// Nature Study Realm Pack 1: Wildroot Preserve
// Adds a dedicated Nature Study realm with observation, plants, animals, weather, habitats, tracking, and field journaling.
// Uses subject key "Nature" for engine simplicity, while the realm text calls it Nature Study.
// Adds starter Nature grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.
// Uses existing lesson/portfolio/boss systems. Minimal engine risk.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const natureRooms = {
    wildrootRoad1:{
      title:"Fernfoot Path",
      zone:"Wildroot Road",
      text:"A soft dirt path leaves town under arching branches. Ferns line the edges, and little wooden signs show leaves, feathers, pawprints, mushrooms, clouds, and acorns.",
      exits:{southeast:"townSquare",east:"wildrootRoad2"}
    },
    wildrootRoad2:{
      title:"Birdcall Bend",
      zone:"Wildroot Road",
      text:"The path bends beside a thicket alive with chirps and rustles. A small listening post holds carved wooden ears and a sign that reads: Slow down. Nature speaks quietly.",
      exits:{west:"wildrootRoad1",east:"wildrootGate"}
    },
    wildrootGate:{
      title:"Wildroot Gate",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"A living arch of twisted roots and bright leaves opens into Wildroot Preserve. The air smells like soil, moss, rain, and growing things.",
      npc:{name:"Ranger Moss",desc:"A calm nature guide with a walking stick, field notebook, and muddy boots.",text:"Ranger Moss smiles. 'Nature study begins with noticing. Look closely, listen carefully, and ask good questions.'"},
      exits:{west:"wildrootRoad2",east:"observationGrove",south:"leafLibrary"}
    },
    observationGrove:{
      title:"Observation Grove",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"A ring of benches sits beneath tall trees. Magnifying glasses, field cards, and sketch boards rest on a stump table. Everything here invites careful looking.",
      npc:{name:"Juniper Scout",desc:"A young trail scout who teaches observation, field notes, and careful descriptions.",text:"Juniper holds up a notebook. 'Do not just say leaf. Say smooth leaf, jagged edge, dark green top, pale underside.'"},
      exits:{west:"wildrootGate",east:"pondwatch",south:"habitatHollow"}
    },
    leafLibrary:{
      title:"Leaf Library",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"Pressed leaves, bark rubbings, seed pods, and flower diagrams fill this quiet shelter. Shelves are labeled roots, stems, leaves, flowers, seeds, cones, bark, and fruit.",
      npc:{name:"Professor Rootwick",desc:"A mossy old botanist who teaches plant parts, life cycles, and careful plant comparisons.",text:"Rootwick lifts a seed pod. 'Plants may stand still, but they are busy living, growing, and solving problems.'"},
      exits:{north:"wildrootGate",east:"habitatHollow",south:"weatherRock"}
    },
    habitatHollow:{
      title:"Habitat Hollow",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"The hollow contains small habitat models: woodland, pond, meadow, cave, stream, garden, and fallen log. Tiny signs show food, water, shelter, and space.",
      npc:{name:"Hollow Hare",desc:"A talking hare who teaches habitats, animal needs, and adaptations.",text:"Hollow Hare twitches his nose. 'A habitat is not just a place. It is a place that gives a living thing what it needs.'"},
      exits:{north:"observationGrove",west:"leafLibrary",east:"trackTrail",south:"weatherRock"}
    },
    pondwatch:{
      title:"Pondwatch Pier",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"A little wooden pier reaches over a clear pond. Dragonflies hover above lily pads. Tadpoles flick through shallow water, and reeds whisper along the bank.",
      npc:{name:"Reed the Pondkeeper",desc:"A patient pond watcher who teaches water habitats, frogs, insects, and life cycles.",text:"Reed points into the water. 'A pond is a whole little world. Watch one quiet minute and you will see ten lessons.'"},
      exits:{west:"observationGrove",south:"trackTrail"}
    },
    trackTrail:{
      title:"Track Trail",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"Soft mud holds prints from birds, rabbits, deer, raccoons, and beetles. A rack of plaster cast examples helps learners compare toes, claws, hooves, and stride patterns.",
      npc:{name:"Tracker Wren",desc:"A sharp-eyed tracker who teaches animal signs, tracks, and evidence.",text:"Wren kneels by a print. 'A track is a clue, not a complete story. Look for more clues before you decide.'"},
      exits:{north:"pondwatch",west:"habitatHollow",south:"weatherRock"}
    },
    weatherRock:{
      title:"Weather Rock",
      zone:"Wildroot Preserve",
      subject:"Nature",
      text:"A broad flat rock sits in a clearing beside a rain gauge, wind ribbon, shadow stick, and cloud chart. The sky feels close here.",
      npc:{name:"Cloudwatch Nora",desc:"A friendly weather watcher who teaches clouds, seasons, wind, rain, and field measurements.",text:"Nora checks the wind ribbon. 'Weather is today's sky story. Climate is the long memory of a place.'"},
      exits:{north:"habitatHollow",west:"leafLibrary",east:"trackTrail"}
    }
  };

  Object.assign(ROOMS, natureRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.northwest) ROOMS.townSquare.exits.northwest = "wildrootRoad1";
    else if(!ROOMS.townSquare.exits.southeast) ROOMS.townSquare.exits.southeast = "wildrootRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Nature = window.LR_REWARDS.Nature || [];
  window.LR_REWARDS.Nature.push(
    {name:"Pressed Leaf Card",slot:"wall"},
    {name:"Tiny Field Notebook",slot:"desk"},
    {name:"Acorn Jar",slot:"shelf"},
    {name:"Pondwatch Lily Tile",slot:"shelf"},
    {name:"Track Cast Plaque",slot:"wall"},
    {name:"Weather Ribbon",slot:"wall"},
    {name:"Habitat Hollow Model",slot:"shelf"},
    {name:"Wildroot Walking Stick",slot:"shelf"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Nature = {display:"Nature Study / Plants / Animals",targetCorrect:160,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Nature = {display:"Nature Study / Habitats / Field Notes",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Nature = {display:"Nature Study / Ecology / Evidence",targetCorrect:240,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Nature")) cfg.assignmentSubjects[child].push("Nature");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Nature:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Nature:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Nature:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Nature = {
    zone:"Wildroot Preserve",
    units:[
      {id:"G1-NAT-OBSERVE",title:"Careful Observation",goal:"Use senses and simple words to describe plants, animals, weather, and places.",targetLessons:100,skills:["observe","describe","same","different","field notes"]},
      {id:"G1-NAT-PLANTS",title:"Plant Parts and Growth",goal:"Recognize roots, stems, leaves, flowers, seeds, and basic plant needs.",targetLessons:120,skills:["roots","stems","leaves","flowers","seeds","water","light"]},
      {id:"G1-NAT-ANIMALS",title:"Animals and Habitats",goal:"Understand animal needs, habitats, and simple body-part adaptations.",targetLessons:120,skills:["habitat","food","water","shelter","body parts","tracks"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Nature = {
    zone:"Wildroot Preserve",
    units:[
      {id:"G6-NAT-FIELD",title:"Field Notes and Evidence",goal:"Use careful observation, measurements, and evidence in nature study.",targetLessons:150,skills:["field notes","evidence","measurement","description","comparison"]},
      {id:"G6-NAT-ECOLOGY",title:"Habitats and Ecosystems",goal:"Explain habitats, populations, food webs, adaptations, and environmental relationships.",targetLessons:170,skills:["habitat","ecosystem","food web","adaptation","population","niche"]},
      {id:"G6-NAT-WEATHER",title:"Weather and Seasonal Patterns",goal:"Observe weather, clouds, wind, precipitation, and seasonal changes.",targetLessons:120,skills:["weather","clouds","wind","rain","season","pattern"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Nature = {
    zone:"Wildroot Preserve",
    units:[
      {id:"G7-NAT-ECOLOGY",title:"Ecology and Systems",goal:"Analyze ecosystems using energy flow, interactions, adaptations, and limiting factors.",targetLessons:170,skills:["energy flow","food web","limiting factor","adaptation","ecosystem"]},
      {id:"G7-NAT-EVIDENCE",title:"Evidence From Nature",goal:"Use tracks, patterns, field notes, and observations to support claims.",targetLessons:150,skills:["evidence","inference","claim","field data","pattern"]},
      {id:"G7-NAT-CONSERVATION",title:"Stewardship and Conservation",goal:"Understand responsible care of land, water, wildlife, and natural resources.",targetLessons:140,skills:["conservation","stewardship","resource","habitat protection","impact"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-NAT-LEAF-1",subject:"Nature",unit:"G1-NAT-OBSERVE",title:"Leaf Observation",prompt:"Look at a leaf or pretend leaf. Draw it or describe it. Tell its color, shape, edge, and one detail you notice.",helper:"Use words like smooth, bumpy, pointed, round, dark, light, big, or small.",estimatedMinutes:20},
    {id:"LUNA-NAT-ANIMAL-1",subject:"Nature",unit:"G1-NAT-ANIMALS",title:"Animal Needs Picture",prompt:"Draw or describe an animal and show what it needs: food, water, shelter, and space.",helper:"Think about where the animal lives and what helps it stay safe.",estimatedMinutes:20}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-NAT-FIELDNOTE-1",subject:"Nature",unit:"G6-NAT-FIELD",title:"Field Note Entry",prompt:"Write a field note about something in nature. Include date, place, weather, object observed, and three careful details.",helper:"Do not just name it. Describe it with evidence.",estimatedMinutes:25},
    {id:"AVA-NAT-HABITAT-1",subject:"Nature",unit:"G6-NAT-ECOLOGY",title:"Habitat Explanation",prompt:"Choose one habitat and explain how it provides food, water, shelter, and space for a living thing.",helper:"Use a specific animal or plant example.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-NAT-EVIDENCE-1",subject:"Nature",unit:"G7-NAT-EVIDENCE",title:"Nature Claim With Evidence",prompt:"Make a claim about an animal, plant, habitat, or weather pattern, then support it with at least two observations.",helper:"Use claim, evidence, and reasoning.",estimatedMinutes:30},
    {id:"MICHAEL-NAT-CONSERVE-1",subject:"Nature",unit:"G7-NAT-CONSERVATION",title:"Stewardship Response",prompt:"Explain one practical way people can protect a habitat or resource and why it matters.",helper:"Mention cause, effect, and responsibility.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addNatureLadder(child){
    LR_addLessons(child,"Nature",[
      {gradeBand:"K",unit:"K-NAT-OBSERVE",skill:"using senses",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Nature study begins by noticing.",
       workedExample:"You can notice a leaf's color, shape, and size.",
       guidedPractice:"Choose something you can observe.",
       q:"Which can you observe about a leaf?",c:["color","subtraction","capital city"],a:"color",
       explain:"Color is something you can observe."},

      {gradeBand:"G1",unit:"G1-NAT-PLANTS",skill:"plant parts",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Plants have parts that help them live.",
       workedExample:"Roots hold the plant in soil. Leaves help the plant use sunlight.",
       guidedPractice:"Think about the job of each plant part.",
       q:"Which plant part helps hold the plant in soil?",c:["roots","flower","leaf"],a:"roots",
       explain:"Roots help hold the plant in the soil."},

      {gradeBand:"G2",unit:"G2-NAT-HABITAT",skill:"habitats",difficulty:"grade 2",mode:"foundation",
       miniLesson:"A habitat is the place where a living thing gets what it needs.",
       workedExample:"A frog may live near a pond because it needs water and insects.",
       guidedPractice:"Choose the place that fits the animal.",
       q:"Which habitat fits a frog best?",c:["pond","dry shelf","empty box"],a:"pond",
       explain:"A pond gives a frog water and food sources."},

      {gradeBand:"G3",unit:"G3-NAT-LIFECYCLE",skill:"life cycles",difficulty:"grade 3",mode:"foundation",
       miniLesson:"Living things have life cycles.",
       workedExample:"A butterfly begins as an egg, becomes a caterpillar, forms a chrysalis, and becomes an adult butterfly.",
       guidedPractice:"Think about stages of growth.",
       q:"Which is part of a butterfly life cycle?",c:["caterpillar","chair","coin"],a:"caterpillar",
       explain:"A caterpillar is a butterfly life-cycle stage."},

      {gradeBand:"G4",unit:"G4-NAT-ADAPT",skill:"adaptations",difficulty:"grade 4",mode:"foundation",
       miniLesson:"An adaptation is a trait or behavior that helps a living thing survive.",
       workedExample:"A bird's beak shape can help it get certain kinds of food.",
       guidedPractice:"Ask how the trait helps the organism.",
       q:"A thick coat helping an animal stay warm is an...",c:["adaptation","equation","opinion"],a:"adaptation",
       explain:"The thick coat helps the animal survive cold."},

      {gradeBand:"G5",unit:"G5-NAT-FOODCHAIN",skill:"food chains",difficulty:"grade 5",mode:"foundation",
       miniLesson:"A food chain shows how energy moves from one living thing to another.",
       workedExample:"Grass → rabbit → fox shows energy moving from plant to herbivore to predator.",
       guidedPractice:"Find the producer first.",
       q:"In grass → rabbit → fox, the producer is...",c:["grass","rabbit","fox"],a:"grass",
       explain:"Grass makes its own food using sunlight, so it is the producer."},

      {gradeBand:"G6",unit:"G6-NAT-ECOLOGY",skill:"ecosystems",difficulty:"grade 6",mode:"foundation",
       miniLesson:"An ecosystem includes living and nonliving things interacting.",
       workedExample:"A pond ecosystem includes water, sunlight, plants, insects, frogs, fish, and mud.",
       guidedPractice:"Look for living and nonliving parts working together.",
       q:"Which includes living and nonliving parts interacting?",c:["ecosystem","sentence","fraction"],a:"ecosystem",
       explain:"An ecosystem includes organisms and their environment."},

      {gradeBand:"G7",unit:"G7-NAT-EVIDENCE",skill:"tracking evidence",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Animal signs can be evidence, but one clue is rarely the whole story.",
       workedExample:"Tracks near a pond may suggest an animal visited, but more clues help support the conclusion.",
       guidedPractice:"Look for multiple pieces of evidence.",
       q:"A track is best treated as...",c:["evidence","final proof of everything","a spelling word"],a:"evidence",
       explain:"A track is evidence that can support a conclusion when combined with other clues."},

      {gradeBand:"G8",unit:"G8-NAT-SYSTEMS",skill:"limiting factors",difficulty:"grade 8",mode:"foundation",
       miniLesson:"A limiting factor is something that restricts population growth.",
       workedExample:"Limited water, food, space, or shelter can limit how many organisms live in an area.",
       guidedPractice:"Ask what resource is restricting growth.",
       q:"Which could be a limiting factor?",c:["limited water","unlimited food","extra empty space"],a:"limited water",
       explain:"Limited water can restrict how many organisms survive in an area."}
    ]);
  }

  LR_addNatureLadder("Luna");
  LR_addNatureLadder("Ava");
  LR_addNatureLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Nature = [
    {title:"Leaf Library Trial",intro:"Professor Rootwick holds up a tiny plant.",q:"Which plant part helps hold the plant in soil?",c:["roots","flower","petal color"],a:"roots",reward:"Pressed Leaf Badge"},
    {title:"Habitat Hollow Trial",intro:"Hollow Hare hops beside a pond model.",q:"A habitat gives a living thing what it...",c:["needs","spells","counts"],a:"needs",reward:"Habitat Hollow Ribbon"}
  ];

  window.LR_BOSS_CONTENT.Ava.Nature = [
    {title:"Field Note Trial",intro:"Juniper Scout opens a field notebook.",q:"A strong field note should include careful...",c:["observations","random guesses","blank lines only"],a:"observations",reward:"Field Note Seal"},
    {title:"Pondwatch Food Web Trial",intro:"Reed points to grass, insects, frogs, and birds.",q:"In a food chain, energy usually starts with...",c:["producers","predators only","rocks"],a:"producers",reward:"Pondwatch Token"}
  ];

  window.LR_BOSS_CONTENT.Michael.Nature = [
    {title:"Track Trail Evidence Trial",intro:"Tracker Wren kneels by muddy prints.",q:"A track is evidence that should be combined with...",c:["more clues","a random guess","only color"],a:"more clues",reward:"Tracker Lens"},
    {title:"Limiting Factor Trial",intro:"The preserve grows quiet during a dry season.",q:"Limited water can act as a...",c:["limiting factor","sentence fragment","map key"],a:"limiting factor",reward:"Wildroot Steward Badge"}
  ];
})();
