// Curriculum Pack 3A: Grade Math Depth + Written Response Practice
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Math",[
 {teach:"You can make ten to add faster.",practice:"9 + 6 = 10 + 5 = 15.",q:"9 + 6 = ?",c:["15","14","16"],a:"15"},
 {teach:"You can break apart numbers to add.",practice:"8 + 7 = 8 + 2 + 5 = 15.",q:"8 + 7 = ?",c:["15","14","16"],a:"15"},
 {teach:"Subtraction facts connect to addition facts.",practice:"13 - 5 = 8 because 8 + 5 = 13.",q:"13 - 5 = ?",c:["8","7","9"],a:"8"},
 {teach:"A number with tens and ones can be built with place value.",practice:"46 is 4 tens and 6 ones.",q:"46 has how many tens?",c:["4","6","46"],a:"4"},
 {teach:"The digit in the ones place tells how many ones.",practice:"73 has 7 tens and 3 ones.",q:"73 has how many ones?",c:["3","7","73"],a:"3"},
 {teach:"Counting by tens helps count larger numbers.",practice:"10, 20, 30, 40.",q:"What comes after 30 when counting by tens?",c:["40","31","35"],a:"40"},
 {teach:"A quarter is 25 cents.",practice:"Two quarters are 50 cents.",q:"Two quarters equal...",c:["50 cents","25 cents","10 cents"],a:"50 cents"},
 {teach:"The hour hand is shorter and tells the hour.",practice:"If the short hand points to 3, it is 3 o'clock.",q:"The short hand tells the...",c:["hour","minute","day"],a:"hour"},
 {teach:"A line of symmetry splits a shape into matching halves.",practice:"A heart can have symmetry.",q:"Symmetry means matching...",c:["halves","colors","letters only"],a:"halves"},
 {teach:"Data can be shown with a picture graph.",practice:"Each picture can stand for one item.",q:"A picture graph shows...",c:["data","weather only","sentences only"],a:"data"}
]);

LR_addLessons("Luna","Reading",[
 {teach:"Long a can be spelled ai in the middle of words.",practice:"rain, train, snail",q:"Which word has ai?",c:["rain","run","rock"],a:"rain"},
 {teach:"Long e can be spelled ee.",practice:"tree, sheep, feet",q:"Which word has ee?",c:["tree","trap","ship"],a:"tree"},
 {teach:"Long o can be spelled oa.",practice:"boat, road, goat",q:"Which word has oa?",c:["boat","bat","bug"],a:"boat"},
 {teach:"A retell tells important events in order.",practice:"Beginning, middle, end.",q:"A good retell uses...",c:["order","random words","only the title"],a:"order"},
 {teach:"Main idea is what a story or passage is mostly about.",practice:"A passage about frogs is mostly about frogs.",q:"Main idea means...",c:["mostly about","page color","one letter"],a:"mostly about"},
 {teach:"A detail tells more about the main idea.",practice:"Frogs have long back legs.",q:"Which is a detail?",c:["long back legs","frog passage","the book"],a:"long back legs"}
]);

LR_addLessons("Luna","English",[
 {teach:"A sentence can be made stronger by adding where.",practice:"The cat slept on the rug.",q:"Which tells where?",c:["on the rug","cat","slept"],a:"on the rug"},
 {teach:"A sentence can be made stronger by adding when.",practice:"The owl flew at night.",q:"Which tells when?",c:["at night","owl","flew"],a:"at night"},
 {teach:"A good answer can restate the question.",practice:"Question: Where did the fox go? Answer: The fox went to the den.",q:"Which answer restates?",c:["The fox went to the den.","Den.","Yes."],a:"The fox went to the den."},
 {teach:"A story response can tell what happened and why.",practice:"The rabbit hid because it heard thunder.",q:"Which word often tells why?",c:["because","and","the"],a:"because"}
]);

LR_addLessons("Ava","Math",[
 {teach:"A proportional relationship can be written as y = kx.",practice:"If k = 4, then y = 4x.",q:"In y = 4x, the constant of proportionality is...",c:["4","x","y"],a:"4"},
 {teach:"Percent can be found using part divided by whole.",practice:"15 out of 60 is 25%.",q:"15 out of 60 equals...",c:["25%","15%","60%"],a:"25%"},
 {teach:"Markup increases an original amount by a percent.",practice:"A 20% markup on 50 adds 10.",q:"20% of 50 is...",c:["10","20","5"],a:"10"},
 {teach:"A discount decreases an original amount by a percent.",practice:"A 25% discount on 80 takes off 20.",q:"25% of 80 is...",c:["20","25","40"],a:"20"},
 {teach:"Integer multiplication: same signs give a positive product.",practice:"-4 × -3 = 12.",q:"-4 × -3 = ?",c:["12","-12","7"],a:"12"},
 {teach:"Integer multiplication: different signs give a negative product.",practice:"-5 × 6 = -30.",q:"-5 × 6 = ?",c:["-30","30","11"],a:"-30"},
 {teach:"Inequalities can be solved like equations, but multiplying or dividing by a negative flips the sign.",practice:"-2x > 8 becomes x < -4.",q:"When dividing by a negative, the inequality sign...",c:["flips","stays always","disappears"],a:"flips"},
 {teach:"The area of a circle is pi times radius squared.",practice:"A = πr².",q:"Circle area uses radius...",c:["squared","cubed","ignored"],a:"squared"},
 {teach:"A circle's radius is half its diameter.",practice:"Diameter 10 means radius 5.",q:"If diameter is 10, radius is...",c:["5","10","20"],a:"5"},
 {teach:"Mean absolute deviation describes average distance from the mean.",practice:"It measures spread.",q:"MAD measures data...",c:["spread","title","spelling"],a:"spread"}
]);

LR_addLessons("Ava","English",[
 {teach:"A written response should answer the question directly.",practice:"Start with a clear answer.",q:"A response should begin with a clear...",c:["answer","joke","new topic"],a:"answer"},
 {teach:"Evidence should be introduced smoothly.",practice:"The text states...",q:"Which phrase introduces evidence?",c:["The text states","I forgot","Maybe"],a:"The text states"},
 {teach:"Reasoning explains why the evidence matters.",practice:"This shows the character changed because...",q:"Reasoning explains why evidence...",c:["matters","is deleted","is random"],a:"matters"},
 {teach:"A concluding sentence wraps up the response.",practice:"This is why the theme is perseverance.",q:"A conclusion should...",c:["wrap up the idea","start a new topic","ignore the claim"],a:"wrap up the idea"},
 {teach:"Compare means tell how things are alike.",practice:"Both characters are brave.",q:"Compare means tell how things are...",c:["alike","different only","spelled"],a:"alike"},
 {teach:"Contrast means tell how things are different.",practice:"One character is cautious, the other is bold.",q:"Contrast means tell how things are...",c:["different","identical","measured"],a:"different"}
]);

LR_addLessons("Ava","Science",[
 {teach:"A scientific model represents something to help explain it.",practice:"A diagram can model a cell.",q:"A model helps...",c:["explain","hide","guess only"],a:"explain"},
 {teach:"Data tables organize observations.",practice:"Rows and columns can hold measurements.",q:"Data tables organize...",c:["observations","characters only","claims only"],a:"observations"},
 {teach:"A conclusion should be based on evidence.",practice:"Use data from the experiment.",q:"A conclusion should use...",c:["evidence","random opinion","no data"],a:"evidence"},
 {teach:"Independent variable is what the investigator changes.",practice:"Changing water amount in a plant test.",q:"The changed variable is...",c:["independent variable","dependent variable","constant"],a:"independent variable"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Linear equations can be written in slope-intercept form.",practice:"y = mx + b.",q:"Slope-intercept form is...",c:["y = mx + b","a² + b² = c²","F = ma"],a:"y = mx + b"},
 {teach:"Standard form of a linear equation is Ax + By = C.",practice:"2x + 3y = 12.",q:"Standard form looks like...",c:["Ax + By = C","y = kx only","V = lwh"],a:"Ax + By = C"},
 {teach:"To find x-intercept, set y = 0.",practice:"On the x-axis, y is 0.",q:"For x-intercept, set y equal to...",c:["0","1","x"],a:"0"},
 {teach:"To find y-intercept, set x = 0.",practice:"On the y-axis, x is 0.",q:"For y-intercept, set x equal to...",c:["0","1","y"],a:"0"},
 {teach:"A system can be solved by elimination.",practice:"Add equations to cancel a variable.",q:"Elimination tries to cancel a...",c:["variable","paragraph","circle"],a:"variable"},
 {teach:"Functions can be compared by rate of change.",practice:"Greater slope means faster increase.",q:"Rate of change is related to...",c:["slope","area only","volume only"],a:"slope"},
 {teach:"The Pythagorean theorem applies only to right triangles.",practice:"a² + b² = c².",q:"Pythagorean theorem applies to...",c:["right triangles","all shapes","circles only"],a:"right triangles"},
 {teach:"A cone volume is one third the volume of a cylinder with same base and height.",practice:"V = 1/3πr²h.",q:"Cone volume includes the factor...",c:["1/3","2","4"],a:"1/3"},
 {teach:"A two-way table organizes data from two categories.",practice:"Rows and columns compare groups.",q:"Two-way tables compare...",c:["two categories","only one number","only shapes"],a:"two categories"},
 {teach:"A line of best fit models a trend in scatter plot data.",practice:"It approximates the pattern.",q:"Line of best fit models a...",c:["trend","single letter","citation"],a:"trend"}
]);

LR_addLessons("Michael","English",[
 {teach:"A strong written response starts with a precise claim.",practice:"The author shows courage through the character's choices.",q:"A precise claim should be...",c:["clear and specific","vague","unrelated"],a:"clear and specific"},
 {teach:"Embedded evidence fits smoothly into a sentence.",practice:"The author writes, \"...\"",q:"Embedded evidence should fit...",c:["smoothly","randomly","without context"],a:"smoothly"},
 {teach:"Commentary explains the importance of evidence.",practice:"This matters because...",q:"Commentary explains evidence's...",c:["importance","font","spelling"],a:"importance"},
 {teach:"Source reliability depends on author, evidence, date, and purpose.",practice:"Purpose can reveal bias.",q:"Source purpose can reveal...",c:["bias","volume","weather"],a:"bias"},
 {teach:"A counterclaim makes an argument stronger when answered well.",practice:"It shows the writer considered another side.",q:"Addressing counterclaims can make writing...",c:["stronger","weaker always","unrelated"],a:"stronger"},
 {teach:"Transitions show relationships between ideas.",practice:"therefore shows result.",q:"Therefore shows...",c:["result","contrast","time only"],a:"result"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Speed is distance over time, and velocity includes direction.",practice:"North at 30 mph is velocity.",q:"Velocity includes speed and...",c:["direction","mass","density"],a:"direction"},
 {teach:"Acceleration can mean speeding up, slowing down, or changing direction.",practice:"Turning is acceleration.",q:"Acceleration can include changing...",c:["direction","font","source"],a:"direction"},
 {teach:"Work happens when a force moves an object over a distance.",practice:"Pushing a box across a floor.",q:"Work needs force and...",c:["distance","grammar","citizenship"],a:"distance"},
 {teach:"Power is the rate of doing work.",practice:"More work in less time means more power.",q:"Power is rate of...",c:["work","mass","law"],a:"work"}
]);
