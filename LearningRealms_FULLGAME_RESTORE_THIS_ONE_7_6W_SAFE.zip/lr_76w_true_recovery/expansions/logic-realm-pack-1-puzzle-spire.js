// Logic Realm Pack 1: Puzzle Spire
// Adds a dedicated Logic / Critical Thinking realm with patterns, analogies, cause/effect, evidence, puzzles, and reasoning.
// Adds starter Logic grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.
// Uses existing lesson/portfolio/boss systems. Minimal engine risk.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const logicRooms = {
    puzzleRoad1:{
      title:"Riddle Road",
      zone:"Puzzle Road",
      text:"A narrow road twists away from town between stone posts carved with question marks, arrows, spirals, and tiny locked boxes. Every sign seems to ask you to notice what comes next.",
      exits:{south:"townSquare",east:"puzzleRoad2"}
    },
    puzzleRoad2:{
      title:"Pattern Bend",
      zone:"Puzzle Road",
      text:"The road bends around a low wall tiled in repeating shapes: star, moon, star, moon. A brass gate ahead clicks softly like gears inside a clock.",
      exits:{west:"puzzleRoad1",east:"puzzleGate"}
    },
    puzzleGate:{
      title:"Puzzle Spire Gate",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"A tall spiral tower rises from a courtyard of checker stones. The entrance door has three locks: one shaped like a pattern, one like a cause-and-effect chain, and one like a question.",
      npc:{name:"Keeper Cog",desc:"A small clockwork owl who teaches careful thinking.",text:"Keeper Cog blinks with little brass eyelids. 'Logic is not guessing. Logic is noticing, testing, and explaining why.'"},
      exits:{west:"puzzleRoad2",east:"patternCourt",south:"reasoningHall"}
    },
    patternCourt:{
      title:"Pattern Court",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"Colored stones form rows of patterns on the floor. Some repeat by color, some by shape, some by number. A fountain clicks every third splash.",
      npc:{name:"Mosaic Pip",desc:"A cheerful tile sprite who teaches patterns and sequences.",text:"Pip hops from tile to tile. 'Find the rule, and the next step almost tells on itself!'"},
      exits:{west:"puzzleGate",east:"sequenceStairs",south:"analogyAtrium"}
    },
    reasoningHall:{
      title:"Reasoning Hall",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"Long tables hold clue cards, sorting trays, and little wooden tokens labeled because, therefore, maybe, always, never, and prove it.",
      npc:{name:"Master Because",desc:"A calm teacher in a blue cloak who insists every answer needs a reason.",text:"Master Because folds his hands. 'A strong answer says what you think, then why it makes sense.'"},
      exits:{north:"puzzleGate",east:"analogyAtrium",south:"clueLibrary"}
    },
    analogyAtrium:{
      title:"Analogy Atrium",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"Tall windows shine over paired statues: bird and nest, fish and pond, key and lock, seed and tree. Each pair shows a relationship.",
      npc:{name:"Pairsmith Luma",desc:"A silver-haired guide who teaches analogies and relationships.",text:"Luma smiles. 'Analogies are bridges. Find how the first pair connects, then build the second bridge the same way.'"},
      exits:{north:"patternCourt",west:"reasoningHall",east:"causewayBridge"}
    },
    sequenceStairs:{
      title:"Sequence Stairs",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"A staircase climbs in uneven steps labeled 2, 4, 6, 8, then blank. Another rail shows first, next, then, finally. The stairs teach order before height.",
      npc:{name:"Stepwise Ren",desc:"A practical puzzle climber who teaches order, sequences, and multi-step thinking.",text:"Ren tightens a bootlace. 'Most hard problems are just easy steps stacked in the right order.'"},
      exits:{west:"patternCourt",south:"causewayBridge"}
    },
    causewayBridge:{
      title:"Causeway Bridge",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"A stone bridge crosses a dry channel. One side is carved with causes: rain, push, heat, practice. The other side is carved with effects: puddles, motion, melting, improvement.",
      npc:{name:"Chainlink Ada",desc:"A bridgekeeper who teaches cause and effect.",text:"Ada taps a chain. 'A cause starts something. An effect is what happens because of it.'"},
      exits:{north:"sequenceStairs",west:"analogyAtrium",south:"logicLab"}
    },
    clueLibrary:{
      title:"Clue Library",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"Shelves hold mystery cards, evidence tags, and little magnifying glasses. A sign reads: Do not believe every clue. Test it.",
      npc:{name:"Inspector Nib",desc:"A tiny mouse detective who teaches evidence, assumptions, and careful conclusions.",text:"Inspector Nib twitches his whiskers. 'A clue is useful only when it actually supports the conclusion.'"},
      exits:{north:"reasoningHall",east:"logicLab"}
    },
    logicLab:{
      title:"Logic Lab",
      zone:"Puzzle Spire",
      subject:"Logic",
      text:"The top chamber glows with blue puzzle light. Gears turn slowly, mirrors bounce beams across the walls, and a final locked chest waits for careful thinkers.",
      npc:{name:"The Riddle Engine",desc:"A humming brass machine that asks final reasoning challenges.",text:"The Riddle Engine whirs. 'State your claim. Test your rule. Check your evidence. Then answer.'"},
      exits:{north:"causewayBridge",west:"clueLibrary"}
    }
  };

  Object.assign(ROOMS, logicRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.northeast) ROOMS.townSquare.exits.northeast = "puzzleRoad1";
    else if(!ROOMS.townSquare.exits.east) ROOMS.townSquare.exits.east = "puzzleRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Logic = window.LR_REWARDS.Logic || [];
  window.LR_REWARDS.Logic.push(
    {name:"Tiny Puzzle Gear",slot:"shelf"},
    {name:"Pattern Tile Set",slot:"desk"},
    {name:"Because Token",slot:"shelf"},
    {name:"Analogy Bridge Charm",slot:"wall"},
    {name:"Cause Chain Plaque",slot:"wall"},
    {name:"Inspector Lens",slot:"desk"},
    {name:"Sequence Stair Model",slot:"shelf"},
    {name:"Riddle Engine Cog",slot:"shelf"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Logic = {display:"Logic / Patterns / Thinking",targetCorrect:150,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Logic = {display:"Logic / Evidence / Reasoning",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Logic = {display:"Logic / Critical Thinking / Analysis",targetCorrect:240,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Logic")) cfg.assignmentSubjects[child].push("Logic");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Logic:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Logic:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Logic:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Logic = {
    zone:"Puzzle Spire",
    units:[
      {id:"G1-LOGIC-PATTERN",title:"Patterns and Sorting",goal:"Recognize simple patterns, categories, and what comes next.",targetLessons:100,skills:["patterns","sorting","same","different","next"]},
      {id:"G1-LOGIC-CAUSE",title:"Cause and Effect",goal:"Understand simple cause and effect relationships.",targetLessons:90,skills:["cause","effect","because","what happened","why"]},
      {id:"G1-LOGIC-REASON",title:"Give a Reason",goal:"Answer simple questions with a reason.",targetLessons:80,skills:["reason","because","evidence","explain"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Logic = {
    zone:"Puzzle Spire",
    units:[
      {id:"G6-LOGIC-EVIDENCE",title:"Evidence and Conclusions",goal:"Use evidence to support reasonable conclusions.",targetLessons:150,skills:["evidence","conclusion","support","assumption","proof"]},
      {id:"G6-LOGIC-RELATION",title:"Relationships and Analogies",goal:"Recognize relationships, analogies, patterns, and categories.",targetLessons:140,skills:["analogies","relationships","categories","sequences","patterns"]},
      {id:"G6-LOGIC-ARGUMENT",title:"Simple Argument Logic",goal:"Distinguish claims, reasons, evidence, and weak support.",targetLessons:140,skills:["claim","reason","evidence","support","weak argument"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Logic = {
    zone:"Puzzle Spire",
    units:[
      {id:"G7-LOGIC-ARGUMENT",title:"Argument Evaluation",goal:"Evaluate claims, evidence, assumptions, and reasoning.",targetLessons:160,skills:["claim","evidence","assumption","inference","reasoning"]},
      {id:"G7-LOGIC-FALLACY",title:"Flawed Reasoning Basics",goal:"Recognize common weak reasoning patterns without overgeneralizing.",targetLessons:140,skills:["overgeneralization","false choice","irrelevant evidence","unsupported claim"]},
      {id:"G7-LOGIC-PROBLEM",title:"Problem Solving Systems",goal:"Use stepwise reasoning, constraints, and checking to solve problems.",targetLessons:140,skills:["constraints","sequence","logic grid","test cases","check answer"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-LOGIC-PATTERN-1",subject:"Logic",unit:"G1-LOGIC-PATTERN",title:"Make a Pattern",prompt:"Make or draw a repeating pattern. Tell what comes next and why.",helper:"Try red-blue-red-blue, circle-square-circle-square, or clap-tap-clap-tap.",estimatedMinutes:15},
    {id:"LUNA-LOGIC-BECAUSE-1",subject:"Logic",unit:"G1-LOGIC-REASON",title:"Answer With Because",prompt:"Answer one question using the word because. Example: I picked the red tile because it comes next.",helper:"Use: I think ___ because ___.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-LOGIC-EVIDENCE-1",subject:"Logic",unit:"G6-LOGIC-EVIDENCE",title:"Evidence or Guess?",prompt:"Write a claim and then list one piece of evidence that supports it. Explain why it is stronger than a guess.",helper:"Use claim, evidence, and reasoning.",estimatedMinutes:25},
    {id:"AVA-LOGIC-ANALOGY-1",subject:"Logic",unit:"G6-LOGIC-RELATION",title:"Build an Analogy",prompt:"Create three analogies and explain the relationship in each one.",helper:"Example: bird is to nest as fish is to pond.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-LOGIC-ARG-1",subject:"Logic",unit:"G7-LOGIC-ARGUMENT",title:"Evaluate an Argument",prompt:"Write a short argument, then label the claim, evidence, and assumption. Explain whether the argument is strong or weak.",helper:"Look for missing proof or hidden assumptions.",estimatedMinutes:30},
    {id:"MICHAEL-LOGIC-CONSTRAINT-1",subject:"Logic",unit:"G7-LOGIC-PROBLEM",title:"Constraint Puzzle Explanation",prompt:"Make a small logic puzzle with two or three clues, then explain the solution step by step.",helper:"Keep it solvable. Each clue should remove possibilities.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addLogicLadder(child){
    LR_addLessons(child,"Logic",[
      {gradeBand:"K",unit:"K-LOGIC-SAME",skill:"same and different",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Logic starts with noticing what is the same and what is different.",
       workedExample:"A red circle and a blue circle are the same shape but different colors.",
       guidedPractice:"Look for one thing that matches.",
       q:"A red circle and a blue circle are the same...",c:["shape","color","size always"],a:"shape",
       explain:"Both are circles, so they are the same shape."},

      {gradeBand:"G1",unit:"G1-LOGIC-PATTERN",skill:"patterns",difficulty:"grade 1",mode:"foundation",
       miniLesson:"A pattern repeats by a rule.",
       workedExample:"Star, moon, star, moon repeats. The next shape is star.",
       guidedPractice:"Find the repeated part.",
       q:"Star, moon, star, moon, what comes next?",c:["star","moon","tree"],a:"star",
       explain:"The pattern repeats star, moon."},

      {gradeBand:"G2",unit:"G2-LOGIC-CAUSE",skill:"cause and effect",difficulty:"grade 2",mode:"foundation",
       miniLesson:"A cause makes something happen. An effect is what happens because of it.",
       workedExample:"The glass fell, so it broke. Falling is the cause. Breaking is the effect.",
       guidedPractice:"Ask why it happened.",
       q:"It rained, so the ground got wet. What was the cause?",c:["it rained","ground got wet","the ground existed"],a:"it rained",
       explain:"The rain caused the ground to get wet."},

      {gradeBand:"G3",unit:"G3-LOGIC-SEQUENCE",skill:"sequences",difficulty:"grade 3",mode:"foundation",
       miniLesson:"A sequence follows an order or rule.",
       workedExample:"2, 4, 6, 8 follows a rule of adding 2.",
       guidedPractice:"Find the rule between numbers.",
       q:"2, 4, 6, 8, what comes next?",c:["10","9","12"],a:"10",
       explain:"The sequence adds 2 each time."},

      {gradeBand:"G4",unit:"G4-LOGIC-ANALOGY",skill:"analogies",difficulty:"grade 4",mode:"foundation",
       miniLesson:"An analogy compares relationships.",
       workedExample:"Bird is to nest as fish is to pond. A bird lives in a nest, and a fish lives in a pond.",
       guidedPractice:"Find how the first pair relates.",
       q:"Bird is to nest as fish is to...",c:["pond","tree","book"],a:"pond",
       explain:"A bird lives in a nest, and a fish lives in a pond."},

      {gradeBand:"G5",unit:"G5-LOGIC-EVIDENCE",skill:"evidence",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Evidence supports a conclusion.",
       workedExample:"If muddy footprints lead to the door, that evidence may support the conclusion that someone walked there after rain.",
       guidedPractice:"Choose the clue that supports the conclusion.",
       q:"Which is evidence that it rained?",c:["wet ground","a red hat","a closed book"],a:"wet ground",
       explain:"Wet ground can support the idea that it rained."},

      {gradeBand:"G6",unit:"G6-LOGIC-ASSUMPTION",skill:"assumptions",difficulty:"grade 6",mode:"foundation",
       miniLesson:"An assumption is something accepted without being directly proven.",
       workedExample:"If someone says the road is safe because it looks quiet, they may assume quiet means safe.",
       guidedPractice:"Look for what the thinker is taking for granted.",
       q:"An assumption is something accepted without direct...",c:["proof","color","height"],a:"proof",
       explain:"Assumptions are not directly proven."},

      {gradeBand:"G7",unit:"G7-LOGIC-ARGUMENT",skill:"argument evaluation",difficulty:"grade 7",mode:"foundation",
       miniLesson:"To evaluate an argument, check the claim, reasons, evidence, and assumptions.",
       workedExample:"A claim with weak or unrelated evidence is not well supported.",
       guidedPractice:"Ask whether the evidence actually proves the claim.",
       q:"An argument is stronger when evidence is...",c:["relevant","random","missing"],a:"relevant",
       explain:"Relevant evidence supports the claim."},

      {gradeBand:"G8",unit:"G8-LOGIC-FALLACY",skill:"false choice",difficulty:"grade 8",mode:"foundation",
       miniLesson:"A false choice makes it seem like there are only two options when more may exist.",
       workedExample:"Saying 'Either we build a huge bridge or we do nothing' may ignore smaller repair options.",
       guidedPractice:"Ask whether other choices exist.",
       q:"A false choice ignores possible...",c:["other options","correct spelling","map symbols"],a:"other options",
       explain:"A false choice acts like only two choices exist when there may be more."}
    ]);
  }

  LR_addLogicLadder("Luna");
  LR_addLogicLadder("Ava");
  LR_addLogicLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Logic = [
    {title:"Pattern Court Trial",intro:"Mosaic Pip points to a row of tiles: star, moon, star, moon.",q:"What comes next: star, moon, star, moon?",c:["star","moon","tree"],a:"star",reward:"Pattern Tile Badge"},
    {title:"Because Token Trial",intro:"Master Because asks Luna to choose the word that gives a reason.",q:"Which word helps give a reason?",c:["because","under","blue"],a:"because",reward:"Because Token"}
  ];

  window.LR_BOSS_CONTENT.Ava.Logic = [
    {title:"Analogy Atrium Trial",intro:"Pairsmith Luma presents two pairs.",q:"Bird is to nest as fish is to...",c:["pond","tree","chair"],a:"pond",reward:"Analogy Bridge Badge"},
    {title:"Inspector Nib's Evidence Trial",intro:"Inspector Nib asks for proof, not a guess.",q:"Evidence should support the...",c:["conclusion","weather","page color"],a:"conclusion",reward:"Evidence Lens"}
  ];

  window.LR_BOSS_CONTENT.Michael.Logic = [
    {title:"Argument Evaluation Trial",intro:"The Riddle Engine hums and asks for a strong argument.",q:"An argument is stronger when evidence is...",c:["relevant","random","missing"],a:"relevant",reward:"Riddle Engine Cog"},
    {title:"False Choice Trial",intro:"The tower offers two doors, but a third tiny door glows behind a curtain.",q:"A false choice ignores...",c:["other possible options","all punctuation","map scale"],a:"other possible options",reward:"Third Door Key"}
  ];
})();
