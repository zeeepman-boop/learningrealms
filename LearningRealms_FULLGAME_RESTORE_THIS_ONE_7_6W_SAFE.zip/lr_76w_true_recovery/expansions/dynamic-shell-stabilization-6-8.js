/* LearningRealms Dynamic Shell Stabilization 6.8
   Makes the dynamic adventure screen the single visible game surface.
   Existing content stays intact. Old action/sidebar systems are bridged into the main screen.
*/
(function(){
  'use strict';
  if(window.__LR68_DYNAMIC_SHELL_STABILIZATION__) return;
  window.__LR68_DYNAMIC_SHELL_STABILIZATION__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function stripEmoji(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){
    try{ if(window.state) return window.state; }catch(e){}
    try{ if(typeof state !== 'undefined' && state) return state; }catch(e){}
    return null;
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined' && ROOMS) return ROOMS; }catch(e){}
    return {};
  }
  function getLoc(){ var s=getState(); return (s && s.loc) ? s.loc : 'crossroads'; }
  function getRoom(id){
    var rooms = getRooms();
    var key = id || getLoc();
    try{ if(!id && typeof window.room === 'function') return window.room() || rooms[key] || {}; }catch(e){}
    try{ if(!id && typeof room === 'function') return room() || rooms[key] || {}; }catch(e){}
    return rooms[key] || rooms.crossroads || {};
  }
  function call(name){
    var args = Array.prototype.slice.call(arguments,1);
    try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR68 call failed', name, e); }
    try{ if(typeof eval(name) === 'function') return eval(name).apply(window,args); }catch(e){}
    return undefined;
  }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }
  function feedback(msg){ var fb=byId('feedback'); if(fb) fb.textContent = msg || ''; }
  function activeChildName(){ try{ if(typeof activeChild !== 'undefined') return activeChild; }catch(e){} return ''; }

  function ensureMount(){
    try{
      document.body.classList.add('lrDynamicAdventureMode','lr68DynamicShell');
      document.body.classList.remove('homeMode');
    }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var firstCard = document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; }
      if(firstCard){ firstCard.style.display='block'; firstCard.style.visibility='visible'; firstCard.style.opacity='1'; firstCard.style.width='100%'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen';
      if(firstCard.firstChild) firstCard.insertBefore(mount, firstCard.firstChild);
      else firstCard.appendChild(mount);
    }
    mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen';
    mount.style.display='block';
    mount.style.visibility='visible';
    mount.style.opacity='1';
    mount.style.width='100%';
    mount.style.minHeight='650px';
    return mount;
  }

  function hideOldSurfaces(){
    var ids = ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','movementControls','leftActionButtons'];
    ids.forEach(function(id){
      var el = byId(id);
      if(el){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
    });
    try{
      document.querySelectorAll('.compassBox,.compassGrid,.movementButtons,.travelButtons,.tinyTravelFooter,.lrAdventurePanel,.lrExplorePanel,.lr65ExplorePanel,.lr67ChoicePanelClone').forEach(function(el){
        el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden';
      });
    }catch(e){}
  }

  function levelLine(){
    var s = getState() || {};
    var p = [];
    if(activeChildName()) p.push(activeChildName());
    if(typeof s.room !== 'undefined') p.push('Room ' + s.room);
    if(typeof s.sparks !== 'undefined') p.push((s.sparks || 0) + ' Sparks');
    if(typeof s.streak !== 'undefined') p.push('Streak ' + (s.streak || 0));
    return p.join(' · ');
  }
  function subjectLine(subject){
    var s = String(subject || '').toLowerCase();
    if(!s) return '';
    if(s.indexOf('reading') >= 0) return 'This path uses story clues, careful reading, and proof from the text.';
    if(s.indexOf('math') >= 0) return 'This path uses numbers, patterns, models, and careful problem solving.';
    if(s.indexOf('science') >= 0) return 'This path uses observation, evidence, testing, and clear explanations.';
    if(s.indexOf('writing') >= 0) return 'This path uses words, sentences, records, and clear explanations.';
    if(s.indexOf('history') >= 0) return 'This path uses old evidence, maps, dates, people, and cause-and-effect clues.';
    if(s.indexOf('civics') >= 0) return 'This path uses rules, responsibility, service, and community choices.';
    if(s.indexOf('geography') >= 0) return 'This path uses maps, places, landforms, routes, and location clues.';
    if(s.indexOf('economics') >= 0) return 'This path uses choices, trade, saving, needs, wants, and value.';
    if(s.indexOf('logic') >= 0) return 'This path uses evidence, careful thinking, and avoiding weak reasoning.';
    if(s.indexOf('nature') >= 0 || s.indexOf('health') >= 0) return 'This path uses safe observation, living things, habits, rest, food, and movement.';
    if(s.indexOf('music') >= 0 || s.indexOf('art') >= 0) return 'This path uses sound, rhythm, shape, color, pattern, and creative choices.';
    return 'This learning path is ready.';
  }
  function getNpc(){
    try{ if(typeof window.roomHasNpc === 'function' && window.roomHasNpc() && typeof window.npc === 'function') return window.npc(); }catch(e){}
    try{ if(typeof roomHasNpc === 'function' && roomHasNpc() && typeof npc === 'function') return npc(); }catch(e){}
    return null;
  }
  function sceneParagraphs(r, mode, note){
    var bits = [];
    if(note) bits.push(note);
    if(r && r.text) bits.push(r.text);
    if(r && r.subject) bits.push(subjectLine(r.subject));
    var n = getNpc();
    if(mode === 'talk'){
      if(n) bits.push((n.name || 'The guide') + ' says: “' + (n.text || n.desc || 'Choose the clearest path and keep learning one step at a time.') + '”');
      else bits.push('No guide is standing here right now. The room itself gives the clues: look around, choose a path, or open a lesson.');
    }else if(mode === 'look'){
      bits.push('You slow down and study the scene. Useful clues are in the signs, shelves, maps, tools, doors, paths, sounds, and little details around the room.');
      if(n && n.desc) bits.push(n.desc);
    }else if(n && n.desc){
      bits.push(n.desc);
    }
    if(!bits.length) bits.push('The room is ready for the next choice.');
    return bits.slice(0,5);
  }
  function targetText(target, dir){
    var r = getRoom(target);
    var title = stripEmoji(r.title || target || 'the next place');
    var joined = (title + ' ' + (r.zone||'') + ' ' + (r.subject||'')).toLowerCase();
    if(target === 'home' || dir === 'home') return 'Return to Home Hearth and check rooms, storage, pets, and family rewards.';
    if(joined.indexOf('shop') >= 0 || joined.indexOf('market') >= 0) return 'Walk into ' + title + ' and see what the shelves are offering.';
    if(joined.indexOf('fountain') >= 0 || joined.indexOf('square') >= 0) return 'Walk toward ' + title + ' and let the town open around the fountain.';
    if(joined.indexOf('gate') >= 0) return 'Approach ' + title + ' and see what the old road reveals.';
    if(joined.indexOf('room') >= 0 || joined.indexOf('hall') >= 0 || joined.indexOf('archive') >= 0) return 'Step inside ' + title + ' and read the clues waiting there.';
    if(r.subject) return 'Travel to ' + title + ', where ' + stripEmoji(r.subject) + ' learning waits.';
    if(r.zone) return 'Follow the path to ' + title + ' in ' + stripEmoji(r.zone) + '.';
    return 'Travel to ' + title + ' and continue the adventure.';
  }
  function metaFor(id){
    var r = getRoom(id), parts=[];
    if(r.zone) parts.push(stripEmoji(r.zone));
    if(r.subject) parts.push(stripEmoji(r.subject));
    return parts.join(' · ');
  }
  function choiceCards(r){
    var exits = (r && r.exits) || {};
    var keys = Object.keys(exits);
    if(!keys.length){
      return '<div class="lr68Quiet">No travel path is marked from this room yet. Open Go Learn, Home, or look around while this area grows.</div>';
    }
    return keys.map(function(k, i){
      var target = exits[k];
      var tr = getRoom(target);
      return '<button type="button" class="lr68ChoiceCard" onclick="lr68Travel(\'' + esc(k) + '\')">' +
        '<span class="lr68ChoiceNumber">' + (i+1) + '</span>' +
        '<span class="lr68ChoiceCopy"><b>' + esc(targetText(target,k)) + '</b><small>' + esc(tr.title || target) + (metaFor(target) ? ' · ' + esc(metaFor(target)) : '') + '</small></span>' +
      '</button>';
    }).join('');
  }
  function isShopLoc(loc){
    loc = loc || getLoc();
    if(['seasonalShop','pictureShop','luckyKettle','shiftyTent'].indexOf(loc) >= 0) return true;
    var r = getRoom(loc);
    var text = ((r.title||'') + ' ' + (r.zone||'')).toLowerCase();
    return /shop|market|diner|tent/.test(text) && typeof window.shopItems === 'function';
  }
  function roomActions(r){
    var loc = getLoc();
    var html = '';
    if(r && r.subject){
      html += '<button type="button" class="lr68Action primary" onclick="lr68OpenLessonHere()">📘 Open a ' + esc(r.subject) + ' lesson</button>';
      html += '<button type="button" class="lr68Action" onclick="lr68RunAction(\'showMasteryStatus\',\'Mastery Status\')">🏆 Check mastery here</button>';
    }
    if(isShopLoc(loc)) html += '<button type="button" class="lr68Action primary" onclick="lr68OpenShop()">🏪 Browse the shop shelves</button>';
    if(loc === 'home' || ((r.zone||'').toLowerCase().indexOf('home') >= 0)){
      html += '<button type="button" class="lr68Action primary" onclick="lr68OpenHome()">🏡 Open Home rooms and storage</button>';
      html += '<button type="button" class="lr68Action" onclick="lr68RunAction(\'openCompanionDen\',\'Companion Den\')">🐾 Companion Den</button>';
      html += '<button type="button" class="lr68Action" onclick="lr68RunAction(\'openCollectionLog\',\'Collection Log\')">📚 Collection Log</button>';
    }
    if(loc === 'questBoardPlaza') html += '<button type="button" class="lr68Action" onclick="lr68RunAction(\'openQuestBoard\',\'Quest Board\')">📜 Read the quest board</button>';
    if(loc === 'historicalSociety') html += '<button type="button" class="lr68Action" onclick="lr68RunAction(\'openInvestigationBoard\',\'Investigation Board\')">🗺 Check the investigation board</button>';
    return html ? '<div class="lr68ActionStrip"><div class="lr68PanelTitle"><span>Useful here</span><small>These happen on the main screen.</small></div><div class="lr68ActionRow">' + html + '</div></div>' : '';
  }

  function renderScene(mode, note){
    try{
      var mount = ensureMount();
      hideOldSurfaces();
      var r = getRoom();
      var n = getNpc();
      var paras = sceneParagraphs(r, mode || 'room', note).map(function(p){ return '<p>' + esc(p) + '</p>'; }).join('');
      var npcLine = n ? '<span>Guide: <b>' + esc(n.name || 'Realm Guide') + '</b></span>' : '<span>Guide: none nearby</span>';
      mount.innerHTML =
        '<section class="lr68SceneHero">' +
          '<div class="lr68HeroTop"><span class="lr68Kicker">Learning adventure screen</span><span class="lr68Status">' + esc(levelLine()) + '</span></div>' +
          '<h1>' + esc(r.title || 'LearningRealms') + '</h1>' +
          '<div class="lr68Meta"><span>' + esc(r.zone || 'Realm') + '</span>' + (r.subject ? '<span>' + esc(r.subject) + '</span>' : '') + npcLine + '</div>' +
          '<div class="lr68SceneText">' + paras + '</div>' +
        '</section>' +
        roomActions(r) +
        '<section class="lr68ChoicePanel"><div class="lr68PanelTitle"><span>What happens next?</span><small>Pick a story choice. The main screen changes immediately.</small></div>' + choiceCards(r) + '</section>' +
        bottomBar();
      stats();
      return false;
    }catch(e){
      console.error('LR68 scene render failed', e);
      feedback('Dynamic shell error: ' + (e.message || e));
      return false;
    }
  }
  function bottomBar(extra){
    return '<div class="lr68BottomBar">' +
      (extra || '') +
      '<button type="button" onclick="lr68Render(\'look\')">🔎 Look around</button>' +
      '<button type="button" onclick="lr68Render(\'talk\')">💬 Talk / listen</button>' +
      '<button type="button" onclick="lr68OpenLearn()">📘 Go Learn</button>' +
      '<button type="button" onclick="lr68OpenHome()">🏡 Home</button>' +
    '</div>';
  }
  function resolveTarget(keyOrTarget){
    var rooms = getRooms();
    var r = getRoom();
    var exits = (r && r.exits) || {};
    if(exits[keyOrTarget]) return {target:exits[keyOrTarget], dir:keyOrTarget};
    if(rooms[keyOrTarget]) return {target:keyOrTarget, dir:''};
    return {target:null, dir:keyOrTarget};
  }
  function travel(keyOrTarget){
    try{
      var res = resolveTarget(keyOrTarget);
      if(!res.target){ renderScene('room','No path opens that way yet.'); return false; }
      var s = getState();
      if(!s){ renderScene('room','The save state is not ready yet. Try again.'); return false; }
      var note = targetText(res.target, res.dir);
      s.loc = res.target;
      s.room = Math.max(1, Number(s.room || 1)) + 1;
      try{ if(res.dir) call('lrPagedMapMove', res.dir); }catch(e){}
      try{ if(res.dir) call('lrMiniMapMoveDirection', res.dir); }catch(e){}
      try{ call('recordGameFunEvent','roomVisits',1,{room:res.target}); }catch(e){}
      try{ var lb=byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
      try{ var sb=byId('storageBox'); if(sb) sb.classList.add('hidden'); }catch(e){}
      save(); stats(); hideOldSurfaces();
      if(res.target === 'home') return openHome(note);
      renderScene('room', note);
      try{ if(typeof window.maybeTriggerRandomEvent === 'function') setTimeout(function(){ try{ window.maybeTriggerRandomEvent(res.target); }catch(e){} }, 30); }catch(e){}
      return false;
    }catch(e){
      console.error('LR68 travel failed', e);
      renderScene('room','Something blocked that choice: ' + (e.message || e));
      return false;
    }
  }

  function moveChildren(from, to){
    if(!from || !to) return 0;
    var count = 0;
    while(from.firstChild){ to.appendChild(from.firstChild); count++; }
    return count;
  }
  function renderEmbeddedAction(title, note){
    var mount = ensureMount();
    hideOldSurfaces();
    var r = getRoom();
    mount.innerHTML =
      '<section class="lr68SceneHero lr68ActionHero">' +
        '<div class="lr68HeroTop"><span class="lr68Kicker">Main-screen action</span><span class="lr68Status">' + esc(levelLine()) + '</span></div>' +
        '<h1>' + esc(title || (byId('actionTitle') && byId('actionTitle').textContent) || r.title || 'Action') + '</h1>' +
        '<div class="lr68Meta"><span>' + esc(r.zone || 'Realm') + '</span><span>No popup</span><span>Main screen bridge</span></div>' +
        (note ? '<div class="lr68SceneText"><p>' + esc(note) + '</p></div>' : '') +
      '</section>' +
      '<section class="lr68EmbeddedPanel"><div id="lr68ActionHost" class="lr68ActionHost"></div><div id="lr68StorageHost" class="lr68StorageHost"></div></section>' +
      bottomBar('<button type="button" onclick="lr68Render()">↩ Return to scene</button>');
    var ah = byId('lr68ActionHost');
    var sh = byId('lr68StorageHost');
    var actionText = byId('actionText');
    var storageItems = byId('storageItems');
    var moved = 0;
    moved += moveChildren(actionText, ah);
    if(storageItems && storageItems.childNodes && storageItems.childNodes.length){
      var cap = document.createElement('div');
      cap.className = 'lr68StorageCap';
      cap.innerHTML = '<h3>Related items</h3>';
      sh.appendChild(cap);
      moved += moveChildren(storageItems, sh);
    }
    if(!moved && ah){ ah.innerHTML = '<div class="lr68Quiet">Nothing appeared here yet. Return to the scene and choose another path.</div>'; }
    try{ var lb=byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
    try{ var sb=byId('storageBox'); if(sb) sb.classList.add('hidden'); }catch(e){}
    stats();
    return false;
  }
  function runAction(fnName, title){
    try{
      var out = call(fnName);
      setTimeout(function(){ renderEmbeddedAction(title || fnName); }, 20);
      return out;
    }catch(e){
      renderScene('room','That action was blocked: ' + (e.message || e));
      return false;
    }
  }
  function openHome(note){
    try{
      var s = getState();
      if(s){ s.loc='home'; s.room = Math.max(1, Number(s.room || 1)); }
      document.body.classList.remove('homeMode');
      if(window.__LR68_OLD_openHomeView__) window.__LR68_OLD_openHomeView__.call(window);
      else call('openHomeView');
      save();
      setTimeout(function(){ renderEmbeddedAction('Home Hearth', note || 'Home opens on the main adventure screen now.'); }, 20);
    }catch(e){
      console.error('LR68 home failed', e);
      renderScene('room','Home could not open: ' + (e.message || e));
    }
    return false;
  }
  function openShop(){
    try{
      if(typeof window.lr67RenderShopScene === 'function') return window.lr67RenderShopScene();
      if(window.__LR68_OLD_openShop__) window.__LR68_OLD_openShop__.call(window);
      else call('openShop');
      setTimeout(function(){ renderEmbeddedAction('Shop Shelves'); }, 20);
    }catch(e){ renderScene('room','Shop could not open: ' + (e.message || e)); }
    return false;
  }
  function openLearn(){
    var names = ['lr62eOpenLearn','lr19OpenLearningChooser','openRealCurriculumPicker','openLessonLauncher','openSubjectAtlasUI'];
    for(var i=0;i<names.length;i++){
      try{ if(typeof window[names[i]] === 'function'){ window[names[i]](); enlargePopup(); return false; } }catch(e){}
    }
    renderScene('room','The learning menu is still loading.');
    return false;
  }
  function openLessonHere(){
    try{
      if(typeof window.startLesson === 'function'){ window.startLesson(); enlargePopup(); return false; }
      if(typeof window.lrStartLesson === 'function'){ window.lrStartLesson(); enlargePopup(); return false; }
    }catch(e){}
    openLearn();
    return false;
  }
  function enlargePopup(){
    setTimeout(function(){
      try{ document.body.classList.add('lrBigLessonPopup','lr68BigLessonPopup'); }catch(e){}
    }, 20);
  }

  function dynamicFastTravel(target){
    try{
      var hub = null;
      try{ if(typeof window.atlasHubs === 'function') hub = (window.atlasHubs() || []).find(function(h){ return h.id === target; }); }catch(e){}
      if(hub && hub.systemAction){
        try{ if(typeof window.atlasSystemAction === 'function') window.atlasSystemAction(hub.systemAction); }catch(e){}
        setTimeout(function(){ renderEmbeddedAction(hub.title || 'Atlas Shortcut'); }, 20);
        return false;
      }
      if(!getRooms()[target]){ feedback('That destination is not loaded yet.'); renderScene('room','That atlas destination is not loaded yet.'); return false; }
      var s = getState();
      if(s){ s.loc = target; s.room = Math.max(1, Number(s.room || 1)) + 1; }
      try{ call('markAtlasVisit', target); }catch(e){}
      try{ call('recordGameFunEvent','roomVisits',1,{room:target}); }catch(e){}
      try{ call('addMemory','Atlas Fast Travel',(activeChildName() || 'Traveler') + ' fast traveled to ' + ((hub && hub.title) || target) + '.'); }catch(e){}
      save(); stats();
      if(target === 'home') return openHome('The atlas path brings you back to Home Hearth.');
      renderScene('room','The atlas path carries you to ' + ((hub && hub.title) || (getRoom(target).title || target)) + '.');
      return false;
    }catch(e){ renderScene('room','Atlas travel was blocked: ' + (e.message || e)); return false; }
  }

  function wrapActionFunction(name, title){
    try{
      var old = window[name];
      if(typeof old !== 'function') return;
      if(old.__lr68Wrapped) return;
      if(name === 'openHomeView') window.__LR68_OLD_openHomeView__ = old;
      if(name === 'openShop') window.__LR68_OLD_openShop__ = old;
      var wrapped = function(){
        var out;
        try{ out = old.apply(this, arguments); }catch(e){ console.error('LR68 wrapped action failed', name, e); feedback(String(e.message || e)); }
        setTimeout(function(){ renderEmbeddedAction(title || (byId('actionTitle') && byId('actionTitle').textContent) || name); }, 25);
        return out;
      };
      wrapped.__lr68Wrapped = true;
      window[name] = wrapped;
      try{ eval(name + ' = window["' + name + '"];'); }catch(e){}
    }catch(e){}
  }

  function wrapRenderRoom(){
    try{
      var old = window.renderRoom;
      if(typeof old !== 'function' || old.__lr68Wrapped) return;
      window.__LR68_OLD_renderRoom__ = old;
      var wrapped = function(){
        var out;
        try{ out = window.__LR68_OLD_renderRoom__.apply(this, arguments); }catch(e){ console.warn('old renderRoom failed inside LR68', e); }
        setTimeout(function(){
          if(!window.__LR68_SUPPRESS_RENDER__) renderScene('room');
        }, 20);
        return out;
      };
      wrapped.__lr68Wrapped = true;
      window.renderRoom = wrapped;
      try{ renderRoom = wrapped; }catch(e){}
    }catch(e){}
  }
  function installOverrides(){
    window.lr68Render = renderScene;
    window.lr68Travel = travel;
    window.lr68RunAction = runAction;
    window.lr68OpenHome = openHome;
    window.lr68OpenShop = openShop;
    window.lr68OpenLearn = openLearn;
    window.lr68OpenLessonHere = openLessonHere;

    window.lr67RenderDynamicScreen = renderScene;
    window.lr67ChoosePath = travel;
    window.lrAdventureChoiceGo = travel;
    window.lrNavRestoreGo = travel;
    window.go = travel;
    window.lr67GoHome = openHome;
    window.travelHome = openHome;
    window.enterHomePortal = openHome;
    window.lr67OpenLearn = openLearn;
    window.lr67StartRoomLesson = openLessonHere;
    window.lr67ShowActionInScene = function(fnName, title){ return runAction(fnName, title); };
    window.fastTravelAtlas = dynamicFastTravel;
    window.lrSafeBrowseShopPopup = openShop;
    try{ lr67RenderDynamicScreen = renderScene; }catch(e){}
    try{ lr67ChoosePath = travel; }catch(e){}
    try{ lrAdventureChoiceGo = travel; }catch(e){}
    try{ lrNavRestoreGo = travel; }catch(e){}
    try{ go = travel; }catch(e){}
    try{ lr67GoHome = openHome; }catch(e){}
    try{ travelHome = openHome; }catch(e){}
    try{ enterHomePortal = openHome; }catch(e){}
    try{ lr67OpenLearn = openLearn; }catch(e){}
    try{ lr67StartRoomLesson = openLessonHere; }catch(e){}
    try{ fastTravelAtlas = dynamicFastTravel; }catch(e){}
    try{ lrSafeBrowseShopPopup = openShop; }catch(e){}

    wrapRenderRoom();
    var names = [
      ['openHomeView','Home Hearth'],['lrSafeStorageChest','Storage Chest'],['chest','Storage Chest'],
      ['openCollectionLog','Collection Log'],['openCompanionDen','Companion Den'],['openWorldAtlas','World Atlas'],
      ['openQuestBoard','Quest Board'],['openQuestJournal','Quest Journal'],['lrSafeOpenQuestJournal','Quest Journal'],
      ['openLongQuestJournal','Long Quest Journal'],['lrSafeOpenLongQuestJournal','Long Quest Journal'],
      ['openStoryQuestJournal','Story Quests'],['openStoryCampaigns','Story Campaigns'],
      ['openCastlePrestige','Castle Prestige'],['openSeasonalCalendar','Season Calendar'],['openSeasonHall','Season Hall'],
      ['openSeasonQuests','Season Quests'],['openSeasonalVendor','Seasonal Vendor'],['openSeasonalSearch','Season Search'],
      ['openHomeDecor','Home Decor'],['openHomeRooms','Home Rooms'],['openLivingHome','Living Home'],['openVisibleHome','Home View'],['openVisualHome','Home View'],
      ['openHomeExpansion2','Expand Home'],['openHomePlacement','Home Placement'],['openWardrobe','Wardrobe'],['openInventoryPopup','Inventory'],['openBackpack','Backpack'],
      ['openAchievementsJournal','Achievements'],['openAchievementJournal','Achievements'],['openPetJournal','Pet Journal'],['lrSafeOpenPetJournal','Pet Journal'],
      ['openMuseumHall','Museum Hall'],['openMuseumRenderer','Museum Hall'],['openCraftingRenderer','Crafting'],['openCraftingStation','Crafting'],
      ['openJourneyWorld','Journey World'],['openWorldDirectory','World Directory'],['openLandmarkJournal','Landmarks'],['openStudentJournal','Student Journal'],
      ['openEventLog','Event Log'],['openReportCenter','Report Center'],['openMasteryPaths','Mastery Paths'],['openAdaptiveReview','Adaptive Review'],
      ['openBossGauntlets','Boss Gauntlets'],['showMasteryStatus','Mastery Status'],['startBossChallenge','Realm Boss'],['openSystemHealth','System Health'],
      ['openNpcRelations','Realm Friends'],['openInvestigationBoard','Investigation Board'],['openShopHub','Shop Lantern Hub']
    ];
    names.forEach(function(pair){ wrapActionFunction(pair[0], pair[1]); });

    // Shops get a custom bridge instead of the generic action capture.
    window.openShop = openShop;
    try{ openShop = openShop; }catch(e){}
  }

  function injectStyles(){
    if(byId('lr68DynamicShellStyle')) return;
    var st = document.createElement('style');
    st.id = 'lr68DynamicShellStyle';
    st.textContent = `
      body.lr68DynamicShell main{display:grid !important;grid-template-columns:minmax(0,1fr) 270px !important;gap:16px !important;align-items:start !important;}
      body.lr68DynamicShell .actionSidebar, body.lr68DynamicShell .rightSidebar{display:none !important;}
      body.lr68DynamicShell .main{display:block !important;width:100% !important;min-width:0 !important;max-width:none !important;}
      body.lr68DynamicShell .main > .card:first-child{display:block !important;width:100% !important;max-width:none !important;padding:0 !important;overflow:hidden !important;border-color:rgba(255,227,160,.36) !important;}
      body.lr68DynamicShell .main > .card:nth-child(2){display:block !important;position:absolute !important;left:-99999px !important;top:auto !important;width:1px !important;height:1px !important;overflow:hidden !important;opacity:0 !important;pointer-events:none !important;}
      body.lr68DynamicShell #roomTitle, body.lr68DynamicShell #roomText, body.lr68DynamicShell #mainCompassNav, body.lr68DynamicShell #mainGameplayActions{display:none !important;}
      body.lr68DynamicShell #lrDynamicAdventureScreen{display:block !important;visibility:visible !important;opacity:1 !important;width:100% !important;min-height:650px !important;position:relative !important;z-index:3 !important;color:#fff3cc;background:radial-gradient(circle at 15% 0%, rgba(255,211,112,.25), transparent 34%),radial-gradient(circle at 98% 4%, rgba(99,175,150,.18), transparent 38%),linear-gradient(180deg, rgba(12,31,27,.98), rgba(5,15,13,.99));}
      body.lr68DynamicShell .playerSidebar{min-width:250px !important;max-width:270px !important;}
      .lr68SceneHero{padding:24px 28px 20px;border-bottom:1px solid rgba(255,227,160,.22);}
      .lr68HeroTop{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:8px;}
      .lr68Kicker{font-weight:950;text-transform:uppercase;letter-spacing:.09em;color:#ffdf87;font-size:.76rem;}
      .lr68Status{font-size:.84rem;color:#d9e5c9;font-weight:800;text-align:right;}
      .lr68SceneHero h1{font-size:clamp(2rem,3.2vw,3.15rem);line-height:1.04;margin:4px 0 10px;color:#fff7d7;text-shadow:0 3px 12px rgba(0,0,0,.42);}
      .lr68Meta{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 15px;}
      .lr68Meta span{border:1px solid rgba(255,227,160,.28);background:rgba(255,244,200,.08);color:#ffe8a4;border-radius:999px;padding:5px 9px;font-weight:850;font-size:.82rem;}
      .lr68SceneText{max-width:980px;font-size:1.05rem;line-height:1.58;color:#fff2c8;}
      .lr68SceneText p{margin:.55rem 0;}
      .lr68ChoicePanel,.lr68ActionStrip,.lr68EmbeddedPanel{padding:18px 26px;border-top:1px solid rgba(255,227,160,.13);}
      .lr68PanelTitle{display:flex;justify-content:space-between;gap:10px;align-items:end;margin-bottom:12px;color:#fff4ce;}
      .lr68PanelTitle span{font-weight:950;font-size:1.08rem;}.lr68PanelTitle small{color:#d9e5c9;font-weight:750;}
      .lr68ChoiceCard{width:100% !important;text-align:left !important;display:flex !important;gap:13px !important;align-items:flex-start !important;border-radius:18px !important;border:1px solid rgba(255,227,160,.35) !important;background:rgba(255,250,226,.94) !important;color:#17352d !important;padding:14px 16px !important;margin:0 0 11px !important;box-shadow:0 10px 20px rgba(0,0,0,.22) !important;cursor:pointer !important;transition:transform .08s ease, box-shadow .08s ease !important;}
      .lr68ChoiceCard:hover{transform:translateY(-1px);box-shadow:0 13px 26px rgba(0,0,0,.28) !important;}
      .lr68ChoiceNumber{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;background:#254f41;color:#fff4d0;font-weight:950;}
      .lr68ChoiceCopy{display:flex;flex-direction:column;gap:4px;line-height:1.25;}.lr68ChoiceCopy b{font-size:1rem;}.lr68ChoiceCopy small{font-size:.83rem;color:#536860;font-weight:800;}
      .lr68ActionRow{display:flex;flex-wrap:wrap;gap:10px;}.lr68Action{border-radius:14px !important;background:rgba(255,246,214,.93) !important;color:#17352d !important;border:1px solid rgba(255,227,160,.42) !important;padding:10px 12px !important;font-weight:950 !important;}.lr68Action.primary{background:#ffdf87 !important;color:#14352d !important;}
      .lr68BottomBar{display:flex;flex-wrap:wrap;gap:10px;padding:17px 26px 24px;border-top:1px solid rgba(255,227,160,.18);background:rgba(0,0,0,.16);}.lr68BottomBar button{border-radius:14px !important;background:#294f43 !important;color:#fff4d0 !important;border:1px solid rgba(255,227,160,.34) !important;padding:10px 13px !important;font-weight:950 !important;}
      .lr68Quiet{background:rgba(255,244,200,.08);border:1px solid rgba(255,227,160,.24);border-radius:16px;padding:14px;color:#fff1bd;font-weight:800;}
      .lr68EmbeddedPanel{background:rgba(0,0,0,.12);}.lr68ActionHost,.lr68StorageHost{max-width:1060px;}.lr68ActionHost .lessonCard,.lr68StorageHost .lessonCard,.lr68ActionHost .journalPage,.lr68StorageHost .journalPage,.lr68ActionHost .journalBook,.lr68StorageHost .journalBook{color:#18352d;}.lr68ActionHost > *, .lr68StorageHost > *{margin-bottom:12px;}.lr68StorageCap h3{color:#fff4ce;margin:12px 0 8px;}
      body.lr68BigLessonPopup .lrPopupWindow, body.lrBigLessonPopup .lrPopupWindow{width:min(1120px,94vw) !important;max-height:92vh !important;}
      body.lr68BigLessonPopup .lrPopupBody, body.lrBigLessonPopup .lrPopupBody{max-height:78vh !important;font-size:1.06rem !important;line-height:1.62 !important;}
      body.lr68DynamicShell .lrPopupWindow{width:min(1120px,94vw);}
      @media(max-width:950px){body.lr68DynamicShell main{grid-template-columns:1fr !important;}body.lr68DynamicShell .playerSidebar{max-width:none !important;width:100% !important;}.lr68HeroTop,.lr68PanelTitle{align-items:flex-start;flex-direction:column;}.lr68SceneHero,.lr68ChoicePanel,.lr68ActionStrip,.lr68EmbeddedPanel,.lr68BottomBar{padding-left:16px;padding-right:16px;}}
    `;
    document.head.appendChild(st);
  }

  function watchdog(){
    try{
      document.body.classList.add('lr68DynamicShell','lrDynamicAdventureMode');
      installOverrides();
      hideOldSurfaces();
      var mount = byId('lrDynamicAdventureScreen');
      var bad = !mount || !mount.innerHTML || !mount.innerHTML.trim();
      if(mount && window.getComputedStyle){
        var cs = window.getComputedStyle(mount);
        if(cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') bad = true;
      }
      if(bad) renderScene('room');
    }catch(e){}
  }
  function boot(){
    injectStyles();
    installOverrides();
    ensureMount();
    renderScene('room');
    setTimeout(watchdog,80); setTimeout(watchdog,300); setTimeout(watchdog,900);
    if(!window.__LR68_WATCHDOG_TIMER__) window.__LR68_WATCHDOG_TIMER__ = setInterval(watchdog,900);
  }

  window.LR68 = {render:renderScene, travel:travel, action:runAction, home:openHome, shop:openShop, learn:openLearn, embed:renderEmbeddedAction};
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 20);
  window.addEventListener('load', function(){ setTimeout(boot, 120); setTimeout(watchdog, 700); });
})();
