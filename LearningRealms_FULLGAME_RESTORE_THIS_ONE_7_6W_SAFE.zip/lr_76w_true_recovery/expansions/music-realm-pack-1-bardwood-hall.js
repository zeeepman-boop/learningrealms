// Music Realm Pack 1: Bardwood Hall
// Adds a dedicated Music subject realm with rhythm, beat, tempo, melody, instruments, listening, and music vocabulary.
// Uses subject key "Music".
// Adds starter Music grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const musicRooms = {
    bardwoodRoad1:{
      title:"Humming Path",
      zone:"Bardwood Road",
      subject:"Music",
      npc:{name:"Bardwood Road Guide",desc:"A friendly guide who points toward the music hall.",text:"Follow the humming leaves to Bardwood Gate. Beat, rhythm, melody, and listening all begin here."},
      text:"A narrow path leaves town beneath trees whose leaves hum softly in the breeze. Small wooden signs show notes, drums, bells, flutes, clapping hands, and dancing feet.",
      exits:{south:"townSquare",east:"bardwoodRoad2"}
    },
    bardwoodRoad2:{
      title:"Echo Bend",
      zone:"Bardwood Road",
      subject:"Music",
      npc:{name:"Echo Bend Guide",desc:"A quiet listener who teaches that music begins with noticing sound.",text:"Listen first. Then name what changed: beat, rhythm, tempo, pitch, or volume."},
      text:"The road bends through a hollow where every footstep makes a gentle echo. A carved sign reads: Listen first. Play second.",
      exits:{west:"bardwoodRoad1",east:"bardwoodGate"}
    },
    bardwoodGate:{
      title:"Bardwood Gate",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"A tall wooden gate opens into Bardwood Hall, a warm music grove of stages, practice rooms, wind chimes, drums, bells, strings, and listening benches.",
      npc:{name:"Maestro Reed",desc:"A kind old music teacher with a baton carved from willow wood.",text:"Maestro Reed taps the air once. 'Music is sound organized with care. Beat, rhythm, melody, and feeling all work together.'"},
      exits:{west:"bardwoodRoad2",east:"rhythmCircle",south:"instrumentGallery"}
    },
    rhythmCircle:{
      title:"Rhythm Circle",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"A circle of flat stones is marked stomp, clap, rest, tap. A low drum sits in the center, pulsing like a friendly heartbeat.",
      npc:{name:"Drumma Dot",desc:"A cheerful drummer who teaches beat, rhythm, rests, and steady pulse.",text:"Drumma Dot pats the drum. 'Beat is the steady pulse. Rhythm is the pattern riding on it.'"},
      exits:{west:"bardwoodGate",east:"melodyBridge",south:"tempoTrail"}
    },
    instrumentGallery:{
      title:"Instrument Gallery",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"Instruments rest on polished shelves: drums, bells, flutes, fiddles, harps, horns, shakers, and tiny wooden xylophones. Each display explains how sound is made.",
      npc:{name:"Timbre Tavi",desc:"A bright-eyed guide who teaches instrument families and tone color.",text:"Tavi plucks a string and taps a drum. 'Different instruments have different voices. That special sound is called timbre.'"},
      exits:{north:"bardwoodGate",east:"tempoTrail",south:"listeningLoft"}
    },
    tempoTrail:{
      title:"Tempo Trail",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"A winding trail has signs marked slow, walking, quick, and very fast. Little lanterns blink at different speeds to show tempo.",
      npc:{name:"Pace Piper",desc:"A lively piper who teaches tempo, speed, and dynamics.",text:"Pace Piper grins. 'Tempo tells how fast the music moves. Dynamics tell how loud or soft it feels.'"},
      exits:{north:"rhythmCircle",west:"instrumentGallery",east:"melodyBridge",south:"choirNook"}
    },
    melodyBridge:{
      title:"Melody Bridge",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"A bridge of bright wood crosses a quiet stream. Each plank plays a different pitch. Walking across makes a simple melody rise and fall.",
      npc:{name:"Lyra Songstep",desc:"A gentle singer who teaches pitch, melody, high, low, and musical shape.",text:"Lyra hums three notes. 'A melody is the tune you can follow. It can climb, fall, leap, or move step by step.'"},
      exits:{west:"rhythmCircle",south:"choirNook"}
    },
    listeningLoft:{
      title:"Listening Loft",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"Soft cushions and wooden ear trumpets fill a quiet loft. A sign says: Name what you hear. Beat, tempo, mood, instruments, pattern.",
      npc:{name:"Quiet Arlo",desc:"A soft-spoken listener who teaches careful listening and musical description.",text:"Quiet Arlo raises a finger to listen. 'Good listening is active. Notice the sound, then name what you noticed.'"},
      exits:{north:"instrumentGallery",east:"choirNook"}
    },
    choirNook:{
      title:"Choir Nook",
      zone:"Bardwood Hall",
      subject:"Music",
      text:"A small stage curves beneath leafy branches. Painted birds perch along the railings. Signs show unison, echo, call-and-response, verse, chorus, and harmony.",
      npc:{name:"Harmony Finch",desc:"A little songbird teacher who explains voices, patterns, and musical form.",text:"Harmony Finch chirps. 'Songs have shapes too. Verses return, choruses repeat, and echoes answer.'"},
      exits:{north:"tempoTrail",west:"listeningLoft",east:"melodyBridge"}
    }
  };

  Object.assign(ROOMS, musicRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.north) ROOMS.townSquare.exits.north = "bardwoodRoad1";
    else if(!ROOMS.townSquare.exits.northwest) ROOMS.townSquare.exits.northwest = "bardwoodRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Music = window.LR_REWARDS.Music || [];
  window.LR_REWARDS.Music.push(
    {name:"Tiny Wooden Drum",slot:"shelf"},
    {name:"Rhythm Stone Tile",slot:"wall"},
    {name:"Melody Bridge Charm",slot:"shelf"},
    {name:"Tempo Lantern",slot:"shelf"},
    {name:"Listening Loft Cushion",slot:"shelf"},
    {name:"Instrument Gallery Plaque",slot:"wall"},
    {name:"Bardwood Songbook",slot:"desk"},
    {name:"Harmony Finch Feather",slot:"shelf"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Music = {display:"Music / Rhythm / Listening",targetCorrect:140,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Music = {display:"Music / Form / Instruments / Listening",targetCorrect:200,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Music = {display:"Music / Analysis / Structure / Evidence",targetCorrect:220,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Music")) cfg.assignmentSubjects[child].push("Music");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Music:2}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Music:3}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Music:3}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Music = {
    zone:"Bardwood Hall",
    units:[
      {id:"G1-MUS-BEAT",title:"Beat and Rhythm",goal:"Recognize steady beat, simple rhythms, rests, and patterns.",targetLessons:100,skills:["beat","rhythm","clap","rest","pattern"]},
      {id:"G1-MUS-SOUND",title:"Sound and Instruments",goal:"Identify simple instrument sounds, loud/soft, fast/slow, and high/low.",targetLessons:100,skills:["instrument","loud","soft","fast","slow","high","low"]},
      {id:"G1-MUS-LISTEN",title:"Listening and Mood",goal:"Describe what music sounds like and how it feels.",targetLessons:80,skills:["listen","mood","happy","calm","strong","quiet"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Music = {
    zone:"Bardwood Hall",
    units:[
      {id:"G6-MUS-RHYTHM",title:"Rhythm, Meter, and Tempo",goal:"Understand beat, rhythm, meter, tempo, rests, and repeated patterns.",targetLessons:140,skills:["beat","rhythm","meter","tempo","rest","syncopation"]},
      {id:"G6-MUS-INSTRUMENTS",title:"Instruments and Timbre",goal:"Recognize instrument families, timbre, dynamics, and texture.",targetLessons:130,skills:["timbre","strings","winds","percussion","brass","dynamics","texture"]},
      {id:"G6-MUS-FORM",title:"Form and Listening Response",goal:"Identify musical form, repeated sections, contrast, and listening evidence.",targetLessons:130,skills:["form","verse","chorus","theme","variation","contrast","listening evidence"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Music = {
    zone:"Bardwood Hall",
    units:[
      {id:"G7-MUS-ANALYSIS",title:"Music Analysis",goal:"Analyze music using evidence about rhythm, melody, harmony, timbre, dynamics, and form.",targetLessons:150,skills:["analysis","evidence","rhythm","melody","harmony","dynamics","form"]},
      {id:"G7-MUS-STRUCTURE",title:"Structure and Style",goal:"Understand musical structure, style, theme, variation, call-response, and texture.",targetLessons:140,skills:["structure","style","theme","variation","call-response","texture"]},
      {id:"G7-MUS-CONTEXT",title:"Music and Context",goal:"Describe how purpose, setting, and audience affect musical choices.",targetLessons:120,skills:["purpose","setting","audience","mood","composer choices","interpretation"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-MUS-RHYTHM-1",subject:"Music",unit:"G1-MUS-BEAT",title:"Make a Clap Pattern",prompt:"Make a short clap/tap pattern and write or tell what repeats.",helper:"Example: clap, tap, clap, tap. What comes next?",estimatedMinutes:15},
    {id:"LUNA-MUS-LISTEN-1",subject:"Music",unit:"G1-MUS-LISTEN",title:"Listening Picture",prompt:"Listen to a safe instrumental song or imagine one. Draw or describe how it feels.",helper:"Use words like calm, bright, slow, fast, loud, soft, happy, or sleepy.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-MUS-INSTRUMENT-1",subject:"Music",unit:"G6-MUS-INSTRUMENTS",title:"Instrument Family Notes",prompt:"Choose one instrument family and explain how its instruments make sound.",helper:"Try strings, woodwinds, brass, percussion, or keyboard.",estimatedMinutes:25},
    {id:"AVA-MUS-FORM-1",subject:"Music",unit:"G6-MUS-FORM",title:"Song Form Map",prompt:"Map the form of a song or pretend song using sections such as A, B, verse, chorus, or repeat.",helper:"Explain which section repeats and which section contrasts.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-MUS-ANALYSIS-1",subject:"Music",unit:"G7-MUS-ANALYSIS",title:"Music Analysis With Evidence",prompt:"Analyze a short instrumental piece or imagined piece using at least three music terms and evidence.",helper:"Mention rhythm, melody, dynamics, tempo, timbre, texture, or form.",estimatedMinutes:30},
    {id:"MICHAEL-MUS-PURPOSE-1",subject:"Music",unit:"G7-MUS-CONTEXT",title:"Music Purpose Response",prompt:"Explain how a composer might change tempo, dynamics, or instruments for a battle scene, calm scene, or travel scene.",helper:"Use claim, musical evidence, and reasoning.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addMusicLadder(child){
    LR_addLessons(child,"Music",[
      {gradeBand:"K",unit:"K-MUS-SOUND",skill:"loud and soft",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Sounds can be loud or soft.",
       workedExample:"A drum can be loud. A whisper can be soft.",
       guidedPractice:"Choose the word for a quiet sound.",
       q:"A whisper is usually...",c:["soft","loud","spicy"],a:"soft",
       explain:"A whisper is a soft sound."},

      {gradeBand:"G1",unit:"G1-MUS-BEAT",skill:"steady beat",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Beat is the steady pulse in music.",
       workedExample:"You can tap a steady beat while a song plays.",
       guidedPractice:"Think of a heartbeat or steady footstep.",
       q:"Beat is the steady...",c:["pulse","picture","map"],a:"pulse",
       explain:"The beat is the steady pulse of music."},

      {gradeBand:"G2",unit:"G2-MUS-RHYTHM",skill:"rhythm",difficulty:"grade 2",mode:"foundation",
       miniLesson:"Rhythm is the pattern of long and short sounds and silences.",
       workedExample:"Clap, clap, rest, clap is a rhythm pattern.",
       guidedPractice:"Look for a sound pattern.",
       q:"Rhythm is a pattern of sounds and...",c:["silences","colors only","coins"],a:"silences",
       explain:"Rhythm includes sounds and rests."},

      {gradeBand:"G3",unit:"G3-MUS-TEMPO",skill:"tempo",difficulty:"grade 3",mode:"foundation",
       miniLesson:"Tempo is the speed of music.",
       workedExample:"A lullaby may have a slow tempo. A march may have a faster tempo.",
       guidedPractice:"Choose the word for speed.",
       q:"Tempo tells how fast or slow music is.",c:["true","false","only in art"],a:"true",
       explain:"Tempo is the speed of the music."},

      {gradeBand:"G4",unit:"G4-MUS-DYNAMICS",skill:"dynamics",difficulty:"grade 4",mode:"foundation",
       miniLesson:"Dynamics tell how loud or soft music is.",
       workedExample:"Piano means soft. Forte means loud.",
       guidedPractice:"Choose the term about loud and soft.",
       q:"Dynamics describe...",c:["loud and soft","map distance","fraction size"],a:"loud and soft",
       explain:"Dynamics are about volume in music."},

      {gradeBand:"G5",unit:"G5-MUS-INSTRUMENTS",skill:"instrument families",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Instruments can be grouped into families.",
       workedExample:"Drums are percussion. Flutes are woodwinds. Violins are strings.",
       guidedPractice:"Match the instrument to the family.",
       q:"A drum belongs to which family?",c:["percussion","strings","woodwinds"],a:"percussion",
       explain:"Drums are percussion instruments."},

      {gradeBand:"G6",unit:"G6-MUS-FORM",skill:"musical form",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Musical form is how sections of music are organized.",
       workedExample:"ABA form has a first section, a different middle section, then the first section returns.",
       guidedPractice:"Look for repeated and contrasting sections.",
       q:"In ABA form, which section returns at the end?",c:["A","B","C"],a:"A",
       explain:"ABA means the A section returns after B."},

      {gradeBand:"G7",unit:"G7-MUS-TIMBRE",skill:"timbre",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Timbre is the special tone color or sound quality of an instrument or voice.",
       workedExample:"A flute and violin may play the same note, but they sound different because of timbre.",
       guidedPractice:"Think about what makes one sound different from another.",
       q:"Timbre means...",c:["tone color","speed","map scale"],a:"tone color",
       explain:"Timbre describes the special sound quality."},

      {gradeBand:"G8",unit:"G8-MUS-ANALYSIS",skill:"listening evidence",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Music analysis should use listening evidence.",
       workedExample:"You might say the music feels tense because the tempo is fast, the dynamics are loud, and the drum rhythm is sharp.",
       guidedPractice:"Name what you hear and explain its effect.",
       q:"A strong music analysis should use...",c:["listening evidence","random guesses","only the title"],a:"listening evidence",
       explain:"Listening evidence supports claims about music."}
    ]);
  }

  LR_addMusicLadder("Luna");
  LR_addMusicLadder("Ava");
  LR_addMusicLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Music = [
    {title:"Rhythm Circle Trial",intro:"Drumma Dot taps a steady drumbeat.",q:"Beat is the steady...",c:["pulse","color","map"],a:"pulse",reward:"Rhythm Stone Badge"},
    {title:"Soft Sound Trial",intro:"Quiet Arlo whispers from the listening loft.",q:"A whisper is usually...",c:["soft","loud","heavy"],a:"soft",reward:"Listening Feather"}
  ];

  window.LR_BOSS_CONTENT.Ava.Music = [
    {title:"Instrument Gallery Trial",intro:"Timbre Tavi points to a drum.",q:"A drum belongs to which instrument family?",c:["percussion","strings","woodwinds"],a:"percussion",reward:"Instrument Gallery Token"},
    {title:"Bardwood Form Trial",intro:"Harmony Finch sings A, B, then A again.",q:"In ABA form, which section returns?",c:["A","B","C"],a:"A",reward:"ABA Song Tile"}
  ];

  window.LR_BOSS_CONTENT.Michael.Music = [
    {title:"Timbre Trial",intro:"Tavi plays the same note on two instruments.",q:"Timbre means...",c:["tone color","tempo speed","map direction"],a:"tone color",reward:"Timbre Lens"},
    {title:"Listening Evidence Trial",intro:"Quiet Arlo asks for proof from what was heard.",q:"Music analysis should use...",c:["listening evidence","random guesses","only title words"],a:"listening evidence",reward:"Listener's Seal"}
  ];
})();
