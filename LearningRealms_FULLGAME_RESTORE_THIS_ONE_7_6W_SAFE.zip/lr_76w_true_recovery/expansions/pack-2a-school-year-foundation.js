// Curriculum Pack 2A: School-Year Foundation Block
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Reading",[
 {teach:"A short a sound can be heard in map.",practice:"map, bag, jam",q:"Which word has the short a sound?",c:["map","cake","tree"],a:"map"},
 {teach:"A short e sound can be heard in hen.",practice:"hen, bed, red",q:"Which word has the short e sound?",c:["hen","bike","moon"],a:"hen"},
 {teach:"A short i sound can be heard in sit.",practice:"sit, pig, lip",q:"Which word has the short i sound?",c:["sit","home","cake"],a:"sit"},
 {teach:"A short o sound can be heard in hop.",practice:"hop, dog, log",q:"Which word has the short o sound?",c:["hop","feet","rain"],a:"hop"},
 {teach:"A short u sound can be heard in cup.",practice:"cup, bug, sun",q:"Which word has the short u sound?",c:["cup","boat","sheep"],a:"cup"},
 {teach:"A character is who the story is about.",practice:"The rabbit found a shell. Rabbit is the character.",q:"Who is the character?",c:["rabbit","shell","path"],a:"rabbit"},
 {teach:"The setting is where a story happens.",practice:"The frog sat in a pond. Pond is the setting.",q:"What is the setting?",c:["pond","frog","sat"],a:"pond"},
 {teach:"A detail tells more about the story.",practice:"The owl had silver feathers.",q:"Which is a detail?",c:["silver feathers","owl","story"],a:"silver feathers"}
]);

LR_addLessons("Luna","English",[
 {teach:"A sentence tells a complete idea.",practice:"The rabbit hops.",q:"Which is a sentence?",c:["The rabbit hops.","rabbit","hops fast"],a:"The rabbit hops."},
 {teach:"A question asks something and ends with a question mark.",practice:"Where is the owl?",q:"Which mark ends a question?",c:["?","!","."],a:"?"},
 {teach:"An exclamation shows strong feeling.",practice:"Wow, the gate glows!",q:"Which mark shows excitement?",c:["!","?","."],a:"!"},
 {teach:"A noun can name an animal.",practice:"rabbit, owl, fox",q:"Which word names an animal?",c:["fox","run","green"],a:"fox"},
 {teach:"A verb can show action.",practice:"jump, run, swim",q:"Which word is an action?",c:["swim","stone","yellow"],a:"swim"},
 {teach:"A name begins with a capital letter.",practice:"Luna begins with capital L.",q:"Which is written correctly?",c:["Luna","luna","luNa"],a:"Luna"}
]);

LR_addLessons("Luna","Math",[
 {teach:"Adding means putting together.",practice:"4 apples plus 3 apples equals 7 apples.",q:"4 + 3 = ?",c:["7","6","8"],a:"7"},
 {teach:"Subtracting means taking away.",practice:"9 berries minus 2 berries leaves 7 berries.",q:"9 - 2 = ?",c:["7","6","8"],a:"7"},
 {teach:"A ten is a group of 10 ones.",practice:"10 ones make 1 ten.",q:"How many ones make a ten?",c:["10","5","20"],a:"10"},
 {teach:"A quarter is 25 cents.",practice:"One quarter = 25.",q:"How much is a quarter?",c:["25","10","5"],a:"25"},
 {teach:"A rectangle has 4 sides.",practice:"A door can look like a rectangle.",q:"How many sides does a rectangle have?",c:["4","3","5"],a:"4"},
 {teach:"A clock's long hand shows minutes.",practice:"The long hand points to minutes.",q:"Which hand shows minutes?",c:["long hand","short hand","no hand"],a:"long hand"}
]);

LR_addLessons("Ava","Math",[
 {teach:"A proportional relationship keeps the same ratio.",practice:"2/3 equals 4/6.",q:"Which ratio matches 2/3?",c:["4/6","3/4","5/6"],a:"4/6"},
 {teach:"A unit rate compares to one unit.",practice:"90 miles in 3 hours = 30 miles per hour.",q:"90 miles in 3 hours is what unit rate?",c:["30 miles per hour","60 miles per hour","93 miles per hour"],a:"30 miles per hour"},
 {teach:"To solve x - 8 = 14, add 8 to both sides.",practice:"14 + 8 = 22.",q:"x - 8 = 14. x = ?",c:["22","6","14"],a:"22"},
 {teach:"To solve 4x = 28, divide by 4.",practice:"28 ÷ 4 = 7.",q:"4x = 28. x = ?",c:["7","24","32"],a:"7"},
 {teach:"The area of a triangle is one half base times height.",practice:"Base 6 and height 4 gives 12.",q:"Triangle area with base 6 and height 4?",c:["12","24","10"],a:"12"},
 {teach:"The median is the middle value when data is ordered.",practice:"2, 5, 9 has median 5.",q:"Median of 2, 5, 9?",c:["5","2","9"],a:"5"},
 {teach:"A negative plus a negative stays negative.",practice:"-3 + -4 = -7.",q:"-3 + -4 = ?",c:["-7","1","7"],a:"-7"}
]);

LR_addLessons("Ava","English",[
 {teach:"Theme is a message or lesson developed by a story.",practice:"A character keeps trying until success.",q:"What is theme?",c:["message or lesson","font style","chapter number"],a:"message or lesson"},
 {teach:"Text evidence supports an answer with proof from the passage.",practice:"Quote the line that proves it.",q:"What supports a reading answer?",c:["text evidence","a random guess","cover color"],a:"text evidence"},
 {teach:"An inference combines clues and reasoning.",practice:"A character slams the door and frowns.",q:"Inference uses clues and...",c:["reasoning","spelling only","division"],a:"reasoning"},
 {teach:"A central idea is the main point of a nonfiction passage.",practice:"The passage explains how frogs grow.",q:"Central idea means...",c:["main point","tiny detail","page number"],a:"main point"},
 {teach:"Context clues help reveal word meaning.",practice:"The scorching sun made the road hot.",q:"Scorching most likely means...",c:["very hot","very cold","very quiet"],a:"very hot"},
 {teach:"A counterclaim is an opposing claim.",practice:"Some people disagree and give a different claim.",q:"A counterclaim is...",c:["opposing claim","same claim","title"],a:"opposing claim"}
]);

LR_addLessons("Ava","Science",[
 {teach:"A food web shows many connected food chains.",practice:"Grass feeds rabbits, rabbits feed foxes.",q:"A food web shows...",c:["connected feeding relationships","punctuation marks","map scales"],a:"connected feeding relationships"},
 {teach:"Photosynthesis uses sunlight to help plants make food.",practice:"Plants use light, water, and carbon dioxide.",q:"Photosynthesis uses...",c:["sunlight","sand only","metal"],a:"sunlight"},
 {teach:"Gravity is an attractive force between objects with mass.",practice:"Earth pulls objects downward.",q:"Gravity is a kind of...",c:["force","paragraph","citizen"],a:"force"},
 {teach:"A controlled experiment changes one variable at a time.",practice:"Only the water amount changes.",q:"A fair test changes how many main variables?",c:["one","five","none"],a:"one"},
 {teach:"Erosion moves weathered rock or soil.",practice:"Water carries soil downhill.",q:"Erosion moves...",c:["soil or rock","capital letters","claims"],a:"soil or rock"}
]);

LR_addLessons("Ava","History",[
 {teach:"A primary source is created by someone from the time being studied.",practice:"A diary written during the event is primary.",q:"Which is a primary source?",c:["diary from the event","modern textbook summary","new cartoon"],a:"diary from the event"},
 {teach:"Civic participation means taking part in community and government life.",practice:"Voting and serving are examples.",q:"Which is civic participation?",c:["voting","evaporation","multiplying"],a:"voting"}
]);

LR_addLessons("Michael","Math",[
 {teach:"To solve 7x + 6 = 41, subtract 6 first.",practice:"7x = 35, so x = 5.",q:"7x + 6 = 41. x = ?",c:["5","35","47"],a:"5"},
 {teach:"A linear function has a constant rate of change.",practice:"y increases by 3 each step.",q:"A linear function has constant...",c:["rate of change","volume","theme"],a:"rate of change"},
 {teach:"Slope-intercept form is y = mx + b.",practice:"m is slope and b is y-intercept.",q:"In y = mx + b, m is...",c:["slope","intercept","area"],a:"slope"},
 {teach:"A system solution is where two graphs meet.",practice:"Two lines cross at one point.",q:"The crossing point is the...",c:["solution","radius","summary"],a:"solution"},
 {teach:"Scientific notation uses powers of ten.",practice:"5,000 = 5 × 10^3.",q:"Scientific notation uses powers of...",c:["10","2","5"],a:"10"},
 {teach:"A transformation can translate, rotate, reflect, or dilate a figure.",practice:"A reflection flips a figure.",q:"Which transformation flips?",c:["reflection","translation","dilation"],a:"reflection"},
 {teach:"Volume of a rectangular prism is length times width times height.",practice:"2 × 3 × 4 = 24.",q:"Volume with 2, 3, and 4?",c:["24","9","12"],a:"24"}
]);

LR_addLessons("Michael","English",[
 {teach:"An argument needs a claim, evidence, and reasoning.",practice:"Claim plus proof plus explanation.",q:"An argument needs claim, evidence, and...",c:["reasoning","weather","radius"],a:"reasoning"},
 {teach:"A strong paragraph has a topic sentence and supporting details.",practice:"Main idea first, details after.",q:"What supports a topic sentence?",c:["details","random guesses","unrelated facts"],a:"details"},
 {teach:"Paraphrasing means restating ideas in your own words.",practice:"Keep the meaning, change the wording.",q:"Paraphrasing uses...",c:["your own words","exact copying","no meaning"],a:"your own words"},
 {teach:"A source must be evaluated for reliability.",practice:"Check author, date, and evidence.",q:"Which helps judge reliability?",c:["author and evidence","font color only","page size"],a:"author and evidence"},
 {teach:"A counterargument addresses the other side.",practice:"The writer explains why another view is weaker.",q:"A counterargument responds to...",c:["another view","weather","multiplication"],a:"another view"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Atoms are made of smaller particles, including protons, neutrons, and electrons.",practice:"Protons and neutrons are in the nucleus.",q:"Which particle has negative charge?",c:["electron","proton","neutron"],a:"electron"},
 {teach:"Chemical reactions rearrange atoms into new substances.",practice:"Rust is a new substance.",q:"Chemical reactions make...",c:["new substances","only bigger pieces","no change"],a:"new substances"},
 {teach:"Kinetic energy is energy of motion.",practice:"A moving cart has kinetic energy.",q:"Energy of motion is...",c:["kinetic energy","potential energy","density"],a:"kinetic energy"},
 {teach:"Potential energy is stored energy.",practice:"A raised object stores energy.",q:"Stored energy is...",c:["potential energy","kinetic energy","erosion"],a:"potential energy"},
 {teach:"Density is mass divided by volume.",practice:"D = m ÷ V.",q:"Density equals mass divided by...",c:["volume","time","color"],a:"volume"}
]);

LR_addLessons("Michael","History",[
 {teach:"Federalism divides power between national and state governments.",practice:"Some powers belong to states.",q:"Federalism divides...",c:["power","weather","sentences"],a:"power"},
 {teach:"Checks and balances help prevent one branch from becoming too powerful.",practice:"Branches can limit one another.",q:"Checks and balances limit...",c:["government power","erosion","fractions"],a:"government power"},
 {teach:"Economic scarcity means resources are limited compared with wants.",practice:"Limited resources require choices.",q:"Scarcity means resources are...",c:["limited","unlimited","irrelevant"],a:"limited"}
]);
