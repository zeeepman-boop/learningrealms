// Curriculum Pack 2C: Science / History / Writing Expansion
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Science",[
 {teach:"Living things need air, water, food, and space.",practice:"A rabbit needs water and food.",q:"Which is something living things need?",c:["water","paint","buttons"],a:"water"},
 {teach:"A plant has roots, stem, leaves, and sometimes flowers.",practice:"Roots hold the plant in the soil.",q:"Which part holds a plant in the soil?",c:["roots","fur","wings"],a:"roots"},
 {teach:"Leaves help plants use sunlight.",practice:"Green leaves catch light.",q:"Which plant part uses sunlight?",c:["leaves","shoes","rocks"],a:"leaves"},
 {teach:"Animals have body parts that help them live.",practice:"Birds use wings to fly.",q:"What helps a bird fly?",c:["wings","roots","fins"],a:"wings"},
 {teach:"Fish live in water and use fins to swim.",practice:"A fish moves with fins.",q:"What helps a fish swim?",c:["fins","feathers","hooves"],a:"fins"},
 {teach:"Weather tells what the sky and air are like today.",practice:"Rainy, windy, sunny, snowy.",q:"Which is weather?",c:["rainy","yesterday","library"],a:"rainy"},
 {teach:"A shadow forms when light is blocked.",practice:"A tree can block sunlight.",q:"A shadow needs blocked...",c:["light","sound","taste"],a:"light"},
 {teach:"Magnets can pull some metals.",practice:"A magnet can stick to some metal objects.",q:"A magnet can pull some...",c:["metals","paper only","water"],a:"metals"}
]);

LR_addLessons("Luna","History",[
 {teach:"A map helps show where places are.",practice:"A map can show roads and rivers.",q:"What helps show places?",c:["map","spoon","song"],a:"map"},
 {teach:"A globe is a model of Earth.",practice:"A globe is round like Earth.",q:"A globe models...",c:["Earth","a chair","a pencil"],a:"Earth"},
 {teach:"Past means something already happened.",practice:"Last week is in the past.",q:"Last week is in the...",c:["past","future","clock"],a:"past"},
 {teach:"Present means happening now.",practice:"Today is the present.",q:"Today is the...",c:["present","past only","map"],a:"present"},
 {teach:"Future means something that has not happened yet.",practice:"Tomorrow is in the future.",q:"Tomorrow is in the...",c:["future","past","basket"],a:"future"},
 {teach:"Community helpers do jobs that help people.",practice:"A firefighter helps in emergencies.",q:"Which is a community helper?",c:["firefighter","rock","cloud"],a:"firefighter"}
]);

LR_addLessons("Luna","English",[
 {teach:"A complete sentence tells a whole thought.",practice:"The owl flew over the gate.",q:"Which is a complete sentence?",c:["The owl flew.","owl","flew over"],a:"The owl flew."},
 {teach:"A describing word tells more about a noun.",practice:"The tall tree.",q:"Which word describes the tree?",c:["tall","tree","the"],a:"tall"},
 {teach:"Retelling means telling what happened again in order.",practice:"First, next, last.",q:"Retelling should be in...",c:["order","random pieces","only colors"],a:"order"},
 {teach:"A title names a story or book.",practice:"The Lost Owl could be a title.",q:"What names a story?",c:["title","period","coin"],a:"title"},
 {teach:"A sentence about yourself can start with I.",practice:"I saw a frog.",q:"Which starts correctly?",c:["I saw a frog.","i saw a frog.","saw a frog"],a:"I saw a frog."},
 {teach:"Writers can add details to make a sentence stronger.",practice:"The frog jumped into the cool pond.",q:"Which sentence has more detail?",c:["The frog jumped into the cool pond.","The frog jumped.","Frog."],a:"The frog jumped into the cool pond."}
]);

LR_addLessons("Ava","Science",[
 {teach:"Cells are the basic units of living things.",practice:"Plants and animals are made of cells.",q:"Living things are made of...",c:["cells","bricks only","planets"],a:"cells"},
 {teach:"The nucleus helps control many cell activities.",practice:"It is often called the control center.",q:"Which cell part is often called the control center?",c:["nucleus","cell wall","soil"],a:"nucleus"},
 {teach:"Plant cells have cell walls that help support them.",practice:"Cell walls are outside the cell membrane.",q:"Which structure supports plant cells?",c:["cell wall","fur","bone"],a:"cell wall"},
 {teach:"Adaptations help organisms survive in their environments.",practice:"Thick fur can help in cold places.",q:"Adaptations help organisms...",c:["survive","write essays","divide fractions"],a:"survive"},
 {teach:"A producer makes its own food, usually using sunlight.",practice:"Most plants are producers.",q:"Which is usually a producer?",c:["plant","fox","owl"],a:"plant"},
 {teach:"A consumer eats other organisms for energy.",practice:"A rabbit eating grass is a consumer.",q:"A consumer gets energy by...",c:["eating","punctuation","voting"],a:"eating"},
 {teach:"A decomposer breaks down dead organisms and waste.",practice:"Fungi can be decomposers.",q:"A decomposer breaks down...",c:["dead material","equations","maps"],a:"dead material"},
 {teach:"The water cycle moves water through evaporation, condensation, precipitation, and collection.",practice:"Rain is precipitation.",q:"Rain is an example of...",c:["precipitation","photosynthesis","friction"],a:"precipitation"}
]);

LR_addLessons("Ava","History",[
 {teach:"A primary source comes from the time or person being studied.",practice:"A soldier's diary from a war is primary.",q:"Which is a primary source?",c:["a diary from the event","a modern movie","a new opinion poster"],a:"a diary from the event"},
 {teach:"A secondary source explains or analyzes primary sources.",practice:"A later textbook chapter is secondary.",q:"A textbook written later is usually...",c:["secondary source","artifact from the event","eyewitness diary"],a:"secondary source"},
 {teach:"Citizenship includes rights and responsibilities.",practice:"Voting and obeying laws are civic actions.",q:"Citizenship includes rights and...",c:["responsibilities","evaporation","slope"],a:"responsibilities"},
 {teach:"Limited government means government power is restricted by law.",practice:"The Constitution limits power.",q:"Limited government restricts...",c:["power","rainfall","roots"],a:"power"},
 {teach:"Economics studies choices about goods, services, and resources.",practice:"People choose how to use limited resources.",q:"Economics studies choices about...",c:["resources","cell walls","paragraphs"],a:"resources"},
 {teach:"Supply is how much of something is available.",practice:"More apples in a market means higher supply.",q:"Supply means how much is...",c:["available","hidden","fictional"],a:"available"}
]);

LR_addLessons("Ava","English",[
 {teach:"A paragraph usually has one main idea.",practice:"The sentences should stay on the same topic.",q:"A paragraph should focus on...",c:["one main idea","many unrelated topics","only punctuation"],a:"one main idea"},
 {teach:"A topic sentence tells what the paragraph is mostly about.",practice:"The first sentence often introduces the point.",q:"A topic sentence tells the...",c:["main idea","page number","author's age"],a:"main idea"},
 {teach:"A summary includes the important points without every detail.",practice:"Shorter than the original.",q:"A summary should include...",c:["important points","every tiny detail","only the title"],a:"important points"},
 {teach:"Evidence should be relevant to the claim.",practice:"Proof must match the answer.",q:"Relevant evidence must...",c:["match the claim","change the subject","be random"],a:"match the claim"},
 {teach:"An explanation tells how evidence supports an answer.",practice:"After quoting, explain why it matters.",q:"After giving evidence, you should...",c:["explain it","ignore it","erase it"],a:"explain it"},
 {teach:"Transitions help connect ideas.",practice:"for example, however, therefore",q:"Which is a transition?",c:["therefore","frog","triangle"],a:"therefore"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Atoms contain protons, neutrons, and electrons.",practice:"Protons and neutrons are in the nucleus.",q:"Which particle has a negative charge?",c:["electron","proton","neutron"],a:"electron"},
 {teach:"Elements are substances made of one kind of atom.",practice:"Oxygen is an element.",q:"An element contains one kind of...",c:["atom","paragraph","government"],a:"atom"},
 {teach:"Compounds form when elements chemically combine.",practice:"Water is H2O.",q:"Water is a...",c:["compound","primary source","function"],a:"compound"},
 {teach:"A chemical change creates a new substance.",practice:"Burning wood makes ash and gases.",q:"Burning wood is a...",c:["chemical change","grammar rule","map scale"],a:"chemical change"},
 {teach:"A physical change does not make a new substance.",practice:"Ice melting is still water.",q:"Ice melting is a...",c:["physical change","new element","civic duty"],a:"physical change"},
 {teach:"Waves transfer energy.",practice:"Sound and light can travel as waves.",q:"Waves transfer...",c:["energy","laws","claims"],a:"energy"},
 {teach:"Amplitude is related to wave height.",practice:"A taller wave has greater amplitude.",q:"Amplitude relates to wave...",c:["height","citizenship","chronology"],a:"height"},
 {teach:"Frequency describes how often waves pass a point.",practice:"More waves per second means higher frequency.",q:"Frequency means how often waves...",c:["pass a point","become laws","form paragraphs"],a:"pass a point"}
]);

LR_addLessons("Michael","History",[
 {teach:"The Constitution established the framework of the United States government.",practice:"It describes branches and powers.",q:"The Constitution established the government...",c:["framework","weather cycle","cell wall"],a:"framework"},
 {teach:"Separation of powers divides government into branches.",practice:"Legislative, executive, judicial.",q:"Separation of powers divides government into...",c:["branches","food webs","paragraphs"],a:"branches"},
 {teach:"Checks and balances let branches limit one another.",practice:"This helps prevent too much power in one branch.",q:"Checks and balances limit...",c:["power","erosion","density"],a:"power"},
 {teach:"Federalism divides power between national and state governments.",practice:"Both levels have authority.",q:"Federalism divides power between national and...",c:["state governments","plant cells","story settings"],a:"state governments"},
 {teach:"The Bill of Rights protects individual freedoms.",practice:"Speech and religion are examples.",q:"The Bill of Rights protects...",c:["freedoms","fractions","weather"],a:"freedoms"},
 {teach:"Economic scarcity means resources are limited compared with wants.",practice:"People must make choices.",q:"Scarcity means resources are...",c:["limited","unlimited","irrelevant"],a:"limited"}
]);

LR_addLessons("Michael","English",[
 {teach:"A research question guides investigation.",practice:"It tells what you are trying to learn.",q:"A research question guides...",c:["investigation","multiplication only","weather"],a:"investigation"},
 {teach:"Reliable sources provide accurate and trustworthy information.",practice:"Check author, evidence, and date.",q:"To judge a source, check author, evidence, and...",c:["date","font color only","page size only"],a:"date"},
 {teach:"A citation gives credit to a source.",practice:"It helps readers find the source.",q:"A citation gives...",c:["credit","weather","volume"],a:"credit"},
 {teach:"A counterclaim presents an opposing position.",practice:"Some people may disagree with the claim.",q:"A counterclaim is an opposing...",c:["position","chemical","slope"],a:"position"},
 {teach:"Rebuttal answers the counterclaim.",practice:"It explains why the original claim still stands.",q:"A rebuttal answers the...",c:["counterclaim","title","map"],a:"counterclaim"},
 {teach:"Precise language makes writing clearer.",practice:"Use exact words instead of vague ones.",q:"Precise language is...",c:["exact","random","unclear"],a:"exact"}
]);
