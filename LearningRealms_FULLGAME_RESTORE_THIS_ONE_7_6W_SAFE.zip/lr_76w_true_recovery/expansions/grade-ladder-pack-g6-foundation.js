// Grade Ladder Pack G6: Grade 6 Foundation
// Tagged with gradeBand:"G6" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG6Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G6",unit:"G6-READ-EVIDENCE",skill:"text evidence",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Text evidence is proof from a passage that supports an answer.",
     workedExample:"If you say a character is worried, evidence might be that the character paced, whispered, and checked the door.",
     guidedPractice:"Choose the detail that directly supports the answer.",
     q:"Which is the best text evidence that a character is nervous?",
     c:["The character's hands trembled.","The sky was blue.","The road was long."],a:"The character's hands trembled.",
     explain:"Trembling hands directly support the idea that the character is nervous."},

    {gradeBand:"G6",unit:"G6-READ-INFERENCE",skill:"inference",difficulty:"grade 6",mode:"foundation",
     miniLesson:"An inference combines clues from the text with careful reasoning.",
     workedExample:"If a traveler hides a map and keeps glancing behind him, you can infer he may be afraid someone is following him.",
     guidedPractice:"Use clues. Do not guess without support.",
     q:"A traveler hides a map and keeps looking behind him. What can you infer?",
     c:["He may be worried someone is following him.","He is baking bread.","He is painting a wall."],a:"He may be worried someone is following him.",
     explain:"Hiding the map and looking behind him are clues that suggest worry or fear."},

    {gradeBand:"G6",unit:"G6-READ-THEME",skill:"theme development",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A theme develops through characters' choices, conflicts, and changes.",
     workedExample:"If a character starts selfish but learns to share after seeing others suffer, a theme about generosity may develop.",
     guidedPractice:"Look at what changes from beginning to end.",
     q:"A character learns to share after seeing others struggle. Which theme fits?",
     c:["Generosity matters.","Mountains are tall.","Fractions can be added."],a:"Generosity matters.",
     explain:"The character's change supports a theme about generosity."},

    {gradeBand:"G6",unit:"G6-READ-STRUCTURE",skill:"text structure",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Text structure is how a passage organizes information.",
     workedExample:"A cause-and-effect structure explains why something happened and what resulted from it.",
     guidedPractice:"Look for signal words such as because, therefore, as a result, problem, or solution.",
     q:"A passage explains a drought and then describes crop failure. Which structure is likely being used?",
     c:["cause and effect","alphabetical order","dialogue only"],a:"cause and effect",
     explain:"The drought is the cause and crop failure is an effect."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G6",unit:"G6-MATH-RATIO",skill:"ratios",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A ratio compares two quantities.",
     workedExample:"If there are 3 red stones and 5 blue stones, the ratio of red to blue is 3:5.",
     guidedPractice:"Keep the order in the ratio the same as the words.",
     q:"There are 4 red stones and 6 blue stones. What is the ratio of red to blue?",
     c:["4:6","6:4","10:4"],a:"4:6",
     explain:"Red is named first, so 4 comes first. Blue is named second, so 6 comes second."},

    {gradeBand:"G6",unit:"G6-MATH-RATIO",skill:"unit rates",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A unit rate compares a quantity to one unit.",
     workedExample:"180 miles in 3 hours is 60 miles per hour because 180 divided by 3 is 60.",
     guidedPractice:"Divide the total by the number of units.",
     q:"180 miles in 3 hours is...",
     c:["60 miles per hour","183 miles per hour","30 miles per hour"],a:"60 miles per hour",
     explain:"180 divided by 3 equals 60, so the unit rate is 60 miles per hour."},

    {gradeBand:"G6",unit:"G6-MATH-NUMBERS",skill:"integers",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Integers include positive numbers, negative numbers, and zero.",
     workedExample:"A temperature of -5 is below zero. A gain of 5 is positive.",
     guidedPractice:"Think about direction from zero.",
     q:"Which number is an integer below zero?",
     c:["-4","4","0"],a:"-4",
     explain:"-4 is less than zero, so it is a negative integer."},

    {gradeBand:"G6",unit:"G6-MATH-EXPRESSIONS",skill:"expressions",difficulty:"grade 6",mode:"foundation",
     miniLesson:"An expression can include numbers, variables, and operations.",
     workedExample:"3x + 5 is an expression. It does not have an equals sign.",
     guidedPractice:"Look for a mathematical phrase without an equals sign.",
     q:"Which is an expression?",
     c:["3x + 5","3x + 5 = 20","x = 4"],a:"3x + 5",
     explain:"3x + 5 has no equals sign, so it is an expression."},

    {gradeBand:"G6",unit:"G6-MATH-STATISTICS",skill:"statistical questions",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A statistical question expects answers that vary.",
     workedExample:"How many minutes did each person read today? is statistical because answers can differ.",
     guidedPractice:"Ask whether different people could give different numeric answers.",
     q:"Which is a statistical question?",
     c:["How many books did each learner read this month?","What is 5 + 5?","How many sides does a triangle have?"],a:"How many books did each learner read this month?",
     explain:"The number of books can vary from person to person, so it is statistical."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G6",unit:"G6-ELA-WRITING",skill:"claims",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A claim is a clear position or answer that can be supported with evidence.",
     workedExample:"The character is responsible is a claim. It can be supported with examples from the text.",
     guidedPractice:"Choose the statement that takes a position.",
     q:"Which is a claim?",
     c:["The character is responsible.","Chapter 2 is short.","The book has pages."],a:"The character is responsible.",
     explain:"This statement takes a position that can be supported with evidence."},

    {gradeBand:"G6",unit:"G6-ELA-WRITING",skill:"evidence and reasoning",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Evidence gives proof. Reasoning explains how the proof supports the claim.",
     workedExample:"Evidence: The character returned the lost coin. Reasoning: Returning it shows honesty because he could have kept it.",
     guidedPractice:"Do not stop at evidence. Explain why it matters.",
     q:"What explains how evidence supports a claim?",
     c:["reasoning","capitalization","setting"],a:"reasoning",
     explain:"Reasoning connects evidence back to the claim."},

    {gradeBand:"G6",unit:"G6-ELA-GRAMMAR",skill:"pronoun clarity",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Pronouns should clearly refer to a specific noun.",
     workedExample:"Mia gave Ava her book can be unclear. We may not know whose book it is.",
     guidedPractice:"Ask whether the reader knows exactly who the pronoun means.",
     q:"Why can unclear pronouns be a problem?",
     c:["The reader may not know who is meant.","They always make spelling easier.","They remove all nouns."],a:"The reader may not know who is meant.",
     explain:"A pronoun needs a clear noun to refer to."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G6",unit:"G6-SCI-CELLS",skill:"cells",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Cells are the basic units of living things.",
     workedExample:"Plants and animals are made of cells. Different cells can have different jobs.",
     guidedPractice:"Choose the smallest basic living unit.",
     q:"The basic unit of living things is the...",
     c:["cell","mountain","paragraph"],a:"cell",
     explain:"Cells are the basic units that make up living things."},

    {gradeBand:"G6",unit:"G6-SCI-ECOSYSTEMS",skill:"energy flow",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Energy flows through ecosystems from producers to consumers and decomposers.",
     workedExample:"Grass uses sunlight. A rabbit eats grass. A fox eats the rabbit.",
     guidedPractice:"Find the producer first.",
     q:"In grass → rabbit → fox, which organism is the producer?",
     c:["grass","rabbit","fox"],a:"grass",
     explain:"Grass makes its own food using sunlight, so it is the producer."},

    {gradeBand:"G6",unit:"G6-SCI-EARTH",skill:"water cycle",difficulty:"grade 6",mode:"foundation",
     miniLesson:"The water cycle moves water through evaporation, condensation, precipitation, and collection.",
     workedExample:"Water evaporates, forms clouds through condensation, and falls as precipitation.",
     guidedPractice:"Name the step where water falls from clouds.",
     q:"Rain is an example of...",
     c:["precipitation","evaporation","photosynthesis"],a:"precipitation",
     explain:"Precipitation is water falling from the atmosphere."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G6",unit:"G6-SS-SOURCES",skill:"source reliability",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Source reliability depends on author, date, purpose, and evidence.",
     workedExample:"A signed source with evidence and a clear date is stronger than an anonymous source with no proof.",
     guidedPractice:"Ask who made it, when, why, and what evidence it gives.",
     q:"Which helps judge source reliability?",
     c:["author, date, purpose, and evidence","font color only","page length only"],a:"author, date, purpose, and evidence",
     explain:"These details help determine whether a source is trustworthy."},

    {gradeBand:"G6",unit:"G6-SS-GEOGRAPHY",skill:"human-environment interaction",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Human-environment interaction studies how people affect the environment and how the environment affects people.",
     workedExample:"People may build irrigation canals, and dry land may affect where people farm.",
     guidedPractice:"Look for people changing or adapting to their surroundings.",
     q:"Building irrigation canals is an example of humans...",
     c:["changing the environment","finding a theme","adding fractions"],a:"changing the environment",
     explain:"Irrigation canals are human-made changes to the environment."},

    {gradeBand:"G6",unit:"G6-SS-ECON",skill:"trade",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Trade is the exchange of goods and services.",
     workedExample:"A town with grain may trade with a town that has metal tools.",
     guidedPractice:"Ask what is being exchanged.",
     q:"Trade means exchanging...",
     c:["goods and services","weather and climate","nouns and verbs"],a:"goods and services",
     explain:"Trade is the exchange of goods and services."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G6",unit:"G6-ART-VALUE",skill:"value scale",difficulty:"grade 6",mode:"foundation",
     miniLesson:"A value scale shows steps from light to dark.",
     workedExample:"An artist can use a value scale to shade a sphere so it looks rounded.",
     guidedPractice:"Think about light, middle, and dark tones.",
     q:"A value scale shows steps from...",
     c:["light to dark","north to south","past to future"],a:"light to dark",
     explain:"Value describes lightness and darkness."},

    {gradeBand:"G6",unit:"G6-ART-COMPOSITION",skill:"composition",difficulty:"grade 6",mode:"foundation",
     miniLesson:"Composition is how parts of an artwork are arranged.",
     workedExample:"An artist might place the largest dragon near the center to make it important.",
     guidedPractice:"Ask how the artist arranged the parts.",
     q:"Composition is the arrangement of...",
     c:["parts of an artwork","only math facts","weather patterns"],a:"parts of an artwork",
     explain:"Composition describes how visual parts are placed together."}
  ]);
}

LR_addG6Foundation("Luna");
LR_addG6Foundation("Ava");
LR_addG6Foundation("Michael");
