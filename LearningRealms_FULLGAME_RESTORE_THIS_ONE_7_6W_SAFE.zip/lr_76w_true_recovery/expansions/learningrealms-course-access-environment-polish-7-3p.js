/* LearningRealms Course Access Map + Environment Polish 7.3P
   Purpose: keep the stable 7.3O RPG shell, reorganize subjects under clear umbrellas,
   remove visible lesson-framework wording from the game surface, and make the navigation
   feel like actual realm travel instead of a loose web-page course list.
   No save reset. No core lesson deletion. No loading curtain. No render loop.
*/
(function(){
  'use strict';
  if(window.__LR73P_COURSE_ACCESS_ENVIRONMENT__) return;
  window.__LR73P_COURSE_ACCESS_ENVIRONMENT__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function text(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function safe(fn){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); schedulePolish(); return true; }
    catch(e){ console.warn('LR73P route failed:', fn, e); return false; }
  }
  function first(routes){
    for(var i=0;i<routes.length;i++){
      var r = routes[i];
      if(Array.isArray(r)){ if(safe.apply(null,r)) return true; }
      else if(safe(r)) return true;
    }
    return false;
  }
  function stateObj(){ try{ return window.state || state || {}; }catch(e){ return {}; } }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    var s = byId('studentSelect');
    if(s && s.value) return s.value;
    try{ return localStorage.getItem('lrActiveChild') || 'Michael'; }catch(e){}
    return 'Michael';
  }
  function sceneName(){
    var h = q('#lrDynamicAdventureScreen h1');
    if(h && text(h)) return text(h);
    var rt = byId('roomTitle');
    return text(rt) || 'Home Hearth';
  }
  function statLine(){
    var s = stateObj();
    var room = text(byId('roomNumber')) || s.room || '1';
    var sparks = text(byId('sparks')) || s.sparks || '0';
    var streak = text(byId('streak')) || s.streak || '0';
    return activeName() + ' · Room ' + room + ' · ' + sparks + ' Sparks · Streak ' + streak;
  }

  function installStyles(){
    if(byId('lr73pStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr73pStyles';
    st.textContent = `
      body.lr73pUmbrellaMap .lr73pHub{min-height:650px;background:linear-gradient(180deg,#0c221e,#071513);border-radius:0 0 18px 18px;overflow:hidden;}
      body.lr73pUmbrellaMap .lr73pHero{padding:26px 30px 22px;background:radial-gradient(circle at 12% 0%,rgba(255,226,139,.22),transparent 30%),linear-gradient(135deg,#17392f,#09201d 58%,#4b3515);border-bottom:1px solid rgba(245,223,154,.25);color:#fff2c2;}
      body.lr73pUmbrellaMap .lr73pHero small{display:block;color:#ffe6a1;font-weight:1000;text-transform:uppercase;letter-spacing:.12em;font-size:.72rem;}
      body.lr73pUmbrellaMap .lr73pHero h1{margin:9px 0 8px;font-size:clamp(1.85rem,3.3vw,3.05rem);line-height:1.02;color:#fff8d7;text-shadow:0 2px 0 rgba(0,0,0,.28);}
      body.lr73pUmbrellaMap .lr73pHero p{max-width:980px;margin:.25rem 0 0;line-height:1.55;font-weight:800;color:#dcefe3;}
      body.lr73pUmbrellaMap .lr73pSections{display:grid;gap:16px;padding:18px;background:linear-gradient(180deg,rgba(255,246,211,.10),rgba(0,0,0,.05));}
      body.lr73pUmbrellaMap .lr73pSection{border:1px solid rgba(245,223,154,.20);border-radius:18px;background:linear-gradient(180deg,rgba(14,39,34,.96),rgba(7,18,17,.98));box-shadow:0 12px 24px rgba(0,0,0,.22);overflow:hidden;}
      body.lr73pUmbrellaMap .lr73pSectionHead{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:center;padding:13px 15px;background:linear-gradient(180deg,rgba(255,232,151,.12),rgba(0,0,0,.06));border-bottom:1px solid rgba(245,223,154,.13);}
      body.lr73pUmbrellaMap .lr73pSectionHead span{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:radial-gradient(circle at 35% 22%,#fff4bd,#d7a74b 50%,#5d3d12);box-shadow:inset 0 0 0 2px rgba(255,255,255,.16),0 6px 12px rgba(0,0,0,.24);font-size:1.45rem;}
      body.lr73pUmbrellaMap .lr73pSectionHead b{display:block;color:#fff0b9;font-size:1.08rem;}.lr73pSectionHead small{display:block;color:#b7d7ca;font-weight:800;line-height:1.25;}
      body.lr73pUmbrellaMap .lr73pGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:12px;padding:14px;}
      body.lr73pUmbrellaMap .lr73pCard{min-height:128px;display:grid;grid-template-columns:42px 1fr auto;gap:11px;align-items:start;text-align:left;border:1px solid rgba(245,223,154,.22);border-radius:17px;background:linear-gradient(180deg,#fff7d6,#d8c690);color:#1b1508;padding:13px;box-shadow:0 9px 16px rgba(0,0,0,.25);cursor:pointer;font-weight:900;}
      body.lr73pUmbrellaMap .lr73pCard:hover{transform:translateY(-1px);box-shadow:0 12px 22px rgba(0,0,0,.30);}
      body.lr73pUmbrellaMap .lr73pCard[disabled]{opacity:.55;filter:saturate(.65);cursor:not-allowed;}
      body.lr73pUmbrellaMap .lr73pCardIcon{width:40px;height:40px;border-radius:11px;background:linear-gradient(180deg,#183a32,#081714);display:grid;place-items:center;color:#fff0bd;font-size:1.25rem;}
      body.lr73pUmbrellaMap .lr73pCard b{display:block;font-size:1.02rem;line-height:1.15;color:#211607;}.lr73pCard small{display:block;margin:4px 0 6px;color:#614713;text-transform:uppercase;letter-spacing:.04em;font-size:.68rem;font-weight:1000;}.lr73pCard p{margin:0;color:#3c3322;line-height:1.32;font-weight:780;}.lr73pCardArrow{align-self:center;font-size:1.9rem;color:#704d11;}
      body.lr73pUmbrellaMap .lr73pFooter{display:flex;gap:9px;flex-wrap:wrap;padding:14px 18px;background:#071513;border-top:1px solid rgba(245,223,154,.14);}
      body.lr73pUmbrellaMap .lr73pFooter button,.lr73pMiniBtn{border:1px solid rgba(245,223,154,.34);border-radius:999px;background:linear-gradient(180deg,#fff2bd,#d1a050);color:#1c1106;font-weight:1000;padding:9px 12px;cursor:pointer;}
      body.lr73pUmbrellaMap .lr73pOldShelf{margin-top:10px;padding:10px;border:1px solid rgba(245,223,154,.15);border-radius:12px;background:rgba(0,0,0,.18);color:#d7eadf;font-weight:800;}
      body.lr73pUmbrellaMap .lr73oCommandGroupTitle{color:#ffe6a1!important;}
      body.lr73pUmbrellaMap #leftActionButtons{grid-template-columns:1fr 1fr!important;}
      body.lr73pUmbrellaMap .lr73pCommandBtn{display:grid!important;grid-template-columns:34px 1fr!important;gap:7px!important;align-items:center!important;text-align:left!important;min-height:44px!important;padding:7px!important;border:1px solid rgba(245,223,154,.34)!important;border-radius:10px!important;background:linear-gradient(180deg,#fff1bc,#c89a45)!important;color:#1c1106!important;font-weight:1000!important;cursor:pointer!important;box-shadow:0 5px 10px rgba(0,0,0,.22)!important;}
      body.lr73pUmbrellaMap .lr73pCommandBtn span{width:30px;height:30px;display:grid;place-items:center;border-radius:8px;background:linear-gradient(180deg,#183b34,#071715);color:#ffe7a8;font-size:1.1rem;}
      body.lr73pUmbrellaMap .lr73pCommandBtn.primary{grid-column:1 / -1;grid-template-columns:38px 1fr;background:linear-gradient(180deg,#fff6cf,#e0b65d)!important;}
      body.lr73pUmbrellaMap .lr73pIconRack{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-top:8px;}
      body.lr73pUmbrellaMap .lr73pIconRack button{height:38px!important;padding:0!important;display:grid!important;place-items:center!important;border-radius:8px!important;background:linear-gradient(180deg,#183530,#081816)!important;color:#fff0bd!important;border:1px solid rgba(245,223,154,.24)!important;font-size:1.14rem!important;position:relative!important;}
      body.lr73pUmbrellaMap .lr73pIconRack button:hover::after{content:attr(title);position:absolute;left:50%;bottom:42px;transform:translateX(-50%);white-space:nowrap;font-size:.68rem;background:#091614;color:#ffe7a8;border:1px solid rgba(245,223,154,.35);border-radius:6px;padding:3px 6px;z-index:20;}
      @media(max-width:1050px){body.lr73pUmbrellaMap .lr73pGrid{grid-template-columns:1fr;}body.lr73pUmbrellaMap .lr73pHero{padding:20px 18px;}}
    `;
    document.head.appendChild(st);
  }

  function mount(){
    try{ document.body.classList.add('lr73pUmbrellaMap','lr73mStable','lr73oCleanNav'); }catch(e){}
    var first = q('.main > .card:first-child') || q('section.main') || document.body;
    var m = byId('lrDynamicAdventureScreen');
    if(!m){
      m = document.createElement('div');
      m.id = 'lrDynamicAdventureScreen';
      m.className = 'lrDynamicAdventureScreen lr73pHub';
      if(first.firstChild) first.insertBefore(m, first.firstChild); else first.appendChild(m);
    }
    m.classList.add('lr73pHub');
    m.style.display='block'; m.style.visibility='visible'; m.style.opacity='1';
    return m;
  }

  function section(icon, title, sub, cards){
    return '<section class="lr73pSection"><div class="lr73pSectionHead"><span>'+esc(icon)+'</span><div><b>'+esc(title)+'</b><small>'+esc(sub)+'</small></div></div><div class="lr73pGrid">'+cards+'</div></section>';
  }
  function card(icon, title, meta, body, act, disabled){
    return '<button type="button" class="lr73pCard" data-lr73p-act="'+esc(act)+'" '+(disabled?'disabled':'')+'><span class="lr73pCardIcon">'+esc(icon)+'</span><span><b>'+esc(title)+'</b><small>'+esc(meta)+'</small><p>'+esc(body)+'</p></span><span class="lr73pCardArrow">›</span></button>';
  }
  function footer(){
    return '<div class="lr73pFooter">'+
      '<button type="button" data-lr73p-act="scene">↩ Return to scene</button>'+
      '<button type="button" data-lr73p-act="atlas">🗺️ Realm Atlas</button>'+
      '<button type="button" data-lr73p-act="home">🏡 Home Hearth</button>'+
      '<button type="button" data-lr73p-act="items">🎒 Collections</button>'+
    '</div>';
  }
  function render(kicker,title,desc,sectionsHtml){
    var m = mount();
    m.innerHTML = '<div class="lr73pHero"><small>'+esc(kicker)+'</small><h1>'+esc(title)+'</h1><p>'+esc(desc)+'</p><p><small>'+esc(statLine())+'</small></p></div><div class="lr73pSections">'+sectionsHtml+'</div>'+footer();
    schedulePolish();
    return false;
  }

  function openAtlas(){
    return render('Realm Atlas','Choose a wing of the realm','The atlas groups each subject where it belongs, so the game feels like roads, halls, shops, chapels, docks, and workshops instead of a pile of disconnected buttons.',
      section('📚','Core Halls','The daily skill roads: reading, writing, math, and careful reasoning.',
        card('📖','Reading Woods','Core Hall','Story clues, vocabulary, details, and proof from the page.','core')+
        card('✒️','Scribe Hall','Core Hall','Copywork, sentences, explanations, journals, and written responses.','core')+
        card('🔢','Math Iron Hills','Core Hall','Numbers, models, patterns, operations, and problem solving.','core')+
        card('🧩','Puzzle Spire','Core Hall','Logic, patterns, evidence, and careful thinking.','core'))+
      section('🔬','Science and Engineering Quarter','Nature, health, weather, machines, inventions, and aerospace live together here.',
        card('🔬','Science Marsh','Science Quarter','Observation, experiments, matter, evidence, and safe investigations.','science')+
        card('🌿','Nature and Health Trails','Science Quarter','Plants, animals, habits, body basics, safety, rest, food, and movement.','science')+
        card('🛠️','Engineering Hall','Engineering Quarter','Inventions, redesign, failures, machines, aerospace, and problem solving.','engineering')+
        card('☁️','Weather and Sky Watch','Science Quarter','Weather, astronomy, sky clues, space, and earth science roads.','science'))+
      section('🏛️','History and World Wing','History is the umbrella for the past, geography, civics, economics, shipwrecks, and special history roads.',
        card('🏛️','History Wing','History and World','Timelines, source clues, artifacts, people, places, causes, and consequences.','history')+
        card('👑','England: Kings and Queens','History Master Road','Monarchs, castles, law, Parliament, symbols, and constitutional change.','england')+
        card('🏺','Ancient Egypt Expedition','History Master Road','Nile, pharaohs, pyramids, the Sphinx, scribes, daily life, temples, tombs, and archaeology.','egypt')+
        card('🗺️','Mapmakers Hall','Geography Topic','Maps, routes, regions, landforms, directions, and how places connect.','geography')+
        card('⚖️','Councilhall Citadel','Civics Topic','Rules, responsibility, services, law, fairness, and civic evidence.','civics')+
        card('🏪','Merchant Row','Economics Topic','Needs, wants, trade, saving, budgets, and market choices.','economics'))+
      section('⛪','Bible Road','A separate respectful Catholic-friendly place, not mixed into ordinary history menus.',
        card('⛪','Bible History Pilgrim Road','Separate Realm','Scripture history, Jesus, Mary, apostles, angels, saints, sacraments, and feast days.','bible')+
        card('🏺','Bible Artifact Hall','Separate Realm','Tasteful study artifacts, chapel decor, badges, and memory symbols.','bibleArtifacts'))+
      section('🎨','Creative Quarter and Homestead','Art, music, making, life skills, home, companions, and practical work.',
        card('🎨','Creative Studio','Creative Quarter','Art, music, theater, crafts, pattern work, storytelling, and studio rewards.','creative')+
        card('🏡','Homestead Workshop','Life Skills','Practical routines, home work, planning, tools, cooking, animal care, and repairs.','homestead')+
        card('🐾','Companion Den','Home Hearth','Pets, companions, collection charm, and long-term goals.','pets')+
        card('🎒','Collection Log','Home Hearth','Treasures, badges, artifacts, rewards, and gathered keepsakes.','items'))
    );
  }

  function openCore(){
    return render('Core Halls','Reading, writing, math, and logic','These are the steady skill halls. Each road still opens the older lesson engine underneath, but the player sees it as a room, shelf, challenge, or guild path.',
      section('📖','Reading and Language','Story, vocabulary, copywork, grammar, and written proof.',
        card('📖','Reading Woods','Reading','Main idea, details, sequence, vocabulary, and evidence from the page.','reading')+
        card('📚','Story Forest','Reading Topic','Characters, setting, plot, retelling, and story order.','reading')+
        card('✒️','Writing Composition Tower','Writing Master Road','Sentences, paragraphs, stories, essays, revision, editing, and portfolios.','writingmaster')+
        card('🪶','Copywork Abbey','Writing Topic','Neat copying, careful language, attention, and memory.','writing'))+
      section('🔢','Numbers and Reasoning','Math, patterns, measurement, geometry, equations, and logic.',
        card('🔢','Math Iron Hills','Math','Operations, fractions, models, measurement, geometry, and equations.','math')+
        card('🏰','Fraction Castle','Math Topic','Parts, wholes, comparisons, models, and fraction thinking.','math')+
        card('🧩','Puzzle Spire','Logic','Patterns, evidence, sequences, claims, and careful reasoning.','logic')+
        card('⚙️','Equation Forge','Math Topic','Unknowns, steps, symbols, and algebra-ready habits.','math'))
    );
  }

  function openScience(){
    return render('Science and Engineering Quarter','Observation roads, machine halls, and sky towers','Science, nature, health, engineering, inventions, aerospace, weather, chemistry, and physics are grouped here so the map makes sense.',
      section('🔬','Science Roads','Nature, weather, matter, energy, earth, and safe investigation.',
        card('🔬','Science Marsh','Science','Observation, evidence, matter, earth science, and simple experiments.','science')+
        card('🌿','Nature and Health Trails','Nature / Health','Plants, habitats, safe body systems, hygiene, nutrition, sleep, movement, and field safety.','naturehealth')+
        card('☁️','Weather and Storm Lab','Science Topic','Clouds, pressure, wind, storms, forecasting, safety, and sky evidence.','weather')+
        card('✈️','Aerospace Mission Wing','Engineering Topic','Flight, rockets, satellites, mission control, testing, and design.','aerospacemaster'))+
      section('🛠️','Engineering Roads','Inventions, repair, machines, robotics, aerospace, and redesign.',
        card('💡','Inventions Hall','Engineering Master Road','Inventors, prototypes, famous failures, fixes, safety, and redesign.','inventions')+
        card('✈️','Aerospace Mission Wing','Engineering Topic','Flight, rockets, forces, testing, safety, and design.','aerospacemaster')+
        card('⚙️','Mechanical Workshop','Engineering Topic','Simple machines, gears, tools, building, and repair thinking.','aerospace')+
        card('🤖','Robotics Lab','Engineering Topic','Sensors, instructions, systems, computers, and machine logic.','aerospace'))
    );
  }

  function openHistory(){
    return render('History and World Wing','Past roads, maps, civic halls, and market streets','Great Depression and Wild West now live under History. Geography, civics, economics, maritime history, and ancient-world material are treated as topics inside the larger History and World umbrella.',
      section('🏛️','History Master Roads','Major history zones and long-form guided roads.',
        card('🏚️','Great Depression Road','History Master Road','Banks, work, Dust Bowl, families, recovery, saving, systems, and resilience.','depression')+
        card('🤠','Wild West Frontier Trail','History Master Road','Frontier towns, trails, homesteads, railroads, cattle drives, tools, maps, and myth vs. history.','wildwest')+
        card('⚓','Shipwreck Cove','Maritime History Topic','Shipwrecks, navigation, weather, evidence, rescue, engineering, pirates, legends, and sea-room mystery.','shipwreck')+
        card('🏺','Ancient Egypt Expedition','History Master Road','Nile, pharaohs, pyramids, Sphinx, scribes, daily life, beliefs, archaeology, and real evidence habits.','egypt'))+
      section('🗺️','World and Society Topics','These support history instead of floating as random separate islands.',
        card('🗺️','Mapmakers Hall','Geography Topic','Maps, landforms, regions, directions, routes, and place evidence.','geography')+
        card('⚖️','Councilhall Citadel','Civics Topic','Rules, law, responsibility, services, citizenship, and source judgment.','civics')+
        card('🏪','Merchant Row','Economics Topic','Needs, wants, value, trade, saving, budgets, and work.','economics')+
        card('📜','Timeline Hall','History Tool Room','Sequence, cause and effect, date clues, and historical order.','historyTrails'))
    );
  }

  function openBible(){
    return render('Bible Road','A separate reverent realm','Bible History stays off by itself, respectfully. It is treated like a pilgrim road with a chapel, scriptorium, artifact hall, saint-card shelves, feast-day rooms, and Catholic study symbols.',
      section('⛪','Pilgrim Road','Catholic-friendly Bible History area.',
        card('⛪','Walk Pilgrim Road','Guided Road','Move through Scripture history, New Testament foundations, Mary, apostles, saints, angels, sacraments, and feasts.','bibleTrail')+
        card('📖','Scripture Scriptorium','Road Map','Open the full Bible History room map.','bibleCourse')+
        card('🏺','Artifact Hall','Respectful Rewards','Study-room displays, chapel decor, badges, and memory symbols.','bibleArtifacts')+
        card('🏪','Pilgrim Shops','Tasteful Shopkeepers','Saint cards, Scripture satchels, bells, banners, candles, and Catholic study decor.','bibleShops'))+
      section('🕯️','Review and Keepsakes','Quiet support shelves for the Bible realm.',
        card('🏆','Treasure Shelf','Rewards','View earned Bible History keepsakes.','bibleRewards')+
        card('🔎','Review Shelf','Missed Challenges','Review missed items without making the area feel like a classroom menu.','bibleReview')+
        card('🗺️','Realm Atlas','Backtrack','Return to the larger atlas.','atlas'))
    );
  }

  function openCreative(){
    return render('Creative Quarter','Studios, music rooms, maker cottages, and gallery paths','Art, music, theater, crafts, and story making belong together here.',
      section('🎨','Maker Studios','Creative practice without random subject clutter.',
        card('🎨','Creative Studio','Creative Master Road','Drawing, painting, crafts, patterns, theater, music, story making, and gallery habits.','creativeCourse')+
        card('🖌️','Dragonbrush Vale','Art Topic','Line, shape, color, design, and visual storytelling.','arts')+
        card('🎵','Bardwood Hall','Music Topic','Rhythm, sound, listening, instruments, patterns, and music vocabulary.','music')+
        card('🎭','Theater Stage','Creative Topic','Performance, voice, safe theater habits, and story presentation.','arts'))
    );
  }

  function openHomestead(){
    return render('Homestead Workshop','Practical work, home rooms, companions, and useful everyday skills','Life skills and home systems belong here instead of floating through academic roads.',
      section('🏡','Home and Practical Work','Daily habits, making, repairing, storage, and home goals.',
        card('🏡','Home Hearth','Home','Home rooms, storage, decor, household progress, and display places.','home')+
        card('🧰','Homestead Workshop','Life Skills','Planning, routines, chores, tools, cooking, repair, and useful work.','life')+
        card('🍳','Cooking Guild','Life Skills Topic','Kitchen basics, safety habits, measuring, planning, and simple food work.','life')+
        card('🐾','Animal Care Corner','Life Skills Topic','Gentle animal care, responsibility, routines, and observation.','life'))+
      section('🎒','Collections and Companions','Game motivation stays in the adventure loop.',
        card('🐾','Companion Den','Companions','Pets, companion records, bonds, and discovered friends.','pets')+
        card('🎒','Collection Log','Collections','Badges, decor, artifacts, rewards, and treasures.','items')+
        card('📜','Quest Board','Quests','Errands, records, story paths, daily jobs, and long-term goals.','quests'))
    );
  }

  function oldShelf(subject){
    if(subject === 'reading') return safe('openRealCurriculumPicker','reading');
    if(subject === 'writing') return safe('openRealCurriculumPicker','writing');
    if(subject === 'math') return safe('openRealCurriculumPicker','math');
    if(subject === 'science') return safe('openRealCurriculumPicker','science');
    if(subject === 'geography') return safe('openRealCurriculumPicker','geography');
    if(subject === 'logic') return safe('openRealCurriculumPicker','logic');
    if(subject === 'aerospace') return safe('openRealCurriculumPicker','aerospace');
    if(subject === 'heritage') return safe('openRealCurriculumPicker','heritage');
    if(subject === 'life') return safe('openRealCurriculumPicker','life');
    if(subject === 'arts' || subject === 'music') return safe('openRealCurriculumPicker','arts');
    if(subject === 'economics') return safe('openRealCurriculumPicker','life') || safe('openRealCurriculumPicker','geography');
    if(subject === 'civics') return safe('openRealCurriculumPicker','geography');
    if(subject === 'historyTrails') return safe('openRealCurriculumPicker','heritage') || false;
    return safe('openRealCurriculumPicker');
  }

  function doAction(act){
    act = String(act || 'atlas').toLowerCase().replace(/[^a-z0-9]/g,'');
    if(act === 'atlas' || act === 'map' || act === 'realmmap' || act === 'learn' || act === 'golearn' || act === 'featuredtrails') return openAtlas();
    if(act === 'core') return openCore();
    if(act === 'science' || act === 'stem' || act === 'nature') return openScience();
    if(act === 'engineering' || act === 'inventions') return first([['openInventionsDeepCourse'],['openInventionsRewardCatalog']]) || openScience();
    if(act === 'history' || act === 'historywing') return openHistory();
    if(act === 'bible' || act === 'bibleroad' || act === 'biblehistory') return openBible();
    if(act === 'creative') return openCreative();
    if(act === 'homestead') return openHomestead();
    if(act === 'scene') return first([['lr68Render','room','You return to the scene.'],['lr68Render'],['renderRoom']]) || openAtlas();
    if(act === 'look') return first([['lr68Render','look','You study the room.'],['openSubjectAtlasRoom',sceneName()],['openWorldAtlas']]) || openAtlas();
    if(act === 'talk') return first([['lr68Render','talk','You look for a guide or keeper nearby.'],['openNpcRelations'],['openQuestJournal'],['openQuestPopup']]) || openAtlas();
    if(act === 'writing' || act === 'writingmaster' || act === 'composition') return first([['openWritingCompositionMasterCourse'],['openWritingCompositionMaster74W'],['openAuthorGuild'],['openWritingForge']]) || oldShelf('writing');
    if(act === 'scienceengineering') return first([['openScienceEngineeringAdventure74M'],['openScienceEngineeringQuarter74M']]) || openScience();
    if(act === 'nature' || act === 'naturehealth') return first([['openNatureHealthDeepAdventure'],['openNatureHealth74T'],['openNatureAndHealth'],['openNatureTrail']]) || oldShelf('science');
    if(act === 'weather' || act === 'weatherstorm') return first([['openWeatherStormLab74U'],['openWeatherStormLab'],['openStormwatchTower'],['openWeatherStation']]) || openScience();
    if(act === 'animals' || act === 'animal' || act === 'creatures' || act === 'creaturefieldguide') return first([['openCreatureFieldGuide'],['openAnimalKingdom74V'],['openAnimalKingdom'],['openCreatureFieldStation']]) || openScience();
    if(act === 'aerospace' || act === 'aerospacemaster') return first([['openAerospaceEngineering74S'],['openAerospaceEngineering'],['openAerospaceDeepCourse'],['openAerospaceMissionWing74S']]) || oldShelf('aerospace');
    if(act === 'england' || act === 'kingsqueens') return first([['openEnglandKingsQueens74Q'],['openEnglandKingsQueensRoad74Q']]) || openHistory();
    if(act === 'mapmakers') return first([['openMapmakersLoft74P'],['openHistoryWorldSupportAdventure74P']]) || oldShelf('geography');
    if(act === 'civichall') return first([['openCivicHall74P'],['openHistoryWorldSupportAdventure74P']]) || oldShelf('civics');
    if(act === 'marketsquare') return first([['openMarketSquare74P'],['openHistoryWorldSupportAdventure74P']]) || oldShelf('economics');
    if(act === 'coreadventure') return first([['openCoreHallsNoFillerAdventure74N'],['openCoreHallsAdventure74N']]) || openCore();
    if(act === 'creativeadventure') return first([['openCreativeQuarterAdventure74O'],['openCreativeHomesteadAdventure74O']]) || openCreative();
    if(act === 'homesteadadventure') return first([['openHomesteadWorkshopAdventure74O'],['openCreativeHomesteadAdventure74O']]) || openHomestead();
    if(act === 'worldsupport') return first([['openHistoryWorldSupportAdventure74P']]) || openHistory();
    if(act === 'reading' || act === 'math' || act === 'geography' || act === 'logic' || act === 'heritage' || act === 'life' || act === 'arts' || act === 'music' || act === 'civics' || act === 'economics' || act === 'historytrails') return oldShelf(act);
    if(act === 'depression' || act === 'greatdepression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || openHistory();
    if(act === 'wildwest') return first([['openWildWestTrail'],['openWildWestCourse']]) || openHistory();
    if(act === 'shipwreck') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['openShipwreckCoveMap']]) || openHistory();
    if(act === 'egypt' || act === 'ancientegypt') return first([['openAncientEgyptTrail'],['openAncientEgyptCourse']]) || openHistory();
    if(act === 'bibletrail') return first([['openBibleHistoryTrail'],['openBibleHistoryCourse']]) || openBible();
    if(act === 'biblecourse') return first([['openBibleHistoryCourse'],['openBibleHistoryTrail']]) || openBible();
    if(act === 'bibleartifacts' || act === 'artifacthall') return first([['openBibleHistoryArtifacts73B'],['openBibleHistoryArtifacts'],['openBibleHistoryRewards']]) || openBible();
    if(act === 'bibleshops') return first([['openBibleHistoryShops'],['openBibleHistoryCourse']]) || openBible();
    if(act === 'biblerewards') return first([['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || openBible();
    if(act === 'biblereview') return first([['openBibleHistoryReview'],['openBibleHistoryCourse']]) || openBible();
    if(act === 'creativecourse') return first([['openCreativeStudioCourse'],['openCreativeStudioByStudio']]) || oldShelf('arts');
    if(act === 'home') return first([['openHomeRooms'],['lr68OpenHome'],['openHomeView'],['openHomeRenderer'],['openVisualHome'],['renderHomeSlots']]) || openHomestead();
    if(act === 'items' || act === 'collection' || act === 'collectionlog') return first([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openAchievementJournal']]) || openHomestead();
    if(act === 'pets' || act === 'companions' || act === 'companionden') return first([['openCompanionDen'],['openPetJournal'],['openCompanionPopup']]) || openHomestead();
    if(act === 'quests' || act === 'questboard') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openQuestPopup'],['openStoryQuestJournal']]) || openHomestead();
    return openAtlas();
  }
  window.lr73pDo = doAction;

  function commandButton(icon,label,act,extra){
    return '<button type="button" class="lr73pCommandBtn '+(extra||'')+'" data-lr73p-act="'+esc(act)+'"><span>'+esc(icon)+'</span><b>'+esc(label)+'</b></button>';
  }
  function rewriteCommands(){
    var side = q('.actionSidebar');
    var host = byId('leftActionButtons');
    if(!side || !host) return;
    var h2 = side.querySelector('h2'); if(h2) h2.textContent = 'Commands';
    var html = ''+
      '<div class="lr73oCommandGroupTitle">Adventure</div>'+ 
      commandButton('🗺️','Realm Atlas','atlas','primary')+
      commandButton('🪟','Scene','scene')+commandButton('🔎','Look','look')+commandButton('💬','Talk','talk')+
      '<div class="lr73oCommandGroupTitle">Subject Wings</div>'+ 
      commandButton('📚','Core Halls','core')+commandButton('🔬','Science Quarter','science')+commandButton('🏛️','History Wing','history')+commandButton('🏺','Egypt Road','egypt')+commandButton('⛪','Bible Road','bible')+commandButton('🎨','Creative Quarter','creative')+commandButton('🏡','Homestead','homestead')+
      '<div class="lr73oCommandGroupTitle">Adventure Tools</div>'+ 
      commandButton('🎒','Collections','items')+commandButton('🐾','Companions','pets')+commandButton('📜','Quest Board','quests');
    if(host.innerHTML !== html) host.innerHTML = html;
  }
  function rewriteHeader(){
    var h = q('.compactHeader'); if(!h) return;
    var brand = q('.lr73mBrand small', h); if(brand) brand.textContent = sceneName() + ' · ' + statLine();
    var nav = q('.lr73mTopNav', h);
    if(nav){
      var html = '<button type="button" class="lr73oBtn" data-lr73p-act="scene">Scene</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73p-act="atlas">Realm Atlas</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73p-act="history">History Wing</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73p-act="egypt">Egypt Road</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73p-act="bible">Bible Road</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73p-act="home">Home</button>';
      if(nav.innerHTML !== html) nav.innerHTML = html;
    }
  }
  function rewritePlayerIcons(){
    var oldRack = q('.lr73mIconRack');
    if(!oldRack) return;
    oldRack.classList.add('lr73pIconRack');
    var html = icon('🗺️','Realm Atlas','atlas')+icon('📚','Core Halls','core')+icon('🔬','Science Quarter','science')+icon('🏛️','History Wing','history')+
      icon('🏺','Egypt Road','egypt')+icon('⛪','Bible Road','bible')+icon('🎨','Creative Quarter','creative')+icon('🏡','Homestead','homestead')+icon('🎒','Collections','items');
    if(oldRack.innerHTML !== html) oldRack.innerHTML = html;
  }
  function icon(symbol,title,act){
    return '<button type="button" title="'+esc(title)+'" aria-label="'+esc(title)+'" data-lr73p-act="'+esc(act)+'">'+esc(symbol)+'</button>';
  }
  function rewriteLedgerHints(){
    var ledger = q('.lr73mLedger'); if(!ledger) return;
    var html = '<b>Current road</b><small>'+esc(sceneName())+'<br>'+esc(statLine())+'</small>'+ 
      '<div class="lr73oLedgerHints"><span>🗺️ Atlas groups the realm.</span><span>🏛️ History holds history topics.</span></div>';
    if(ledger.innerHTML !== html) ledger.innerHTML = html;
  }

  var phraseRules = [
    [/Learning trails router/gi,'Roadsign Board'],
    [/Choose the next learning trail\.?/gi,'Choose the next road.'],
    [/Choose the next learning trail/gi,'Choose the next road'],
    [/Learning Trails/g,'Realm Roads'],
    [/learning trails/g,'realm roads'],
    [/learning trail/g,'realm road'],
    [/Learning adventure screen/gi,'Realm Scene'],
    [/learning adventure screen/gi,'realm scene'],
    [/Main Adventure Window/g,'Main Realm Window'],
    [/Pick a story choice\. The main screen changes immediately\./g,'Choose a path. The realm answers.'],
    [/These happen on the main screen\./g,'Nearby places'],
    [/Useful here/g,'Nearby'],
    [/Shopkeeper lessons and goal rewards/gi,'Market errands and keeper rewards'],
    [/giant course-button feeling/gi,'flat menu feeling'],
    [/Lessons and quizzes still open in the larger reading windows\./g,'Reading rooms and challenge chambers open when needed.'],
    [/Open full course map/g,'Open full road map'],
    [/Open course map/g,'Open road map'],
    [/Course map/g,'Road map'],
    [/course map/g,'road map'],
    [/Master Course/g,'Master Road'],
    [/master course/g,'master road'],
    [/Reward catalog/g,'Treasure shelf'],
    [/reward catalog/g,'treasure shelf'],
    [/Review missed/g,'Review shelf'],
    [/review missed/g,'review shelf'],
    [/Take quiz/g,'Enter challenge'],
    [/Take Quiz/g,'Enter Challenge'],
    [/ Quiz:/g,' Challenge:'],
    [/ Quiz/g,' Challenge'],
    [/ quiz/g,' challenge'],
    [/REAL Curriculum/g,'Realm Scroll Shelf'],
    [/real authored lessons/g,'ready realm scrolls'],
    [/Authored Lesson Bank/g,'Scroll Archive'],
    [/Lesson Bank/g,'Scroll Shelf'],
    [/Start Test/g,'Begin challenge'],
    [/Back to REAL Curriculum/g,'Back to Scroll Shelf'],
    [/\bTest\b/g,'Challenge'],
    [/\bSkill:/g,'Focus:'],
    [/No special room actions here yet\. Explore another path or use quick travel\./g,'The room is quiet. Try the command window or another road.'],
    [/Learning Log/g,'Journey Log'],
    [/Student Records/g,'Records Ledger']
  ];
  function scrubString(s){
    var out = String(s == null ? '' : s);
    for(var i=0;i<phraseRules.length;i++) out = out.replace(phraseRules[i][0], phraseRules[i][1]);
    return out;
  }
  function scrubTextNodes(root){
    root = root || document.body;
    if(!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode:function(node){
        var p = node.parentNode;
        if(!p) return NodeFilter.FILTER_REJECT;
        var tag = (p.nodeName || '').toLowerCase();
        if(tag === 'script' || tag === 'style' || tag === 'textarea') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var list=[], n;
    while((n = walker.nextNode())) list.push(n);
    list.forEach(function(node){
      var v = node.nodeValue;
      var nv = scrubString(v);
      if(nv !== v) node.nodeValue = nv;
    });
  }
  function scrubTitles(){
    ['actionTitle','lrPopupTitle','roomTitle'].forEach(function(id){ var el=byId(id); if(el){ var t=el.textContent, nt=scrubString(t); if(nt!==t) el.textContent=nt; }});
  }

  function wrapPopup(){
    if(window.__LR73P_POPUP_WRAPPED__) return;
    if(typeof window.lrOpenPopup !== 'function') return;
    window.__LR73P_POPUP_WRAPPED__ = true;
    var old = window.lrOpenPopup;
    window.lrOpenPopup = function(title, html){
      title = scrubString(title);
      html = scrubString(html || '');
      var out = old.call(window, title, html);
      setTimeout(function(){ scrubTextNodes(byId('lrPopupRoot') || document.body); scrubTitles(); }, 20);
      setTimeout(schedulePolish, 60);
      return out;
    };
    try{ lrOpenPopup = window.lrOpenPopup; }catch(e){}
  }

  function wrapRealCurriculum(){
    if(window.__LR73P_REAL_WRAPPED__) return;
    if(typeof window.openRealCurriculumPicker !== 'function') return;
    window.__LR73P_REAL_WRAPPED__ = true;
    var old = window.openRealCurriculumPicker;
    window.openRealCurriculumPicker = async function(subject){
      var out = await old.apply(window, arguments);
      setTimeout(function(){
        try{
          var at = byId('actionTitle'); if(at && /REAL|Curriculum|Lesson/i.test(at.textContent||'')) at.textContent = '📚 Realm Scroll Shelf';
          var hdr = q('.lrRealCurriculumHeader h3'); if(hdr) hdr.textContent = 'Scroll Archive';
          var p = q('.lrRealCurriculumHeader p'); if(p) p.textContent = 'Choose a shelf. Each scroll opens a short reading room and challenge.';
          scrubTextNodes(byId('actionText') || document.body); scrubTitles();
        }catch(e){}
      }, 40);
      return out;
    };
    try{ openRealCurriculumPicker = window.openRealCurriculumPicker; }catch(e){}
  }

  function routeMenus(){
    var menu = byId('gameMenuSelect');
    if(menu && !menu.__lr73pMenuBound){
      menu.__lr73pMenuBound = true;
      menu.addEventListener('change', function(){
        var v = String(menu.value || '');
        var map = {collectionLog:'items', companionDen:'pets', eventLog:'quests', masteryPaths:'atlas', reportCenter:'quests', classroomSchedule:'homestead', storyCampaigns:'quests', adaptiveReview:'core', bossGauntlets:'core', worldAtlas:'atlas', systemHealth:'quests'};
        if(v === 'parentDashboard') return safe('openParentDashboard') || safe('openParentPopup');
        if(map[v]) doAction(map[v]);
        setTimeout(function(){ menu.value=''; }, 50);
      }, true);
    }
  }

  var polishTimer = 0;
  function polishNow(){
    polishTimer = 0;
    try{ document.body.classList.add('lr73pUmbrellaMap','lr73mStable','lr73oCleanNav'); }catch(e){}
    installStyles(); wrapPopup(); wrapRealCurriculum(); rewriteHeader(); rewriteCommands(); rewritePlayerIcons(); rewriteLedgerHints(); routeMenus(); scrubTextNodes(document.body); scrubTitles();
  }
  function schedulePolish(){ if(polishTimer) return; polishTimer = setTimeout(polishNow, 75); }

  function bindClicks(){
    if(window.__LR73P_CLICK_BOUND__) return;
    window.__LR73P_CLICK_BOUND__ = true;
    window.addEventListener('click', function(ev){
      var t = ev.target && ev.target.closest ? ev.target.closest('[data-lr73p-act],[data-lr73o-act],[data-lr73m-act]') : null;
      if(!t) return;
      var act = t.getAttribute('data-lr73p-act') || t.getAttribute('data-lr73o-act') || t.getAttribute('data-lr73m-act');
      if(!act) return;
      var norm = String(act).toLowerCase().replace(/[^a-z0-9]/g,'');
      var known = /^(atlas|map|realmmap|learn|golearn|featuredtrails|core|science|stem|nature|engineering|inventions|history|historywing|bible|bibleroad|biblehistory|creative|homestead|scene|look|talk|reading|writing|math|geography|logic|aerospace|heritage|life|arts|music|civics|economics|historytrails|depression|greatdepression|wildwest|shipwreck|egypt|ancientegypt|bibletrail|biblecourse|bibleartifacts|artifacthall|bibleshops|biblerewards|biblereview|creativecourse|home|items|collection|collectionlog|pets|companions|companionden|quests|questboard|writingmaster|composition|naturehealth|weather|weatherstorm|animals|animal|creatures|creaturefieldguide|england|kingsqueens|aerospacemaster|scienceengineering|coreadventure|creativeadventure|homesteadadventure|worldsupport|mapmakers|civichall|marketsquare)$/i.test(norm);
      if(!known) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      doAction(norm);
    }, true);
  }

  function overrideOldRouters(){
    if(!window.__LR73P_OLD_ROUTERS_WRAPPED__){
      window.__LR73P_OLD_ROUTERS_WRAPPED__ = true;
      window.lr68OpenLearn = function(){ return openAtlas(); };
      window.lr68bOpenLearningTrails = function(section){
        section = String(section || '').toLowerCase();
        if(section === 'world') return openHistory();
        if(section === 'stem') return openScience();
        if(section === 'creative') return openCreative();
        if(section === 'core') return openCore();
        return openAtlas();
      };
      try{ lr68OpenLearn = window.lr68OpenLearn; }catch(e){}
      try{ lr68bOpenLearningTrails = window.lr68bOpenLearningTrails; }catch(e){}
      if(typeof window.lr73mDo === 'function'){
        window.__LR73P_OLD_LR73M_DO__ = window.lr73mDo;
        window.lr73mDo = function(act){ return doAction(act || 'atlas'); };
      }
      window.openLearningRealmsRealmAtlas = openAtlas;
      window.openLearningRealmsHistoryWing = openHistory;
      window.openLearningRealmsBibleRoad = openBible;
    }
  }

  function boot(){
    bindClicks(); overrideOldRouters(); polishNow();
    setTimeout(function(){ overrideOldRouters(); polishNow(); }, 160);
    setTimeout(polishNow, 650);
    setTimeout(polishNow, 1400);
    try{
      var mo = new MutationObserver(function(){ schedulePolish(); });
      mo.observe(document.body, {subtree:true, childList:true});
    }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot, 80); setTimeout(polishNow, 900); });
})();
