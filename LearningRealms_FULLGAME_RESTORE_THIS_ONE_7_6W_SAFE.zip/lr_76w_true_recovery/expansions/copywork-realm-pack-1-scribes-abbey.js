// Handwriting / Copywork Realm Pack 1: Scribe's Abbey
// Adds a dedicated Copywork subject realm with handwriting, careful copying, spacing, punctuation, proofreading, and written precision.
// Uses subject key "Copywork" for engine simplicity.
// Adds starter Copywork grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const copyRooms = {
    scribeRoad1:{
      title:"Quillstone Path",
      zone:"Scribe Road",
      text:"A quiet stone path leaves town beneath hanging lanterns shaped like ink drops. Smooth practice boards line the way, each marked with careful letters, spacing marks, and little arrows showing where strokes begin.",
      exits:{south:"townSquare",east:"scribeRoad2"}
    },
    scribeRoad2:{
      title:"Inkleaf Bend",
      zone:"Scribe Road",
      text:"The path bends beneath trees whose leaves look like tiny pages. A low sign reads: Slow writing is strong writing. Neat work begins with attention.",
      exits:{west:"scribeRoad1",east:"scribeGate"}
    },
    scribeGate:{
      title:"Scribe's Abbey Gate",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"A calm abbey of warm stone and wooden desks stands before you. The doorway is carved with quills, books, straight lines, margin marks, and careful letters.",
      npc:{name:"Brother Quill",desc:"A patient writing guide with ink-stained fingers and a gentle voice.",text:"Brother Quill bows. 'Copywork teaches the hand, the eye, and the mind to work together. Accuracy is a quiet kind of strength.'"},
      exits:{west:"scribeRoad2",east:"letterCloister",south:"lineRoom"}
    },
    letterCloister:{
      title:"Letter Cloister",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"Arched windows shine over tablets showing uppercase letters, lowercase letters, tall letters, short letters, hanging letters, and careful stroke order.",
      npc:{name:"Sister Forma",desc:"A careful letter-shape teacher who explains size, shape, slant, and spacing.",text:"Sister Forma traces a letter in the air. 'A good letter is not rushed. It has shape, size, and a place to stand.'"},
      exits:{west:"scribeGate",east:"spacingGarden",south:"copyDeskHall"}
    },
    lineRoom:{
      title:"Line Room",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"Long tables are covered with practice pages. Wide lines, narrow lines, margins, baselines, and guide marks help writers keep letters steady and easy to read.",
      npc:{name:"Margin Mole",desc:"A tiny mole with spectacles who teaches margins, baselines, and staying on the line.",text:"Margin Mole peeks over a ruler. 'Letters like homes. Put them on the line, give them room, and they behave better.'"},
      exits:{north:"scribeGate",east:"copyDeskHall",south:"punctuationTower"}
    },
    copyDeskHall:{
      title:"Copy Desk Hall",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"A hall of wooden desks holds clean pages and short model sentences. Each desk has a tiny lamp, a smooth writing board, and a sign: Look, remember, write, check.",
      npc:{name:"Copy Master Vale",desc:"A calm mentor who teaches accurate copying, word spacing, and checking against a model.",text:"Vale points to a model sentence. 'Copy once with care. Then compare every word, every capital, every mark.'"},
      exits:{north:"letterCloister",west:"lineRoom",east:"proofingLibrary",south:"spacingGarden"}
    },
    spacingGarden:{
      title:"Spacing Garden",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"Small stepping stones sit between flower beds at even distances. The garden teaches spaces between letters, words, sentences, and paragraphs.",
      npc:{name:"Gapwise Pippin",desc:"A cheerful garden keeper who teaches word spacing and visual neatness.",text:"Pippin hops between stones. 'Too close, and words bump heads. Too far, and they wander away. Good spacing helps readers breathe.'"},
      exits:{north:"letterCloister",west:"copyDeskHall",east:"punctuationTower"}
    },
    punctuationTower:{
      title:"Punctuation Tower",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"A small tower rises above the abbey. Bells hang beside signs for periods, commas, question marks, exclamation marks, apostrophes, quotation marks, and colons.",
      npc:{name:"Keeper Period",desc:"A precise bellkeeper who teaches punctuation and sentence boundaries.",text:"Keeper Period rings a tiny bell. 'Marks are small, but they guide the reader's voice.'"},
      exits:{north:"lineRoom",west:"spacingGarden",east:"proofingLibrary"}
    },
    proofingLibrary:{
      title:"Proofing Library",
      zone:"Scribe's Abbey",
      subject:"Copywork",
      text:"This quiet library holds comparison pages, proofreading marks, clean copies, and mistake hunts. A brass sign reads: The best scribes check their own work.",
      npc:{name:"Inspector Redline",desc:"A friendly proofreader who teaches editing, checking, and fixing mistakes without fuss.",text:"Inspector Redline smiles over his spectacles. 'A mistake found is not a failure. It is a chance to make the page stronger.'"},
      exits:{west:"copyDeskHall",south:"punctuationTower"}
    }
  };

  Object.assign(ROOMS, copyRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.west) ROOMS.townSquare.exits.west = "scribeRoad1";
    else if(!ROOMS.townSquare.exits.northwest) ROOMS.townSquare.exits.northwest = "scribeRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Copywork = window.LR_REWARDS.Copywork || [];
  window.LR_REWARDS.Copywork.push(
    {name:"Tiny Quill Stand",slot:"desk"},
    {name:"Clean Copy Ribbon",slot:"wall"},
    {name:"Spacing Stone Set",slot:"shelf"},
    {name:"Punctuation Bell",slot:"shelf"},
    {name:"Proofreader Lens",slot:"desk"},
    {name:"Margin Guide Plaque",slot:"wall"},
    {name:"Scribe Abbey Lantern",slot:"shelf"},
    {name:"Golden Baseline Ruler",slot:"desk"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Copywork = {display:"Handwriting / Copywork",targetCorrect:160,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Copywork = {display:"Copywork / Proofreading / Written Precision",targetCorrect:180,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Copywork = {display:"Copywork / Editing / Accuracy",targetCorrect:180,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Copywork")) cfg.assignmentSubjects[child].push("Copywork");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Copywork:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Copywork:2}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Copywork:2}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Copywork = {
    zone:"Scribe's Abbey",
    units:[
      {id:"G1-COPY-LETTERS",title:"Letter Formation",goal:"Practice clear letter shapes, size, direction, and line placement.",targetLessons:120,skills:["uppercase","lowercase","baseline","letter size","letter shape"]},
      {id:"G1-COPY-WORDS",title:"Words and Spacing",goal:"Copy words and short sentences with clear spacing and simple punctuation.",targetLessons:120,skills:["word spacing","sentence spacing","period","capital letter","neat copy"]},
      {id:"G1-COPY-CHECK",title:"Check Your Work",goal:"Compare copywork to a model and notice missing capitals, letters, spaces, or punctuation.",targetLessons:80,skills:["compare","check","fix","capital","punctuation"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Copywork = {
    zone:"Scribe's Abbey",
    units:[
      {id:"G6-COPY-ACCURACY",title:"Accurate Transcription",goal:"Copy passages accurately with punctuation, capitalization, paragraphing, and attention to detail.",targetLessons:130,skills:["accuracy","punctuation","capitalization","paragraphing","model comparison"]},
      {id:"G6-COPY-PROOF",title:"Proofreading and Correction",goal:"Find and correct copying errors, missing punctuation, unclear spacing, and grammar mistakes.",targetLessons:130,skills:["proofreading","editing","spelling","punctuation","spacing"]},
      {id:"G6-COPY-STYLE",title:"Sentence Style Through Copywork",goal:"Notice sentence patterns, transitions, word choice, and punctuation style in carefully chosen model sentences.",targetLessons:120,skills:["sentence style","transition","word choice","quotation marks","commas"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Copywork = {
    zone:"Scribe's Abbey",
    units:[
      {id:"G7-COPY-PRECISION",title:"Precision and Accuracy",goal:"Develop accuracy in copying, note-taking, punctuation, structure, and self-checking.",targetLessons:130,skills:["precision","copy accuracy","note-taking","self-check","format"]},
      {id:"G7-COPY-EDITING",title:"Editing for Clarity",goal:"Use proofreading and editing to improve clarity, mechanics, and organization.",targetLessons:130,skills:["clarity","editing","mechanics","organization","revision"]},
      {id:"G7-COPY-ANALYSIS",title:"Learning From Models",goal:"Analyze copied models for sentence structure, punctuation, word choice, and effect.",targetLessons:120,skills:["model analysis","syntax","punctuation effect","tone","style"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-COPY-LINE-1",subject:"Copywork",unit:"G1-COPY-WORDS",title:"Careful Sentence Copy",prompt:"Copy this sentence neatly on paper: The little fox ran home. Then check capitals, spaces, and the period.",helper:"Look at each word. Leave finger spaces. End with a period.",estimatedMinutes:15},
    {id:"LUNA-COPY-LETTER-1",subject:"Copywork",unit:"G1-COPY-LETTERS",title:"Letter Shape Practice",prompt:"Choose five letters that are hard for you and practice each one carefully. Circle the neatest one for each letter.",helper:"Go slow. Start in the right place. Keep letters on the line.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-COPY-PROOF-1",subject:"Copywork",unit:"G6-COPY-PROOF",title:"Proofread a Copy",prompt:"Copy a short paragraph from your reading or from a parent-approved sentence set. Then compare it to the original and mark every difference.",helper:"Check capitals, punctuation, spelling, skipped words, and paragraphing.",estimatedMinutes:25},
    {id:"AVA-COPY-STYLE-1",subject:"Copywork",unit:"G6-COPY-STYLE",title:"Notice Sentence Style",prompt:"Copy two strong sentences and explain one thing you notice about word choice, punctuation, or sentence rhythm.",helper:"Look for commas, strong verbs, transitions, or sentence length.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-COPY-PRECISION-1",subject:"Copywork",unit:"G7-COPY-PRECISION",title:"Precision Copy Challenge",prompt:"Copy a short model passage exactly, then write a short reflection on what kinds of errors you had to check for.",helper:"Track skipped words, punctuation, capitalization, spelling, and formatting.",estimatedMinutes:30},
    {id:"MICHAEL-COPY-EDIT-1",subject:"Copywork",unit:"G7-COPY-EDITING",title:"Edit for Clarity",prompt:"Write three rough sentences, then revise them for clarity and correct mechanics. Explain one change you made.",helper:"Focus on punctuation, sentence boundaries, specific words, and flow.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addCopyworkLadder(child){
    LR_addLessons(child,"Copywork",[
      {gradeBand:"K",unit:"K-COPY-LETTERS",skill:"letter shapes",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Letters have shapes. Some are tall, some are short, and some go below the line.",
       workedExample:"The letter l is tall. The letter a is short.",
       guidedPractice:"Choose the tall letter.",
       q:"Which letter is tall?",c:["l","a","o"],a:"l",
       explain:"Lowercase l is a tall letter."},

      {gradeBand:"G1",unit:"G1-COPY-SPACING",skill:"word spaces",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Words need spaces so readers can tell where one word ends and the next begins.",
       workedExample:"The cat ran is easier to read than Thecatran.",
       guidedPractice:"Look for clear spaces between words.",
       q:"Which is easier to read?",c:["The cat ran.","Thecatran.","Thec atran."],a:"The cat ran.",
       explain:"The words have clear spaces."},

      {gradeBand:"G2",unit:"G2-COPY-PUNCT",skill:"ending punctuation",difficulty:"grade 2",mode:"foundation",
       miniLesson:"A telling sentence usually ends with a period.",
       workedExample:"The rabbit hopped. ends with a period.",
       guidedPractice:"Choose the sentence with correct ending punctuation.",
       q:"Which sentence is punctuated correctly?",c:["The rabbit hopped.","The rabbit hopped","the rabbit hopped"],a:"The rabbit hopped.",
       explain:"It starts with a capital and ends with a period."},

      {gradeBand:"G3",unit:"G3-COPY-CHECK",skill:"checking against a model",difficulty:"grade 3",mode:"foundation",
       miniLesson:"After copying, compare your work to the model.",
       workedExample:"Check every word, capital letter, punctuation mark, and space.",
       guidedPractice:"Choose what to check.",
       q:"After copying a sentence, you should compare it to the...",c:["model","weather","coin"],a:"model",
       explain:"The model helps you find copying mistakes."},

      {gradeBand:"G4",unit:"G4-COPY-QUOTES",skill:"quotation marks",difficulty:"grade 4",mode:"foundation",
       miniLesson:"Quotation marks show exact spoken words.",
       workedExample:"Mira said, 'Bring the map.' The words inside quotation marks are exactly what Mira said.",
       guidedPractice:"Look for the marks around spoken words.",
       q:"Quotation marks show...",c:["exact spoken words","multiplication only","weather"],a:"exact spoken words",
       explain:"Quotation marks mark the exact words spoken."},

      {gradeBand:"G5",unit:"G5-COPY-COMMAS",skill:"commas in a series",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Commas can separate items in a series.",
       workedExample:"The pack held bread, rope, and a lantern.",
       guidedPractice:"Look for commas between listed items.",
       q:"Which sentence uses commas in a series correctly?",c:["The pack held bread, rope, and a lantern.","The pack held bread rope and a lantern.","The pack, held bread rope and a lantern."],a:"The pack held bread, rope, and a lantern.",
       explain:"Commas separate the listed items."},

      {gradeBand:"G6",unit:"G6-COPY-PROOF",skill:"proofreading",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Proofreading means checking writing for mistakes before calling it finished.",
       workedExample:"A proofreader looks for spelling, punctuation, capitalization, skipped words, and sentence errors.",
       guidedPractice:"Choose the purpose of proofreading.",
       q:"Proofreading means checking writing for...",c:["mistakes","weather","slope"],a:"mistakes",
       explain:"Proofreading finds and fixes mistakes."},

      {gradeBand:"G7",unit:"G7-COPY-STYLE",skill:"model analysis",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Copywork can help you notice how strong sentences are built.",
       workedExample:"A sentence may use a transition, a vivid verb, or a comma to guide the reader.",
       guidedPractice:"Look at structure, word choice, and punctuation.",
       q:"Model analysis helps you notice...",c:["sentence choices","random guessing","map distance"],a:"sentence choices",
       explain:"Analyzing models helps writers notice how sentences work."},

      {gradeBand:"G8",unit:"G8-COPY-PRECISION",skill:"precision",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Precision means being exact and careful.",
       workedExample:"In copywork, precision means matching words, spelling, punctuation, capitalization, and formatting.",
       guidedPractice:"Choose the word that means exact carefulness.",
       q:"Precision means being...",c:["exact and careful","fast and careless","silent only"],a:"exact and careful",
       explain:"Precision is careful exactness."}
    ]);
  }

  LR_addCopyworkLadder("Luna");
  LR_addCopyworkLadder("Ava");
  LR_addCopyworkLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Copywork = [
    {title:"Spacing Garden Trial",intro:"Gapwise Pippin points to three copied sentences.",q:"Which is easiest to read?",c:["The cat ran.","Thecatran.","Thec atran."],a:"The cat ran.",reward:"Spacing Stone Badge"},
    {title:"Period Bell Trial",intro:"Keeper Period rings a small bell.",q:"A telling sentence usually ends with a...",c:["period","comma only","number"],a:"period",reward:"Punctuation Bell"}
  ];

  window.LR_BOSS_CONTENT.Ava.Copywork = [
    {title:"Proofing Library Trial",intro:"Inspector Redline opens a page with one missing mark.",q:"Proofreading means checking writing for...",c:["mistakes","weather","coin value"],a:"mistakes",reward:"Proofreader Lens"},
    {title:"Comma Series Trial",intro:"Keeper Period points to a list of supplies.",q:"Commas in a series separate...",c:["listed items","all verbs","map symbols"],a:"listed items",reward:"Comma Keeper Ribbon"}
  ];

  window.LR_BOSS_CONTENT.Michael.Copywork = [
    {title:"Precision Copy Trial",intro:"Copy Master Vale places a model beside a copy.",q:"Precision in copywork means matching words, spelling, punctuation, and...",c:["formatting","temperature","supply"],a:"formatting",reward:"Golden Baseline Ruler"},
    {title:"Model Analysis Trial",intro:"Sister Forma asks what copywork can teach beyond neatness.",q:"Analyzing model sentences helps writers notice...",c:["sentence choices","random guesses","only page color"],a:"sentence choices",reward:"Scribe Style Seal"}
  ];
})();
