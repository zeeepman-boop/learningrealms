// Curriculum Pack 6E - Life Skills Foundation
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Life Skills",[
{teach:"Putting toys away helps keep rooms neat.",q:"What helps keep rooms neat?",c:["putting toys away","throwing toys","hiding toys"],a:"putting toys away"},
{teach:"Wash hands before eating.",q:"When should hands be washed?",c:["before eating","after sleeping only","never"],a:"before eating"},
{teach:"Needs are important things like food and home.",q:"Which is a need?",c:["food","extra toy","sticker"],a:"food"},
{teach:"Belongings last longer when cared for.",q:"What helps belongings last?",c:["taking care of them","throwing them","forgetting them"],a:"taking care of them"},
{teach:"Helping family is a good habit.",q:"Helping family is...",c:["a good habit","a race","a game only"],a:"a good habit"},
{teach:"Put things back where they belong.",q:"After using something...",c:["put it back","hide it","drop it"],a:"put it back"},
{teach:"Brush teeth every day.",q:"What should be done daily?",c:["brush teeth","lose shoes","spill water"],a:"brush teeth"},
{teach:"Weather changes what we wear.",q:"Cold weather may need...",c:["a coat","sandals","swimsuit"],a:"a coat"}
]);

LR_addLessons("Ava","Life Skills",[
{teach:"Planning helps finish jobs.",q:"Planning helps...",c:["finish jobs","forget work","lose time"],a:"finish jobs"},
{teach:"Needs come before wants.",q:"Which should come first?",c:["needs","wants","extras"],a:"needs"},
{teach:"Saving means keeping money for later.",q:"Saving means...",c:["keeping money for later","spending all","hiding forever"],a:"keeping money for later"},
{teach:"Kitchen safety matters.",q:"What matters in kitchens?",c:["safety","speed only","noise"],a:"safety"},
{teach:"Organization saves time.",q:"Organization can save...",c:["time","rain","paint"],a:"time"},
{teach:"Lists help remember tasks.",q:"What helps remember tasks?",c:["lists","clouds","bells"],a:"lists"},
{teach:"Responsibilities should be completed.",q:"Responsibilities should...",c:["be completed","be ignored","be hidden"],a:"be completed"},
{teach:"Budgets help track spending.",q:"Budgets help track...",c:["spending","weather","stories"],a:"spending"}
]);

LR_addLessons("Michael","Life Skills",[
{teach:"Budgets balance needs, savings, and spending.",q:"Budgets balance...",c:["needs savings and spending","luck only","random choices"],a:"needs savings and spending"},
{teach:"Time management helps productivity.",q:"Time management helps...",c:["productivity","confusion","forgetting"],a:"productivity"},
{teach:"Decision making compares options.",q:"Decision making compares...",c:["options","colors only","noise"],a:"options"},
{teach:"Preparedness reduces problems.",q:"Preparedness can...",c:["reduce problems","cause storms","erase time"],a:"reduce problems"},
{teach:"Maintenance prevents bigger issues.",q:"Maintenance often...",c:["prevents bigger issues","creates damage","does nothing"],a:"prevents bigger issues"},
{teach:"Practical skills build independence.",q:"Practical skills build...",c:["independence","confusion","luck"],a:"independence"},
{teach:"Goals work best when planned.",q:"Goals work best when...",c:["planned","ignored","hidden"],a:"planned"},
{teach:"Resources should be used wisely.",q:"Resources should be used...",c:["wisely","carelessly","randomly"],a:"wisely"}
]);
})();