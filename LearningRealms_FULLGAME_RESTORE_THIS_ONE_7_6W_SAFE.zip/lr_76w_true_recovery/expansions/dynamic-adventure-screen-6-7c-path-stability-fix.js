/* LearningRealms Dynamic Adventure Screen 6.7C
   Path stability fix: dynamic travel now changes scenes directly instead of calling the older
   render/navigation stack. This prevents choices like the fountain path from making the main
   adventure window disappear.
*/
(function(){
  'use strict';
  if(window.__LR67C_PATH_STABILITY_FIX__) return;
  window.__LR67C_PATH_STABILITY_FIX__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function stripEmoji(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){
    try{ if(typeof state !== 'undefined' && state) return state; }catch(e){}
    try{ if(window.state) return window.state; }catch(e){}
    return null;
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined' && ROOMS) return ROOMS; }catch(e){}
    return {};
  }
  function currentLoc(){
    var s = getState();
    return (s && s.loc) ? s.loc : 'crossroads';
  }
  function currentRoom(){
    var rooms = getRooms();
    var loc = currentLoc();
    try{ if(typeof room === 'function') return room() || rooms[loc] || {}; }catch(e){}
    try{ if(typeof window.room === 'function') return window.room() || rooms[loc] || {}; }catch(e){}
    return rooms[loc] || rooms.crossroads || {};
  }
  function callMaybe(name){
    try{ if(typeof window[name] === 'function') return window[name].apply(window, Array.prototype.slice.call(arguments,1)); }catch(e){ console.warn(name, e); }
    try{ if(typeof eval(name) === 'function') return eval(name).apply(window, Array.prototype.slice.call(arguments,1)); }catch(e){}
  }
  function safeSave(){ callMaybe('save'); }

  function ensureMount(){
    try{ document.body.classList.add('lrDynamicAdventureMode'); document.body.classList.remove('homeMode'); }catch(e){}
    var main = document.querySelector('.main');
    var firstCard = document.querySelector('.main > .card:first-child') || main || document.querySelector('main') || document.body;
    try{
      if(main){ main.style.display = ''; main.style.visibility = 'visible'; main.style.opacity = '1'; }
      if(firstCard){ firstCard.style.display = 'block'; firstCard.style.visibility = 'visible'; firstCard.style.opacity = '1'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen';
      if(firstCard.firstChild) firstCard.insertBefore(mount, firstCard.firstChild);
      else firstCard.appendChild(mount);
    }
    mount.style.display = 'block';
    mount.style.visibility = 'visible';
    mount.style.opacity = '1';
    mount.style.width = '100%';
    mount.style.minHeight = '560px';
    return mount;
  }

  function hideOldNavigationShells(){
    ['lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','mainCompassNav','movementControls'].forEach(function(id){
      var el = byId(id);
      if(el){ el.style.display = 'none'; el.style.visibility = 'hidden'; el.style.height = '0'; el.style.overflow = 'hidden'; }
    });
    try{
      document.querySelectorAll('.compassBox,.compassGrid,.movementButtons,.travelButtons,.tinyTravelFooter,.lrAdventurePanel,.lrExplorePanel').forEach(function(el){
        el.style.display = 'none'; el.style.visibility = 'hidden'; el.style.height = '0'; el.style.overflow = 'hidden';
      });
    }catch(e){}
  }

  function forceDynamicVisible(note){
    ensureMount();
    hideOldNavigationShells();
    try{
      if(typeof window.lr67RenderDynamicScreen === 'function'){
        window.lr67RenderDynamicScreen('room', note || undefined);
      }
    }catch(e){ console.warn('6.7C render retry skipped', e); }
    var mount = ensureMount();
    if(mount && (!mount.innerHTML || !mount.innerHTML.trim())){
      var r = currentRoom();
      mount.innerHTML = '<div class="lr67Hero"><div class="lr67HeroTop"><span class="lr67Kicker">Dynamic adventure screen</span></div><h1>' + esc(r.title || currentLoc() || 'LearningRealms') + '</h1><div class="lr67SceneText"><p>' + esc(note || r.text || 'The next scene is ready.') + '</p></div></div>' +
        '<div class="lr67BottomBar"><button type="button" onclick="lr67RenderDynamicScreen(\'look\')">🔎 Look around</button><button type="button" onclick="lr67OpenLearn()">📘 Go Learn</button><button type="button" onclick="lr67GoHome()">🏡 Home</button></div>';
    }
  }

  function describeTarget(target, dir){
    var rooms = getRooms();
    var r = rooms[target] || {};
    var title = stripEmoji(r.title || target || 'the next place');
    var zone = stripEmoji(r.zone || '');
    var subject = stripEmoji(r.subject || '');
    if(target === 'home') return 'You return to Home Hearth.';
    if(/fountain|town square|crossroads/i.test(title + ' ' + zone)) return 'You walk toward the fountain and the town square opens around you.';
    if(dir === 'up') return 'You climb toward ' + title + '.';
    if(dir === 'down') return 'You climb down toward ' + title + '.';
    if(dir === 'out') return 'You step back toward ' + title + '.';
    if(subject) return 'You travel to ' + title + ', where ' + subject + ' learning waits.';
    if(zone) return 'You travel to ' + title + ' in ' + zone + '.';
    return 'You travel to ' + title + '.';
  }

  function resolveTarget(dirOrTarget){
    var rooms = getRooms();
    var r = currentRoom();
    var exits = (r && r.exits) || {};
    if(exits && exits[dirOrTarget]) return {target:exits[dirOrTarget], dir:dirOrTarget};
    if(rooms[dirOrTarget]) return {target:dirOrTarget, dir:''};
    return {target:null, dir:dirOrTarget};
  }

  function directDynamicTravel(dirOrTarget){
    try{
      var resolved = resolveTarget(dirOrTarget);
      var target = resolved.target;
      var dir = resolved.dir;
      if(!target){
        forceDynamicVisible('No path opens that way yet.');
        return false;
      }
      var s = getState();
      if(!s){ forceDynamicVisible('The save state was not ready yet. Try the choice again.'); return false; }

      var note = describeTarget(target, dir);
      s.loc = target;
      s.room = Math.max(0, Number(s.room || 0)) + 1;
      try{ if(target !== 'home') document.body.classList.remove('homeMode'); }catch(e){}
      try{ callMaybe('lrPagedMapMove', dir); }catch(e){}
      try{ callMaybe('lrMiniMapMoveDirection', dir); }catch(e){}
      try{ callMaybe('recordGameFunEvent', 'roomVisits', 1, {room:target}); }catch(e){}
      try{ var lb = byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
      try{ var sb = byId('storageBox'); if(sb) sb.classList.add('hidden'); }catch(e){}
      safeSave();

      // Do NOT call the older go()/renderRoom() stack here. That stack can hand off to old panels
      // and hide the new main adventure window. Dynamic mode owns scene-to-scene movement now.
      hideOldNavigationShells();
      try{ callMaybe('renderStats'); }catch(e){}
      try{ callMaybe('renderHomeSlots'); }catch(e){}
      forceDynamicVisible(note);
      setTimeout(function(){ forceDynamicVisible(); }, 35);
      setTimeout(function(){ forceDynamicVisible(); }, 150);
      return false;
    }catch(e){
      console.error('6.7C direct dynamic travel failed', e);
      forceDynamicVisible('Something blocked that travel choice: ' + (e.message || e));
      return false;
    }
  }

  function dynamicHome(){
    var s = getState();
    if(s){ s.loc = 'home'; s.room = Math.max(0, Number(s.room || 0)) + 1; }
    try{ document.body.classList.remove('homeMode'); }catch(e){}
    safeSave();
    forceDynamicVisible('You step back into Home Hearth.');
    setTimeout(function(){ forceDynamicVisible(); }, 90);
    return false;
  }

  function installOverrides(){
    window.lr67ChoosePath = directDynamicTravel;
    window.lrAdventureChoiceGo = directDynamicTravel;
    window.lrNavRestoreGo = directDynamicTravel;
    window.go = directDynamicTravel;
    window.lr67GoHome = dynamicHome;
    window.travelHome = dynamicHome;
    window.enterHomePortal = dynamicHome;
    try{ lr67ChoosePath = directDynamicTravel; }catch(e){}
    try{ lrAdventureChoiceGo = directDynamicTravel; }catch(e){}
    try{ lrNavRestoreGo = directDynamicTravel; }catch(e){}
    try{ go = directDynamicTravel; }catch(e){}
    try{ lr67GoHome = dynamicHome; }catch(e){}
    try{ travelHome = dynamicHome; }catch(e){}
    try{ enterHomePortal = dynamicHome; }catch(e){}
  }

  function injectStyles(){
    if(byId('lr67CPathStabilityStyle')) return;
    var st = document.createElement('style');
    st.id = 'lr67CPathStabilityStyle';
    st.textContent = `
      body.lrDynamicAdventureMode .main,
      body.lrDynamicAdventureMode .main > .card:first-child,
      body.lrDynamicAdventureMode #lrDynamicAdventureScreen{
        display:block !important;
        visibility:visible !important;
        opacity:1 !important;
      }
      body.lrDynamicAdventureMode #lrDynamicAdventureScreen{
        width:100% !important;
        min-height:560px !important;
        position:relative !important;
        z-index:2 !important;
      }
      body.lrDynamicAdventureMode #mainCompassNav,
      body.lrDynamicAdventureMode .compassBox,
      body.lrDynamicAdventureMode .compassGrid,
      body.lrDynamicAdventureMode #lrControlDock,
      body.lrDynamicAdventureMode #lrFixedGameplayDock,
      body.lrDynamicAdventureMode #lrCenterActionDock,
      body.lrDynamicAdventureMode #lrCenterGameplayDock,
      body.lrDynamicAdventureMode .movementButtons,
      body.lrDynamicAdventureMode .travelButtons,
      body.lrDynamicAdventureMode .tinyTravelFooter{
        display:none !important;
        height:0 !important;
        max-height:0 !important;
        min-height:0 !important;
        overflow:hidden !important;
        padding:0 !important;
        margin:0 !important;
      }
    `;
    document.head.appendChild(st);
  }

  function watchdog(){
    try{
      installOverrides();
      injectStyles();
      var mount = byId('lrDynamicAdventureScreen');
      var bad = !mount || mount.style.display === 'none' || mount.offsetParent === null || !mount.innerHTML || !mount.innerHTML.trim();
      // offsetParent is null for fixed/hidden ancestors, so double-check computed display.
      if(mount){
        var cs = window.getComputedStyle ? window.getComputedStyle(mount) : null;
        if(cs && (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0')) bad = true;
      }
      if(bad) forceDynamicVisible();
      else hideOldNavigationShells();
    }catch(e){}
  }

  function boot(){
    installOverrides();
    injectStyles();
    forceDynamicVisible();
    setTimeout(watchdog, 80);
    setTimeout(watchdog, 300);
    setTimeout(watchdog, 900);
    try{
      if(!window.__LR67C_WATCHDOG_TIMER__){
        window.__LR67C_WATCHDOG_TIMER__ = setInterval(watchdog, 700);
      }
    }catch(e){}
    try{
      if(!window.__LR67C_MUTATION_OBSERVER__ && window.MutationObserver){
        window.__LR67C_MUTATION_OBSERVER__ = new MutationObserver(function(){ setTimeout(watchdog, 20); });
        window.__LR67C_MUTATION_OBSERVER__.observe(document.body, {childList:true, subtree:true, attributes:true, attributeFilter:['style','class']});
      }
    }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 15);
  window.addEventListener('load', function(){ setTimeout(boot, 120); setTimeout(watchdog, 650); });
})();
