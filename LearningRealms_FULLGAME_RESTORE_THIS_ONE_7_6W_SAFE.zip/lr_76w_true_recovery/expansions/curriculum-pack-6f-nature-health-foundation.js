// Curriculum Pack 6F: Nature / Health Foundation
// Content-only expansion. No UI, Home, save, multiplayer, or engine changes.
// Uses LR_addLessons() so the subject stays open-ended for future thousands of lessons.

(function(){
  if (typeof LR_addLessons !== "function") {
    console.warn("LearningRealms: LR_addLessons not found for Curriculum Pack 6F.");
    return;
  }

  LR_addLessons("Luna", "Nature / Health", [
    {
      teach:"Living things need care. Plants need water, light, and room to grow.",
      practice:"A little seed cannot grow well if it is kept dry and dark forever.",
      q:"What does a plant need to grow?",
      c:["water and light","a blanket only","a locked box"],
      a:"water and light"
    },
    {
      teach:"Animals need food, water, shelter, and safe space.",
      practice:"A bird nest helps protect baby birds.",
      q:"What helps an animal stay safe?",
      c:["shelter","loud banging","no water"],
      a:"shelter"
    },
    {
      teach:"Healthy habits help the body stay ready for the day.",
      practice:"Sleep, clean hands, good food, and movement all help the body.",
      q:"Which is a healthy habit?",
      c:["washing hands","licking mud","never sleeping"],
      a:"washing hands"
    },
    {
      teach:"Weather tells what the sky and air are like.",
      practice:"Rainy, sunny, windy, and snowy are kinds of weather.",
      q:"Which word describes weather?",
      c:["windy","pillow","spoon"],
      a:"windy"
    },
    {
      teach:"The five senses help us notice the world.",
      practice:"Eyes see color. Ears hear sound. Skin feels warm and cold.",
      q:"Which sense uses ears?",
      c:["hearing","smelling","tasting"],
      a:"hearing"
    },
    {
      teach:"A habitat is the home place where a living thing belongs.",
      practice:"A pond can be a habitat for frogs, fish, and insects.",
      q:"What is a habitat?",
      c:["a living thing's home place","a kind of candy","a hat"],
      a:"a living thing's home place"
    },
    {
      teach:"Clean water is important for people, animals, and plants.",
      practice:"Water helps bodies work and helps plants stand tall.",
      q:"Why is clean water important?",
      c:["living things need it","it makes rocks fly","it turns night into day"],
      a:"living things need it"
    },
    {
      teach:"Exercise means moving the body on purpose.",
      practice:"Walking, stretching, jumping, and playing can all move the body.",
      q:"Exercise means...",
      c:["moving the body","sitting forever","hiding socks"],
      a:"moving the body"
    },
    {
      teach:"Food gives the body energy.",
      practice:"Different foods help the body in different ways.",
      q:"Food gives the body...",
      c:["energy","thunder","paint"],
      a:"energy"
    },
    {
      teach:"Nature has patterns, like day and night or seasons changing.",
      practice:"Spring, summer, fall, and winter come in a repeating order.",
      q:"Which is a nature pattern?",
      c:["seasons","a broken cup","one random shoe"],
      a:"seasons"
    }
  ]);

  LR_addLessons("Ava", "Nature / Health", [
    {
      teach:"An ecosystem includes living things and the nonliving parts around them.",
      practice:"A pond ecosystem may include frogs, fish, insects, water, mud, sunlight, and plants.",
      q:"What belongs in an ecosystem?",
      c:["living and nonliving parts","only one animal","only clouds"],
      a:"living and nonliving parts"
    },
    {
      teach:"Producers are living things that make their own food, usually using sunlight.",
      practice:"Grass, trees, and algae are producers.",
      q:"Which is usually a producer?",
      c:["grass","fox","rock"],
      a:"grass"
    },
    {
      teach:"Consumers get energy by eating plants or other animals.",
      practice:"A rabbit eats plants. A hawk may eat smaller animals.",
      q:"A consumer gets energy by...",
      c:["eating","turning into stone","making thunder"],
      a:"eating"
    },
    {
      teach:"Decomposers break down dead material and return nutrients to the soil.",
      practice:"Fungi and worms can help break down old leaves.",
      q:"What do decomposers do?",
      c:["break down dead material","build metal bridges","erase the sun"],
      a:"break down dead material"
    },
    {
      teach:"A food chain shows how energy moves from one living thing to another.",
      practice:"Grass to rabbit to fox is a simple food chain.",
      q:"A food chain shows...",
      c:["energy moving through living things","a shopping list","where shoes go"],
      a:"energy moving through living things"
    },
    {
      teach:"The body needs rest to recover and grow.",
      practice:"Sleep helps the brain, muscles, and mood.",
      q:"Why does the body need rest?",
      c:["to recover","to stop learning forever","to become invisible"],
      a:"to recover"
    },
    {
      teach:"First aid means simple help given for minor injuries or until more help arrives.",
      practice:"Cleaning a small scrape and covering it can be basic first aid.",
      q:"What is first aid?",
      c:["simple injury help","a board game","a weather report"],
      a:"simple injury help"
    },
    {
      teach:"Labels can help people understand ingredients, serving sizes, and safety information.",
      practice:"Reading a label can help compare foods or notice allergens.",
      q:"What can labels help you understand?",
      c:["ingredients and safety information","tree height only","music notes only"],
      a:"ingredients and safety information"
    },
    {
      teach:"Weather and climate are different. Weather is short term. Climate is long term patterns.",
      practice:"A rainy afternoon is weather. A region’s usual seasons are climate.",
      q:"Weather is usually...",
      c:["short term","always a century","never changing"],
      a:"short term"
    },
    {
      teach:"Observation helps nature study because details matter.",
      practice:"A naturalist may note tracks, feathers, sounds, leaf shapes, and water levels.",
      q:"Why is observation useful in nature study?",
      c:["details matter","guessing is always enough","it hides evidence"],
      a:"details matter"
    }
  ]);

  LR_addLessons("Michael", "Nature / Health", [
    {
      teach:"Homeostasis means the body works to keep internal conditions steady.",
      practice:"The body regulates temperature, fluids, and blood sugar within useful ranges.",
      q:"Homeostasis means keeping internal conditions...",
      c:["steady","random","always frozen"],
      a:"steady"
    },
    {
      teach:"Nutrients support body structure, energy, and repair.",
      practice:"Protein supports tissues. Carbohydrates and fats can provide energy. Vitamins and minerals support many body processes.",
      q:"Nutrients help with...",
      c:["energy, structure, and repair","turning into smoke","stopping all growth"],
      a:"energy, structure, and repair"
    },
    {
      teach:"A biome is a large natural region with characteristic climate, plants, and animals.",
      practice:"Forests, grasslands, deserts, tundra, and wetlands are examples of major biome types.",
      q:"A biome is a large region with characteristic...",
      c:["climate, plants, and animals","buildings only","one single rock"],
      a:"climate, plants, and animals"
    },
    {
      teach:"Biodiversity means variety of living things in an area.",
      practice:"A forest with many plants, insects, birds, fungi, and mammals has rich biodiversity.",
      q:"Biodiversity means...",
      c:["variety of living things","only one species","empty land"],
      a:"variety of living things"
    },
    {
      teach:"Adaptations are traits that help living things survive or reproduce in their environment.",
      practice:"Camouflage, thick fur, sharp beaks, and deep roots can all be adaptations.",
      q:"An adaptation helps a living thing...",
      c:["survive or reproduce","forget its habitat","become a machine"],
      a:"survive or reproduce"
    },
    {
      teach:"Systems thinking means looking at how parts affect one another.",
      practice:"Changing water levels can affect plants, insects, frogs, birds, and soil.",
      q:"Systems thinking looks at...",
      c:["how parts affect one another","one fact alone","only names"],
      a:"how parts affect one another"
    },
    {
      teach:"Risk assessment means noticing hazards and choosing safer actions.",
      practice:"Checking weather before a hike and carrying water are simple safety decisions.",
      q:"Risk assessment helps you choose...",
      c:["safer actions","more danger","no plan"],
      a:"safer actions"
    },
    {
      teach:"Public health studies how groups of people stay healthier and safer.",
      practice:"Clean water, sanitation, food safety, and disease prevention are public health topics.",
      q:"Public health focuses on...",
      c:["groups of people","only one private notebook","ancient coins only"],
      a:"groups of people"
    },
    {
      teach:"Scientific claims should be supported by evidence, not just confidence.",
      practice:"A health claim is stronger when it has clear methods, good data, and careful interpretation.",
      q:"A scientific health claim should be supported by...",
      c:["evidence","confidence only","volume"],
      a:"evidence"
    },
    {
      teach:"Conservation means wisely protecting natural resources and living systems.",
      practice:"Protecting soil, water, habitats, and species helps keep ecosystems functioning.",
      q:"Conservation means protecting...",
      c:["natural resources and living systems","only trophies","empty boxes"],
      a:"natural resources and living systems"
    }
  ]);
})();
