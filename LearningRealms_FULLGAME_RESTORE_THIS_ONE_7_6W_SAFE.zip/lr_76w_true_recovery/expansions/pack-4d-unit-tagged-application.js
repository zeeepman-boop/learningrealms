// Curriculum Pack 4D: Unit-Tagged Applied Practice
// Applied classroom-style questions for longer homeschool learning blocks.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Reading",[
 {unit:"G1-READ-COMP",skill:"retell",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Retelling means telling the important parts in order.",practice:"First the owl found a map. Next it followed the path. Last it found the gate.",q:"What happened next after the owl found the map?",c:["It followed the path.","It ate lunch.","It went to sleep."],a:"It followed the path."},
 {unit:"G1-READ-COMP",skill:"main idea",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: The main idea is what the passage is mostly about.",practice:"A short passage tells how bees find flowers and carry pollen.",q:"What is the passage mostly about?",c:["how bees help flowers","how clocks work","how to build a chair"],a:"how bees help flowers"},
 {unit:"G1-READ-COMP",skill:"details",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: A detail tells more about the main idea.",practice:"The fox has a bushy tail and quiet paws.",q:"Which is a detail about the fox?",c:["bushy tail","fox story","the title"],a:"bushy tail"},
 {unit:"G1-READ-FLUENCY",skill:"phrase reading",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Read groups of words smoothly.",practice:"under the old bridge",q:"Which phrase tells where?",c:["under the old bridge","the old","bridge old"],a:"under the old bridge"},
 {unit:"G1-READ-PHONICS",skill:"word families",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Word family words can rhyme.",practice:"lake, cake, make",q:"Which word rhymes with lake?",c:["cake","lock","fish"],a:"cake"}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-WRITING",skill:"beginning-middle-end",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Stories have a beginning, middle, and end.",practice:"Beginning: The rabbit lost a key. Middle: It looked near the tree. End: It found the key.",q:"What happened at the end?",c:["It found the key.","It lost the key.","It looked near the tree."],a:"It found the key."},
 {unit:"G1-ELA-WRITING",skill:"adding details",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Details make a sentence clearer.",practice:"The bird sang in the tall pine tree.",q:"Which words add detail?",c:["in the tall pine tree","The bird","sang"],a:"in the tall pine tree"},
 {unit:"G1-ELA-SENTENCES",skill:"complete sentences",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: A complete sentence tells a whole thought.",practice:"The lantern glowed in the window.",q:"Which is complete?",c:["The lantern glowed in the window.","glowed in","lantern window"],a:"The lantern glowed in the window."}
]);

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"addition within 20",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Addition can solve putting-together problems.",practice:"Ava found 6 feathers. Luna found 5 more.",q:"How many feathers altogether?",c:["11","10","12"],a:"11"},
 {unit:"G1-MATH-FACTS",skill:"subtraction within 20",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Subtraction can solve taking-away problems.",practice:"There were 14 berries. A bird ate 6.",q:"How many berries are left?",c:["8","7","9"],a:"8"},
 {unit:"G1-MATH-PLACE",skill:"tens and ones",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Tens and ones help build numbers.",practice:"A treasure bag has 3 tens and 9 ones.",q:"What number is that?",c:["39","93","12"],a:"39"},
 {unit:"G1-MATH-MEASURE",skill:"picture graphs",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Picture graphs show data.",practice:"The graph shows 4 frogs and 7 birds.",q:"Which has more?",c:["birds","frogs","same"],a:"birds"}
]);

LR_addLessons("Luna","Science",[
 {unit:"G1-SCI-LIFE",skill:"habitats",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: A habitat is where a living thing lives.",practice:"A frog lives near ponds and wet places.",q:"Which is a frog habitat?",c:["pond","desert cave only","book shelf"],a:"pond"},
 {unit:"G1-SCI-EARTH",skill:"daily observation",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Scientists observe and describe.",practice:"The sky is gray and rain is falling.",q:"What weather is being observed?",c:["rainy","sunny","snowy"],a:"rainy"}
]);

LR_addLessons("Luna","History",[
 {unit:"G1-SS-COMMUNITY",skill:"goods",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Goods are things people can use or buy.",practice:"Bread, books, and blankets are goods.",q:"Which is a good?",c:["book","haircut","singing"],a:"book"}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-RATIO",skill:"unit rates",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Unit rates compare to one unit.",practice:"A cart travels 180 miles in 3 hours.",q:"What is the unit rate?",c:["60 miles per hour","183 miles per hour","30 miles per hour"],a:"60 miles per hour"},
 {unit:"G7-MATH-RATIO",skill:"percent",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Percent problems can be solved by finding the percent of the original.",practice:"A 20% discount on 90 means 0.20 × 90.",q:"How much is 20% of 90?",c:["18","20","45"],a:"18"},
 {unit:"G7-MATH-INT",skill:"integer addition",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Integers can represent gains and losses.",practice:"A team loses 7 yards, then gains 3 yards.",q:"What is the total change?",c:["-4","10","4"],a:"-4"},
 {unit:"G7-MATH-EQ",skill:"two-step equations",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Equations can represent unknowns.",practice:"A number multiplied by 4, then increased by 6, equals 30.",q:"Which equation matches?",c:["4x + 6 = 30","x + 4 = 30","6x + 4 = 30"],a:"4x + 6 = 30"},
 {unit:"G7-MATH-GEO-DATA",skill:"probability",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Probability compares outcomes.",practice:"A bag has 3 red stones and 2 blue stones.",q:"What is the probability of picking blue?",c:["2 out of 5","3 out of 5","2 out of 3"],a:"2 out of 5"}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-WRITING",skill:"CER",difficulty:"application",mode:"written-response-prep",teach:"Applied Practice: A CER response needs claim, evidence, and reasoning.",practice:"Claim: The character is brave. Evidence: She enters the cave to help someone.",q:"What should come next?",c:["reasoning explaining why this shows bravery","a random new topic","the title only"],a:"reasoning explaining why this shows bravery"},
 {unit:"G7-ELA-EVIDENCE",skill:"inference",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Inference combines clues with reasoning.",practice:"The character checks the lock twice and whispers, 'I hope nobody heard that.'",q:"What can you infer?",c:["The character is nervous.","The character is sleeping.","The character is eating."],a:"The character is nervous."},
 {unit:"G7-ELA-EVIDENCE",skill:"theme",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Theme grows from what characters learn.",practice:"A character keeps practicing and finally succeeds.",q:"Which theme fits best?",c:["Practice and persistence matter.","Food tastes good.","Maps show places."],a:"Practice and persistence matter."}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-LIFE",skill:"food webs",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Energy moves through food webs.",practice:"Grass is eaten by a rabbit. The rabbit is eaten by a fox.",q:"Which organism is the producer?",c:["grass","rabbit","fox"],a:"grass"},
 {unit:"G7-SCI-EARTH",skill:"weathering",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Weathering breaks rock into smaller pieces.",practice:"Water freezes in cracks and breaks rock apart.",q:"This is an example of...",c:["weathering","deposition","condensation"],a:"weathering"},
 {unit:"G7-SCI-PHYSICAL",skill:"variables",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: The independent variable is what is changed.",practice:"A student changes the amount of sunlight a plant gets.",q:"What is the independent variable?",c:["amount of sunlight","plant height","kind of pot"],a:"amount of sunlight"}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"cause and effect",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Cause explains why something happened; effect tells what happened because of it.",practice:"A storm washed out the bridge, so travelers used a longer road.",q:"What was the cause?",c:["storm washed out the bridge","travelers used a longer road","the road was long"],a:"storm washed out the bridge"},
 {unit:"G7-SS-CIVICS",skill:"public services",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Taxes can help pay for public services.",practice:"Road repair and emergency services can be public services.",q:"Which is a public service?",c:["road repair","private toy collection","personal snack"],a:"road repair"},
 {unit:"G7-SS-ECON",skill:"trade",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Trade is exchanging goods or services.",practice:"A farmer sells grain and buys tools.",q:"This is an example of...",c:["trade","erosion","theme"],a:"trade"}
]);

LR_addLessons("Ava","Reading",[
 {unit:"G7-ELA-EVIDENCE",skill:"central idea",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Central idea is the main point of a nonfiction text.",practice:"A passage explains how water moves through evaporation, condensation, and precipitation.",q:"What is the central idea?",c:["how the water cycle works","why rabbits hop","how to solve equations"],a:"how the water cycle works"}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-EQ",skill:"variables both sides",difficulty:"application",mode:"word-problem",teach:"Applied Practice: Some situations create equations with variables on both sides.",practice:"Two plans cost 5x + 20 and 3x + 40.",q:"Which equation shows when the plans cost the same?",c:["5x + 20 = 3x + 40","5x = 40","20 = 3x"],a:"5x + 20 = 3x + 40"},
 {unit:"G8-MATH-FUNC",skill:"slope",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Slope is rate of change.",practice:"A line goes from (0,2) to (4,14).",q:"What is the slope?",c:["3","12","4"],a:"3"},
 {unit:"G8-MATH-FUNC",skill:"systems",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: A system solution satisfies both equations.",practice:"If y = x + 5 and y = 12, then x must be 7.",q:"What is x?",c:["7","12","5"],a:"7"},
 {unit:"G8-MATH-GEO-DATA",skill:"Pythagorean theorem",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Use a² + b² = c² for right triangles.",practice:"A right triangle has legs 8 and 15.",q:"Which is the hypotenuse?",c:["17","23","7"],a:"17"},
 {unit:"G8-MATH-NUMBERS",skill:"scientific notation",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Scientific notation helps write large numbers.",practice:"The number 430,000 can be written as 4.3 × 10^5.",q:"430,000 begins with...",c:["4.3 × 10","43 × 10","0.43 × 10"],a:"4.3 × 10"}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"reasoning",difficulty:"application",mode:"written-response-prep",teach:"Applied Practice: Reasoning explains how evidence supports the claim.",practice:"Claim: The law should be changed. Evidence: Many citizens report the rule causes confusion.",q:"What should reasoning explain?",c:["how the evidence supports the claim","what color the page is","only who wrote it"],a:"how the evidence supports the claim"},
 {unit:"G8-ELA-ARG",skill:"counterclaim",difficulty:"application",mode:"written-response-prep",teach:"Applied Practice: A counterclaim gives another side of the argument.",practice:"Claim: The gate should remain closed. Another side says it should open.",q:"The other side is the...",c:["counterclaim","citation","setting"],a:"counterclaim"},
 {unit:"G8-ELA-RESEARCH",skill:"source reliability",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Reliable sources can be checked for author, evidence, date, and purpose.",practice:"A page has no author, no date, and no sources.",q:"This source is probably...",c:["weak","strong","automatically perfect"],a:"weak"},
 {unit:"G8-ELA-READING",skill:"analysis",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Analysis explains meaning, not just what happened.",practice:"The locked gate may show separation or unfinished work.",q:"That kind of explanation is...",c:["analysis","copying","counting"],a:"analysis"}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-MATTER",skill:"physical change",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: A physical change does not make a new substance.",practice:"Breaking ice into pieces still leaves ice.",q:"Breaking ice is a...",c:["physical change","chemical change","new compound"],a:"physical change"},
 {unit:"G8-SCI-FORCE",skill:"Newton's laws",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Greater force can cause greater acceleration if mass stays the same.",practice:"Two carts have the same mass. One gets a stronger push.",q:"Which cart accelerates more?",c:["the cart with stronger push","the cart with weaker push","neither always"],a:"the cart with stronger push"},
 {unit:"G8-SCI-WAVES-EARTH",skill:"rock cycle",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Heat and pressure can change rock.",practice:"Sedimentary rock buried deep can become metamorphic rock.",q:"Heat and pressure can form...",c:["metamorphic rock","a thesis","a market"],a:"metamorphic rock"}
]);

LR_addLessons("Michael","History",[
 {unit:"G8-SS-CIVICS",skill:"checks and balances",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Checks and balances prevent one branch from having too much power.",practice:"A court can review whether a law follows the Constitution.",q:"This is connected to...",c:["checks and balances","erosion","food webs"],a:"checks and balances"},
 {unit:"G8-SS-ECON",skill:"supply and demand",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Supply and demand can affect prices.",practice:"Demand rises while supply stays low.",q:"Prices will often...",c:["rise","always fall","vanish"],a:"rise"},
 {unit:"G8-SS-HISTORICAL",skill:"source perspective",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Source perspective affects how events are described.",practice:"A merchant and a farmer may describe the same tax differently.",q:"This shows different...",c:["perspectives","velocities","equations"],a:"perspectives"}
]);

LR_addLessons("Michael","Civics",[
 {unit:"G8-SS-CIVICS",skill:"civic virtue",difficulty:"application",mode:"applied-practice",teach:"Applied Practice: Civic virtue means acting for the good of the community.",practice:"A citizen helps solve a town problem.",q:"This shows...",c:["civic virtue","inflation","chemical change"],a:"civic virtue"}
]);
