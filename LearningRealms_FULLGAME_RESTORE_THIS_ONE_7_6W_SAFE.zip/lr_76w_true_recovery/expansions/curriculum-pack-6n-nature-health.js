// Curriculum Pack 6N Nature & Health
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Nature",[
{teach:"Plants need water and sunlight.",q:"Plants need...",c:["water and sunlight","sand only","music"],a:"water and sunlight"},
{teach:"Animals live in habitats.",q:"Animal homes are...",c:["habitats","equations","chapters"],a:"habitats"},
{teach:"Weather changes.",q:"Weather can...",c:["change","freeze forever","stop"],a:"change"},
{teach:"Healthy foods help bodies.",q:"Healthy foods help...",c:["bodies","rocks","cars"],a:"bodies"}
]);

LR_addLessons("Ava","Nature",[
{teach:"Ecosystems contain living and nonliving parts.",q:"Ecosystems contain...",c:["living and nonliving things","only animals","only plants"],a:"living and nonliving things"},
{teach:"Food chains transfer energy.",q:"Food chains move...",c:["energy","clouds","maps"],a:"energy"},
{teach:"Nutrition supports growth.",q:"Nutrition helps...",c:["growth","weather","geometry"],a:"growth"},
{teach:"Safety helps prevent injuries.",q:"Safety helps prevent...",c:["injuries","sunsets","storms"],a:"injuries"}
]);

LR_addLessons("Michael","Nature",[
{teach:"Body systems work together.",q:"Body systems can...",c:["work together","ignore each other","stop"],a:"work together"},
{teach:"Habitats affect organisms.",q:"Habitats affect...",c:["organisms","equations","fonts"],a:"organisms"},
{teach:"Weather systems interact.",q:"Weather systems...",c:["interact","sleep","freeze"],a:"interact"},
{teach:"Conservation protects resources.",q:"Conservation helps...",c:["protect resources","erase history","move mountains"],a:"protect resources"}
]);
})();