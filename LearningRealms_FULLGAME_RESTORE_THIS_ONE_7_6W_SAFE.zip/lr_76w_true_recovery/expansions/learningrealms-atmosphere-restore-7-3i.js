/* LearningRealms Atmosphere Restore 7.3I
   Goal: recover the living RPG feel without rewriting lessons or core mechanics.
   - Keeps 7.3B course placement: Depression + Wild West under History, Bible separate.
   - Removes old cleanup poison from the base app.js before this file is loaded.
   - Adds a consistent adventure frame, richer player banner, grouped icon atlas, and fantasy-window styling.
*/
(function(){
  'use strict';
  if(window.__LR73I_ATMOSPHERE_RESTORE__) return;
  window.__LR73I_ATMOSPHERE_RESTORE__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v == null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    var args = Array.prototype.slice.call(arguments,1);
    try{ if(has(fn)) return window[fn].apply(window,args); }catch(e){ console.warn('LR73I call failed', fn, e); }
    return false;
  }
  function getState(){
    try{ if(window.state) return window.state; }catch(e){}
    try{ if(typeof state !== 'undefined') return state; }catch(e){}
    return {};
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined') return ROOMS; }catch(e){}
    return {};
  }
  function currentRoom(){
    var s = getState();
    var rooms = getRooms();
    var id = (s && s.loc) || 'crossroads';
    return rooms[id] || rooms.crossroads || {};
  }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    try{ var sel = byId('studentSelect'); if(sel && sel.value) return sel.value; }catch(e){}
    try{ return localStorage.getItem('lrActiveChild') || 'Scholar'; }catch(e){}
    return 'Scholar';
  }
  function avatarFor(name){
    name = String(name || '').toLowerCase();
    if(name.indexOf('luna') >= 0) return '🌙';
    if(name.indexOf('ava') >= 0) return '🌺';
    if(name.indexOf('michael') >= 0) return '🛡️';
    return '🧭';
  }
  function roomLine(){
    var r = currentRoom();
    var parts = [];
    if(r.title) parts.push(r.title);
    if(r.zone) parts.push(r.zone);
    if(r.subject) parts.push(r.subject);
    return parts.join(' · ') || 'Crossroads · Adventure ready';
  }
  function statLine(){
    var s = getState();
    var bits = [];
    if(typeof s.room !== 'undefined') bits.push('Room ' + (s.room || 1));
    if(typeof s.sparks !== 'undefined') bits.push((s.sparks || 0) + ' Sparks');
    if(typeof s.streak !== 'undefined') bits.push('Streak ' + (s.streak || 0));
    return bits.join(' · ') || 'Ready';
  }

  function ensureMount(){
    try{ document.body.classList.add('lr73iAtmosphere','lrDynamicAdventureMode','lr68DynamicShell'); document.body.classList.remove('homeMode'); }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var first = document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; }
      if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen lr73iScreen';
      if(first && first.firstChild) first.insertBefore(mount, first.firstChild);
      else (first || document.body).appendChild(mount);
    }
    mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none';
    return mount;
  }

  var SECTIONS = [
    {
      title:'Core Kingdoms', eyebrow:'Daily learning roads', tone:'core',
      cards:[
        ['📖','Reading Woods','Story clues, vocabulary, proof from the text, and careful reading.','lr68bOpenLearningTrails','core'],
        ['🔢','Math Iron Hills','Numbers, operations, patterns, models, and step-by-step problem solving.','lr68bOpenLearningTrails','core'],
        ['🔬','Science Marsh','Observation, evidence, weather, nature, matter, and safe experiments.','lr68bOpenLearningTrails','stem'],
        ['✒️','Writing Guild','Sentences, explanations, copywork, records, and organized ideas.','lr68bOpenLearningTrails','core']
      ]
    },
    {
      title:'History and World Wing', eyebrow:'Maps, records, people, places', tone:'history',
      cards:[
        ['🏛️','History Archive','Timelines, source clues, artifacts, cause and effect, and real-world context.','lr68bOpenLearningTrails','world'],
        ['🏚️','Great Depression Street','A kid-safe master course on the 1930s, daily life, money systems, and resilience.','openGreatDepressionCourse'],
        ['🤠','Wild West Frontier Trail','Frontier life, geography, railroads, homesteads, shops, evidence, and myth checking.','openWildWestCourse'],
        ['🗺️','Geography Mapmakers','Landforms, routes, regions, maps, directions, and how places connect.','lr68bOpenLearningTrails','world'],
        ['⚖️','Civics Citadel','Rules, responsibility, service, fair decisions, and community choices.','lr68bOpenLearningTrails','world'],
        ['🏪','Economics Merchant Row','Needs, wants, value, trade, saving, budgets, and shopkeeper thinking.','lr68bOpenLearningTrails','featured']
      ]
    },
    {
      title:'Special Realms', eyebrow:'Big themed adventures', tone:'special',
      cards:[
        ['⛪','Bible History Pilgrim Road','A separate, respectful Catholic-friendly Bible History realm with saints, angels, Scripture, sacraments, and artifacts.','openBibleHistoryCourse'],
        ['🏺','Bible Artifact Hall','Tasteful study artifacts earned through Bible History lessons.','openBibleHistoryArtifacts73B'],
        ['⚓','Shipwreck Cove','Ships, navigation, weather, rescue, mystery, pirates, legends, and maritime evidence.','shipwreckGuidedZoneOpen'],
        ['🛠️','Inventions Hall','Inventors, prototypes, redesign, failures, engineering choices, and safety lessons.','openInventionsDeepCourse'],
        ['🎨','Creative Studio','Drawing, painting, crafts, theater, music, storytelling, and gallery habits.','openCreativeStudioCourse'],
        ['🌿','Nature and Health Trails','Wildroot Preserve, Hearthwell Clinic, habits, body basics, and outdoor observation.','lr68bOpenLearningTrails','stem']
      ]
    }
  ];

  function runCard(fn,arg){
    if(fn === 'lr68bOpenLearningTrails' && has('lr68bOpenLearningTrails')) return window.lr68bOpenLearningTrails(arg || 'featured');
    if(has(fn)) return window[fn](arg);
    if(fn === 'openBibleHistoryCourse' && has('openBibleHistoryTrail')) return window.openBibleHistoryTrail();
    if(fn === 'openGreatDepressionCourse' && has('openGreatDepressionTrail')) return window.openGreatDepressionTrail();
    if(fn === 'openWildWestCourse' && has('openWildWestTrail')) return window.openWildWestTrail();
    if(has('lr68bOpenLearningTrails')) return window.lr68bOpenLearningTrails('featured');
    return false;
  }
  window.lr73iRunCard = runCard;

  function cardHtml(card, idx){
    var icon=card[0], title=card[1], body=card[2], fn=card[3], arg=card[4] || '';
    return '<button type="button" class="lr73iRealmCard" onclick="lr73iRunCard(\''+esc(fn)+'\',\''+esc(arg)+'\')">' +
      '<span class="lr73iCardIcon">'+esc(icon)+'</span>' +
      '<span class="lr73iCardText"><b>'+esc(title)+'</b><small>Realm gate '+(idx+1)+'</small><p>'+esc(body)+'</p></span>' +
      '<span class="lr73iCardArrow">›</span>' +
    '</button>';
  }

  function openAtlas(){
    var mount = ensureMount();
    var html = '';
    html += '<section class="lr73iMapHero">' +
      '<div class="lr73iMapKicker"><span>Adventure Atlas</span><span>'+esc(activeName())+' · '+esc(statLine())+'</span></div>' +
      '<div class="lr73iMapTitle"><span class="lr73iBigSeal">'+esc(avatarFor(activeName()))+'</span><div><h1>Choose a realm from the map table.</h1><p>This is meant to feel like a game hub again: big realms, clear wings, icon gates, and course roads placed where they belong.</p></div></div>' +
    '</section>';
    SECTIONS.forEach(function(sec){
      html += '<section class="lr73iRealmSection lr73iTone_'+esc(sec.tone)+'"><div class="lr73iSectionHead"><small>'+esc(sec.eyebrow)+'</small><h2>'+esc(sec.title)+'</h2></div><div class="lr73iRealmGrid">';
      sec.cards.forEach(function(c,i){ html += cardHtml(c,i); });
      html += '</div></section>';
    });
    html += '<div class="lr73iFooterBar"><button type="button" onclick="lr68Render&&lr68Render()">↩ Return to scene</button><button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'featured\')">Go Learn trails</button><button type="button" onclick="lr68OpenHome&&lr68OpenHome()">Home</button><button type="button" onclick="openWorldAtlas&&openWorldAtlas()">World Atlas</button></div>';
    mount.innerHTML = html;
    installHeader();
    return false;
  }
  window.lr73iOpenAtlas = openAtlas;

  function installHeader(){
    try{
      var header = document.querySelector('.compactHeader');
      if(!header) return;
      header.classList.add('lr73iHeader');
      var name = activeName();
      var html = '<div class="lr73iPlayerRune">'+esc(avatarFor(name))+'</div>' +
        '<div class="lr73iBrand"><b>LearningRealms</b><small>'+esc(roomLine())+'</small></div>' +
        '<div class="lr73iPlayerPlate"><span>'+esc(name)+'</span><small>'+esc(statLine())+'</small></div>' +
        '<nav class="lr73iTopNav">' +
          '<button type="button" onclick="lr68Render&&lr68Render()">Scene</button>' +
          '<button type="button" onclick="lr73iOpenAtlas()">Realm Map</button>' +
          '<button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'world\')">History Wing</button>' +
          '<button type="button" onclick="openBibleHistoryCourse&&openBibleHistoryCourse()">Bible Road</button>' +
          '<button type="button" onclick="lr68OpenHome&&lr68OpenHome()">Home</button>' +
        '</nav>';
      if(header.innerHTML !== html) header.innerHTML = html;
    }catch(e){ console.warn('LR73I header failed', e); }
  }

  function labelPanels(){
    try{
      var mainCard = document.querySelector('.main > .card:first-child');
      if(mainCard && !mainCard.querySelector('.lr73iWindowLabel')){
        mainCard.insertAdjacentHTML('afterbegin','<div class="lr73iWindowLabel">Realm Scene Window</div>');
      }
      var right = document.querySelector('.rightSidebar .card');
      if(right && !right.querySelector('.lr73iWindowLabel')) right.insertAdjacentHTML('afterbegin','<div class="lr73iWindowLabel">Records Ledger</div>');
      var player = document.querySelector('.playerSidebar');
      if(player && !player.querySelector('.lr73iWindowLabel')) player.insertAdjacentHTML('afterbegin','<div class="lr73iWindowLabel">Player Sheet</div>');
    }catch(e){}
  }

  function cleanOldButtonDamage(){
    try{
      document.querySelectorAll('.lrNukeOldButton').forEach(function(btn){
        btn.classList.remove('lrNukeOldButton');
        if(btn.style && btn.style.display === 'none') btn.style.display = '';
      });
      var clean = byId('lrCleanGameShell');
      if(clean) clean.remove();
    }catch(e){}
  }

  function decorateLearningTrails(){
    try{
      var hero = document.querySelector('#lrDynamicAdventureScreen .lr68bHero');
      if(hero && !hero.querySelector('.lr73iHeroSeal')){
        hero.insertAdjacentHTML('afterbegin','<span class="lr73iHeroSeal">🧭</span>');
      }
      document.querySelectorAll('.lr68bTrailCard').forEach(function(card){
        if(card.querySelector('.lr73iMiniGem')) return;
        var text = (card.textContent || '').toLowerCase();
        var gem = '✦';
        if(text.indexOf('history') >= 0 || text.indexOf('wild west') >= 0 || text.indexOf('depression') >= 0) gem = '🏛️';
        else if(text.indexOf('bible') >= 0 || text.indexOf('pilgrim') >= 0) gem = '⛪';
        else if(text.indexOf('shipwreck') >= 0) gem = '⚓';
        else if(text.indexOf('creative') >= 0 || text.indexOf('music') >= 0 || text.indexOf('art') >= 0) gem = '🎨';
        else if(text.indexOf('math') >= 0 || text.indexOf('number') >= 0) gem = '🔢';
        else if(text.indexOf('science') >= 0 || text.indexOf('nature') >= 0 || text.indexOf('health') >= 0) gem = '🔬';
        else if(text.indexOf('reading') >= 0 || text.indexOf('story') >= 0) gem = '📖';
        card.insertAdjacentHTML('afterbegin','<span class="lr73iMiniGem">'+gem+'</span>');
      });
    }catch(e){}
  }

  function wrapLearningOpen(){
    try{
      var old = window.lr68bOpenLearningTrails;
      if(typeof old === 'function' && !old.__lr73iWrapped){
        var repl = function(section){
          var out = old.apply(this, arguments);
          [40,140,360,720].forEach(function(ms){ setTimeout(function(){ installHeader(); labelPanels(); decorateLearningTrails(); }, ms); });
          return out;
        };
        repl.__lr73iWrapped = true;
        repl.__old = old;
        window.lr68bOpenLearningTrails = repl;
        try{ lr68bOpenLearningTrails = repl; }catch(e){}
      }
      var oldRender = window.lr68Render;
      if(typeof oldRender === 'function' && !oldRender.__lr73iWrapped){
        var r2 = function(){
          var out = oldRender.apply(this, arguments);
          [30,160,400].forEach(function(ms){ setTimeout(function(){ installHeader(); labelPanels(); decorateLearningTrails(); }, ms); });
          return out;
        };
        r2.__lr73iWrapped = true;
        r2.__old = oldRender;
        window.lr68Render = r2;
        try{ lr68Render = r2; }catch(e){}
      }
    }catch(e){}
  }

  function styles(){
    if(byId('lr73iAtmosphereStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr73iAtmosphereStyles';
    st.textContent = `
      :root{--lr73i-ink:#271d10;--lr73i-gold:#e9c46a;--lr73i-amber:#ffe6a2;--lr73i-deep:#10231f;--lr73i-green:#1f4a3f;--lr73i-blue:#25375f;--lr73i-purple:#34255a;--lr73i-paper:#fff7dc;--lr73i-soft:#f4e5bd;}
      body.lr73iAtmosphere{min-height:100vh;background:radial-gradient(circle at 7% 0%,rgba(255,217,128,.22),transparent 31%),radial-gradient(circle at 92% 5%,rgba(92,168,139,.18),transparent 32%),linear-gradient(180deg,#06110f 0%,#0d241f 46%,#071512 100%)!important;color:#fff1c7;}
      body.lr73iAtmosphere:before{content:'';position:fixed;inset:0;pointer-events:none;z-index:-1;background:linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(180deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:38px 38px;mask-image:radial-gradient(circle at center,black,transparent 82%);}
      body.lr73iAtmosphere .shell{max-width:1540px;margin:0 auto;padding:16px 18px 24px;background:linear-gradient(180deg,rgba(255,236,173,.07),rgba(255,255,255,.025));border-left:1px solid rgba(255,224,147,.16);border-right:1px solid rgba(255,224,147,.16);box-shadow:0 0 80px rgba(0,0,0,.35);}
      .lr73iHeader{display:grid!important;grid-template-columns:auto minmax(180px,1fr) auto auto;align-items:center;gap:13px;margin:0 0 14px!important;padding:12px 14px!important;border-radius:24px!important;border:2px solid rgba(255,224,150,.28)!important;background:linear-gradient(135deg,rgba(20,49,41,.98),rgba(9,24,22,.98) 54%,rgba(51,38,22,.98))!important;box-shadow:0 18px 36px rgba(0,0,0,.32),inset 0 1px 0 rgba(255,255,255,.08)!important;min-height:74px;}
      .lr73iPlayerRune{width:58px;height:58px;display:grid;place-items:center;border-radius:19px;background:radial-gradient(circle at 30% 20%,#fff4b8,#e6b84d 48%,#6d4a13);color:#211506;font-size:2rem;box-shadow:0 10px 22px rgba(0,0,0,.35),inset 0 0 0 2px rgba(255,255,255,.22);}
      .lr73iBrand b{display:block;color:#fff5c8;font-size:1.42rem;letter-spacing:.02em}.lr73iBrand small{display:block;color:#cde8d9;font-weight:850;margin-top:3px;line-height:1.2}.lr73iPlayerPlate{min-width:160px;border:1px solid rgba(255,231,161,.26);border-radius:18px;padding:9px 12px;background:rgba(255,255,255,.055)}.lr73iPlayerPlate span{display:block;color:#fff7da;font-weight:1000}.lr73iPlayerPlate small{display:block;color:#cfe6da;font-weight:850;font-size:.78rem;margin-top:2px}.lr73iTopNav{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:7px}.lr73iTopNav button,.lr73iFooterBar button{border:1px solid rgba(255,229,151,.38);border-radius:999px;background:linear-gradient(180deg,#fff7d7,#d9a948);color:#24190b;font-weight:1000;padding:9px 12px;box-shadow:0 6px 12px rgba(0,0,0,.23);cursor:pointer}.lr73iTopNav button:hover,.lr73iFooterBar button:hover,.lr73iRealmCard:hover{transform:translateY(-1px);filter:brightness(1.04)}
      body.lr73iAtmosphere main{gap:15px!important}.lr73iWindowLabel{display:inline-block;margin:0 0 8px;padding:5px 10px;border-radius:999px;background:rgba(255,226,143,.14);border:1px solid rgba(255,226,143,.25);color:#ffe9ad;font-weight:1000;text-transform:uppercase;letter-spacing:.09em;font-size:.68rem}.card,.rightInfoCard,.playerSidebar{border-radius:24px!important;border:1px solid rgba(255,226,143,.24)!important;background:linear-gradient(180deg,rgba(20,47,41,.95),rgba(8,23,20,.96))!important;color:#fff0c2!important;box-shadow:0 16px 32px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.07)!important}.card h2,.playerSidebar h2,.rightInfoCard h2{color:#fff5c8!important}.card p,.card div,.playerSidebar,.rightInfoCard{color:#f3e6bd}select,input,textarea{border-radius:12px;border:1px solid rgba(255,228,151,.26);background:#fff9df;color:#23190b;padding:7px 8px;font-weight:800}button{font-family:inherit}.card button:not(.lr68ChoiceCard):not(.lr68bTrailCard):not(.lr73iRealmCard):not(.lr73bBibleCard),.playerSidebar button,.rightSidebar button{border:1px solid rgba(255,228,151,.32);border-radius:14px;background:linear-gradient(180deg,#fff6d2,#d6a84e);color:#23180b;font-weight:950;padding:9px 11px;cursor:pointer;box-shadow:0 6px 12px rgba(0,0,0,.18)}
      #lrDynamicAdventureScreen{position:relative!important;border-radius:30px!important;overflow:hidden!important;border:2px solid rgba(255,227,151,.28)!important;background:radial-gradient(circle at 16% 0%,rgba(255,213,116,.18),transparent 32%),radial-gradient(circle at 92% 4%,rgba(104,190,152,.16),transparent 34%),linear-gradient(180deg,rgba(17,48,41,.99),rgba(7,20,18,.99))!important;box-shadow:0 24px 54px rgba(0,0,0,.38),inset 0 0 0 1px rgba(255,255,255,.055)!important;}
      #lrDynamicAdventureScreen:after{content:'';position:absolute;left:16px;right:16px;bottom:12px;height:1px;background:linear-gradient(90deg,transparent,rgba(255,229,151,.35),transparent);pointer-events:none}.lr68SceneHero,.lr67Hero,.lr68bHero,.lr73iMapHero{position:relative;overflow:hidden;border-radius:26px 26px 18px 18px!important;margin:0!important;padding:28px 30px 24px!important;background:linear-gradient(135deg,rgba(42,91,72,.95),rgba(12,33,31,.98) 52%,rgba(64,47,27,.95))!important;border-bottom:1px solid rgba(255,225,148,.22)!important;color:#fff2c8!important}.lr68SceneHero h1,.lr67Hero h1,.lr68bHero h1,.lr73iMapHero h1{color:#fff8d5!important;text-shadow:0 2px 0 rgba(0,0,0,.18);letter-spacing:.01em}.lr68SceneText,.lr67SceneText{border-radius:20px;background:rgba(255,251,222,.08);border:1px solid rgba(255,226,147,.18);padding:15px 16px!important;color:#fff4cf!important}.lr68Meta span,.lr68HeroTop span,.lr68bHeroTop span{border-radius:999px;background:rgba(255,240,184,.13)!important;border:1px solid rgba(255,225,151,.22);color:#ffe9ad!important;padding:6px 9px;font-weight:950}.lr68ChoicePanel,.lr68ActionStrip,.lr68bTrailGrid{padding:17px!important;background:linear-gradient(180deg,rgba(255,246,214,.08),rgba(255,255,255,.035))!important}.lr68PanelTitle span{color:#ffeab2!important}.lr68PanelTitle small{color:#cfe5d8!important}.lr68ChoiceCard,.lr68bTrailCard{position:relative;overflow:hidden;border-radius:22px!important;border:1px solid rgba(255,226,143,.22)!important;background:linear-gradient(135deg,#fff7df,#ead29c 60%,#d7ecdc)!important;color:#2d2111!important;box-shadow:0 10px 20px rgba(0,0,0,.22)!important;text-align:left!important}.lr68ChoiceCard b,.lr68bTrailCard b{color:#281b0c!important}.lr68ChoiceCard small,.lr68bTrailCard small{color:#6d551f!important;font-weight:1000!important}.lr68ChoiceCard p,.lr68bTrailCard p{color:#4b3e2b!important;font-weight:760!important}.lr68ChoiceNumber,.lr68bTrailArrow{background:#243e36!important;color:#fff5c5!important}.lr73iMiniGem{position:absolute;right:13px;top:12px;font-size:1.4rem;filter:drop-shadow(0 2px 1px rgba(0,0,0,.22));}.lr68bTrailCard .lr68bTrailText{padding-right:38px!important}.lr73iHeroSeal{position:absolute;right:22px;bottom:12px;font-size:4.6rem;opacity:.13;filter:grayscale(.15)}.lr68bTabs{padding:13px 16px 4px!important;gap:9px!important;background:rgba(0,0,0,.12)!important}.lr68bTabs button{border-radius:18px!important;background:linear-gradient(180deg,#fff7da,#ead39a)!important;color:#251908!important;border:1px solid rgba(255,232,162,.3)!important;box-shadow:0 7px 14px rgba(0,0,0,.18)!important}.lr68bTabs button.active{background:linear-gradient(180deg,#ffeaa5,#bd7e2d)!important;color:#1d1206!important}.lr68BottomBar,.lr68bFooter,.lr73iFooterBar{display:flex;flex-wrap:wrap;gap:10px;padding:15px 18px!important;background:linear-gradient(180deg,rgba(8,19,17,.82),rgba(3,10,9,.92))!important;border-top:1px solid rgba(255,225,144,.18)!important}.lr68BottomBar button,.lr68bFooter button{border:1px solid rgba(255,228,151,.32)!important;border-radius:999px!important;background:linear-gradient(180deg,#fff6d2,#d6a84e)!important;color:#23180b!important;font-weight:1000!important;box-shadow:0 7px 14px rgba(0,0,0,.24)!important}
      .lr73iMapKicker{display:flex;justify-content:space-between;gap:12px;color:#ffe7a5;font-weight:1000;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}.lr73iMapTitle{display:grid;grid-template-columns:auto 1fr;gap:18px;align-items:center;margin-top:14px}.lr73iBigSeal{width:84px;height:84px;border-radius:26px;display:grid;place-items:center;background:radial-gradient(circle at 35% 24%,#fff6c8,#e4b34f 48%,#5d3b10);font-size:3rem;box-shadow:0 18px 36px rgba(0,0,0,.35),inset 0 0 0 2px rgba(255,255,255,.18)}.lr73iMapHero p{max-width:920px;color:#f4e7bf!important;font-weight:760;line-height:1.5}.lr73iRealmSection{margin:16px;padding:17px;border-radius:25px;border:1px solid rgba(255,228,151,.22);box-shadow:0 16px 32px rgba(0,0,0,.20),inset 0 1px 0 rgba(255,255,255,.055)}.lr73iTone_core{background:linear-gradient(135deg,rgba(33,75,64,.94),rgba(12,29,27,.96))}.lr73iTone_history{background:linear-gradient(135deg,rgba(91,65,30,.94),rgba(37,28,18,.97))}.lr73iTone_special{background:linear-gradient(135deg,rgba(47,39,91,.94),rgba(18,18,41,.97))}.lr73iSectionHead{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin-bottom:12px}.lr73iSectionHead small{color:#ffe6a6;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.lr73iSectionHead h2{margin:0;color:#fff5ca}.lr73iRealmGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(285px,1fr));gap:12px}.lr73iRealmCard{display:grid;grid-template-columns:auto 1fr auto;gap:13px;align-items:start;text-align:left;min-height:148px;padding:14px;border-radius:22px;border:1px solid rgba(72,51,18,.18);background:linear-gradient(135deg,#fff9e8,#ead49c 56%,#e8f2e6);color:#2c2110;box-shadow:0 12px 22px rgba(0,0,0,.22);cursor:pointer;transition:.15s ease}.lr73iCardIcon{width:48px;height:48px;border-radius:16px;background:linear-gradient(180deg,#fff7cf,#d6a542);display:grid;place-items:center;font-size:1.75rem;box-shadow:inset 0 0 0 1px rgba(255,255,255,.35)}.lr73iCardText b{display:block;font-size:1.04rem;color:#241707}.lr73iCardText small{display:block;margin-top:3px;color:#7a5a18;font-weight:1000;text-transform:uppercase;letter-spacing:.05em;font-size:.68rem}.lr73iCardText p{margin:8px 0 0;color:#4a3f2d;font-weight:760;line-height:1.36}.lr73iCardArrow{font-size:2rem;font-weight:1000;color:#315345;line-height:1}.lr73iFooterBar{border-radius:0 0 26px 26px!important;margin:0 16px 16px!important}
      .lrPopupWindow,.popup,.modal,.locked-card{border-radius:26px!important;border:2px solid rgba(255,225,144,.34)!important;background:linear-gradient(180deg,#fff8df,#ead9ab)!important;color:#24180b!important;box-shadow:0 28px 70px rgba(0,0,0,.45)!important}.lrPopupHeader{background:linear-gradient(135deg,#17382f,#0a1d1a)!important;color:#fff2c2!important;border-radius:22px 22px 0 0!important;border-bottom:1px solid rgba(255,227,151,.22)!important}.lrPopupBody{background:linear-gradient(180deg,#fff9e6,#f1e2bd)!important;color:#271d10!important}.gdpShell,.wwShell,.bhShell{border-radius:24px!important;overflow:hidden!important;box-shadow:0 20px 40px rgba(0,0,0,.18)!important}.gdpHero,.wwHero,.bhHero{border-radius:22px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.10)!important}.gdpGrid,.wwGrid,.bhGrid,.bhTopicGrid{gap:13px!important}.gdpTopic,.wwTopic,.bhTopic,.gdpCard,.wwCard,.bhCard{border-radius:20px!important;box-shadow:0 9px 18px rgba(0,0,0,.13)!important}.lr73bHistoryShelf{box-shadow:0 14px 28px rgba(0,0,0,.22)!important;border-radius:25px!important}.lr73bIntegratedCard{border-radius:22px!important;box-shadow:0 12px 24px rgba(0,0,0,.18)!important}.lr73bBibleHero{border-radius:25px 25px 0 0!important}.lr73bBibleGrid,.lr73bArtifactGrid{padding:18px!important}.lr73bBibleCard,.lr73bArtifact{border-radius:20px!important;box-shadow:0 10px 20px rgba(0,0,0,.13)!important}
      @media(max-width:980px){.lr73iHeader{grid-template-columns:auto 1fr;}.lr73iPlayerPlate,.lr73iTopNav{grid-column:1 / -1}.lr73iTopNav{justify-content:flex-start}.lr73iMapTitle{grid-template-columns:1fr}.lr73iBigSeal{width:70px;height:70px;font-size:2.4rem}.lr73iRealmGrid{grid-template-columns:1fr}.lr73iSectionHead{display:block}}
    `;
    document.head.appendChild(st);
  }

  function boot(){
    styles();
    cleanOldButtonDamage();
    wrapLearningOpen();
    installHeader();
    labelPanels();
    decorateLearningTrails();
    setTimeout(function(){ installHeader(); labelPanels(); decorateLearningTrails(); }, 250);
    setTimeout(function(){ installHeader(); labelPanels(); decorateLearningTrails(); }, 900);
    try{ setInterval(installHeader, 2500); }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
