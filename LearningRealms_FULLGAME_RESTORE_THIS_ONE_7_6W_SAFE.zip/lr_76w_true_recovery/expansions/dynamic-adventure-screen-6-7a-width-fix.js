/* LearningRealms Dynamic Adventure Screen 6.7A
   Width/layout fix for 6.7: the dynamic adventure screen was being forced into the old grid column 2,
   which crushed it into a narrow vertical strip. This patch makes the adventure screen the wide first
   column and moves the side panels after it. No lessons or course content are changed.
*/
(function(){
  'use strict';
  if(window.__LR67A_DYNAMIC_WIDTH_FIX__) return;
  window.__LR67A_DYNAMIC_WIDTH_FIX__ = true;

  function byId(id){ return document.getElementById(id); }

  function injectStyles(){
    if(byId('lrDynamicAdventureScreen67AWidthFixStyle')) return;
    var st = document.createElement('style');
    st.id = 'lrDynamicAdventureScreen67AWidthFixStyle';
    st.textContent = `
      body.lrDynamicAdventureMode .shell{
        width:min(1540px,98vw) !important;
        max-width:1540px !important;
      }

      /* The real fix: older layout packs forced .main into grid-column:2.
         In 6.7 dynamic mode that made the adventure screen land in a skinny sidebar column.
         Put the main adventure screen in column 1 and let it take the wide space. */
      body.lrDynamicAdventureMode main{
        display:grid !important;
        grid-template-columns:minmax(720px,1fr) minmax(240px,285px) minmax(190px,230px) !important;
        gap:16px !important;
        align-items:start !important;
      }
      body.lrDynamicAdventureMode .actionSidebar{
        display:none !important;
        grid-column:auto !important;
        width:0 !important;
        min-width:0 !important;
        max-width:0 !important;
        overflow:hidden !important;
      }
      body.lrDynamicAdventureMode .main{
        grid-column:1 !important;
        width:100% !important;
        min-width:0 !important;
        max-width:none !important;
      }
      body.lrDynamicAdventureMode .rightSidebar{
        grid-column:2 !important;
        width:auto !important;
        min-width:0 !important;
        max-width:none !important;
      }
      body.lrDynamicAdventureMode .playerSidebar{
        grid-column:3 !important;
        width:auto !important;
        min-width:0 !important;
        max-width:none !important;
      }
      body.lrDynamicAdventureMode .main > .card:first-child{
        width:100% !important;
        min-width:0 !important;
      }
      body.lrDynamicAdventureMode #lrDynamicAdventureScreen,
      body.lrDynamicAdventureMode .lrDynamicAdventureScreen{
        width:100% !important;
        min-width:0 !important;
        max-width:none !important;
      }

      /* Keep the old navigation/movement docks hidden in dynamic-screen mode.
         The travel choices inside the main screen are the navigation now. */
      body.lrDynamicAdventureMode #mainCompassNav,
      body.lrDynamicAdventureMode .mainCompassNav,
      body.lrDynamicAdventureMode .compassBox,
      body.lrDynamicAdventureMode .compassGrid,
      body.lrDynamicAdventureMode .movementButtons,
      body.lrDynamicAdventureMode .travelButtons,
      body.lrDynamicAdventureMode #movementControls,
      body.lrDynamicAdventureMode .tinyTravelFooter,
      body.lrDynamicAdventureMode .localRadarMap,
      body.lrDynamicAdventureMode .localRadarUpDown,
      body.lrDynamicAdventureMode #lrControlDock,
      body.lrDynamicAdventureMode #lrFixedGameplayDock,
      body.lrDynamicAdventureMode #lrCenterActionDock,
      body.lrDynamicAdventureMode #lrCenterGameplayDock{
        display:none !important;
        height:0 !important;
        min-height:0 !important;
        max-height:0 !important;
        padding:0 !important;
        margin:0 !important;
        overflow:hidden !important;
      }

      body.lrDynamicAdventureMode .lr67Hero{
        padding:26px 30px 20px !important;
      }
      body.lrDynamicAdventureMode .lr67ChoicePanel{
        padding:20px 30px 22px !important;
      }
      body.lrDynamicAdventureMode .lr67BottomBar{
        padding:18px 30px 28px !important;
      }
      body.lrDynamicAdventureMode .lr67SceneText{
        max-width:none !important;
      }

      @media(max-width:1250px){
        body.lrDynamicAdventureMode .shell{
          width:min(1180px,98vw) !important;
        }
        body.lrDynamicAdventureMode main{
          grid-template-columns:minmax(0,1fr) minmax(230px,280px) !important;
        }
        body.lrDynamicAdventureMode .main{grid-column:1 !important;}
        body.lrDynamicAdventureMode .rightSidebar{grid-column:2 !important;}
        body.lrDynamicAdventureMode .playerSidebar{
          grid-column:1 / -1 !important;
        }
      }

      @media(max-width:980px){
        body.lrDynamicAdventureMode .shell{
          width:96vw !important;
        }
        body.lrDynamicAdventureMode main{
          display:block !important;
        }
        body.lrDynamicAdventureMode .main,
        body.lrDynamicAdventureMode .rightSidebar,
        body.lrDynamicAdventureMode .playerSidebar{
          width:100% !important;
          max-width:none !important;
          min-width:0 !important;
        }
        body.lrDynamicAdventureMode .lr67Hero,
        body.lrDynamicAdventureMode .lr67ChoicePanel,
        body.lrDynamicAdventureMode .lr67BottomBar,
        body.lrDynamicAdventureMode .lr67RoomActions{
          padding-left:16px !important;
          padding-right:16px !important;
        }
      }
    `;
    document.head.appendChild(st);
  }

  function applyMode(){
    try{ document.body.classList.add('lrDynamicAdventureMode'); }catch(e){}
    injectStyles();
  }

  function refresh(){
    applyMode();
    try{
      if(typeof window.lr67RenderDynamicScreen === 'function') window.lr67RenderDynamicScreen('room');
    }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(refresh, 30); setTimeout(refresh, 250); });
  else { setTimeout(refresh, 30); setTimeout(refresh, 250); }
  window.addEventListener('load', function(){ setTimeout(refresh, 150); setTimeout(refresh, 700); });
})();
