// Life Skills Realm Pack 1: Homestead Workshop
// Adds a dedicated Life Skills realm with time, calendar, chores, cooking measurements, tools, household safety, organization, and practical problem solving.
// Uses subject key "LifeSkills" for engine simplicity.
// Adds starter LifeSkills grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const lifeRooms = {
    homesteadRoad1:{
      title:"Toolbox Trail",
      zone:"Homestead Road",
      text:"A packed-earth trail leaves town beside fences, garden beds, stacked firewood, and little painted signs showing clocks, calendars, measuring cups, brooms, tools, and safety gloves.",
      exits:{south:"townSquare",east:"homesteadRoad2"}
    },
    homesteadRoad2:{
      title:"Chorepost Bend",
      zone:"Homestead Road",
      text:"The trail bends around a wooden post covered in tidy task cards: feed, sweep, sort, measure, plan, check, fix, and put away. A small bell marks the start of useful work.",
      exits:{west:"homesteadRoad1",east:"homesteadGate"}
    },
    homesteadGate:{
      title:"Homestead Workshop Gate",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"A sturdy workshop opens into a cheerful homestead yard. Every corner teaches something practical: time, food, cleaning, tools, safety, planning, and taking care of everyday things.",
      npc:{name:"Keeper Rowan",desc:"A practical guide with rolled-up sleeves, a pencil behind one ear, and a calm grin.",text:"Keeper Rowan nods. 'Life skills are the small useful things that make a home run smoother and a person more capable.'"},
      exits:{west:"homesteadRoad2",east:"timekeepingPorch",south:"kitchenMeasureRoom"}
    },
    timekeepingPorch:{
      title:"Timekeeping Porch",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"Clocks, calendars, sand timers, and day-planner boards hang on a sunny porch. A chalkboard shows morning, afternoon, evening, yesterday, today, tomorrow, and next week.",
      npc:{name:"Clockmaker Bell",desc:"A tidy clockmaker who teaches time, schedules, calendars, and planning.",text:"Clockmaker Bell sets a little clock. 'Time is easier to use when you can name it, measure it, and plan with it.'"},
      exits:{west:"homesteadGate",east:"toolShed",south:"choreBoardYard"}
    },
    kitchenMeasureRoom:{
      title:"Kitchen Measure Room",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"A teaching kitchen holds measuring cups, spoons, mixing bowls, recipe cards, clean counters, and bright labels for cup, half cup, teaspoon, tablespoon, and timer.",
      npc:{name:"Cook Marla",desc:"A warm kitchen teacher who teaches measuring, recipes, safe food habits, and cleanup.",text:"Cook Marla taps a measuring cup. 'A recipe is a set of instructions. Read first, measure carefully, then clean as you go.'"},
      exits:{north:"homesteadGate",east:"choreBoardYard",south:"safetyBarn"}
    },
    choreBoardYard:{
      title:"Chore Board Yard",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"A large board sorts tasks into daily, weekly, before, after, done, and check again. Wooden tokens can be moved from one column to another.",
      npc:{name:"Taskmaster Tilly",desc:"A cheerful organizer who teaches routines, responsibility, and breaking work into steps.",text:"Tilly moves a token. 'A big job is less bossy when you split it into small jobs.'"},
      exits:{north:"timekeepingPorch",west:"kitchenMeasureRoom",east:"toolShed",south:"sortingLoft"}
    },
    toolShed:{
      title:"Tool Shed",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"A neat shed displays safe pretend tools: hammer, screwdriver, wrench, tape measure, pliers, gloves, flashlight, and broom. Every tool has a label and a safe-use sign.",
      npc:{name:"Fixit Bram",desc:"A careful repair guide who teaches tool names, safe use, maintenance, and asking for help.",text:"Fixit Bram holds up a wrench. 'Tools are helpful when used properly. The first rule is knowing when you need an adult.'"},
      exits:{west:"choreBoardYard",south:"safetyBarn"}
    },
    sortingLoft:{
      title:"Sorting Loft",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"Shelves, baskets, labels, folded cloths, and storage bins fill a quiet loft. Everything has a place, and the whole room feels easier to think in.",
      npc:{name:"Label Lark",desc:"A bright little organizer who teaches sorting, categories, labels, storage, and keeping track of things.",text:"Label Lark flutters onto a basket. 'Organizing is not about fancy. It is about finding what you need without a hunt.'"},
      exits:{north:"choreBoardYard",east:"safetyBarn"}
    },
    safetyBarn:{
      title:"Safety Barn",
      zone:"Homestead Workshop",
      subject:"LifeSkills",
      text:"A wide barn holds practice stations for household safety: fire plans, weather safety, first-aid basics, tool caution, kitchen caution, electrical safety, and emergency steps.",
      npc:{name:"Captain Careful",desc:"A steady safety teacher who explains caution without panic.",text:"Captain Careful points to a clear path out of the barn. 'Safety means thinking ahead, staying calm, and knowing who to ask for help.'"},
      exits:{north:"toolShed",west:"kitchenMeasureRoom",east:"sortingLoft"}
    }
  };

  Object.assign(ROOMS, lifeRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.west) ROOMS.townSquare.exits.west = "homesteadRoad1";
    else if(!ROOMS.townSquare.exits.southwest) ROOMS.townSquare.exits.southwest = "homesteadRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.LifeSkills = window.LR_REWARDS.LifeSkills || [];
  window.LR_REWARDS.LifeSkills.push(
    {name:"Tiny Toolbox",slot:"shelf"},
    {name:"Homestead Clock",slot:"wall"},
    {name:"Measuring Cup Trophy",slot:"shelf"},
    {name:"Chore Board Token",slot:"wall"},
    {name:"Safety Barn Badge",slot:"wall"},
    {name:"Sorting Basket Model",slot:"shelf"},
    {name:"Recipe Card Stand",slot:"desk"},
    {name:"Golden Checkmark Plaque",slot:"wall"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.LifeSkills = {display:"Life Skills / Time / Safety / Helping",targetCorrect:150,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.LifeSkills = {display:"Life Skills / Planning / Practical Math",targetCorrect:210,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.LifeSkills = {display:"Life Skills / Systems / Problem Solving",targetCorrect:230,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("LifeSkills")) cfg.assignmentSubjects[child].push("LifeSkills");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({LifeSkills:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({LifeSkills:3}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({LifeSkills:3}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.LifeSkills = {
    zone:"Homestead Workshop",
    units:[
      {id:"G1-LIFE-TIME",title:"Time and Daily Order",goal:"Understand before/after, morning/afternoon/evening, days, calendars, and simple schedules.",targetLessons:100,skills:["before","after","morning","afternoon","evening","calendar","schedule"]},
      {id:"G1-LIFE-HELP",title:"Helping and Responsibility",goal:"Learn simple helping tasks, routines, sorting, and putting things away.",targetLessons:100,skills:["help","routine","sort","put away","daily task","responsibility"]},
      {id:"G1-LIFE-SAFE",title:"Safety and Asking for Help",goal:"Understand basic home safety, tool caution, kitchen caution, and when to ask an adult.",targetLessons:90,skills:["safety","adult help","hot","sharp","tool","fire plan"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.LifeSkills = {
    zone:"Homestead Workshop",
    units:[
      {id:"G6-LIFE-PLAN",title:"Planning and Time Management",goal:"Use schedules, priorities, estimates, and task breakdowns to plan work.",targetLessons:140,skills:["schedule","priority","estimate","task breakdown","deadline","routine"]},
      {id:"G6-LIFE-MEASURE",title:"Practical Measuring and Recipes",goal:"Use measurement, fractions, timing, and directions in household tasks and recipes.",targetLessons:140,skills:["recipe","cup","tablespoon","teaspoon","timer","fraction","directions"]},
      {id:"G6-LIFE-SAFE",title:"Household Safety and Organization",goal:"Apply safety rules, organization systems, labels, checklists, and maintenance thinking.",targetLessons:130,skills:["checklist","labels","storage","tool safety","kitchen safety","emergency plan"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.LifeSkills = {
    zone:"Homestead Workshop",
    units:[
      {id:"G7-LIFE-SYSTEMS",title:"Household Systems",goal:"Understand routines, maintenance, supplies, safety checks, and practical responsibility as systems.",targetLessons:150,skills:["system","maintenance","routine","supplies","inventory","checklist"]},
      {id:"G7-LIFE-PROBLEM",title:"Practical Problem Solving",goal:"Use step-by-step reasoning to solve everyday problems and decide when to ask for help.",targetLessons:140,skills:["diagnose","steps","evidence","tools","adult help","risk"]},
      {id:"G7-LIFE-MEASURE",title:"Real-World Measurement",goal:"Use measurement, estimation, unit reasoning, time, rates, and planning in practical tasks.",targetLessons:130,skills:["measurement","estimate","rate","time","recipe scaling","materials"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-LIFE-ROUTINE-1",subject:"LifeSkills",unit:"G1-LIFE-TIME",title:"My Simple Routine",prompt:"Draw or list three things you do in order. Tell what comes first, next, and last.",helper:"Example: wake up, eat breakfast, brush teeth.",estimatedMinutes:15},
    {id:"LUNA-LIFE-SAFE-1",subject:"LifeSkills",unit:"G1-LIFE-SAFE",title:"Ask an Adult Rule",prompt:"Draw or tell one thing that needs adult help. Explain why.",helper:"Think hot, sharp, heavy, plugged in, high up, or confusing.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-LIFE-PLAN-1",subject:"LifeSkills",unit:"G6-LIFE-PLAN",title:"Break Down a Job",prompt:"Choose one household task and break it into at least five clear steps.",helper:"Use first, next, then, after that, finally.",estimatedMinutes:25},
    {id:"AVA-LIFE-MEASURE-1",subject:"LifeSkills",unit:"G6-LIFE-MEASURE",title:"Recipe Direction Check",prompt:"Write a simple pretend recipe or household direction list. Include at least two measurements and one timing step.",helper:"Example measurements: cup, half cup, teaspoon, minutes.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-LIFE-SYSTEM-1",subject:"LifeSkills",unit:"G7-LIFE-SYSTEMS",title:"Create a Checklist",prompt:"Create a checklist for one recurring household task and explain why the order matters.",helper:"Think setup, supplies, safety, task steps, cleanup, and final check.",estimatedMinutes:30},
    {id:"MICHAEL-LIFE-PROBLEM-1",subject:"LifeSkills",unit:"G7-LIFE-PROBLEM",title:"Practical Problem Plan",prompt:"Describe a common household problem and write a safe step-by-step plan to investigate it. Include when to stop and ask an adult.",helper:"Use evidence, safety, tools, and next step language.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addLifeSkillsLadder(child){
    LR_addLessons(child,"LifeSkills",[
      {gradeBand:"K",unit:"K-LIFE-SORT",skill:"sorting",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Sorting means putting things into groups.",
       workedExample:"Spoons go with spoons. Socks go with socks.",
       guidedPractice:"Choose what belongs with cups.",
       q:"Which item belongs with dishes?",c:["cup","shoe","leaf"],a:"cup",
       explain:"A cup is a dish item."},

      {gradeBand:"G1",unit:"G1-LIFE-TIME",skill:"before and after",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Before and after help put events in order.",
       workedExample:"You put on socks before shoes.",
       guidedPractice:"Think about what comes first.",
       q:"What usually comes before shoes?",c:["socks","hat","blanket"],a:"socks",
       explain:"Socks usually go on before shoes."},

      {gradeBand:"G2",unit:"G2-LIFE-CALENDAR",skill:"calendar basics",difficulty:"grade 2",mode:"foundation",
       miniLesson:"A calendar shows days, weeks, and months.",
       workedExample:"Tomorrow is the day after today. Yesterday is the day before today.",
       guidedPractice:"Choose the day after today.",
       q:"The day after today is...",c:["tomorrow","yesterday","last week"],a:"tomorrow",
       explain:"Tomorrow comes after today."},

      {gradeBand:"G3",unit:"G3-LIFE-MEASURE",skill:"measuring cups",difficulty:"grade 3",mode:"foundation",
       miniLesson:"Measuring cups help follow recipes.",
       workedExample:"Two half cups make one whole cup.",
       guidedPractice:"Add the two halves.",
       q:"Two half cups equal...",c:["one cup","two cups","one teaspoon"],a:"one cup",
       explain:"1/2 cup plus 1/2 cup equals 1 cup."},

      {gradeBand:"G4",unit:"G4-LIFE-STEPS",skill:"task steps",difficulty:"grade 4",mode:"foundation",
       miniLesson:"A task is easier when broken into steps.",
       workedExample:"To sweep a room: pick up items, sweep corners, sweep center, collect pile, put broom away.",
       guidedPractice:"Choose the best first step.",
       q:"Before sweeping a cluttered floor, it helps to...",c:["pick up items","hide the broom","turn off all lights"],a:"pick up items",
       explain:"Picking up items clears the floor for sweeping."},

      {gradeBand:"G5",unit:"G5-LIFE-SAFETY",skill:"tool safety",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Tool safety means using the right tool carefully and asking for help when needed.",
       workedExample:"A sharp or powered tool requires adult help and careful instruction.",
       guidedPractice:"Choose the safest answer.",
       q:"If a tool is sharp, confusing, or powered, you should...",c:["ask an adult","guess quickly","use it blindfolded"],a:"ask an adult",
       explain:"Adult help is needed for risky tools."},

      {gradeBand:"G6",unit:"G6-LIFE-PLAN",skill:"priorities",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Priorities help decide what should be done first.",
       workedExample:"A safety problem comes before decorating because safety is more urgent.",
       guidedPractice:"Choose the more urgent task.",
       q:"Which should usually come first?",c:["cleaning a spill","organizing a shelf later","choosing a decoration"],a:"cleaning a spill",
       explain:"A spill can be a safety issue and should be handled first."},

      {gradeBand:"G7",unit:"G7-LIFE-SYSTEMS",skill:"checklists",difficulty:"grade 7",mode:"foundation",
       miniLesson:"A checklist helps make sure important steps are not forgotten.",
       workedExample:"A pet-care checklist might include water, food, clean area, and final check.",
       guidedPractice:"Think about preventing missed steps.",
       q:"A checklist mainly helps you...",c:["remember steps","make random guesses","avoid all planning"],a:"remember steps",
       explain:"Checklists reduce forgotten steps."},

      {gradeBand:"G8",unit:"G8-LIFE-PROBLEM",skill:"safe troubleshooting",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Safe troubleshooting means observing, checking simple causes, and stopping if risk appears.",
       workedExample:"If a lamp does not work, you might check the switch and bulb, but electrical repair requires adult help.",
       guidedPractice:"Know when to stop.",
       q:"If a problem involves electricity or danger, you should...",c:["ask an adult","keep poking wires","ignore safety"],a:"ask an adult",
       explain:"Electrical or dangerous problems require adult help."}
    ]);
  }

  LR_addLifeSkillsLadder("Luna");
  LR_addLifeSkillsLadder("Ava");
  LR_addLifeSkillsLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.LifeSkills = [
    {title:"Sorting Loft Trial",intro:"Label Lark drops three items into baskets.",q:"Which item belongs with dishes?",c:["cup","shoe","leaf"],a:"cup",reward:"Sorting Basket Badge"},
    {title:"Before and After Trial",intro:"Clockmaker Bell points to socks and shoes.",q:"What usually comes before shoes?",c:["socks","hat","blanket"],a:"socks",reward:"Timekeeping Token"}
  ];

  window.LR_BOSS_CONTENT.Ava.LifeSkills = [
    {title:"Kitchen Measure Trial",intro:"Cook Marla sets out two half cups.",q:"Two half cups equal...",c:["one cup","two cups","one teaspoon"],a:"one cup",reward:"Measuring Cup Trophy"},
    {title:"Priority Board Trial",intro:"Taskmaster Tilly points to a spill and a decoration box.",q:"Which should usually come first?",c:["cleaning a spill","decorating later","sorting ribbons"],a:"cleaning a spill",reward:"Priority Checkmark"}
  ];

  window.LR_BOSS_CONTENT.Michael.LifeSkills = [
    {title:"Checklist Trial",intro:"Keeper Rowan hands over a half-finished checklist.",q:"A checklist helps prevent...",c:["forgotten steps","all weather","map errors only"],a:"forgotten steps",reward:"Golden Checkmark Plaque"},
    {title:"Safety Barn Trial",intro:"Captain Careful points to an electrical problem sign.",q:"If a problem involves electricity or danger, you should...",c:["ask an adult","guess quickly","ignore safety"],a:"ask an adult",reward:"Safety Barn Badge"}
  ];
})();
