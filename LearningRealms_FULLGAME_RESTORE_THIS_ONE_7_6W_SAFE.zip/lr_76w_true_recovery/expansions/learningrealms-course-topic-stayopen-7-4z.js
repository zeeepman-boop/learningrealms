/* LearningRealms Course Topic Stay-Open Repair 7.4Z
   Built on 7.4Y. Conservative fix only: keep deep course/topic pages from being
   mistaken for umbrella hub pages by the 7.4K subject-room detector.
   No lesson rewrites, no shell rewrite, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR74Z_COURSE_TOPIC_STAYOPEN__) return;
  window.__LR74Z_COURSE_TOPIC_STAYOPEN__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ try{ return (root||document).querySelector(sel); }catch(e){ return null; } }

  var COURSE_SELECTORS = [
    '.egypt74Map','.egypt74Read','.egypt74Shell','.egypt74dRoyalMount','.egypt74jChoice',
    '.lr74qMap','.lr74qTopic','.lr74qCard',
    '.lr74rMap','.lr74rBody','.lr74rCard',
    '.lr74sMap','.lr74sBody','.lr74sArea',
    '.lr74tChamber','.lr74tBody','.lr74tAreaCard',
    '.lr74uHero','.lr74uCard','.lr74uBody',
    '.lr74vMap','.lr74vPage','.lr74vBody',
    '.lr74wMap','.lr74wPage','.lr74wBody',
    '.lr74pMap','.lr74pPage','.lr74pBody',
    '.lr74oMap','.lr74oPage','.lr74oBody',
    '.lr74lBody','.lr74lCard',
    '.shipwreckCoveNoFiller','.shipwreckNoFiller','.shipwreck74i',
    '.gdTrail','.greatDepressionTrail','.wildWestTrail','.bibleHistoryTrail'
  ];

  var COURSE_TEXT = /England: Kings and Queens|Royal Challenge|Ancient Egypt|Royal Gallery|World Expansion|Great Depression|Wild West|Bible History|Shipwreck Cove|Science and Engineering Expedition|Inventions & Engineering|Aerospace Engineering|Nature & Health|Weather & Storm Lab|Animal Kingdom|Creature Field Guide|Writing Composition|Mapmaker|Civic Hall|Market Square|Creative Quarter Adventure|Homestead Workshop Adventure/i;

  function isCourseScreen(root){
    if(!root) return false;
    for(var i=0;i<COURSE_SELECTORS.length;i++){
      if(q(COURSE_SELECTORS[i], root)) return true;
    }
    var t = (root.textContent || '').slice(0, 12000);
    return COURSE_TEXT.test(t);
  }

  function installStyles(){
    if(byId('lr74zCourseStayOpenStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr74zCourseStayOpenStyles';
    st.textContent = '.lr74zCourseSentinel{display:none!important;visibility:hidden!important;width:0!important;height:0!important;overflow:hidden!important} body.lr74zCourseOpen #lrDynamicAdventureScreen{display:block!important;visibility:visible!important;opacity:1!important}';
    document.head.appendChild(st);
  }

  function markCourseRoot(root){
    if(!root || !isCourseScreen(root)) return false;
    installStyles();
    document.body.classList.add('lr74zCourseOpen');
    if(!q('.lr74zCourseSentinel', root)){
      var s = document.createElement('i');
      s.className = 'lr74kRealm lr74zCourseSentinel';
      s.setAttribute('aria-hidden','true');
      s.textContent = 'course-stay-open';
      root.insertBefore(s, root.firstChild || null);
    }
    return true;
  }

  function scan(){
    var root = byId('lrDynamicAdventureScreen');
    if(markCourseRoot(root)) return;
    // If the current course rendered into a nested mount instead, mark the dynamic root anyway.
    var course = q(COURSE_SELECTORS.join(','), document.body);
    if(course && root){ markCourseRoot(root); }
  }

  var pending = 0;
  function schedule(){
    if(pending) return;
    pending = 1;
    setTimeout(function(){ pending = 0; scan(); }, 0);
  }

  // Course button clicks mutate the central screen first; this observer marks the new
  // course/topic page before the older 7.4K detector can bounce it back to a hub.
  function boot(){
    installStyles();
    scan();
    try{
      var mo = new MutationObserver(schedule);
      mo.observe(document.body, {subtree:true, childList:true});
    }catch(e){}
    window.addEventListener('click', function(){ setTimeout(scan, 0); setTimeout(scan, 80); }, true);
    setTimeout(scan, 120);
    setTimeout(scan, 700);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(scan, 150); setTimeout(scan, 900); });
})();
