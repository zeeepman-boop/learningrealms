/* LearningRealms Exploration Navigation Restore 6.5A
   Restores the real room-to-room navigation under the room text.
   Keeps content packs intact. Removes generic fake/floating movement docks.
*/
(function(){
  'use strict';
  if(window.__LR65A_EXPLORATION_NAV_RESTORE__) return;
  window.__LR65A_EXPLORATION_NAV_RESTORE__ = true;

  function esc(value){
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }

  function getRoom(){
    try{ return (typeof room === 'function') ? room() : {}; }catch(e){ return {}; }
  }

  function getRooms(){
    try{ return (typeof ROOMS !== 'undefined' && ROOMS) ? ROOMS : {}; }catch(e){ return {}; }
  }

  var DIRS = ['northwest','north','northeast','west','center','east','southwest','south','southeast','up','down'];
  var SHORT = {northwest:'NW',north:'N',northeast:'NE',west:'W',east:'E',southwest:'SW',south:'S',southeast:'SE',up:'UP',down:'DOWN'};
  var FULL = {northwest:'Northwest',north:'North',northeast:'Northeast',west:'West',east:'East',southwest:'Southwest',south:'South',southeast:'Southeast',up:'Up',down:'Down'};

  function targetTitle(id){
    var rooms = getRooms();
    return rooms[id] ? (rooms[id].title || id) : id;
  }

  function allExits(){
    var r = getRoom();
    return (r && r.exits) ? r.exits : {};
  }

  function showMessage(title, body){
    try{
      var actionTitle = document.getElementById('actionTitle');
      var actionText = document.getElementById('actionText');
      if(actionTitle) actionTitle.textContent = title;
      if(actionText) actionText.innerHTML = body;
    }catch(e){}
  }

  window.lrNavRestoreGo = function(dir){
    try{
      var exits = allExits();
      if(!exits[dir]){
        showMessage('No path that way', '<div class="lessonCard"><div class="lessonCardTitle">🧭 No open path</div><div class="lessonCardText">There is not a visible path ' + esc(FULL[dir] || dir) + ' from this room. Try one of the lit path buttons.</div></div>');
        var fb = document.getElementById('feedback');
        if(fb) fb.textContent = 'No visible path ' + (FULL[dir] || dir) + '.';
        return;
      }
      if(typeof go === 'function'){
        go(dir);
        setTimeout(lrRenderExplorationNav, 20);
        return;
      }
      showMessage('Travel unavailable', '<div class="lessonCard"><div class="lessonCardTitle">🧭 Travel hook missing</div><div class="lessonCardText">The room has a path, but the travel function did not load.</div></div>');
    }catch(e){
      console.error(e);
      showMessage('Travel error', '<div class="lessonCard"><div class="lessonCardTitle">Travel Error</div><div class="lessonCardText">' + esc(e.message || e) + '</div></div>');
    }
  };

  window.lrNavRestoreLook = function(){
    var r = getRoom();
    var exits = Object.keys(allExits());
    var pathText = exits.length ? exits.map(function(d){ return esc(FULL[d] || d) + ' to ' + esc(targetTitle(allExits()[d])); }).join('<br>') : 'No visible exits are marked here yet.';
    var npcLine = '';
    try{
      if(typeof roomHasNpc === 'function' && roomHasNpc() && typeof npc === 'function'){
        var n = npc();
        npcLine = '<p><b>Nearby:</b> ' + esc((n && n.name) || 'A realm helper') + '</p>';
      }
    }catch(e){}
    showMessage('Look Around', '<div class="lrLookAroundCard"><h3>🔎 ' + esc(r.title || 'This Room') + '</h3><p>' + esc(r.text || 'You pause and study the room carefully.') + '</p>' + npcLine + '<p><b>Visible paths:</b><br>' + pathText + '</p></div>');
  };

  window.lrNavRestoreInteract = function(){
    try{
      if(typeof roomHasNpc === 'function' && roomHasNpc() && typeof talk === 'function'){
        talk();
        return;
      }
      if(typeof lrStartInteraction === 'function'){
        lrStartInteraction();
        return;
      }
      lrNavRestoreLook();
    }catch(e){
      console.error(e);
      lrNavRestoreLook();
    }
  };

  function exitButton(dir, target){
    var label = FULL[dir] || dir;
    var short = SHORT[dir] || label;
    var dest = targetTitle(target);
    return '<button type="button" class="lrExploreMoveBtn lrExplore-' + esc(dir) + '" onclick="lrNavRestoreGo(\'' + esc(dir) + '\')">' +
      '<b>' + esc(short) + '</b><span>' + esc(dest) + '</span><small>' + esc(label) + '</small></button>';
  }

  function compassHtml(){
    var exits = allExits();
    var hasAny = Object.keys(exits).length > 0;
    var html = '<div class="lrExplorePanel" id="lrExplorePanel">' +
      '<div class="lrExploreHeader"><span>🧭 Explore</span><small>Move room by room. Only lit buttons are real paths.</small></div>';

    if(!hasAny){
      html += '<div class="lrExploreNoPaths">No open paths are marked from this room yet.</div>';
    }else{
      html += '<div class="lrExploreCompassGrid">';
      DIRS.forEach(function(dir){
        if(dir === 'center'){
          var r = getRoom();
          html += '<div class="lrExploreHere"><b>HERE</b><span>' + esc(r.title || 'Room') + '</span></div>';
        }else if(exits[dir]){
          html += exitButton(dir, exits[dir]);
        }else{
          html += '<div class="lrExploreBlank" aria-hidden="true"></div>';
        }
      });
      html += '</div>';
    }

    html += '<div class="lrExploreActionRow">' +
      '<button type="button" onclick="lrNavRestoreLook()">🔎 Look around</button>' +
      '<button type="button" onclick="lrNavRestoreInteract()">✨ Talk / interact</button>' +
      '<button type="button" onclick="travelHome && travelHome()">🏡 Home</button>' +
      '</div>';

    html += '</div>';
    return html;
  }

  function removeOldDocks(){
    ['lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock'].forEach(function(id){
      var el = document.getElementById(id);
      if(el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  window.lrRenderExplorationNav = function(){
    try{
      removeOldDocks();
      var mount = document.getElementById('mainCompassNav');
      if(!mount){
        var roomText = document.getElementById('roomText');
        if(roomText && roomText.parentNode){
          mount = document.createElement('div');
          mount.id = 'mainCompassNav';
          mount.className = 'mainCompassNav';
          roomText.parentNode.insertBefore(mount, roomText.nextSibling);
        }
      }
      if(mount){
        mount.innerHTML = compassHtml();
        mount.style.display = 'block';
        mount.style.height = 'auto';
        mount.style.overflow = 'visible';
      }
      var fb = document.getElementById('feedback');
      if(fb && !fb.textContent) fb.textContent = 'Exploration controls restored.';
    }catch(e){
      console.error('6.5A exploration nav restore skipped', e);
    }
  };

  function injectStyle(){
    if(document.getElementById('lrExploreNavRestoreStyle')) return;
    var css = `
      #mainCompassNav, #mainCompassNav .compassBox, #mainCompassNav .compassGrid{
        display:block !important;
        height:auto !important;
        min-height:0 !important;
        padding:0 !important;
        margin:0 !important;
        overflow:visible !important;
      }
      #lrControlDock,#lrFixedGameplayDock,#lrCenterActionDock,#lrCenterGameplayDock{
        display:none !important;
      }
      .lrExplorePanel{
        margin:14px 0 10px;
        padding:12px;
        border-radius:16px;
        background:rgba(18,32,20,.92);
        border:2px solid rgba(223,233,199,.36);
        box-shadow:0 8px 18px rgba(0,0,0,.22);
        color:#f3edd8;
        position:relative;
        z-index:2;
      }
      .lrExploreHeader{
        display:flex;
        justify-content:space-between;
        gap:10px;
        align-items:flex-end;
        margin-bottom:10px;
        color:#fff4cf;
        font-weight:900;
        font-size:1.05rem;
      }
      .lrExploreHeader small{
        font-weight:600;
        font-size:.78rem;
        color:#dfe9c7;
        opacity:.9;
        text-align:right;
      }
      .lrExploreCompassGrid{
        display:grid;
        grid-template-columns:repeat(3,minmax(112px,1fr));
        gap:8px;
        align-items:stretch;
      }
      .lrExploreMoveBtn{
        min-height:64px !important;
        padding:8px 9px !important;
        display:flex !important;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        gap:3px;
        text-align:center !important;
        line-height:1.08;
        border-radius:12px !important;
        cursor:pointer;
      }
      .lrExploreMoveBtn b{font-size:1.08rem;letter-spacing:.03em;}
      .lrExploreMoveBtn span{font-size:.82rem;max-width:100%;white-space:normal;}
      .lrExploreMoveBtn small{font-size:.68rem;opacity:.76;}
      .lrExploreHere{
        min-height:64px;
        border-radius:12px;
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        text-align:center;
        background:rgba(239,227,191,.11);
        border:1px dashed rgba(239,227,191,.34);
        color:#fff4cf;
        padding:8px;
        box-sizing:border-box;
      }
      .lrExploreHere b{font-size:.92rem;letter-spacing:.04em;}
      .lrExploreHere span{font-size:.76rem;opacity:.88;}
      .lrExploreBlank{min-height:64px;border-radius:12px;background:rgba(255,255,255,.035);opacity:.55;}
      .lrExploreActionRow{
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(130px,1fr));
        gap:8px;
        margin-top:10px;
        padding-top:10px;
        border-top:1px solid rgba(239,227,191,.18);
      }
      .lrExploreActionRow button{min-height:38px !important;}
      .lrExploreNoPaths{
        padding:10px;
        border-radius:12px;
        background:rgba(239,227,191,.08);
        color:#f3edd8;
      }
      .lrLookAroundCard{
        padding:12px;
        border-radius:14px;
        background:rgba(239,227,191,.10);
        border:1px solid rgba(239,227,191,.22);
        color:#f3edd8;
      }
      .lrLookAroundCard h3{margin-top:0;color:#fff4cf;}
      @media(max-width:900px){
        .lrExploreCompassGrid{grid-template-columns:repeat(3,minmax(82px,1fr));gap:6px;}
        .lrExploreMoveBtn{min-height:56px !important;font-size:.86rem !important;}
        .lrExploreHeader{display:block;}
        .lrExploreHeader small{display:block;text-align:left;margin-top:3px;}
      }
    `;
    var style = document.createElement('style');
    style.id = 'lrExploreNavRestoreStyle';
    style.textContent = css;
    document.head.appendChild(style);
  }

  injectStyle();

  try{
    window.lrApplyFixedDockLayout = function(){ removeOldDocks(); };
    lrApplyFixedDockLayout = window.lrApplyFixedDockLayout;
  }catch(e){}
  try{
    window.lrKeepCenterControlsVisible = function(){ removeOldDocks(); };
    lrKeepCenterControlsVisible = window.lrKeepCenterControlsVisible;
  }catch(e){}
  try{
    window.lrRenderMainCompass = function(){ lrRenderExplorationNav(); };
    lrRenderMainCompass = window.lrRenderMainCompass;
  }catch(e){}

  try{
    if(typeof renderRoom === 'function' && !window.__LR65A_RENDER_WRAPPED__){
      window.__LR65A_RENDER_WRAPPED__ = true;
      var oldRenderRoom = renderRoom;
      renderRoom = function(){
        var result = oldRenderRoom.apply(this, arguments);
        setTimeout(lrRenderExplorationNav, 10);
        setTimeout(removeOldDocks, 35);
        return result;
      };
      window.renderRoom = renderRoom;
    }
  }catch(e){ console.warn('6.5A render wrap skipped', e); }

  window.addEventListener('load', function(){
    setTimeout(function(){ injectStyle(); lrRenderExplorationNav(); removeOldDocks(); }, 60);
    setTimeout(function(){ injectStyle(); lrRenderExplorationNav(); removeOldDocks(); }, 400);
  });

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', function(){ injectStyle(); setTimeout(lrRenderExplorationNav, 40); });
  }else{
    setTimeout(function(){ injectStyle(); lrRenderExplorationNav(); }, 40);
  }
})();
