// Question Mountain Phase 13 - Writing Deepening IV
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Writing",[
{teach:"Commas separate items.",q:"Commas help separate...",c:["items","clouds","maps"],a:"items"},
{teach:"Names use capitals.",q:"Names begin with...",c:["capitals","numbers","symbols"],a:"capitals"},
{teach:"Sentences share ideas.",q:"Sentences express...",c:["ideas","coins","weather"],a:"ideas"},
{teach:"Question marks ask.",q:"Question marks show...",c:["questions","titles","trade"],a:"questions"},
{teach:"Periods end statements.",q:"Periods end...",c:["statements","maps","graphs"],a:"statements"}
]);

LR_addLessons("Ava","Writing",[
{teach:"Strong openings gain attention.",q:"Openings help...",c:["gain attention","measure","count"],a:"gain attention"},
{teach:"Details support paragraphs.",q:"Details support...",c:["paragraphs","maps","trade"],a:"paragraphs"},
{teach:"Sequence organizes events.",q:"Sequence organizes...",c:["events","equations","weather"],a:"events"},
{teach:"Word choice matters.",q:"Word choice affects...",c:["writing","coins","covers"],a:"writing"},
{teach:"Revision improves drafts.",q:"Revision improves...",c:["drafts","distance","temperature"],a:"drafts"}
]);

LR_addLessons("Michael","Writing",[
{teach:"Audience affects writing.",q:"Audience affects...",c:["writing choices","weather","graphs"],a:"writing choices"},
{teach:"Evidence builds arguments.",q:"Arguments need...",c:["evidence","luck","maps"],a:"evidence"},
{teach:"Organization guides readers.",q:"Organization helps...",c:["readers","coins","titles"],a:"readers"},
{teach:"Transitions connect sections.",q:"Transitions connect...",c:["ideas","trade","weather"],a:"ideas"},
{teach:"Editing refines grammar.",q:"Editing improves...",c:["grammar","maps","songs"],a:"grammar"}
]);
})();