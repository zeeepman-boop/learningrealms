// Economics Realm Pack 1: Merchant Row
// Adds a dedicated Economics realm with markets, trade, money, scarcity, budgets, supply/demand, and choices.
// Adds starter Economics grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.
// Uses existing lesson/portfolio/boss systems. Minimal engine risk.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const econRooms = {
    merchantRoad1:{
      title:"Coinstone Lane",
      zone:"Merchant Road",
      text:"A neat road paved with coin-shaped stones leads away from town. Little signs show apples, tools, cloth, bread, and candles. The air smells like woodsmoke, fresh paper, and warm rolls.",
      exits:{south:"townSquare",east:"merchantRoad2"}
    },
    merchantRoad2:{
      title:"Tradepost Bend",
      zone:"Merchant Road",
      text:"A bend in the road holds small trade carts stacked with wooden crates. Each crate is stamped with symbols for goods, services, needs, wants, savings, and choices.",
      exits:{west:"merchantRoad1",east:"merchantGate"}
    },
    merchantGate:{
      title:"Merchant Gate",
      zone:"Merchant Row",
      subject:"Economics",
      text:"A bright gate opens into Merchant Row, where learning stalls line a cobbled street. Banners flutter above the entrance: Choose wisely. Trade fairly. Spend carefully. Save patiently.",
      npc:{name:"Pennywise Bram",desc:"A cheerful gatekeeper with a ledger, coin pouch, and kind eyes.",text:"Bram jingles a small coin pouch. 'Economics is about choices. What do people need? What do they want? What do they give up?'"},
      exits:{west:"merchantRoad2",east:"marketSquare",south:"needsAlley"}
    },
    marketSquare:{
      title:"Market Square",
      zone:"Merchant Row",
      subject:"Economics",
      text:"Market stalls surround a busy square. One stall sells bread, another offers repairs, and a third displays tools. A large sign explains goods, services, buyers, and sellers.",
      npc:{name:"Mara Marketbell",desc:"A clear-voiced seller who teaches goods, services, producers, and consumers.",text:"Mara rings a tiny bell. 'A good is something you can hold. A service is work someone does for another person.'"},
      exits:{west:"merchantGate",east:"supplyDocks",south:"budgetHouse"}
    },
    needsAlley:{
      title:"Needs and Wants Alley",
      zone:"Merchant Row",
      subject:"Economics",
      text:"Two rows of shelves face each other. One side holds food, water, blankets, and shelter models. The other side holds toys, decorations, sweet treats, and fancy hats.",
      npc:{name:"Auntie Needful",desc:"A practical shopkeeper who teaches needs, wants, and wise choices.",text:"Auntie Needful smiles. 'A want can be wonderful, but a need comes first.'"},
      exits:{north:"merchantGate",east:"budgetHouse",south:"scarcityWell"}
    },
    budgetHouse:{
      title:"Budget House",
      zone:"Merchant Row",
      subject:"Economics",
      text:"Inside this cozy counting house, chalkboards show simple spending plans. Jars are labeled Save, Spend, Give, Repair, Food, and Tools.",
      npc:{name:"Ledger Finch",desc:"A calm bookkeeper who teaches budgets, saving, spending, and planning.",text:"Ledger Finch taps a chalkboard. 'A budget is not a cage. It is a plan so your coins know where to go.'"},
      exits:{north:"marketSquare",west:"needsAlley",east:"tradeBridge",south:"scarcityWell"}
    },
    supplyDocks:{
      title:"Supply Docks",
      zone:"Merchant Row",
      subject:"Economics",
      text:"Small boats unload sacks, baskets, wood bundles, and clay jars. Some docks are full. Others are nearly empty. Chalk marks show how available supply changes what people can get.",
      npc:{name:"Dockmaster Sella",desc:"A dockmaster who teaches supply, demand, shortages, and surplus.",text:"Sella points to an empty crate. 'When many people want something and there is not much of it, choices get harder.'"},
      exits:{west:"marketSquare",south:"tradeBridge"}
    },
    tradeBridge:{
      title:"Trade Bridge",
      zone:"Merchant Row",
      subject:"Economics",
      text:"A covered bridge connects two sides of Merchant Row. Traders pass baskets, tools, cloth, and notes across the bridge, showing how exchange helps people get what they need.",
      npc:{name:"Trader Oren",desc:"A traveling merchant who teaches trade, specialization, barter, and money.",text:"Oren adjusts his pack. 'No one makes everything alone. Trade lets people share skills and goods.'"},
      exits:{north:"supplyDocks",west:"budgetHouse",east:"priceTower",south:"scarcityWell"}
    },
    scarcityWell:{
      title:"Scarcity Well",
      zone:"Merchant Row",
      subject:"Economics",
      text:"An old stone well stands in a quiet courtyard. Three buckets hang beside it, but only one can be filled at a time. The place feels like a lesson about limited resources.",
      npc:{name:"Old Scarce",desc:"A wise old wellkeeper who teaches scarcity, opportunity cost, and tradeoffs.",text:"Old Scarce leans on the well. 'When you choose one thing, you give up another. That is where wisdom begins.'"},
      exits:{north:"needsAlley",east:"tradeBridge"}
    },
    priceTower:{
      title:"Price Tower",
      zone:"Merchant Row",
      subject:"Economics",
      text:"A tall tower holds moving signs that show prices rising and falling as supply and demand shift. A pulley lifts baskets labeled demand while another lowers crates labeled supply.",
      npc:{name:"Professor Price",desc:"A sharp-eyed teacher who explains prices, supply and demand, incentives, and inflation basics.",text:"Professor Price points to the pulleys. 'Prices tell a story about how much exists, how badly people want it, and what choices they make.'"},
      exits:{west:"tradeBridge"}
    }
  };

  Object.assign(ROOMS, econRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.south) ROOMS.townSquare.exits.south = "merchantRoad1";
    else if(!ROOMS.townSquare.exits.northwest) ROOMS.townSquare.exits.northwest = "merchantRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Economics = window.LR_REWARDS.Economics || [];
  window.LR_REWARDS.Economics.push(
    {name:"Tiny Coin Pouch",slot:"shelf"},
    {name:"Merchant Row Ledger",slot:"desk"},
    {name:"Needs and Wants Shelf Card",slot:"wall"},
    {name:"Budget Jar Set",slot:"shelf"},
    {name:"Trade Bridge Token",slot:"shelf"},
    {name:"Supply Crate Model",slot:"shelf"},
    {name:"Scarcity Well Plaque",slot:"wall"},
    {name:"Price Tower Miniature",slot:"desk"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Economics = {display:"Economics / Needs / Wants / Money",targetCorrect:150,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Economics = {display:"Economics / Trade / Scarcity / Budgeting",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Economics = {display:"Economics / Markets / Supply & Demand",targetCorrect:240,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Economics")) cfg.assignmentSubjects[child].push("Economics");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Economics:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Economics:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Economics:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Economics = {
    zone:"Merchant Row",
    units:[
      {id:"G1-ECON-NEEDS",title:"Needs and Wants",goal:"Tell the difference between things people need and things people want.",targetLessons:100,skills:["needs","wants","food","water","shelter","choices"]},
      {id:"G1-ECON-GOODS",title:"Goods and Services",goal:"Identify goods, services, buyers, sellers, producers, and consumers at a simple level.",targetLessons:100,skills:["goods","services","buyer","seller","producer","consumer"]},
      {id:"G1-ECON-MONEY",title:"Money and Choices",goal:"Understand that money is used for choices, spending, saving, and trade.",targetLessons:80,skills:["money","spend","save","trade","choice"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Economics = {
    zone:"Merchant Row",
    units:[
      {id:"G6-ECON-SCARCITY",title:"Scarcity and Opportunity Cost",goal:"Explain scarcity, choices, tradeoffs, and opportunity cost.",targetLessons:160,skills:["scarcity","tradeoff","opportunity cost","resources","choice"]},
      {id:"G6-ECON-MARKETS",title:"Markets and Trade",goal:"Understand producers, consumers, trade, specialization, and money.",targetLessons:150,skills:["producer","consumer","trade","specialization","money","barter"]},
      {id:"G6-ECON-BUDGET",title:"Budgeting and Personal Finance",goal:"Use budgeting concepts to plan spending, saving, and priorities.",targetLessons:140,skills:["budget","income","expense","saving","spending","priorities"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Economics = {
    zone:"Merchant Row",
    units:[
      {id:"G7-ECON-SUPPLY",title:"Supply and Demand",goal:"Explain how supply and demand influence prices and choices.",targetLessons:170,skills:["supply","demand","price","shortage","surplus","market"]},
      {id:"G7-ECON-INCENTIVES",title:"Incentives and Choices",goal:"Understand incentives, tradeoffs, opportunity cost, and market behavior.",targetLessons:150,skills:["incentive","tradeoff","opportunity cost","choice","behavior"]},
      {id:"G7-ECON-MONEY",title:"Money, Inflation, and Value",goal:"Understand money as a medium of exchange and basic inflation/value concepts.",targetLessons:140,skills:["money","value","inflation","purchasing power","saving","prices"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-ECON-NEEDS-1",subject:"Economics",unit:"G1-ECON-NEEDS",title:"Needs and Wants Sort",prompt:"Draw or list two needs and two wants. Tell why one item is a need.",helper:"Needs are things people must have. Wants are things people would like.",estimatedMinutes:15},
    {id:"LUNA-ECON-GOOD-SERVICE-1",subject:"Economics",unit:"G1-ECON-GOODS",title:"Good or Service",prompt:"Choose one good and one service. Explain the difference.",helper:"A good is a thing. A service is work someone does.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-ECON-BUDGET-1",subject:"Economics",unit:"G6-ECON-BUDGET",title:"Simple Budget Plan",prompt:"Make a simple budget with three categories: need, save, and want. Explain why you placed each item there.",helper:"Use clear categories and one reason for each choice.",estimatedMinutes:25},
    {id:"AVA-ECON-OPPCOST-1",subject:"Economics",unit:"G6-ECON-SCARCITY",title:"Opportunity Cost Example",prompt:"Describe a choice where choosing one thing means giving up another. Identify the opportunity cost.",helper:"Opportunity cost is the next best choice given up.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-ECON-SUPPLY-1",subject:"Economics",unit:"G7-ECON-SUPPLY",title:"Supply and Demand Explanation",prompt:"Explain what may happen to price when demand rises but supply stays low. Give a simple example.",helper:"Use the words supply, demand, price, and scarcity.",estimatedMinutes:30},
    {id:"MICHAEL-ECON-INFLATION-1",subject:"Economics",unit:"G7-ECON-MONEY",title:"Purchasing Power Explanation",prompt:"Explain the idea that money can buy less when prices rise over time.",helper:"Keep it simple and use a concrete example.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addEconomicsLadder(child){
    LR_addLessons(child,"Economics",[
      {gradeBand:"K",unit:"K-ECON-CHOICES",skill:"choices",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"A choice is when you pick one thing instead of another.",
       workedExample:"If you choose an apple instead of a cracker, you made a choice.",
       guidedPractice:"Choose the answer that means picking.",
       q:"A choice means you...",c:["pick something","sleep only","count clouds"],a:"pick something",
       explain:"A choice is picking one option."},

      {gradeBand:"G1",unit:"G1-ECON-NEEDS",skill:"needs and wants",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Needs are things people must have. Wants are things people would like.",
       workedExample:"Food and water are needs. A toy is a want.",
       guidedPractice:"Ask whether someone must have it to live.",
       q:"Which is a need?",c:["water","toy","ribbon"],a:"water",
       explain:"Water is something people need to live."},

      {gradeBand:"G2",unit:"G2-ECON-GOODS",skill:"goods and services",difficulty:"grade 2",mode:"foundation",
       miniLesson:"Goods are things people use. Services are work people do for others.",
       workedExample:"A loaf of bread is a good. A haircut is a service.",
       guidedPractice:"Choose whether the example is a thing or work.",
       q:"Which is a service?",c:["haircut","apple","chair"],a:"haircut",
       explain:"A haircut is work someone does for another person."},

      {gradeBand:"G3",unit:"G3-ECON-PRODUCERS",skill:"producers and consumers",difficulty:"grade 3",mode:"foundation",
       miniLesson:"A producer makes goods or provides services. A consumer uses or buys them.",
       workedExample:"A baker produces bread. A person who buys bread is a consumer.",
       guidedPractice:"Ask who makes and who uses.",
       q:"A baker who makes bread is a...",c:["producer","consumer","map"],a:"producer",
       explain:"A producer makes goods or services."},

      {gradeBand:"G4",unit:"G4-ECON-OPPCOST",skill:"opportunity cost",difficulty:"grade 4",mode:"foundation",
       miniLesson:"Opportunity cost is what you give up when you make a choice.",
       workedExample:"If you choose to spend coins on a lantern instead of a map, the map is the opportunity cost.",
       guidedPractice:"Ask what choice was not taken.",
       q:"Opportunity cost means what you...",c:["give up","always keep","never choose"],a:"give up",
       explain:"Opportunity cost is the next best option given up."},

      {gradeBand:"G5",unit:"G5-ECON-SUPPLY",skill:"supply and demand",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Supply is how much is available. Demand is how much people want.",
       workedExample:"If many people want apples but there are few apples, demand is high and supply is low.",
       guidedPractice:"Ask what exists and what people want.",
       q:"Demand means how much people...",c:["want","divide","evaporate"],a:"want",
       explain:"Demand is how much people want a good or service."},

      {gradeBand:"G6",unit:"G6-ECON-SCARCITY",skill:"scarcity",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Scarcity means resources are limited compared with wants.",
       workedExample:"If there is only enough wood for one bridge, people must decide how to use it.",
       guidedPractice:"Look for limited resources and choices.",
       q:"Scarcity means resources are...",c:["limited","unlimited","unneeded"],a:"limited",
       explain:"Scarcity exists because resources are limited."},

      {gradeBand:"G7",unit:"G7-ECON-SUPPLY",skill:"price signals",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Prices can signal information about supply and demand.",
       workedExample:"When demand rises and supply stays low, prices often rise.",
       guidedPractice:"Think about how much people want and how much is available.",
       q:"High demand and low supply often make prices...",c:["rise","always fall","vanish"],a:"rise",
       explain:"When many people want something scarce, price often rises."},

      {gradeBand:"G8",unit:"G8-ECON-MONEY",skill:"inflation basics",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Inflation is a general rise in prices over time.",
       workedExample:"If the same basket of goods costs more later, money buys less than before.",
       guidedPractice:"Think about purchasing power.",
       q:"Inflation means prices generally...",c:["rise over time","always fall","never change"],a:"rise over time",
       explain:"Inflation is a general increase in prices over time."}
    ]);
  }

  LR_addEconomicsLadder("Luna");
  LR_addEconomicsLadder("Ava");
  LR_addEconomicsLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Economics = [
    {title:"Needs and Wants Trial",intro:"Auntie Needful points to two shelves: one for needs and one for wants.",q:"Which is a need?",c:["food","toy","fancy hat"],a:"food",reward:"Needs Shelf Badge"},
    {title:"Goods and Services Bell",intro:"Mara Marketbell rings her tiny market bell.",q:"A service is...",c:["work someone does","a thing you hold","a river"],a:"work someone does",reward:"Marketbell Ribbon"}
  ];

  window.LR_BOSS_CONTENT.Ava.Economics = [
    {title:"Scarcity Well Trial",intro:"Old Scarce lowers one bucket into the well.",q:"Scarcity means resources are...",c:["limited","unlimited","always free"],a:"limited",reward:"Scarcity Well Token"},
    {title:"Budget House Trial",intro:"Ledger Finch hands over a small ledger.",q:"A budget is a plan for...",c:["using money","weather patterns","sentence fragments"],a:"using money",reward:"Budget Jar Charm"}
  ];

  window.LR_BOSS_CONTENT.Michael.Economics = [
    {title:"Price Tower Trial",intro:"Professor Price raises the demand pulley while supply stays low.",q:"High demand and low supply often cause prices to...",c:["rise","fall to zero","disappear"],a:"rise",reward:"Price Tower Medal"},
    {title:"Inflation Signal Trial",intro:"A price sign changes while the coin stays the same.",q:"Inflation means money may buy...",c:["less over time","more forever","nothing always"],a:"less over time",reward:"Purchasing Power Seal"}
  ];
})();
