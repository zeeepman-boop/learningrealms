
/* LearningRealms 7.6A - Shipwreck Cove Deep Rebuild Part 1
   Additive master-zone patch built from 7.5U. No shell rebuild, no render loop, no loading curtain.
   Purpose: replace thin/filler Shipwreck Cove surface with a richer in-world maritime history adventure. */
(function(){
'use strict';
if(window.__LR76A_SHIPWRECK_COVE_DEEP_REBUILD__) return;
window.__LR76A_SHIPWRECK_COVE_DEEP_REBUILD__ = true;

var PATCH = '7.6A Shipwreck Cove Deep Rebuild Part 1';
var STORAGE = 'lr76a_shipwreck_cove_state_v1';
var CHAMBERS = [
  {
    "id": "fog-bell-pier",
    "icon": "⚓",
    "title": "Fog Bell Pier: What a Wreck Can Teach",
    "room": "Fog Bell Pier",
    "area": "Cove Entrance",
    "reward": "Wreck Steward Oath Badge",
    "token": "Brass Fog Bell Token",
    "summary": "A respectful first chamber where the cove explains why shipwrecks are studied as evidence, memory, engineering records, and safety warnings.",
    "scene": "A brass fog bell hangs beside wet pilings. Captain Brine, the friendly old cove guide, points to a locked chart case and a shelf of carefully labeled fragments.",
    "place": "coasts, reefs, river mouths, harbor entrances, lake bottoms, and deep ocean floors where vessels came to rest after storms, collisions, fire, grounding, or structural failure",
    "era": "many eras, from ancient cargo boats and wooden sailing ships to steamers, ocean liners, lake freighters, submarines, and modern steel vessels",
    "evidence": "site maps, hull timbers, bells, anchors, cargo lists, ship logs, passenger records, photographs, sonar images, legal inquiry notes, and conservation tags",
    "tools": "measuring tapes, waterproof slates, cameras, sonar scans, museum labels, archival records, and careful drawings made before anything is moved",
    "science": "a wreck is shaped by buoyancy, hull strength, water pressure, corrosion, currents, sediment, marine life, and the original design choices made by builders",
    "safety": "respectful wreck study looks for warning signs so later sailors can improve navigation, loading, communication, fire safety, lifeboats, and emergency planning",
    "specific": "A wreck is not just treasure on the seafloor. It is a site with location, context, damage patterns, objects, and records that have to be kept together to tell the truth.",
    "choice": "choose whether to begin at the chart case, the bell rope, or the artifact shelf",
    "inspect": "The pier boards are painted with tide marks. A small brass plate reminds explorers that every wreck has a place, a route, a vessel, a crew, and a reason the story should be handled carefully."
  },
  {
    "id": "chart-loft",
    "icon": "🗺️",
    "title": "Lighthouse Chart Loft: Routes, Depths, and Warnings",
    "room": "Lighthouse Chart Loft",
    "area": "Navigation Wing",
    "reward": "Silver Soundings Pin",
    "token": "Folded Chart Token",
    "summary": "A map room about charts, soundings, lighthouses, buoys, currents, and the decisions mariners make before entering dangerous water.",
    "scene": "Lantern light falls across a long blue chart. Tiny depth numbers, compass roses, shoal marks, wreck symbols, buoy colors, and lighthouse flashes cover the table.",
    "place": "harbor channels, sandbars, reefs, capes, iceberg lanes, foggy straits, and Great Lakes shipping routes where a wrong turn can put a keel into danger",
    "era": "charts have guided mariners for centuries, and modern ships still use updated charts, electronic navigation, pilot advice, and official notices to mariners",
    "evidence": "old and corrected charts, lighthouse lists, buoy records, tide tables, current notes, pilot books, log entries, and the measured final position of a wreck",
    "tools": "compasses, dividers, parallel rules, lead lines, depth sounders, tide tables, range lights, fog signals, and chart corrections sent to mariners",
    "science": "water depth, tide height, wave direction, current speed, magnetic direction, visibility, and the draft of the ship all change whether a route is safe",
    "safety": "good navigation adds margins of safety by keeping vessels away from rocks, shoals, reefs, wreckage, restricted channels, and weather-exposed waters",
    "specific": "Soundings are depth measurements. On a chart they turn plain blue water into a readable landscape with shallow places, channels, slopes, and hazards.",
    "choice": "trace the safe channel around the reef or mark the shorter risky line and explain what would have to be checked first",
    "inspect": "The chart table has a tiny metal chain holding down a pencil, because a useful chart is never treated as decoration. It gets corrected, checked, compared, and questioned."
  },
  {
    "id": "storm-table",
    "icon": "🌫️",
    "title": "Storm Table: Fog, Waves, Currents, and Weather Clues",
    "room": "Storm Table House",
    "area": "Weather Wing",
    "reward": "Storm Glass Lantern",
    "token": "Fog Signal Token",
    "summary": "A weather chamber about how wind, waves, fog, pressure, ice, and currents can turn a normal voyage into a dangerous chain of events.",
    "scene": "Rain taps the windows while a barometer, cloud cards, wave sketches, current arrows, and a fog bell schedule sit beside a glowing storm glass.",
    "place": "open oceans, narrow sounds, cold lake routes, polar waters, tropical storm tracks, river mouths, and rocky coasts where weather can change the whole plan",
    "era": "every maritime age has battled weather, from oar and sail to steam, diesel, radar, satellite forecasts, and modern rescue coordination",
    "evidence": "weather logs, pressure readings, ice warnings, wave reports, fog signal records, eyewitness accounts, damage marks, drift patterns, and rescue timing notes",
    "tools": "barometers, cloud observation, wind scales, radio weather reports, fog horns, lighthouse signals, radar, satellite forecasts, current charts, and ice patrol reports",
    "science": "wind transfers energy into waves, pressure changes can warn of storms, fog limits sight, currents move vessels off track, and cold water can reduce survival time",
    "safety": "weather planning helps a captain delay, seek shelter, change course, slow down, call for help sooner, or keep extra distance from known hazards",
    "specific": "A wreck often has more than one cause. A safe design, a good route, and a skilled crew can still be tested hard when fog, current, and timing line up badly.",
    "choice": "watch the barometer drop and decide whether the cove vessel should delay, turn for shelter, or send a warning before conditions worsen",
    "inspect": "The rain-streaked window has three colored strings tied outside. They show wind direction, but Captain Brine warns that one clue is never enough by itself."
  },
  {
    "id": "dry-dock",
    "icon": "⛵",
    "title": "Shipwright Dry Dock: Hulls, Ballast, and Buoyancy",
    "room": "Shipwright Dry Dock",
    "area": "Engineering Deck",
    "reward": "Painted Ballast Stone",
    "token": "Keel Workshop Token",
    "summary": "An engineering chamber about why ships float, why loading matters, how hulls are strengthened, and why watertight spaces can buy time.",
    "scene": "A half-built model ship sits in a test tank. Lead weights slide near the keel while chalk marks show the waterline, cargo deck, pumps, and watertight doors.",
    "place": "shipyards, dry docks, naval yards, cargo ports, lake freighter docks, and repair basins where builders study shape, strength, balance, and loading",
    "era": "ancient boatbuilders, medieval shipwrights, iron shipyards, steamship designers, and modern naval architects all faced the same basic problem of floating safely",
    "evidence": "builder plans, hull remains, cargo manifests, ballast records, stability tests, pump reports, compartment diagrams, inspection notes, and survivor testimony",
    "tools": "model tanks, plumb lines, waterline marks, rivet gauges, weld records, pump diagrams, loading plans, stability books, and damage surveys",
    "science": "a ship floats when it displaces enough water, but stability depends on center of gravity, hull shape, cargo placement, free surface water, and reserve buoyancy",
    "safety": "good design and careful loading can slow flooding, keep a ship upright longer, protect exits, give pumps time to work, and give rescuers time to respond",
    "specific": "Ballast is weight placed low in a vessel to improve stability. Poor loading can raise the center of gravity and make a ship roll more dangerously.",
    "choice": "move the model cargo lower, close a tiny watertight door, or compare a narrow hull with a wider one in the test tank",
    "inspect": "The dry dock smells like wood shavings and salt. A little sign says, A beautiful ship must also be balanced, because the sea grades design choices without mercy."
  },
  {
    "id": "rescue-station",
    "icon": "🛶",
    "title": "Rescue Station: Signals, Lifeboats, and Calm Order",
    "room": "Lifeboat Rescue Station",
    "area": "Safety House",
    "reward": "Canvas Lifeboat Token",
    "token": "Rescue Bell Token",
    "summary": "A safety chamber about distress calls, lifeboat planning, drills, radios, rescue stations, and the calm organization that saves lives.",
    "scene": "Canvas lifeboats hang from davits beside rope ladders, signal lamps, blankets, cork life belts, radio headphones, and a neat muster list under glass.",
    "place": "ocean liners, ferries, lake boats, river steamers, coastal stations, lighthouses, rescue houses, and modern command centers that answer distress calls",
    "era": "organized rescue grew from shore-based life-saving stations and signal flags into wireless radio, international rules, coast guards, radar, and satellite distress systems",
    "evidence": "distress messages, lifeboat capacity plates, drill records, rescue logs, crew orders, survivor lists, inquiry reports, and changes made to safety rules afterward",
    "tools": "lifeboats, davits, oars, radios, signal lamps, flares, life jackets, muster cards, blankets, first aid supplies, rescue charts, and search patterns",
    "science": "cold water, darkness, distance, waves, wind, and visibility all affect how long a rescue may take and what equipment is needed before help arrives",
    "safety": "a lifeboat is only useful if people can find it, load it, lower it, stay together, signal position, and be located by rescuers",
    "specific": "After Titanic sank in 1912, safety rules became much stricter, including stronger expectations for lifeboats, drills, wireless watchkeeping, and ice monitoring.",
    "choice": "prepare the blankets and lights first, test the radio, or check that every lifeboat station has a clear route from the deck",
    "inspect": "Every hook in the station has a label. The room feels serious but not frightening, because the cove treats safety as preparation, not panic."
  },
  {
    "id": "evidence-lab",
    "icon": "🏺",
    "title": "Sunken Evidence Lab: Archaeology Without Treasure Hunting",
    "room": "Sunken Evidence Lab",
    "area": "Archaeology Wing",
    "reward": "Conservation Tag Badge",
    "token": "Slate Sketch Token",
    "summary": "A respectful archaeology chamber about mapping wreck sites, recording context, conserving artifacts, and why old objects should not be ripped out of place.",
    "scene": "A quiet lab table holds a waterproof drawing slate, a jar of desalinating metal, a tiny grid map, photo cards, and a sign reading, Context is part of the artifact.",
    "place": "shallow coves, deep-water wreck fields, riverbeds, lake bottoms, harbor mud, protected marine parks, and museum conservation rooms",
    "era": "maritime archaeology studies ancient shipwrecks, Age of Sail sites, steamship wrecks, wartime wrecks, trading vessels, fishing boats, and modern accident sites",
    "evidence": "photographs, measured grids, sediment layers, object locations, wood samples, ceramic marks, metal corrosion, cargo remains, archival records, and conservation notes",
    "tools": "sonar, remotely operated vehicles, dive slates, measuring grids, photogrammetry, conservation tanks, catalog numbers, gloves, labels, and database records",
    "science": "salt water, oxygen, bacteria, pressure, sand movement, and metal corrosion affect what survives and how carefully it must be stabilized after recovery",
    "safety": "protected wrecks are documented with permission because careless removal can destroy evidence, damage habitats, and erase the story the site was holding together",
    "specific": "An artifact without its location is like a sentence torn out of a book. The object may be interesting, but the most important meaning can be lost.",
    "choice": "draw the anchor before moving anything, photograph the cargo line, or place a conservation tag beside the fragile metal fitting",
    "inspect": "The lab has no treasure chest in the middle. Instead it has shelves of humble tags, because a careful label can protect more history than a shiny prize."
  },
  {
    "id": "pirate-map-room",
    "icon": "🏴‍☠️",
    "title": "Pirate Map Room: Myth, Trade, and Maritime Law",
    "room": "Pirate Map Room",
    "area": "Pirate and Trade Annex",
    "reward": "Compass Rose Warrant",
    "token": "Red Wax Map Seal",
    "summary": "A kid-safe pirate chamber that separates storybook pirate flavor from real maritime trade, law, privateering, smuggling, patrols, and port records.",
    "scene": "A red wax seal holds down a map of trade routes. A carved parrot perches over a ledger while the friendly cove ghost whispers, Do not trust every treasure tale.",
    "place": "busy sea lanes, island ports, colonial harbors, river mouths, coves, customs houses, naval patrol routes, and merchant docks where goods and laws met",
    "era": "the famous Golden Age of piracy is usually placed roughly from the late 1600s into the early 1700s, though sea robbery and maritime law are much older",
    "evidence": "court records, port books, ship manifests, customs papers, letters of marque, merchant ledgers, naval patrol notes, maps, coins, and newspaper notices",
    "tools": "charts, compasses, port records, cargo ledgers, sealed orders, naval signals, customs stamps, patrol routes, and courtroom testimony",
    "science": "winds, currents, ship speed, cargo weight, fresh water supplies, and safe anchorages shaped where vessels could travel and where raiders could hide",
    "safety": "the chamber keeps the adventure flavor without celebrating cruelty. The main focus is trade, navigation, law, evidence, choices, and how ports tried to keep routes safer",
    "specific": "A letter of marque allowed a private ship to attack enemy shipping during wartime under government authority, which is different from simple piracy even though the line could be messy in practice.",
    "choice": "compare a treasure map to a port ledger, check whether a ship carried legal papers, or follow the patrol route around the cove",
    "inspect": "The map has a skull stamp in one corner, but the biggest shelf holds boring-looking papers. Captain Brine says boring records often catch louder legends telling tall tales."
  },
  {
    "id": "famous-wreck-gallery",
    "icon": "🚢",
    "title": "Famous Wreck Gallery: Titanic, Great Lakes, and Better Rules",
    "room": "Famous Wreck Gallery",
    "area": "Memory Gallery",
    "reward": "Blue Inquiry Notebook",
    "token": "Gallery Lantern Token",
    "summary": "A respectful overview chamber using famous wreck stories to compare ice, storms, design, cargo, rescue, inquiry reports, and later safety improvements.",
    "scene": "Blue lanterns shine on three quiet displays: an ice-warning telegraph card, a Great Lakes storm chart, and an inquiry notebook with careful questions on every page.",
    "place": "North Atlantic liner routes, Great Lakes shipping lanes, coastal waters, rivers, and harbor approaches where busy traffic, weather, cargo, and design all matter",
    "era": "famous wrecks come from many periods, including sailing ships, steamships, early wireless ocean liners, lake freighters, ferries, and modern cargo vessels",
    "evidence": "wireless messages, weather maps, cargo records, ship plans, inquiry testimony, survivor accounts, photographs, sonar surveys, debris fields, and rule changes",
    "tools": "timeline boards, comparison charts, inquiry questions, route maps, distress records, lifeboat plans, weather reconstructions, and underwater survey images",
    "science": "ice can tear or open hull plating, storms can overwhelm stability, cargo can shift, fires can spread, and cold water changes the urgency of rescue",
    "safety": "the gallery asks what changed afterward, because the most useful memory of a disaster is often the rule, tool, warning, or habit that protects later voyages",
    "specific": "Titanic sank in April 1912 after striking an iceberg in the North Atlantic. Later investigations helped push stronger lifeboat, wireless, and ice-watch practices.",
    "choice": "compare the ice warning card, the storm chart, or the lifeboat plan before deciding what safety question the gallery is asking",
    "inspect": "Nothing in the gallery tries to shock the visitor. The cases are quiet on purpose, and every display asks what evidence can teach without turning sorrow into decoration."
  }
];
var ROOMS = [
  {id:'pier', icon:'⚓', title:'Fog Bell Pier', desc:'The entrance dock introduces respectful wreck study, evidence handling, and the Wreck Steward oath.', chambers:[0]},
  {id:'lighthouse', icon:'🗺️', title:'Lighthouse and Chart Loft', desc:'Charts, lighthouses, soundings, currents, and warning marks turn open water into a readable map.', chambers:[1]},
  {id:'storm', icon:'🌫️', title:'Storm Table House', desc:'Weather, fog, waves, ice, and currents explain why timing can change a whole voyage.', chambers:[2]},
  {id:'drydock', icon:'⛵', title:'Shipwright Dry Dock', desc:'Hull shape, ballast, cargo, buoyancy, pumps, and compartments show the engineering side of wreck history.', chambers:[3]},
  {id:'rescue', icon:'🛶', title:'Lifeboat Rescue Station', desc:'Signals, drills, lifeboats, wireless calls, blankets, search patterns, and calm order belong here.', chambers:[4]},
  {id:'lab', icon:'🏺', title:'Sunken Evidence Lab', desc:'Archaeology, mapping, photo records, conservation, and protected wreck ethics keep history together.', chambers:[5]},
  {id:'pirate', icon:'🏴‍☠️', title:'Pirate Map Room', desc:'A kid-safe pirate annex separates myths from port records, trade routes, maritime law, and evidence.', chambers:[6]},
  {id:'gallery', icon:'🚢', title:'Famous Wreck Gallery', desc:'Famous wreck cases are handled quietly through evidence, inquiry questions, safety improvements, and memory.', chambers:[7]}
];

function byId(id){ return document.getElementById(id); }
function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g,function(ch){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];}); }
function state(){ try{ return JSON.parse(localStorage.getItem(STORAGE) || '{}') || {}; }catch(e){ return {}; } }
function save(s){ try{ localStorage.setItem(STORAGE, JSON.stringify(s || {})); }catch(e){} }
function has(fn){ return typeof window[fn] === 'function'; }
function setFeedback(msg){ var f=byId('feedback'); if(f) f.textContent = msg || ''; }
function mount(title, html){
  installStyles();
  var t=byId('actionTitle'), b=byId('actionText'), lb=byId('lessonBox'), sb=byId('storageBox');
  if(t) t.textContent = title || 'Shipwreck Cove';
  if(b) b.innerHTML = html || '';
  if(lb) lb.classList.add('hidden');
  if(sb) sb.classList.add('hidden');
  setFeedback('');
  try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){}
  try{ if(b && b.scrollIntoView) b.scrollIntoView({block:'start', behavior:'smooth'}); }catch(e){}
}
function progress(){ var s=state(), mastered=s.mastered || {}; var count=0; CHAMBERS.forEach(function(c){ if(mastered[c.id]) count++; }); return {count:count,total:CHAMBERS.length,pct:Math.round((count/CHAMBERS.length)*100)}; }
function roomById(id){ for(var i=0;i<ROOMS.length;i++) if(ROOMS[i].id===id) return ROOMS[i]; return ROOMS[0]; }
function chamberById(id){ for(var i=0;i<CHAMBERS.length;i++) if(CHAMBERS[i].id===id) return CHAMBERS[i]; return CHAMBERS[0]; }
function chamberIndex(id){ for(var i=0;i<CHAMBERS.length;i++) if(CHAMBERS[i].id===id) return i; return 0; }
function award(name){ var s=state(); s.items=s.items||[]; if(s.items.indexOf(name)<0) s.items.push(name); save(s); try{ if(typeof window.LR_merchantAwardCurrency==='function') window.LR_merchantAwardCurrency('seaGlass', 1, name); }catch(e){} return name; }
function buildPages(t){
  return [
    [
      t.scene + ' The room is written like a museum adventure, but every clue points back to real maritime history instead of random treasure talk.',
      'This chamber belongs to ' + t.place + '. ' + t.era.charAt(0).toUpperCase() + t.era.slice(1) + ', so the cove treats the subject as a long chain of human decisions, weather, tools, and evidence.',
      t.specific + ' Captain Brine asks the player to look for place, route, vessel, records, and damage patterns before jumping to a dramatic answer.',
      'The first task is not to race through the room. The player chooses a path, inspects the objects, and builds a careful explanation from the same kinds of clues historians, engineers, sailors, and archaeologists would use.'
    ],
    [
      'The evidence shelf holds ' + t.evidence + '. Each item matters most when it stays connected to where it was found, who recorded it, and what other clues surround it.',
      'A single object can be misleading if it is pulled out of context. A bell may identify a vessel, a log may preserve a route, and a damage mark may show force, but the strongest explanation comes when several clues agree.',
      'The chamber also keeps a record of uncertainty. Some wreck stories are incomplete because storms scatter debris, wood decays, metal corrodes, witnesses disagree, or older records leave gaps.',
      'The room choice is simple but meaningful: ' + t.choice + '. That choice turns the chamber into an investigation instead of a flat reading page.'
    ],
    [
      'The working tools here are ' + t.tools + '. They are not decorations. They show how mariners and researchers measure, compare, record, and test what the water has left behind.',
      t.science.charAt(0).toUpperCase() + t.science.slice(1) + '. This is why Shipwreck Cove belongs partly in history and partly in science and engineering.',
      'The player can connect the chamber to math and map skills too. Depth, distance, speed, time, weight, direction, capacity, and sequence all affect what happened and what a careful rescue or investigation would require.',
      'Captain Brine keeps the ghostly flavor gentle. He taps the table, points to the evidence, and reminds the player that a good sea story is stronger when the facts can carry it.'
    ],
    [
      'The safety wall explains that wreck history should never become a spooky shock display. It is about memory, skill, respect, and the practical question of how later voyages can be safer.',
      t.safety.charAt(0).toUpperCase() + t.safety.slice(1) + '. The cove therefore asks what warning, rule, tool, habit, or design improvement can come from the story.',
      'Some chambers involve famous losses, but the wording stays calm and kid-safe. The focus stays on evidence, weather, navigation, rescue, engineering, and respectful remembrance rather than gruesome details.',
      'By the end of the safety page, the player should be able to explain the difference between an exciting legend and a responsible account. Legends may add flavor, but records, maps, measurements, and careful questions do the teaching.'
    ],
    [
      'The final page ties the chamber back to the larger cove. A route, a vessel, a design choice, a weather clue, a rescue action, and a preserved artifact can all belong to one connected explanation.',
      'The earned artifact for this chamber is the ' + t.reward + '. It is a memory object, not a treasure grab, and it belongs on the shelf only after the proof challenge shows careful reading.',
      'The inspection token is the ' + t.token + '. Finding it proves the room was explored, while the proof questions prove the chamber was actually read.',
      'When the page closes, the player can return to the map, inspect the room, open the artifact shelf, or enter the challenge. The cove stays open-ended, but the facts stay anchored.'
    ]
  ];
}
function quizFor(t){
  return [
    {q:'What is the main purpose of this chamber?', a:'To use wreck evidence, records, science, and respectful memory to explain maritime history.', d:['To hunt for shiny treasure as fast as possible.','To replace every subject with a plain menu button.','To tell a random spooky story without checking evidence.'], why:t.summary},
    {q:'Which evidence belongs in this chamber?', a:t.evidence + '.', d:['Only a made-up treasure chest with no location.','Only a monster drawing with no record attached.','Only a button label that says Continue.'], why:'The chamber evidence is listed on the evidence shelf.'},
    {q:'Which tool set helps investigators or mariners here?', a:t.tools + '.', d:['A blank poster and a pretend crown.','A sword, a throne, and an unrelated puzzle key.','A sticker sheet with no map or record.'], why:'The tools show how the room is investigated.'},
    {q:'What science or engineering idea matters here?', a:t.science + '.', d:['The sea has no forces worth measuring.','Ships sink only because stories need drama.','Maps and measurements do not help explain wrecks.'], why:'This is the science/engineering thread of the chamber.'},
    {q:'What safety idea does the chamber protect?', a:t.safety + '.', d:['Safety plans are less important than decorations.','Warnings should be ignored if the route looks exciting.','A rescue plan is only useful after everyone guesses.'], why:'The safety wall turns wreck history into practical wisdom.'},
    {q:'Which artifact is earned after mastering this chamber?', a:t.reward + '.', d:['A blank placeholder coin.','A random item from an unrelated room.','A trophy with no memory tag.'], why:'The mastery artifact is ' + t.reward + '.'}
  ].map(function(q, qi){ return rotateQuestion(q, qi); });
}
function rotateQuestion(q, qi){
  var choices=[q.a].concat(q.d), offset=(qi*2+1)%choices.length, out=[];
  for(var i=0;i<choices.length;i++) out.push(choices[(i+offset)%choices.length]);
  return {q:q.q, choices:out, a:out.indexOf(q.a), why:q.why};
}
function bar(){ var p=progress(); return '<div class="lr76aBar"><i style="width:'+p.pct+'%"></i></div><small>'+p.count+' / '+p.total+' chambers mastered · '+p.pct+'%</small>'; }
function topNav(extra){
  return '<div class="lr76aNav"><button data-lr76a-act="map">Cove map</button><button data-lr76a-act="rewards">Artifact shelf</button><button data-lr76a-act="review">Review shelf</button><button data-lr76a-act="merchant">Cove keeper</button>' + (extra||'') + '</div>';
}
function openMap(){
  var p=progress(), s=state(), mastered=s.mastered||{};
  var roomCards = ROOMS.map(function(r){
    var chamberList = r.chambers.map(function(i){ var c=CHAMBERS[i]; return c.icon+' '+c.title; }).join(' · ');
    return '<button class="lr76aRoomCard" data-lr76a-act="room:'+esc(r.id)+'"><span>'+esc(r.icon)+'</span><b>'+esc(r.title)+'</b><p>'+esc(r.desc)+'</p><small>'+esc(chamberList)+'</small><i>Enter ›</i></button>';
  }).join('');
  var chamberCards = CHAMBERS.map(function(c,i){ var done=!!mastered[c.id]; return '<button class="lr76aChamberCard '+(done?'done':'')+'" data-lr76a-act="topic:'+i+':0"><span>'+esc(c.icon)+'</span><b>'+esc(c.title)+'</b><p>'+esc(c.summary)+'</p><small>'+esc(c.reward)+(done?' ✓':'')+'</small></button>'; }).join('');
  mount('⚓ Shipwreck Cove', '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">⚓</div><div><h2>Shipwreck Cove Deep Rebuild</h2><p>The cove is now a real maritime history adventure zone: lighthouses, storms, ship design, rescue work, archaeology, kid-safe pirate records, famous wreck evidence, artifact shelves, and proof-of-reading challenges.</p>'+bar()+'</div></section><section class="lr76aPanel"><h3>Choose a place in the cove</h3><p>Captain Brine keeps the ghostly flavor gentle. Every room is meant to feel like an in-world museum wing, not a school menu.</p><div class="lr76aRoomGrid">'+roomCards+'</div></section><section class="lr76aPanel"><h3>Part 1 chambers</h3><p>Each chamber has 5 pages, 4 substantial paragraphs per page, a room inspection, an artifact reward, and 6 proof-of-reading questions.</p><div class="lr76aGrid">'+chamberCards+'</div></section>'+topNav('<button data-lr76a-act="history">History Wing</button>')+'</div>');
}
function openRoom(id){
  var r=roomById(id), s=state(); s.room=id; save(s);
  var cards = r.chambers.map(function(i){ var c=CHAMBERS[i]; return '<button class="lr76aChamberCard" data-lr76a-act="topic:'+i+':0"><span>'+esc(c.icon)+'</span><b>'+esc(c.title)+'</b><p>'+esc(c.summary)+'</p><small>Reward: '+esc(c.reward)+'</small></button>'; }).join('');
  var other = ROOMS.filter(function(x){return x.id!==r.id;}).map(function(x){return '<button data-lr76a-act="room:'+esc(x.id)+'">'+esc(x.icon+' '+x.title)+'</button>';}).join('');
  mount(esc(r.icon+' '+r.title), '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">'+esc(r.icon)+'</div><div><h2>'+esc(r.title)+'</h2><p>'+esc(r.desc)+'</p>'+bar()+'</div></section><section class="lr76aPanel"><h3>Room inspection</h3><p>'+esc(CHAMBERS[r.chambers[0]].inspect)+'</p><button class="lr76aPrimary" data-lr76a-act="inspect:'+esc(r.id)+'">Inspect carefully</button></section><section class="lr76aPanel"><h3>Chambers here</h3><div class="lr76aGrid">'+cards+'</div></section><section class="lr76aPanel"><h3>Travel choices</h3><div class="lr76aNav">'+other+'</div></section>'+topNav()+'</div>');
}
function openTopic(i,p){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0));
  p=Math.max(0, Math.min(4, Number(p)||0));
  var c=CHAMBERS[i], pages=buildPages(c), paras=pages[p], s=state(); s.topic=i; s.page=p; save(s);
  var prev = p>0 ? '<button data-lr76a-act="topic:'+i+':'+(p-1)+'">◀ Previous page</button>' : '<button data-lr76a-act="map">Cove map</button>';
  var next = p<4 ? '<button class="lr76aPrimary" data-lr76a-act="topic:'+i+':'+(p+1)+'">Next page ▶</button>' : '<button class="lr76aPrimary" data-lr76a-act="challenge:'+i+'">Enter proof challenge</button>';
  mount(c.icon+' '+c.title, '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">'+esc(c.icon)+'</div><div><h2>'+esc(c.title)+'</h2><p>'+esc(c.room)+' · Page '+(p+1)+' of 5 · '+esc(c.area)+'</p>'+bar()+'</div></section><article class="lr76aReading"><h3>'+esc(['Entering the room','Evidence shelf','Science and tools','Safety and memory','Artifact choice'][p])+'</h3>'+paras.map(function(x){return '<p>'+esc(x)+'</p>';}).join('')+'</article><div class="lr76aChoice"><b>Room choice:</b> '+esc(c.choice)+'</div><div class="lr76aNav">'+prev+'<button data-lr76a-act="inspectroom:'+i+'">Inspect room</button>'+next+'</div>'+topNav()+'</div>');
}
function inspectRoomIndex(i){ var c=CHAMBERS[Math.max(0,Math.min(CHAMBERS.length-1,Number(i)||0))]; var found=award(c.token); mount('🔎 Inspect '+c.room, '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">🔎</div><div><h2>'+esc(c.room)+'</h2><p>'+esc(c.inspect)+'</p></div></section><section class="lr76aPanel"><h3>Found exploration token</h3><p><b>'+esc(found)+'</b></p><p>This token proves the room was inspected instead of skipped. It is stored on the Shipwreck Cove artifact shelf.</p></section><div class="lr76aNav"><button class="lr76aPrimary" data-lr76a-act="topic:'+chamberIndex(c.id)+':'+((state().page||0))+'">Return to chamber</button><button data-lr76a-act="rewards">Artifact shelf</button></div></div>'); }
function inspectPlace(id){ var r=roomById(id); var found=award(r.icon+' '+r.title+' Room Token'); mount('🔎 Inspect '+r.title, '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">'+esc(r.icon)+'</div><div><h2>'+esc(r.title)+'</h2><p>'+esc(r.desc)+'</p></div></section><section class="lr76aPanel"><h3>Found room token</h3><p><b>'+esc(found)+'</b></p><p>Captain Brine adds it to the shelf as proof that this part of the cove was explored.</p></section><div class="lr76aNav"><button class="lr76aPrimary" data-lr76a-act="room:'+esc(r.id)+'">Return to room</button><button data-lr76a-act="rewards">Artifact shelf</button></div></div>'); }
function openChallenge(i){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0));
  var c=CHAMBERS[i], qs=quizFor(c);
  var html = '<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">'+esc(c.icon)+'</div><div><h2>Proof challenge: '+esc(c.title)+'</h2><p>Answer from the chamber pages. This is meant to prove reading, not reward random clicking.</p></div></section>' + qs.map(function(q,qi){ return '<div class="lr76aQuestion"><b>Question '+(qi+1)+':</b> '+esc(q.q)+'<div class="lr76aChoices">'+q.choices.map(function(choice,ci){ return '<label><input type="radio" name="lr76aq_'+qi+'" value="'+ci+'"> '+esc(choice)+'</label>'; }).join('')+'</div></div>'; }).join('') + '<div class="lr76aNav"><button data-lr76a-act="topic:'+i+':0">Review chamber</button><button class="lr76aPrimary" data-lr76a-act="check:'+i+'">Check challenge</button></div></div>';
  mount('Shipwreck Cove Challenge', html);
}
function checkChallenge(i){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0));
  var c=CHAMBERS[i], qs=quizFor(c), score=0, missed=[];
  qs.forEach(function(q, qi){ var el=document.querySelector('input[name="lr76aq_'+qi+'"]:checked'); var val=el?Number(el.value):-1; if(val===q.a) score++; else missed.push({chamber:c.title, answer:q.choices[q.a], why:q.why}); });
  var s=state(); s.missed=(s.missed||[]).concat(missed).slice(-160);
  if(score===qs.length){ s.mastered=s.mastered||{}; s.mastered[c.id]=true; s.rewards=s.rewards||[]; if(s.rewards.indexOf(c.reward)<0) s.rewards.push(c.reward); award(c.reward); try{ if(typeof window.LR_merchantAwardCurrency==='function') window.LR_merchantAwardCurrency('seaGlass', 3, c.title); }catch(e){} }
  save(s);
  var review = missed.map(function(m){ return '<li><b>'+esc(m.answer)+'</b><br><small>'+esc(m.why)+'</small></li>'; }).join('');
  var nextBtn = i < CHAMBERS.length-1 ? '<button class="lr76aPrimary" data-lr76a-act="topic:'+(i+1)+':0">Next chamber</button>' : '<button class="lr76aPrimary" data-lr76a-act="rewards">Artifact shelf</button>';
  mount('⚓ Challenge Result', '<div class="lr76aShell"><section class="lr76aPanel">'+(score===qs.length?'<h2>🏆 Cove mastery earned</h2><p>You earned <b>'+esc(c.reward)+'</b>. It has been added to the artifact shelf.</p>':'<h2>🔁 '+score+' / '+qs.length+'</h2><p>The cove door stays open. Review the chamber pages and try again.</p>')+(review?'<h3>Review clues</h3><ol>'+review+'</ol>':'')+'</section><div class="lr76aNav"><button data-lr76a-act="topic:'+i+':0">Review chamber</button><button data-lr76a-act="map">Cove map</button>'+nextBtn+'</div></div>');
}
function rewards(){
  var s=state(), r=s.rewards||[], items=s.items||[];
  var earned=CHAMBERS.map(function(c){ var got=r.indexOf(c.reward)>=0; return '<span class="lr76aReward '+(got?'got':'')+'">'+esc(c.icon+' '+c.reward)+(got?' ✓':'')+'</span>'; }).join('');
  var found=items.length ? items.map(function(x){ return '<span class="lr76aReward got">'+esc(x)+'</span>'; }).join('') : '<p>No room tokens found yet. Inspect rooms and chambers to collect them.</p>';
  mount('⚓ Shipwreck Cove Artifact Shelf','<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">🏆</div><div><h2>Artifact Shelf</h2><p>These are memory objects tied to reading, evidence, safety, navigation, engineering, rescue, and conservation. They are not random treasure drops.</p>'+bar()+'</div></section><section class="lr76aPanel"><h3>Mastery artifacts</h3><div class="lr76aRewards">'+earned+'</div></section><section class="lr76aPanel"><h3>Exploration tokens</h3><div class="lr76aRewards">'+found+'</div></section>'+topNav()+'</div>');
}
function reviewShelf(){
  var s=state(), m=s.missed||[];
  mount('🔁 Shipwreck Cove Review Shelf','<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">🔁</div><div><h2>Review Shelf</h2><p>Missed proof clues appear here so the player can return to the exact evidence instead of guessing.</p></div></section><section class="lr76aPanel">'+(m.length?'<ol>'+m.slice(-60).reverse().map(function(x){ return '<li><b>'+esc(x.chamber)+': '+esc(x.answer)+'</b><br><small>'+esc(x.why)+'</small></li>'; }).join('')+'</ol>':'<p>No missed challenge clues yet.</p>')+'</section>'+topNav()+'</div>');
}
function merchant(){
  mount('🧭 Cove Keeper','<div class="lr76aShell"><section class="lr76aHero"><div class="lr76aHeroIcon">🧭</div><div><h2>Old Marnie the Cove Keeper</h2><p>Marnie keeps the lantern shop, but she only trades in careful work: proof challenges, room inspections, and respectful evidence handling.</p></div></section><section class="lr76aPanel"><h3>Shopkeeper notes for future rewards</h3><p>Future Shipwreck Cove parts can add lighthouse decor, ship wheel wall pieces, map table furniture, safe ghost lanterns, compass charms, diving slate badges, museum labels, rescue blankets, model ship shelves, and friendly cove pets.</p><p>For now, mastery gives sea-glass style credit hooks when the broader merchant system is available, without forcing a new shop system into the shell.</p></section>'+topNav()+'</div>');
}
function route(act){
  act=String(act||'map');
  if(act==='map'||act==='open') return openMap();
  if(act==='rewards') return rewards();
  if(act==='review') return reviewShelf();
  if(act==='merchant') return merchant();
  if(act==='history'){ if(has('openLearningCenterAnnex75O')) return window.openLearningCenterAnnex75O('history'); if(has('openRealmLibrary75A')) return window.openRealmLibrary75A('history'); return openMap(); }
  if(act.indexOf('room:')===0) return openRoom(act.slice(5));
  if(act.indexOf('inspect:')===0) return inspectPlace(act.slice(8));
  if(act.indexOf('inspectroom:')===0) return inspectRoomIndex(Number(act.slice(12)||0));
  if(act.indexOf('topic:')===0){ var p=act.split(':'); return openTopic(Number(p[1]||0), Number(p[2]||0)); }
  if(act.indexOf('challenge:')===0) return openChallenge(Number(act.slice(10)||0));
  if(act.indexOf('check:')===0) return checkChallenge(Number(act.slice(6)||0));
  return openMap();
}
function bind(){
  if(window.__LR76A_SHIPWRECK_BIND__) return; window.__LR76A_SHIPWRECK_BIND__=true;
  window.addEventListener('click', function(ev){ var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr76a-act]') : null; if(!el) return; ev.preventDefault(); /* 7.6W: do not swallow normal clicks */ route(el.getAttribute('data-lr76a-act')); }, true);
}
function injectDoor(){
  var root=byId('actionText'); if(!root || byId('lr76aInjectedShipwreckDoor')) return;
  if(root.querySelector && root.querySelector('.lr76aShell')) return;
  var text=(root.textContent||'');
  if(!/(History and World|World Directory|Realm Library|Connection Ledger|Shipwreck)/i.test(text)) return;
  var panel=document.createElement('div'); panel.id='lr76aInjectedShipwreckDoor'; panel.className='lr76aInject';
  panel.innerHTML='<button data-lr76a-act="map"><span>⚓</span><b>Shipwreck Cove Deep Rebuild</b><small>Maritime history · lighthouses · storms · rescue · archaeology · pirates</small><i>Open ›</i></button>';
  try{ root.appendChild(panel); }catch(e){}
}
function patchObviousShipwreckButtons(){
  try{
    Array.prototype.slice.call(document.querySelectorAll('button')).forEach(function(btn){
      if(btn.closest && btn.closest('.lr76aShell')) return;
      var text=(btn.textContent||'').replace(/\s+/g,' ').trim();
      if(text.length < 90 && /Shipwreck Cove|Shipwreck|Cove/i.test(text) && !/History and World|World Directory|Realm Library|Connection Ledger|Bible|Science|Core|Creative|Homestead/i.test(text)){
        btn.setAttribute('data-lr76a-act','map');
      }
    });
  }catch(e){}
}
function boot(){
  installStyles(); bind(); injectDoor(); patchObviousShipwreckButtons();
  try{ var mo=new MutationObserver(function(){ injectDoor(); patchObviousShipwreckButtons(); }); mo.observe(document.body,{childList:true,subtree:true}); }catch(e){}
  setTimeout(injectDoor,250); setTimeout(patchObviousShipwreckButtons,400); setTimeout(injectDoor,1000);
}
function installStyles(){
  if(byId('lr76aShipwreckStyles')) return;
  var st=document.createElement('style'); st.id='lr76aShipwreckStyles'; st.textContent = `
.lr76aShell{font-family:inherit;color:#17303a}.lr76aHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;margin:0 0 14px;border-radius:18px;background:linear-gradient(135deg,#102f3d,#1d6678 58%,#ead08a);color:#fff;border:2px solid rgba(255,227,159,.55);box-shadow:0 10px 24px rgba(0,0,0,.14)}.lr76aHero h2{margin:.1rem 0 .45rem;color:#fff}.lr76aHero p,.lr76aHero small{color:#fff9e8;line-height:1.45}.lr76aHeroIcon{font-size:2.6rem;filter:drop-shadow(0 2px 2px rgba(0,0,0,.25))}.lr76aBar{height:12px;border-radius:99px;background:rgba(255,255,255,.32);overflow:hidden;margin:9px 0}.lr76aBar i{display:block;height:100%;background:linear-gradient(90deg,#ffe17b,#7ee3ff)}.lr76aPanel,.lr76aReading,.lr76aQuestion,.lr76aChoice{background:linear-gradient(180deg,#fffdf6,#f7efdf);border:1px solid rgba(62,87,98,.2);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 5px 14px rgba(10,32,42,.08)}.lr76aReading p{line-height:1.72;margin:.82rem 0;font-size:1.01rem}.lr76aPanel p{line-height:1.5}.lr76aRoomGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(235px,1fr));gap:10px}.lr76aGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}.lr76aRoomCard,.lr76aChamberCard{display:grid;grid-template-columns:auto 1fr auto;gap:10px;text-align:left;width:100%;padding:12px;border-radius:15px;border:1px solid rgba(33,65,82,.22);background:#fffaf0;box-shadow:0 2px 0 rgba(0,0,0,.07);cursor:pointer;color:#1d3340}.lr76aRoomCard span,.lr76aChamberCard span{font-size:1.8rem;grid-row:span 3}.lr76aRoomCard b,.lr76aChamberCard b{display:block}.lr76aRoomCard p,.lr76aChamberCard p{margin:.25rem 0;line-height:1.38}.lr76aRoomCard small,.lr76aChamberCard small{color:#46616b}.lr76aChamberCard.done{background:linear-gradient(180deg,#f2fff5,#e7f7ec);border-color:#73a77b}.lr76aNav{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.lr76aNav button,.lr76aPanel button,.lr76aPrimary{border:1px solid rgba(33,65,82,.28);border-radius:12px;background:#fffaf0;padding:9px 12px;font-weight:800;cursor:pointer;box-shadow:0 2px 0 rgba(0,0,0,.08);color:#1d3340}.lr76aPrimary,.lr76aNav .lr76aPrimary{background:#ffd86f!important;border-color:#926a05!important}.lr76aQuestion b{display:block;margin-bottom:7px}.lr76aChoices{display:grid;gap:7px;margin-top:9px}.lr76aChoices label{display:block;padding:8px 10px;border-radius:10px;background:#f9fbfc;border:1px solid rgba(54,76,90,.16);line-height:1.35}.lr76aRewards{display:flex;flex-wrap:wrap;gap:8px}.lr76aReward{display:inline-block;padding:7px 10px;border-radius:999px;border:1px solid rgba(73,82,93,.22);background:#eef3f4}.lr76aReward.got{background:#fff0af;border-color:#bc8b19;font-weight:800}.lr76aInject{margin:10px 0}.lr76aInject button{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:center;width:100%;padding:12px;border-radius:15px;background:#f0fbff;border:1px solid #7db7c8;color:#15333e;cursor:pointer}.lr76aInject span{font-size:1.8rem}.lr76aInject small{display:block;color:#41606c}.lr76aChoice{border-left:5px solid #1f7b92;background:#eef9fb}@media(max-width:760px){.lr76aHero{grid-template-columns:1fr}.lr76aRoomCard,.lr76aChamberCard{grid-template-columns:1fr}.lr76aRoomCard span,.lr76aChamberCard span{grid-row:auto}}
  `; document.head.appendChild(st);
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
window.__LR_SHIPWRECK_COVE_COURSE_76A__ = {title:'Shipwreck Cove Deep Rebuild Part 1', chambers:CHAMBERS, rooms:ROOMS};
window.openShipwreckCoveDeepCourse = openMap;
window.openShipwreckCoveMap = openMap;
window.shipwreckGuidedZoneOpen = openMap;
window.shipwreckGuidedZoneContinue = function(){ var s=state(); if(typeof s.topic==='number') return openTopic(s.topic, s.page||0); return openMap(); };
window.shipwreckGuidedZoneMap = openMap;
window.shipwreckGuidedZoneMove = function(id){ return openRoom(id || (state().room || 'pier')); };
window.shipwreckGuidedZoneTalk = merchant;
window.openShipwreckCoveRewardCatalog = rewards;
window.openShipwreckCoveKeeper76A = merchant;
window.shipwreckOpenTopic = openTopic;
window.shipwreckOpenQuiz = openChallenge;
window.shipwreckCheckQuiz = checkChallenge;
window.shipwreckCoveTravel = openRoom;
window.shipwreckCoveInspect = function(id){ if(typeof id==='number') return inspectRoomIndex(id); return inspectPlace(id||'pier'); };
window.openShipwreckCoveDeepRebuild76A = openMap;
})();
