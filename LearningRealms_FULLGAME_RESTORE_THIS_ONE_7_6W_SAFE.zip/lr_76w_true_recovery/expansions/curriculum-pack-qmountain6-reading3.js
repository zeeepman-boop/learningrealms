// Question Mountain Phase 6 - Reading Deepening III
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Reading",[
{teach:"Titles tell about stories.",q:"A title tells about the...",c:["story","weather","coins"],a:"story"},
{teach:"Readers can retell stories.",q:"Retelling means...",c:["telling again","drawing only","counting"],a:"telling again"},
{teach:"Stories have problems.",q:"Stories can have...",c:["problems","mountains only","maps"],a:"problems"},
{teach:"Stories have solutions.",q:"Problems may have...",c:["solutions","coins","covers"],a:"solutions"},
{teach:"Readers ask questions.",q:"Readers can ask...",c:["questions","equations","trades"],a:"questions"}
]);

LR_addLessons("Ava","Reading",[
{teach:"Authors organize ideas.",q:"Authors organize...",c:["ideas","clouds","coins"],a:"ideas"},
{teach:"Text features help readers.",q:"Headings are text...",c:["features","equations","maps"],a:"features"},
{teach:"Main idea uses details.",q:"Main idea is supported by...",c:["details","weather","titles"],a:"details"},
{teach:"Readers infer meaning.",q:"Inference uses clues plus...",c:["thinking","luck","trading"],a:"thinking"},
{teach:"Sources may differ.",q:"Sources can...",c:["differ","freeze","sleep"],a:"differ"}
]);

LR_addLessons("Michael","Reading",[
{teach:"Arguments use evidence.",q:"Arguments need...",c:["evidence","covers","maps"],a:"evidence"},
{teach:"Authors may persuade.",q:"Persuasive texts try to...",c:["convince","count","measure"],a:"convince"},
{teach:"Word choice affects tone.",q:"Word choice affects...",c:["tone","weather","trade"],a:"tone"},
{teach:"Texts may contain claims.",q:"Claims should be...",c:["evaluated","ignored","colored"],a:"evaluated"},
{teach:"Readers synthesize ideas.",q:"Synthesize means...",c:["combine ideas","erase","sleep"],a:"combine ideas"}
]);
})();