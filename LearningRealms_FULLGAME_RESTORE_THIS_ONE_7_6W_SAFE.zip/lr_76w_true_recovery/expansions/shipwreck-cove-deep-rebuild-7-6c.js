/* LearningRealms 7.6C - Shipwreck Cove Deep Rebuild Part 2
   Additive content patch built from 7.6B. No shell rebuild, no render loop, no loading curtain.
   Purpose: add a second wave of rich Shipwreck Cove chambers, rewards, route bridges, and kid-safe maritime mystery. */
(function(){
'use strict';
if(window.__LR76C_SHIPWRECK_COVE_PART2__) return;
window.__LR76C_SHIPWRECK_COVE_PART2__ = true;

var PATCH = '7.6C Shipwreck Cove Deep Rebuild Part 2';
var STORAGE = 'lr76c_shipwreck_cove_part2_state_v1';
var oldPart1Map = (typeof window.openShipwreckCoveDeepRebuild76A === 'function') ? window.openShipwreckCoveDeepRebuild76A : ((typeof window.openShipwreckCoveDeepCourse === 'function') ? window.openShipwreckCoveDeepCourse : null);
var oldPart1Rewards = (typeof window.openShipwreckCoveRewardCatalog === 'function') ? window.openShipwreckCoveRewardCatalog : null;

var CHAMBERS = [
  {
    id:'ghost-captain-cabin', icon:'📜', title:"Ghost Captain's Cabin: Logs, Clues, and Quiet Questions", room:"Ghost Captain's Cabin", area:'Logbook Deck',
    reward:'Sea Log Decoder Badge', token:'Blue Ink Logbook Token', companion:'Ghost Gull Companion',
    summary:'A gentle mystery chamber where ship logs, bearings, cargo notes, watches, and weather entries are used to rebuild a voyage without turning the past into a spooky guessing game.',
    scene:'A friendly blue lantern glows over a captain’s desk. The cabin has no jump scares, only a folded chart, a brass clock, a wet boot print by the door, and a logbook with several careful entries.',
    main:'A ship log is a working record of a voyage. It may include position, course, speed, weather, sails or engines, cargo, repairs, signals, watches, and unusual events, so it can be more useful than a dramatic legend.',
    records:'captain’s logs, deck logs, engine room notes, watch schedules, cargo manifests, harbor clearance papers, chart marks, bell times, signal records, and later inquiry summaries',
    tools:'marine clocks, compasses, parallel rules, pencils, log lines, speed estimates, barometers, signal lamps, and simple timeline boards',
    science:'time, direction, distance, speed, wind, current, fuel, cargo weight, and crew watches all affect how a vessel moves and what choices are available',
    safety:'good logkeeping helps later crews see what changed, when the danger began, which warnings were noticed, and which choices could be improved next time',
    specific:'A logbook is strongest when its entries line up with charts, weather reports, cargo lists, and witness accounts. The cove never treats one lonely clue as the whole answer.',
    choice:'choose the weather entry, the course line, or the cargo note, then decide which other record should be checked before making a claim',
    inspect:'The desk drawer opens with a soft click. Inside is a slate that says, A mystery is not solved by the loudest tale; it is solved by the clues that can stand together.'
  },
  {
    id:'great-lakes-gale-room', icon:'🌊', title:'Great Lakes Gale Room: Inland Seas and Hard Weather', room:'Great Lakes Gale Room', area:'Freshwater Storm Wing',
    reward:'Inland Sea Storm Pin', token:'Lake Freighter Rivet Token', companion:'Lighthouse Cat Companion',
    summary:'A Great Lakes chamber about long freshwater routes, sudden gales, steep waves, iron ore freighters, shore stations, and why lakes can behave like inland seas.',
    scene:'A huge lake map covers the wall. Blue lights mark Superior, Michigan, Huron, Erie, and Ontario, while a model freighter waits beside wind arrows and a quiet memorial lantern.',
    main:'The Great Lakes are freshwater lakes, but they are so large that sailors often call them inland seas. Long fetch, cold water, fast weather changes, narrow passages, and heavy cargo can create serious hazards.',
    records:'lake charts, storm warnings, lighthouse logs, freighter loading records, radio messages, harbor reports, weather maps, survivor memories from older wrecks, and respectful memorial records',
    tools:'barometers, wave reports, radios, radar, lighthouse signals, harbor lights, loading marks, bilge pumps, life jackets, and shore rescue coordination boards',
    science:'wind blowing across a long stretch of open water builds waves; shallow areas can steepen them; cold water lowers survival time; and heavy cargo affects stability and how a ship rides through weather',
    safety:'lake routes need the same serious planning as ocean routes: weather margins, loading care, communication, shelter choices, watchkeeping, and respect for warnings',
    specific:'The freighter Edmund Fitzgerald sank on Lake Superior during a severe storm on November 10, 1975. The chamber handles that history quietly, focusing on weather, shipping, inquiry, memory, and safer habits.',
    choice:'compare the storm warning board, the cargo loading card, or the lighthouse log before choosing whether the model freighter should hold course, slow down, or seek shelter',
    inspect:'The lake model has tiny whitecaps carved into the surface. Captain Brine points out that freshwater can still be fierce water when wind, distance, cold, and cargo meet.'
  },
  {
    id:'lighthouse-keepers-workshop', icon:'💡', title:"Lighthouse Keeper's Workshop: Lenses, Lamps, and Fog Signals", room:"Lighthouse Keeper's Workshop", area:'Beacon Loft',
    reward:'Fresnel Lens Apprentice Badge', token:'Polished Lens Token', companion:'Beacon Moth Companion',
    summary:'A lighthouse chamber about Fresnel lenses, lamp rooms, flash patterns, fog signals, maintenance, keeper routines, and how a light becomes a message at sea.',
    scene:'Glass prisms shine in a circle above a workbench. Oil cans, wicks, polishing cloths, clockwork gears, foghorn cards, and a keeper’s notebook sit in neat rows.',
    main:'A lighthouse is not just a tall building with a bright lamp. It is a navigation aid with a known location, height, light pattern, range, maintenance record, and connection to charts used by mariners.',
    records:'light lists, keeper logs, lamp maintenance notes, lens orders, fog signal schedules, chart symbols, weather entries, and reports from ships passing the station',
    tools:'Fresnel lenses, lamps, reflectors, clockwork turning systems, fog bells, foghorns, signal flags, oil or fuel stores, cleaning cloths, and height measurements',
    science:'a Fresnel lens bends and concentrates light so a lamp can be seen farther away; flash patterns help sailors identify one light from another; fog can block sight even when the lamp is working',
    safety:'clear light patterns and fog signals help vessels fix their position, avoid rocks or shoals, enter harbors carefully, and know when visibility has become dangerous',
    specific:'Different lighthouses can have different characteristics, such as fixed lights, flashing lights, colored sectors, or timed patterns. The pattern turns the light into an address on the coast.',
    choice:'polish the lens, wind the clockwork, or compare the fog signal card to the chart before sending the keeper’s warning out across the cove',
    inspect:'A small brass tag hangs from the lens rail. It says, Bright is helpful, but known, timed, clean, and charted is what makes a beacon trustworthy.'
  },
  {
    id:'preservation-vault', icon:'🏺', title:'Preservation Vault: Treasure Myths and Real Archaeology', room:'Preservation Vault', area:'Museum Care Vault',
    reward:'Context Keeper Seal', token:'Numbered Museum Tag Token', companion:'Archivist Hermit Crab Companion',
    summary:'A museum-care chamber that separates treasure stories from real preservation, context, permits, conservation, careful labels, and respect for protected wreck sites.',
    scene:'A locked glass case holds plain-looking tags, not piles of gold. A water tank keeps a small iron fitting stable while a map grid shows exactly where each object was recorded.',
    main:'Real wreck archaeology is not a race to grab objects. The location, layer, angle, nearby items, damage, sediment, and records can matter as much as the object itself.',
    records:'site grids, object numbers, photo logs, dive notes, permit records, conservation reports, museum labels, storage conditions, legal protection notes, and publication summaries',
    tools:'measuring tapes, underwater cameras, waterproof labels, conservation tanks, brushes, desalination tubs, database entries, acid-free tags, and controlled storage shelves',
    science:'saltwater can soak into wood and metal; drying an artifact too quickly can crack, crumble, or corrode it; conservation slows damage so evidence can be studied and shared responsibly',
    safety:'protected sites need permission, patient recording, and careful conservation because careless collecting can damage habitats, destroy context, and erase the best part of the evidence',
    specific:'An artifact without context is like a puzzle piece with the picture scraped off. It may still be interesting, but the strongest story has been weakened.',
    choice:'number the object tag, sketch the grid square, or leave the fragile fitting in its water tank until the conservation plan is ready',
    inspect:'The vault key is tied to a wooden label instead of a jewel. The label reads, The true treasure is the story that can still be proven.'
  },
  {
    id:'storm-survivor-table', icon:'🧭', title:"Storm Survivor's Planning Table: Order, Warmth, and Signals", room:"Storm Survivor's Planning Table", area:'Rescue Planning Annex',
    reward:'Calm Order Rescue Card', token:'Signal Whistle Token', companion:'Harbor Seal Pup Companion',
    summary:'A rescue planning chamber about cold water, flotation, signals, muster lists, staying calm, shelter, radio calls, and the order rescuers need when weather is bad.',
    scene:'A sturdy table holds a blanket roll, signal mirror, whistle, small radio, life jacket diagram, muster list, and a model lifeboat with every seat numbered.',
    main:'Survival planning at sea is not about panic. It is about flotation, warmth, signals, head counts, clear roles, emergency gear, and quick communication before confusion spreads.',
    records:'muster lists, drill records, radio distress logs, lifeboat capacity cards, rescue station notes, weather warnings, passenger counts, and after-action reports',
    tools:'life jackets, immersion protection in cold regions, whistles, signal mirrors, flares where appropriate, radios, blankets, lifeboats, rafts, heaving lines, and rescue checklists',
    science:'cold water pulls heat from the body quickly; flotation keeps airways above water; bright colors and signals improve visibility; and organized movement keeps a small emergency from becoming worse',
    safety:'the safest rescue plan is practiced before trouble: know the muster place, put on flotation correctly, keep people counted, signal clearly, and avoid wasting energy',
    specific:'A calm checklist is not boring in an emergency. It protects memory when fear is high and gives everyone one next useful action.',
    choice:'sort the muster list, check the life jacket fit card, or send a clear radio message before the weather chart turns red',
    inspect:'The table has a carved compass rose with four words around it: float, warm, signal, count. Captain Brine says those words belong in that order for a reason.'
  },
  {
    id:'ice-patrol-rulebook-hall', icon:'📘', title:'Ice Patrol and Rulebook Hall: What Wrecks Changed', room:'Ice Patrol and Rulebook Hall', area:'Safety Rules Gallery',
    reward:'Blue Rulebook Lantern', token:'Ice Watch Token', companion:'Compass Tern Companion',
    summary:'A safety history chamber about how inquiries, wireless watches, lifeboat rules, ice patrols, training, and international agreements changed after major maritime disasters.',
    scene:'Blue rulebooks line the wall beside an ice chart, a wireless headset, a lifeboat plan, and a lantern labeled, Memory should become protection.',
    main:'After major wrecks, investigators often ask what rule, tool, training, signal, watch, inspection, or design practice could reduce the chance of the same pattern happening again.',
    records:'inquiry testimony, safety recommendations, lifeboat regulations, wireless watch rules, ice reports, training manuals, inspection forms, route notices, and international agreements',
    tools:'wireless radio, distress procedures, lifeboat drills, ice patrol reports, route warnings, inspection checklists, watertight door rules, and emergency training plans',
    science:'ice movement, visibility, radio range, hull strength, evacuation time, human attention, and communication delays all affect whether a warning becomes action quickly enough',
    safety:'the chamber connects memory to prevention by showing how evidence can become better rules, stronger habits, clearer warnings, and safer equipment',
    specific:'After Titanic, maritime safety discussions helped strengthen lifeboat expectations, wireless communication practices, ice monitoring, and international safety rules. The cove focuses on the protective changes, not shock value.',
    choice:'compare the ice chart, the wireless watch card, or the lifeboat drill sheet before deciding which rule would protect the next voyage most directly',
    inspect:'The final hall is quiet. A blue lantern shines on the words, A rule written after sorrow should be used before danger returns.'
  }
];

var ROOMS = [
  {id:'cabin', icon:'📜', title:"Ghost Captain's Cabin", desc:'Logbooks, bearings, watches, and quiet clues turn a gentle mystery into a careful investigation.', chambers:[0]},
  {id:'greatlakes', icon:'🌊', title:'Great Lakes Gale Room', desc:'Freshwater routes, hard weather, freighter loading, shore lights, and inland-sea warnings live here.', chambers:[1]},
  {id:'keeper', icon:'💡', title:"Lighthouse Keeper's Workshop", desc:'Lens work, lamp care, fog signals, flash patterns, and keeper records explain how a beacon speaks.', chambers:[2]},
  {id:'vault', icon:'🏺', title:'Preservation Vault', desc:'Museum tags, conservation tanks, site grids, and protected-wreck ethics replace treasure grabbing.', chambers:[3]},
  {id:'survivor', icon:'🧭', title:"Storm Survivor's Planning Table", desc:'Flotation, warmth, signals, head counts, radio messages, and calm checklists guide this rescue annex.', chambers:[4]},
  {id:'rules', icon:'📘', title:'Ice Patrol and Rulebook Hall', desc:'Inquiries, wireless watches, lifeboat rules, ice monitoring, and training show how memory becomes safety.', chambers:[5]}
];

function byId(id){ return document.getElementById(id); }
function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g,function(ch){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];}); }
function has(fn){ return typeof window[fn] === 'function'; }
function state(){ try{ return JSON.parse(localStorage.getItem(STORAGE) || '{}') || {}; }catch(e){ return {}; } }
function save(s){ try{ localStorage.setItem(STORAGE, JSON.stringify(s || {})); }catch(e){} }
function titleBox(){ return byId('actionTitle') || byId('mainTitle') || byId('lessonTitle'); }
function mainBox(){ return byId('actionText') || byId('mainInteraction') || byId('lessonContent') || byId('output'); }
function setFeedback(msg){ var f=byId('feedback'); if(f) f.textContent = msg || ''; }
function mount(title, html){
  installStyles();
  var t=titleBox(), b=mainBox(), lb=byId('lessonBox'), sb=byId('storageBox');
  if(t) t.textContent = title || 'Shipwreck Cove';
  if(b) b.innerHTML = html || '';
  if(lb) lb.classList.add('hidden');
  if(sb) sb.classList.add('hidden');
  setFeedback('');
  try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){}
  try{ if(b && b.scrollIntoView) b.scrollIntoView({block:'start', behavior:'smooth'}); }catch(e){}
}
function progress(){ var s=state(), mastered=s.mastered || {}; var count=0; CHAMBERS.forEach(function(c){ if(mastered[c.id]) count++; }); return {count:count,total:CHAMBERS.length,pct:Math.round((count/CHAMBERS.length)*100)}; }
function roomById(id){ for(var i=0;i<ROOMS.length;i++) if(ROOMS[i].id===id) return ROOMS[i]; return ROOMS[0]; }
function chamberById(id){ for(var i=0;i<CHAMBERS.length;i++) if(CHAMBERS[i].id===id) return CHAMBERS[i]; return CHAMBERS[0]; }
function chamberIndex(id){ for(var i=0;i<CHAMBERS.length;i++) if(CHAMBERS[i].id===id) return i; return 0; }
function award(name, amount){
  var s=state(); s.items=s.items||[]; if(s.items.indexOf(name)<0) s.items.push(name); save(s);
  try{ if(typeof window.LR_merchantAwardCurrency==='function') window.LR_merchantAwardCurrency('seaGlass', amount || 1, name); }catch(e){}
  return name;
}
function part1Count(){ try{ return (window.__LR_SHIPWRECK_COVE_COURSE_76A__ && window.__LR_SHIPWRECK_COVE_COURSE_76A__.chambers && window.__LR_SHIPWRECK_COVE_COURSE_76A__.chambers.length) || 8; }catch(e){ return 8; } }
function buildPages(t){
  return [
    [
      t.scene + ' This room keeps the cove’s ghostly flavor gentle and useful, so the mystery comes from evidence instead of scare tricks.',
      t.main + ' Captain Brine asks the player to slow down and notice which details are records, which are physical clues, and which are only guesses.',
      'The chamber belongs to ' + t.area + ', but it also connects with history, geography, science, engineering, and practical decision making. Maritime stories often cross more than one subject because ships move through weather, maps, rules, tools, cargo, and human choices.',
      t.specific + ' The first page therefore starts with a question: what can be proven from the room, and what still needs another clue?'
    ],
    [
      'The record shelf holds ' + t.records + '. Each record is more useful when it stays tied to date, place, vessel, route, and purpose.',
      'A good cove explorer compares sources instead of grabbing the loudest story. A log may show time, a chart may show location, a signal may show warning, and an inquiry may show what people understood later.',
      'Some evidence is humble. A tag, a note, a scratch on a model hull, or a quiet weather entry may matter more than a shiny object because it helps place the story in order.',
      'For the room choice, the player can ' + t.choice + '. That turns reading into a small investigation with a reason to inspect the room carefully.'
    ],
    [
      'The tool bench includes ' + t.tools + '. These tools give the chamber a practical backbone instead of leaving it as a pretend pirate corner.',
      t.science.charAt(0).toUpperCase() + t.science.slice(1) + '. The cove uses that science in plain language so the player can explain cause and effect without needing an advanced textbook.',
      'Numbers can matter here too. Time, distance, depth, speed, direction, temperature, cargo amount, capacity, and sequence can all change the meaning of a maritime clue.',
      'Captain Brine points out that tools do not remove judgment. They help a careful person ask better questions, compare possibilities, and know when the evidence is still incomplete.'
    ],
    [
      'The safety wall in this room stays calm. It does not use wreck history for shock. It asks how a hard event became a better warning, better tool, better record, better habit, or better rule.',
      t.safety.charAt(0).toUpperCase() + t.safety.slice(1) + '. That makes the chamber useful even when the subject is serious.',
      'The kid-safe rule for this wing is simple: no gruesome detail, no glorifying cruelty, and no treasure-grabbing message. The focus stays on evidence, preservation, rescue, navigation, weather, engineering, and respect.',
      'By the end of the safety page, the player should be able to explain what the room protects: not just a ship story, but a smarter way to travel, build, signal, preserve, or remember.'
    ],
    [
      'The final page gives the player a cove task instead of a flat ending. The room asks for one claim, one clue that supports it, and one second clue that would make the claim stronger.',
      'The mastery artifact is the ' + t.reward + '. It is earned only after the proof challenge, so the shelf shows reading and careful thinking instead of random clicking.',
      'The inspection token is the ' + t.token + '. The companion hook for this chamber is the ' + t.companion + ', saved as a future reward idea for the Cove shopkeeper and collection systems.',
      'After the chamber, the player can return to the Part 2 map, open the Part 1 cove, visit the artifact shelf, or continue into another room. The cove feels open, but the learning stays anchored.'
    ]
  ];
}
function quizFor(t){
  return [
    {q:'What makes this chamber more than a random sea story?', a:'It uses records, tools, science, safety ideas, and connected clues to explain maritime history.', d:['It asks the player to grab treasure without recording anything.','It hides the subject inside an unrelated classroom menu.','It rewards guessing without reading the chamber pages.'], why:t.summary},
    {q:'Which record group belongs in this chamber?', a:t.records + '.', d:['Only a loose jewel with no label.','Only a monster drawing with no location.','Only a blank button that says Continue.'], why:'The record shelf names the evidence used in the room.'},
    {q:'Which tool group helps the room make sense?', a:t.tools + '.', d:['A crown, a trumpet, and an unrelated trophy.','A plain sticker with no chart or label.','A pretend key that opens no evidence case.'], why:'The tool bench gives the chamber its practical backbone.'},
    {q:'What science or cause-and-effect idea matters here?', a:t.science + '.', d:['Water, weather, time, and design never affect ships.','Records do not need dates, places, or routes.','A single rumor proves the whole story.'], why:'The science line explains the real-world force or system in the chamber.'},
    {q:'What safety or respect idea does the room protect?', a:t.safety + '.', d:['Wreck history should be used for shock.','Safety warnings are decorations.','Careful records make a story weaker.'], why:'The safety wall explains why this room belongs in a kid-safe maritime course.'},
    {q:'Which reward is earned after mastering this chamber?', a:t.reward + '.', d:['A random filler coin.','An unrelated spelling badge.','A blank reward with no room name.'], why:'The mastery artifact is ' + t.reward + '.'}
  ].map(function(q, qi){ return rotateQuestion(q, qi); });
}
function rotateQuestion(q, qi){ var choices=[q.a].concat(q.d), offset=(qi*3+1)%choices.length, out=[]; for(var i=0;i<choices.length;i++) out.push(choices[(i+offset)%choices.length]); return {q:q.q, choices:out, a:out.indexOf(q.a), why:q.why}; }
function bar(){ var p=progress(); return '<div class="lr76cBar"><i style="width:'+p.pct+'%"></i></div><small>Part 2: '+p.count+' / '+p.total+' chambers mastered · '+p.pct+'%</small>'; }
function topNav(extra){ return '<div class="lr76cNav"><button data-lr76c-act="map">Part 2 map</button><button data-lr76c-act="part1">Part 1 cove</button><button data-lr76c-act="rewards">Artifact shelf</button><button data-lr76c-act="review">Review shelf</button><button data-lr76c-act="merchant">Cove keeper</button>'+(extra||'')+'</div>'; }
function openPart1(){ if(oldPart1Map && oldPart1Map !== openMap){ return oldPart1Map(); } return openMap(); }
function openMap(){
  var p=progress(), s=state(), mastered=s.mastered||{};
  var roomCards = ROOMS.map(function(r){ var chamberList = r.chambers.map(function(i){ var c=CHAMBERS[i]; return c.icon+' '+c.title; }).join(' · '); return '<button class="lr76cRoomCard" data-lr76c-act="room:'+esc(r.id)+'"><span>'+esc(r.icon)+'</span><b>'+esc(r.title)+'</b><p>'+esc(r.desc)+'</p><small>'+esc(chamberList)+'</small><i>Enter ›</i></button>'; }).join('');
  var chamberCards = CHAMBERS.map(function(c,i){ var done=!!mastered[c.id]; return '<button class="lr76cChamberCard '+(done?'done':'')+'" data-lr76c-act="topic:'+i+':0"><span>'+esc(c.icon)+'</span><b>'+esc(c.title)+'</b><p>'+esc(c.summary)+'</p><small>'+esc(c.reward)+(done?' ✓':'')+'</small></button>'; }).join('');
  mount('⚓ Shipwreck Cove', '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">⚓</div><div><h2>Shipwreck Cove Deep Rebuild, Part 2</h2><p>The cove now has a second rich wing: ghost-cabin logbooks, Great Lakes weather, lighthouse keeper work, preservation ethics, storm survival planning, and safety rule history. Part 1 remains one button away.</p>'+bar()+'</div></section><section class="lr76cPanel lr76cNotice"><b>Connected Cove:</b> Part 1 has '+part1Count()+' chambers. Part 2 adds '+CHAMBERS.length+' more chambers, new artifact hooks, and future companion ideas without changing the shell.</section><section class="lr76cPanel"><h3>Choose a new cove place</h3><p>Every room is written as an in-world maritime adventure chamber, not a school menu or placeholder drawer.</p><div class="lr76cRoomGrid">'+roomCards+'</div></section><section class="lr76cPanel"><h3>Part 2 chambers</h3><p>Each chamber has 5 pages, 4 substantial paragraphs per page, a room inspection, an artifact reward, and 6 proof-of-reading questions.</p><div class="lr76cGrid">'+chamberCards+'</div></section>'+topNav('<button data-lr76c-act="history">History Wing</button>')+'</div>');
}
function openRoom(id){
  var r=roomById(id), s=state(); s.room=id; save(s);
  var cards = r.chambers.map(function(i){ var c=CHAMBERS[i]; return '<button class="lr76cChamberCard" data-lr76c-act="topic:'+i+':0"><span>'+esc(c.icon)+'</span><b>'+esc(c.title)+'</b><p>'+esc(c.summary)+'</p><small>Reward: '+esc(c.reward)+'</small></button>'; }).join('');
  var other = ROOMS.filter(function(x){return x.id!==r.id;}).map(function(x){return '<button data-lr76c-act="room:'+esc(x.id)+'">'+esc(x.icon+' '+x.title)+'</button>';}).join('');
  mount(esc(r.icon+' '+r.title), '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">'+esc(r.icon)+'</div><div><h2>'+esc(r.title)+'</h2><p>'+esc(r.desc)+'</p>'+bar()+'</div></section><section class="lr76cPanel"><h3>Room inspection</h3><p>'+esc(CHAMBERS[r.chambers[0]].inspect)+'</p><button class="lr76cPrimary" data-lr76c-act="inspect:'+esc(r.id)+'">Inspect carefully</button></section><section class="lr76cPanel"><h3>Chambers here</h3><div class="lr76cGrid">'+cards+'</div></section><section class="lr76cPanel"><h3>Travel choices</h3><div class="lr76cNav">'+other+'</div></section>'+topNav()+'</div>');
}
function openTopic(i,p){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0)); p=Math.max(0, Math.min(4, Number(p)||0));
  var c=CHAMBERS[i], pages=buildPages(c), paras=pages[p], s=state(); s.topic=i; s.page=p; save(s);
  var prev = p>0 ? '<button data-lr76c-act="topic:'+i+':'+(p-1)+'">◀ Previous page</button>' : '<button data-lr76c-act="map">Part 2 map</button>';
  var next = p<4 ? '<button class="lr76cPrimary" data-lr76c-act="topic:'+i+':'+(p+1)+'">Next page ▶</button>' : '<button class="lr76cPrimary" data-lr76c-act="challenge:'+i+'">Enter proof challenge</button>';
  mount(c.icon+' '+c.title, '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">'+esc(c.icon)+'</div><div><h2>'+esc(c.title)+'</h2><p>'+esc(c.room)+' · Page '+(p+1)+' of 5 · '+esc(c.area)+'</p>'+bar()+'</div></section><article class="lr76cReading"><h3>'+esc(['Entering the room','Record shelf','Tools and science','Safety and respect','Artifact and route choice'][p])+'</h3>'+paras.map(function(x){return '<p>'+esc(x)+'</p>';}).join('')+'</article><div class="lr76cChoice"><b>Room choice:</b> '+esc(c.choice)+'</div><div class="lr76cNav">'+prev+'<button data-lr76c-act="inspectroom:'+i+'">Inspect room</button>'+next+'</div>'+topNav()+'</div>');
}
function inspectRoomIndex(i){ var c=CHAMBERS[Math.max(0,Math.min(CHAMBERS.length-1,Number(i)||0))]; var found=award(c.token,1); mount('🔎 Inspect '+c.room, '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">🔎</div><div><h2>'+esc(c.room)+'</h2><p>'+esc(c.inspect)+'</p></div></section><section class="lr76cPanel"><h3>Found exploration token</h3><p><b>'+esc(found)+'</b></p><p>This token proves the room was inspected instead of skipped. It is stored on the Part 2 artifact shelf.</p></section><div class="lr76cNav"><button class="lr76cPrimary" data-lr76c-act="topic:'+chamberIndex(c.id)+':'+((state().page||0))+'">Return to chamber</button><button data-lr76c-act="rewards">Artifact shelf</button></div></div>'); }
function inspectPlace(id){ var r=roomById(id); var found=award(r.icon+' '+r.title+' Room Token',1); mount('🔎 Inspect '+r.title, '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">'+esc(r.icon)+'</div><div><h2>'+esc(r.title)+'</h2><p>'+esc(r.desc)+'</p></div></section><section class="lr76cPanel"><h3>Found room token</h3><p><b>'+esc(found)+'</b></p><p>Captain Brine adds it to the shelf as proof that this new part of the cove was explored.</p></section><div class="lr76cNav"><button class="lr76cPrimary" data-lr76c-act="room:'+esc(r.id)+'">Return to room</button><button data-lr76c-act="rewards">Artifact shelf</button></div></div>'); }
function openChallenge(i){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0)); var c=CHAMBERS[i], qs=quizFor(c);
  var html = '<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">'+esc(c.icon)+'</div><div><h2>Proof challenge: '+esc(c.title)+'</h2><p>Answer from the chamber pages. The goal is careful reading, not random clicking.</p></div></section>' + qs.map(function(q,qi){ return '<div class="lr76cQuestion"><b>Question '+(qi+1)+':</b> '+esc(q.q)+'<div class="lr76cChoices">'+q.choices.map(function(choice,ci){ return '<label><input type="radio" name="lr76cq_'+qi+'" value="'+ci+'"> '+esc(choice)+'</label>'; }).join('')+'</div></div>'; }).join('') + '<div class="lr76cNav"><button data-lr76c-act="topic:'+i+':0">Review chamber</button><button class="lr76cPrimary" data-lr76c-act="check:'+i+'">Check challenge</button></div></div>';
  mount('Shipwreck Cove Challenge', html);
}
function checkChallenge(i){
  i=Math.max(0, Math.min(CHAMBERS.length-1, Number(i)||0)); var c=CHAMBERS[i], qs=quizFor(c), score=0, missed=[];
  qs.forEach(function(q, qi){ var el=document.querySelector('input[name="lr76cq_'+qi+'"]:checked'); var val=el?Number(el.value):-1; if(val===q.a) score++; else missed.push({chamber:c.title, answer:q.choices[q.a], why:q.why}); });
  var s=state(); s.missed=(s.missed||[]).concat(missed).slice(-180);
  if(score===qs.length){ s.mastered=s.mastered||{}; s.mastered[c.id]=true; s.rewards=s.rewards||[]; if(s.rewards.indexOf(c.reward)<0) s.rewards.push(c.reward); s.companions=s.companions||[]; if(s.companions.indexOf(c.companion)<0) s.companions.push(c.companion); award(c.reward,3); award(c.companion,1); }
  save(s);
  var review = missed.map(function(m){ return '<li><b>'+esc(m.answer)+'</b><br><small>'+esc(m.why)+'</small></li>'; }).join('');
  var nextBtn = i < CHAMBERS.length-1 ? '<button class="lr76cPrimary" data-lr76c-act="topic:'+(i+1)+':0">Next Part 2 chamber</button>' : '<button class="lr76cPrimary" data-lr76c-act="rewards">Artifact shelf</button>';
  mount('⚓ Challenge Result', '<div class="lr76cShell"><section class="lr76cPanel">'+(score===qs.length?'<h2>🏆 Part 2 mastery earned</h2><p>You earned <b>'+esc(c.reward)+'</b> and unlocked the future companion hook <b>'+esc(c.companion)+'</b>.</p>':'<h2>🔁 '+score+' / '+qs.length+'</h2><p>The room stays open. Review the chamber pages and try again.</p>')+(review?'<h3>Review clues</h3><ol>'+review+'</ol>':'')+'</section><div class="lr76cNav"><button data-lr76c-act="topic:'+i+':0">Review chamber</button><button data-lr76c-act="map">Part 2 map</button>'+nextBtn+'</div></div>');
}
function rewards(){
  var s=state(), r=s.rewards||[], items=s.items||[], comps=s.companions||[];
  var earned=CHAMBERS.map(function(c){ var got=r.indexOf(c.reward)>=0; return '<span class="lr76cReward '+(got?'got':'')+'">'+esc(c.icon+' '+c.reward)+(got?' ✓':'')+'</span>'; }).join('');
  var companions=CHAMBERS.map(function(c){ var got=comps.indexOf(c.companion)>=0; return '<span class="lr76cReward '+(got?'got':'')+'">'+esc(c.companion)+(got?' ✓':'')+'</span>'; }).join('');
  var found=items.length ? items.map(function(x){ return '<span class="lr76cReward got">'+esc(x)+'</span>'; }).join('') : '<p>No Part 2 room tokens found yet. Inspect rooms and chambers to collect them.</p>';
  mount('⚓ Shipwreck Cove Artifact Shelf','<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">🏆</div><div><h2>Part 2 Artifact Shelf</h2><p>These rewards are tied to logbooks, lake weather, lighthouse work, preservation, rescue planning, and maritime safety rules.</p>'+bar()+'</div></section><section class="lr76cPanel"><h3>Mastery artifacts</h3><div class="lr76cRewards">'+earned+'</div></section><section class="lr76cPanel"><h3>Companion hooks</h3><p>These are future-friendly hooks for the broader companion and shop systems. They do not force a new system into the shell.</p><div class="lr76cRewards">'+companions+'</div></section><section class="lr76cPanel"><h3>Exploration tokens</h3><div class="lr76cRewards">'+found+'</div></section>'+topNav((oldPart1Rewards?'<button data-lr76c-act="part1rewards">Part 1 shelf</button>':''))+'</div>');
}
function reviewShelf(){ var s=state(), m=s.missed||[]; mount('🔁 Shipwreck Cove Review Shelf','<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">🔁</div><div><h2>Part 2 Review Shelf</h2><p>Missed proof clues appear here so the player can return to the exact record shelf, tool bench, or safety wall.</p></div></section><section class="lr76cPanel">'+(m.length?'<ol>'+m.slice(-70).reverse().map(function(x){ return '<li><b>'+esc(x.chamber)+': '+esc(x.answer)+'</b><br><small>'+esc(x.why)+'</small></li>'; }).join('')+'</ol>':'<p>No missed Part 2 challenge clues yet.</p>')+'</section>'+topNav()+'</div>'); }
function merchant(){
  mount('🧭 Cove Keeper','<div class="lr76cShell"><section class="lr76cHero"><div class="lr76cHeroIcon">🧭</div><div><h2>Old Marnie expands the Cove counter</h2><p>Marnie now keeps a Part 2 reward drawer for logbook work, Great Lakes maps, lighthouse tools, preservation tags, storm planning, and rulebook lanterns.</p></div></section><section class="lr76cPanel"><h3>Future shop and collection hooks</h3><p>Suggested reward line: captain’s writing desk, blue logbook wallpaper, lake freighter model, lighthouse lens lamp, museum tag board, rescue blanket basket, rulebook shelf, harbor chart rug, and gentle cove companion items.</p><p>Companion hooks added in this part: Ghost Gull, Lighthouse Cat, Beacon Moth, Archivist Hermit Crab, Harbor Seal Pup, and Compass Tern. They are stored as hooks only, so the existing companion system is preserved.</p></section>'+topNav()+'</div>');
}
function normalizeRoomId(raw){ raw=String(raw||'').toLowerCase(); if(/lake|superior|freighter|gale/.test(raw)) return 'greatlakes'; if(/keeper|light|lens|beacon|fog/.test(raw)) return 'keeper'; if(/preserv|vault|arch|museum|treasure/.test(raw)) return 'vault'; if(/surviv|rescue|storm|signal|muster/.test(raw)) return 'survivor'; if(/ice|rule|wireless|patrol|safety/.test(raw)) return 'rules'; return 'cabin'; }
function route(act){
  act=String(act||'map');
  if(act==='map'||act==='open') return openMap();
  if(act==='part1') return openPart1();
  if(act==='part1rewards' && oldPart1Rewards) return oldPart1Rewards();
  if(act==='rewards') return rewards();
  if(act==='review') return reviewShelf();
  if(act==='merchant') return merchant();
  if(act==='history'){ if(has('openLearningCenterAnnex75O')) return window.openLearningCenterAnnex75O('history'); if(has('openRealmLibrary75A')) return window.openRealmLibrary75A('history'); return openMap(); }
  if(act.indexOf('room:')===0) return openRoom(act.slice(5));
  if(act.indexOf('inspect:')===0) return inspectPlace(act.slice(8));
  if(act.indexOf('inspectroom:')===0) return inspectRoomIndex(Number(act.slice(12)||0));
  if(act.indexOf('topic:')===0){ var p=act.split(':'); return openTopic(Number(p[1]||0), Number(p[2]||0)); }
  if(act.indexOf('challenge:')===0) return openChallenge(Number(act.slice(10)||0));
  if(act.indexOf('check:')===0) return checkChallenge(Number(act.slice(6)||0));
  return openMap();
}
function bind(){
  if(window.__LR76C_SHIPWRECK_BIND__) return; window.__LR76C_SHIPWRECK_BIND__=true;
  window.addEventListener('click', function(ev){ var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr76c-act]') : null; if(!el) return; ev.preventDefault(); /* 7.6W: do not swallow normal clicks */ route(el.getAttribute('data-lr76c-act')); }, true);
}
function isShipwreckButton(el){
  if(!el || (el.closest && (el.closest('.lr76aShell') || el.closest('.lr76bShell') || el.closest('.lr76cShell')))) return false;
  var text=((el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'')+' '+(el.getAttribute('onclick')||'')+' '+(el.getAttribute('data-route')||'')+' '+(el.getAttribute('data-action')||'')).toLowerCase();
  if(!/(shipwreck|ship wreck|cove|fog bell|lifeboat|chart loft|pirate map|famous wreck|great lakes|lighthouse keeper|ghost captain)/.test(text)) return false;
  if(/core halls|science and engineering|bible road|creative quarter|homestead/.test(text)) return false;
  return true;
}
function rerouteVisibleShipwreckButtons(){
  try{
    Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')).forEach(function(el){
      if(!isShipwreckButton(el)) return;
      try{ /* 7.6W: preserve onclick fallback */ el.removeAttribute('data-lr76a-act'); el.removeAttribute('data-lr76b-act'); }catch(e){}
      if(el.tagName && el.tagName.toLowerCase()==='a') el.setAttribute('href','#');
      var text=(el.textContent||'').toLowerCase();
      if(/great lakes|freighter|edmund/.test(text)) el.setAttribute('data-lr76c-act','room:greatlakes');
      else if(/lighthouse keeper|lens|beacon/.test(text)) el.setAttribute('data-lr76c-act','room:keeper');
      else if(/preservation|treasure|archaeology|vault/.test(text)) el.setAttribute('data-lr76c-act','room:vault');
      else if(/survivor|muster|storm survivor/.test(text)) el.setAttribute('data-lr76c-act','room:survivor');
      else if(/ice patrol|rulebook|wireless/.test(text)) el.setAttribute('data-lr76c-act','room:rules');
      else el.setAttribute('data-lr76c-act','map');
      el.setAttribute('data-lr76c-rerouted','true');
    });
    var door=byId('lr76aInjectedShipwreckDoor');
    if(door){ var btn=door.querySelector('button'); if(btn){ btn.removeAttribute('data-lr76a-act'); btn.setAttribute('data-lr76c-act','map'); var b=btn.querySelector('b'); if(b) b.textContent='Shipwreck Cove Deep Rebuild'; var sm=btn.querySelector('small'); if(sm) sm.textContent='Part 1 plus Part 2: logs, lakes, lighthouses, preservation, rescue, safety rules'; } }
  }catch(e){}
}
function injectDoor(){
  var root=mainBox(); if(!root || byId('lr76cInjectedShipwreckDoor')) return;
  if(root.querySelector && root.querySelector('.lr76cShell')) return;
  var text=(root.textContent||'');
  if(!/(History and World|World Directory|Realm Library|Connection Ledger|Shipwreck)/i.test(text)) return;
  var panel=document.createElement('div'); panel.id='lr76cInjectedShipwreckDoor'; panel.className='lr76cInject';
  panel.innerHTML='<button data-lr76c-act="map"><span>⚓</span><b>Shipwreck Cove Deep Rebuild</b><small>Part 1 plus Part 2 · ghost logs · Great Lakes · lighthouses · preservation · rescue rules</small><i>Open ›</i></button>';
  try{ root.appendChild(panel); }catch(e){}
}
function patchGlobals(){
  window.openShipwreckCoveDeepRebuild76C=openMap;
  window.openShipwreckCovePart176A=openPart1;
  window.openShipwreckCoveDeepRebuild76A=openMap;
  window.openShipwreckCoveDeepCourse=openMap;
  window.openShipwreckCoveMap=openMap;
  window.shipwreckGuidedZoneOpen=openMap;
  window.shipwreckGuidedZoneMap=openMap;
  window.shipwreckGuidedZoneMove=function(id){ return openRoom(normalizeRoomId(id)); };
  window.shipwreckGuidedZoneTalk=merchant;
  window.openShipwreckCoveRewardCatalog=rewards;
  window.openShipwreckCoveKeeper76A=merchant;
  window.openShipwreckCoveKeeper76C=merchant;
  window.shipwreckCoveTravel=function(id){ return openRoom(normalizeRoomId(id)); };
  window.shipwreckCoveInspect=function(id){ if(typeof id==='number') return inspectRoomIndex(id); return inspectPlace(normalizeRoomId(id)); };
  window.shipwreckGuidedZoneContinue=function(){ var s=state(); if(typeof s.topic==='number') return openTopic(s.topic, s.page||0); return openMap(); };
}
function boot(){
  installStyles(); bind(); patchGlobals(); rerouteVisibleShipwreckButtons(); injectDoor();
  try{ var mo=new MutationObserver(function(){ patchGlobals(); rerouteVisibleShipwreckButtons(); injectDoor(); }); mo.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['data-lr76a-act','data-lr76b-act','onclick']}); }catch(e){}
  setTimeout(function(){patchGlobals();rerouteVisibleShipwreckButtons();injectDoor();},200);
  setTimeout(function(){patchGlobals();rerouteVisibleShipwreckButtons();injectDoor();},850);
  setTimeout(function(){patchGlobals();rerouteVisibleShipwreckButtons();injectDoor();},1700);
}
function installStyles(){
  if(byId('lr76cShipwreckStyles')) return;
  var st=document.createElement('style'); st.id='lr76cShipwreckStyles'; st.textContent = `
.lr76cShell{font-family:inherit;color:#17303a}.lr76cHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;margin:0 0 14px;border-radius:18px;background:linear-gradient(135deg,#0f2d3b,#26637b 55%,#c9a650);color:#fff;border:2px solid rgba(255,228,156,.55);box-shadow:0 10px 24px rgba(0,0,0,.14)}.lr76cHero h2{margin:.1rem 0 .45rem;color:#fff}.lr76cHero p,.lr76cHero small{color:#fff9e8;line-height:1.45}.lr76cHeroIcon{font-size:2.6rem;filter:drop-shadow(0 2px 2px rgba(0,0,0,.25))}.lr76cBar{height:12px;border-radius:99px;background:rgba(255,255,255,.32);overflow:hidden;margin:9px 0}.lr76cBar i{display:block;height:100%;background:linear-gradient(90deg,#ffe17b,#7ee3ff)}.lr76cPanel,.lr76cReading,.lr76cQuestion,.lr76cChoice{background:linear-gradient(180deg,#fffdf6,#f7efdf);border:1px solid rgba(62,87,98,.2);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 5px 14px rgba(10,32,42,.08)}.lr76cNotice{background:#eef9fb;border-color:#8ac4d1}.lr76cReading p{line-height:1.72;margin:.82rem 0;font-size:1.01rem}.lr76cPanel p{line-height:1.5}.lr76cRoomGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(235px,1fr));gap:10px}.lr76cGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}.lr76cRoomCard,.lr76cChamberCard{display:grid;grid-template-columns:auto 1fr auto;gap:10px;text-align:left;width:100%;padding:12px;border-radius:15px;border:1px solid rgba(33,65,82,.22);background:#fffaf0;box-shadow:0 2px 0 rgba(0,0,0,.07);cursor:pointer;color:#1d3340}.lr76cRoomCard span,.lr76cChamberCard span{font-size:1.8rem;grid-row:span 3}.lr76cRoomCard b,.lr76cChamberCard b{display:block}.lr76cRoomCard p,.lr76cChamberCard p{margin:.25rem 0;line-height:1.38}.lr76cRoomCard small,.lr76cChamberCard small{color:#46616b}.lr76cChamberCard.done{background:linear-gradient(180deg,#f2fff5,#e7f7ec);border-color:#73a77b}.lr76cNav{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.lr76cNav button,.lr76cPanel button,.lr76cPrimary{border:1px solid rgba(33,65,82,.28);border-radius:12px;background:#fffaf0;padding:9px 12px;font-weight:800;cursor:pointer;box-shadow:0 2px 0 rgba(0,0,0,.08);color:#1d3340}.lr76cPrimary,.lr76cNav .lr76cPrimary{background:#ffd86f!important;border-color:#926a05!important}.lr76cQuestion b{display:block;margin-bottom:7px}.lr76cChoices{display:grid;gap:7px;margin-top:9px}.lr76cChoices label{display:block;padding:8px 10px;border-radius:10px;background:#f9fbfc;border:1px solid rgba(54,76,90,.16);line-height:1.35}.lr76cRewards{display:flex;flex-wrap:wrap;gap:8px}.lr76cReward{display:inline-block;padding:7px 10px;border-radius:999px;border:1px solid rgba(73,82,93,.22);background:#eef3f4}.lr76cReward.got{background:#fff0af;border-color:#bc8b19;font-weight:800}.lr76cInject{margin:10px 0}.lr76cInject button{display:grid;grid-template-columns:auto 1fr auto;gap:10px;align-items:center;width:100%;padding:12px;border-radius:15px;background:#f0fbff;border:1px solid #7db7c8;color:#15333e;cursor:pointer}.lr76cInject span{font-size:1.8rem}.lr76cInject small{display:block;color:#41606c}.lr76cChoice{border-left:5px solid #1f7b92;background:#eef9fb}@media(max-width:760px){.lr76cHero{grid-template-columns:1fr}.lr76cRoomCard,.lr76cChamberCard{grid-template-columns:1fr}.lr76cRoomCard span,.lr76cChamberCard span{grid-row:auto}}
  `; document.head.appendChild(st);
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
window.__LR_SHIPWRECK_COVE_COURSE_76C__ = {title:'Shipwreck Cove Deep Rebuild Part 2', chambers:CHAMBERS, rooms:ROOMS};
})();
