/* LearningRealms Subject Room Polish 7.4K
   Built from the working 7.4J branch.
   Purpose: keep the stable shell, but make the major subject umbrellas feel like
   real adventure rooms instead of framework menus. Adds environment, guides,
   room choices, keepsake tokens, and extra framework-word cleanup.
   No save reset. No loading curtain. No render loop. No interface rewrite.
*/
(function(){
  'use strict';
  if(window.__LR74K_SUBJECT_ROOM_POLISH__) return;
  window.__LR74K_SUBJECT_ROOM_POLISH__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function txt(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function safe(fn){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); setTimeout(scrubFramework,60); return true; }
    catch(e){ console.warn('LR74K route failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var r = list[i];
      if(Array.isArray(r)){ if(safe.apply(null,r)) return true; }
      else if(safe(r)) return true;
    }
    return false;
  }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    var s = byId('studentSelect');
    if(s && s.value) return s.value;
    return 'Adventurer';
  }
  function mount(){
    var firstCard = q('.main > .card:first-child') || q('section.main') || document.body;
    var m = byId('lrDynamicAdventureScreen');
    if(!m){
      m = document.createElement('div');
      m.id = 'lrDynamicAdventureScreen';
      m.className = 'lrDynamicAdventureScreen lr74kMount';
      if(firstCard.firstChild) firstCard.insertBefore(m, firstCard.firstChild); else firstCard.appendChild(m);
    }
    m.classList.add('lr74kMount');
    m.style.display = 'block';
    m.style.visibility = 'visible';
    m.style.opacity = '1';
    return m;
  }
  function popup(title, html){
    title = scrubString(title);
    html = scrubString(html || '');
    if(typeof window.lrOpenPopup === 'function'){
      window.lrOpenPopup(title, html);
      setTimeout(scrubFramework,50);
      return;
    }
    var at = byId('actionTitle'), ax = byId('actionText');
    if(at) at.textContent = title;
    if(ax) ax.innerHTML = html;
    if(typeof window.lrOpenActionPopup === 'function') window.lrOpenActionPopup(title);
    setTimeout(scrubFramework,50);
  }

  var ROOMS = {
    atlas: {
      icon:'🗺️', title:'Realm Crossroads', kicker:'Adventure Atlas',
      subtitle:'Six large roads branch from this room. Each road is treated like a place, not a loose stack of class buttons.',
      scene:'A round table fills the center of the chamber. Brass map pins mark forests, halls, docks, workshops, chapels, and old roads. A low lantern burns beside the map so the player can choose the next path without digging through scattered menus.',
      guide:'The atlas keeper taps the map and says, “Pick the road that fits the kind of adventure you want. The subjects are grouped by where they belong now.”',
      inspect:'You notice the map has been cleaned up. History roads sit together. Science and engineering share one quarter. Bible Road has its own respectful gate. Home and companions stay with the homestead.',
      token:'Crossroads Map Pin',
      choices:[
        ['📚','Core Halls','Reading, writing, math, and logic live in the steady skill halls.','core'],
        ['🔬','Science and Engineering Quarter','Nature, health, weather, inventions, machines, aerospace, and experiments gather here.','science'],
        ['🏛️','History and World Wing','Egypt, Great Depression, Wild West, Shipwreck Cove, geography, civics, and economics belong here.','history'],
        ['⛪','Bible Road','A separate, reverent road for Catholic-friendly Bible History and respectful artifacts.','bible'],
        ['🎨','Creative Quarter','Art, music, theater, crafts, and story making share the studio streets.','creative'],
        ['🏡','Homestead Workshop','Home rooms, life skills, animal care, storage, companions, and collections.','homestead']
      ],
      shelf:['Brass road pins','Folded atlas cloth','Tiny lantern marker','Blank quest card']
    },
    core: {
      icon:'📚', title:'Core Halls', kicker:'Skill halls',
      subtitle:'Reading, writing, math, and logic sit together in one useful academic wing.',
      scene:'The Core Halls are quiet but not plain. One side looks like a story library with carved book rails. The other side opens into a number forge where gears, fraction shields, and pattern tiles hang on the wall. The room feels like the dependable center of the realm.',
      guide:'The hall steward says, “This is where steady skills get stronger. Read carefully, write clearly, count with patience, and test every answer like a small clue.”',
      inspect:'You see labeled doors for Reading Woods, Scribe Hall, Math Iron Hills, Fraction Castle, Puzzle Spire, and Equation Forge. Nothing here needs to float elsewhere because these are the basic tools every other road uses.',
      token:'Scribe-and-Gear Hall Token',
      choices:[
        ['📖','Reading Woods','Main idea, details, sequence, vocabulary, and proof from the page.','reading'],
        ['🌲','Story Forest','Characters, setting, plot, retelling, and story order.','reading'],
        ['✒️','Scribe Hall','Sentences, paragraphs, explanations, copywork, and clear answers.','writing'],
        ['🪶','Copywork Abbey','Careful copying, attention, language memory, and neat written habits.','writing'],
        ['🔢','Math Iron Hills','Operations, models, measurement, geometry, fractions, and equations.','math'],
        ['🏰','Fraction Castle','Parts, wholes, comparisons, models, and fraction thinking.','math'],
        ['🧩','Puzzle Spire','Patterns, evidence, sequences, claims, and careful reasoning.','logic'],
        ['⚙️','Equation Forge','Unknowns, symbols, steps, and algebra-ready habits.','math']
      ],
      shelf:['Bookmark press','Wax number seal','Pattern tiles','Quiet reading lamp']
    },
    science: {
      icon:'🔬', title:'Science and Engineering Quarter', kicker:'Labs, sky towers, and machine roads',
      subtitle:'Science, nature, health, inventions, engineering, aerospace, weather, and machines are grouped together.',
      scene:'Copper pipes run along the walls, glass jars sit on oak shelves, and a weather vane turns above a skylight. One hallway smells faintly of soil and leaves. Another leads toward a machine shop where models, gears, wings, and warning signs remind the player that good design comes from testing.',
      guide:'The quartermaster says, “Look first, measure carefully, and never trust a guess that evidence can check. Machines, bodies, plants, weather, and sky all leave clues.”',
      inspect:'The quarter is organized by observation and design: living things, weather, sky study, chemistry, physics, inventions, robotics, repair, and flight all make sense in the same district.',
      token:'Copper Lab Lantern',
      choices:[
        ['🔬','Science Marsh','Observation, matter, earth science, safe experiments, and evidence habits.','science'],
        ['🌿','Nature and Health Trails','Plants, animals, habitats, hygiene, nutrition, exercise, sleep, and safe body basics.','nature'],
        ['☁️','Weather Academy','Clouds, storms, air, seasons, forecasts, and sky evidence.','science'],
        ['🌌','Sky Watch Observatory','Astronomy, planets, rockets, careful sky study, and space tools.','aerospace'],
        ['💡','Inventions Hall','Inventors, prototypes, redesign, famous failures, safety, and problem solving.','inventions'],
        ['✈️','Aerospace Academy','Flight, lift, drag, rockets, forces, testing, and design choices.','aerospace'],
        ['⚙️','Mechanical Workshop','Tools, simple machines, gears, motion, repair thinking, and building.','aerospace'],
        ['🤖','Robotics Lab','Sensors, instructions, systems, computers, loops, and machine logic.','aerospace']
      ],
      shelf:['Storm glass','Wing model','Gear gauge','Seed tray','Safety goggles']
    },
    history: {
      icon:'🏛️', title:'History and World Wing', kicker:'Past roads and world rooms',
      subtitle:'Major history areas and supporting world topics now live together under one umbrella.',
      scene:'The History and World Wing feels like a museum built inside an old fortress. A timeline runs across the stone floor. Painted doors show a Nile boat, a Dust Bowl sky, a frontier rail line, a foggy harbor, a map table, a council bench, and a merchant stall.',
      guide:'The keeper of records says, “History is not a pile of names. Walk the rooms, notice the tools, follow the evidence, and ask why people made the choices they made.”',
      inspect:'This wing now keeps history roads together. Ancient Egypt is here. The Great Depression and Wild West are here. Shipwreck Cove belongs here as maritime history. Geography, civics, and economics support the main historical roads instead of floating away as random subjects.',
      token:'Timeline Compass Charm',
      choices:[
        ['🏺','Ancient Egypt Expedition','Nile foundations, pyramids, Sphinx, scribes, daily life, belief, archaeology, and evidence.','egypt'],
        ['👑','Egypt Royal Gallery','Notable pharaohs and rulers across the dynasties, treated as a real gallery.','egyptroyal'],
        ['🛶','Egypt World Expansion','River docks, village life, temples, tomb builders, trade, art, and preservation.','egyptworld'],
        ['🏚️','Great Depression Road','Banks, work, Dust Bowl, family budgets, recovery, systems, and resilience.','depression'],
        ['🤠','Wild West Frontier Trail','Frontier towns, trails, railroads, cattle drives, tools, water, newspapers, and myth vs. history.','wildwest'],
        ['⚓','Shipwreck Cove','Navigation, storms, wreck evidence, rescue, archaeology, pirates, folklore, and maritime safety.','shipwreck'],
        ['🗺️','Mapmakers Hall','Landforms, routes, directions, regions, maps, and place evidence.','geography'],
        ['⚖️','Councilhall Citadel','Rules, law, responsibility, services, civic order, and source judgment.','civics'],
        ['🏪','Merchant Row','Needs, wants, value, trade, saving, budgets, and work.','economics'],
        ['📜','Timeline Hall','Sequence, cause and effect, date clues, and historical order.','historytrails']
      ],
      shelf:['Date stones','Archive gloves','Map weights','Bronze timeline strip','Old ledger key']
    },
    bible: {
      icon:'⛪', title:'Bible Road', kicker:'Separate reverent realm',
      subtitle:'Bible History stays as its own respectful place, not mixed into ordinary history menus.',
      scene:'Bible Road begins at a quiet stone gate. A scriptorium window glows softly, shelves hold saint cards and Scripture markers, and a small artifact hall displays study symbols with care. The room is calm, reverent, and clearly separate from the noisy academic wings.',
      guide:'The pilgrim guide says, “Walk this road with respect. The rooms point to Scripture history, Catholic teaching, saints, angels, Mary, sacraments, feast days, and sacred art without treating holy things like silly loot.”',
      inspect:'The artifacts here are memory symbols and study displays: candles, bells, windows, cards, maps, and devotional-looking decor handled respectfully. The road is meant to feel quiet and meaningful.',
      token:'Pilgrim Road Bookmark',
      choices:[
        ['⛪','Walk Pilgrim Road','Scripture history, New Testament foundations, Mary, apostles, saints, angels, sacraments, and feasts.','bibletrail'],
        ['📖','Scripture Scriptorium','Open the Bible History room map and scroll chambers.','biblecourse'],
        ['🏺','Artifact Hall','Tasteful Catholic-friendly study displays and memory symbols.','bibleartifacts'],
        ['🏆','Treasure Shelf','View earned Bible History keepsakes.','biblerewards'],
        ['🔎','Review Shelf','Return to missed challenges and read carefully again.','biblereview'],
        ['🗺️','Realm Crossroads','Return to the main atlas.','atlas']
      ],
      shelf:['Illuminated page stand','Quiet candle marker','Saint card drawer','Blue mantle ribbon','Chapel bell sketch']
    },
    creative: {
      icon:'🎨', title:'Creative Quarter', kicker:'Studios and maker rooms',
      subtitle:'Art, music, theater, craft work, design, and story making are together in one lively quarter.',
      scene:'The Creative Quarter is warmer and louder than the archive halls. Painted panels lean against the walls, a stage curtain hangs over a small platform, and a music room hums with bells, drums, and string sounds. A story table waits with blank cards and colored pencils.',
      guide:'The studio keeper says, “Try the craft, study the pattern, listen closely, and make something with care. Creative work still has skill, order, and practice.”',
      inspect:'The quarter is arranged like a little town of studios: drawing, painting, crafts, theater, music, pattern work, and story making all connect because they train attention, design, memory, and expression.',
      token:'Dragonbrush Color Tile',
      choices:[
        ['🎨','Creative Studio','Drawing, painting, crafts, patterns, theater, music, story making, and gallery habits.','creativecourse'],
        ['🖌️','Dragonbrush Vale','Line, shape, color, design, and visual storytelling.','arts'],
        ['🎵','Bardwood Hall','Rhythm, sound, listening, instruments, patterns, and music vocabulary.','music'],
        ['🎭','Theater Stage','Voice, performance, safe theater habits, and story presentation.','arts'],
        ['🧵','Craft Cottage','Hands-on making, careful assembly, patterns, and design choices.','arts'],
        ['📚','Story Maker Room','Inventing scenes, characters, problems, and endings.','reading']
      ],
      shelf:['Brush cup','Pattern stamp','Stage mask','Music bell','Story dice']
    },
    homestead: {
      icon:'🏡', title:'Homestead Workshop', kicker:'Home, companions, and useful work',
      subtitle:'Life skills, home systems, animal care, storage, collections, and companion goals stay together.',
      scene:'The Homestead Workshop feels like the player’s base. A hearth glows near the storage chest, tool hooks line the wall, pet beds sit near the corner, and a workbench holds maps, jars, cloth, repair parts, and little signs for daily jobs.',
      guide:'The homestead keeper says, “Not every useful skill belongs in a classroom. Some skills live in routines, repairs, cooking, animal care, planning, and taking care of the place you call home.”',
      inspect:'This area keeps practical systems together: home rooms, decor, storage, companions, life skills, cooking, repair, animal care, collections, and quests.',
      token:'Hearth Workshop Key Hook',
      choices:[
        ['🏡','Home Hearth','Home rooms, storage, decor, household progress, and display places.','home'],
        ['🧰','Homestead Workshop','Planning, routines, chores, tools, cooking, repair, and useful work.','life'],
        ['🍳','Cooking Guild','Kitchen basics, safety habits, measuring, planning, and simple food work.','life'],
        ['🐾','Animal Care Corner','Gentle animal care, responsibility, routines, and observation.','life'],
        ['🐾','Companion Den','Pets, companion records, bonds, and discovered friends.','pets'],
        ['🎒','Collection Log','Badges, decor, artifacts, rewards, and treasures.','items'],
        ['📜','Quest Board','Errands, records, story paths, daily jobs, and long-term goals.','quests']
      ],
      shelf:['Tool tag','Pet brush','Recipe slate','Storage label','Quest peg']
    }
  };

  function styles(){
    if(byId('lr74kStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr74kStyles';
    st.textContent = `
      .lr74kMount{border-radius:18px;overflow:hidden;background:#061413;box-shadow:0 16px 38px rgba(0,0,0,.28)}
      .lr74kRealm{min-height:650px;color:#f7ecc4;background:radial-gradient(circle at 14% 0%,rgba(255,226,139,.18),transparent 32%),linear-gradient(180deg,#0a2420,#081413 62%,#150f09);}
      .lr74kHero{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(280px,.7fr);gap:18px;padding:24px;background:linear-gradient(135deg,rgba(22,62,54,.94),rgba(7,20,18,.97) 56%,rgba(84,55,19,.86));border-bottom:1px solid rgba(246,218,142,.22)}
      .lr74kBadge{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(246,218,142,.28);background:rgba(0,0,0,.23);border-radius:999px;padding:6px 10px;color:#ffeab2;font-weight:1000;text-transform:uppercase;letter-spacing:.09em;font-size:.72rem}
      .lr74kHero h1{margin:12px 0 8px;color:#fff6d4;font-size:clamp(2rem,3.5vw,3.35rem);line-height:1;text-shadow:0 3px 0 rgba(0,0,0,.24)}
      .lr74kHero p{margin:.35rem 0;color:#d6eadf;font-weight:800;line-height:1.55;max-width:920px}.lr74kSceneBox{border:1px solid rgba(246,218,142,.22);background:linear-gradient(180deg,rgba(255,248,211,.10),rgba(0,0,0,.16));border-radius:17px;padding:14px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.04)}
      .lr74kSceneBox b{display:block;color:#fff1bd;margin-bottom:5px}.lr74kSceneBox p{font-size:.94rem;line-height:1.45;margin:0;color:#cfe7da}.lr74kBody{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:16px;padding:18px}.lr74kChoices{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:12px}.lr74kDoor{display:grid!important;grid-template-columns:46px 1fr auto;gap:11px;align-items:start;text-align:left;min-height:132px;border:1px solid rgba(246,218,142,.25)!important;border-radius:18px!important;background:linear-gradient(180deg,#fff8d8,#d8c18b)!important;color:#201609!important;padding:13px!important;box-shadow:0 10px 18px rgba(0,0,0,.25)!important;cursor:pointer!important;font-weight:900!important}.lr74kDoor:hover{transform:translateY(-1px);box-shadow:0 14px 26px rgba(0,0,0,.33)!important}.lr74kIcon{width:44px;height:44px;border-radius:12px;background:linear-gradient(180deg,#173831,#071715);display:grid;place-items:center;color:#fff0bd;font-size:1.35rem}.lr74kDoor b{display:block;color:#211607;font-size:1.02rem;line-height:1.15}.lr74kDoor small{display:block;color:#745515;text-transform:uppercase;letter-spacing:.04em;font-weight:1000;font-size:.68rem;margin:3px 0 5px}.lr74kDoor span p{margin:0;color:#3d3322;line-height:1.32;font-weight:780}.lr74kArrow{align-self:center;font-size:1.85rem;color:#6e4b0f}.lr74kSide{display:grid;gap:12px;align-content:start}.lr74kPanel{border:1px solid rgba(246,218,142,.20);border-radius:16px;background:linear-gradient(180deg,rgba(255,247,212,.10),rgba(0,0,0,.17));padding:13px}.lr74kPanel h3{margin:0 0 8px;color:#fff0bd}.lr74kPanel p{margin:.3rem 0;color:#cfe7da;line-height:1.42;font-weight:780}.lr74kShelf{display:flex;flex-wrap:wrap;gap:7px}.lr74kShelf span{border:1px solid rgba(246,218,142,.24);border-radius:999px;background:rgba(0,0,0,.20);color:#ffe8ab;padding:6px 8px;font-weight:900;font-size:.78rem}.lr74kActions{display:grid;gap:8px}.lr74kActions button,.lr74kFooter button{border:1px solid rgba(246,218,142,.34)!important;border-radius:12px!important;background:linear-gradient(180deg,#fff3bf,#d2a04b)!important;color:#1c1106!important;font-weight:1000!important;padding:10px!important;cursor:pointer!important}.lr74kActions button.lr74kPrimary{background:linear-gradient(180deg,#fff7d2,#e3ba63)!important}.lr74kFooter{display:flex;flex-wrap:wrap;gap:9px;padding:14px 18px;background:#071413;border-top:1px solid rgba(246,218,142,.16)}.lr74kToast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:99999;border:1px solid rgba(246,218,142,.45);border-radius:999px;background:#071413;color:#fff0bd;box-shadow:0 10px 24px rgba(0,0,0,.35);padding:10px 14px;font-weight:1000}.lr74kTalkPopup h3{margin-top:0;color:#2a1d09}.lr74kTalkPopup{color:#2a1d09}.lr74kTalkPopup p{line-height:1.5}.lr74kSmallGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:10px}.lr74kSmallGrid button{border-radius:12px!important;padding:9px!important;font-weight:1000!important}.lr74kCommandHint{margin-top:8px;padding:8px;border-radius:10px;background:rgba(0,0,0,.20);color:#ffe8ab;font-weight:900;font-size:.78rem}
      @media(max-width:1050px){.lr74kHero,.lr74kBody{grid-template-columns:1fr}.lr74kBody{padding:12px}.lr74kHero{padding:18px}.lr74kChoices{grid-template-columns:1fr}}
    `;
    document.head.appendChild(st);
  }

  function door(c){
    return '<button type="button" class="lr74kDoor" data-lr74k-act="'+esc(c[3])+'"><span class="lr74kIcon">'+esc(c[0])+'</span><span><b>'+esc(c[1])+'</b><small>Road door</small><p>'+esc(c[2])+'</p></span><i class="lr74kArrow">›</i></button>';
  }
  function shelf(items){ return '<div class="lr74kShelf">'+items.map(function(x){return '<span>'+esc(x)+'</span>';}).join('')+'</div>'; }
  function renderRoom(key){
    styles();
    var r = ROOMS[key] || ROOMS.atlas;
    var m = mount();
    m.removeAttribute('data-lr74k-last-source');
    m.setAttribute('data-lr74k-view', key);
    m.innerHTML = '<div class="lr74kRealm" data-lr74k-room="'+esc(key)+'">'+
      '<section class="lr74kHero"><div><span class="lr74kBadge">'+esc(r.icon)+' '+esc(r.kicker)+'</span><h1>'+esc(r.title)+'</h1><p>'+esc(r.subtitle)+'</p><p>'+esc(r.scene)+'</p></div><div class="lr74kSceneBox"><b>Guide nearby</b><p>'+esc(r.guide)+'</p><div class="lr74kCommandHint">Choose a door, inspect the room, talk to the guide, or collect the room token.</div></div></section>'+
      '<section class="lr74kBody"><div class="lr74kChoices">'+r.choices.map(door).join('')+'</div><aside class="lr74kSide"><div class="lr74kPanel"><h3>🔎 Room details</h3><p>'+esc(r.inspect)+'</p></div><div class="lr74kPanel"><h3>🏺 Shelf items</h3>'+shelf(r.shelf)+'</div><div class="lr74kPanel"><h3>🎒 Room token</h3><p>'+esc(r.token)+' can be placed in home storage as a little memory of visiting this area.</p><div class="lr74kActions"><button class="lr74kPrimary" data-lr74k-act="collect:'+esc(key)+'">Collect room token</button><button data-lr74k-act="talk:'+esc(key)+'">Talk to guide</button><button data-lr74k-act="look:'+esc(key)+'">Inspect room</button></div></div></aside></section>'+
      '<div class="lr74kFooter"><button data-lr74k-act="atlas">🗺️ Realm Crossroads</button><button data-lr74k-act="history">🏛️ History Wing</button><button data-lr74k-act="bible">⛪ Bible Road</button><button data-lr74k-act="home">🏡 Home</button></div>'+
      '</div>';
    scrubFramework();
    return false;
  }

  function toast(msg){
    var old = byId('lr74kToast'); if(old) old.remove();
    var d = document.createElement('div'); d.id='lr74kToast'; d.className='lr74kToast'; d.textContent=msg;
    document.body.appendChild(d);
    setTimeout(function(){ try{ d.remove(); }catch(e){} }, 2200);
  }
  function award(key){
    var r = ROOMS[key] || ROOMS.atlas;
    var name = r.token;
    try{
      if(typeof window.ensureHome === 'function'){
        var h = window.ensureHome();
        h.storage = h.storage || [];
        var exists = h.storage.some(function(it){ return (it && (it.name || it) === name); });
        if(!exists) h.storage.push({name:name, slot:'shelf'});
        if(typeof window.addMemory === 'function') window.addMemory('Room Token', activeName()+' collected '+name+' in '+r.title+'.');
        if(typeof window.save === 'function') window.save();
        toast(exists ? 'Already on the shelf: '+name : 'Added to storage: '+name);
      }else{
        var k = 'LR74K_ROOM_TOKENS_'+activeName();
        var list = [];
        try{ list = JSON.parse(localStorage.getItem(k)||'[]'); }catch(e){}
        if(list.indexOf(name) === -1) list.push(name);
        localStorage.setItem(k, JSON.stringify(list));
        toast('Token remembered: '+name);
      }
    }catch(e){ toast('Token noted: '+name); }
  }
  function talk(key){
    var r = ROOMS[key] || ROOMS.atlas;
    popup(r.icon+' '+r.title+' Guide', '<div class="lr74kTalkPopup"><h3>'+esc(r.title)+'</h3><p>'+esc(r.guide)+'</p><p>'+esc(r.inspect)+'</p><div class="lr74kSmallGrid"><button data-lr74k-act="'+esc(key)+'">Return to room</button><button data-lr74k-act="collect:'+esc(key)+'">Collect room token</button></div></div>');
  }
  function look(key){
    var r = ROOMS[key] || ROOMS.atlas;
    popup('🔎 Inspect '+r.title, '<div class="lr74kTalkPopup"><h3>'+esc(r.icon+' '+r.title)+'</h3><p>'+esc(r.scene)+'</p><p>'+esc(r.inspect)+'</p><h3>Shelf details</h3>'+shelf(r.shelf)+'<div class="lr74kSmallGrid"><button data-lr74k-act="'+esc(key)+'">Return to room</button><button data-lr74k-act="collect:'+esc(key)+'">Collect room token</button></div></div>');
  }

  function oldShelf(subject){
    if(subject === 'reading') return safe('openRealCurriculumPicker','reading');
    if(subject === 'writing') return safe('openRealCurriculumPicker','writing');
    if(subject === 'math') return safe('openRealCurriculumPicker','math');
    if(subject === 'science') return safe('openRealCurriculumPicker','science');
    if(subject === 'geography') return safe('openRealCurriculumPicker','geography');
    if(subject === 'logic') return safe('openRealCurriculumPicker','logic');
    if(subject === 'aerospace') return safe('openRealCurriculumPicker','aerospace');
    if(subject === 'life') return safe('openRealCurriculumPicker','life');
    if(subject === 'arts' || subject === 'music') return safe('openRealCurriculumPicker','arts');
    if(subject === 'civics') return safe('openRealCurriculumPicker','geography');
    if(subject === 'economics') return safe('openRealCurriculumPicker','life') || safe('openRealCurriculumPicker','geography');
    if(subject === 'historytrails') return safe('openRealCurriculumPicker','heritage') || renderRoom('history');
    return safe('openRealCurriculumPicker');
  }
  function route(act){
    act = String(act || 'atlas').toLowerCase().replace(/[^a-z0-9:]/g,'');
    if(act.indexOf('collect:') === 0){ award(act.split(':')[1]); return false; }
    if(act.indexOf('talk:') === 0){ talk(act.split(':')[1]); return false; }
    if(act.indexOf('look:') === 0){ look(act.split(':')[1]); return false; }
    if(ROOMS[act]) return renderRoom(act);
    if(act === 'map' || act === 'realmmap' || act === 'golearn' || act === 'learn') return renderRoom('atlas');
    if(act === 'historywing') return renderRoom('history');
    if(act === 'bibleroad' || act === 'biblehistory') return renderRoom('bible');
    if(act === 'depression' || act === 'greatdepression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || renderRoom('history');
    if(act === 'wildwest') return first([['openWildWestTrail'],['openWildWestCourse']]) || renderRoom('history');
    if(act === 'shipwreck') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['openShipwreckCoveMap']]) || renderRoom('history');
    if(act === 'egypt' || act === 'ancientegypt') return first([['openAncientEgyptTrail'],['openAncientEgyptCourse']]) || renderRoom('history');
    if(act === 'egyptroyal') return first([['openAncientEgyptRoyalGallery'],['openAncientEgyptRoyalCourse'],['openAncientEgyptTrail']]) || renderRoom('history');
    if(act === 'egyptworld') return first([['openAncientEgyptWorldExpansion'],['openAncientEgyptWorldCourse'],['openAncientEgyptTrail']]) || renderRoom('history');
    if(act === 'bibletrail') return first([['openBibleHistoryTrail'],['openBibleHistoryCourse']]) || renderRoom('bible');
    if(act === 'biblecourse') return first([['openBibleHistoryCourse'],['openBibleHistoryTrail']]) || renderRoom('bible');
    if(act === 'bibleartifacts') return first([['openBibleHistoryArtifacts73B'],['openBibleHistoryArtifacts'],['openBibleHistoryRewards']]) || renderRoom('bible');
    if(act === 'biblerewards') return first([['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || renderRoom('bible');
    if(act === 'biblereview') return first([['openBibleHistoryReview'],['openBibleHistoryCourse']]) || renderRoom('bible');
    if(act === 'inventions') return first([['openInventionsDeepCourse'],['openInventionsRewardCatalog']]) || renderRoom('science');
    if(act === 'creativecourse') return first([['openCreativeStudioCourse'],['openCreativeStudioByStudio']]) || oldShelf('arts');
    if(act === 'home') return first([['openHomeRenderer'],['openHomeViewPopup'],['openHomeView'],['openVisualHome'],['renderHomeSlots']]) || renderRoom('homestead');
    if(act === 'items' || act === 'collection' || act === 'collectionlog') return first([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openAchievementJournal']]) || renderRoom('homestead');
    if(act === 'pets' || act === 'companions' || act === 'companionden') return first([['openCompanionDen'],['openPetJournal'],['openCompanionPopup']]) || renderRoom('homestead');
    if(act === 'quests' || act === 'questboard') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openQuestPopup'],['openStoryQuestJournal']]) || renderRoom('homestead');
    return oldShelf(act) || renderRoom('atlas');
  }
  window.lr74kRoute = route;
  window.openLearningRealmsRealmAtlas74K = function(){ return renderRoom('atlas'); };
  window.openLearningRealmsHistoryWing74K = function(){ return renderRoom('history'); };
  window.openLearningRealmsBibleRoad74K = function(){ return renderRoom('bible'); };

  var replacements = [
    [/\bstudents will\b/gi,'the road reveals'],
    [/\bstudent will\b/gi,'the road reveals'],
    [/\bstudents should\b/gi,'adventurers can'],
    [/\bstudent should\b/gi,'adventurers can'],
    [/\bstudents\b/gi,'adventurers'],
    [/\bstudent\b/gi,'adventurer'],
    [/learning objective/gi,'road purpose'],
    [/lesson objective/gi,'room purpose'],
    [/course framework/gi,'realm structure'],
    [/lesson framework/gi,'realm structure'],
    [/framework/gi,'structure'],
    [/curriculum/gi,'scroll work'],
    [/REAL Curriculum/gi,'Realm Scroll Shelf'],
    [/Authored Lesson Bank/gi,'Scroll Archive'],
    [/Loaded \d+ real authored lessons from \d+ packs\.?/gi,'Choose a shelf. Each scroll opens a reading room and challenge.'],
    [/real authored lessons/gi,'ready realm scrolls'],
    [/lesson bank/gi,'scroll shelf'],
    [/lesson launcher/gi,'scroll door'],
    [/start lesson/gi,'open scroll chamber'],
    [/take quiz/gi,'enter challenge'],
    [/start test/gi,'begin challenge'],
    [/test result/gi,'challenge result'],
    [/\btest\b/gi,'challenge'],
    [/\bquiz\b/gi,'challenge'],
    [/course map/gi,'road map'],
    [/reward catalog/gi,'treasure shelf'],
    [/review missed/gi,'review shelf'],
    [/classroom schedule/gi,'daily rhythm'],
    [/student records/gi,'Records Ledger'],
    [/learning log/gi,'Journey Log']
  ];
  function scrubString(s){
    var out = String(s == null ? '' : s);
    for(var i=0;i<replacements.length;i++) out = out.replace(replacements[i][0], replacements[i][1]);
    return out;
  }
  function scrubFramework(root){
    root = root || document.body;
    if(!root || !document.createTreeWalker) return;
    try{
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode:function(node){
          var p = node.parentNode;
          if(!p) return NodeFilter.FILTER_REJECT;
          var tag = (p.nodeName || '').toLowerCase();
          if(tag === 'script' || tag === 'style' || tag === 'textarea' || tag === 'input') return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      var nodes=[], n;
      while((n=walker.nextNode())) nodes.push(n);
      nodes.forEach(function(node){ var v=node.nodeValue, nv=scrubString(v); if(nv!==v) node.nodeValue=nv; });
      ['actionTitle','lrPopupTitle','roomTitle'].forEach(function(id){ var el=byId(id); if(el){ var t=el.textContent, nt=scrubString(t); if(nt!==t) el.textContent=nt; }});
      var label = q('label.rightInfoPicker');
      if(label){ label.childNodes.forEach(function(node){ if(node.nodeType===3) node.nodeValue = node.nodeValue.replace(/Show/i,'Open'); }); }
    }catch(e){}
  }

  function detectOldScreen(){
    var root = byId('lrDynamicAdventureScreen');
    if(!root) return;
    if(root.querySelector('.lr74kRealm')) return;
    var t = txt(root);
    if(!t) return;
    if(/Core Halls|Reading and Language|Numbers and Reasoning/i.test(t)) return renderRoom('core');
    if(/Science and Engineering Quarter|Science Roads|Engineering Roads/i.test(t)) return renderRoom('science');
    if(/History and World Wing|History Master Roads|World and Society Topics/i.test(t)) return renderRoom('history');
    if(/Bible Road|Pilgrim Road|Scripture Scriptorium/i.test(t)) return renderRoom('bible');
    if(/Creative Quarter|Maker Studios|Creative Studio/i.test(t)) return renderRoom('creative');
    if(/Homestead Workshop|Home and Practical Work|Collections and Companions/i.test(t)) return renderRoom('homestead');
    if(/Core Halls.*Science|Realm Atlas|Subject Wings|Adventure Atlas/i.test(t)) return renderRoom('atlas');
  }

  function bind(){
    if(window.__LR74K_BOUND__) return;
    window.__LR74K_BOUND__ = true;
    window.addEventListener('click', function(ev){
      var el = ev.target && ev.target.closest ? ev.target.closest('[data-lr74k-act]') : null;
      if(!el) return;
      var act = el.getAttribute('data-lr74k-act');
      if(!act) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      route(act);
    }, true);
  }
  var timer = 0;
  function schedule(){ if(timer) return; timer = setTimeout(function(){ timer=0; styles(); detectOldScreen(); scrubFramework(); }, 120); }
  function boot(){
    styles(); bind(); scrubFramework();
    setTimeout(schedule,150);
    setTimeout(schedule,650);
    setTimeout(schedule,1500);
    try{
      var mo = new MutationObserver(function(){ schedule(); });
      mo.observe(document.body,{subtree:true,childList:true,characterData:true});
    }catch(e){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,120); setTimeout(schedule,900); });
})();
