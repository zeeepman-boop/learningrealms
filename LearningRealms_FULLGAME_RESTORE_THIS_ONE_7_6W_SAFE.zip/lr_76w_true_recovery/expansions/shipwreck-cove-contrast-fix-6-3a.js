/* Shipwreck Cove Contrast Fix 6.3a
   Small visual-only patch: makes the guided-tour primary button readable.
*/
(function(){
  'use strict';
  if(window.__LR_SHIPWRECK_COVE_CONTRAST_FIX_63A__) return;
  window.__LR_SHIPWRECK_COVE_CONTRAST_FIX_63A__ = true;
  function install(){
    if(document.getElementById('swczContrastFix63a')) return;
    var st=document.createElement('style');
    st.id='swczContrastFix63a';
    st.textContent = [
      '.swczCPrimary, button.swczCPrimary, .swczCHeroBtns button.swczCPrimary {',
      '  background:#1f5c73 !important;',
      '  color:#fffaf0 !important;',
      '  border-color:#0d3444 !important;',
      '  text-shadow:0 1px 1px rgba(0,0,0,.35) !important;',
      '  box-shadow:0 3px 8px rgba(0,0,0,.18) !important;',
      '}',
      '.swczCPrimary span, .swczCPrimary b, .swczCPrimary small { color:#fffaf0 !important; }',
      '.swczCHeroBtns button:not(.swczCPrimary), .swczCNav button:not(.swczCPrimary), .swczCChooser button:not(.swczCPrimary) {',
      '  background:#fffdf6 !important;',
      '  color:#20313e !important;',
      '  border-color:rgba(51,76,94,.35) !important;',
      '}',
      '.swczCHeroBtns button:not(.swczCPrimary) span, .swczCHeroBtns button:not(.swczCPrimary) small { color:#20313e !important; }',
      '.swczCHead { color:#20313e !important; }'
    ].join('\n');
    document.head.appendChild(st);
  }
  install();
  window.addEventListener('load', install);
  setTimeout(install, 300);
  setTimeout(install, 1200);
})();
