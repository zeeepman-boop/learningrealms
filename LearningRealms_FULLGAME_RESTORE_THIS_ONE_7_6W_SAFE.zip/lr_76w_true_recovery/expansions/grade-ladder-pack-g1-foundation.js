// Grade Ladder Pack G1: Grade 1 Foundation
// All children pass through this band after Kindergarten.
// Tagged with gradeBand:"G1" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG1Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G1",unit:"G1-READ-PHONICS",skill:"short vowels",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Short vowel sounds are quick sounds often found in small words.",
     workedExample:"In cat, the a makes the short a sound. In pig, the i makes the short i sound.",
     guidedPractice:"Say the word slowly and listen to the middle vowel sound.",
     q:"Which word has the short a sound?",c:["cat","cake","tree"],a:"cat",
     explain:"Cat has the quick short a sound."},

    {gradeBand:"G1",unit:"G1-READ-PHONICS",skill:"digraphs",difficulty:"grade 1",mode:"foundation",
     miniLesson:"A digraph is two letters that work together to make one sound.",
     workedExample:"Sh in ship makes one sound. Ch in chair also makes one sound.",
     guidedPractice:"Look for two letters making one sound at the start.",
     q:"Which word begins with a digraph?",c:["ship","frog","lamp"],a:"ship",
     explain:"Ship begins with sh, a digraph."},

    {gradeBand:"G1",unit:"G1-READ-COMP",skill:"story elements",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Stories have characters, settings, problems, and solutions.",
     workedExample:"If a rabbit loses a key in the forest, the rabbit is the character and the forest is the setting.",
     guidedPractice:"Ask who the story is about and where it happens.",
     q:"The owl sat in a tree. What is the setting?",c:["tree","owl","sat"],a:"tree",
     explain:"The setting is where the story happens."},

    {gradeBand:"G1",unit:"G1-READ-COMP",skill:"main idea and detail",difficulty:"grade 1",mode:"foundation",
     miniLesson:"The main idea is what something is mostly about. Details tell more about it.",
     workedExample:"A passage about frogs may have details about legs, ponds, and tadpoles.",
     guidedPractice:"Find what the whole passage is mostly about.",
     q:"A passage tells how frogs grow. What is the main idea?",c:["how frogs grow","one frog is green","the page is long"],a:"how frogs grow",
     explain:"The whole passage is mostly about how frogs grow."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G1",unit:"G1-MATH-FACTS",skill:"addition within 20",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Addition means putting amounts together.",
     workedExample:"7 + 5 can be solved by counting on: 8, 9, 10, 11, 12.",
     guidedPractice:"Start with the bigger number and count on.",
     q:"7 + 5 = ?",c:["12","11","13"],a:"12",
     explain:"Counting on from 7 five times gives 12."},

    {gradeBand:"G1",unit:"G1-MATH-FACTS",skill:"subtraction within 20",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Subtraction means taking away or finding what is left.",
     workedExample:"15 - 6 means start with 15 and take away 6. That leaves 9.",
     guidedPractice:"Check subtraction with addition.",
     q:"15 - 6 = ?",c:["9","8","10"],a:"9",
     explain:"9 + 6 = 15, so 15 - 6 = 9."},

    {gradeBand:"G1",unit:"G1-MATH-PLACE",skill:"tens and ones",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Two-digit numbers are made from tens and ones.",
     workedExample:"53 has 5 tens and 3 ones.",
     guidedPractice:"Look at the first digit for tens and the second digit for ones.",
     q:"53 has how many tens?",c:["5","3","53"],a:"5",
     explain:"The 5 is in the tens place."},

    {gradeBand:"G1",unit:"G1-MATH-MEASURE",skill:"time",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Time can be read to the hour and half hour.",
     workedExample:"Half past 2 means 2:30.",
     guidedPractice:"Half past means 30 minutes after the hour.",
     q:"Half past 2 is...",c:["2:30","2:00","3:30"],a:"2:30",
     explain:"Half past 2 means 2:30."},

    {gradeBand:"G1",unit:"G1-MATH-MEASURE",skill:"coins",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Coins have values. A dime is 10 cents and a nickel is 5 cents.",
     workedExample:"One dime and one nickel make 15 cents.",
     guidedPractice:"Count the dime first, then add the nickel.",
     q:"A dime and a nickel equal...",c:["15 cents","10 cents","5 cents"],a:"15 cents",
     explain:"10 cents plus 5 cents equals 15 cents."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G1",unit:"G1-ELA-SENTENCES",skill:"complete sentences",difficulty:"grade 1",mode:"foundation",
     miniLesson:"A complete sentence tells a whole thought.",
     workedExample:"The fox ran home. This tells who and what happened.",
     guidedPractice:"Check whether the words make a full idea.",
     q:"Which is a complete sentence?",c:["The fox ran home.","fox ran","home"],a:"The fox ran home.",
     explain:"The fox ran home is a complete thought."},

    {gradeBand:"G1",unit:"G1-ELA-SENTENCES",skill:"nouns and verbs",difficulty:"grade 1",mode:"foundation",
     miniLesson:"A noun names a person, place, thing, or animal. A verb shows action.",
     workedExample:"In The rabbit hops, rabbit is a noun and hops is a verb.",
     guidedPractice:"Ask who or what, then ask what it does.",
     q:"In The bird sings, which word is the verb?",c:["sings","bird","the"],a:"sings",
     explain:"Sings is the action word."},

    {gradeBand:"G1",unit:"G1-ELA-WRITING",skill:"adding details",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Details make writing clearer.",
     workedExample:"The dog ran is simple. The brown dog ran across the yard gives more detail.",
     guidedPractice:"Look for the sentence that tells more.",
     q:"Which sentence has more detail?",c:["The brown dog ran across the yard.","The dog ran.","Dog."],a:"The brown dog ran across the yard.",
     explain:"It tells what kind of dog and where it ran."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G1",unit:"G1-SCI-LIFE",skill:"plant parts",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Plants have parts that help them live.",
     workedExample:"Roots hold the plant in the soil. Leaves help the plant use sunlight.",
     guidedPractice:"Think about what each plant part does.",
     q:"Which plant part helps hold the plant in soil?",c:["roots","flower","leaf"],a:"roots",
     explain:"Roots help hold the plant in the soil."},

    {gradeBand:"G1",unit:"G1-SCI-LIFE",skill:"animal needs",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Animals need food, water, air, and shelter.",
     workedExample:"A bird needs food and water, and it may use a nest for shelter.",
     guidedPractice:"Choose something an animal needs to live.",
     q:"Which does an animal need?",c:["water","toy car","pencil"],a:"water",
     explain:"Animals need water to live."},

    {gradeBand:"G1",unit:"G1-SCI-EARTH",skill:"weather and seasons",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Weather can change from day to day. Seasons bring patterns of weather.",
     workedExample:"Winter is often colder. Summer is often warmer.",
     guidedPractice:"Choose the season often linked with cold weather.",
     q:"Which season is often cold?",c:["winter","summer","spring"],a:"winter",
     explain:"Winter is often the cold season."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G1",unit:"G1-SS-COMMUNITY",skill:"needs and wants",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Needs are things people must have. Wants are things people would like to have.",
     workedExample:"Food and water are needs. A toy is a want.",
     guidedPractice:"Ask whether someone must have it to live.",
     q:"Which is a need?",c:["food","toy","painting"],a:"food",
     explain:"Food is something people need."},

    {gradeBand:"G1",unit:"G1-SS-COMMUNITY",skill:"goods and services",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Goods are things people use. Services are jobs people do for others.",
     workedExample:"A book is a good. A haircut is a service.",
     guidedPractice:"Choose whether the answer is a thing or a job.",
     q:"Which is a service?",c:["haircut","apple","chair"],a:"haircut",
     explain:"A haircut is work someone does for another person."},

    {gradeBand:"G1",unit:"G1-SS-MAPS",skill:"maps and symbols",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Maps show places. Symbols stand for things on a map.",
     workedExample:"A star symbol may show a capital city. A line may show a road.",
     guidedPractice:"Think about what helps people find places.",
     q:"What helps show where places are?",c:["map","verb","shadow"],a:"map",
     explain:"A map shows places and helps people find their way."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G1",unit:"G1-ART-COLOR",skill:"primary colors",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Primary colors are important starting colors in art.",
     workedExample:"Red, blue, and yellow are primary colors.",
     guidedPractice:"Remember the three starting colors.",
     q:"Which is a primary color?",c:["blue","pink","brown"],a:"blue",
     explain:"Blue is one of the primary colors."},

    {gradeBand:"G1",unit:"G1-ART-LINES",skill:"lines and shapes",difficulty:"grade 1",mode:"foundation",
     miniLesson:"Artists use lines and shapes to build pictures.",
     workedExample:"A house can use a square for the wall and a triangle for the roof.",
     guidedPractice:"Look for the shape that could make a roof.",
     q:"Which shape could make a simple roof?",c:["triangle","circle","oval"],a:"triangle",
     explain:"A triangle can make a pointed roof."}
  ]);
}

LR_addG1Foundation("Luna");
LR_addG1Foundation("Ava");
LR_addG1Foundation("Michael");
