/* LearningRealms Inventions & Engineering Disasters Stability Polish Pack 6.4A
   Small safe patch on top of 6.4.
   Goals: preserve visible game shell, keep one Go Learn button, make the Inventions launcher cleaner in Go Learn,
   and avoid duplicate launcher rows or popup/readability issues. No lesson content is removed or replaced.
*/
(function(){
  'use strict';
  if(window.__LR64A_INV_STABILITY_POLISH__) return;
  window.__LR64A_INV_STABILITY_POLISH__ = true;

  function byId(id){ return document.getElementById(id); }
  function norm(s){ return String(s||'').replace(/\s+/g,' ').trim().toLowerCase(); }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function visible(el){ return !!(el && el.offsetParent !== null && getComputedStyle(el).display !== 'none' && getComputedStyle(el).visibility !== 'hidden'); }

  function addStyles(){
    if(byId('lr64aInvPolishStyles')) return;
    var st=document.createElement('style');
    st.id='lr64aInvPolishStyles';
    st.textContent = [
      'body,.shell,main,.card,.main,.actionSidebar,.rightSidebar,.playerSidebar{visibility:visible!important;opacity:1!important}',
      '.lr64aInvLauncher{display:block;margin:0 0 14px 0;padding:14px;border-radius:16px;background:linear-gradient(135deg,#173247,#244c62)!important;border:2px solid rgba(255,226,155,.75)!important;box-shadow:0 10px 24px rgba(0,0,0,.22)!important;color:#fff!important}',
      '.lr64aInvLauncher *{color:#fff!important}',
      '.lr64aInvLauncherTitle{font-weight:900;font-size:1.08rem;margin-bottom:8px}',
      '.lr64aInvLauncher small{display:block;opacity:.95;font-weight:600;line-height:1.35;margin-top:4px}',
      '.lr64aInvLauncher button{width:100%;text-align:left;margin-top:8px;border:1px solid rgba(255,232,170,.9)!important;background:#fff7d8!important;color:#1e261f!important;border-radius:14px;padding:12px 14px;font-weight:900;cursor:pointer}',
      '.lr64aInvLauncher button *{color:#1e261f!important}',
      '.lr64aInvLauncher button.secondary{background:#e8f4ff!important}',
      '.invShell,.invShell p,.invShell small,.invShell b,.invShell h2,.invShell h3,.invShell label{color:#21313d!important}',
      '.invPrimary{background:#9b6500!important;border-color:#5e3d00!important;color:#fff!important}',
      '.invPrimary *{color:#fff!important}',
      '.invNav button[disabled]{opacity:.45;cursor:not-allowed}',
      '[data-lr64a-hidden-dupe-golearn="1"],[data-lr64a-hidden-dupe-inv="1"]{display:none!important}'
    ].join('\n');
    document.head.appendChild(st);
  }

  function dedupeGoLearn(){
    try{
      var buttons=[].slice.call(document.querySelectorAll('button'));
      var goButtons=buttons.filter(function(b){ var t=norm(b.textContent); return t==='go learn' || t==='📘 go learn'; });
      if(goButtons.length <= 1) return;
      var keeper = goButtons.find(function(b){ return b.closest && b.closest('#leftActionButtons'); }) || goButtons.find(visible) || goButtons[0];
      goButtons.forEach(function(b){
        if(b===keeper){ b.removeAttribute('data-lr64a-hidden-dupe-golearn'); b.style.display=''; }
        else { b.setAttribute('data-lr64a-hidden-dupe-golearn','1'); }
      });
    }catch(e){}
  }

  function removeDuplicateInventionRows(container){
    try{
      var body = container || byId('lrPopupBody') || byId('actionText') || document.body;
      var rows=[].slice.call(body.querySelectorAll('[data-lr64-inventions-row],[data-lr64a-inventions-row]'));
      if(rows.length <= 1) return;
      rows.forEach(function(row,idx){ if(idx>0) row.setAttribute('data-lr64a-hidden-dupe-inv','1'); });
    }catch(e){}
  }

  function addInventionsLauncher(){
    try{
      if(typeof window.openInventionsDeepCourse !== 'function') return;
      var body = byId('lrPopupBody') || byId('actionText') || document.querySelector('.lrPopupBody');
      if(!body) return;
      removeDuplicateInventionRows(body);
      if(body.querySelector('[data-lr64a-inventions-row]') || body.querySelector('[data-lr64-inventions-row]')){
        var old = body.querySelector('[data-lr64-inventions-row]');
        if(old){
          old.className = 'lr64aInvLauncher';
          old.style.cssText = '';
          old.setAttribute('data-lr64a-inventions-restyled','1');
        }
        return;
      }
      var row=document.createElement('div');
      row.className='lr64aInvLauncher';
      row.setAttribute('data-lr64a-inventions-row','1');
      row.innerHTML =
        '<div class="lr64aInvLauncherTitle">💡 Inventions & Engineering Disasters</div>'+
        '<small>Grade 5+ deep course · prototypes, famous failures, redesign, safety culture, and practical engineering thinking.</small>'+
        '<button type="button" onclick="openInventionsDeepCourse()">💡 Open Deep Master Course<span style="display:block;font-weight:600;font-size:.88rem;margin-top:4px">Starts the full inventions and engineering-disasters course.</span></button>'+
        '<button type="button" class="secondary" onclick="openInventionsRewardCatalog()">🎁 View invention reward catalog<span style="display:block;font-weight:600;font-size:.88rem;margin-top:4px">Shows the collectibles and vanity rewards tied to the course.</span></button>';
      if(body.firstChild) body.insertBefore(row, body.firstChild); else body.appendChild(row);
    }catch(e){ console.warn('LR64A inventions launcher failed', e); }
  }

  function stabilizePopups(){
    try{
      var root=byId('lrPopupRoot');
      if(root){ root.style.zIndex='99990'; }
      var popup=byId('lrPopupBody');
      if(popup){ popup.style.color='#21313d'; }
    }catch(e){}
  }

  function installHealthCheck(){
    window.lr64aInventionsHealthCheck = function(){
      var courseLoaded = typeof window.openInventionsDeepCourse === 'function';
      var goCount = [].slice.call(document.querySelectorAll('button')).filter(function(b){ var t=norm(b.textContent); return (t==='go learn' || t==='📘 go learn') && !b.hasAttribute('data-lr64a-hidden-dupe-golearn'); }).length;
      return {
        courseLoaded: courseLoaded,
        visibleGoLearnButtons: goCount,
        notes: courseLoaded ? '6.4A course hook is loaded.' : 'Inventions course hook was not found yet.'
      };
    };
  }

  function wrapChooser(name){
    try{
      if(typeof window[name] !== 'function' || window[name].__lr64aInvWrapped) return;
      var old=window[name];
      var repl=function(){
        var out=old.apply(this,arguments);
        [40,120,300,700].forEach(function(ms){ setTimeout(run,ms); });
        return out;
      };
      repl.__lr64aInvWrapped=true;
      window[name]=repl;
      try{ eval(name+'=window[name]'); }catch(e){}
    }catch(e){}
  }

  function run(){
    addStyles();
    stabilizePopups();
    dedupeGoLearn();
    removeDuplicateInventionRows();
    wrapChooser('lr19OpenLearningChooser');
    wrapChooser('lr18OpenLearningChooser');
    wrapChooser('lr16OpenLearningChooser');
    // Only add the inventions launcher when a learning/menu popup appears, so the main screen stays clean.
    var title = byId('lrPopupTitle');
    var body = byId('lrPopupBody');
    var popupLooksOpen = body && body.innerHTML && (!byId('lrPopupRoot') || !byId('lrPopupRoot').classList.contains('hidden'));
    var actionTitle = byId('actionTitle');
    var actionLooksLikeLearning = actionTitle && /learn|lesson|curriculum|subject|course/i.test(actionTitle.textContent||'');
    if(popupLooksOpen || actionLooksLikeLearning) addInventionsLauncher();
  }

  installHealthCheck();
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){ run(); [100,400,1000,2000].forEach(function(ms){setTimeout(run,ms);}); });
  else { run(); [100,400,1000,2000].forEach(function(ms){setTimeout(run,ms);}); }
  window.addEventListener('load',function(){ run(); setTimeout(run,500); setTimeout(run,1500); });
})();
