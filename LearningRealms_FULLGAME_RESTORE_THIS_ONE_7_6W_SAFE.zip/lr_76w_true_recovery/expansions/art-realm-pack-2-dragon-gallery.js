// Art Realm Pack 2: Dragon Gallery + Sketchbook Studio
// Fixes/locks Dragonbrush Vale into LR_ROOMS correctly and expands Art into a fuller subject.
// Adds gallery rooms, art portfolio prompts, rewards, targets, curriculum map units, and more Art lessons.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const artRooms = {
    dragonbrushRoad1:{
      title:"Lantern Path",
      zone:"Dragonbrush Vale Road",
      text:"A cobbled lane bends away from the eastern edge of town beneath painted lanterns shaped like dragon eggs. A wooden sign shows a brush crossed with a dragon wing. The air smells faintly of pine, parchment, and paint.",
      exits:{north:"eastTownRoad",east:"dragonbrushRoad2"}
    },
    dragonbrushRoad2:{
      title:"Painter's Rise",
      zone:"Dragonbrush Vale Road",
      text:"The road climbs a gentle rise where ribbons flutter from carved poles. Painted stones mark the way forward, each one decorated with little dragon footprints, swirls, stars, and bright leaves.",
      exits:{west:"dragonbrushRoad1",east:"dragonbrushRoad3"}
    },
    dragonbrushRoad3:{
      title:"Bridge of Colors",
      zone:"Dragonbrush Vale Road",
      text:"A bright arched bridge crosses a clear stream. Mineral streaks in the stones make the water sparkle with reds, blues, yellows, greens, and violet flashes. Beyond the bridge, high cliffs curve around a hidden valley.",
      exits:{west:"dragonbrushRoad2",east:"dragonbrushGate"}
    },

    dragonbrushGate:{
      title:"Dragonbrush Gate",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"You stand at the entrance to Dragonbrush Vale, a peaceful bowl of green hills and painted stone paths. Colorful streamers hang between carved dragon statues. A tiny ember dragon sketches glowing lines in the air with its tail.",
      npc:{name:"Emberline",desc:"Emberline is a small ember-scaled dragon who teaches lines, shapes, and brave first sketches.",text:"Emberline chirps, 'Every great picture begins with one little line. Come on, artist. Let us warm up those drawing claws!'"},
      exits:{west:"dragonbrushRoad3",east:"paletteMeadow",south:"sketchHollow"}
    },
    paletteMeadow:{
      title:"Palette Meadow",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"Soft grass ripples through a meadow ringed by flowers in every shade. Painted easels stand under the open sky. A broad flat stone nearby is dotted with dry specks of color left by earlier students.",
      npc:{name:"Chroma Puff",desc:"Chroma Puff is a round paint-splattered dragon who teaches color families, mixing, and mood.",text:"Chroma Puff taps jars of color with one claw. 'Color is not just pretty. Color tells the eye where to look and the heart what to feel.'"},
      exits:{west:"dragonbrushGate",east:"winglightOverlook",south:"muralCourt"}
    },
    winglightOverlook:{
      title:"Winglight Overlook",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"A cliff overlook opens above the vale, where sunlight strikes crystal fragments set into the path. Looking out from here, the hills and trees make clear foreground, middle ground, and background layers.",
      npc:{name:"Silverwing Master Orro",desc:"Orro is an old silver dragon who teaches perspective, distance, and how artists guide the viewer's eye.",text:"Orro lowers his wise head. 'Depth is a trick of the eye, little traveler. Learn the trick, and a flat page becomes a world.'"},
      exits:{west:"paletteMeadow",south:"scaleGallery"}
    },
    sketchHollow:{
      title:"Sketch Hollow",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"A quiet hollow beneath bent willow branches shelters long benches, charcoal sticks, and smooth paper boards. The hush here makes every scratch of pencil feel important.",
      npc:{name:"Ashcurl",desc:"Ashcurl is a smoke-gray dragon who teaches sketching, value, shading, and careful observation.",text:"Ashcurl nudges a charcoal stick forward. 'Draw what you see first. Fancy can come later.'"},
      exits:{north:"dragonbrushGate",east:"muralCourt",south:"sketchbookStudio"}
    },
    muralCourt:{
      title:"Mural Court",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"Tall stone walls form an open court covered in bright murals of heroes, animals, castles, storms, and stars. Some pictures are simple and bold. Others are layered with tiny details that reward a long look.",
      npc:{name:"Muraldrake",desc:"Muraldrake is a broad green dragon who teaches picture storytelling, composition, and how details build meaning.",text:"Muraldrake smiles at the wall. 'A picture can tell a story before a single word is read.'"},
      exits:{north:"paletteMeadow",west:"sketchHollow",east:"scaleGallery"}
    },
    scaleGallery:{
      title:"Hall of Bright Scales",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"This round teaching hall is roofed in overlapping tiles that gleam like dragon scales. Finished student paintings line the walls. Pedestals display carved masks, clay figures, and folded paper dragons.",
      npc:{name:"Master Azurea",desc:"Master Azurea is a majestic blue dragon and the keeper of the Dragon Gallery.",text:"Master Azurea bows. 'Technique matters, but attention matters more. Slow eyes make strong artists.'"},
      exits:{north:"winglightOverlook",west:"muralCourt",south:"dragonGallery"}
    },
    sketchbookStudio:{
      title:"Sketchbook Studio",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"Long tables hold sketchbooks, colored pencils, chalk, clay, folded paper, and clean practice boards. A large sign reads: Make work worth saving. The room feels calm, creative, and ready for portfolio work.",
      npc:{name:"Quillscale",desc:"Quillscale is a thin golden dragon who guards the sketchbooks and encourages steady daily practice.",text:"Quillscale whispers, 'A sketchbook is not for perfect work. It is for growing work.'"},
      exits:{north:"sketchHollow",east:"dragonGallery"}
    },
    dragonGallery:{
      title:"Dragon Gallery",
      zone:"Dragonbrush Vale",
      subject:"Art",
      text:"A warm gallery cave opens into a circular room lit by glowing crystals. Empty frames wait for future student work. Dragon statues hold plaques for color, line, shape, value, form, contrast, and perspective.",
      npc:{name:"Gallery Wyrm Solaro",desc:"Solaro is a calm gold dragon who teaches critique, reflection, and how to talk about art respectfully.",text:"Solaro blinks slowly. 'An artist learns twice: once while making, and again while looking back.'"},
      exits:{north:"scaleGallery",west:"sketchbookStudio"}
    }
  };

  Object.assign(ROOMS, artRooms);

  if(ROOMS.eastTownRoad){
    ROOMS.eastTownRoad.exits = ROOMS.eastTownRoad.exits || {};
    ROOMS.eastTownRoad.exits.south = "dragonbrushRoad1";
  }
})();

(function(){
  // Add Art rewards to normal lesson reward pool.
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Art = window.LR_REWARDS.Art || [];
  window.LR_REWARDS.Art.push(
    {name:"Tiny Dragon Sketch",slot:"wall"},
    {name:"Color Wheel Tile",slot:"wall"},
    {name:"Charcoal Pencil Cup",slot:"desk"},
    {name:"Dragon Scale Paint Jar",slot:"shelf"},
    {name:"Gallery Candle",slot:"shelf"},
    {name:"Folded Paper Dragon",slot:"shelf"},
    {name:"Perspective Practice Board",slot:"desk"},
    {name:"Warm and Cool Banner",slot:"wall"}
  );
})();

(function(){
  // Add Art to grade targets in a scalable way.
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Art = {display:"Art / Drawing / Color",targetCorrect:180,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Art = {display:"Art / Design / Visual Response",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Art = {display:"Art / Design / Analysis",targetCorrect:240,bossTarget:1};
})();

(function(){
  // Add Art to daily classroom rotation lightly, not replacing core subjects.
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};
  cfg.timeBlocks = cfg.timeBlocks || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Art")) cfg.assignmentSubjects[child].push("Art");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Art:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Art:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Art:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  // Add Art units to curriculum map.
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Art = {
    zone:"Dragonbrush Vale",
    units:[
      {id:"G1-ART-COLOR",title:"Color Basics",goal:"Recognize primary colors, color choices, and simple color meaning.",targetLessons:120,skills:["primary colors","warm colors","cool colors","color choice","color mood"]},
      {id:"G1-ART-LINES",title:"Lines and Shapes",goal:"Use lines and shapes to build simple pictures.",targetLessons:120,skills:["straight lines","curved lines","zigzag lines","circles","triangles","rectangles"]},
      {id:"G1-ART-STORY",title:"Picture Storytelling",goal:"Use pictures to show characters, setting, action, and details.",targetLessons:100,skills:["picture details","setting","action","character","story order"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Art = {
    zone:"Dragonbrush Vale",
    units:[
      {id:"G7-ART-COLOR",title:"Color and Mood",goal:"Use warm/cool colors, value, contrast, and color choices to affect mood.",targetLessons:160,skills:["warm colors","cool colors","value","contrast","mood"]},
      {id:"G7-ART-COMPOSITION",title:"Composition and Space",goal:"Understand composition, foreground/background, balance, focus, and visual path.",targetLessons:160,skills:["composition","foreground","middle ground","background","balance","focal point"]},
      {id:"G7-ART-CRITIQUE",title:"Art Vocabulary and Critique",goal:"Use precise art vocabulary to describe and evaluate artwork.",targetLessons:120,skills:["texture","line","shape","form","value","critique","artist choices"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Art = {
    zone:"Dragonbrush Vale",
    units:[
      {id:"G8-ART-FORM",title:"Form, Value, and Proportion",goal:"Use value, proportion, and light/shadow to create convincing form.",targetLessons:180,skills:["form","value","proportion","light","shadow","observation"]},
      {id:"G8-ART-PERSPECTIVE",title:"Perspective and Depth",goal:"Understand one-point perspective, vanishing point, scale, and depth.",targetLessons:160,skills:["one-point perspective","vanishing point","horizon line","depth","scale"]},
      {id:"G8-ART-DESIGN",title:"Design and Analysis",goal:"Analyze design choices using contrast, balance, emphasis, and composition.",targetLessons:160,skills:["contrast","balance","emphasis","composition","analysis","visual evidence"]}
    ]
  };
})();

(function(){
  // Add Art portfolio prompts.
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-ART-DRAGON-1",subject:"Art",unit:"G1-ART-LINES",title:"Draw a Line Dragon",prompt:"Draw a friendly dragon using at least three kinds of lines. Tell which lines you used.",helper:"Try straight, curved, zigzag, thick, or thin lines.",estimatedMinutes:20},
    {id:"LUNA-ART-STORY-1",subject:"Art",unit:"G1-ART-STORY",title:"Picture Story Page",prompt:"Draw one picture that tells a tiny story. Include a character, a place, and something happening.",helper:"Think: Who is in the picture? Where are they? What are they doing?",estimatedMinutes:20}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-ART-COLOR-MOOD-1",subject:"Art",unit:"G7-ART-COLOR",title:"Color Mood Study",prompt:"Make or describe two small color plans for the same scene: one warm and one cool. Explain how the mood changes.",helper:"Use words like calm, bright, tense, cozy, quiet, or energetic.",estimatedMinutes:25},
    {id:"AVA-ART-COMPOSITION-1",subject:"Art",unit:"G7-ART-COMPOSITION",title:"Focal Point Sketch",prompt:"Create or describe a picture where the viewer knows where to look first. Explain what makes that area the focal point.",helper:"Think about size, contrast, placement, and lines pointing toward the subject.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-ART-PERSPECTIVE-1",subject:"Art",unit:"G8-ART-PERSPECTIVE",title:"One-Point Perspective Plan",prompt:"Draw or describe a hallway, road, or bridge using one-point perspective. Identify the vanishing point.",helper:"Receding lines should aim toward the same point.",estimatedMinutes:30},
    {id:"MICHAEL-ART-ANALYSIS-1",subject:"Art",unit:"G8-ART-DESIGN",title:"Analyze an Artwork",prompt:"Choose any artwork or picture in the game world and explain how contrast, focus, or composition affects what the viewer notices first.",helper:"Use visual evidence. Say what you notice and why it matters.",estimatedMinutes:30}
  );
})();

(function(){
  // More Art lessons.
  LR_addLessons("Luna","Art",[
    {unit:"G1-ART-COLOR",skill:"warm colors",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"Warm colors can feel bright, sunny, or energetic.",
     workedExample:"Red, orange, and yellow are usually warm colors. A picture of a campfire might use warm colors.",
     guidedPractice:"Think about colors that remind you of fire or sunshine.",
     q:"Which is usually a warm color?",c:["orange","blue","purple"],a:"orange",
     explain:"Orange is usually grouped with warm colors."},

    {unit:"G1-ART-LINES",skill:"zigzag lines",difficulty:"practice",mode:"daily-drill",
     miniLesson:"A zigzag line changes direction sharply.",
     workedExample:"Lightning is often drawn with a zigzag line.",
     guidedPractice:"Think about a line that goes pointy back and forth.",
     q:"Which line could show lightning?",c:["zigzag","smooth curve","circle"],a:"zigzag",
     explain:"Lightning is often shown with a sharp zigzag."},

    {unit:"G1-ART-STORY",skill:"setting details",difficulty:"application",mode:"applied-practice",
     miniLesson:"Setting details show where a picture story happens.",
     workedExample:"Trees, mushrooms, and a path can show that the story happens in a forest.",
     guidedPractice:"Look for details that tell the place.",
     q:"Which detail best shows a forest setting?",c:["trees","fork","blank paper"],a:"trees",
     explain:"Trees help the viewer know the setting is a forest."},

    {unit:"G1-ART-SHAPES",skill:"building pictures",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"Simple shapes can build bigger pictures.",
     workedExample:"A dragon can start with an oval body, triangle spikes, circle eyes, and curved wings.",
     guidedPractice:"Look for the shape that could make dragon spikes.",
     q:"Which shape could make pointed dragon spikes?",c:["triangle","circle","oval"],a:"triangle",
     explain:"Triangles have points, so they work well for spikes."},

    {unit:"G1-ART-COLOR",skill:"color choice",difficulty:"application",mode:"applied-practice",
     miniLesson:"Artists choose colors to help a picture feel a certain way.",
     workedExample:"A sunny picture might use yellow. A nighttime picture might use dark blue.",
     guidedPractice:"Choose the color that best fits the scene.",
     q:"Which color best fits a sunny picture?",c:["yellow","black","gray"],a:"yellow",
     explain:"Yellow often makes people think of sun and brightness."}
  ]);

  LR_addLessons("Ava","Art",[
    {unit:"G7-ART-COLOR",skill:"contrast",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"Contrast is a strong difference between elements.",
     workedExample:"A bright white moon on a dark blue sky creates strong contrast.",
     guidedPractice:"Look for two things that are very different.",
     q:"A bright shape on a dark background creates strong...",c:["contrast","timeline","supply"],a:"contrast",
     explain:"Contrast helps important parts stand out."},

    {unit:"G7-ART-COMPOSITION",skill:"focal point",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"A focal point is the area the viewer notices first.",
     workedExample:"An artist can make a dragon the focal point by making it larger, brighter, or centered.",
     guidedPractice:"Ask where your eye goes first.",
     q:"The area a viewer notices first is the...",c:["focal point","subtitle","denominator"],a:"focal point",
     explain:"The focal point is the main area of attention."},

    {unit:"G7-ART-COMPOSITION",skill:"balance",difficulty:"practice",mode:"daily-drill",
     miniLesson:"Balance is how visual weight is arranged.",
     workedExample:"A large object on one side may be balanced by several smaller objects on the other side.",
     guidedPractice:"Think about whether one side feels too heavy.",
     q:"Balance is about arranging visual...",c:["weight","temperature","citizenship"],a:"weight",
     explain:"Visual balance deals with how heavy or light parts feel in a composition."},

    {unit:"G7-ART-CRITIQUE",skill:"critique",difficulty:"application",mode:"applied-practice",
     miniLesson:"A critique is a careful, respectful discussion of artwork.",
     workedExample:"Instead of saying 'good' or 'bad,' explain what works and what could be stronger.",
     guidedPractice:"Use art words and specific observations.",
     q:"A helpful critique should be...",c:["specific and respectful","rude and vague","only one word"],a:"specific and respectful",
     explain:"Good critique helps the artist understand what is working and what to improve."},

    {unit:"G7-ART-COLOR",skill:"value",difficulty:"application",mode:"applied-practice",
     miniLesson:"Value helps show light and shadow.",
     workedExample:"A shaded side of a dragon egg can make it look round.",
     guidedPractice:"Ask where the light side and dark side should be.",
     q:"Value helps show...",c:["light and shadow","only the title","the page number"],a:"light and shadow",
     explain:"Value is lightness and darkness, which helps show form."}
  ]);

  LR_addLessons("Michael","Art",[
    {unit:"G8-ART-PERSPECTIVE",skill:"horizon line",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"The horizon line is the viewer's eye level in many perspective drawings.",
     workedExample:"In a road scene, the vanishing point often sits on the horizon line.",
     guidedPractice:"Find eye level first, then place the vanishing point.",
     q:"In perspective, the horizon line often represents...",c:["eye level","shadow color","paper size"],a:"eye level",
     explain:"The horizon line usually shows the viewer's eye level."},

    {unit:"G8-ART-FORM",skill:"light source",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"A light source tells where light is coming from.",
     workedExample:"If light comes from the left, the left side of the object is lighter and the right side may be darker.",
     guidedPractice:"Choose shadow direction based on the light source.",
     q:"If light comes from the left, the shadow side is usually on the...",c:["right","left","top only"],a:"right",
     explain:"The side away from the light is usually darker."},

    {unit:"G8-ART-DESIGN",skill:"emphasis",difficulty:"teaching",mode:"guided lesson",
     miniLesson:"Emphasis makes one part of an artwork stand out.",
     workedExample:"A glowing dragon eye in a dark cave creates emphasis.",
     guidedPractice:"Look for what the artist wants you to notice first.",
     q:"Emphasis helps one part...",c:["stand out","disappear","be measured in miles"],a:"stand out",
     explain:"Emphasis draws attention to an important area."},

    {unit:"G8-ART-ANALYSIS",skill:"visual evidence",difficulty:"application",mode:"applied-practice",
     miniLesson:"Art analysis should use visual evidence.",
     workedExample:"You might say the picture feels tense because the colors are dark and the lines are sharp.",
     guidedPractice:"Point to something you can actually see in the artwork.",
     q:"Visual evidence means evidence you can...",c:["see in the artwork","guess without looking","hear from a rumor"],a:"see in the artwork",
     explain:"Visual evidence comes from details visible in the image."},

    {unit:"G8-ART-PROPORTION",skill:"checking proportions",difficulty:"practice",mode:"daily-drill",
     miniLesson:"Artists check proportions by comparing parts.",
     workedExample:"If a dragon wing is tiny compared with the body, the artist may need to enlarge it for balance.",
     guidedPractice:"Compare one part to another.",
     q:"Proportion compares...",c:["sizes of parts","weather patterns","source dates"],a:"sizes of parts",
     explain:"Proportion is about how the sizes of parts relate to one another."}
  ]);
})();

(function(){
  // Add stronger Art boss content if Boss Content Pack is active.
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Art = [
    {title:"Emberline's Line Boss",intro:"Emberline draws glowing lines in the air and asks you to name what artists use to build pictures.",q:"Which can be straight, curved, zigzag, thick, or thin?",c:["line","coin","weather"],a:"line",reward:"Emberline Line Banner"},
    {title:"Color Egg Boss",intro:"Three dragon eggs glow red, blue, and yellow.",q:"Which color is a primary color?",c:["blue","pink","brown"],a:"blue",reward:"Primary Color Dragon Egg"}
  ];

  window.LR_BOSS_CONTENT.Ava.Art = [
    {title:"Chroma Puff's Value Boss",intro:"Chroma Puff shades a dragon egg until it looks round.",q:"In art, value means...",c:["lightness or darkness","speed","citizenship"],a:"lightness or darkness",reward:"Value Scale Scroll"},
    {title:"Muraldrake's Composition Boss",intro:"Muraldrake points to the part of a mural everyone notices first.",q:"The area a viewer notices first is the...",c:["focal point","suffix","source date"],a:"focal point",reward:"Focal Point Frame"}
  ];

  window.LR_BOSS_CONTENT.Michael.Art = [
    {title:"Orro's Perspective Boss",intro:"Silverwing Master Orro points toward a road that narrows into the distance.",q:"In one-point perspective, receding lines meet at the...",c:["vanishing point","color jar","caption"],a:"vanishing point",reward:"Perspective Dragon Lens"},
    {title:"Solaro's Analysis Boss",intro:"Gallery Wyrm Solaro asks for visual proof, not guesses.",q:"Art analysis should use evidence you can...",c:["see in the artwork","guess without looking","hear from a rumor"],a:"see in the artwork",reward:"Gallery Critic Seal"}
  ];
})();
