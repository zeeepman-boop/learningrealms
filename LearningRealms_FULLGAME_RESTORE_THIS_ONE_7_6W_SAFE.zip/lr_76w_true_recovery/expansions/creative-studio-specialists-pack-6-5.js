/* LearningRealms Creative Studio Specialists Pack 6.5
   Built on 6.4A. Adds a safe deep creative-arts course only.
   No guided zone, no shell replacement, no floating buttons.
*/
(function(){
'use strict';
if(window.__LR65_CREATIVE_STUDIO__) return;
window.__LR65_CREATIVE_STUDIO__=true;
var COURSE={
  "id": "creative_studio_specialists_pack_6_5_v01",
  "label": "Creative Studio Specialists",
  "icon": "🎨",
  "subject": "Creative Studio",
  "summary": "A safe, hands-on creative course covering drawing, painting, craft work, design, theater, music, storytelling, gallery habits, and themed maker rewards.",
  "topics": [
    {
      "studio": "Drawing Desk",
      "title": "Welcome to the Drawing Desk",
      "icon": "✏️",
      "summary": "Drawing is careful seeing turned into marks. It trains the eyes, the hand, and the patience to notice shape, edge, size, direction, and detail.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "pencil",
          "paragraphs": [
            "Welcome to the Drawing Desk teaches this main idea: Drawing is careful seeing turned into marks. It trains the eyes, the hand, and the patience to notice shape, edge, size, direction, and detail.",
            "This belongs in the Drawing Desk because A drawing desk is useful because almost every creative field begins with some kind of sketch, plan, map, doodle, diagram, or rough visual idea.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are line, shape, edge, sketch. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "The basic tools are simple: pencil, eraser, paper, sharpener, ruler, and a flat place to work. A sketchbook keeps attempts together so progress can be seen later.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep pencils away from eyes and mouths, use scissors only when needed, and keep the desk clear so tools do not roll or fall.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Begin with slow looking. Notice the biggest shape first, then smaller shapes, then lines, corners, shadows, and texture.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Good drawing is not about making a perfect picture on the first try. It is about building a habit of checking what is really there.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Pick one simple object and draw only its outside edge before adding any inside detail.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ✏️ Sketchbook Starter Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Drawing Desk?",
          "choices": [
            "Drawing is careful seeing turned into marks. It trains the eyes, the hand, and the patience to notice shape, edge, size, direction, and detail.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Drawing Desk belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A drawing desk is useful because almost every creative field begins with some kind of sketch, plan, map, doodle, diagram, or rough visual idea.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Drawing Desk?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "The basic tools are simple: pencil, eraser, paper, sharpener, ruler, and a flat place to work. A sketchbook keeps attempts together so progress can be seen later.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Begin with slow looking. Notice the biggest shape first, then smaller shapes, then lines, corners, shadows, and texture."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Drawing Desk?",
          "choices": [
            "Good drawing is not about making a perfect picture on the first try. It is about building a habit of checking what is really there.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep pencils away from eyes and mouths, use scissors only when needed, and keep the desk clear so tools do not roll or fall.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words line, shape, edge, sketch matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Drawing Desk?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Pick one simple object and draw only its outside edge before adding any inside detail."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "✏️ Sketchbook Starter Badge"
    },
    {
      "studio": "Drawing Desk",
      "title": "Lines that show direction",
      "icon": "➰",
      "summary": "A line can show direction, movement, border, energy, texture, or separation between shapes.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "line",
          "paragraphs": [
            "Lines that show direction teaches this main idea: A line can show direction, movement, border, energy, texture, or separation between shapes.",
            "This belongs in the Drawing Desk because Lines are one of the oldest and simplest art tools, and they appear in drawings, maps, plans, lettering, comics, borders, and symbols.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are straight line, curve, zigzag, contour. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a pencil, crayon, marker, or brush. Try straight lines, curved lines, zigzags, spirals, broken lines, and thick-to-thin lines.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Pressing too hard can tear paper or tire the hand; gentle control usually gives more choices.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice making the same line slowly, quickly, softly, and firmly. Each change gives a different feeling and purpose.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A careful line is not always a fancy line. Sometimes the best line is plain because it explains the shape clearly.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a small path using five kinds of lines and label what each line is doing.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ➰ Line Explorer Ribbon",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Lines that show direction?",
          "choices": [
            "A line can show direction, movement, border, energy, texture, or separation between shapes.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Lines that show direction belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Lines are one of the oldest and simplest art tools, and they appear in drawings, maps, plans, lettering, comics, borders, and symbols.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Lines that show direction?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a pencil, crayon, marker, or brush. Try straight lines, curved lines, zigzags, spirals, broken lines, and thick-to-thin lines.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice making the same line slowly, quickly, softly, and firmly. Each change gives a different feeling and purpose."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Lines that show direction?",
          "choices": [
            "A careful line is not always a fancy line. Sometimes the best line is plain because it explains the shape clearly.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Pressing too hard can tear paper or tire the hand; gentle control usually gives more choices.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words straight line, curve, zigzag, contour matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Lines that show direction?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a small path using five kinds of lines and label what each line is doing."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "➰ Line Explorer Ribbon"
    },
    {
      "studio": "Drawing Desk",
      "title": "Shapes inside everything",
      "icon": "🔷",
      "summary": "Most objects can be started by noticing simple shapes such as circles, ovals, rectangles, triangles, cylinders, and boxes.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "shapes",
          "paragraphs": [
            "Shapes inside everything teaches this main idea: Most objects can be started by noticing simple shapes such as circles, ovals, rectangles, triangles, cylinders, and boxes.",
            "This belongs in the Drawing Desk because Artists, builders, map makers, and inventors use shape thinking because complicated things become easier when broken into parts.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are circle, oval, rectangle, triangle, form. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use pencil first and keep the first shapes light. A ruler can help with boxes, but many natural objects need loose rounded shapes.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not erase every guide line immediately; light planning lines help until the larger drawing is steady.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Look for the biggest shape, then the next shape attached to it, then the smaller features.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Shape drawing helps prevent guessing. It asks the maker to build the picture instead of chasing tiny details too soon.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a toy, cup, or shoe by first marking the simple shapes hidden inside it.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔷 Shape Builder Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Shapes inside everything?",
          "choices": [
            "Most objects can be started by noticing simple shapes such as circles, ovals, rectangles, triangles, cylinders, and boxes.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Shapes inside everything belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Artists, builders, map makers, and inventors use shape thinking because complicated things become easier when broken into parts.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Shapes inside everything?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use pencil first and keep the first shapes light. A ruler can help with boxes, but many natural objects need loose rounded shapes.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Look for the biggest shape, then the next shape attached to it, then the smaller features."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Shapes inside everything?",
          "choices": [
            "Shape drawing helps prevent guessing. It asks the maker to build the picture instead of chasing tiny details too soon.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not erase every guide line immediately; light planning lines help until the larger drawing is steady.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words circle, oval, rectangle, triangle, form matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Shapes inside everything?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a toy, cup, or shoe by first marking the simple shapes hidden inside it."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔷 Shape Builder Token"
    },
    {
      "studio": "Drawing Desk",
      "title": "Contour drawing",
      "icon": "🧵",
      "summary": "Contour drawing follows the outside and important inside edges of a subject as if the pencil is walking around the form.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "thread",
          "paragraphs": [
            "Contour drawing teaches this main idea: Contour drawing follows the outside and important inside edges of a subject as if the pencil is walking around the form.",
            "This belongs in the Drawing Desk because Contour practice teaches patience because the eyes must travel along the edge instead of rushing to symbols from memory.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are contour, outline, edge, observation. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use pencil or pen and choose a simple object with a clear outline. Move slowly enough to notice bumps, corners, and changes.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use non messy tools first so the focus stays on watching and controlling the line.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Try one normal contour drawing and one slow blind contour where the eyes stay mostly on the object.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The result may look wobbly, but the skill is serious: it trains observation instead of guessing.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Trace the edge of a leaf, spoon, or small toy with your eyes before drawing it.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧵 Contour Thread Pin",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Contour drawing?",
          "choices": [
            "Contour drawing follows the outside and important inside edges of a subject as if the pencil is walking around the form.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Contour drawing belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Contour practice teaches patience because the eyes must travel along the edge instead of rushing to symbols from memory.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Contour drawing?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use pencil or pen and choose a simple object with a clear outline. Move slowly enough to notice bumps, corners, and changes.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Try one normal contour drawing and one slow blind contour where the eyes stay mostly on the object."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Contour drawing?",
          "choices": [
            "The result may look wobbly, but the skill is serious: it trains observation instead of guessing.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use non messy tools first so the focus stays on watching and controlling the line.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words contour, outline, edge, observation matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Contour drawing?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Trace the edge of a leaf, spoon, or small toy with your eyes before drawing it."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧵 Contour Thread Pin"
    },
    {
      "studio": "Drawing Desk",
      "title": "Proportion and spacing",
      "icon": "📏",
      "summary": "Proportion is how sizes compare, and spacing is how far parts sit from one another.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "ruler",
          "paragraphs": [
            "Proportion and spacing teaches this main idea: Proportion is how sizes compare, and spacing is how far parts sit from one another.",
            "This belongs in the Drawing Desk because A drawing can have nice details but still feel strange if the main parts are too large, too small, or in the wrong place.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are proportion, spacing, measure, compare. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a pencil as a simple measuring helper. Compare height to width, top to bottom, and one part to another.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Hold tools carefully and do not point pencils toward faces when measuring from a distance.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Before details, mark where the top, bottom, left, and right edges will go. Then check the halfway point.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Proportion is not about stiff measuring every second. It is about checking relationships before the drawing becomes crowded.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a cup or book and mark the halfway point before adding details.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📏 Careful Measure Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Proportion and spacing?",
          "choices": [
            "Proportion is how sizes compare, and spacing is how far parts sit from one another.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Proportion and spacing belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A drawing can have nice details but still feel strange if the main parts are too large, too small, or in the wrong place.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Proportion and spacing?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a pencil as a simple measuring helper. Compare height to width, top to bottom, and one part to another.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Before details, mark where the top, bottom, left, and right edges will go. Then check the halfway point."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Proportion and spacing?",
          "choices": [
            "Proportion is not about stiff measuring every second. It is about checking relationships before the drawing becomes crowded.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Hold tools carefully and do not point pencils toward faces when measuring from a distance.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words proportion, spacing, measure, compare matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Proportion and spacing?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a cup or book and mark the halfway point before adding details."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📏 Careful Measure Badge"
    },
    {
      "studio": "Drawing Desk",
      "title": "Shading and value",
      "icon": "◻️",
      "summary": "Shading uses light and dark values to show form, depth, surface, and light direction.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "shade",
          "paragraphs": [
            "Shading and value teaches this main idea: Shading uses light and dark values to show form, depth, surface, and light direction.",
            "This belongs in the Drawing Desk because Value helps a flat drawing feel round or solid because the eye reads darker areas as shadow and lighter areas as light.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are value, highlight, shadow, hatching. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use pencil, charcoal pencil, crayon, or colored pencil. Try hatching, crosshatching, smooth shading, and stippling.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep dusty materials away from mouths and clean hands after using soft pencils or charcoal.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Choose one light source. Then mark the brightest area, middle value, darkest shadow, and cast shadow.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Good shading is gradual and controlled. A picture can become muddy if every area is darkened without a plan.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Shade a sphere, cube, or rolled sock using at least three values.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ◻️ Value Finder Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Shading and value?",
          "choices": [
            "Shading uses light and dark values to show form, depth, surface, and light direction.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Shading and value belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Value helps a flat drawing feel round or solid because the eye reads darker areas as shadow and lighter areas as light.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Shading and value?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use pencil, charcoal pencil, crayon, or colored pencil. Try hatching, crosshatching, smooth shading, and stippling.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Choose one light source. Then mark the brightest area, middle value, darkest shadow, and cast shadow."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Shading and value?",
          "choices": [
            "Good shading is gradual and controlled. A picture can become muddy if every area is darkened without a plan.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep dusty materials away from mouths and clean hands after using soft pencils or charcoal.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words value, highlight, shadow, hatching matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Shading and value?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Shade a sphere, cube, or rolled sock using at least three values."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "◻️ Value Finder Charm"
    },
    {
      "studio": "Drawing Desk",
      "title": "Texture marks",
      "icon": "🪵",
      "summary": "Texture marks suggest how a surface might feel, such as rough bark, soft cloth, shiny metal, bumpy stone, or fuzzy yarn.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "texture",
          "paragraphs": [
            "Texture marks teaches this main idea: Texture marks suggest how a surface might feel, such as rough bark, soft cloth, shiny metal, bumpy stone, or fuzzy yarn.",
            "This belongs in the Drawing Desk because Texture makes drawings richer because it gives clues about material, age, use, and environment.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are texture, surface, pattern, material. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use repeated marks: dots, short strokes, loops, scribbles, tiny dashes, cross marks, or smooth blended areas.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not rub unknown surfaces onto art materials; observe first and keep materials clean.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Study the texture before drawing it. Ask whether it is regular, random, smooth, sharp, soft, or layered.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Texture should serve the drawing. Too much texture everywhere can make the picture noisy.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a texture sampler with six little boxes: wood, cloth, stone, metal, grass, and fur.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🪵 Texture Sampler Patch",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Texture marks?",
          "choices": [
            "Texture marks suggest how a surface might feel, such as rough bark, soft cloth, shiny metal, bumpy stone, or fuzzy yarn.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Texture marks belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Texture makes drawings richer because it gives clues about material, age, use, and environment.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Texture marks?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use repeated marks: dots, short strokes, loops, scribbles, tiny dashes, cross marks, or smooth blended areas.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Study the texture before drawing it. Ask whether it is regular, random, smooth, sharp, soft, or layered."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Texture marks?",
          "choices": [
            "Texture should serve the drawing. Too much texture everywhere can make the picture noisy.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not rub unknown surfaces onto art materials; observe first and keep materials clean.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words texture, surface, pattern, material matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Texture marks?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a texture sampler with six little boxes: wood, cloth, stone, metal, grass, and fur."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🪵 Texture Sampler Patch"
    },
    {
      "studio": "Drawing Desk",
      "title": "Simple perspective",
      "icon": "🛤️",
      "summary": "Perspective is a way to show depth by making far things appear smaller and by guiding lines toward a vanishing point.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "path",
          "paragraphs": [
            "Simple perspective teaches this main idea: Perspective is a way to show depth by making far things appear smaller and by guiding lines toward a vanishing point.",
            "This belongs in the Drawing Desk because Roads, halls, fences, train tracks, shelves, and buildings become easier to draw when depth is planned.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are horizon, vanishing point, depth, foreground. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a ruler, pencil, horizon line, and one vanishing point. Keep early marks light.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use a ruler flat on the table, not in the air, so it does not slip or poke.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Draw a road or hallway by making the side lines move toward the same point in the distance.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Perspective is a tool, not a trap. Simple scenes only need enough depth to make the space believable.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a path going away from the viewer and add three objects that get smaller.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🛤️ Perspective Path Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Simple perspective?",
          "choices": [
            "Perspective is a way to show depth by making far things appear smaller and by guiding lines toward a vanishing point.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Simple perspective belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Roads, halls, fences, train tracks, shelves, and buildings become easier to draw when depth is planned.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Simple perspective?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a ruler, pencil, horizon line, and one vanishing point. Keep early marks light.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Draw a road or hallway by making the side lines move toward the same point in the distance."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Simple perspective?",
          "choices": [
            "Perspective is a tool, not a trap. Simple scenes only need enough depth to make the space believable.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use a ruler flat on the table, not in the air, so it does not slip or poke.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words horizon, vanishing point, depth, foreground matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Simple perspective?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a path going away from the viewer and add three objects that get smaller."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🛤️ Perspective Path Badge"
    },
    {
      "studio": "Drawing Desk",
      "title": "Drawing from memory and imagination",
      "icon": "💭",
      "summary": "Imagination drawing uses memory, observation, and invention together instead of copying only what is in front of the eyes.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "cloud",
          "paragraphs": [
            "Drawing from memory and imagination teaches this main idea: Imagination drawing uses memory, observation, and invention together instead of copying only what is in front of the eyes.",
            "This belongs in the Drawing Desk because Stories, creatures, maps, inventions, and fantasy places all need imagination, but they still become stronger when built from real observed details.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are imagination, reference, memory, variation. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a sketchbook to collect shapes, animal parts, tools, leaves, vehicles, doors, and patterns that can be reused in imagined scenes.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep designs kid safe and avoid copying copyrighted characters exactly when making your own world.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start with a real reference idea, then change one feature at a time: size, shape, texture, setting, or purpose.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Imagination is not random guessing. It works best when the maker has a library of observed details.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Invent a harmless creature using one real animal shape, one tool shape, and one plant texture.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 💭 Imagination Sketch Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Drawing from memory and imagination?",
          "choices": [
            "Imagination drawing uses memory, observation, and invention together instead of copying only what is in front of the eyes.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Drawing from memory and imagination belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Stories, creatures, maps, inventions, and fantasy places all need imagination, but they still become stronger when built from real observed details.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Drawing from memory and imagination?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a sketchbook to collect shapes, animal parts, tools, leaves, vehicles, doors, and patterns that can be reused in imagined scenes.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start with a real reference idea, then change one feature at a time: size, shape, texture, setting, or purpose."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Drawing from memory and imagination?",
          "choices": [
            "Imagination is not random guessing. It works best when the maker has a library of observed details.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep designs kid safe and avoid copying copyrighted characters exactly when making your own world.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words imagination, reference, memory, variation matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Drawing from memory and imagination?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Invent a harmless creature using one real animal shape, one tool shape, and one plant texture."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "💭 Imagination Sketch Badge"
    },
    {
      "studio": "Drawing Desk",
      "title": "Visual notes and diagrams",
      "icon": "🗒️",
      "summary": "Visual notes use simple drawings, arrows, labels, and boxes to explain ideas clearly.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "notes",
          "paragraphs": [
            "Visual notes and diagrams teaches this main idea: Visual notes use simple drawings, arrows, labels, and boxes to explain ideas clearly.",
            "This belongs in the Drawing Desk because Diagrams help with science, history, stories, inventions, recipes, repairs, maps, and planning because they organize information visually.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are diagram, label, arrow, sequence. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use boxes, arrows, labels, numbers, and simple icons. Clarity matters more than fancy artwork.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use clean labels and leave margins so the page is readable.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice turning a paragraph into a small diagram with three labeled parts.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A strong diagram answers a question. It should not be crowded with decorations that make the idea harder to read.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a diagram showing how to care for art tools after a project.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🗒️ Diagram Note Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Visual notes and diagrams?",
          "choices": [
            "Visual notes use simple drawings, arrows, labels, and boxes to explain ideas clearly.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Visual notes and diagrams belong in the Drawing Desk?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Diagrams help with science, history, stories, inventions, recipes, repairs, maps, and planning because they organize information visually.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Visual notes and diagrams?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use boxes, arrows, labels, numbers, and simple icons. Clarity matters more than fancy artwork.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice turning a paragraph into a small diagram with three labeled parts."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Visual notes and diagrams?",
          "choices": [
            "A strong diagram answers a question. It should not be crowded with decorations that make the idea harder to read.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use clean labels and leave margins so the page is readable.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words diagram, label, arrow, sequence matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Visual notes and diagrams?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a diagram showing how to care for art tools after a project."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🗒️ Diagram Note Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Welcome to the Painting Studio",
      "icon": "🎨",
      "summary": "Painting uses color, value, edges, layers, brush movement, and surface choices to build an image or design.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "palette",
          "paragraphs": [
            "Welcome to the Painting Studio teaches this main idea: Painting uses color, value, edges, layers, brush movement, and surface choices to build an image or design.",
            "This belongs in the Painting Studio because Painting feels playful, but it also teaches planning because wet materials can mix, smear, stain, dry, and cover differently.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are paint, palette, brush, layer. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Start with washable paints, water cup, brush, palette, paper towel, apron, and a protected work surface.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use washable materials unless an adult approves otherwise, keep paint away from mouths, and wipe spills quickly.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Test colors on scrap paper before using them in the main picture.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A painting studio habit is simple: prepare the area, paint with purpose, clean tools, and let work dry safely.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Set up a tiny painting station and name each tool before beginning.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎨 Painter Apron Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Painting Studio?",
          "choices": [
            "Painting uses color, value, edges, layers, brush movement, and surface choices to build an image or design.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Painting Studio belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Painting feels playful, but it also teaches planning because wet materials can mix, smear, stain, dry, and cover differently.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Painting Studio?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Start with washable paints, water cup, brush, palette, paper towel, apron, and a protected work surface.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Test colors on scrap paper before using them in the main picture."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Painting Studio?",
          "choices": [
            "A painting studio habit is simple: prepare the area, paint with purpose, clean tools, and let work dry safely.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use washable materials unless an adult approves otherwise, keep paint away from mouths, and wipe spills quickly.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words paint, palette, brush, layer matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Painting Studio?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Set up a tiny painting station and name each tool before beginning."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎨 Painter Apron Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Primary and secondary colors",
      "icon": "🔴",
      "summary": "Primary colors can be mixed to make many other colors, and secondary colors come from mixing two primaries.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "colorwheel",
          "paragraphs": [
            "Primary and secondary colors teaches this main idea: Primary colors can be mixed to make many other colors, and secondary colors come from mixing two primaries.",
            "This belongs in the Painting Studio because Color mixing is one of the easiest ways to learn cause and effect because each new color records what was added.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are primary, secondary, mix, color wheel. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use red, yellow, blue, a brush, water, and a mixing space. Mix small amounts so paint is not wasted.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Rinse the brush between colors so the whole palette does not turn brown too soon.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Make orange, green, and purple, then adjust each one by changing which primary is stronger.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Color mixing teaches control. Muddy color often happens when too many colors are mixed without a plan.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a six-color wheel using only red, yellow, and blue paint.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔴 Color Mixer Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Primary and secondary colors?",
          "choices": [
            "Primary colors can be mixed to make many other colors, and secondary colors come from mixing two primaries.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Primary and secondary colors belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Color mixing is one of the easiest ways to learn cause and effect because each new color records what was added.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Primary and secondary colors?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use red, yellow, blue, a brush, water, and a mixing space. Mix small amounts so paint is not wasted.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Make orange, green, and purple, then adjust each one by changing which primary is stronger."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Primary and secondary colors?",
          "choices": [
            "Color mixing teaches control. Muddy color often happens when too many colors are mixed without a plan.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Rinse the brush between colors so the whole palette does not turn brown too soon.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words primary, secondary, mix, color wheel matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Primary and secondary colors?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a six-color wheel using only red, yellow, and blue paint."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔴 Color Mixer Token"
    },
    {
      "studio": "Painting Studio",
      "title": "Warm and cool colors",
      "icon": "🔥",
      "summary": "Warm colors often feel sunny or fiery, while cool colors often feel watery, shady, calm, or distant.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "sun",
          "paragraphs": [
            "Warm and cool colors teaches this main idea: Warm colors often feel sunny or fiery, while cool colors often feel watery, shady, calm, or distant.",
            "This belongs in the Painting Studio because Artists use warm and cool color choices to organize mood, depth, and attention without needing extra details.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are warm color, cool color, mood, contrast. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use reds, oranges, yellows, blues, greens, and violets. Compare how each color feels next to the others.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep paint lids closed when not in use so colors do not dry out.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Paint the same simple shape twice, once with mostly warm colors and once with mostly cool colors.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Warm and cool are not strict rules. They are useful comparisons that help the maker choose on purpose.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make two tiny landscapes: one warm sunset version and one cool moonlit version.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔥 Warm Cool Compass",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Warm and cool colors?",
          "choices": [
            "Warm colors often feel sunny or fiery, while cool colors often feel watery, shady, calm, or distant.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Warm and cool colors belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Artists use warm and cool color choices to organize mood, depth, and attention without needing extra details.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Warm and cool colors?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use reds, oranges, yellows, blues, greens, and violets. Compare how each color feels next to the others.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Paint the same simple shape twice, once with mostly warm colors and once with mostly cool colors."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Warm and cool colors?",
          "choices": [
            "Warm and cool are not strict rules. They are useful comparisons that help the maker choose on purpose.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep paint lids closed when not in use so colors do not dry out.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words warm color, cool color, mood, contrast matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Warm and cool colors?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make two tiny landscapes: one warm sunset version and one cool moonlit version."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔥 Warm Cool Compass"
    },
    {
      "studio": "Painting Studio",
      "title": "Light, dark, and painted value",
      "icon": "🌗",
      "summary": "Painted value means how light or dark a color is, and it helps show form, distance, and attention.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "moon",
          "paragraphs": [
            "Light, dark, and painted value teaches this main idea: Painted value means how light or dark a color is, and it helps show form, distance, and attention.",
            "This belongs in the Painting Studio because A color can be beautiful but still hard to see if it has the same value as everything around it.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are tint, shade, value, contrast. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use one color plus white and a tiny bit of dark paint. Make a value ladder from light to dark.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Add dark paint slowly because a little can overpower a mixture.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice painting a simple object with a light side, middle side, and shadow side.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Value is often more important than the color name. A clear light-dark plan makes the picture readable.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Paint five squares from very light to very dark using one color family.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🌗 Value Ladder Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Light, dark, and painted value?",
          "choices": [
            "Painted value means how light or dark a color is, and it helps show form, distance, and attention.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Light, dark, and painted value belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A color can be beautiful but still hard to see if it has the same value as everything around it.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Light, dark, and painted value?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use one color plus white and a tiny bit of dark paint. Make a value ladder from light to dark.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice painting a simple object with a light side, middle side, and shadow side."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Light, dark, and painted value?",
          "choices": [
            "Value is often more important than the color name. A clear light-dark plan makes the picture readable.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Add dark paint slowly because a little can overpower a mixture.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words tint, shade, value, contrast matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Light, dark, and painted value?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Paint five squares from very light to very dark using one color family."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🌗 Value Ladder Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Brush care and brush choices",
      "icon": "🖌️",
      "summary": "Different brushes make different marks, and caring for them keeps them useful longer.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "brush",
          "paragraphs": [
            "Brush care and brush choices teaches this main idea: Different brushes make different marks, and caring for them keeps them useful longer.",
            "This belongs in the Painting Studio because A flat brush can cover an area, a round brush can make lines and shapes, and a small brush can add details.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are bristle, flat brush, round brush, stroke. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use water, gentle wiping, and careful reshaping of bristles after cleaning. Do not smash the brush into the cup.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Never leave brushes standing on their bristles in water; it bends them and weakens the handle.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice one brush five ways: thin line, thick stroke, dot, dry mark, and soft wash.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Brush care is craftsmanship. A good maker respects tools because tools affect the finished work.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a brush mark chart and write what each brush seems best at doing.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🖌️ Brush Keeper Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Brush care and brush choices?",
          "choices": [
            "Different brushes make different marks, and caring for them keeps them useful longer.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Brush care and brush choices belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A flat brush can cover an area, a round brush can make lines and shapes, and a small brush can add details.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Brush care and brush choices?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use water, gentle wiping, and careful reshaping of bristles after cleaning. Do not smash the brush into the cup.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice one brush five ways: thin line, thick stroke, dot, dry mark, and soft wash."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Brush care and brush choices?",
          "choices": [
            "Brush care is craftsmanship. A good maker respects tools because tools affect the finished work.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Never leave brushes standing on their bristles in water; it bends them and weakens the handle.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words bristle, flat brush, round brush, stroke matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Brush care and brush choices?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a brush mark chart and write what each brush seems best at doing."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🖌️ Brush Keeper Charm"
    },
    {
      "studio": "Painting Studio",
      "title": "Watercolor wash basics",
      "icon": "💧",
      "summary": "A watercolor wash is a thin layer of color that lets light from the paper shine through.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "water",
          "paragraphs": [
            "Watercolor wash basics teaches this main idea: A watercolor wash is a thin layer of color that lets light from the paper shine through.",
            "This belongs in the Painting Studio because Watercolor teaches patience because wet areas spread, bleed, and dry lighter than they first appear.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are wash, gradient, wet-on-wet, transparency. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use watercolor, water, brush, thick paper if available, and a paper towel for lifting extra water.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep the water cup steady and away from elbows so it does not spill across the work.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Try a flat wash, a gradient wash, and a wet-on-wet color blend.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The secret is water control. Too little water scratches; too much water puddles.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Paint a sky wash that moves from dark at the top to light near the bottom.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 💧 Watercolor Drop Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Watercolor wash basics?",
          "choices": [
            "A watercolor wash is a thin layer of color that lets light from the paper shine through.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Watercolor wash basics belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Watercolor teaches patience because wet areas spread, bleed, and dry lighter than they first appear.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Watercolor wash basics?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use watercolor, water, brush, thick paper if available, and a paper towel for lifting extra water.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Try a flat wash, a gradient wash, and a wet-on-wet color blend."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Watercolor wash basics?",
          "choices": [
            "The secret is water control. Too little water scratches; too much water puddles.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep the water cup steady and away from elbows so it does not spill across the work.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words wash, gradient, wet-on-wet, transparency matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Watercolor wash basics?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Paint a sky wash that moves from dark at the top to light near the bottom."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "💧 Watercolor Drop Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Opaque paint basics",
      "icon": "🪣",
      "summary": "Opaque paint covers more strongly than watercolor and can build solid shapes, bold colors, and corrections.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "paintbucket",
          "paragraphs": [
            "Opaque paint basics teaches this main idea: Opaque paint covers more strongly than watercolor and can build solid shapes, bold colors, and corrections.",
            "This belongs in the Painting Studio because Tempera and acrylic-style paints are common for craft and poster work because they make clear, bright areas.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are opaque, layer, coverage, dry time. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use small paint amounts, a protected table, and brushes suited for covering areas.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use only kid-safe paints and follow the label for cleanup.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Paint a base shape, let it dry, then add a second layer or detail on top.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Opaque painting teaches order. Wet paint underneath can mix with new paint if the maker rushes.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Paint a simple sign or emblem using one base layer and one detail layer.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🪣 Solid Color Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Opaque paint basics?",
          "choices": [
            "Opaque paint covers more strongly than watercolor and can build solid shapes, bold colors, and corrections.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Opaque paint basics belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Tempera and acrylic-style paints are common for craft and poster work because they make clear, bright areas.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Opaque paint basics?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use small paint amounts, a protected table, and brushes suited for covering areas.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Paint a base shape, let it dry, then add a second layer or detail on top."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Opaque paint basics?",
          "choices": [
            "Opaque painting teaches order. Wet paint underneath can mix with new paint if the maker rushes.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use only kid-safe paints and follow the label for cleanup.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words opaque, layer, coverage, dry time matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Opaque paint basics?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Paint a simple sign or emblem using one base layer and one detail layer."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🪣 Solid Color Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Still life painting",
      "icon": "🍎",
      "summary": "A still life is a picture of arranged objects, often chosen for shape, color, texture, and light.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "apple",
          "paragraphs": [
            "Still life painting teaches this main idea: A still life is a picture of arranged objects, often chosen for shape, color, texture, and light.",
            "This belongs in the Painting Studio because Still life painting is useful because the subject stays still long enough for careful observation.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are still life, arrangement, object, shadow. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose two or three safe objects such as fruit, a cup, a folded cloth, or a toy. Set one light direction if possible.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not use breakable items unless an adult says it is okay and the surface is safe.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Sketch the big shapes first, then block in main colors, then add shadows and small details.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good still life does not need fancy objects. It needs careful looking and a clear arrangement.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Paint three objects with one light source and one cast shadow.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🍎 Still Life Table Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Still life painting?",
          "choices": [
            "A still life is a picture of arranged objects, often chosen for shape, color, texture, and light.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Still life painting belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Still life painting is useful because the subject stays still long enough for careful observation.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Still life painting?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose two or three safe objects such as fruit, a cup, a folded cloth, or a toy. Set one light direction if possible.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Sketch the big shapes first, then block in main colors, then add shadows and small details."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Still life painting?",
          "choices": [
            "A good still life does not need fancy objects. It needs careful looking and a clear arrangement.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not use breakable items unless an adult says it is okay and the surface is safe.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words still life, arrangement, object, shadow matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Still life painting?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Paint three objects with one light source and one cast shadow."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🍎 Still Life Table Token"
    },
    {
      "studio": "Painting Studio",
      "title": "Landscape painting",
      "icon": "🏞️",
      "summary": "A landscape shows outdoor space using foreground, middle ground, background, sky, land, water, plants, or buildings.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "landscape",
          "paragraphs": [
            "Landscape painting teaches this main idea: A landscape shows outdoor space using foreground, middle ground, background, sky, land, water, plants, or buildings.",
            "This belongs in the Painting Studio because Landscape painting teaches depth because nearby things usually look larger, sharper, and more detailed than far things.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are foreground, middle ground, background, horizon. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a simple plan: sky area, ground area, large shapes, then smaller details.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep outdoor painting materials simple and do not paint on public or household surfaces without permission.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Paint back to front. Start with sky or distant areas, then add closer shapes after those are placed.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A landscape can be real or imagined, but it should still have a clear space for the eye to travel through.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Paint a tiny scene with a clear foreground, middle ground, and background.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏞️ Landscape Maker Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Landscape painting?",
          "choices": [
            "A landscape shows outdoor space using foreground, middle ground, background, sky, land, water, plants, or buildings.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Landscape painting belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Landscape painting teaches depth because nearby things usually look larger, sharper, and more detailed than far things.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Landscape painting?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a simple plan: sky area, ground area, large shapes, then smaller details.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Paint back to front. Start with sky or distant areas, then add closer shapes after those are placed."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Landscape painting?",
          "choices": [
            "A landscape can be real or imagined, but it should still have a clear space for the eye to travel through.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep outdoor painting materials simple and do not paint on public or household surfaces without permission.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words foreground, middle ground, background, horizon matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Landscape painting?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Paint a tiny scene with a clear foreground, middle ground, and background."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏞️ Landscape Maker Badge"
    },
    {
      "studio": "Painting Studio",
      "title": "Planning a painted project",
      "icon": "🧾",
      "summary": "A painting plan helps decide size, colors, subject, tools, and drying order before the mess begins.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "clipboard",
          "paragraphs": [
            "Planning a painted project teaches this main idea: A painting plan helps decide size, colors, subject, tools, and drying order before the mess begins.",
            "This belongs in the Painting Studio because Planning prevents wasted supplies and gives the maker a better chance to finish calmly.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are thumbnail, plan, subject, drying order. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a thumbnail sketch, color notes, tool list, and a safe drying place.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Set wet paintings somewhere flat and safe where little hands, pets, or sleeves will not smear them.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Before painting, answer three questions: what is the main subject, what colors matter most, and what must dry first?",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A plan can change, but starting with one keeps the project from becoming a scramble.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make three tiny thumbnail plans and choose the strongest one to paint.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧾 Project Planner Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Planning a painted project?",
          "choices": [
            "A painting plan helps decide size, colors, subject, tools, and drying order before the mess begins.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Planning a painted project belong in the Painting Studio?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Planning prevents wasted supplies and gives the maker a better chance to finish calmly.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Planning a painted project?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a thumbnail sketch, color notes, tool list, and a safe drying place.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Before painting, answer three questions: what is the main subject, what colors matter most, and what must dry first?"
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Planning a painted project?",
          "choices": [
            "A plan can change, but starting with one keeps the project from becoming a scramble.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Set wet paintings somewhere flat and safe where little hands, pets, or sleeves will not smear them.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words thumbnail, plan, subject, drying order matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Planning a painted project?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make three tiny thumbnail plans and choose the strongest one to paint."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧾 Project Planner Badge"
    },
    {
      "studio": "Craft Cottage",
      "title": "Welcome to the Craft Cottage",
      "icon": "🧵",
      "summary": "Crafting turns materials into useful, decorative, or story-filled objects through cutting, folding, joining, shaping, and finishing.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "thread",
          "paragraphs": [
            "Welcome to the Craft Cottage teaches this main idea: Crafting turns materials into useful, decorative, or story-filled objects through cutting, folding, joining, shaping, and finishing.",
            "This belongs in the Craft Cottage because Craft work connects art to the hands because it asks how materials bend, tear, glue, stack, hang, and hold together.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are craft, material, join, finish. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Common tools include paper, glue, tape, scissors, string, cardboard, fabric scraps, craft sticks, and safe markers.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use scissors, hot glue, needles, or sharp tools only with adult approval and keep small pieces away from younger children.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start by sorting materials and deciding what each part will do before attaching anything permanently.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A craft cottage habit is to plan the build, test the fit, then finish neatly.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Build a small name sign or room marker from paper and cardboard.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧵 Craft Cottage Key",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Craft Cottage?",
          "choices": [
            "Crafting turns materials into useful, decorative, or story-filled objects through cutting, folding, joining, shaping, and finishing.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Craft Cottage belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Craft work connects art to the hands because it asks how materials bend, tear, glue, stack, hang, and hold together.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Craft Cottage?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Common tools include paper, glue, tape, scissors, string, cardboard, fabric scraps, craft sticks, and safe markers.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start by sorting materials and deciding what each part will do before attaching anything permanently."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Craft Cottage?",
          "choices": [
            "A craft cottage habit is to plan the build, test the fit, then finish neatly.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use scissors, hot glue, needles, or sharp tools only with adult approval and keep small pieces away from younger children.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words craft, material, join, finish matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Craft Cottage?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Build a small name sign or room marker from paper and cardboard."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧵 Craft Cottage Key"
    },
    {
      "studio": "Craft Cottage",
      "title": "Paper cutting and clean edges",
      "icon": "✂️",
      "summary": "Cutting changes a flat sheet into shapes, strips, tabs, windows, borders, and pieces for building.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "scissors",
          "paragraphs": [
            "Paper cutting and clean edges teaches this main idea: Cutting changes a flat sheet into shapes, strips, tabs, windows, borders, and pieces for building.",
            "This belongs in the Craft Cottage because Clean cutting matters because rough edges can make even a good idea look rushed or hard to assemble.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are cut, edge, tab, guide line. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use safe scissors, paper, pencil guidelines, and a scrap bowl for trimmings.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Carry scissors closed and pointed down; set them down when not cutting.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Turn the paper as you cut curves instead of twisting the wrist into awkward positions.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A careful maker cuts outside the line when unsure, then trims slowly to the final edge.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Cut five shapes from scrap paper and arrange them into one simple picture.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ✂️ Clean Edge Scissors Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Paper cutting and clean edges?",
          "choices": [
            "Cutting changes a flat sheet into shapes, strips, tabs, windows, borders, and pieces for building.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Paper cutting and clean edges belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Clean cutting matters because rough edges can make even a good idea look rushed or hard to assemble.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Paper cutting and clean edges?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use safe scissors, paper, pencil guidelines, and a scrap bowl for trimmings.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Turn the paper as you cut curves instead of twisting the wrist into awkward positions."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Paper cutting and clean edges?",
          "choices": [
            "A careful maker cuts outside the line when unsure, then trims slowly to the final edge.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Carry scissors closed and pointed down; set them down when not cutting.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words cut, edge, tab, guide line matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Paper cutting and clean edges?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Cut five shapes from scrap paper and arrange them into one simple picture."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "✂️ Clean Edge Scissors Badge"
    },
    {
      "studio": "Craft Cottage",
      "title": "Folding, tabs, and pop-up shapes",
      "icon": "📐",
      "summary": "Folding gives paper strength, movement, and structure, while tabs help flat pieces attach to other surfaces.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "fold",
          "paragraphs": [
            "Folding, tabs, and pop-up shapes teaches this main idea: Folding gives paper strength, movement, and structure, while tabs help flat pieces attach to other surfaces.",
            "This belongs in the Craft Cottage because Cards, boxes, paper houses, pop-ups, models, and envelopes all depend on folds that land in the right place.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are fold, crease, tab, pop-up. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a ruler edge or fingernail to press a crease, but do not tear the paper by pressing too hard.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Fold away from faces and do not use sharp scoring tools unless an adult helps.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice valley folds, mountain folds, tabs, and simple pop-up bridges.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Good paper engineering is part art and part structure. The fold must look nice and also work.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a tiny pop-up door or window that opens when the page opens.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📐 Paper Engineer Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Folding, tabs, and pop-up shapes?",
          "choices": [
            "Folding gives paper strength, movement, and structure, while tabs help flat pieces attach to other surfaces.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Folding, tabs, and pop-up shapes belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Cards, boxes, paper houses, pop-ups, models, and envelopes all depend on folds that land in the right place.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Folding, tabs, and pop-up shapes?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a ruler edge or fingernail to press a crease, but do not tear the paper by pressing too hard.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice valley folds, mountain folds, tabs, and simple pop-up bridges."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Folding, tabs, and pop-up shapes?",
          "choices": [
            "Good paper engineering is part art and part structure. The fold must look nice and also work.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Fold away from faces and do not use sharp scoring tools unless an adult helps.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words fold, crease, tab, pop-up matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Folding, tabs, and pop-up shapes?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a tiny pop-up door or window that opens when the page opens."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📐 Paper Engineer Token"
    },
    {
      "studio": "Craft Cottage",
      "title": "Collage choices",
      "icon": "🧩",
      "summary": "Collage builds a picture or design from separate pieces of paper, fabric, photos, labels, or textures.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "puzzle",
          "paragraphs": [
            "Collage choices teaches this main idea: Collage builds a picture or design from separate pieces of paper, fabric, photos, labels, or textures.",
            "This belongs in the Craft Cottage because Collage is useful because it teaches selection: not every piece belongs, and placement changes meaning.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are collage, layer, focus, arrangement. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use scraps, glue stick, background paper, and a plan for big shapes before small pieces.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use only safe, approved materials and do not cut up important papers or photos without permission.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Lay pieces down without glue first. Move them around until the arrangement feels clear.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A strong collage usually has a main focus, supporting pieces, and enough empty space for the eye to rest.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a collage using only five large pieces and three small details.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧩 Collage Builder Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Collage choices?",
          "choices": [
            "Collage builds a picture or design from separate pieces of paper, fabric, photos, labels, or textures.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Collage choices belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Collage is useful because it teaches selection: not every piece belongs, and placement changes meaning.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Collage choices?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use scraps, glue stick, background paper, and a plan for big shapes before small pieces.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Lay pieces down without glue first. Move them around until the arrangement feels clear."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Collage choices?",
          "choices": [
            "A strong collage usually has a main focus, supporting pieces, and enough empty space for the eye to rest.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use only safe, approved materials and do not cut up important papers or photos without permission.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words collage, layer, focus, arrangement matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Collage choices?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a collage using only five large pieces and three small details."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧩 Collage Builder Badge"
    },
    {
      "studio": "Craft Cottage",
      "title": "Weaving basics",
      "icon": "🧺",
      "summary": "Weaving crosses strands over and under to make cloth, mats, baskets, and decorative patterns.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "basket",
          "paragraphs": [
            "Weaving basics teaches this main idea: Weaving crosses strands over and under to make cloth, mats, baskets, and decorative patterns.",
            "This belongs in the Craft Cottage because Weaving is ancient, practical, and mathematical because it depends on repetition, order, tension, and pattern.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are warp, weft, loom, tension. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use paper strips or yarn with a simple cardboard loom. Warp threads stay in place; weft threads travel across.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep yarn away from necks and do not leave long loops where small children or pets could tangle.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice over-under-over-under, then reverse the pattern on the next row.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The challenge is even tension. Pulling too hard curls the work; pulling too loosely leaves gaps.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a paper woven mat with two colors.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧺 Weaver Loop Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Weaving basics?",
          "choices": [
            "Weaving crosses strands over and under to make cloth, mats, baskets, and decorative patterns.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Weaving basics belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Weaving is ancient, practical, and mathematical because it depends on repetition, order, tension, and pattern.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Weaving basics?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use paper strips or yarn with a simple cardboard loom. Warp threads stay in place; weft threads travel across.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice over-under-over-under, then reverse the pattern on the next row."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Weaving basics?",
          "choices": [
            "The challenge is even tension. Pulling too hard curls the work; pulling too loosely leaves gaps.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep yarn away from necks and do not leave long loops where small children or pets could tangle.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words warp, weft, loom, tension matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Weaving basics?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a paper woven mat with two colors."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧺 Weaver Loop Charm"
    },
    {
      "studio": "Craft Cottage",
      "title": "Yarn, knots, and simple fiber art",
      "icon": "🧶",
      "summary": "Fiber art uses yarn, thread, cord, fabric, and knots to make texture, pattern, fringe, tassels, and soft decorations.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "yarn",
          "paragraphs": [
            "Yarn, knots, and simple fiber art teaches this main idea: Fiber art uses yarn, thread, cord, fabric, and knots to make texture, pattern, fringe, tassels, and soft decorations.",
            "This belongs in the Craft Cottage because Fiber skills show how flexible materials can be tied, wrapped, braided, twisted, or woven into something stronger.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are fiber, knot, braid, tassel. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use yarn, cardboard, tape, and blunt tools when possible. Learn a simple overhand knot and braid.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not wrap string around fingers tightly, and keep loose strands put away after working.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice making a tassel, a wrapped stick, or a braided bookmark.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Fiber projects reward patience because uneven pulling can change the whole shape.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a small braided cord and attach a paper charm to it.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧶 Fiber Artist Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Yarn, knots, and simple fiber art?",
          "choices": [
            "Fiber art uses yarn, thread, cord, fabric, and knots to make texture, pattern, fringe, tassels, and soft decorations.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Yarn, knots, and simple fiber art belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Fiber skills show how flexible materials can be tied, wrapped, braided, twisted, or woven into something stronger.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Yarn, knots, and simple fiber art?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use yarn, cardboard, tape, and blunt tools when possible. Learn a simple overhand knot and braid.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice making a tassel, a wrapped stick, or a braided bookmark."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Yarn, knots, and simple fiber art?",
          "choices": [
            "Fiber projects reward patience because uneven pulling can change the whole shape.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not wrap string around fingers tightly, and keep loose strands put away after working.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words fiber, knot, braid, tassel matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Yarn, knots, and simple fiber art?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a small braided cord and attach a paper charm to it."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧶 Fiber Artist Badge"
    },
    {
      "studio": "Craft Cottage",
      "title": "Sewing and stitching basics",
      "icon": "🪡",
      "summary": "Stitching joins fabric or adds decoration by passing thread through material in a planned path.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "needle",
          "paragraphs": [
            "Sewing and stitching basics teaches this main idea: Stitching joins fabric or adds decoration by passing thread through material in a planned path.",
            "This belongs in the Craft Cottage because Sewing is both practical and creative because it repairs, decorates, strengthens, and shapes soft materials.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are stitch, seam, thread, fabric. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use felt or fabric scraps, blunt plastic needle when possible, embroidery thread, and large simple stitches.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use needles only with adult approval, count them before and after, and store them safely.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice a running stitch on scrap fabric before trying a project.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Even stitches are easier when the fabric is held steady and the path is marked lightly first.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a tiny felt patch with a border of simple running stitches.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🪡 Safe Stitch Patch",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Sewing and stitching basics?",
          "choices": [
            "Stitching joins fabric or adds decoration by passing thread through material in a planned path.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Sewing and stitching basics belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Sewing is both practical and creative because it repairs, decorates, strengthens, and shapes soft materials.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Sewing and stitching basics?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use felt or fabric scraps, blunt plastic needle when possible, embroidery thread, and large simple stitches.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice a running stitch on scrap fabric before trying a project."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Sewing and stitching basics?",
          "choices": [
            "Even stitches are easier when the fabric is held steady and the path is marked lightly first.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use needles only with adult approval, count them before and after, and store them safely.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words stitch, seam, thread, fabric matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Sewing and stitching basics?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a tiny felt patch with a border of simple running stitches."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🪡 Safe Stitch Patch"
    },
    {
      "studio": "Craft Cottage",
      "title": "Clay and modeling materials",
      "icon": "🏺",
      "summary": "Modeling materials can be pinched, rolled, pressed, joined, textured, and shaped into small objects or relief designs.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "clay",
          "paragraphs": [
            "Clay and modeling materials teaches this main idea: Modeling materials can be pinched, rolled, pressed, joined, textured, and shaped into small objects or relief designs.",
            "This belongs in the Craft Cottage because Clay-like work teaches form because the maker handles height, thickness, balance, surface, and structure directly.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are form, coil, slab, texture. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use kid-safe modeling clay or dough, a protected surface, and simple tools like craft sticks or plastic knives if approved.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use only non-food craft materials for crafting and wash hands afterward.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start with basic forms: ball, coil, slab, pinch pot, and pressed texture.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A sculpture that looks good still needs to stand, hold together, and avoid pieces that are too thin to survive handling.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a small coil bowl or textured tile.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏺 Clay Maker Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Clay and modeling materials?",
          "choices": [
            "Modeling materials can be pinched, rolled, pressed, joined, textured, and shaped into small objects or relief designs.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Clay and modeling materials belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Clay-like work teaches form because the maker handles height, thickness, balance, surface, and structure directly.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Clay and modeling materials?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use kid-safe modeling clay or dough, a protected surface, and simple tools like craft sticks or plastic knives if approved.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start with basic forms: ball, coil, slab, pinch pot, and pressed texture."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Clay and modeling materials?",
          "choices": [
            "A sculpture that looks good still needs to stand, hold together, and avoid pieces that are too thin to survive handling.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use only non-food craft materials for crafting and wash hands afterward.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words form, coil, slab, texture matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Clay and modeling materials?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a small coil bowl or textured tile."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏺 Clay Maker Token"
    },
    {
      "studio": "Craft Cottage",
      "title": "Building with cardboard",
      "icon": "📦",
      "summary": "Cardboard can become houses, signs, stages, models, frames, storage, scenery, and game pieces.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "box",
          "paragraphs": [
            "Building with cardboard teaches this main idea: Cardboard can become houses, signs, stages, models, frames, storage, scenery, and game pieces.",
            "This belongs in the Craft Cottage because Cardboard crafting teaches structure because flat pieces must be folded, braced, joined, or layered to stand.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are brace, tab, structure, model. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use cereal boxes, cardboard, tape, glue, ruler, pencil, and safe scissors.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Thick cardboard can be hard to cut; get adult help rather than forcing scissors.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Plan walls, tabs, braces, and openings before cutting. Test-fit pieces before final glue.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A strong cardboard build usually has hidden support. The inside matters even when the outside gets decorated.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Build a tiny display stand that can hold a small paper sign upright.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📦 Cardboard Builder Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Building with cardboard?",
          "choices": [
            "Cardboard can become houses, signs, stages, models, frames, storage, scenery, and game pieces.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Building with cardboard belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Cardboard crafting teaches structure because flat pieces must be folded, braced, joined, or layered to stand.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Building with cardboard?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use cereal boxes, cardboard, tape, glue, ruler, pencil, and safe scissors.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Plan walls, tabs, braces, and openings before cutting. Test-fit pieces before final glue."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Building with cardboard?",
          "choices": [
            "A strong cardboard build usually has hidden support. The inside matters even when the outside gets decorated.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Thick cardboard can be hard to cut; get adult help rather than forcing scissors.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words brace, tab, structure, model matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Building with cardboard?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Build a tiny display stand that can hold a small paper sign upright."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📦 Cardboard Builder Badge"
    },
    {
      "studio": "Craft Cottage",
      "title": "Finishing touches without clutter",
      "icon": "✨",
      "summary": "Finishing touches are the last details that make a craft look complete, clear, and cared for.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "sparkle",
          "paragraphs": [
            "Finishing touches without clutter teaches this main idea: Finishing touches are the last details that make a craft look complete, clear, and cared for.",
            "This belongs in the Craft Cottage because A project can be weakened by adding too much. Good finishing means choosing details that help the design.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are finish, border, highlight, trim. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use borders, labels, small highlights, neat edges, a backing layer, or one repeated accent.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Let glue dry before handling so pieces do not slide or tear.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Pause before adding more. Ask whether the new detail improves the project or only fills space.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Finish work shows respect for the time already spent. It can include cleanup, trimming, drying, and display.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Take one simple paper craft and add only three finishing details.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ✨ Neat Finish Star",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Finishing touches without clutter?",
          "choices": [
            "Finishing touches are the last details that make a craft look complete, clear, and cared for.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Finishing touches without clutter belong in the Craft Cottage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A project can be weakened by adding too much. Good finishing means choosing details that help the design.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Finishing touches without clutter?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use borders, labels, small highlights, neat edges, a backing layer, or one repeated accent.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Pause before adding more. Ask whether the new detail improves the project or only fills space."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Finishing touches without clutter?",
          "choices": [
            "Finish work shows respect for the time already spent. It can include cleanup, trimming, drying, and display.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Let glue dry before handling so pieces do not slide or tear.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words finish, border, highlight, trim matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Finishing touches without clutter?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Take one simple paper craft and add only three finishing details."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "✨ Neat Finish Star"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Welcome to the Pattern Workshop",
      "icon": "🔶",
      "summary": "Design uses choices about shape, color, spacing, balance, contrast, pattern, and purpose.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "pattern",
          "paragraphs": [
            "Welcome to the Pattern Workshop teaches this main idea: Design uses choices about shape, color, spacing, balance, contrast, pattern, and purpose.",
            "This belongs in the Pattern Workshop because Patterns and layouts appear in quilts, tiles, books, clothing, signs, borders, maps, game screens, and home decor.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are design, layout, pattern, purpose. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use grid paper, ruler, colored pencils, cut shapes, or digital-safe planning tools if available.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use rulers and scissors carefully and keep small shape pieces collected.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Begin with a purpose: decorate a border, organize information, make a symbol, or build a repeating design.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Design is problem solving for the eye. It asks what should be noticed first and how the parts should fit.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a small pattern strip using two shapes and three colors.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔶 Pattern Workshop Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Pattern Workshop?",
          "choices": [
            "Design uses choices about shape, color, spacing, balance, contrast, pattern, and purpose.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Pattern Workshop belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Patterns and layouts appear in quilts, tiles, books, clothing, signs, borders, maps, game screens, and home decor.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Pattern Workshop?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use grid paper, ruler, colored pencils, cut shapes, or digital-safe planning tools if available.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Begin with a purpose: decorate a border, organize information, make a symbol, or build a repeating design."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Pattern Workshop?",
          "choices": [
            "Design is problem solving for the eye. It asks what should be noticed first and how the parts should fit.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use rulers and scissors carefully and keep small shape pieces collected.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words design, layout, pattern, purpose matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Pattern Workshop?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a small pattern strip using two shapes and three colors."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔶 Pattern Workshop Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Repeating patterns",
      "icon": "🔁",
      "summary": "A repeating pattern uses a unit that comes back in order.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "loop",
          "paragraphs": [
            "Repeating patterns teaches this main idea: A repeating pattern uses a unit that comes back in order.",
            "This belongs in the Pattern Workshop because Repeating patterns help decorate, organize, count, predict, and create rhythm across a surface.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are repeat, motif, sequence, rhythm. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a simple motif such as circle-star-leaf or triangle-square-line. Repeat it across a strip.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep marker caps closed so colors stay usable.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Check the repeat by reading it out loud or pointing to each unit.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The unit should be clear enough that someone else can predict what comes next.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create an AB, AAB, ABC, and mirror repeat on one page.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔁 Repeat Rhythm Ribbon",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Repeating patterns?",
          "choices": [
            "A repeating pattern uses a unit that comes back in order.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Repeating patterns belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Repeating patterns help decorate, organize, count, predict, and create rhythm across a surface.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Repeating patterns?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a simple motif such as circle-star-leaf or triangle-square-line. Repeat it across a strip.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Check the repeat by reading it out loud or pointing to each unit."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Repeating patterns?",
          "choices": [
            "The unit should be clear enough that someone else can predict what comes next.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep marker caps closed so colors stay usable.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words repeat, motif, sequence, rhythm matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Repeating patterns?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create an AB, AAB, ABC, and mirror repeat on one page."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔁 Repeat Rhythm Ribbon"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Symmetry and mirror design",
      "icon": "🪞",
      "summary": "Symmetry means parts match across a line, center, or rotation.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "mirror",
          "paragraphs": [
            "Symmetry and mirror design teaches this main idea: Symmetry means parts match across a line, center, or rotation.",
            "This belongs in the Pattern Workshop because Symmetry appears in leaves, butterflies, buildings, shields, snowflake designs, furniture, and patterns.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are symmetry, mirror, center line, match. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Fold paper to create a center line, draw one side lightly, then copy or cut to make a matching side.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not cut folded paper too close to the crease unless you want separate pieces.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Look carefully for what must match: size, direction, position, and spacing.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Symmetry can feel calm and ordered, but not every design needs to be symmetrical. The choice should fit the goal.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a shield or badge design with clear left-right symmetry.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🪞 Symmetry Mirror Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Symmetry and mirror design?",
          "choices": [
            "Symmetry means parts match across a line, center, or rotation.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Symmetry and mirror design belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Symmetry appears in leaves, butterflies, buildings, shields, snowflake designs, furniture, and patterns.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Symmetry and mirror design?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Fold paper to create a center line, draw one side lightly, then copy or cut to make a matching side.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Look carefully for what must match: size, direction, position, and spacing."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Symmetry and mirror design?",
          "choices": [
            "Symmetry can feel calm and ordered, but not every design needs to be symmetrical. The choice should fit the goal.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not cut folded paper too close to the crease unless you want separate pieces.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words symmetry, mirror, center line, match matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Symmetry and mirror design?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a shield or badge design with clear left-right symmetry."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🪞 Symmetry Mirror Charm"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Balance in a design",
      "icon": "⚖️",
      "summary": "Balance is how visual weight is spread across a page, object, stage, or layout.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "scales",
          "paragraphs": [
            "Balance in a design teaches this main idea: Balance is how visual weight is spread across a page, object, stage, or layout.",
            "This belongs in the Pattern Workshop because A design can feel tilted or crowded if all strong shapes, dark values, or busy details sit on one side.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are balance, visual weight, focus, space. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use big and small shapes, light and dark areas, empty space, and placement to test balance.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Step back from the page before adding more details; distance helps reveal imbalance.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Place the main focus first, then add supporting parts so the whole design feels steady.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Balance does not always mean both sides match. Asymmetrical balance can still feel stable if the visual weight is handled well.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Arrange five cut shapes into a balanced design without making both sides identical.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ⚖️ Balance Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Balance in a design?",
          "choices": [
            "Balance is how visual weight is spread across a page, object, stage, or layout.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Balance in a design belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A design can feel tilted or crowded if all strong shapes, dark values, or busy details sit on one side.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Balance in a design?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use big and small shapes, light and dark areas, empty space, and placement to test balance.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Place the main focus first, then add supporting parts so the whole design feels steady."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Balance in a design?",
          "choices": [
            "Balance does not always mean both sides match. Asymmetrical balance can still feel stable if the visual weight is handled well.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Step back from the page before adding more details; distance helps reveal imbalance.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words balance, visual weight, focus, space matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Balance in a design?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Arrange five cut shapes into a balanced design without making both sides identical."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "⚖️ Balance Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Contrast and emphasis",
      "icon": "🔦",
      "summary": "Contrast makes differences stand out, and emphasis tells the viewer what to notice first.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "lantern",
          "paragraphs": [
            "Contrast and emphasis teaches this main idea: Contrast makes differences stand out, and emphasis tells the viewer what to notice first.",
            "This belongs in the Pattern Workshop because Contrast can come from light against dark, large next to small, smooth near rough, warm near cool, or simple beside busy.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are contrast, emphasis, focus, difference. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose one main focus and make it different from its surroundings in one or two clear ways.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use bold markers or dark paint with care because strong marks are harder to undo.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Too much contrast everywhere becomes noise. Emphasis works best when some areas stay calmer.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good design guides the eye instead of making everything shout at once.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make one small poster where the main word or shape is easy to spot first.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔦 Focus Lantern Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Contrast and emphasis?",
          "choices": [
            "Contrast makes differences stand out, and emphasis tells the viewer what to notice first.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Contrast and emphasis belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Contrast can come from light against dark, large next to small, smooth near rough, warm near cool, or simple beside busy.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Contrast and emphasis?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose one main focus and make it different from its surroundings in one or two clear ways.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Too much contrast everywhere becomes noise. Emphasis works best when some areas stay calmer."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Contrast and emphasis?",
          "choices": [
            "A good design guides the eye instead of making everything shout at once.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use bold markers or dark paint with care because strong marks are harder to undo.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words contrast, emphasis, focus, difference matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Contrast and emphasis?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make one small poster where the main word or shape is easy to spot first."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔦 Focus Lantern Token"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Borders and frames",
      "icon": "🖼️",
      "summary": "A border or frame can protect the edge, guide the eye, decorate a page, or make a project feel finished.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "frame",
          "paragraphs": [
            "Borders and frames teaches this main idea: A border or frame can protect the edge, guide the eye, decorate a page, or make a project feel finished.",
            "This belongs in the Pattern Workshop because Borders appear in books, maps, certificates, quilts, tiles, signs, and picture frames.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are border, frame, corner, margin. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use repeated shapes, corner markers, ruler lines, or small symbols connected to the subject.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Leave enough margin so the border does not crowd the main work.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Keep the border from fighting the main picture. It should support the work, not take over.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A strong border has corners, spacing, and repeat units that look intentional.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Design a border for a story map, nature page, or invention notebook.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🖼️ Border Maker Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Borders and frames?",
          "choices": [
            "A border or frame can protect the edge, guide the eye, decorate a page, or make a project feel finished.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Borders and frames belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Borders appear in books, maps, certificates, quilts, tiles, signs, and picture frames.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Borders and frames?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use repeated shapes, corner markers, ruler lines, or small symbols connected to the subject.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Keep the border from fighting the main picture. It should support the work, not take over."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Borders and frames?",
          "choices": [
            "A strong border has corners, spacing, and repeat units that look intentional.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Leave enough margin so the border does not crowd the main work.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words border, frame, corner, margin matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Borders and frames?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Design a border for a story map, nature page, or invention notebook."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🖼️ Border Maker Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Lettering and readable words",
      "icon": "🔤",
      "summary": "Lettering turns words into visual design while still needing to stay readable.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "letters",
          "paragraphs": [
            "Lettering and readable words teaches this main idea: Lettering turns words into visual design while still needing to stay readable.",
            "This belongs in the Pattern Workshop because Signs, labels, cards, maps, posters, comics, and title pages all depend on letter size, spacing, and clarity.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are lettering, spacing, title, label. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use pencil guidelines, block letters, bubble letters, serif ideas, or simple script if it remains clear.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Avoid copying trademark logos exactly; design your own letters for your own project.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Plan the word first so it fits. Count letters and mark the middle before drawing huge letters.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The best lettering matches the project without making people struggle to read.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make three title styles for the same word: bold, quiet, and playful.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔤 Lettering Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Lettering and readable words?",
          "choices": [
            "Lettering turns words into visual design while still needing to stay readable.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Lettering and readable words belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Signs, labels, cards, maps, posters, comics, and title pages all depend on letter size, spacing, and clarity.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Lettering and readable words?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use pencil guidelines, block letters, bubble letters, serif ideas, or simple script if it remains clear.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Plan the word first so it fits. Count letters and mark the middle before drawing huge letters."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Lettering and readable words?",
          "choices": [
            "The best lettering matches the project without making people struggle to read.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Avoid copying trademark logos exactly; design your own letters for your own project.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words lettering, spacing, title, label matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Lettering and readable words?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make three title styles for the same word: bold, quiet, and playful."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔤 Lettering Token"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Layout for pages and posters",
      "icon": "🧭",
      "summary": "Layout is the arrangement of words, pictures, headings, margins, and empty space.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "compass",
          "paragraphs": [
            "Layout for pages and posters teaches this main idea: Layout is the arrangement of words, pictures, headings, margins, and empty space.",
            "This belongs in the Pattern Workshop because Good layout helps the viewer know where to start, what matters, and what belongs together.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are layout, margin, heading, empty space. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use boxes, columns, headings, picture spaces, and arrows before final writing or drawing.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not crowd every corner; empty space can make a page easier to read.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Make a thumbnail first. A tiny plan can save a messy full-size page.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Layout is not decoration at the end. It is the map that makes the information easier to follow.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Plan a one-page display with a title, picture, three facts, and a border.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧭 Layout Compass Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Layout for pages and posters?",
          "choices": [
            "Layout is the arrangement of words, pictures, headings, margins, and empty space.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Layout for pages and posters belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Good layout helps the viewer know where to start, what matters, and what belongs together.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Layout for pages and posters?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use boxes, columns, headings, picture spaces, and arrows before final writing or drawing.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Make a thumbnail first. A tiny plan can save a messy full-size page."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Layout for pages and posters?",
          "choices": [
            "Layout is not decoration at the end. It is the map that makes the information easier to follow.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not crowd every corner; empty space can make a page easier to read.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words layout, margin, heading, empty space matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Layout for pages and posters?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Plan a one-page display with a title, picture, three facts, and a border."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧭 Layout Compass Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Tessellations and tile thinking",
      "icon": "🧱",
      "summary": "A tessellation uses shapes that fit together without gaps or overlaps.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "tiles",
          "paragraphs": [
            "Tessellations and tile thinking teaches this main idea: A tessellation uses shapes that fit together without gaps or overlaps.",
            "This belongs in the Pattern Workshop because Tiles, mosaics, floors, quilts, and some nature patterns show how repeated shapes can cover a surface.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are tessellation, tile, gap, overlap. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Start with squares, triangles, or hexagons. Then try a simple repeated cut-and-slide shape if ready.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use scissors carefully and keep small tile pieces in a tray or envelope.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Check whether each piece touches neatly and repeats in the same order.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Tessellation is art meeting geometry. The beauty comes from fit, repeat, and transformation.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Fill a small rectangle with repeated triangles or squares and add color rhythm.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧱 Tile Designer Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Tessellations and tile thinking?",
          "choices": [
            "A tessellation uses shapes that fit together without gaps or overlaps.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Tessellations and tile thinking belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Tiles, mosaics, floors, quilts, and some nature patterns show how repeated shapes can cover a surface.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Tessellations and tile thinking?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Start with squares, triangles, or hexagons. Then try a simple repeated cut-and-slide shape if ready.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Check whether each piece touches neatly and repeats in the same order."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Tessellations and tile thinking?",
          "choices": [
            "Tessellation is art meeting geometry. The beauty comes from fit, repeat, and transformation.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use scissors carefully and keep small tile pieces in a tray or envelope.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words tessellation, tile, gap, overlap matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Tessellations and tile thinking?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Fill a small rectangle with repeated triangles or squares and add color rhythm."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧱 Tile Designer Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Designing a symbol or badge",
      "icon": "🏅",
      "summary": "A symbol uses a simple image to stand for an idea, group, place, skill, or story.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "badge",
          "paragraphs": [
            "Designing a symbol or badge teaches this main idea: A symbol uses a simple image to stand for an idea, group, place, skill, or story.",
            "This belongs in the Pattern Workshop because Badges, crests, icons, signs, game rewards, and map markers need symbols that are easy to recognize.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are symbol, icon, badge, silhouette. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose one main idea, then reduce it to a clear shape, strong outline, and limited colors.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep symbols original and avoid copying official emblems.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Test the symbol small. If it cannot be recognized when tiny, it may be too complicated.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A symbol should not need a long explanation before it works. Simplicity gives it power.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Design a badge for a maker skill such as careful cutting, good cleanup, or brave revision.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏅 Symbol Smith Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Designing a symbol or badge?",
          "choices": [
            "A symbol uses a simple image to stand for an idea, group, place, skill, or story.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Designing a symbol or badge belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Badges, crests, icons, signs, game rewards, and map markers need symbols that are easy to recognize.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Designing a symbol or badge?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose one main idea, then reduce it to a clear shape, strong outline, and limited colors.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Test the symbol small. If it cannot be recognized when tiny, it may be too complicated."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Designing a symbol or badge?",
          "choices": [
            "A symbol should not need a long explanation before it works. Simplicity gives it power.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep symbols original and avoid copying official emblems.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words symbol, icon, badge, silhouette matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Designing a symbol or badge?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Design a badge for a maker skill such as careful cutting, good cleanup, or brave revision."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏅 Symbol Smith Badge"
    },
    {
      "studio": "Pattern Workshop",
      "title": "Design review and revision",
      "icon": "🔍",
      "summary": "Design review means looking at a project and asking what works, what confuses, and what could improve.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "magnifier",
          "paragraphs": [
            "Design review and revision teaches this main idea: Design review means looking at a project and asking what works, what confuses, and what could improve.",
            "This belongs in the Pattern Workshop because Revision is a normal maker habit, not a punishment. Even strong artists and designers make changes.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are review, revision, clear, improve. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use questions: What is the focus? Is it readable? Is anything crowded? Does the color plan fit?",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use gentle language when reviewing anyone else’s work.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Choose one change at a time so you can tell what improved the design.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good review is kind, specific, and useful. It names the work, not the worth of the maker.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Pick an old sketch and improve one part without starting over.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔍 Revision Lens Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Design review and revision?",
          "choices": [
            "Design review means looking at a project and asking what works, what confuses, and what could improve.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Design review and revision belong in the Pattern Workshop?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Revision is a normal maker habit, not a punishment. Even strong artists and designers make changes.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Design review and revision?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use questions: What is the focus? Is it readable? Is anything crowded? Does the color plan fit?",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Choose one change at a time so you can tell what improved the design."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Design review and revision?",
          "choices": [
            "A good review is kind, specific, and useful. It names the work, not the worth of the maker.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use gentle language when reviewing anyone else’s work.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words review, revision, clear, improve matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Design review and revision?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Pick an old sketch and improve one part without starting over."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔍 Revision Lens Charm"
    },
    {
      "studio": "Theater Stage",
      "title": "Welcome to the Theater Stage",
      "icon": "🎭",
      "summary": "Theater uses voice, movement, setting, props, timing, and story to bring scenes to life.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "mask",
          "paragraphs": [
            "Welcome to the Theater Stage teaches this main idea: Theater uses voice, movement, setting, props, timing, and story to bring scenes to life.",
            "This belongs in the Theater Stage because A theater stage can be a real stage, a puppet box, a blanket fort, a tabletop, or a marked space on the floor.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are scene, stage, prop, cue. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Basic tools include a short script, simple props, safe costumes, a clear acting space, and a beginning and ending cue.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep walking paths clear, avoid capes or cords that drag, and never use props as weapons.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start with a tiny scene: who is there, where they are, what they want, and what changes.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Theater teaches expression, listening, sequence, confidence, and teamwork without needing fancy equipment.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a thirty-second scene with one prop and one clear ending line.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎭 Stage Starter Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Theater Stage?",
          "choices": [
            "Theater uses voice, movement, setting, props, timing, and story to bring scenes to life.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Theater Stage belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A theater stage can be a real stage, a puppet box, a blanket fort, a tabletop, or a marked space on the floor.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Theater Stage?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Basic tools include a short script, simple props, safe costumes, a clear acting space, and a beginning and ending cue.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start with a tiny scene: who is there, where they are, what they want, and what changes."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Theater Stage?",
          "choices": [
            "Theater teaches expression, listening, sequence, confidence, and teamwork without needing fancy equipment.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep walking paths clear, avoid capes or cords that drag, and never use props as weapons.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words scene, stage, prop, cue matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Theater Stage?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a thirty-second scene with one prop and one clear ending line."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎭 Stage Starter Badge"
    },
    {
      "studio": "Theater Stage",
      "title": "Voice and clear speaking",
      "icon": "📣",
      "summary": "A stage voice is clear, steady, and expressive enough for listeners to understand.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "megaphone",
          "paragraphs": [
            "Voice and clear speaking teaches this main idea: A stage voice is clear, steady, and expressive enough for listeners to understand.",
            "This belongs in the Theater Stage because Voice work matters because a good line can be lost if it is mumbled, rushed, or shouted without control.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are volume, pause, pitch, expression. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Practice volume, speed, pause, pitch, and expression using a short sentence.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not strain the voice or scream for practice; control is better than force.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Say the same line as surprised, calm, nervous, proud, and sleepy.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Clear speaking is not just loud speaking. It uses breath, timing, and clean words.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Read one short line three ways and decide which meaning is clearest.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📣 Clear Voice Ribbon",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Voice and clear speaking?",
          "choices": [
            "A stage voice is clear, steady, and expressive enough for listeners to understand.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Voice and clear speaking belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Voice work matters because a good line can be lost if it is mumbled, rushed, or shouted without control.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Voice and clear speaking?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Practice volume, speed, pause, pitch, and expression using a short sentence.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Say the same line as surprised, calm, nervous, proud, and sleepy."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Voice and clear speaking?",
          "choices": [
            "Clear speaking is not just loud speaking. It uses breath, timing, and clean words.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not strain the voice or scream for practice; control is better than force.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words volume, pause, pitch, expression matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Voice and clear speaking?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Read one short line three ways and decide which meaning is clearest."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📣 Clear Voice Ribbon"
    },
    {
      "studio": "Theater Stage",
      "title": "Gesture and body language",
      "icon": "🙋",
      "summary": "Gesture and body language show feeling, action, attention, and character before words are even spoken.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "gesture",
          "paragraphs": [
            "Gesture and body language teaches this main idea: Gesture and body language show feeling, action, attention, and character before words are even spoken.",
            "This belongs in the Theater Stage because Movement helps a scene because the audience can see who is confident, tired, sneaky, confused, excited, or careful.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are gesture, posture, movement, stillness. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Practice open hands, crossed arms, looking away, leaning forward, slow steps, quick steps, and stillness.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use safe, slow movement and keep enough space between people and furniture.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Choose movement that fits the character and scene instead of wiggling randomly.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Stillness can be powerful. A character who freezes or slowly turns can say a lot without words.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Act out finding a mysterious key using only movement and no words.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🙋 Gesture Guide Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Gesture and body language?",
          "choices": [
            "Gesture and body language show feeling, action, attention, and character before words are even spoken.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Gesture and body language belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Movement helps a scene because the audience can see who is confident, tired, sneaky, confused, excited, or careful.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Gesture and body language?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Practice open hands, crossed arms, looking away, leaning forward, slow steps, quick steps, and stillness.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Choose movement that fits the character and scene instead of wiggling randomly."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Gesture and body language?",
          "choices": [
            "Stillness can be powerful. A character who freezes or slowly turns can say a lot without words.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use safe, slow movement and keep enough space between people and furniture.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words gesture, posture, movement, stillness matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Gesture and body language?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Act out finding a mysterious key using only movement and no words."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🙋 Gesture Guide Badge"
    },
    {
      "studio": "Theater Stage",
      "title": "Script beats",
      "icon": "📜",
      "summary": "A beat is a small unit of action or change inside a scene.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "scroll",
          "paragraphs": [
            "Script beats teaches this main idea: A beat is a small unit of action or change inside a scene.",
            "This belongs in the Theater Stage because Breaking a scene into beats helps performers know when a character learns, decides, reacts, or changes direction.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are beat, action, reaction, change. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a short scene and mark each time the action changes.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep scripts short enough to practice well instead of rushing too much material.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "A beat can be as simple as noticing a sound, asking a question, hiding an object, or choosing to help.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Beat thinking keeps a scene from becoming one flat blur. It gives the performance steps.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Write a four-beat scene about opening a strange box.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📜 Script Beat Scroll",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Script beats?",
          "choices": [
            "A beat is a small unit of action or change inside a scene.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Script beats belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Breaking a scene into beats helps performers know when a character learns, decides, reacts, or changes direction.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Script beats?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a short scene and mark each time the action changes.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "A beat can be as simple as noticing a sound, asking a question, hiding an object, or choosing to help."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Script beats?",
          "choices": [
            "Beat thinking keeps a scene from becoming one flat blur. It gives the performance steps.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep scripts short enough to practice well instead of rushing too much material.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words beat, action, reaction, change matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Script beats?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Write a four-beat scene about opening a strange box."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📜 Script Beat Scroll"
    },
    {
      "studio": "Theater Stage",
      "title": "Props that help the story",
      "icon": "🗝️",
      "summary": "A prop is an object used in a scene, and the best props help the audience understand the story.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "key",
          "paragraphs": [
            "Props that help the story teaches this main idea: A prop is an object used in a scene, and the best props help the audience understand the story.",
            "This belongs in the Theater Stage because Props can show place, job, clue, goal, memory, mistake, or change.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are prop, clue, object, stage business. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose safe, simple props that are easy to hold and easy to recognize.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use soft or harmless props and ask before borrowing household items.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "A prop should have a reason. If it does not change the scene or explain something, it may not belong.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "One strong prop is often better than a pile of random things.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Choose one object and make it important in a tiny scene.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🗝️ Prop Keeper Key",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Props that help the story?",
          "choices": [
            "A prop is an object used in a scene, and the best props help the audience understand the story.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Props that help the story belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Props can show place, job, clue, goal, memory, mistake, or change.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Props that help the story?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose safe, simple props that are easy to hold and easy to recognize.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "A prop should have a reason. If it does not change the scene or explain something, it may not belong."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Props that help the story?",
          "choices": [
            "One strong prop is often better than a pile of random things.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use soft or harmless props and ask before borrowing household items.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words prop, clue, object, stage business matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Props that help the story?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Choose one object and make it important in a tiny scene."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🗝️ Prop Keeper Key"
    },
    {
      "studio": "Theater Stage",
      "title": "Puppet design",
      "icon": "🧸",
      "summary": "A puppet is a character controlled by hand, stick, string, shadow, or simple movement.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "puppet",
          "paragraphs": [
            "Puppet design teaches this main idea: A puppet is a character controlled by hand, stick, string, shadow, or simple movement.",
            "This belongs in the Theater Stage because Puppets let a maker combine craft, voice, design, and story in one small character.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are puppet, character, expression, control. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use paper bags, socks, craft sticks, paper plates, felt, buttons drawn on paper, yarn, or cardboard.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Avoid tiny loose decorations if younger children may reach them.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Design the puppet’s face so the emotion can be seen from a little distance.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A puppet does not need many details. It needs clear eyes, a readable shape, and movement that fits its personality.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a simple puppet with one strong facial expression.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧸 Puppet Maker Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Puppet design?",
          "choices": [
            "A puppet is a character controlled by hand, stick, string, shadow, or simple movement.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Puppet design belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Puppets let a maker combine craft, voice, design, and story in one small character.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Puppet design?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use paper bags, socks, craft sticks, paper plates, felt, buttons drawn on paper, yarn, or cardboard.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Design the puppet’s face so the emotion can be seen from a little distance."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Puppet design?",
          "choices": [
            "A puppet does not need many details. It needs clear eyes, a readable shape, and movement that fits its personality.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Avoid tiny loose decorations if younger children may reach them.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words puppet, character, expression, control matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Puppet design?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a simple puppet with one strong facial expression."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧸 Puppet Maker Badge"
    },
    {
      "studio": "Theater Stage",
      "title": "Shadow theater",
      "icon": "🌑",
      "summary": "Shadow theater uses light, a screen, and silhouettes to tell a story.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "shadow",
          "paragraphs": [
            "Shadow theater teaches this main idea: Shadow theater uses light, a screen, and silhouettes to tell a story.",
            "This belongs in the Theater Stage because Because the audience sees outlines, shadow theater teaches strong shape design and clear movement.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are silhouette, shadow, screen, light source. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a flashlight, wall or sheet, and simple cut paper shapes with adult approval.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not shine bright lights into eyes and keep cords or lamps safely placed.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Move characters slowly and keep them between the light and screen.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A shadow scene works best with bold silhouettes and simple action. Tiny details disappear.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a three-shadow scene with a tree, a door, and one character.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🌑 Shadow Stage Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Shadow theater?",
          "choices": [
            "Shadow theater uses light, a screen, and silhouettes to tell a story.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Shadow theater belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Because the audience sees outlines, shadow theater teaches strong shape design and clear movement.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Shadow theater?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a flashlight, wall or sheet, and simple cut paper shapes with adult approval.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Move characters slowly and keep them between the light and screen."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Shadow theater?",
          "choices": [
            "A shadow scene works best with bold silhouettes and simple action. Tiny details disappear.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not shine bright lights into eyes and keep cords or lamps safely placed.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words silhouette, shadow, screen, light source matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Shadow theater?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a three-shadow scene with a tree, a door, and one character."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🌑 Shadow Stage Token"
    },
    {
      "studio": "Theater Stage",
      "title": "Costume and character clues",
      "icon": "👒",
      "summary": "Costume pieces can hint at who a character is without needing a long explanation.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "hat",
          "paragraphs": [
            "Costume and character clues teaches this main idea: Costume pieces can hint at who a character is without needing a long explanation.",
            "This belongs in the Theater Stage because A hat, scarf, apron, cloak, badge, or color choice can suggest job, mood, time, place, or personality.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are costume, character clue, accessory, color. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use simple, safe pieces from approved dress-up or craft materials.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Avoid masks or clothing that blocks vision, breathing, or safe walking.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Choose one clue, not ten. Too many pieces can make movement awkward and the character unclear.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Costume design is storytelling through shape, color, and practical use.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Design a paper costume card for a lighthouse keeper, painter, or inventor.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 👒 Costume Clue Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Costume and character clues?",
          "choices": [
            "Costume pieces can hint at who a character is without needing a long explanation.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Costume and character clues belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A hat, scarf, apron, cloak, badge, or color choice can suggest job, mood, time, place, or personality.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Costume and character clues?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use simple, safe pieces from approved dress-up or craft materials.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Choose one clue, not ten. Too many pieces can make movement awkward and the character unclear."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Costume and character clues?",
          "choices": [
            "Costume design is storytelling through shape, color, and practical use.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Avoid masks or clothing that blocks vision, breathing, or safe walking.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words costume, character clue, accessory, color matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Costume and character clues?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Design a paper costume card for a lighthouse keeper, painter, or inventor."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "👒 Costume Clue Badge"
    },
    {
      "studio": "Theater Stage",
      "title": "Setting a scene",
      "icon": "🏕️",
      "summary": "A scene setting tells where the action happens and what kind of world the character is in.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "tent",
          "paragraphs": [
            "Setting a scene teaches this main idea: A scene setting tells where the action happens and what kind of world the character is in.",
            "This belongs in the Theater Stage because Setting can be shown by backdrop, sound, prop, line of dialogue, movement, or a simple sign.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are setting, backdrop, place, clue. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use one backdrop idea, one prop, and one sound or line to suggest the place.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep scenery low and stable so it does not fall or block movement.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "A strong setting does not need a huge build. It needs selected clues that work together.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The audience should know the place quickly enough to follow the action.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Turn a chair and blanket into three different settings using only small changes.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏕️ Scene Setter Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Setting a scene?",
          "choices": [
            "A scene setting tells where the action happens and what kind of world the character is in.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Setting a scene belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Setting can be shown by backdrop, sound, prop, line of dialogue, movement, or a simple sign.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Setting a scene?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use one backdrop idea, one prop, and one sound or line to suggest the place.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "A strong setting does not need a huge build. It needs selected clues that work together."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Setting a scene?",
          "choices": [
            "The audience should know the place quickly enough to follow the action.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep scenery low and stable so it does not fall or block movement.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words setting, backdrop, place, clue matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Setting a scene?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Turn a chair and blanket into three different settings using only small changes."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏕️ Scene Setter Badge"
    },
    {
      "studio": "Theater Stage",
      "title": "Rehearsal and timing",
      "icon": "⏱️",
      "summary": "Rehearsal means practicing the scene so lines, movement, props, and timing work smoothly.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "timer",
          "paragraphs": [
            "Rehearsal and timing teaches this main idea: Rehearsal means practicing the scene so lines, movement, props, and timing work smoothly.",
            "This belongs in the Theater Stage because Timing matters because entrances, pauses, reactions, and endings help the audience understand the story.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are rehearsal, timing, entrance, pause. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Practice once for words, once for movement, once for props, and once for the whole scene.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep practice spaces calm and stop if movement becomes unsafe.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "If something goes wrong, pause, reset, and try again without turning the practice into a fuss.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Rehearsal is not about being flawless. It is about becoming ready.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Practice a tiny scene three times and improve only one thing each time.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ⏱️ Rehearsal Timer Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Rehearsal and timing?",
          "choices": [
            "Rehearsal means practicing the scene so lines, movement, props, and timing work smoothly.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Rehearsal and timing belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Timing matters because entrances, pauses, reactions, and endings help the audience understand the story.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Rehearsal and timing?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Practice once for words, once for movement, once for props, and once for the whole scene.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "If something goes wrong, pause, reset, and try again without turning the practice into a fuss."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Rehearsal and timing?",
          "choices": [
            "Rehearsal is not about being flawless. It is about becoming ready.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep practice spaces calm and stop if movement becomes unsafe.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words rehearsal, timing, entrance, pause matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Rehearsal and timing?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Practice a tiny scene three times and improve only one thing each time."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "⏱️ Rehearsal Timer Token"
    },
    {
      "studio": "Theater Stage",
      "title": "Kind audience habits",
      "icon": "👏",
      "summary": "An audience helps a performance by listening, watching, waiting, and responding at the right time.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "applause",
          "paragraphs": [
            "Kind audience habits teaches this main idea: An audience helps a performance by listening, watching, waiting, and responding at the right time.",
            "This belongs in the Theater Stage because Good audience habits make small home performances feel respected without making them stiff or formal.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are audience, attention, applause, feedback. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Practice quiet watching, laughing at the right time, clapping at the end, and giving one kind specific comment.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not tease performers or interrupt unless safety needs attention.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "A helpful comment names something real: a clear voice, funny movement, good prop, or strong ending.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The stage and audience work together. One side shares; the other side receives with attention.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Watch a one-minute puppet scene and give one kind, specific comment.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 👏 Good Audience Star",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Kind audience habits?",
          "choices": [
            "An audience helps a performance by listening, watching, waiting, and responding at the right time.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Kind audience habits belong in the Theater Stage?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Good audience habits make small home performances feel respected without making them stiff or formal.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Kind audience habits?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Practice quiet watching, laughing at the right time, clapping at the end, and giving one kind specific comment.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "A helpful comment names something real: a clear voice, funny movement, good prop, or strong ending."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Kind audience habits?",
          "choices": [
            "The stage and audience work together. One side shares; the other side receives with attention.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not tease performers or interrupt unless safety needs attention.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words audience, attention, applause, feedback matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Kind audience habits?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Watch a one-minute puppet scene and give one kind, specific comment."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "👏 Good Audience Star"
    },
    {
      "studio": "Music Corner",
      "title": "Welcome to the Music Corner",
      "icon": "🎼",
      "summary": "Music uses organized sound, silence, beat, rhythm, pitch, melody, dynamics, and pattern.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "music",
          "paragraphs": [
            "Welcome to the Music Corner teaches this main idea: Music uses organized sound, silence, beat, rhythm, pitch, melody, dynamics, and pattern.",
            "This belongs in the Music Corner because Music connects art to listening because the maker must notice what happens over time, not just what sits on a page.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are sound, beat, rhythm, melody. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use voice, claps, taps, safe household rhythm objects, simple instruments, or listening maps.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Protect ears, keep volume reasonable, and do not hit objects that can break.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start with beat and pattern before trying complicated tunes.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A music corner habit is to listen first, practice slowly, and repeat short patterns until they feel steady.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Clap a steady beat while saying a short rhyme.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎼 Music Corner Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Music Corner?",
          "choices": [
            "Music uses organized sound, silence, beat, rhythm, pitch, melody, dynamics, and pattern.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Music Corner belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Music connects art to listening because the maker must notice what happens over time, not just what sits on a page.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Music Corner?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use voice, claps, taps, safe household rhythm objects, simple instruments, or listening maps.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start with beat and pattern before trying complicated tunes."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Music Corner?",
          "choices": [
            "A music corner habit is to listen first, practice slowly, and repeat short patterns until they feel steady.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Protect ears, keep volume reasonable, and do not hit objects that can break.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words sound, beat, rhythm, melody matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Music Corner?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Clap a steady beat while saying a short rhyme."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎼 Music Corner Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Steady beat",
      "icon": "🥁",
      "summary": "A steady beat is the even pulse that music can move with.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "drum",
          "paragraphs": [
            "Steady beat teaches this main idea: A steady beat is the even pulse that music can move with.",
            "This belongs in the Music Corner because Beat is the part people tap, march, clap, or sway to, and it helps keep music together.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are beat, pulse, steady, tempo. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use claps, knee taps, drum pad, table taps with fingers, or footsteps.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Tap gently on safe surfaces and stop if the sound bothers anyone.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice slow, medium, and quick beats without speeding up or slowing down.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The beat is like a path. Rhythms can dance over it, but the path should stay steady.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Keep a steady beat for twenty counts while someone else speaks a rhyme.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🥁 Beat Keeper Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Steady beat?",
          "choices": [
            "A steady beat is the even pulse that music can move with.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Steady beat belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Beat is the part people tap, march, clap, or sway to, and it helps keep music together.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Steady beat?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use claps, knee taps, drum pad, table taps with fingers, or footsteps.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice slow, medium, and quick beats without speeding up or slowing down."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Steady beat?",
          "choices": [
            "The beat is like a path. Rhythms can dance over it, but the path should stay steady.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Tap gently on safe surfaces and stop if the sound bothers anyone.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words beat, pulse, steady, tempo matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Steady beat?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Keep a steady beat for twenty counts while someone else speaks a rhyme."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🥁 Beat Keeper Token"
    },
    {
      "studio": "Music Corner",
      "title": "Rhythm patterns",
      "icon": "🎵",
      "summary": "Rhythm is the pattern of long and short sounds over a beat.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "note",
          "paragraphs": [
            "Rhythm patterns teaches this main idea: Rhythm is the pattern of long and short sounds over a beat.",
            "This belongs in the Music Corner because Rhythm gives music movement, surprise, bounce, and shape.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are rhythm, rest, pattern, repeat. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use ta, ti-ti, rest, claps, taps, or simple syllables to build patterns.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not use loud banging to prove rhythm; clear timing matters more than volume.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Create a four-beat rhythm and repeat it three times without losing the beat.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good rhythm can be simple and still interesting if it is steady and clear.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a rhythm using clap, clap, rest, tap, then change one beat.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎵 Rhythm Builder Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Rhythm patterns?",
          "choices": [
            "Rhythm is the pattern of long and short sounds over a beat.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Rhythm patterns belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Rhythm gives music movement, surprise, bounce, and shape.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Rhythm patterns?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use ta, ti-ti, rest, claps, taps, or simple syllables to build patterns.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Create a four-beat rhythm and repeat it three times without losing the beat."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Rhythm patterns?",
          "choices": [
            "A good rhythm can be simple and still interesting if it is steady and clear.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not use loud banging to prove rhythm; clear timing matters more than volume.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words rhythm, rest, pattern, repeat matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Rhythm patterns?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a rhythm using clap, clap, rest, tap, then change one beat."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎵 Rhythm Builder Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Tempo changes",
      "icon": "🐢",
      "summary": "Tempo is the speed of the beat: slow, medium, fast, or changing.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "turtle",
          "paragraphs": [
            "Tempo changes teaches this main idea: Tempo is the speed of the beat: slow, medium, fast, or changing.",
            "This belongs in the Music Corner because Tempo changes the feeling of music and movement because the same rhythm can feel sleepy, steady, or excited.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are tempo, slow, fast, control. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a hand clap or metronome-style counting if available. Try the same pattern at three speeds.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not rush movement games in crowded areas.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Name the tempo before starting so everyone knows the plan.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A performer needs control. Speeding up by accident is different from choosing a faster tempo on purpose.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Perform the same four-beat rhythm slowly, then medium, then quick.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🐢 Tempo Turtle Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Tempo changes?",
          "choices": [
            "Tempo is the speed of the beat: slow, medium, fast, or changing.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Tempo changes belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Tempo changes the feeling of music and movement because the same rhythm can feel sleepy, steady, or excited.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Tempo changes?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a hand clap or metronome-style counting if available. Try the same pattern at three speeds.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Name the tempo before starting so everyone knows the plan."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Tempo changes?",
          "choices": [
            "A performer needs control. Speeding up by accident is different from choosing a faster tempo on purpose.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not rush movement games in crowded areas.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words tempo, slow, fast, control matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Tempo changes?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Perform the same four-beat rhythm slowly, then medium, then quick."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🐢 Tempo Turtle Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Pitch and melody",
      "icon": "🎶",
      "summary": "Pitch means how high or low a sound is, and melody is a shaped line of pitches.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "melody",
          "paragraphs": [
            "Pitch and melody teaches this main idea: Pitch means how high or low a sound is, and melody is a shaped line of pitches.",
            "This belongs in the Music Corner because Melody gives music a tune people can remember, hum, whistle, or sing.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are pitch, melody, high, low. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use voice, a simple keyboard, bells, recorder with approval, or any safe pitched instrument.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep singing comfortable and do not force high notes.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Practice high, middle, and low sounds, then make a three-note melody.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A melody is easier to remember when it has a shape: up, down, repeat, leap, or step.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a tiny melody that goes low-middle-high-middle.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎶 Melody Maker Charm",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Pitch and melody?",
          "choices": [
            "Pitch means how high or low a sound is, and melody is a shaped line of pitches.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Pitch and melody belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Melody gives music a tune people can remember, hum, whistle, or sing.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Pitch and melody?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use voice, a simple keyboard, bells, recorder with approval, or any safe pitched instrument.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Practice high, middle, and low sounds, then make a three-note melody."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Pitch and melody?",
          "choices": [
            "A melody is easier to remember when it has a shape: up, down, repeat, leap, or step.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep singing comfortable and do not force high notes.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words pitch, melody, high, low matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Pitch and melody?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a tiny melody that goes low-middle-high-middle."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎶 Melody Maker Charm"
    },
    {
      "studio": "Music Corner",
      "title": "Dynamics and expression",
      "icon": "📢",
      "summary": "Dynamics describe how loud or soft music is, and expression is how the sound feels.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "volume",
          "paragraphs": [
            "Dynamics and expression teaches this main idea: Dynamics describe how loud or soft music is, and expression is how the sound feels.",
            "This belongs in the Music Corner because Volume changes can make music feel near, far, gentle, bold, secret, or triumphant.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are dynamics, soft, loud, crescendo. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Practice whisper-soft, speaking-level, strong but not shouting, and gradual louder or softer.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Protect ears and avoid sudden loud sounds near anyone.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Use dynamics to match a story moment or movement.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Expression is not random drama. It is sound chosen to fit the musical idea.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Perform a rhythm that starts soft and slowly grows stronger.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📢 Dynamic Sound Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Dynamics and expression?",
          "choices": [
            "Dynamics describe how loud or soft music is, and expression is how the sound feels.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Dynamics and expression belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Volume changes can make music feel near, far, gentle, bold, secret, or triumphant.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Dynamics and expression?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Practice whisper-soft, speaking-level, strong but not shouting, and gradual louder or softer.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Use dynamics to match a story moment or movement."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Dynamics and expression?",
          "choices": [
            "Expression is not random drama. It is sound chosen to fit the musical idea.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Protect ears and avoid sudden loud sounds near anyone.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words dynamics, soft, loud, crescendo matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Dynamics and expression?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Perform a rhythm that starts soft and slowly grows stronger."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📢 Dynamic Sound Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Instrument families",
      "icon": "🎻",
      "summary": "Instrument families group sounds by how they are made: strings, winds, brass, percussion, and keyboards.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "violin",
          "paragraphs": [
            "Instrument families teaches this main idea: Instrument families group sounds by how they are made: strings, winds, brass, percussion, and keyboards.",
            "This belongs in the Music Corner because Families help listeners identify tone color and understand why instruments sound different.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are instrument family, string, wind, percussion. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Listen for plucked strings, blown air, buzzing lips, struck surfaces, or keys controlling hammers or air.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use real instruments carefully and put them away after practice.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Sort instrument pictures or names into families and explain one reason for each choice.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The same melody can feel different when a new instrument family plays it.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Name five instruments and sort them by how they make sound.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎻 Instrument Family Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Instrument families?",
          "choices": [
            "Instrument families group sounds by how they are made: strings, winds, brass, percussion, and keyboards.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Instrument families belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Families help listeners identify tone color and understand why instruments sound different.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Instrument families?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Listen for plucked strings, blown air, buzzing lips, struck surfaces, or keys controlling hammers or air.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Sort instrument pictures or names into families and explain one reason for each choice."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Instrument families?",
          "choices": [
            "The same melody can feel different when a new instrument family plays it.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use real instruments carefully and put them away after practice.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words instrument family, string, wind, percussion matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Instrument families?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Name five instruments and sort them by how they make sound."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎻 Instrument Family Token"
    },
    {
      "studio": "Music Corner",
      "title": "Sound effects for stories",
      "icon": "🌧️",
      "summary": "Sound effects use noise, rhythm, objects, or voice to suggest action, weather, place, or mood.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "rain",
          "paragraphs": [
            "Sound effects for stories teaches this main idea: Sound effects use noise, rhythm, objects, or voice to suggest action, weather, place, or mood.",
            "This belongs in the Music Corner because Stories become more vivid when the sound matches the scene without covering the words.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are sound effect, cue, mood, scene. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use soft tapping for rain, paper rustle for leaves, low hum for wind, or gentle drum for footsteps.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not use glass, sharp objects, or loud crashes for effects.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Plan where each sound happens so it helps the story rather than interrupting it.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The best sound effect is recognizable and controlled. It should support the scene.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create safe sound effects for rain, a door, footsteps, and a tiny bell.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🌧️ Sound Effects Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Sound effects for stories?",
          "choices": [
            "Sound effects use noise, rhythm, objects, or voice to suggest action, weather, place, or mood.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Sound effects for stories belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Stories become more vivid when the sound matches the scene without covering the words.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Sound effects for stories?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use soft tapping for rain, paper rustle for leaves, low hum for wind, or gentle drum for footsteps.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Plan where each sound happens so it helps the story rather than interrupting it."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Sound effects for stories?",
          "choices": [
            "The best sound effect is recognizable and controlled. It should support the scene.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not use glass, sharp objects, or loud crashes for effects.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words sound effect, cue, mood, scene matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Sound effects for stories?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create safe sound effects for rain, a door, footsteps, and a tiny bell."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🌧️ Sound Effects Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Listening maps",
      "icon": "🗺️",
      "summary": "A listening map is a visual guide that shows what happens in music over time.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "map",
          "paragraphs": [
            "Listening maps teaches this main idea: A listening map is a visual guide that shows what happens in music over time.",
            "This belongs in the Music Corner because Maps help listeners follow repeated sections, loud and soft parts, instrument changes, or melody movement.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are listening map, section, repeat, change. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use arrows, shapes, colors, and labels while listening to a short piece.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep music volume comfortable so listening stays clear.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Mark when the music repeats, changes, gets louder, or introduces a new sound.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A listening map turns hearing into noticing. It helps the listener remember structure.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a map for a short song using symbols instead of sentences.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🗺️ Listening Map Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Listening maps?",
          "choices": [
            "A listening map is a visual guide that shows what happens in music over time.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Listening maps belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Maps help listeners follow repeated sections, loud and soft parts, instrument changes, or melody movement.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Listening maps?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use arrows, shapes, colors, and labels while listening to a short piece.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Mark when the music repeats, changes, gets louder, or introduces a new sound."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Listening maps?",
          "choices": [
            "A listening map turns hearing into noticing. It helps the listener remember structure.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep music volume comfortable so listening stays clear.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words listening map, section, repeat, change matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Listening maps?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a map for a short song using symbols instead of sentences."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🗺️ Listening Map Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Simple composition",
      "icon": "📝",
      "summary": "Composition means creating music by choosing sounds, rhythm, order, and expression.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "pencilmusic",
          "paragraphs": [
            "Simple composition teaches this main idea: Composition means creating music by choosing sounds, rhythm, order, and expression.",
            "This belongs in the Music Corner because A tiny composition can be made from claps, voice, instruments, or sound effects.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are composition, pattern, order, ending. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose a beat, make two rhythm patterns, decide the order, and add a beginning and ending.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep instruments and voices at a safe volume and respect quiet times.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Write the plan with simple symbols so it can be repeated later.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Composition is not only for experts. It begins when a maker chooses and organizes sound on purpose.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Compose an eight-beat piece using clap, tap, rest, and one soft sound.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📝 Young Composer Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Simple composition?",
          "choices": [
            "Composition means creating music by choosing sounds, rhythm, order, and expression.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Simple composition belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A tiny composition can be made from claps, voice, instruments, or sound effects.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Simple composition?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose a beat, make two rhythm patterns, decide the order, and add a beginning and ending.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Write the plan with simple symbols so it can be repeated later."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Simple composition?",
          "choices": [
            "Composition is not only for experts. It begins when a maker chooses and organizes sound on purpose.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep instruments and voices at a safe volume and respect quiet times.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words composition, pattern, order, ending matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Simple composition?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Compose an eight-beat piece using clap, tap, rest, and one soft sound."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📝 Young Composer Badge"
    },
    {
      "studio": "Music Corner",
      "title": "Music and movement",
      "icon": "🕺",
      "summary": "Music and movement connect beat, space, direction, speed, and expression.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "dance",
          "paragraphs": [
            "Music and movement teaches this main idea: Music and movement connect beat, space, direction, speed, and expression.",
            "This belongs in the Music Corner because Movement helps the body feel rhythm and helps performers show musical changes.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are movement, beat, gesture, space. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use safe gestures, steps in place, claps, turns, or scarf movement if there is room.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Clear the floor and avoid spinning near furniture or people.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Match movement to beat, tempo, dynamics, or sections of the music.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The goal is not wild motion. It is controlled movement that shows listening.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make four motions for a four-part listening map.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🕺 Movement Ribbon",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Music and movement?",
          "choices": [
            "Music and movement connect beat, space, direction, speed, and expression.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Music and movement belong in the Music Corner?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Movement helps the body feel rhythm and helps performers show musical changes.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Music and movement?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use safe gestures, steps in place, claps, turns, or scarf movement if there is room.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Match movement to beat, tempo, dynamics, or sections of the music."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Music and movement?",
          "choices": [
            "The goal is not wild motion. It is controlled movement that shows listening.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Clear the floor and avoid spinning near furniture or people.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words movement, beat, gesture, space matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Music and movement?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make four motions for a four-part listening map."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🕺 Movement Ribbon"
    },
    {
      "studio": "Story Maker Room",
      "title": "Welcome to the Story Maker Room",
      "icon": "📖",
      "summary": "Story making turns characters, settings, problems, choices, and endings into a meaningful sequence.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "book",
          "paragraphs": [
            "Welcome to the Story Maker Room teaches this main idea: Story making turns characters, settings, problems, choices, and endings into a meaningful sequence.",
            "This belongs in the Story Maker Room because Stories can be written, drawn, acted, sung, made with puppets, mapped in comics, or built as game quests.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are character, setting, problem, ending. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use paper, pencil, story cards, character sketches, setting maps, and a simple beginning-middle-end plan.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep stories kid safe and avoid copying someone else’s characters as if they were your own.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start small: one character, one place, one problem, one choice, and one result.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A story maker learns that creativity becomes clearer when the parts are organized.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a five-box story plan about finding a lost tool.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📖 Story Maker Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Story Maker Room?",
          "choices": [
            "Story making turns characters, settings, problems, choices, and endings into a meaningful sequence.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Story Maker Room belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Stories can be written, drawn, acted, sung, made with puppets, mapped in comics, or built as game quests.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Story Maker Room?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use paper, pencil, story cards, character sketches, setting maps, and a simple beginning-middle-end plan.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start small: one character, one place, one problem, one choice, and one result."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Story Maker Room?",
          "choices": [
            "A story maker learns that creativity becomes clearer when the parts are organized.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep stories kid safe and avoid copying someone else’s characters as if they were your own.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words character, setting, problem, ending matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Story Maker Room?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a five-box story plan about finding a lost tool."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📖 Story Maker Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Character design",
      "icon": "🧍",
      "summary": "A character is a person, animal, creature, object, or figure that acts in a story.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "person",
          "paragraphs": [
            "Character design teaches this main idea: A character is a person, animal, creature, object, or figure that acts in a story.",
            "This belongs in the Story Maker Room because Character design combines appearance, wants, habits, strengths, limits, and choices.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are character, trait, goal, clue. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Sketch the character and write three facts: what they want, what they fear, and what they are good at.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep character designs kind and avoid mocking real people.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Give the character one clear visual clue, such as a hat, tool, color, symbol, or posture.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A strong character does not need a long list of traits. The story needs enough to understand choices.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Design a helper character for a creative studio adventure.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧍 Character Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Character design?",
          "choices": [
            "A character is a person, animal, creature, object, or figure that acts in a story.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Character design belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Character design combines appearance, wants, habits, strengths, limits, and choices.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Character design?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Sketch the character and write three facts: what they want, what they fear, and what they are good at.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Give the character one clear visual clue, such as a hat, tool, color, symbol, or posture."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Character design?",
          "choices": [
            "A strong character does not need a long list of traits. The story needs enough to understand choices.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep character designs kind and avoid mocking real people.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words character, trait, goal, clue matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Character design?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Design a helper character for a creative studio adventure."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧍 Character Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Setting design",
      "icon": "🏰",
      "summary": "Setting is where and when a story happens, including place, mood, weather, objects, and rules of the world.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "castle",
          "paragraphs": [
            "Setting design teaches this main idea: Setting is where and when a story happens, including place, mood, weather, objects, and rules of the world.",
            "This belongs in the Story Maker Room because Setting affects what characters can do. A cave, castle, garden, shipwreck, kitchen, or workshop creates different choices.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are setting, place, mood, map. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Draw a setting map with three important places and one object that matters.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep imaginary danger mild and kid safe when designing adventure spaces.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Add sensory details: what can be seen, heard, smelled, touched safely, or noticed in the air.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A setting should not be wallpaper only. It should help shape the action.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a map of a tiny theater, craft cottage, or painter’s garden.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏰 Setting Map Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Setting design?",
          "choices": [
            "Setting is where and when a story happens, including place, mood, weather, objects, and rules of the world.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Setting design belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Setting affects what characters can do. A cave, castle, garden, shipwreck, kitchen, or workshop creates different choices.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Setting design?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Draw a setting map with three important places and one object that matters.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Add sensory details: what can be seen, heard, smelled, touched safely, or noticed in the air."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Setting design?",
          "choices": [
            "A setting should not be wallpaper only. It should help shape the action.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep imaginary danger mild and kid safe when designing adventure spaces.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words setting, place, mood, map matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Setting design?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a map of a tiny theater, craft cottage, or painter’s garden."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏰 Setting Map Token"
    },
    {
      "studio": "Story Maker Room",
      "title": "Beginning, middle, and end",
      "icon": "➡️",
      "summary": "A clear story has a beginning that sets things up, a middle where choices happen, and an end that resolves the main thread.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "arrow",
          "paragraphs": [
            "Beginning, middle, and end teaches this main idea: A clear story has a beginning that sets things up, a middle where choices happen, and an end that resolves the main thread.",
            "This belongs in the Story Maker Room because This structure helps readers or listeners follow what changed.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are beginning, middle, end, sequence. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use three boxes first. In box one, introduce the character and place. In box two, show the problem. In box three, show the result.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not make endings mean or scary for younger listeners; keep the tone safe.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "After the three boxes work, add more details or scenes if needed.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A simple structure does not make a story boring. It gives the imagination a strong path.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Plan a story in three boxes before writing any full sentences.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ➡️ Story Path Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Beginning, middle, and end?",
          "choices": [
            "A clear story has a beginning that sets things up, a middle where choices happen, and an end that resolves the main thread.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Beginning, middle, and end belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "This structure helps readers or listeners follow what changed.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Beginning, middle, and end?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use three boxes first. In box one, introduce the character and place. In box two, show the problem. In box three, show the result.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "After the three boxes work, add more details or scenes if needed."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Beginning, middle, and end?",
          "choices": [
            "A simple structure does not make a story boring. It gives the imagination a strong path.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not make endings mean or scary for younger listeners; keep the tone safe.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words beginning, middle, end, sequence matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Beginning, middle, and end?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Plan a story in three boxes before writing any full sentences."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "➡️ Story Path Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Problem and solution",
      "icon": "🧩",
      "summary": "A story problem gives the character something to face, fix, learn, find, choose, or understand.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "puzzle",
          "paragraphs": [
            "Problem and solution teaches this main idea: A story problem gives the character something to face, fix, learn, find, choose, or understand.",
            "This belongs in the Story Maker Room because Without a problem or goal, a story can feel like random events.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are problem, solution, goal, clue. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose a problem that fits the character and setting, then plan a solution that grows from the character’s choice.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep problems safe and age appropriate; adventure can be exciting without being harsh.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "The solution should not drop from nowhere. It should connect to clues, effort, kindness, skill, or learning.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good story problem does not need to be huge. A missing brush, broken prop, or confusing map can be enough.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Write three possible solutions for one small story problem.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🧩 Problem Solver Story Pin",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Problem and solution?",
          "choices": [
            "A story problem gives the character something to face, fix, learn, find, choose, or understand.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Problem and solution belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Without a problem or goal, a story can feel like random events.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Problem and solution?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose a problem that fits the character and setting, then plan a solution that grows from the character’s choice.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "The solution should not drop from nowhere. It should connect to clues, effort, kindness, skill, or learning."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Problem and solution?",
          "choices": [
            "A good story problem does not need to be huge. A missing brush, broken prop, or confusing map can be enough.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep problems safe and age appropriate; adventure can be exciting without being harsh.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words problem, solution, goal, clue matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Problem and solution?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Write three possible solutions for one small story problem."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🧩 Problem Solver Story Pin"
    },
    {
      "studio": "Story Maker Room",
      "title": "Dialogue that sounds useful",
      "icon": "💬",
      "summary": "Dialogue is what characters say, and strong dialogue reveals information, feeling, choice, or personality.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "speech",
          "paragraphs": [
            "Dialogue that sounds useful teaches this main idea: Dialogue is what characters say, and strong dialogue reveals information, feeling, choice, or personality.",
            "This belongs in the Story Maker Room because Dialogue should not repeat everything the narrator already explained. It should add something.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are dialogue, speaker, line, voice. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use short lines first. Give each character a reason to speak.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep character talk respectful and avoid rude male-female behavior or mean teasing.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Read dialogue out loud to hear whether it sounds stiff, too long, or confusing.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Good dialogue often has a job: ask, warn, joke, explain, disagree kindly, remember, or decide.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Write four lines between a puppet and a painter looking for a lost color.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 💬 Dialogue Bubble Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Dialogue that sounds useful?",
          "choices": [
            "Dialogue is what characters say, and strong dialogue reveals information, feeling, choice, or personality.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Dialogue that sounds useful belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Dialogue should not repeat everything the narrator already explained. It should add something.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Dialogue that sounds useful?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use short lines first. Give each character a reason to speak.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Read dialogue out loud to hear whether it sounds stiff, too long, or confusing."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Dialogue that sounds useful?",
          "choices": [
            "Good dialogue often has a job: ask, warn, joke, explain, disagree kindly, remember, or decide.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep character talk respectful and avoid rude male-female behavior or mean teasing.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words dialogue, speaker, line, voice matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Dialogue that sounds useful?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Write four lines between a puppet and a painter looking for a lost color."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "💬 Dialogue Bubble Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Comic panels",
      "icon": "▦",
      "summary": "Comic panels divide a story into pictured moments that readers follow in order.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "grid",
          "paragraphs": [
            "Comic panels teaches this main idea: Comic panels divide a story into pictured moments that readers follow in order.",
            "This belongs in the Story Maker Room because Panels teach pacing because each box chooses one important moment.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are panel, caption, speech bubble, pacing. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use boxes, speech bubbles, captions, and arrows only when needed.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep words readable and do not cram too many tiny details into each panel.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Start with four panels: setup, problem, attempt, result.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A comic page should guide the eye clearly from one panel to the next.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Draw a four-panel comic about finishing a craft project.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: ▦ Comic Panel Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Comic panels?",
          "choices": [
            "Comic panels divide a story into pictured moments that readers follow in order.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Comic panels belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Panels teach pacing because each box chooses one important moment.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Comic panels?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use boxes, speech bubbles, captions, and arrows only when needed.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Start with four panels: setup, problem, attempt, result."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Comic panels?",
          "choices": [
            "A comic page should guide the eye clearly from one panel to the next.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep words readable and do not cram too many tiny details into each panel.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words panel, caption, speech bubble, pacing matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Comic panels?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Draw a four-panel comic about finishing a craft project."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "▦ Comic Panel Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Storyboards",
      "icon": "🎬",
      "summary": "A storyboard is a series of quick pictures that plans a scene, video, play, comic, or game moment.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "clapper",
          "paragraphs": [
            "Storyboards teaches this main idea: A storyboard is a series of quick pictures that plans a scene, video, play, comic, or game moment.",
            "This belongs in the Story Maker Room because Storyboards help makers test order before creating the final version.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are storyboard, scene, view, order. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use rough sketches, arrows, notes about sound or movement, and short captions.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep action scenes gentle and safe; focus on movement, mystery, or humor.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Focus on camera view or audience view: close, far, left, right, above, or behind.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A storyboard does not need polished art. It needs clear planning.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Storyboard a puppet entering a room, finding a clue, and making a choice.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🎬 Storyboard Slate Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Storyboards?",
          "choices": [
            "A storyboard is a series of quick pictures that plans a scene, video, play, comic, or game moment.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Storyboards belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Storyboards help makers test order before creating the final version.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Storyboards?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use rough sketches, arrows, notes about sound or movement, and short captions.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Focus on camera view or audience view: close, far, left, right, above, or behind."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Storyboards?",
          "choices": [
            "A storyboard does not need polished art. It needs clear planning.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep action scenes gentle and safe; focus on movement, mystery, or humor.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words storyboard, scene, view, order matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Storyboards?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Storyboard a puppet entering a room, finding a clue, and making a choice."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🎬 Storyboard Slate Token"
    },
    {
      "studio": "Story Maker Room",
      "title": "Captions and labels",
      "icon": "🏷️",
      "summary": "Captions and labels help readers understand pictures, diagrams, maps, and comics.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "label",
          "paragraphs": [
            "Captions and labels teaches this main idea: Captions and labels help readers understand pictures, diagrams, maps, and comics.",
            "This belongs in the Story Maker Room because A caption can explain time, place, action, thought, or a detail that the picture cannot show alone.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are caption, label, title, note. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use short clear words. Place captions where they do not cover important art.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Write neatly and leave enough space around words.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Write labels for maps, inventions, costume parts, or character tools.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A caption should help, not repeat what is already obvious.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Add helpful labels to a drawing of a stage or studio.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏷️ Label Maker Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Captions and labels?",
          "choices": [
            "Captions and labels help readers understand pictures, diagrams, maps, and comics.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Captions and labels belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A caption can explain time, place, action, thought, or a detail that the picture cannot show alone.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Captions and labels?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use short clear words. Place captions where they do not cover important art.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Write labels for maps, inventions, costume parts, or character tools."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Captions and labels?",
          "choices": [
            "A caption should help, not repeat what is already obvious.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Write neatly and leave enough space around words.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words caption, label, title, note matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Captions and labels?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Add helpful labels to a drawing of a stage or studio."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏷️ Label Maker Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Quest writing",
      "icon": "🗺️",
      "summary": "A quest is a story task with a goal, path, obstacle, helper, and reward.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "questmap",
          "paragraphs": [
            "Quest writing teaches this main idea: A quest is a story task with a goal, path, obstacle, helper, and reward.",
            "This belongs in the Story Maker Room because Quest writing works well for games because it turns learning or exploration into a purposeful journey.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are quest, goal, helper, reward. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Plan who gives the quest, what is needed, where to go, what problem appears, and what is earned.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep quests message-free and kid safe, with practical or imaginative goals.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "A good quest reward should connect to the task instead of feeling random.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The best quests are clear enough to follow but interesting enough to remember.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Write a quest where a gallery keeper needs help finding missing labels.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🗺️ Quest Writer Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Quest writing?",
          "choices": [
            "A quest is a story task with a goal, path, obstacle, helper, and reward.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Quest writing belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Quest writing works well for games because it turns learning or exploration into a purposeful journey.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Quest writing?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Plan who gives the quest, what is needed, where to go, what problem appears, and what is earned.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "A good quest reward should connect to the task instead of feeling random."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Quest writing?",
          "choices": [
            "The best quests are clear enough to follow but interesting enough to remember.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep quests message-free and kid safe, with practical or imaginative goals.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words quest, goal, helper, reward matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Quest writing?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Write a quest where a gallery keeper needs help finding missing labels."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🗺️ Quest Writer Badge"
    },
    {
      "studio": "Story Maker Room",
      "title": "Revision for stories",
      "icon": "🔁",
      "summary": "Story revision means improving order, clarity, details, dialogue, or ending after the first draft.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "loop",
          "paragraphs": [
            "Revision for stories teaches this main idea: Story revision means improving order, clarity, details, dialogue, or ending after the first draft.",
            "This belongs in the Story Maker Room because First drafts are allowed to be rough because they help the maker discover the story.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are revision, draft, clarity, ending. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Review one thing at a time: beginning, problem, character choice, ending, or confusing spot.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use kind notes and do not tear up early drafts in frustration.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Read the story aloud and mark places where the listener might get lost.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "Revision is where a story becomes easier to follow and more satisfying.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Choose one old story idea and improve only the ending.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🔁 Story Revision Ribbon",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Revision for stories?",
          "choices": [
            "Story revision means improving order, clarity, details, dialogue, or ending after the first draft.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Revision for stories belong in the Story Maker Room?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "First drafts are allowed to be rough because they help the maker discover the story.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Revision for stories?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Review one thing at a time: beginning, problem, character choice, ending, or confusing spot.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Read the story aloud and mark places where the listener might get lost."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Revision for stories?",
          "choices": [
            "Revision is where a story becomes easier to follow and more satisfying.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use kind notes and do not tear up early drafts in frustration.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words revision, draft, clarity, ending matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Revision for stories?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Choose one old story idea and improve only the ending."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🔁 Story Revision Ribbon"
    },
    {
      "studio": "Mini Gallery",
      "title": "Welcome to the Mini Gallery",
      "icon": "🖼️",
      "summary": "A mini gallery is a place to choose, arrange, label, and reflect on finished creative work.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "frame",
          "paragraphs": [
            "Welcome to the Mini Gallery teaches this main idea: A mini gallery is a place to choose, arrange, label, and reflect on finished creative work.",
            "This belongs in the Mini Gallery because Display teaches decision making because not every piece needs to be shown in the same way.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are gallery, display, portfolio, reflect. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a folder, wall space with permission, binder, digital-safe photo folder, or box for small crafts.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Ask permission before hanging anything and use safe tape or display methods.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Pick work that shows effort, progress, variety, or a favorite skill.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A gallery is not just showing off. It is a record of practice and growth.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Choose three pieces and decide why each one belongs in a mini gallery.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🖼️ Mini Gallery Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Welcome to the Mini Gallery?",
          "choices": [
            "A mini gallery is a place to choose, arrange, label, and reflect on finished creative work.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Welcome to the Mini Gallery belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Display teaches decision making because not every piece needs to be shown in the same way.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Welcome to the Mini Gallery?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a folder, wall space with permission, binder, digital-safe photo folder, or box for small crafts.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Pick work that shows effort, progress, variety, or a favorite skill."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Welcome to the Mini Gallery?",
          "choices": [
            "A gallery is not just showing off. It is a record of practice and growth.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Ask permission before hanging anything and use safe tape or display methods.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words gallery, display, portfolio, reflect matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Welcome to the Mini Gallery?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Choose three pieces and decide why each one belongs in a mini gallery."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🖼️ Mini Gallery Badge"
    },
    {
      "studio": "Mini Gallery",
      "title": "Choosing work for a portfolio",
      "icon": "📁",
      "summary": "A portfolio is a collection of work that shows progress, skill, experiments, and finished pieces.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "folder",
          "paragraphs": [
            "Choosing work for a portfolio teaches this main idea: A portfolio is a collection of work that shows progress, skill, experiments, and finished pieces.",
            "This belongs in the Mini Gallery because Portfolios are useful because a maker can look back and see improvement that might be missed day to day.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are portfolio, collection, progress, date. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose a mix: one careful drawing, one colorful piece, one craft, one story plan, and one favorite attempt.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Store flat work where it will not be stepped on, spilled on, or torn.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Write the date and one note about what was learned.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A portfolio should include growth, not only the neatest final work.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Start a folder with five labeled creative pieces.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📁 Portfolio Folder Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Choosing work for a portfolio?",
          "choices": [
            "A portfolio is a collection of work that shows progress, skill, experiments, and finished pieces.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Choosing work for a portfolio belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Portfolios are useful because a maker can look back and see improvement that might be missed day to day.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Choosing work for a portfolio?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose a mix: one careful drawing, one colorful piece, one craft, one story plan, and one favorite attempt.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Write the date and one note about what was learned."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Choosing work for a portfolio?",
          "choices": [
            "A portfolio should include growth, not only the neatest final work.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Store flat work where it will not be stepped on, spilled on, or torn.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words portfolio, collection, progress, date matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Choosing work for a portfolio?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Start a folder with five labeled creative pieces."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📁 Portfolio Folder Token"
    },
    {
      "studio": "Mini Gallery",
      "title": "Simple artist notes",
      "icon": "📝",
      "summary": "An artist note explains what the maker tried, what tools were used, and what part took effort.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "pencil",
          "paragraphs": [
            "Simple artist notes teaches this main idea: An artist note explains what the maker tried, what tools were used, and what part took effort.",
            "This belongs in the Mini Gallery because Notes help the maker think clearly about choices instead of saying only “I like it” or “I messed up.”",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are artist note, tool, choice, next time. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use three sentence starters: I used, I tried, next time I might.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not write mean notes about yourself or someone else. Be truthful and kind.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Keep notes honest and simple. They do not need fancy art words to be useful.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good note turns a project into learning evidence.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Write a three-sentence note for a drawing or craft.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 📝 Artist Note Pencil",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Simple artist notes?",
          "choices": [
            "An artist note explains what the maker tried, what tools were used, and what part took effort.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Simple artist notes belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Notes help the maker think clearly about choices instead of saying only “I like it” or “I messed up.”",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Simple artist notes?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use three sentence starters: I used, I tried, next time I might.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Keep notes honest and simple. They do not need fancy art words to be useful."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Simple artist notes?",
          "choices": [
            "A good note turns a project into learning evidence.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not write mean notes about yourself or someone else. Be truthful and kind.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words artist note, tool, choice, next time matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Simple artist notes?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Write a three-sentence note for a drawing or craft."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "📝 Artist Note Pencil"
    },
    {
      "studio": "Mini Gallery",
      "title": "Kind critique",
      "icon": "💌",
      "summary": "Critique means looking carefully and giving helpful feedback about the work, not attacking the person.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "heartletter",
          "paragraphs": [
            "Kind critique teaches this main idea: Critique means looking carefully and giving helpful feedback about the work, not attacking the person.",
            "This belongs in the Mini Gallery because Kind critique helps a maker see strengths and possible improvements.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are critique, feedback, notice, wonder. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use this pattern: I notice, I like how, I wonder if.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Never use critique to embarrass someone.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Feedback should be specific. “Good job” is kind but not as useful as naming the clear line, strong color, or helpful label.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The goal is improvement and encouragement together.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Give one kind specific comment and one gentle question about a project.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 💌 Kind Critique Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Kind critique?",
          "choices": [
            "Critique means looking carefully and giving helpful feedback about the work, not attacking the person.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Kind critique belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Kind critique helps a maker see strengths and possible improvements.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Kind critique?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use this pattern: I notice, I like how, I wonder if.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Feedback should be specific. “Good job” is kind but not as useful as naming the clear line, strong color, or helpful label."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Kind critique?",
          "choices": [
            "The goal is improvement and encouragement together.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Never use critique to embarrass someone.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words critique, feedback, notice, wonder matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Kind critique?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Give one kind specific comment and one gentle question about a project."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "💌 Kind Critique Badge"
    },
    {
      "studio": "Mini Gallery",
      "title": "Protecting finished work",
      "icon": "🛡️",
      "summary": "Finished work can be damaged by water, bending, sunlight, dust, rough handling, or messy storage.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "shield",
          "paragraphs": [
            "Protecting finished work teaches this main idea: Finished work can be damaged by water, bending, sunlight, dust, rough handling, or messy storage.",
            "This belongs in the Mini Gallery because Care for finished work teaches respect for time, materials, and effort.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are protect, store, dry, handle. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use folders, sleeves, boxes, drying racks, labels, or safe display spots.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep art away from food, drinks, and damp areas.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Let wet projects dry fully before stacking or storing.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A maker who protects work can study it later, give it as a gift, or use it as a record of progress.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a safe storage plan for flat art and small crafts.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🛡️ Art Protector Shield",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Protecting finished work?",
          "choices": [
            "Finished work can be damaged by water, bending, sunlight, dust, rough handling, or messy storage.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Protecting finished work belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Care for finished work teaches respect for time, materials, and effort.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Protecting finished work?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use folders, sleeves, boxes, drying racks, labels, or safe display spots.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Let wet projects dry fully before stacking or storing."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Protecting finished work?",
          "choices": [
            "A maker who protects work can study it later, give it as a gift, or use it as a record of progress.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep art away from food, drinks, and damp areas.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words protect, store, dry, handle matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Protecting finished work?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a safe storage plan for flat art and small crafts."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🛡️ Art Protector Shield"
    },
    {
      "studio": "Mini Gallery",
      "title": "Displaying 3D crafts",
      "icon": "🏺",
      "summary": "Three-dimensional crafts need display choices that consider balance, size, viewing angle, and safety.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "stand",
          "paragraphs": [
            "Displaying 3D crafts teaches this main idea: Three-dimensional crafts need display choices that consider balance, size, viewing angle, and safety.",
            "This belongs in the Mini Gallery because A sculpture, puppet, model, or cardboard build can tip, crush, or hide its best side if displayed carelessly.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are 3D, base, display, balance. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a shelf, tray, stand, labeled base, or small backdrop with permission.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Keep breakable or heavy objects away from edges and younger children.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Turn the object and decide which side should face forward.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good 3D display makes the object easy to see without making it easy to knock over.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Make a simple paper label and base for a small craft.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏺 Display Stand Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Displaying 3D crafts?",
          "choices": [
            "Three-dimensional crafts need display choices that consider balance, size, viewing angle, and safety.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Displaying 3D crafts belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A sculpture, puppet, model, or cardboard build can tip, crush, or hide its best side if displayed carelessly.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Displaying 3D crafts?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a shelf, tray, stand, labeled base, or small backdrop with permission.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Turn the object and decide which side should face forward."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Displaying 3D crafts?",
          "choices": [
            "A good 3D display makes the object easy to see without making it easy to knock over.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Keep breakable or heavy objects away from edges and younger children.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words 3D, base, display, balance matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Displaying 3D crafts?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Make a simple paper label and base for a small craft."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏺 Display Stand Token"
    },
    {
      "studio": "Mini Gallery",
      "title": "Decor choices for a room or game space",
      "icon": "🏡",
      "summary": "Decor choices use color, theme, size, and placement to make a space feel organized and pleasant.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "home",
          "paragraphs": [
            "Decor choices for a room or game space teaches this main idea: Decor choices use color, theme, size, and placement to make a space feel organized and pleasant.",
            "This belongs in the Mini Gallery because Decor does not need to be expensive or trendy. Handmade signs, banners, labels, and small displays can make a room feel cared for.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are decor, theme, placement, organize. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose one theme, one main color idea, and one useful purpose such as labeling, cheering, or organizing.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Do not hang decor near heat, cords, doors, or places where it can fall.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Place decor where it helps the space instead of cluttering walkways or surfaces.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The best decor supports real life. It should be easy to move, clean, or change later.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Design a small handmade sign for a reading nook, craft shelf, or game area.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🏡 Room Decor Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Decor choices for a room or game space?",
          "choices": [
            "Decor choices use color, theme, size, and placement to make a space feel organized and pleasant.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Decor choices for a room or game space belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Decor does not need to be expensive or trendy. Handmade signs, banners, labels, and small displays can make a room feel cared for.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Decor choices for a room or game space?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose one theme, one main color idea, and one useful purpose such as labeling, cheering, or organizing.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Place decor where it helps the space instead of cluttering walkways or surfaces."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Decor choices for a room or game space?",
          "choices": [
            "The best decor supports real life. It should be easy to move, clean, or change later.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Do not hang decor near heat, cords, doors, or places where it can fall.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words decor, theme, placement, organize matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Decor choices for a room or game space?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Design a small handmade sign for a reading nook, craft shelf, or game area."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🏡 Room Decor Badge"
    },
    {
      "studio": "Mini Gallery",
      "title": "Collecting inspiration",
      "icon": "🌟",
      "summary": "Inspiration can come from nature, books, tools, old buildings, animals, patterns, music, and everyday objects.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "star",
          "paragraphs": [
            "Collecting inspiration teaches this main idea: Inspiration can come from nature, books, tools, old buildings, animals, patterns, music, and everyday objects.",
            "This belongs in the Mini Gallery because A maker collects ideas by noticing, sketching, saving safe scraps, or writing quick notes.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are inspiration, reference, swatch, original. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use an inspiration page with tiny drawings, color swatches, words, and shape ideas.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Ask before cutting pictures from books or magazines.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Do not copy a whole work and claim it as your own. Use inspiration to start an original choice.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A good inspiration habit feeds imagination without stealing.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create an inspiration page with five colors, five shapes, and five words.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🌟 Inspiration Star Token",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Collecting inspiration?",
          "choices": [
            "Inspiration can come from nature, books, tools, old buildings, animals, patterns, music, and everyday objects.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Collecting inspiration belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A maker collects ideas by noticing, sketching, saving safe scraps, or writing quick notes.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Collecting inspiration?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use an inspiration page with tiny drawings, color swatches, words, and shape ideas.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Do not copy a whole work and claim it as your own. Use inspiration to start an original choice."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Collecting inspiration?",
          "choices": [
            "A good inspiration habit feeds imagination without stealing.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Ask before cutting pictures from books or magazines.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words inspiration, reference, swatch, original matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Collecting inspiration?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create an inspiration page with five colors, five shapes, and five words."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🌟 Inspiration Star Token"
    },
    {
      "studio": "Mini Gallery",
      "title": "Creative habits that last",
      "icon": "🌱",
      "summary": "Creative growth comes from repeated small habits: looking, planning, practicing, cleaning up, revising, and saving work.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "sprout",
          "paragraphs": [
            "Creative habits that last teaches this main idea: Creative growth comes from repeated small habits: looking, planning, practicing, cleaning up, revising, and saving work.",
            "This belongs in the Mini Gallery because Talent is less useful without patience, and practice is easier when the steps are small enough to repeat.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are habit, practice, growth, maker. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Use a simple rhythm: warm up, make, pause, improve, clean up, save.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Stop before frustration turns careless; a short break can protect both the project and the mood.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Notice one thing that improved, not only what still needs work.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "A maker can build skill over time by returning to the desk, studio, cottage, stage, music corner, story room, and gallery.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Choose one creative habit to practice three times this week.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 🌱 Creative Growth Badge",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Creative habits that last?",
          "choices": [
            "Creative growth comes from repeated small habits: looking, planning, practicing, cleaning up, revising, and saving work.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Creative habits that last belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "Talent is less useful without patience, and practice is easier when the steps are small enough to repeat.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Creative habits that last?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Use a simple rhythm: warm up, make, pause, improve, clean up, save.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Notice one thing that improved, not only what still needs work."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Creative habits that last?",
          "choices": [
            "A maker can build skill over time by returning to the desk, studio, cottage, stage, music corner, story room, and gallery.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Stop before frustration turns careless; a short break can protect both the project and the mood.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words habit, practice, growth, maker matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Creative habits that last?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Choose one creative habit to practice three times this week."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "🌱 Creative Growth Badge"
    },
    {
      "studio": "Mini Gallery",
      "title": "Master Maker challenge",
      "icon": "👑",
      "summary": "The Master Maker challenge combines drawing, color, craft, design, story, sound, and display into one small project.",
      "screens": [
        {
          "heading": "What this studio skill teaches",
          "art": "crown",
          "paragraphs": [
            "Master Maker challenge teaches this main idea: The Master Maker challenge combines drawing, color, craft, design, story, sound, and display into one small project.",
            "This belongs in the Mini Gallery because A final challenge helps connect the studios so they do not feel like separate random activities.",
            "The point is not to make every project look fancy. The point is to learn a real maker habit that can be used again in drawings, crafts, stories, performances, music, display work, or home projects.",
            "Key words for this lesson are master project, process, present, reflect. These words help name what the maker is doing instead of guessing or rushing.",
            "A good creative lesson should leave behind a usable skill, a stronger eye, a cleaner process, or a better way to explain choices.",
            "Read this window first, then move through tools, practice, craftsmanship, and the maker challenge."
          ]
        },
        {
          "heading": "Tools, materials, and setup",
          "art": "tools",
          "paragraphs": [
            "Choose a safe theme, sketch a plan, make one crafted object or picture, add a title, prepare a tiny display, and explain one creative choice.",
            "Setup matters because creative work can get messy, crowded, or confusing when the tools are scattered everywhere.",
            "A simple setup usually works better than a pile of supplies. Choose only what the project needs, place it where it can be reached, and leave room for the work itself.",
            "Safety note: Use only approved materials and keep the workspace safe from start to cleanup.",
            "The setup should also include cleanup. A maker who knows where scraps, caps, water, brushes, paper, or props go can work with less stress.",
            "Before beginning, ask: what tool starts the job, what tool finishes it, and what needs to stay out of the way?"
          ]
        },
        {
          "heading": "Practice steps",
          "art": "practice",
          "paragraphs": [
            "Keep the project small enough to finish well. A tiny finished project teaches more than a huge abandoned one.",
            "Practice works best when the task is small and repeatable. A short focused attempt gives more information than one giant rushed project.",
            "Look for the part that can be checked: Is the line controlled? Is the beat steady? Is the cut clean? Is the label readable? Is the scene clear?",
            "If something goes wrong, do not treat it like the whole project failed. Name the specific part that needs another try.",
            "Creative skill grows through noticing. The maker should be able to say what changed between the first attempt and the next one.",
            "A practice page, scrap test, rehearsal run, or rough sketch is not wasted work. It is how the real project gets better."
          ]
        },
        {
          "heading": "Craftsmanship and creative choice",
          "art": "craft",
          "paragraphs": [
            "The challenge is proof of process: plan, make, revise, present, and reflect.",
            "Craftsmanship means giving attention to the way the work is made. Edges, spacing, pressure, timing, volume, balance, and cleanup all matter.",
            "Creative choice means the maker decides on purpose. The color, prop, line, word, rhythm, shape, or display choice should help the project do its job.",
            "A project can be simple and still show strong craftsmanship. Neat choices, clear focus, and patient finishing often matter more than extra decoration.",
            "This is also where revision belongs. A maker can pause, look again, and improve one part without throwing everything away.",
            "The best question is not “Is it fancy?” The better question is “Does this choice make the work clearer, stronger, safer, or more interesting?”"
          ]
        },
        {
          "heading": "Maker challenge and reflection",
          "art": "challenge",
          "paragraphs": [
            "Maker challenge: Create a mini gallery piece with a title, label, and one sentence about what you learned.",
            "Keep the challenge small enough to finish. A completed tiny project builds more confidence than a huge project that never gets cleaned up or displayed.",
            "After finishing, name one choice you made on purpose. It might be a color, tool, word, sound, shape, line, material, movement, label, or display spot.",
            "Then name one thing you would try differently next time. That turns the project into a lesson instead of only an object.",
            "Mastery reward for this topic: 👑 Master Maker Crown",
            "Save the work, photograph it with permission, or add a note if it shows a useful step in your creative growth."
          ]
        }
      ],
      "quiz": [
        {
          "q": "What is the main lesson of Master Maker challenge?",
          "choices": [
            "The Master Maker challenge combines drawing, color, craft, design, story, sound, and display into one small project.",
            "The main lesson is to add as many decorations as possible.",
            "The main lesson is to rush before the idea changes.",
            "The main lesson is to avoid practice and only show finished work."
          ],
          "a": 0,
          "explain": "The strongest answer names the real creative skill being taught."
        },
        {
          "q": "Why does Master Maker challenge belong in the Mini Gallery?",
          "choices": [
            "It belongs there only because it sounds fancy.",
            "A final challenge helps connect the studios so they do not feel like separate random activities.",
            "It belongs there because every project must use the same tool.",
            "It belongs there because mistakes should be hidden instead of studied."
          ],
          "a": 1,
          "explain": "The studio connection explains how the skill fits a larger creative habit."
        },
        {
          "q": "Which setup idea fits Master Maker challenge?",
          "choices": [
            "Use every supply nearby, even if the project does not need it.",
            "Skip setup and search for tools after the project has already become messy.",
            "Choose a safe theme, sketch a plan, make one crafted object or picture, add a title, prepare a tiny display, and explain one creative choice.",
            "Choose supplies randomly so the project feels more surprising."
          ],
          "a": 2,
          "explain": "Good setup supports safer, calmer, clearer making."
        },
        {
          "q": "What practice habit fits this topic?",
          "choices": [
            "Practice should be skipped because it makes the project less creative.",
            "The first attempt should always be treated as the final version.",
            "Only the neatest finished project matters; rough tests teach nothing.",
            "Keep the project small enough to finish well. A tiny finished project teaches more than a huge abandoned one."
          ],
          "a": 3,
          "explain": "The practice answer shows a repeatable way to build skill."
        },
        {
          "q": "What craftsmanship idea belongs with Master Maker challenge?",
          "choices": [
            "The challenge is proof of process: plan, make, revise, present, and reflect.",
            "Craftsmanship means covering every empty space.",
            "Craftsmanship means never revising a choice.",
            "Craftsmanship means using complicated tools instead of careful choices."
          ],
          "a": 0,
          "explain": "Craftsmanship is about careful, useful decisions."
        },
        {
          "q": "Which safety habit fits this lesson?",
          "choices": [
            "Safety is only needed for big machines, not creative work.",
            "Use only approved materials and keep the workspace safe from start to cleanup.",
            "Tools are safer when left scattered around the work area.",
            "Messy setup is fine as long as the finished project looks interesting."
          ],
          "a": 1,
          "explain": "Creative work still needs safe tools, clear space, and careful cleanup."
        },
        {
          "q": "Why do the words master project, process, present, reflect matter?",
          "choices": [
            "They are fancy words that replace real practice.",
            "They matter only when making expensive artwork.",
            "They help name the skill clearly so the maker can understand, practice, and explain the choice.",
            "They are useful only if the project is displayed in a large gallery."
          ],
          "a": 2,
          "explain": "Vocabulary helps when it is tied to real making."
        },
        {
          "q": "What is the best challenge response for Master Maker challenge?",
          "choices": [
            "Ignore the challenge and only read about the topic.",
            "Make the project much larger than needed so it becomes harder to finish.",
            "Copy someone else exactly and call it original.",
            "Create a mini gallery piece with a title, label, and one sentence about what you learned."
          ],
          "a": 3,
          "explain": "The challenge turns the lesson into active creative practice."
        }
      ],
      "reward": "👑 Master Maker Crown"
    }
  ]
};
var STORAGE='lr65CreativeStudio';
function text(v){return String(v==null?'':v);}
function esc(s){return text(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function byId(id){return document.getElementById(id);}
function activeName(){var s=byId('studentSelect'); return (s&&s.value)||(typeof window.activeChild!=='undefined'?window.activeChild:'Luna');}
function loadStore(){try{return JSON.parse(localStorage.getItem(STORAGE)||'{}');}catch(e){return {};}}
function saveStore(x){try{localStorage.setItem(STORAGE,JSON.stringify(x));}catch(e){}}
function courseState(){var all=loadStore(), child=activeName(); all[child]=all[child]||{topic:0,screen:0,mastered:{},rewards:[],missed:[]}; all[child].mastered=all[child].mastered||{}; all[child].rewards=Array.isArray(all[child].rewards)?all[child].rewards:[]; all[child].missed=Array.isArray(all[child].missed)?all[child].missed:[]; return {all:all, child:all[child]};}
function grantReward(name){try{var child=activeName(); if(window.state){ window.state.materials=window.state.materials||{}; if(!Array.isArray(window.state.materials[child])) window.state.materials[child]=[]; if(window.state.materials[child].indexOf(name)===-1) window.state.materials[child].push(name); window.state.inventory=Array.isArray(window.state.inventory)?window.state.inventory:[]; if(window.state.inventory.indexOf(name)===-1) window.state.inventory.push(name); if(typeof window.save==='function') window.save(); } }catch(e){}}
function fallbackPopup(title,html){var old=byId('creativeFallbackPopup65'); if(old) old.remove(); var root=document.createElement('div'); root.id='creativeFallbackPopup65'; root.innerHTML='<div class="cs65Backdrop"></div><div class="cs65Modal"><div class="cs65ModalHead"><b>'+esc(title)+'</b><button type="button" class="cs65CloseBtn">✕</button></div><div class="cs65ModalBody">'+html+'</div></div>'; document.body.appendChild(root); var btn=root.querySelector('.cs65CloseBtn'); if(btn) btn.onclick=function(){root.remove();};}
function popup(title,html){try{if(typeof window.lrOpenPopup==='function') return window.lrOpenPopup(title,html);}catch(e){} var body=byId('lrPopupBody'), root=byId('lrPopupRoot'), titleEl=byId('lrPopupTitle'); if(body&&root){if(titleEl)titleEl.textContent=title; body.innerHTML=html; root.classList.remove('hidden'); return;} fallbackPopup(title,html);}
function progress(){var s=courseState().child, total=COURSE.topics.length, mastered=Object.keys(s.mastered||{}).filter(function(k){return s.mastered[k];}).length; return {total:total,mastered:mastered,pct:total?Math.round(mastered/total*100):0};}
function bar(){var p=progress(); return '<div class="cs65Bar"><i style="width:'+p.pct+'%"></i></div><small>'+p.mastered+' / '+p.total+' topics mastered · '+p.pct+'%</small>';}
function studios(){var out=[]; COURSE.topics.forEach(function(t){if(out.indexOf(t.studio)<0) out.push(t.studio);}); return out;}
function openTopic(i,scr){var st=courseState(); i=Math.max(0,Math.min(COURSE.topics.length-1,Number(i)||0)); var t=COURSE.topics[i]; scr=Math.max(0,Math.min(t.screens.length-1,Number(scr)||0)); st.child.topic=i; st.child.screen=scr; saveStore(st.all); var sc=t.screens[scr]; var paras=(sc.paragraphs||[]).map(function(p){return '<p>'+esc(p)+'</p>';}).join(''); var html='<div class="cs65Shell"><div class="cs65Hero"><div><h2>'+esc(t.icon+' '+t.title)+'</h2><p><b>'+esc(t.studio)+'</b> · '+esc(t.summary)+'</p>'+bar()+'</div><div class="cs65HeroBtns"><button type="button" onclick="openCreativeStudioCourse()">Course map</button><button type="button" onclick="openCreativeStudioRewards()">Rewards</button><button type="button" onclick="openCreativeStudioReview()">Review missed</button></div></div><div class="cs65Card"><h3>'+esc(sc.heading)+'</h3>'+paras+'</div><div class="cs65Nav"><button type="button" '+(scr<=0?'disabled':'')+' onclick="creativeOpenTopic('+i+','+(scr-1)+')">◀ Previous window</button><button type="button" '+(scr>=t.screens.length-1?'disabled':'')+' onclick="creativeOpenTopic('+i+','+(scr+1)+')">Next window ▶</button><button type="button" class="cs65Primary" onclick="creativeOpenQuiz('+i+')">Take quiz</button></div></div>'; popup('🎨 Creative Studio',html);}
function openQuiz(i){var t=COURSE.topics[i]; if(!t)return; var html='<div class="cs65Shell"><div class="cs65Hero"><div><h2>'+esc(t.icon+' Quiz: '+t.title)+'</h2><p>This checks the actual maker skill, setup, safety, and creative choice from the lesson.</p></div></div>'+(t.quiz||[]).map(function(q,qi){return '<div class="cs65Question"><b>Question '+(qi+1)+':</b> '+esc(q.q)+'<div class="cs65Choices">'+(q.choices||[]).map(function(c,ci){return '<label><input type="radio" name="cs65q_'+qi+'" value="'+ci+'"> '+esc(c)+'</label>';}).join('')+'</div></div>';}).join('')+'<div class="cs65Nav"><button type="button" onclick="creativeOpenTopic('+i+',0)">Review lesson</button><button type="button" class="cs65Primary" onclick="creativeCheckQuiz('+i+')">Check quiz</button></div></div>'; popup('Creative Studio Quiz',html);}
function checkQuiz(i){var t=COURSE.topics[i], qs=t.quiz||[], score=0, missed=[]; qs.forEach(function(q,qi){var el=document.querySelector('input[name="cs65q_'+qi+'"]:checked'); var val=el?Number(el.value):-1; if(val===q.a) score++; else missed.push({topic:i,question:qi,q:q.q,answer:q.choices[q.a],explain:q.explain});}); var st=courseState(); st.child.missed=(st.child.missed||[]).concat(missed).slice(-80); var mastered=score===qs.length; if(mastered){st.child.mastered[i]=true; if(st.child.rewards.indexOf(t.reward)===-1){st.child.rewards.push(t.reward); grantReward(t.reward);}} saveStore(st.all); var msg=mastered?'<h2>🏆 Creative mastery!</h2><p>You earned: <b>'+esc(t.reward)+'</b></p>':'<h2>🔁 '+score+' / '+qs.length+'</h2><p>Good try. Review the lesson windows and come back for mastery.</p>'; var review=missed.slice(0,4).map(function(m){return '<li><b>'+esc(m.answer)+'</b><br><small>'+esc(m.explain||'Review the lesson.')+'</small></li>';}).join(''); popup('Creative Studio Result','<div class="cs65Shell"><div class="cs65Card">'+msg+(review?'<h3>Review notes</h3><ul>'+review+'</ul>':'')+'</div><div class="cs65Nav"><button type="button" onclick="creativeOpenTopic('+i+',0)">Review topic</button><button type="button" onclick="openCreativeStudioCourse()">Course map</button><button type="button" class="cs65Primary" onclick="creativeOpenTopic('+(Math.min(COURSE.topics.length-1,i+1))+',0)">Next topic</button></div></div>');}
window.creativeOpenTopic=openTopic; window.creativeOpenQuiz=openQuiz; window.creativeCheckQuiz=checkQuiz;
window.openCreativeStudioByStudio=function(i){var arr=studios(); return window.openCreativeStudioCourse(arr[Number(i)]||null);};
window.openCreativeStudioCourse=function(filter){var s=courseState().child; var studioList=studios(); var menu=studioList.map(function(studio,si){return '<button type="button" onclick="openCreativeStudioByStudio('+si+')">'+esc(studio)+'</button>';}).join(''); var shown=COURSE.topics.map(function(t,i){return {t:t,i:i};}).filter(function(x){return !filter || x.t.studio===filter;}); var cards=shown.map(function(x){var t=x.t, i=x.i, done=s.mastered&&s.mastered[i]; return '<div class="cs65Topic '+(done?'done':'')+'"><b>'+esc(t.icon+' '+(i+1)+'. '+t.title)+'</b><p><small>'+esc(t.studio)+'</small><br>'+esc(t.summary)+'</p><small>Reward: '+esc(t.reward)+'</small><button type="button" onclick="creativeOpenTopic('+i+',0)">'+(done?'Review':'Begin')+'</button></div>';}).join(''); popup('🎨 Creative Studio Specialists','<div class="cs65Shell"><div class="cs65Hero"><div><h2>🎨 '+esc(COURSE.label)+'</h2><p>'+esc(COURSE.summary)+'</p>'+bar()+'</div><div class="cs65HeroBtns"><button type="button" class="cs65Primary" onclick="creativeOpenTopic('+(s.topic||0)+','+(s.screen||0)+')">Continue</button><button type="button" onclick="openCreativeStudioRewards()">Reward catalog</button><button type="button" onclick="openCreativeStudioReview()">Review missed</button></div></div><div class="cs65StudioMenu"><button type="button" onclick="openCreativeStudioCourse()">All studios</button>'+menu+'</div><div class="cs65Grid">'+cards+'</div></div>');};
window.openCreativeStudioRewards=function(){var s=courseState().child, earned=s.rewards||[]; var chips=COURSE.topics.map(function(t){var got=earned.indexOf(t.reward)>=0; return '<span class="cs65Reward '+(got?'got':'')+'">'+esc(t.reward)+(got?' ✓':'')+'</span>';}).join(''); popup('🎁 Creative Studio Rewards','<div class="cs65Shell"><div class="cs65Hero"><h2>🎁 Creative Studio Vanity Rewards</h2><p>Every topic earns a themed maker item, badge, charm, title, or studio collectible.</p></div><div class="cs65Rewards">'+chips+'</div></div>');};
window.openCreativeStudioReview=function(){var s=courseState().child, list=s.missed||[]; if(!list.length) return popup('Creative Studio Review','<div class="cs65Shell"><div class="cs65Card"><h2>No missed questions saved yet</h2><p>Missed quiz questions from this creative course will appear here for focused review.</p></div></div>'); var cards=list.slice(-30).reverse().map(function(m){return '<div class="cs65Card"><b>'+esc(COURSE.topics[m.topic]?(COURSE.topics[m.topic].title):'Review topic')+'</b><p>'+esc(m.q)+'</p><p><b>Best answer:</b> '+esc(m.answer)+'</p><small>'+esc(m.explain||'Review the lesson.')+'</small><button type="button" onclick="creativeOpenTopic('+m.topic+',0)">Review lesson</button></div>';}).join(''); popup('Creative Studio Review','<div class="cs65Shell"><div class="cs65Hero"><h2>🔁 Creative Studio Review</h2><p>These are missed questions saved from the course.</p></div><div class="cs65Grid">'+cards+'</div></div>');};
function addLauncher(){try{if(typeof window.openCreativeStudioCourse!=='function')return; var body=byId('lrPopupBody')||byId('actionText')||document.querySelector('.lrPopupBody'); if(!body)return; var existing=[].slice.call(body.querySelectorAll('[data-lr65-creative-row]')); if(existing.length){existing.slice(1).forEach(function(e){e.style.display='none';}); return;} var row=document.createElement('div'); row.className='cs65Launcher'; row.setAttribute('data-lr65-creative-row','1'); row.innerHTML='<div class="cs65LauncherTitle">🎨 Creative Studio Specialists</div><small>Drawing, painting, craft cottage, pattern design, theater, music, story making, mini gallery habits, and themed maker rewards.</small><button type="button" onclick="openCreativeStudioCourse()">🎨 Open Creative Studio Course<span>Hands-on creative lessons with safe tools, practice steps, and maker challenges.</span></button><button type="button" class="secondary" onclick="openCreativeStudioRewards()">🎁 View creative reward catalog<span>Shows aprons, brushes, badges, charms, gallery pieces, stage items, and more.</span></button>'; var inv=body.querySelector('[data-lr64a-inventions-row],[data-lr64-inventions-row]'); if(inv && inv.nextSibling) body.insertBefore(row, inv.nextSibling); else if(inv) body.appendChild(row); else if(body.firstChild) body.insertBefore(row,body.firstChild); else body.appendChild(row);}catch(e){console.warn('LR65 creative launcher failed',e);}}
function wrapChooser(name){try{if(typeof window[name]!=='function'||window[name].__lr65CreativeWrapped)return; var old=window[name]; var repl=function(){var out=old.apply(this,arguments); [60,160,350,800].forEach(function(ms){setTimeout(run,ms);}); return out;}; repl.__lr65CreativeWrapped=true; window[name]=repl; try{eval(name+'=window[name]');}catch(e){}}catch(e){}}
function installRoute(){if(typeof window.startLesson==='function' && !window.__LR65_CREATIVE_START_WRAP__){window.__LR65_CREATIVE_START_WRAP__=true; var old=window.startLesson; window.startLesson=function(){try{var r=(typeof room==='function')?room():null; var key=r?[r.subject,r.realm,r.id,r.title,r.zone].join(' '):''; if(/art|paint|drawing|craft|music|theater|story|creative|gallery|pattern/i.test(key)) return window.openCreativeStudioCourse();}catch(e){} return old.apply(this,arguments);}; try{startLesson=window.startLesson;}catch(e){}}}
function addStyles(){if(byId('creativeStudioStyles65'))return; var st=document.createElement('style'); st.id='creativeStudioStyles65'; st.textContent='.cs65Shell{font-family:inherit;color:#23313b!important}.cs65Shell p,.cs65Shell small,.cs65Shell b,.cs65Shell h2,.cs65Shell h3,.cs65Shell label{color:#23313b!important}.cs65Hero{display:grid;grid-template-columns:1.35fr .65fr;gap:14px;padding:16px;margin-bottom:14px;border-radius:18px;background:linear-gradient(135deg,#fff0d6,#f2eaff,#e9fbff);border:2px solid rgba(98,64,126,.22)}.cs65Hero h2{margin:.1rem 0 .4rem}.cs65HeroBtns{display:flex;flex-direction:column;gap:8px}.cs65HeroBtns button,.cs65Nav button,.cs65Topic button,.cs65StudioMenu button{border:1px solid rgba(71,62,91,.25);border-radius:12px;background:#fffdf8;padding:9px 11px;font-weight:850;cursor:pointer}.cs65Primary{background:#6f3fa0!important;border-color:#4e2479!important;color:#fff!important}.cs65Bar{height:10px;border-radius:99px;background:#ded7e8;overflow:hidden;margin:8px 0}.cs65Bar i{display:block;height:100%;background:#8a55b5}.cs65Card,.cs65Question,.cs65Topic{background:#fffdf8;border:1px solid rgba(71,62,91,.18);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 4px 12px rgba(0,0,0,.06)}.cs65Card p{line-height:1.55}.cs65Grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px}.cs65Topic.done{background:#f3fff2}.cs65Topic p{font-size:.92rem}.cs65Nav{display:flex;gap:9px;flex-wrap:wrap;margin-top:12px}.cs65Nav button[disabled]{opacity:.45;cursor:not-allowed}.cs65Choices{display:grid;gap:7px;margin-top:8px}.cs65Choices label{display:block;padding:8px 10px;border-radius:10px;background:#f8f6fb;border:1px solid rgba(71,62,91,.16)}.cs65Rewards{display:flex;flex-wrap:wrap;gap:8px}.cs65Reward{display:inline-block;padding:7px 10px;border-radius:999px;border:1px solid rgba(73,82,93,.22);background:#f1f3f4}.cs65Reward.got{background:#f2dcff;border-color:#7b46a7;font-weight:800}.cs65StudioMenu{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 14px 0}.cs65Launcher{display:block;margin:0 0 14px 0;padding:14px;border-radius:16px;background:linear-gradient(135deg,#3a2154,#70458b)!important;border:2px solid rgba(255,233,180,.72)!important;box-shadow:0 10px 24px rgba(0,0,0,.20)!important;color:#fff!important}.cs65Launcher *{color:#fff!important}.cs65LauncherTitle{font-weight:900;font-size:1.08rem;margin-bottom:8px}.cs65Launcher small{display:block;opacity:.95;font-weight:600;line-height:1.35;margin-top:4px}.cs65Launcher button{width:100%;text-align:left;margin-top:8px;border:1px solid rgba(255,232,170,.9)!important;background:#fff7d8!important;color:#22172f!important;border-radius:14px;padding:12px 14px;font-weight:900;cursor:pointer}.cs65Launcher button *,.cs65Launcher button span{color:#22172f!important}.cs65Launcher button span{display:block;font-weight:600;font-size:.88rem;margin-top:4px}.cs65Launcher button.secondary{background:#efeaff!important}#creativeFallbackPopup65{position:fixed;inset:0;z-index:99999}.cs65Backdrop{position:absolute;inset:0;background:rgba(0,0,0,.42)}.cs65Modal{position:relative;margin:4vh auto;padding:0;background:#fffdf8;width:min(980px,92vw);max-height:88vh;overflow:auto;border-radius:18px;box-shadow:0 25px 70px rgba(0,0,0,.4)}.cs65ModalHead{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid #ddd;background:#f2e5ff}.cs65ModalHead button{border:0;background:#fff;border-radius:8px;padding:5px 9px;cursor:pointer}@media(max-width:760px){.cs65Hero{grid-template-columns:1fr}}'; document.head.appendChild(st);}
function run(){addStyles(); wrapChooser('lr19OpenLearningChooser'); wrapChooser('lr18OpenLearningChooser'); wrapChooser('lr16OpenLearningChooser'); installRoute(); var body=byId('lrPopupBody'); var root=byId('lrPopupRoot'); var popupLooksOpen=body && body.innerHTML && (!root || !root.classList.contains('hidden')); var actionTitle=byId('actionTitle'); var actionLooksLearning=actionTitle && /learn|lesson|curriculum|subject|course/i.test(actionTitle.textContent||''); if(popupLooksOpen || actionLooksLearning) addLauncher();}
window.lr65CreativeHealthCheck=function(){return {courseLoaded:typeof window.openCreativeStudioCourse==='function', topicCount:COURSE.topics.length, popupLauncherPresent:!!document.querySelector('[data-lr65-creative-row]'), notes:'Creative Studio 6.5 is loaded when courseLoaded is true.'};};
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',function(){run(); [100,400,1000,2000].forEach(function(ms){setTimeout(run,ms);});}); else {run(); [100,400,1000,2000].forEach(function(ms){setTimeout(run,ms);});}
window.addEventListener('load',function(){run(); setTimeout(run,500); setTimeout(run,1500);});
})();
