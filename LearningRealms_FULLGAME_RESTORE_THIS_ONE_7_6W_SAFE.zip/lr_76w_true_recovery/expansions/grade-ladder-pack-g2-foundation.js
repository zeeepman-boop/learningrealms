// Grade Ladder Pack G2: Grade 2 Foundation
// All children pass through this band after Grade 1 when their cap allows it.
// Tagged with gradeBand:"G2" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG2Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G2",unit:"G2-READ-PHONICS",skill:"long vowel teams",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Vowel teams are two vowels working together to make one sound.",
     workedExample:"In boat, oa makes the long o sound. In rain, ai makes the long a sound.",
     guidedPractice:"Look for two vowels beside each other.",
     q:"Which word has the oa vowel team?",c:["boat","bat","bug"],a:"boat",
     explain:"Boat has oa, which often makes the long o sound."},

    {gradeBand:"G2",unit:"G2-READ-PHONICS",skill:"r-controlled vowels",difficulty:"grade 2",mode:"foundation",
     miniLesson:"When a vowel is followed by r, the r can change the vowel sound.",
     workedExample:"Car, bird, and storm all have r-controlled vowel sounds.",
     guidedPractice:"Look for a vowel followed by r.",
     q:"Which word has an r-controlled vowel?",c:["car","cat","cake"],a:"car",
     explain:"Car has ar, an r-controlled vowel pattern."},

    {gradeBand:"G2",unit:"G2-READ-COMP",skill:"central message",difficulty:"grade 2",mode:"foundation",
     miniLesson:"A story can teach a message or lesson.",
     workedExample:"If a character keeps trying and succeeds, the message may be to never give up.",
     guidedPractice:"Ask what the character learned.",
     q:"A character practices every day and improves. What message fits?",c:["Keep trying.","Sleep all day.","Hide the map."],a:"Keep trying.",
     explain:"The character improves because of practice, so Keep trying fits."},

    {gradeBand:"G2",unit:"G2-READ-COMP",skill:"cause and effect",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Cause tells why something happened. Effect tells what happened because of it.",
     workedExample:"It rained, so the path became muddy. Rain is the cause. Muddy path is the effect.",
     guidedPractice:"Ask what made the event happen.",
     q:"The wind blew hard, so the kite flew away. What was the cause?",c:["wind blew hard","kite flew away","the kite was red"],a:"wind blew hard",
     explain:"The wind made the kite fly away, so it is the cause."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G2",unit:"G2-MATH-PLACE",skill:"place value to 1000",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Three-digit numbers have hundreds, tens, and ones.",
     workedExample:"348 has 3 hundreds, 4 tens, and 8 ones.",
     guidedPractice:"Look at each digit's place.",
     q:"348 has how many hundreds?",c:["3","4","8"],a:"3",
     explain:"The 3 is in the hundreds place."},

    {gradeBand:"G2",unit:"G2-MATH-ADD",skill:"two-digit addition",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Two-digit addition adds tens with tens and ones with ones.",
     workedExample:"34 + 25 = 59 because 30 + 20 = 50 and 4 + 5 = 9.",
     guidedPractice:"Break the numbers into tens and ones.",
     q:"34 + 25 = ?",c:["59","69","49"],a:"59",
     explain:"30 + 20 is 50, and 4 + 5 is 9. Together they make 59."},

    {gradeBand:"G2",unit:"G2-MATH-SUB",skill:"two-digit subtraction",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Two-digit subtraction takes away tens and ones.",
     workedExample:"67 - 24 = 43 because 60 - 20 = 40 and 7 - 4 = 3.",
     guidedPractice:"Subtract tens, then subtract ones.",
     q:"67 - 24 = ?",c:["43","41","53"],a:"43",
     explain:"60 - 20 is 40, and 7 - 4 is 3. Together they make 43."},

    {gradeBand:"G2",unit:"G2-MATH-MEASURE",skill:"money",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Coins can be counted by their values.",
     workedExample:"A quarter is 25 cents, a dime is 10 cents, and a nickel is 5 cents. 25 + 10 + 5 = 40.",
     guidedPractice:"Start with the largest coin and count up.",
     q:"A quarter, dime, and nickel equal...",c:["40 cents","35 cents","30 cents"],a:"40 cents",
     explain:"25 + 10 + 5 = 40 cents."},

    {gradeBand:"G2",unit:"G2-MATH-DATA",skill:"bar graphs",difficulty:"grade 2",mode:"foundation",
     miniLesson:"A bar graph uses bars to show data.",
     workedExample:"If the frog bar reaches 6 and the bird bar reaches 9, birds have more.",
     guidedPractice:"Compare the heights or numbers on the bars.",
     q:"A bar graph shows frogs 6 and birds 9. Which has more?",c:["birds","frogs","same"],a:"birds",
     explain:"9 is more than 6, so birds have more."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G2",unit:"G2-ELA-SENTENCES",skill:"subject and predicate",difficulty:"grade 2",mode:"foundation",
     miniLesson:"A sentence has a subject and a predicate. The subject tells who or what. The predicate tells what happened.",
     workedExample:"The rabbit hopped. The rabbit is the subject. Hopped is what happened.",
     guidedPractice:"Ask who or what the sentence is about.",
     q:"In The dragon slept, what is the subject?",c:["dragon","slept","the"],a:"dragon",
     explain:"Dragon is who the sentence is about."},

    {gradeBand:"G2",unit:"G2-ELA-GRAMMAR",skill:"adjectives and adverbs",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Adjectives describe nouns. Adverbs can describe verbs.",
     workedExample:"In the bright star, bright describes star. In ran quickly, quickly describes ran.",
     guidedPractice:"Find the word that tells more about the noun.",
     q:"In the silver dragon, which word describes dragon?",c:["silver","dragon","the"],a:"silver",
     explain:"Silver describes the dragon."},

    {gradeBand:"G2",unit:"G2-ELA-WRITING",skill:"opinion writing",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Opinion writing tells what you think and gives reasons.",
     workedExample:"I like the dragon mural because it uses bright colors.",
     guidedPractice:"Look for the word because to give a reason.",
     q:"Which sentence gives an opinion with a reason?",c:["I like the mural because it is bright.","The mural is on the wall.","Mural."],a:"I like the mural because it is bright.",
     explain:"It tells an opinion and gives a reason."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G2",unit:"G2-SCI-LIFE",skill:"plant life cycles",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Plants have life cycles. Many begin as seeds, sprout, grow, and make new seeds.",
     workedExample:"A bean seed can sprout into a small plant, then grow leaves and flowers.",
     guidedPractice:"Think about what comes first in a plant life cycle.",
     q:"What often comes first in a plant life cycle?",c:["seed","flower","fruit"],a:"seed",
     explain:"Many plants begin as seeds."},

    {gradeBand:"G2",unit:"G2-SCI-LIFE",skill:"animal habitats",difficulty:"grade 2",mode:"foundation",
     miniLesson:"A habitat is where a living thing gets what it needs.",
     workedExample:"A frog may live near a pond because it needs water and insects.",
     guidedPractice:"Choose the place where the animal can meet its needs.",
     q:"Which habitat fits a frog best?",c:["pond","dry attic","empty shelf"],a:"pond",
     explain:"A pond gives a frog water and food sources."},

    {gradeBand:"G2",unit:"G2-SCI-EARTH",skill:"landforms",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Landforms are natural features of Earth's surface.",
     workedExample:"Mountains, valleys, plains, and hills are landforms.",
     guidedPractice:"Choose the natural land shape.",
     q:"Which is a landform?",c:["mountain","chair","pencil"],a:"mountain",
     explain:"A mountain is a natural landform."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G2",unit:"G2-SS-COMMUNITY",skill:"community roles",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Communities have people with different roles and responsibilities.",
     workedExample:"A mayor helps lead a town. A farmer grows food. A builder builds structures.",
     guidedPractice:"Ask what job the person does for the community.",
     q:"Who helps lead a town?",c:["mayor","cloud","river"],a:"mayor",
     explain:"A mayor is a community leader."},

    {gradeBand:"G2",unit:"G2-SS-GEOGRAPHY",skill:"map features",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Maps often use symbols, labels, and a compass rose.",
     workedExample:"A compass rose shows directions like north, south, east, and west.",
     guidedPractice:"Choose the map tool that shows directions.",
     q:"What shows directions on a map?",c:["compass rose","paragraph","shadow"],a:"compass rose",
     explain:"A compass rose shows directions."},

    {gradeBand:"G2",unit:"G2-SS-ECON",skill:"producers and consumers",difficulty:"grade 2",mode:"foundation",
     miniLesson:"A producer makes or provides goods or services. A consumer uses or buys them.",
     workedExample:"A baker produces bread. A person who buys bread is a consumer.",
     guidedPractice:"Ask who makes and who uses.",
     q:"A baker who makes bread is a...",c:["producer","consumer","map"],a:"producer",
     explain:"A producer makes goods or provides services."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G2",unit:"G2-ART-COLOR",skill:"secondary colors",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Secondary colors can be made by mixing primary colors.",
     workedExample:"Red and yellow make orange. Blue and yellow make green. Red and blue make purple.",
     guidedPractice:"Think about what two colors mix together.",
     q:"Red and yellow make...",c:["orange","green","purple"],a:"orange",
     explain:"Red mixed with yellow makes orange."},

    {gradeBand:"G2",unit:"G2-ART-TEXTURE",skill:"texture",difficulty:"grade 2",mode:"foundation",
     miniLesson:"Texture means how something looks or feels on the surface.",
     workedExample:"Dragon scales might look rough. A cloud might look soft.",
     guidedPractice:"Choose the word that describes surface feel.",
     q:"Texture tells how something might...",c:["feel","count","divide"],a:"feel",
     explain:"Texture is about surface feel or appearance."}
  ]);
}

LR_addG2Foundation("Luna");
LR_addG2Foundation("Ava");
LR_addG2Foundation("Michael");
