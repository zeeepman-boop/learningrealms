// Curriculum Pack 6O Geography Civics Economics
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Geography",[
{teach:"Maps help people find places.",q:"Maps help people...",c:["find places","grow plants","cook"],a:"find places"},
{teach:"A globe shows Earth.",q:"Earth can be shown on a...",c:["globe","clock","ladder"],a:"globe"},
{teach:"Earth has land and water.",q:"Earth has...",c:["land and water","only land","only water"],a:"land and water"},
{teach:"Directions help travel.",q:"Directions help us...",c:["travel","sleep","count"],a:"travel"}
]);

LR_addLessons("Ava","Geography",[
{teach:"Climate affects regions.",q:"Climate affects...",c:["regions","fonts","equations"],a:"regions"},
{teach:"Resources support people.",q:"Resources help meet...",c:["needs","songs","maps only"],a:"needs"},
{teach:"Physical geography includes landforms.",q:"Landforms are part of...",c:["physical geography","economics","writing"],a:"physical geography"},
{teach:"Maps use symbols.",q:"Map symbols show...",c:["information","music","stories"],a:"information"}
]);

LR_addLessons("Michael","Geography",[
{teach:"Population affects communities.",q:"Population affects...",c:["communities","weather only","rocks"],a:"communities"},
{teach:"Trade connects regions.",q:"Trade connects...",c:["regions","chapters","planets"],a:"regions"},
{teach:"Migration changes populations.",q:"Migration changes...",c:["populations","equations","fonts"],a:"populations"},
{teach:"Landforms influence settlement.",q:"Landforms influence...",c:["settlement","titles","songs"],a:"settlement"}
]);

LR_addLessons("Luna","Civics",[
{teach:"Communities have helpers.",q:"Communities have...",c:["helpers","dragons","clouds"],a:"helpers"},
{teach:"Rules help people work together.",q:"Rules help...",c:["work together","hide","sleep"],a:"work together"}
]);

LR_addLessons("Ava","Civics",[
{teach:"Government has levels.",q:"Government can have...",c:["levels","colors","maps"],a:"levels"},
{teach:"Citizens have responsibilities.",q:"Citizens have...",c:["responsibilities","engines","coins"],a:"responsibilities"}
]);

LR_addLessons("Michael","Economics",[
{teach:"Scarcity means limits exist.",q:"Scarcity means...",c:["limits","extra","weather"],a:"limits"},
{teach:"Opportunity cost is choosing one thing over another.",q:"Opportunity cost involves...",c:["choices","maps","titles"],a:"choices"},
{teach:"Production creates goods.",q:"Production creates...",c:["goods","clouds","stories"],a:"goods"},
{teach:"Markets involve exchange.",q:"Markets involve...",c:["exchange","sleep","paint"],a:"exchange"}
]);
})();