// Curriculum Pack 6D-Deep: Logic / Critical Thinking Real Implementation
// Content-only deep expansion. No engine, Home, UI, or save changes.
// Adds broad logic foundations through LR_addLessons() for long-term open expansion.

(function(){
  if (typeof LR_addLessons !== "function") {
    console.warn("LearningRealms: LR_addLessons not found for 6D-Deep Logic.");
    return;
  }

  LR_addLessons("Luna", "Logic", [
    {teach:"Sorting means putting things into groups that belong together.",practice:"Red blocks with red blocks. Round buttons with round buttons. That is sorting.",q:"What does sorting mean?",c:["putting things in groups","throwing everything away","making a loud noise"],a:"putting things in groups"},
    {teach:"A pattern repeats in order.",practice:"Red, blue, red, blue is a pattern because the colors repeat.",q:"Which is a pattern?",c:["red blue red blue","red green yellow purple","cat rock spoon"],a:"red blue red blue"},
    {teach:"Same means alike. Different means not alike.",practice:"Two stars are the same shape. A star and a square are different shapes.",q:"Same means...",c:["alike","broken","hungry"],a:"alike"},
    {teach:"A clue helps you figure something out.",practice:"Wet paw prints are a clue that an animal walked through water.",q:"What helps you figure something out?",c:["a clue","a nap","a cloud"],a:"a clue"},
    {teach:"First, next, and last tell the order things happen.",practice:"First wash hands, next eat, last clean up.",q:"Which word tells what happens at the end?",c:["last","first","round"],a:"last"},
    {teach:"A reason tells why.",practice:"I wore boots because it was muddy. Mud is the reason.",q:"A reason tells...",c:["why","how loud","how tall"],a:"why"},
    {teach:"Compare means noticing how things are alike and different.",practice:"A cat and dog both have fur, but they make different sounds.",q:"Compare means look for...",c:["alike and different","only noise","only color"],a:"alike and different"},
    {teach:"A good guess uses clues.",practice:"Seeing crumbs by the cookie jar helps make a good guess.",q:"A good guess uses...",c:["clues","nothing","noise"],a:"clues"},
    {teach:"A part is one piece of a whole thing.",practice:"A wheel is part of a wagon.",q:"What is one piece of a whole called?",c:["part","storm","song"],a:"part"},
    {teach:"Whole means all together.",practice:"All puzzle pieces together make the whole puzzle.",q:"Whole means...",c:["all together","only one tiny piece","lost"],a:"all together"},
    {teach:"Opposites are very different pairs.",practice:"Hot and cold are opposites.",q:"Which pair is opposites?",c:["hot and cold","big and large","small and tiny"],a:"hot and cold"},
    {teach:"Before means earlier. After means later.",practice:"Put on socks before shoes.",q:"Which word means earlier?",c:["before","after","later"],a:"before"},
    {teach:"Odd one out means the thing that does not belong.",practice:"Apple, banana, carrot. The carrot may be the odd one out because it is not a fruit.",q:"Odd one out means...",c:["does not belong","is always biggest","is always red"],a:"does not belong"},
    {teach:"A sequence is an order.",practice:"Baby, child, adult is a sequence.",q:"A sequence shows...",c:["order","noise","color only"],a:"order"},
    {teach:"Careful thinkers slow down before choosing.",practice:"Looking twice can help you avoid a silly mistake.",q:"What should you do before answering?",c:["think carefully","shout fast","close your eyes"],a:"think carefully"},
    {teach:"If something is missing, look for clues.",practice:"If a mitten is gone, check where mittens belong.",q:"What should you look for?",c:["clues","thunder","paint"],a:"clues"},
    {teach:"A rule helps a pattern make sense.",practice:"The rule might be: add one more block each time.",q:"What helps a pattern make sense?",c:["a rule","a blanket","a bell"],a:"a rule"},
    {teach:"True means correct. False means not correct.",practice:"A fish lives in water is true. A fish is a chair is false.",q:"False means...",c:["not correct","very shiny","super tall"],a:"not correct"},
    {teach:"Some questions need more than a fast answer.",practice:"A riddle may need listening, thinking, and checking clues.",q:"A riddle needs...",c:["thinking","running away","sleeping only"],a:"thinking"},
    {teach:"Details are small things you notice.",practice:"A blue button, a tiny key, or a scratch on a door can be details.",q:"Details are things you...",c:["notice","eat","erase"],a:"notice"}
  ]);

  LR_addLessons("Ava", "Logic", [
    {teach:"Observation means noticing details carefully.",practice:"A careful thinker notices color, shape, size, order, changes, and missing pieces.",q:"Observation means...",c:["noticing details","guessing without looking","copying an answer"],a:"noticing details"},
    {teach:"A cause is why something happens. An effect is what happens after.",practice:"The wind blew, so the leaves moved. Wind is the cause. Moving leaves is the effect.",q:"The effect is...",c:["what happens after","the reason it happened","a random opinion"],a:"what happens after"},
    {teach:"Evidence is information that supports a claim.",practice:"Footprints by the door can be evidence that someone walked there.",q:"What supports a claim?",c:["evidence","a guess","a decoration"],a:"evidence"},
    {teach:"An inference is a thoughtful conclusion based on clues.",practice:"If the floor is wet and an umbrella is by the door, you may infer it rained.",q:"An inference is based on...",c:["clues","nothing","volume"],a:"clues"},
    {teach:"A fact can be checked. An opinion tells what someone thinks or feels.",practice:"The cup is blue can be checked. Blue is the best color is an opinion.",q:"Which can be checked?",c:["fact","opinion","preference"],a:"fact"},
    {teach:"A sequence puts events in order.",practice:"Seed, sprout, plant is a sequence.",q:"What puts events in order?",c:["sequence","bias","guess"],a:"sequence"},
    {teach:"A category is a group with something in common.",practice:"Mammals, reptiles, tools, and foods can all be categories.",q:"A category is...",c:["a group with something in common","a broken pattern","a loud answer"],a:"a group with something in common"},
    {teach:"Compare and contrast means telling how things are alike and different.",practice:"A pencil and pen both write, but one uses lead and one uses ink.",q:"Contrast means finding...",c:["differences","only copies","only numbers"],a:"differences"},
    {teach:"A strong answer explains why it is true.",practice:"Because is a helpful word when giving a reason.",q:"A strong answer should include...",c:["a reason","only yes","nothing else"],a:"a reason"},
    {teach:"A prediction is a thoughtful idea about what may happen next.",practice:"Dark clouds may help you predict rain.",q:"A prediction is about...",c:["what may happen next","what happened last year only","favorite color"],a:"what may happen next"},
    {teach:"Not all evidence is equally useful.",practice:"A direct clue is stronger than an unrelated detail.",q:"Which evidence is usually stronger?",c:["a direct clue","an unrelated detail","a random feeling"],a:"a direct clue"},
    {teach:"A contradiction happens when two ideas cannot both be true in the same way.",practice:"The box is empty and the box is full cannot both be true at the same time.",q:"A contradiction means...",c:["two ideas conflict","two ideas match","two ideas repeat"],a:"two ideas conflict"},
    {teach:"A rule helps decide what belongs in a pattern or group.",practice:"If the rule is even numbers, 2, 4, and 6 belong.",q:"What helps decide what belongs?",c:["a rule","a noise","a guess"],a:"a rule"},
    {teach:"A problem can be solved step by step.",practice:"Read, look for clues, try a plan, then check the answer.",q:"Good problem solving is often...",c:["step by step","random only","only guessing"],a:"step by step"},
    {teach:"Changing your mind can be wise when new evidence appears.",practice:"If better clues show your first idea was wrong, revise your answer.",q:"When new evidence proves you wrong, you should...",c:["revise your answer","ignore it","hide it"],a:"revise your answer"},
    {teach:"An analogy compares relationships.",practice:"Bird is to nest as dog is to doghouse.",q:"Bird is to nest as dog is to...",c:["doghouse","cloud","spoon"],a:"doghouse"},
    {teach:"Relevant means connected to the question.",practice:"If solving who ate the cookie, crumbs are relevant. A cloud outside may not be.",q:"Relevant means...",c:["connected to the question","always loud","not useful"],a:"connected to the question"},
    {teach:"A conclusion should fit the clues.",practice:"If the clues point to rain, sunshine may not be the best conclusion.",q:"A conclusion should fit...",c:["the clues","only your favorite answer","the longest word"],a:"the clues"},
    {teach:"Some answers are possible but not likely.",practice:"A missing pencil may be on the desk. It is possible it flew to the moon, but not likely.",q:"A good thinker asks what is...",c:["most likely","most silly","most sparkly"],a:"most likely"},
    {teach:"A fair test changes one thing at a time.",practice:"To test which plant food works, keep light and water the same.",q:"A fair test changes...",c:["one thing at a time","everything at once","nothing ever"],a:"one thing at a time"},
    {teach:"A hidden assumption is something taken for granted.",practice:"Assuming a closed shop is empty may be wrong if workers are inside.",q:"An assumption is...",c:["taken for granted","proven for sure","always visible"],a:"taken for granted"},
    {teach:"A detail trap is an answer that sounds close but misses a key detail.",practice:"If the clue says red scarf, blue scarf is a detail trap.",q:"A detail trap misses...",c:["a key detail","all letters","every sound"],a:"a key detail"},
    {teach:"Evidence ranking means judging which clues are strongest.",practice:"Seeing the broken vase is stronger than hearing a rumor about it.",q:"Evidence ranking judges...",c:["which clues are strongest","which word is prettiest","which color is brightest"],a:"which clues are strongest"},
    {teach:"Cause and effect chains can have several steps.",practice:"Rain falls, ground softens, tracks appear.",q:"A cause/effect chain has...",c:["several steps","one random answer","no order"],a:"several steps"}
  ]);

  LR_addLessons("Michael", "Logic", [
    {teach:"A valid conclusion follows from the evidence and reasoning given.",practice:"If all squares have four sides and this shape is a square, it must have four sides.",q:"A valid conclusion follows from...",c:["evidence and reasoning","mood only","a random answer"],a:"evidence and reasoning"},
    {teach:"A claim is a statement someone says is true.",practice:"The bridge is unsafe is a claim. It needs evidence before accepting it.",q:"A claim is...",c:["a statement said to be true","proof by itself","a question only"],a:"a statement said to be true"},
    {teach:"Bias is a tendency that can unfairly affect judgment.",practice:"Liking one team can make someone judge a close call unfairly.",q:"Bias can affect...",c:["judgment","gravity","temperature only"],a:"judgment"},
    {teach:"Correlation means two things happen together. It does not always prove one caused the other.",practice:"Ice cream sales and hot days rise together, but ice cream does not cause summer heat.",q:"Correlation alone does not prove...",c:["causation","comparison","counting"],a:"causation"},
    {teach:"An assumption is something accepted without full proof.",practice:"Assuming a quiet person is angry may be wrong without evidence.",q:"An assumption lacks...",c:["full proof","words","any meaning"],a:"full proof"},
    {teach:"A counterexample disproves a broad claim by showing one case where it fails.",practice:"One black swan disproves the claim that all swans are white.",q:"What can disprove a broad claim?",c:["counterexample","repetition","volume"],a:"counterexample"},
    {teach:"A premise is a starting statement used in an argument.",practice:"If the premises are weak, the conclusion may be weak too.",q:"A premise is used as...",c:["a starting statement","a final reward","a decoration"],a:"a starting statement"},
    {teach:"Deductive reasoning moves from a rule to a certain conclusion when the logic is valid.",practice:"All mammals breathe air. Whales are mammals. Therefore whales breathe air.",q:"Deductive reasoning often moves from...",c:["rule to conclusion","feeling to rumor","drawing to music"],a:"rule to conclusion"},
    {teach:"Inductive reasoning uses examples to form a likely general idea.",practice:"Several metal objects expand when heated, so you may infer metals often expand when heated.",q:"Inductive reasoning uses...",c:["examples","guarantees only","no evidence"],a:"examples"},
    {teach:"A logical fallacy is a flaw in reasoning.",practice:"Attacking a person instead of the idea is poor reasoning.",q:"A logical fallacy is...",c:["a flaw in reasoning","a strong proof","a math tool only"],a:"a flaw in reasoning"},
    {teach:"A false dilemma wrongly acts like there are only two choices when more may exist.",practice:"Either we do my plan or we fail ignores other possible plans.",q:"A false dilemma hides...",c:["other options","all evidence","the topic"],a:"other options"},
    {teach:"Circular reasoning repeats the claim instead of proving it.",practice:"This rule is good because it is a good rule does not prove anything.",q:"Circular reasoning mostly...",c:["repeats the claim","adds strong evidence","solves the problem"],a:"repeats the claim"},
    {teach:"A reliable source has reasons to be trusted, but still should be checked.",practice:"Experts, original records, and clear evidence are stronger than anonymous rumors.",q:"A reliable source should be...",c:["checked and supported","believed blindly","ignored always"],a:"checked and supported"},
    {teach:"Ranking evidence means deciding which support is strongest.",practice:"A direct measurement is usually stronger than a vague memory.",q:"Ranking evidence means judging...",c:["strength of support","favorite color","loudest voice"],a:"strength of support"},
    {teach:"Critical thinking is careful, fair thinking that checks claims before accepting them.",practice:"A critical thinker asks: What is the evidence? Is there another explanation?",q:"Critical thinking checks...",c:["claims before accepting them","only easy answers","nothing"],a:"claims before accepting them"},
    {teach:"A straw man fallacy misrepresents someone’s position to make it easier to attack.",practice:"If someone says spend carefully, claiming they hate all spending is a straw man.",q:"A straw man fallacy...",c:["misrepresents a position","uses direct evidence","proves a claim"],a:"misrepresents a position"},
    {teach:"Ad hominem attacks the person instead of the argument.",practice:"Saying an idea is wrong because the speaker is annoying does not address the evidence.",q:"Ad hominem attacks...",c:["the person instead of the argument","the evidence directly","the conclusion with proof"],a:"the person instead of the argument"},
    {teach:"A hasty generalization draws a broad conclusion from too little evidence.",practice:"One rude visitor does not prove all visitors are rude.",q:"A hasty generalization uses...",c:["too little evidence","complete evidence","careful testing"],a:"too little evidence"},
    {teach:"A strong argument has clear premises, relevant evidence, and a conclusion that follows.",practice:"If one piece is missing, the argument may be weaker.",q:"A strong argument needs...",c:["premises, evidence, and a fitting conclusion","only confidence","only a long paragraph"],a:"premises, evidence, and a fitting conclusion"},
    {teach:"Alternative explanations should be considered.",practice:"If a plant wilts, it may need water, but disease, heat, or root damage could also matter.",q:"Critical thinkers consider...",c:["alternative explanations","only the first idea","no other possibilities"],a:"alternative explanations"},
    {teach:"Burden of proof means the person making a claim needs to support it.",practice:"A bold claim should not be accepted merely because nobody disproved it yet.",q:"The burden of proof belongs to...",c:["the person making the claim","the person listening only","no one"],a:"the person making the claim"},
    {teach:"A sound argument is valid and has true premises.",practice:"A valid structure is not enough if the starting facts are false.",q:"A sound argument has valid logic and...",c:["true premises","louder words","more jokes"],a:"true premises"},
    {teach:"Probability thinking compares how likely explanations are.",practice:"A simple common explanation is often more likely than a complicated unlikely one, but evidence still matters.",q:"Probability thinking compares...",c:["how likely explanations are","which answer is longest","which idea is funniest"],a:"how likely explanations are"},
    {teach:"A chain of reasoning connects each step clearly.",practice:"If one link in the reasoning chain breaks, the conclusion may fail.",q:"A reasoning chain needs...",c:["clear connected steps","hidden jumps","only a final answer"],a:"clear connected steps"},
    {teach:"A good critique challenges an idea fairly without twisting it.",practice:"You can disagree strongly while still representing the other side accurately.",q:"A fair critique avoids...",c:["twisting the other side","using evidence","clear reasoning"],a:"twisting the other side"}
  ]);
})();
