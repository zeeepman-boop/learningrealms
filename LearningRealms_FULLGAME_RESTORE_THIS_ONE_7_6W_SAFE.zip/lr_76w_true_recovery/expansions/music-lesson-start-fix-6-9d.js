/* LearningRealms Music Lesson Start Fix 6.9D
   Fixes Music lesson launch so Bardwood / Music rooms use the real Music lesson bank,
   not the Creative Studio Specialists course map.
   No new lessons, rewards, UI shell changes, or route rewrites.
*/
(function(){
  'use strict';
  if(window.__LR69D_MUSIC_LESSON_START_FIX__) return;
  window.__LR69D_MUSIC_LESSON_START_FIX__ = true;

  function byId(id){ return document.getElementById(id); }
  function call(name){ try{ if(typeof window[name] === 'function') return window[name].apply(window, Array.prototype.slice.call(arguments,1)); }catch(e){} try{ if(typeof self[name] === 'function') return self[name].apply(self, Array.prototype.slice.call(arguments,1)); }catch(e){} }
  function getRoom(){ try{ if(typeof room === 'function') return room(); }catch(e){} return null; }
  function getState(){ try{ if(typeof state !== 'undefined' && state) return state; }catch(e){} try{ if(window.state) return window.state; }catch(e){} return null; }
  function getChild(){ try{ if(typeof activeChild !== 'undefined' && activeChild) return activeChild; }catch(e){} try{ if(window.activeChild) return window.activeChild; }catch(e){} var sel=byId('studentSelect'); return (sel && sel.value) || 'Luna'; }
  function getLessonsRoot(){ try{ if(typeof LESSONS !== 'undefined' && LESSONS) return LESSONS; }catch(e){} return window.LR_LESSONS || {}; }
  function esc(v){ try{ if(typeof lrEscape === 'function') return lrEscape(v); }catch(e){} return String(v === undefined || v === null ? '' : v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];}); }
  function isMusicRoom(r){
    if(!r) return false;
    var key = [r.id, r.title, r.zone, r.realm, r.subject].join(' ').toLowerCase();
    return r.subject === 'Music' || /bardwood|music hall|rhythm circle|instrument gallery|tempo trail|melody bridge|listening loft|choir nook|humming path|echo bend/.test(key);
  }
  function setFeedback(msg){ var f=byId('feedback'); if(f) f.textContent = msg; }
  function ensureProgressSafe(s, child, subj){
    try{ if(typeof ensureProgress === 'function') ensureProgress(); }catch(e){}
    if(!s) return;
    s.progress = s.progress || {};
    s.progress[child] = s.progress[child] || {};
    if(typeof s.progress[child][subj] !== 'number') s.progress[child][subj] = 0;
  }
  function directMusicLesson(){
    var r = getRoom();
    if(!isMusicRoom(r)) return null;

    try{
      if(typeof lrCanStartLearning === 'function' && !window.__lrStartingFromInteract){
        var gate = lrCanStartLearning();
        if(gate && gate.ok === false){ setFeedback(gate.msg || 'Learning is not available yet.'); return false; }
        try{ if(typeof lrReserveLearningAttempt === 'function') lrReserveLearningAttempt(); }catch(e){}
      }
    }catch(e){}

    var subj = 'Music';
    var child = getChild();
    var s = getState();
    ensureProgressSafe(s, child, subj);

    var lessonsRoot = getLessonsRoot();
    var list = (lessonsRoot[child] && lessonsRoot[child][subj]) || [];
    if(!list.length){
      setFeedback('No Music lesson pack loaded for ' + child + ' yet.');
      return false;
    }

    var idx = 0;
    try{ idx = (s.progress[child][subj] || 0) % list.length; }catch(e){ idx = 0; }
    var L = list[idx] || list[0];
    if(!L){ setFeedback('Music lesson data could not be opened.'); return false; }

    var lessonBox = byId('lessonBox');
    var storageBox = byId('storageBox');
    var actionTitle = byId('actionTitle');
    var actionText = byId('actionText');
    var questionText = byId('questionText');
    var choices = byId('choices');

    if(lessonBox) lessonBox.classList.remove('hidden');
    if(storageBox) storageBox.classList.add('hidden');
    if(actionTitle) actionTitle.textContent = 'Music Lesson';

    var intro = '';
    try{ if(typeof lrWorldFlavor === 'function') intro += lrWorldFlavor(); }catch(e){}
    try{ if(typeof lessonIntroHtml === 'function') intro += lessonIntroHtml(L, subj, idx, list.length); }catch(e){
      intro += '<div class="lessonIntro"><h3>' + esc(L.title || 'Music Lesson') + '</h3><p>' + esc(L.teach || L.miniLesson || L.q || 'Listen carefully and answer the music challenge.') + '</p></div>';
    }
    if(actionText) actionText.innerHTML = intro;

    if(questionText){
      questionText.innerHTML = '<div class="questionBanner"><div class="questionTitle">Challenge Question</div><div class="questionBody">' + esc(L.q || 'What did this music lesson teach?') + '</div></div>';
    }
    if(choices){
      choices.innerHTML = '';
      (L.c || L.choices || []).forEach(function(choice,i){
        var b=document.createElement('button');
        b.className='choice';
        var letter='ABCD'[i] || String(i+1);
        try{ if(typeof lessonChoiceLetter === 'function') letter = lessonChoiceLetter(i); }catch(e){}
        b.innerHTML='<span class="choiceLetter">'+esc(letter)+'</span><span>'+esc(choice)+'</span>';
        b.onclick=function(){
          try{ if(typeof answer === 'function') return answer(choice,L,subj,idx,b); }catch(e){ console.warn('LR69D Music answer fallback failed', e); }
          return false;
        };
        choices.appendChild(b);
      });
    }
    setFeedback('Music lesson opened from Bardwood Hall. Correct answers build mastery, Sparks, attendance records, and boss readiness.');

    try{ if(typeof lrMoveLessonIntoPopup === 'function') lrMoveLessonIntoPopup(); }catch(e){}
    try{ if(typeof window.lr68EnlargePopup === 'function') window.lr68EnlargePopup(); }catch(e){}
    try{ document.body.classList.add('lrBigLessonPopup'); }catch(e){}
    return false;
  }

  function install(){
    if(typeof window.startLesson === 'function' && !window.startLesson.__lr69dMusicDirectWrapped){
      var oldStart = window.startLesson;
      var wrapped = function(){
        var out = directMusicLesson();
        if(out !== null) return out;
        return oldStart.apply(this, arguments);
      };
      wrapped.__lr69dMusicDirectWrapped = true;
      wrapped.__lr69dOld = oldStart;
      window.startLesson = wrapped;
      try{ startLesson = wrapped; }catch(e){}
    }

    // If a Music room somehow has a direct creative launcher button, redirect that specific case.
    try{
      document.addEventListener('click', function(ev){
        var btn = ev.target && ev.target.closest ? ev.target.closest('button') : null;
        if(!btn) return;
        var txt = (btn.textContent || '').toLowerCase();
        var on = (btn.getAttribute('onclick') || '').toLowerCase();
        if(isMusicRoom(getRoom()) && /creative studio/.test(txt) && /opencreativestudiocourse/.test(on)){
          ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
          directMusicLesson();
        }
      }, true);
    }catch(e){}
  }

  window.lr69dStartMusicLessonDirect = directMusicLesson;
  window.lr69dMusicLessonHealth = function(){
    var r=getRoom(); var child=getChild(); var root=getLessonsRoot();
    return {
      loaded:true,
      currentRoom:r && (r.title || r.id || r.zone),
      isMusicRoom:isMusicRoom(r),
      child:child,
      musicLessonCount:((root[child] && root[child].Music) || []).length,
      startWrapped:!!(window.startLesson && window.startLesson.__lr69dMusicDirectWrapped),
      notes:'Music rooms should launch the Music lesson bank directly, not Creative Studio.'
    };
  };

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(install,120); setTimeout(install,650); });
  else { setTimeout(install,120); setTimeout(install,650); }
  window.addEventListener('load', function(){ setTimeout(install,350); setTimeout(install,1500); });
})();
