// Curriculum Pack 6H - Arts / Music / Creativity Foundation
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Arts",[
{teach:"Colors can be warm or cool.",q:"Which is a warm color?",c:["red","blue","purple"],a:"red"},
{teach:"Lines can be straight or curved.",q:"Which line bends?",c:["curved","straight","flat"],a:"curved"},
{teach:"Rhythm is a repeating beat.",q:"Rhythm is a repeating...",c:["beat","cloud","shape"],a:"beat"},
{teach:"Artists observe details.",q:"Artists often...",c:["observe details","ignore things","hide pencils"],a:"observe details"},
{teach:"Shapes help build drawings.",q:"What helps build drawings?",c:["shapes","storms","bells"],a:"shapes"},
{teach:"Patterns repeat.",q:"Patterns do what?",c:["repeat","vanish","sleep"],a:"repeat"},
{teach:"Music can be fast or slow.",q:"Music speed can be...",c:["fast or slow","square or round","wet or dry"],a:"fast or slow"},
{teach:"Drawing practice helps artists grow.",q:"Practice helps artists...",c:["grow","shrink","forget"],a:"grow"}
]);

LR_addLessons("Ava","Arts",[
{teach:"Composition is how art is arranged.",q:"Composition means...",c:["how art is arranged","paint color only","frame size"],a:"how art is arranged"},
{teach:"Rhythm in music organizes sound.",q:"Rhythm organizes...",c:["sound","weather","maps"],a:"sound"},
{teach:"Instruments make music in different ways.",q:"Instruments make...",c:["music","clouds","shadows"],a:"music"},
{teach:"Stories can be told through art.",q:"Art can tell...",c:["stories","weather only","math only"],a:"stories"},
{teach:"Foreground appears closer in art.",q:"Foreground looks...",c:["closer","farther","smaller always"],a:"closer"},
{teach:"Background appears farther away.",q:"Background looks...",c:["farther away","closer","louder"],a:"farther away"},
{teach:"Artists use contrast.",q:"Contrast shows...",c:["differences","copies","silence"],a:"differences"},
{teach:"Creative work improves with revision.",q:"Creative work improves with...",c:["revision","hiding","luck"],a:"revision"}
]);

LR_addLessons("Michael","Arts",[
{teach:"Perspective creates depth in art.",q:"Perspective helps create...",c:["depth","sound","weather"],a:"depth"},
{teach:"Symbolism uses images to represent ideas.",q:"Symbolism represents...",c:["ideas","temperature","distance"],a:"ideas"},
{teach:"Musical structure organizes pieces.",q:"Structure organizes...",c:["music","paint only","stories only"],a:"music"},
{teach:"Art analysis studies meaning and technique.",q:"Art analysis studies...",c:["meaning and technique","price only","frames"],a:"meaning and technique"},
{teach:"Creative process includes planning and revision.",q:"Creative process includes...",c:["planning and revision","guessing only","speed"],a:"planning and revision"},
{teach:"Mood can be created through art.",q:"Art can create...",c:["mood","gravity","weather"],a:"mood"},
{teach:"Visual balance affects composition.",q:"Balance affects...",c:["composition","temperature","erosion"],a:"composition"},
{teach:"Music can use repeating themes.",q:"Repeating themes are called...",c:["motifs","habitats","premises"],a:"motifs"}
]);
})();