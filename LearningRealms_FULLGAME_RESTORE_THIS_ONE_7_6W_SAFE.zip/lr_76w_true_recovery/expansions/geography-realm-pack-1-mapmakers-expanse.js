// Geography Realm Pack 1: Mapmaker's Expanse
// Adds a dedicated Geography realm with maps, landforms, regions, directions, and exploration.
// Adds starter Geography grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.
// Uses existing lesson/portfolio/boss systems. Minimal engine risk.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const geoRooms = {
    mapmakerRoad1:{
      title:"Compass Road",
      zone:"Mapmaker's Road",
      text:"A winding road leaves town beneath carved wooden signs pointing north, south, east, and west. Little brass compass marks are set into the stones, and every few steps a painted arrow points toward a different adventure.",
      exits:{south:"townSquare",east:"mapmakerRoad2"}
    },
    mapmakerRoad2:{
      title:"Surveyor's Bend",
      zone:"Mapmaker's Road",
      text:"The road bends around a hill where survey flags flutter in the breeze. A small table holds rolled maps, string, measuring rods, and a bowl of smooth pebbles used to mark distances.",
      exits:{west:"mapmakerRoad1",east:"mapmakerGate"}
    },
    mapmakerGate:{
      title:"Mapmaker's Gate",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"An archway carved with mountains, rivers, forests, and stars opens into a wide land of maps and exploration. A huge compass rose is painted on the ground.",
      npc:{name:"Compass Keeper Nola",desc:"A cheerful map guide with a feathered hat and a brass compass.",text:"Nola spins her compass. 'Geography is the art of knowing where you are, where things are, and why places are different.'"},
      exits:{west:"mapmakerRoad2",east:"compassCourt",south:"mapHall"}
    },
    compassCourt:{
      title:"Compass Court",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"A round courtyard is paved with a giant compass rose. North, south, east, and west are set in bright stone. Smaller paths point northeast, northwest, southeast, and southwest.",
      npc:{name:"Cardinal Crow",desc:"A clever black crow who teaches directions and map symbols.",text:"Cardinal Crow flaps once. 'Never trust a map until you know which way is north!'"},
      exits:{west:"mapmakerGate",east:"landformRidge",south:"regionGardens"}
    },
    mapHall:{
      title:"Hall of Many Maps",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"Tall tables hold maps of towns, forests, rivers, caves, countries, and imaginary lands. Some maps use symbols, some use colors, and some use contour lines.",
      npc:{name:"Archivist Atlas",desc:"A patient old cartographer who teaches map keys, scale, symbols, and latitude/longitude.",text:"Atlas adjusts his spectacles. 'A map is a promise: if you understand its symbols, it will tell you where to go.'"},
      exits:{north:"mapmakerGate",east:"regionGardens",south:"latitudeTower"}
    },
    landformRidge:{
      title:"Landform Ridge",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"A high ridge overlooks miniature mountains, valleys, plains, plateaus, islands, and rivers carved into the earth like a giant teaching model.",
      npc:{name:"Granite Toma",desc:"A friendly stone giant who teaches landforms and physical features.",text:"Toma pats the ridge. 'Mountains rise, valleys dip, rivers flow, and plains stretch wide. The land has shapes, and those shapes matter.'"},
      exits:{west:"compassCourt",south:"waterwayCrossing"}
    },
    regionGardens:{
      title:"Region Gardens",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"Different garden plots show different regions: a dry rock garden, a pine forest path, a grassland square, a cool mountain patch, and a riverbank full of reeds.",
      npc:{name:"Sage Rowan",desc:"A gentle gardener who teaches regions, climate, and human-environment interaction.",text:"Rowan brushes soil from his hands. 'A region is more than a place. It is a place with shared features.'"},
      exits:{north:"compassCourt",west:"mapHall",east:"waterwayCrossing",south:"settlementWorkshop"}
    },
    waterwayCrossing:{
      title:"Waterway Crossing",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"Small bridges cross streams that twist into a larger river model. Signs label source, tributary, riverbank, mouth, and delta.",
      npc:{name:"River Scout Mira",desc:"A quick-footed scout who teaches waterways, resources, erosion, and travel routes.",text:"Mira points downstream. 'Rivers do more than flow. They carry water, soil, people, goods, and stories.'"},
      exits:{north:"landformRidge",west:"regionGardens",south:"latitudeTower"}
    },
    settlementWorkshop:{
      title:"Settlement Workshop",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"Tables hold small wooden houses, farms, roads, wells, bridges, and market stalls. Learners can arrange them to see why people settle near water, roads, farmland, or resources.",
      npc:{name:"Builder Pell",desc:"A practical planner who teaches settlements, resources, and human geography.",text:"Pell sets down a tiny house. 'People do not settle randomly. They look for water, food, safety, trade, and useful land.'"},
      exits:{north:"regionGardens",east:"latitudeTower"}
    },
    latitudeTower:{
      title:"Latitude Tower",
      zone:"Mapmaker's Expanse",
      subject:"Geography",
      text:"A tall tower painted with horizontal and vertical lines rises above the expanse. Globes hang from the ceiling, each marked with latitude, longitude, equator, prime meridian, and hemispheres.",
      npc:{name:"Professor Meridian",desc:"A precise teacher who teaches latitude, longitude, coordinates, and global location.",text:"Professor Meridian taps a globe. 'Coordinates are like an address for the whole Earth.'"},
      exits:{north:"mapHall",west:"settlementWorkshop",east:"waterwayCrossing"}
    }
  };

  Object.assign(ROOMS, geoRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.north) ROOMS.townSquare.exits.north = "mapmakerRoad1";
    else if(!ROOMS.townSquare.exits.west) ROOMS.townSquare.exits.west = "mapmakerRoad1";
  }
})();

(function(){
  // Rewards
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Geography = window.LR_REWARDS.Geography || [];
  window.LR_REWARDS.Geography.push(
    {name:"Tiny Compass Rose",slot:"shelf"},
    {name:"Rolled Explorer Map",slot:"wall"},
    {name:"Mountain Ridge Model",slot:"shelf"},
    {name:"River Route Ribbon",slot:"wall"},
    {name:"Latitude Globe",slot:"desk"},
    {name:"Map Key Plaque",slot:"wall"},
    {name:"Surveyor Flag Cup",slot:"desk"},
    {name:"Region Garden Tile",slot:"shelf"}
  );
})();

(function(){
  // Grade target tracking
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Geography = {display:"Geography / Maps / Places",targetCorrect:150,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Geography = {display:"Geography / Regions / Human-Environment",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Geography = {display:"Geography / Global Systems / Source Maps",targetCorrect:240,bossTarget:1};
})();

(function(){
  // Daily classroom rotation
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Geography")) cfg.assignmentSubjects[child].push("Geography");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Geography:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Geography:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Geography:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  // Curriculum map additions
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Geography = {
    zone:"Mapmaker's Expanse",
    units:[
      {id:"G1-GEO-MAPS",title:"Maps and Directions",goal:"Understand maps, symbols, directions, and simple location words.",targetLessons:120,skills:["map","symbol","north","south","east","west","near","far"]},
      {id:"G1-GEO-PLACES",title:"Places and Features",goal:"Recognize land, water, weather, and simple physical features.",targetLessons:100,skills:["river","mountain","forest","town","weather","land","water"]},
      {id:"G1-GEO-COMMUNITY",title:"People and Places",goal:"Learn how people use places for homes, roads, food, and work.",targetLessons:80,skills:["home","road","farm","community","water","resources"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Geography = {
    zone:"Mapmaker's Expanse",
    units:[
      {id:"G6-GEO-MAPS",title:"Map Skills and Coordinates",goal:"Use map keys, scale, direction, latitude, longitude, and coordinates.",targetLessons:160,skills:["map key","scale","compass rose","latitude","longitude","coordinates"]},
      {id:"G6-GEO-REGIONS",title:"Regions and Landforms",goal:"Understand regions, landforms, climate, and physical geography.",targetLessons:160,skills:["regions","landforms","climate","mountains","plains","rivers"]},
      {id:"G6-GEO-HUMAN",title:"Human-Environment Interaction",goal:"Explain how people adapt to, depend on, and modify environments.",targetLessons:140,skills:["settlement","resources","trade routes","irrigation","human impact","adaptation"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Geography = {
    zone:"Mapmaker's Expanse",
    units:[
      {id:"G7-GEO-SPATIAL",title:"Spatial Reasoning",goal:"Analyze maps, location, movement, scale, and spatial patterns.",targetLessons:170,skills:["scale","coordinates","spatial pattern","movement","distance","map evidence"]},
      {id:"G7-GEO-SYSTEMS",title:"Physical and Human Systems",goal:"Understand how physical systems and human systems interact.",targetLessons:170,skills:["climate","resources","settlement","migration","trade","environmental impact"]},
      {id:"G7-GEO-ANALYSIS",title:"Geographic Evidence",goal:"Use map evidence and reliable sources to explain geographic claims.",targetLessons:140,skills:["map evidence","source reliability","data","claims","patterns","bias"]}
    ]
  };
})();

(function(){
  // Portfolio prompts
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-GEO-MAP-1",subject:"Geography",unit:"G1-GEO-MAPS",title:"Draw a Simple Map",prompt:"Draw or describe a simple map of a room, yard, or pretend village. Add at least three symbols.",helper:"Try symbols for a house, road, tree, river, or table.",estimatedMinutes:20},
    {id:"LUNA-GEO-PLACE-1",subject:"Geography",unit:"G1-GEO-PLACES",title:"Place Description",prompt:"Describe one place. Tell whether it has land, water, roads, trees, buildings, or weather.",helper:"Use: This place has ___. I notice ___.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-GEO-REGION-1",subject:"Geography",unit:"G6-GEO-REGIONS",title:"Describe a Region",prompt:"Describe a region by naming at least three shared features, such as landforms, climate, plants, resources, or settlement patterns.",helper:"Use specific geography words.",estimatedMinutes:25},
    {id:"AVA-GEO-HUMAN-1",subject:"Geography",unit:"G6-GEO-HUMAN",title:"Why People Settle There",prompt:"Explain why people might choose to settle near a river, road, farmland, or resource.",helper:"Mention water, food, transportation, safety, trade, or jobs.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-GEO-MAPEVIDENCE-1",subject:"Geography",unit:"G7-GEO-ANALYSIS",title:"Use Map Evidence",prompt:"Make a claim about a place using map evidence. Explain what the map shows and why that supports your claim.",helper:"Use claim, map evidence, and reasoning.",estimatedMinutes:30},
    {id:"MICHAEL-GEO-SYSTEMS-1",subject:"Geography",unit:"G7-GEO-SYSTEMS",title:"Human-Environment Interaction",prompt:"Explain one way people depend on, adapt to, or modify the environment. Give a specific example.",helper:"Think about rivers, farming, roads, climate, resources, or settlement.",estimatedMinutes:30}
  );
})();

(function(){
  // Grade-ladder Geography lessons for all three children.
  function LR_addGeographyLadder(child){
    LR_addLessons(child,"Geography",[
      {gradeBand:"K",unit:"K-GEO-PLACE",skill:"where things are",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Geography helps us learn where places and things are.",
       workedExample:"A toy can be on a table, under a chair, or beside a box.",
       guidedPractice:"Choose the word that tells where.",
       q:"Which word tells where something is?",c:["under","blue","jump"],a:"under",
       explain:"Under tells location."},

      {gradeBand:"G1",unit:"G1-GEO-MAPS",skill:"maps",difficulty:"grade 1",mode:"foundation",
       miniLesson:"A map shows places from above.",
       workedExample:"A map can show a road, house, river, or forest.",
       guidedPractice:"Choose the tool that shows places.",
       q:"What shows where places are?",c:["map","verb","coin"],a:"map",
       explain:"A map helps show locations."},

      {gradeBand:"G2",unit:"G2-GEO-MAPFEATURES",skill:"map keys",difficulty:"grade 2",mode:"foundation",
       miniLesson:"A map key explains what symbols mean.",
       workedExample:"A blue line might mean river. A star might mean capital city.",
       guidedPractice:"Look for the part that explains symbols.",
       q:"What explains symbols on a map?",c:["map key","paragraph","shadow"],a:"map key",
       explain:"A map key tells what symbols stand for."},

      {gradeBand:"G3",unit:"G3-GEO-REGIONS",skill:"regions",difficulty:"grade 3",mode:"foundation",
       miniLesson:"A region is an area with shared features.",
       workedExample:"A mountain region may have high land, steep slopes, and cooler air.",
       guidedPractice:"Look for common features.",
       q:"An area with shared features is a...",c:["region","fraction","verb"],a:"region",
       explain:"A region is grouped by shared features."},

      {gradeBand:"G4",unit:"G4-GEO-FEATURES",skill:"physical and human features",difficulty:"grade 4",mode:"foundation",
       miniLesson:"Physical features are natural. Human features are made or changed by people.",
       workedExample:"A river is physical. A road is human-made.",
       guidedPractice:"Ask whether nature made it or people made it.",
       q:"Which is a physical feature?",c:["river","road","bridge"],a:"river",
       explain:"A river is a natural physical feature."},

      {gradeBand:"G5",unit:"G5-GEO-COORDINATES",skill:"latitude and longitude",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Latitude and longitude help locate places on Earth.",
       workedExample:"Latitude lines run east-west and measure north or south of the equator.",
       guidedPractice:"Remember latitude is like ladder lines running across.",
       q:"Latitude measures north or south of the...",c:["equator","prime meridian","river"],a:"equator",
       explain:"Latitude measures distance north or south of the equator."},

      {gradeBand:"G6",unit:"G6-GEO-HUMAN",skill:"human-environment interaction",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Human-environment interaction explains how people affect the environment and how the environment affects people.",
       workedExample:"People build irrigation canals to bring water to farms.",
       guidedPractice:"Look for people changing or adapting to surroundings.",
       q:"Building irrigation canals is humans...",c:["modifying the environment","finding a suffix","adding decimals"],a:"modifying the environment",
       explain:"Irrigation changes the environment to support farming."},

      {gradeBand:"G7",unit:"G7-GEO-SPATIAL",skill:"spatial patterns",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Spatial patterns show how things are arranged across places.",
       workedExample:"Settlements may cluster near rivers because water helps farming, travel, and trade.",
       guidedPractice:"Ask where things are located and why.",
       q:"Towns clustered near rivers show a geographic...",c:["spatial pattern","sentence fragment","chemical change"],a:"spatial pattern",
       explain:"The arrangement of towns near rivers is a spatial pattern."},

      {gradeBand:"G8",unit:"G8-GEO-ANALYSIS",skill:"map evidence",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Map evidence can support geographic claims.",
       workedExample:"If a map shows farms concentrated near rivers, you can support a claim that water access affects farming locations.",
       guidedPractice:"Use what the map actually shows.",
       q:"A strong geographic claim should use...",c:["map evidence","random guesses","only color preference"],a:"map evidence",
       explain:"Map evidence helps prove a claim about places or patterns."}
    ]);
  }

  LR_addGeographyLadder("Luna");
  LR_addGeographyLadder("Ava");
  LR_addGeographyLadder("Michael");
})();

(function(){
  // Boss content
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Geography = [
    {title:"Compass Crow's Direction Test",intro:"Cardinal Crow hops around the giant compass rose.",q:"Which word is a direction?",c:["north","blue","jump"],a:"north",reward:"Tiny Compass Feather"},
    {title:"Map Hall Symbol Test",intro:"Archivist Atlas points to a tiny blue line on a map.",q:"What helps explain map symbols?",c:["map key","story title","weather"],a:"map key",reward:"Beginner Map Key"}
  ];

  window.LR_BOSS_CONTENT.Ava.Geography = [
    {title:"Region Garden Trial",intro:"Sage Rowan asks Ava to identify what makes a region.",q:"A region is an area with shared...",c:["features","fractions","verbs"],a:"features",reward:"Region Garden Badge"},
    {title:"Settlement Workshop Trial",intro:"Builder Pell asks why people settle near rivers.",q:"Which reason helps explain settlement near rivers?",c:["water and transportation","silent letters","shading only"],a:"water and transportation",reward:"Settlement Planner Token"}
  ];

  window.LR_BOSS_CONTENT.Michael.Geography = [
    {title:"Latitude Tower Coordinate Trial",intro:"Professor Meridian spins a globe marked with lines.",q:"Latitude measures north or south of the...",c:["equator","prime meridian","mountain ridge"],a:"equator",reward:"Coordinate Scholar Globe"},
    {title:"Map Evidence Trial",intro:"Archivist Atlas asks for proof from the map, not guesses.",q:"A strong geographic claim should rely on...",c:["map evidence","random guessing","loud opinions"],a:"map evidence",reward:"Map Evidence Seal"}
  ];
})();
