/* LearningRealms Dynamic Adventure Screen 6.7D
   Shop bridge fix: shops now render inside the dynamic adventure screen instead of depending
   on the older hidden storage/action panel. This keeps the fast choose-your-own-adventure
   interface while preserving real buying, currencies, ownership, level locks, and Home storage.
*/
(function(){
  'use strict';
  if(window.__LR67D_SHOP_BRIDGE__) return;
  window.__LR67D_SHOP_BRIDGE__ = true;

  var SHOP_IDS = ['seasonalShop','pictureShop','luckyKettle','shiftyTent'];

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function getState(){ try{ if(typeof state !== 'undefined' && state) return state; }catch(e){} return window.state || null; }
  function currentLoc(){ var s = getState(); return (s && s.loc) ? s.loc : 'crossroads'; }
  function getRoom(){ try{ if(typeof room === 'function') return room() || {}; }catch(e){} try{ if(window.room) return window.room() || {}; }catch(e){} try{ return (typeof ROOMS !== 'undefined' && ROOMS[currentLoc()]) || {}; }catch(e){} return {}; }
  function isShopLoc(loc){ return SHOP_IDS.indexOf(loc || currentLoc()) >= 0; }
  function call(name){ try{ if(typeof window[name] === 'function') return window[name].apply(window, Array.prototype.slice.call(arguments,1)); }catch(e){ console.warn(name,e); } try{ if(typeof eval(name) === 'function') return eval(name).apply(window, Array.prototype.slice.call(arguments,1)); }catch(e){} }
  function safeSave(){ call('save'); }
  function safeStats(){ call('renderStats'); }

  function normalizeItem(item){
    try{ if(typeof lrNormalizeShopItem === 'function') return lrNormalizeShopItem(item); }catch(e){}
    if(typeof item === 'string') return {name:item,cost:25,currency:'sparks',slot:'shelf',unique:true};
    item = item || {};
    return {
      name:item.name || 'Unnamed Shop Item',
      cost:Number.isFinite(Number(item.cost)) ? Number(item.cost) : 25,
      currency:item.currency || 'sparks',
      slot:item.slot || 'shelf',
      minLevel:item.minLevel || 0,
      unique:item.unique === false ? false : true,
      source:item.source || 'shop'
    };
  }
  function getItems(){
    try{ if(typeof shopItems === 'function') return (shopItems() || []).map(normalizeItem); }catch(e){ console.warn('shopItems failed', e); }
    try{ if(typeof baseShopItems === 'function') return (baseShopItems() || []).map(normalizeItem); }catch(e){}
    return [];
  }
  function level(){ try{ if(typeof activeLevel === 'function') return activeLevel(); }catch(e){} return 1; }
  function currencyLabel(item){ try{ if(typeof lrShopCurrencyLabel === 'function') return lrShopCurrencyLabel(item); }catch(e){} return item.currency === 'ancientCoins' ? 'Ancient Coins' : 'Sparks'; }
  function unlocked(item){ try{ if(typeof lrShopUnlocked === 'function') return lrShopUnlocked(item); }catch(e){} try{ if(typeof shopItemUnlocked === 'function') return shopItemUnlocked(item); }catch(e){} return !item.minLevel || level() >= item.minLevel; }
  function owned(item){ try{ if(typeof lrShopOwned === 'function') return lrShopOwned(item); }catch(e){} try{ if(typeof ownsHomeItem === 'function') return item.unique !== false && ownsHomeItem(item.name); }catch(e){} return false; }
  function afford(item){ try{ if(typeof lrShopCanAfford === 'function') return lrShopCanAfford(item); }catch(e){} var s = getState() || {}; var key = item.currency === 'ancientCoins' ? 'ancientCoins' : 'sparks'; return (s[key] || 0) >= item.cost; }
  function statusText(item){
    if(!unlocked(item)) return 'Requires Level ' + (item.minLevel || 1);
    if(owned(item)) return 'Owned';
    if(!afford(item)) return 'Need more ' + currencyLabel(item);
    return 'Ready to buy';
  }
  function itemCard(item, index){
    item = normalizeItem(item);
    var canBuy = unlocked(item) && !owned(item) && afford(item);
    var cls = canBuy ? 'lr67ShopReady' : 'lr67ShopMuted';
    return '<div class="lr67ShopCard ' + cls + '">' +
      '<div class="lr67ShopItemTop"><b>' + esc(item.name) + '</b><span>' + esc(item.cost) + ' ' + esc(currencyLabel(item)) + '</span></div>' +
      '<div class="lr67ShopMeta">Slot: ' + esc(item.slot || 'shelf') + ' · ' + esc(statusText(item)) + '</div>' +
      '<button type="button" class="lr67ShopBuy" onclick="lr67ShopBuy(' + index + ')" ' + (canBuy ? '' : 'disabled') + '>' + (owned(item) ? 'Already owned' : 'Buy') + '</button>' +
    '</div>';
  }
  function ensureMount(){
    try{ document.body.classList.add('lrDynamicAdventureMode'); document.body.classList.remove('homeMode'); }catch(e){}
    var firstCard = document.querySelector('.main > .card:first-child') || document.querySelector('.main') || document.querySelector('main') || document.body;
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen';
      if(firstCard.firstChild) firstCard.insertBefore(mount, firstCard.firstChild);
      else firstCard.appendChild(mount);
    }
    mount.style.display = 'block';
    mount.style.visibility = 'visible';
    mount.style.opacity = '1';
    mount.style.width = '100%';
    return mount;
  }
  function hideOldShopPanels(){
    try{ var lb = byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
    try{ var sb = byId('storageBox'); if(sb) sb.classList.add('hidden'); }catch(e){}
  }
  function shopIntro(loc, title){
    if(loc === 'seasonalShop') return 'Seasonal goods are arranged on warm wooden shelves. This shop is for festival pieces, home decor, and little treasures that make the realm feel alive.';
    if(loc === 'pictureShop') return 'Frames, portraits, banners, and wall pieces hang in neat rows. This is where earned rooms can start looking more personal.';
    if(loc === 'luckyKettle') return 'The little diner smells cozy and bright. Food items work like collectible keepsakes and make the home feel more lived in.';
    if(loc === 'shiftyTent') return 'The tent glows with rare relics. These items use Ancient Coins, so they should feel special instead of disposable.';
    return 'The shopkeeper lays out the day’s goods. Choose carefully. Rewards and purchases go to Home Storage.';
  }

  window.lr67RenderShopScene = function(message){
    try{
      var loc = currentLoc();
      if(!isShopLoc(loc)){
        if(typeof window.lr67RenderDynamicScreen === 'function') window.lr67RenderDynamicScreen('room', message || undefined);
        return false;
      }
      hideOldShopPanels();
      var r = getRoom();
      var s = getState() || {};
      var items = getItems();
      var mount = ensureMount();
      var title = r.title || 'Shop';
      var body = items.length ? items.map(itemCard).join('') : '<div class="lr67ShopEmpty">This shop has no stock loaded yet.</div>';
      mount.innerHTML =
        '<div class="lr67Hero lr67ShopHero">' +
          '<div class="lr67HeroTop"><span class="lr67Kicker">Town shop</span><span class="lr67Status">Sparks: ' + esc(s.sparks || 0) + ' · Ancient Coins: ' + esc(s.ancientCoins || 0) + '</span></div>' +
          '<h1>' + esc(title) + '</h1>' +
          '<div class="lr67Meta"><span>' + esc(r.zone || 'Town') + '</span><span>Storage purchases</span><span>Level ' + esc(level()) + '</span></div>' +
          '<div class="lr67SceneText"><p>' + esc(shopIntro(loc, title)) + '</p>' + (message ? '<p class="lr67ShopMessage">' + esc(message) + '</p>' : '') + '</div>' +
        '</div>' +
        '<div class="lr67ShopPanel"><div class="lr67PanelTitle"><span>What is on the shelves?</span><small>Buying stays on this main screen. No popup needed.</small></div><div class="lr67ShopGrid">' + body + '</div></div>' +
        '<div class="lr67BottomBar"><button type="button" onclick="lr67RenderDynamicScreen()">↩ Step back into the room</button><button type="button" onclick="lr67OpenLearn()">📘 Go Learn</button><button type="button" onclick="lr67GoHome()">🏡 Home</button></div>';
      return false;
    }catch(e){
      console.error('6.7D shop scene failed', e);
      try{ if(typeof window.lr67RenderDynamicScreen === 'function') window.lr67RenderDynamicScreen('room', 'Shop display error: ' + (e.message || e)); }catch(_e){}
      return false;
    }
  };

  window.lr67ShopBuy = function(index){
    try{
      var items = getItems();
      var item = normalizeItem(items[Number(index)]);
      if(!item || !item.name){ window.lr67RenderShopScene('That shop item could not be found.'); return false; }
      if(!unlocked(item)){ window.lr67RenderShopScene('That item is still locked until Level ' + (item.minLevel || 1) + '.'); return false; }
      if(owned(item)){ window.lr67RenderShopScene(item.name + ' is already in Home Storage.'); return false; }
      if(!afford(item)){ window.lr67RenderShopScene('Not enough ' + currencyLabel(item) + ' for ' + item.name + '.'); return false; }
      if(typeof buyItem === 'function'){
        buyItem(item);
      }else{
        var s = getState();
        var key = item.currency === 'ancientCoins' ? 'ancientCoins' : 'sparks';
        s[key] = (s[key] || 0) - item.cost;
        if(typeof ensureHome === 'function'){
          var h = ensureHome();
          if(!h.storage) h.storage = [];
          h.storage.push({name:item.name,slot:item.slot || 'shelf'});
        }
        safeSave();
        safeStats();
      }
      setTimeout(function(){ window.lr67RenderShopScene('Purchased ' + item.name + '. Added to Home Storage.'); }, 20);
      return false;
    }catch(e){
      console.error('6.7D shop buy failed', e);
      window.lr67RenderShopScene('Buying was blocked: ' + (e.message || e));
      return false;
    }
  };

  function openShopDynamic(){
    if(isShopLoc()) return window.lr67RenderShopScene();
    try{ if(window.__LR67D_OLD_OPEN_SHOP__) return window.__LR67D_OLD_OPEN_SHOP__.apply(this, arguments); }catch(e){}
    if(typeof window.lr67RenderDynamicScreen === 'function') window.lr67RenderDynamicScreen('room', 'There is no shop counter in this room.');
    return false;
  }

  function installOverrides(){
    try{
      if(!window.__LR67D_OLD_OPEN_SHOP__){
        if(typeof window.openShop === 'function') window.__LR67D_OLD_OPEN_SHOP__ = window.openShop;
        else if(typeof openShop === 'function') window.__LR67D_OLD_OPEN_SHOP__ = openShop;
      }
      window.openShop = openShopDynamic;
      try{ openShop = openShopDynamic; }catch(e){}
    }catch(e){}

    // Repair the old safe popup helper. A previous layer accidentally called itself recursively.
    window.lrSafeBrowseShopPopup = function(){ return window.lr67RenderShopScene(); };
    try{ lrSafeBrowseShopPopup = window.lrSafeBrowseShopPopup; }catch(e){}

    try{
      if(!window.__LR67D_OLD_SHOW_ACTION__ && typeof window.lr67ShowActionInScene === 'function') window.__LR67D_OLD_SHOW_ACTION__ = window.lr67ShowActionInScene;
      window.lr67ShowActionInScene = function(fnName, title){
        if(fnName === 'openShop' || isShopLoc()) return window.lr67RenderShopScene();
        if(window.__LR67D_OLD_SHOW_ACTION__) return window.__LR67D_OLD_SHOW_ACTION__.apply(this, arguments);
        return false;
      };
    }catch(e){}
  }

  function injectStyles(){
    if(byId('lr67DShopBridgeStyle')) return;
    var st = document.createElement('style');
    st.id = 'lr67DShopBridgeStyle';
    st.textContent = `
      .lr67ShopHero{background:linear-gradient(180deg, rgba(50,38,20,.22), rgba(0,0,0,0));}
      .lr67ShopPanel{padding:18px 24px 22px;border-top:1px solid rgba(255,227,160,.16);}
      .lr67ShopGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;}
      .lr67ShopCard{background:rgba(255,250,229,.96);color:#1d352d;border:1px solid rgba(255,232,171,.48);border-radius:16px;padding:12px;box-shadow:0 8px 16px rgba(0,0,0,.22);}
      .lr67ShopCard.lr67ShopMuted{opacity:.72;}
      .lr67ShopItemTop{display:flex;gap:10px;justify-content:space-between;align-items:flex-start;margin-bottom:7px;}
      .lr67ShopItemTop b{font-size:1rem;line-height:1.2;color:#18382f;}
      .lr67ShopItemTop span{background:#24463b;color:#fff4d0;border-radius:999px;padding:4px 7px;font-weight:900;font-size:.78rem;white-space:nowrap;}
      .lr67ShopMeta{font-weight:800;color:#52675f;font-size:.82rem;margin:6px 0 10px;}
      .lr67ShopBuy{width:100% !important;border-radius:12px !important;min-height:38px !important;font-weight:900 !important;background:#2f654f !important;color:#fff6d7 !important;border:1px solid rgba(255,227,160,.4) !important;}
      .lr67ShopBuy:disabled{background:#7c837d !important;color:#ece5d2 !important;cursor:not-allowed !important;}
      .lr67ShopMessage{background:rgba(255,227,160,.14);border:1px solid rgba(255,227,160,.35);border-radius:12px;padding:10px 12px;font-weight:900;color:#fff0bd;}
      .lr67ShopEmpty{background:rgba(255,255,255,.08);border:1px solid rgba(255,227,160,.25);border-radius:14px;padding:14px;color:#fff0bd;}
      @media(max-width:850px){.lr67ShopGrid{grid-template-columns:1fr;}.lr67ShopPanel{padding-left:16px;padding-right:16px;}}
    `;
    document.head.appendChild(st);
  }

  function boot(){
    injectStyles();
    installOverrides();
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 20);
  window.addEventListener('load', function(){ setTimeout(boot, 100); setTimeout(boot, 600); });
})();
