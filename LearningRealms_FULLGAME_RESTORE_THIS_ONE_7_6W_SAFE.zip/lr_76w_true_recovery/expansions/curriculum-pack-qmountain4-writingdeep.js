// Question Mountain Phase 4 - Writing Deepening
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Writing",[
{teach:"Questions end with question marks.",q:"A question ends with...",c:["?","!","."],a:"?"},
{teach:"Exclamations use exclamation marks.",q:"Excited sentences may use...",c:["!","?",";"],a:"!"},
{teach:"Complete sentences have ideas.",q:"Sentences should be...",c:["complete","random","blank"],a:"complete"},
{teach:"Words build sentences.",q:"Sentences are made of...",c:["words","coins","maps"],a:"words"},
{teach:"Capitals start sentences.",q:"Sentence beginnings use...",c:["capitals","numbers","symbols"],a:"capitals"}
]);

LR_addLessons("Ava","Writing",[
{teach:"Supporting details explain ideas.",q:"Details help...",c:["explain ideas","draw maps","count"],a:"explain ideas"},
{teach:"Conclusions finish writing.",q:"Conclusions...",c:["finish writing","start stories","name chapters"],a:"finish writing"},
{teach:"Narratives tell events.",q:"Narratives tell...",c:["events","equations","weather"],a:"events"},
{teach:"Informative writing teaches.",q:"Informative writing...",c:["teaches","sings","counts"],a:"teaches"},
{teach:"Transitions connect paragraphs.",q:"Transitions connect...",c:["ideas","coins","maps"],a:"ideas"}
]);

LR_addLessons("Michael","Writing",[
{teach:"Counterarguments strengthen essays.",q:"Counterarguments can...",c:["strengthen essays","erase evidence","hide claims"],a:"strengthen essays"},
{teach:"Introductions present topics.",q:"Introductions present...",c:["topics","answers","grades"],a:"topics"},
{teach:"Evidence supports claims.",q:"Claims need...",c:["evidence","luck","titles"],a:"evidence"},
{teach:"Revision improves organization.",q:"Revision may improve...",c:["organization","weather","maps"],a:"organization"},
{teach:"Editing checks grammar.",q:"Editing checks...",c:["grammar","trade","population"],a:"grammar"}
]);
})();