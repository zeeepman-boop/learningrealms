// Grade Ladder Pack G4: Grade 4 Foundation
// Tagged with gradeBand:"G4" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG4Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G4",unit:"G4-READ-VOCAB",skill:"context clues",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Context clues are nearby words that help you figure out an unknown word.",
     workedExample:"The frigid wind made everyone shiver. Shiver is a clue that frigid means very cold.",
     guidedPractice:"Look at the words around the unknown word.",
     q:"The frigid wind made everyone shiver. Frigid means...",
     c:["very cold","very loud","very bright"],a:"very cold",
     explain:"Shiver gives a clue that frigid means very cold."},

    {gradeBand:"G4",unit:"G4-READ-COMP",skill:"summarizing",difficulty:"grade 4",mode:"foundation",
     miniLesson:"A summary tells the most important ideas without every tiny detail.",
     workedExample:"A long passage about a dragon learning to paint might be summarized as: A young dragon practices art and learns patience.",
     guidedPractice:"Keep the main idea and important events.",
     q:"A good summary should include...",
     c:["main ideas","every tiny detail","only one word"],a:"main ideas",
     explain:"A summary is shorter than the original and focuses on main ideas."},

    {gradeBand:"G4",unit:"G4-READ-COMP",skill:"point of view",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Point of view is the perspective from which a story is told.",
     workedExample:"First person uses I or we. Third person often uses he, she, or they.",
     guidedPractice:"Look for pronouns that show who is telling the story.",
     q:"Which word can signal first-person point of view?",
     c:["I","they","dragon"],a:"I",
     explain:"I is a clue that the narrator may be speaking in first person."},

    {gradeBand:"G4",unit:"G4-READ-COMP",skill:"theme with evidence",difficulty:"grade 4",mode:"foundation",
     miniLesson:"A theme should be supported with evidence from the story.",
     workedExample:"If a character shares food with someone hungry, that can support a theme about kindness.",
     guidedPractice:"Choose a theme that matches what the character does.",
     q:"A character helps a stranger even when it is hard. Which theme fits best?",
     c:["Kindness matters.","Rocks are round.","Maps have symbols."],a:"Kindness matters.",
     explain:"Helping someone supports the theme that kindness matters."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G4",unit:"G4-MATH-MULT",skill:"multi-digit multiplication",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Multi-digit multiplication can be broken into place value parts.",
     workedExample:"23 x 4 = 20 x 4 plus 3 x 4. That is 80 + 12 = 92.",
     guidedPractice:"Break the two-digit number into tens and ones.",
     q:"23 x 4 = ?",
     c:["92","82","96"],a:"92",
     explain:"20 x 4 is 80, and 3 x 4 is 12. Together they make 92."},

    {gradeBand:"G4",unit:"G4-MATH-DIV",skill:"division with remainders",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Sometimes division leaves a remainder.",
     workedExample:"17 divided by 5 is 3 remainder 2, because 5 x 3 = 15 and 2 are left over.",
     guidedPractice:"Find the largest equal group and see what remains.",
     q:"17 ÷ 5 = ?",
     c:["3 R2","5 R3","4 R1"],a:"3 R2",
     explain:"5 goes into 17 three times with 2 left over."},

    {gradeBand:"G4",unit:"G4-MATH-FRAC",skill:"equivalent fractions",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Equivalent fractions name the same amount.",
     workedExample:"1/2 and 2/4 are equivalent because they show the same part of a whole.",
     guidedPractice:"Think about whether the shaded amount is the same.",
     q:"Which fraction is equivalent to 1/2?",
     c:["2/4","1/4","3/4"],a:"2/4",
     explain:"2 out of 4 equal parts is the same amount as 1 out of 2 equal parts."},

    {gradeBand:"G4",unit:"G4-MATH-DEC",skill:"decimals",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Decimals can show parts of a whole using place value.",
     workedExample:"0.5 means five tenths, which is the same as one half.",
     guidedPractice:"Read the digit after the decimal as tenths.",
     q:"0.5 means...",
     c:["five tenths","five hundreds","five wholes"],a:"five tenths",
     explain:"The 5 is in the tenths place."},

    {gradeBand:"G4",unit:"G4-MATH-GEO",skill:"angles",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Angles are formed where two rays meet. Angles can be acute, right, or obtuse.",
     workedExample:"A right angle makes a square corner and measures 90 degrees.",
     guidedPractice:"Think of the corner of a square.",
     q:"A right angle measures...",
     c:["90 degrees","45 degrees","180 degrees"],a:"90 degrees",
     explain:"A right angle is exactly 90 degrees."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G4",unit:"G4-ELA-GRAMMAR",skill:"prepositions",difficulty:"grade 4",mode:"foundation",
     miniLesson:"A preposition shows relationship, often where or when something happens.",
     workedExample:"In The dragon slept under the tree, under is the preposition.",
     guidedPractice:"Look for a word showing location.",
     q:"In The cat sat beside the box, which word is a preposition?",
     c:["beside","cat","sat"],a:"beside",
     explain:"Beside shows where the cat sat."},

    {gradeBand:"G4",unit:"G4-ELA-WRITING",skill:"opinion paragraph",difficulty:"grade 4",mode:"foundation",
     miniLesson:"An opinion paragraph states an opinion and supports it with reasons.",
     workedExample:"I think the dragon mural is strong because it uses contrast and clear details.",
     guidedPractice:"Look for the reason after because.",
     q:"Which sentence gives an opinion with support?",
     c:["I like the mural because the colors stand out.","The mural is on a wall.","Mural bright."],a:"I like the mural because the colors stand out.",
     explain:"It gives an opinion and a reason."},

    {gradeBand:"G4",unit:"G4-ELA-WRITING",skill:"transitions",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Transitions connect ideas and show order or relationships.",
     workedExample:"First, next, and finally show sequence. However can show contrast.",
     guidedPractice:"Choose the word that shows order.",
     q:"Which transition shows sequence?",
     c:["next","dragon","quick"],a:"next",
     explain:"Next shows what comes after something else."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G4",unit:"G4-SCI-ENERGY",skill:"energy transfer",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Energy can move from one object to another.",
     workedExample:"When sunlight warms a rock, energy transfers from the sun to the rock.",
     guidedPractice:"Ask where the energy starts and where it goes.",
     q:"Sunlight warming a rock is an example of energy...",
     c:["transfer","grammar","citizenship"],a:"transfer",
     explain:"Energy moves from the sunlight to the rock."},

    {gradeBand:"G4",unit:"G4-SCI-WAVES",skill:"waves",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Waves can transfer energy.",
     workedExample:"Sound travels as waves. Light also behaves like waves in many ways.",
     guidedPractice:"Think about what waves carry.",
     q:"Waves can transfer...",
     c:["energy","laws","paragraphs"],a:"energy",
     explain:"Waves transfer energy from place to place."},

    {gradeBand:"G4",unit:"G4-SCI-EARTH",skill:"weathering and erosion",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Weathering breaks rock. Erosion moves the broken pieces.",
     workedExample:"Ice cracking rock is weathering. A river carrying sand is erosion.",
     guidedPractice:"Ask whether rock is breaking or moving.",
     q:"A river carrying sand is...",
     c:["erosion","condensation","magnetism"],a:"erosion",
     explain:"Erosion moves sediment from one place to another."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G4",unit:"G4-SS-GEOGRAPHY",skill:"human and physical features",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Physical features are natural. Human features are made or changed by people.",
     workedExample:"A river is a physical feature. A road is a human feature.",
     guidedPractice:"Ask whether nature made it or people made it.",
     q:"Which is a physical feature?",
     c:["river","road","bridge"],a:"river",
     explain:"A river is a natural feature."},

    {gradeBand:"G4",unit:"G4-SS-CIVICS",skill:"government roles",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Governments make and enforce rules and provide services.",
     workedExample:"A local government may help with roads, safety, and public buildings.",
     guidedPractice:"Think about services that help the community.",
     q:"Which is a public service?",
     c:["road repair","private toy box","personal lunch"],a:"road repair",
     explain:"Road repair is a service that can help the public."},

    {gradeBand:"G4",unit:"G4-SS-ECON",skill:"opportunity cost",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Opportunity cost is what you give up when you make a choice.",
     workedExample:"If you choose to study instead of play, play time is the opportunity cost.",
     guidedPractice:"Ask what choice was not taken.",
     q:"Opportunity cost means what you...",
     c:["give up","always keep","never choose"],a:"give up",
     explain:"Opportunity cost is the next best choice given up."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G4",unit:"G4-ART-PERSPECTIVE",skill:"depth",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Artists can show depth by making closer things larger and farther things smaller.",
     workedExample:"A tree near the viewer may be large. Mountains far away may be small.",
     guidedPractice:"Think about what is closer to the viewer.",
     q:"Objects farther away often look...",
     c:["smaller","louder","heavier"],a:"smaller",
     explain:"Farther objects usually appear smaller in a picture."},

    {gradeBand:"G4",unit:"G4-ART-DESIGN",skill:"contrast",difficulty:"grade 4",mode:"foundation",
     miniLesson:"Contrast is a strong difference that helps something stand out.",
     workedExample:"A bright yellow dragon on a dark blue background has strong contrast.",
     guidedPractice:"Look for a strong difference.",
     q:"A bright object on a dark background shows...",
     c:["contrast","multiplication","evaporation"],a:"contrast",
     explain:"Contrast is a strong visual difference."}
  ]);
}

LR_addG4Foundation("Luna");
LR_addG4Foundation("Ava");
LR_addG4Foundation("Michael");
