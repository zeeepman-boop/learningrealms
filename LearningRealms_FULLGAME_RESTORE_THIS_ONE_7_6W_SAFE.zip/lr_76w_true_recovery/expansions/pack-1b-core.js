// Expansion Pack 1B: 30 more lessons, curriculum only

LR_addLessons("Luna","Reading",[
 {teach:"A short e sound is in bed.",practice:"bed, red, hen",q:"Which word has short e?",c:["bed","cake","moon"],a:"bed"},
 {teach:"A short i sound is in pig.",practice:"pig, sit, fish",q:"Which word has short i?",c:["pig","cake","home"],a:"pig"},
 {teach:"A short o sound is in dog.",practice:"dog, hop, log",q:"Which word has short o?",c:["dog","bike","sun"],a:"dog"},
 {teach:"A short u sound is in sun.",practice:"sun, cup, bug",q:"Which word has short u?",c:["sun","tree","cake"],a:"sun"},
 {teach:"A story has characters.",practice:"The rabbit hops. Rabbit is the character.",q:"Who is a character?",c:["rabbit","road","rain"],a:"rabbit"}
]);

LR_addLessons("Luna","Math",[
 {teach:"A clock has an hour hand.",practice:"The short hand shows the hour.",q:"Which hand shows the hour?",c:["short hand","long hand","no hand"],a:"short hand"},
 {teach:"A nickel is 5 cents.",practice:"One nickel = 5.",q:"How much is a nickel?",c:["5","10","25"],a:"5"},
 {teach:"A triangle has 3 sides.",practice:"Count the sides.",q:"How many sides does a triangle have?",c:["3","4","5"],a:"3"},
 {teach:"A pair means two.",practice:"A pair of socks = 2 socks.",q:"How many are in a pair?",c:["2","3","4"],a:"2"},
 {teach:"20 is two tens.",practice:"10 + 10 = 20.",q:"20 is how many tens?",c:["2","1","5"],a:"2"}
]);

LR_addLessons("Ava","Math",[
 {teach:"To solve 3x = 21, divide by 3.",practice:"21 ÷ 3 = 7.",q:"3x = 21. x = ?",c:["7","18","24"],a:"7"},
 {teach:"A scale drawing keeps measurements proportional.",practice:"1 inch = 5 feet.",q:"If 2 inches are drawn, real length is...",c:["10 feet","5 feet","2 feet"],a:"10 feet"},
 {teach:"Mean is the average.",practice:"2, 4, 6 average to 4.",q:"Mean means...",c:["average","largest","smallest"],a:"average"},
 {teach:"An expression has numbers, variables, and operations.",practice:"3x + 2 is an expression.",q:"Which is an expression?",c:["3x + 2","because","triangle"],a:"3x + 2"},
 {teach:"A negative number is less than zero.",practice:"-3 is below zero.",q:"Which is negative?",c:["-3","3","0"],a:"-3"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Food chains show energy flow.",practice:"grass → rabbit → fox",q:"In a food chain, energy moves through...",c:["organisms","punctuation","maps"],a:"organisms"},
 {teach:"A habitat is where an organism lives.",practice:"A pond can be a frog habitat.",q:"A habitat is a...",c:["home environment","math rule","sentence ending"],a:"home environment"},
 {teach:"Weather is short-term conditions.",practice:"Today is rainy.",q:"Weather describes...",c:["short-term conditions","ancient records","word roots"],a:"short-term conditions"},
 {teach:"Climate is long-term weather pattern.",practice:"Many years of weather patterns.",q:"Climate is...",c:["long-term pattern","one rainy hour","one sentence"],a:"long-term pattern"},
 {teach:"A variable is something that can change in an experiment.",practice:"Amount of sunlight can vary.",q:"A variable can...",c:["change","never change","only be a noun"],a:"change"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Solve 5x - 3 = 22 by adding 3 first.",practice:"5x = 25, so x = 5.",q:"5x - 3 = 22. x = ?",c:["5","25","19"],a:"5"},
 {teach:"A y-intercept is where a line crosses the y-axis.",practice:"In y = 4x + 7, y-intercept is 7.",q:"In y = 4x + 7, y-intercept is...",c:["7","4","11"],a:"7"},
 {teach:"A function table pairs x-values and y-values.",practice:"x input gives y output.",q:"A function table shows inputs and...",c:["outputs","paragraphs","rocks"],a:"outputs"},
 {teach:"Volume measures space inside a solid.",practice:"A box has volume.",q:"Volume measures...",c:["inside space","surface color","sentence length"],a:"inside space"},
 {teach:"A square root reverses squaring.",practice:"√49 = 7.",q:"√49 = ?",c:["7","14","9"],a:"7"}
]);

LR_addLessons("Michael","History",[
 {teach:"Federalism divides power between national and state governments.",practice:"Some powers are national, some are state.",q:"Federalism divides...",c:["power","sentences","weather"],a:"power"},
 {teach:"A primary source comes from the time studied.",practice:"A letter from 1776 is primary.",q:"Which is primary?",c:["old letter","modern movie","new summary"],a:"old letter"},
 {teach:"Cause and effect connect events.",practice:"Tax anger helped cause protest.",q:"Cause explains...",c:["why it happened","how tall it was","what color"],a:"why it happened"},
 {teach:"Checks and balances limit government power.",practice:"Branches can limit each other.",q:"Checks and balances limit...",c:["power","rain","slope"],a:"power"},
 {teach:"Economics studies choices about resources.",practice:"Scarce resources require choices.",q:"Economics studies choices about...",c:["resources","spelling only","weather only"],a:"resources"}
]);
