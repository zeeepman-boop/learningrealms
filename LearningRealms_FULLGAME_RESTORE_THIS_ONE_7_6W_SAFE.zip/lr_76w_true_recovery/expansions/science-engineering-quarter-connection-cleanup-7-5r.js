/* LearningRealms 7.5R - Science and Engineering Quarter Connection Cleanup
   Small bridge patch only. No shell rebuild, no render loop, no loading curtain.
   Purpose: gather the Science and Engineering Quarter master roads and older science drawers
   into one safe in-world map so visible science buttons do not strand learners in loose menus. */
(function(){
  'use strict';

  if(window.__LR75R_SCIENCE_QUARTER_CLEANUP__) return;
  window.__LR75R_SCIENCE_QUARTER_CLEANUP__ = true;

  var PATCH = '7.5R Science and Engineering Quarter Connection Cleanup';
  var injectTimer = null;
  var obsInstalled = false;

  function $(id){ return document.getElementById(id); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }
  function smallText(v, max){
    var s = String(v || '').replace(/\s+/g, ' ').trim();
    if(!max || s.length <= max) return s;
    return s.slice(0, max - 1).trim() + '…';
  }
  function callFirst(names){
    for(var i=0;i<names.length;i++){
      var fn = names[i];
      if(has(fn)){
        try{
          window[fn]();
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }catch(e){ console.warn('LR75R route failed:', fn, e); }
      }
    }
    return false;
  }
  function actionMount(title, html){
    installStyles();
    var titleEl = $('actionTitle');
    var textEl = $('actionText');
    if(titleEl) titleEl.textContent = title || 'Science and Engineering Quarter';
    if(textEl) textEl.innerHTML = html || '';
    try{
      if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title || 'Science and Engineering Quarter');
      else if(has('lrOpenPopup')) window.lrOpenPopup(title || 'Science and Engineering Quarter', html || '');
    }catch(e){}
    scheduleInject();
  }

  var ROADS = [
    {
      key:'science', icon:'🔬', title:'Science and Engineering Expedition', place:'Copper Laboratory Gate',
      body:'The main quarter road for observation, matter, forces, machines, energy, light, sound, circuits, plants, habitats, and engineering design.',
      openers:['openScienceEngineeringAdventure74M','openScienceEngineeringQuarter74M']
    },
    {
      key:'inventions', icon:'🛠️', title:'Inventions & Engineering Disasters', place:'Blueprint Hall and Rebuild Archive',
      body:'A kid-safe engineering road about inventions, failures, testing, redesign, evidence, safety limits, and better rebuilds.',
      openers:['openInventionsEngineeringMaster74R','openInventionsEngineeringDisasters74R','openInventionsDeepCourse']
    },
    {
      key:'aerospace', icon:'🚀', title:'Aerospace Engineering Mission Wing', place:'Sky Dock and Mission Control',
      body:'Flight, lift, drag, thrust, wind tunnels, rockets, orbits, satellites, rovers, space suits, and mission planning.',
      openers:['openAerospaceEngineering74S','openAerospaceEngineering','openAerospaceMissionWing74S','openAerospaceDeepCourse']
    },
    {
      key:'natureHealth', icon:'🌿', title:'Nature & Health Deep Adventure', place:'Living Woods and Health Lodge',
      body:'Ecosystems, garden trails, weather sense, safe body systems, hygiene, sleep, movement, nutrition, and field readiness.',
      openers:['openNatureHealthDeepAdventure','openNatureHealth74T','openNatureAndHealth','openNatureTrail','openHealthLodge']
    },
    {
      key:'weather', icon:'🌦️', title:'Weather & Storm Lab', place:'Stormwatch Tower',
      body:'Clouds, air pressure, wind, storms, instruments, radar, satellites, maps, forecasting, and safe weather choices.',
      openers:['openWeatherStormLab74U','openWeatherStormLab','openStormwatchTower','openWeatherRoad','openWeatherStation']
    },
    {
      key:'animals', icon:'🐾', title:'Animal Kingdom & Creature Field Guide', place:'Creature Field Station',
      body:'Animal groups, habitats, tracks, adaptations, field journals, animal care, and observation evidence.',
      openers:['openCreatureFieldGuide','openAnimalKingdom74V','openAnimalKingdom','openAnimalRoad','openCreatureFieldStation']
    }
  ];

  var DRAWERS = {
    chemistry:{
      icon:'⚗️', title:'Chemistry Institute Drawer',
      note:'Older chemistry material for substances, mixtures, solutions, reactions, atoms, molecules, lab tools, and safe observation.',
      include:/chemistry|chemical|atom|molecule|mixture|solution|reaction|element|compound|acid|base|lab/i,
      empty:'No loose Chemistry Institute lessons were found in the loaded bank. Chemistry still belongs inside the Science and Engineering Quarter; use the main Expedition for matter and mixture chambers.',
      buttons:[['Open Science Expedition','road:science']]
    },
    astronomy:{
      icon:'🌌', title:'Astronomy Observatory Drawer',
      note:'Older astronomy and space-observatory practice for planets, stars, Moon phases, telescopes, satellites, orbits, and space maps.',
      include:/astronomy|observatory|space|planet|star|moon|solar|orbit|satellite|telescope|deep space/i,
      empty:'No loose Astronomy Observatory lessons were found. Space study is still routed through Aerospace Mission Wing and the astronomy drawer.',
      buttons:[['Open Aerospace Mission Wing','road:aerospace']]
    },
    earth:{
      icon:'🌎', title:'Earth Science Drawer',
      note:'Older earth science practice for rocks, minerals, soil, erosion, volcanoes, earthquakes, weathering, landforms, and Earth systems.',
      include:/earth science|earth_science|rock|mineral|soil|erosion|volcano|earthquake|weathering|landform|fossil/i,
      empty:'No loose Earth Science lessons were found. Earth topics are now safely grouped here and can also connect back to the main Science Expedition.',
      buttons:[['Open Science Expedition','road:science']]
    },
    botany:{
      icon:'🌱', title:'Botany Conservatory Drawer',
      note:'Older plant material for seeds, roots, stems, leaves, flowers, gardens, pollination, habitats, and plant observation.',
      include:/botany|plant|seed|root|stem|leaf|leaves|flower|garden|pollination|photosynthesis|conservatory/i,
      empty:'No loose Botany Conservatory lessons were found. Plant study is still kept here and also connects to Nature & Health.',
      buttons:[['Open Nature & Health','road:natureHealth'],['Open Science Expedition','road:science']]
    },
    electricity:{
      icon:'⚡', title:'Electricity Lab Drawer',
      note:'Older electricity practice for circuits, conductors, insulators, magnets, batteries, switches, bulbs, energy, and safe handling.',
      include:/electricity|electric|circuit|conductor|insulator|magnet|battery|switch|bulb|current|voltage/i,
      empty:'No loose Electricity Lab lessons were found. Electricity is still routed through the Science Expedition and this safe drawer.',
      buttons:[['Open Science Expedition','road:science']]
    },
    physics:{
      icon:'🧲', title:'Physics Forge Drawer',
      note:'Older physics practice for force, motion, energy, heat, light, sound, simple machines, friction, gravity, and physical science.',
      include:/physics|force|motion|energy|heat|temperature|light|sound|machine|friction|gravity|physical science/i,
      empty:'No loose Physics Forge lessons were found. Physics topics are already strongly represented inside the Science Expedition.',
      buttons:[['Open Science Expedition','road:science']]
    },
    computers:{
      icon:'🤖', title:'Robotics & Computer Science Drawer',
      note:'Older robotics and computer science practice for algorithms, commands, coding, loops, sensors, robots, and logic-like machine thinking.',
      include:/robot|robotics|computer|coding|code|algorithm|command|loop|sensor|program/i,
      empty:'No loose Robotics or Computer Science lessons were found. This drawer remains the proper future home so the topic does not float loose.',
      buttons:[['Open Science Quarter Map','map'],['Open Logic Tower from Core Halls','coreLogic']]
    },
    dinosaurs:{
      icon:'🦖', title:'Dinosaur & Fossil Drawer',
      note:'Older dinosaur and fossil material for fossils, tracks, ancient life, paleontology, evidence, rocks, and kid-safe prehistoric study.',
      include:/dinosaur|fossil|paleontology|prehistoric|track|ancient life|bones/i,
      empty:'No loose Dinosaur or Fossil lessons were found. Fossils are kept here under science and can connect to Earth Science evidence.',
      buttons:[['Earth Science Drawer','drawer:earth:0']]
    },
    insects:{
      icon:'🐜', title:'Insect Kingdom Drawer',
      note:'Older insect practice for pollinators, bug observation, habitats, body parts, life cycles, gardens, and field notes.',
      include:/insect|bug|pollinator|butterfly|bee|ant|habitat|life cycle|field note/i,
      empty:'No loose Insect Kingdom lessons were found. Insects still belong under Animals, Nature, and this science drawer.',
      buttons:[['Open Creature Field Guide','road:animals'],['Open Nature & Health','road:natureHealth']]
    },
    advanced:{
      icon:'🧪', title:'Older Science Practice Drawer',
      note:'General older science challenges that do not fit one exact room: observation, experiments, variables, classification, evidence, and lab habits.',
      include:/science|experiment|observation|variable|hypothesis|evidence|classify|classifying|lab|marsh/i,
      empty:'No loose general science lessons were found. Use the main Science and Engineering Expedition as the connected science road.',
      buttons:[['Open Science Expedition','road:science']]
    }
  };

  function roadByKey(key){
    for(var i=0;i<ROADS.length;i++) if(ROADS[i].key === key) return ROADS[i];
    return null;
  }
  function navButton(label, act){
    return '<button class="lr75rSmallBtn" data-lr75r-act="' + esc(act) + '">' + esc(label) + '</button>';
  }
  function roadButton(r){
    return '<button class="lr75rCard" data-lr75r-act="road:' + esc(r.key) + '">' +
      '<b>' + esc(r.icon + ' ' + r.title) + '</b>' +
      '<small>' + esc(r.place) + '</small>' +
      '<span>' + esc(r.body) + '</span>' +
    '</button>';
  }
  function drawerButton(key){
    var d = DRAWERS[key];
    if(!d) return '';
    return '<button class="lr75rCard lr75rDrawerCard" data-lr75r-act="drawer:' + esc(key) + ':0">' +
      '<b>' + esc(d.icon + ' ' + d.title) + '</b>' +
      '<small>Connected older science drawer</small>' +
      '<span>' + esc(d.note) + '</span>' +
    '</button>';
  }

  function renderScienceMap(){
    installStyles();
    actionMount('🔬 Science and Engineering Connected Map',
      '<div class="lr75rShell">' +
        '<div class="lr75rHero">' +
          '<div><b>🔬 Science and Engineering Connected Map</b><p>This is a tidy routing pass, not a new course. The main science roads stay first, and older science drawers are grouped underneath so they are reachable without turning the game into a scattered button shelf.</p></div>' +
          '<div class="lr75rHeroBtns">' + navButton('Realm Library','library') + navButton('7.5O Connection Ledger','ledger') + '</div>' +
        '</div>' +
        '<h3>Master roads</h3>' +
        '<div class="lr75rGrid lr75rRoadGrid">' + ROADS.map(roadButton).join('') + '</div>' +
        '<h3>Connected science drawers</h3>' +
        '<div class="lr75rGrid">' + ['chemistry','astronomy','earth','botany','electricity','physics','computers','dinosaurs','insects','advanced'].map(drawerButton).join('') + '</div>' +
        '<div class="lr75rNote"><b>What 7.5R does</b><p>Science, Inventions, Aerospace, Nature/Health, Weather, Animals, and older science drawers now have one safe quarter map. This patch does not thicken lessons yet and does not change the shell.</p></div>' +
      '</div>'
    );
  }

  function openRoad(key){
    var r = roadByKey(key);
    if(!r){ renderScienceMap(); return; }
    if(callFirst(r.openers)) return;
    softNote(r.title, 'This science road is listed in the quarter map, but its opener did not answer in this build. The route remains as an in-world signpost instead of becoming a dead button.', [['Back to Science Map','map']]);
  }
  function openCoreLogic(){
    if(callFirst(['openLogicTowerCriticalThinking75E','openLogicTowerMasterCourse','openLogicTower'])) return;
    softNote('Robotics logic note','Robotics and algorithms connect naturally to the Robotics drawer here and to Logic Tower in Core Halls.', [['Back to Science Map','map'],['Robotics Drawer','drawer:computers:0']]);
  }
  function lessonText(l){ return [l.source_pack,l.pack_region,l.region,l.mastery_tag,l.topic,l.skill,l.question,l.explanation,l.prompt].join(' '); }
  function lessonMatches(l, drawer){ return !!(drawer && drawer.include && drawer.include.test(lessonText(l))); }
  async function getBank(){
    if(has('lrLoadRealCurriculumBank')){
      try{ return await window.lrLoadRealCurriculumBank(); }catch(e){}
    }
    return window.__lrRealCurriculumBank || [];
  }
  async function renderDrawer(key, page){
    installStyles();
    var d = DRAWERS[key];
    if(!d){ renderScienceMap(); return; }
    page = Math.max(0, parseInt(page || 0, 10) || 0);
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75rShell"><div class="lr75rHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>Searching the existing lesson bank for older science material. No new course is being added.</p></div></div><p class="lr75rFoot">Loading connected drawer…</p></div>'
    );
    var bank = await getBank();
    var matches = (bank || []).filter(function(l){ return lessonMatches(l, d); });
    var per = 12;
    var pages = Math.max(1, Math.ceil(matches.length / per));
    if(page >= pages) page = pages - 1;
    var sample = matches.slice(page * per, page * per + per);
    if(!sample.length){
      actionMount(d.icon + ' ' + d.title,
        '<div class="lr75rShell">' +
          '<div class="lr75rHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p></div><div class="lr75rHeroBtns">' + navButton('Science Map','map') + '</div></div>' +
          '<div class="lr75rNote"><b>In-world route note</b><p>' + esc(d.empty) + '</p><div class="lr75rInlineBtns">' + (d.buttons || [['Back to Science Map','map']]).map(function(b){ return navButton(b[0], b[1]); }).join('') + navButton('Back to Science Map','map') + '</div></div>' +
        '</div>'
      );
      return;
    }
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75rShell">' +
        '<div class="lr75rHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p><p><small>' + matches.length + ' connected lesson' + (matches.length === 1 ? '' : 's') + ' found in the existing bank.</small></p></div><div class="lr75rHeroBtns">' + navButton('Science Map','map') + '</div></div>' +
        '<div class="lr75rLessonList">' + sample.map(function(l){
          var idx = bank.indexOf(l);
          return '<button class="lr75rLesson" data-lr75r-act="lesson:' + idx + '"><b>' + esc(l.region || l.pack_region || 'Science lesson') + '</b><small>' + esc(l.mastery_tag || l.source_pack || 'practice') + '</small><span>' + esc(smallText(l.question || l.explanation || l.prompt || '', 170)) + '</span></button>';
        }).join('') + '</div>' +
        '<div class="lr75rPager">' + (page > 0 ? navButton('← Previous','drawer:' + key + ':' + (page - 1)) : '') + '<span>Page ' + (page + 1) + ' of ' + pages + '</span>' + (page < pages - 1 ? navButton('Next →','drawer:' + key + ':' + (page + 1)) : '') + '</div>' +
      '</div>'
    );
  }

  function softNote(title, body, buttons){
    installStyles();
    buttons = buttons || [['Back to Science Map','map']];
    actionMount(title || 'Science Quarter Note',
      '<div class="lr75rShell"><div class="lr75rNote"><b>' + esc(title || 'Science Quarter Note') + '</b><p>' + esc(body || '') + '</p><div class="lr75rInlineBtns">' + buttons.map(function(b){ return navButton(b[0], b[1]); }).join('') + '</div></div></div>'
    );
  }

  function openLesson(idx){
    idx = parseInt(idx, 10);
    if(!isFinite(idx) || idx < 0){ softNote('Lesson route note','That older lesson pointer was not available.', [['Back to Science Map','map']]); return; }
    if(has('lrOpenRealLessonByIndex')){
      window.lrOpenRealLessonByIndex(idx);
      setTimeout(function(){
        var at = $('actionText');
        if(!at) return;
        var btns = at.querySelectorAll('button');
        for(var i=0;i<btns.length;i++){
          if(/Back to REAL Curriculum|Back to Curriculum|Return to Library/i.test(btns[i].textContent || '')){
            btns[i].setAttribute('data-lr75r-act','map');
            btns[i].removeAttribute('onclick');
            btns[i].textContent = 'Back to Science Map';
          }
        }
      }, 80);
      return;
    }
    softNote('Lesson route note','The authored lesson opener was not available in this build.', [['Back to Science Map','map']]);
  }

  function handleAct(act){
    if(!act) return;
    if(act === 'map'){ renderScienceMap(); return; }
    if(act === 'library'){
      if(has('openRealmLibrary75A')){ window.openRealmLibrary75A('science'); scheduleInject(); return; }
      if(has('openRealCurriculumPicker')){ window.openRealCurriculumPicker('all'); scheduleInject(); return; }
      renderScienceMap(); return;
    }
    if(act === 'ledger'){
      if(has('openLearningCenterAnnex75O')){ window.openLearningCenterAnnex75O('science'); scheduleInject(); return; }
      if(has('openLearningCenterConnectionAudit75O')){ window.openLearningCenterConnectionAudit75O(); scheduleInject(); return; }
      renderScienceMap(); return;
    }
    if(act === 'coreLogic'){ openCoreLogic(); return; }
    if(act.indexOf('road:') === 0){ openRoad(act.split(':')[1]); return; }
    if(act.indexOf('drawer:') === 0){ var bits = act.split(':'); renderDrawer(bits[1], bits[2] || 0); return; }
    if(act.indexOf('lesson:') === 0){ openLesson(act.split(':')[1]); return; }
  }

  function installStyles(){
    if($('lr75rStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr75rStyles';
    st.textContent =
      '.lr75rShell{padding:14px;color:#10261f}.lr75rHero{display:flex;gap:12px;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#eafff5,#d8f1ff);border:2px solid #34896f;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 8px 20px rgba(10,60,55,.15)}' +
      '.lr75rHero b{font-size:1.18rem}.lr75rHero p{margin:.35rem 0 0;line-height:1.4}.lr75rHeroBtns,.lr75rInlineBtns{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.lr75rGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:10px;margin:10px 0 18px}.lr75rCard,.lr75rLesson{display:block;text-align:left;width:100%;border:2px solid #3b7f73;background:#f5fffb;border-radius:14px;padding:12px;cursor:pointer;color:#10261f;box-shadow:0 4px 10px rgba(20,70,60,.10)}' +
      '.lr75rCard:hover,.lr75rLesson:hover,.lr75rSmallBtn:hover{transform:translateY(-1px);filter:brightness(1.03)}.lr75rCard b,.lr75rLesson b{display:block;margin-bottom:4px}.lr75rCard small,.lr75rLesson small{display:block;color:#286352;margin-bottom:6px}.lr75rCard span,.lr75rLesson span{display:block;line-height:1.32}.lr75rDrawerCard{background:#fffdf2;border-color:#8d7a33}.lr75rSmallBtn{border:2px solid #286352;background:#f5fffb;border-radius:999px;padding:8px 11px;cursor:pointer;color:#10261f;font-weight:700}.lr75rNote{background:#fffdf2;border:2px dashed #6d8352;border-radius:14px;padding:14px;margin:12px 0}.lr75rLessonList{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}.lr75rPager{display:flex;gap:10px;align-items:center;justify-content:center;margin:14px 0;flex-wrap:wrap}.lr75rFoot{color:#286352}.lr75rAuditDoor{border-color:#2d7695!important;background:linear-gradient(135deg,#e5fbff,#fff9d8)!important}.lr75rLibraryTiny{font-size:.84rem;color:#286352;margin-top:4px;display:block}';
    document.head.appendChild(st);
  }

  function libraryCard(id, title, small, body, act, className){
    var btn = document.createElement('button');
    btn.id = id;
    btn.className = className || 'lr75aDoorCard lr75rAuditDoor';
    btn.setAttribute('data-lr75r-act', act);
    btn.innerHTML = '<b>' + esc(title) + '</b><small class="lr75rLibraryTiny">' + esc(small) + '</small><span>' + esc(body) + '</span>';
    return btn;
  }
  function hasText(node, re){ return re.test((node && node.textContent) || ''); }
  function addCard(grid, id, re, title, small, body, act){
    if(!grid || $(id) || (re && hasText(grid, re))) return;
    grid.appendChild(libraryCard(id, title, small, body, act));
  }
  function injectIntoRealmLibrary(root){
    var grid = root.querySelector('.lr75aDoorGrid');
    if(!grid || !/Science and Engineering Quarter|Nature|Weather|Animals|Inventions|Aerospace/i.test(root.textContent || '')) return;
    if(!$('lr75rScienceConnectedMapDoor')){
      grid.insertBefore(libraryCard('lr75rScienceConnectedMapDoor','🔬 Science and Engineering Connected Map','master roads plus old drawers','A safe 7.5R map for Science, Inventions, Aerospace, Nature/Health, Weather, Animals, Chemistry, Astronomy, Earth Science, Botany, Electricity, Physics, Computers, Dinosaurs, and Insects.','map'), grid.firstChild);
    }
    addCard(grid,'lr75rScienceRoadDoor',/Science and Engineering Expedition/i,'🔬 Science and Engineering Expedition','main quarter road','Observation, matter, forces, machines, energy, circuits, plants, habitats, and design.','road:science');
    addCard(grid,'lr75rChemistryDrawerDoor',/Chemistry Institute/i,'⚗️ Chemistry Institute Drawer','legacy drawer','Connects older chemistry rooms and routes back to the main Science Expedition.','drawer:chemistry:0');
    addCard(grid,'lr75rEarthDrawerDoor',/Earth Science Drawer/i,'🌎 Earth Science Drawer','legacy drawer','Connects rocks, minerals, erosion, weathering, volcanoes, and fossils.','drawer:earth:0');
    addCard(grid,'lr75rComputerDrawerDoor',/Robotics|Computer Science/i,'🤖 Robotics & Computer Science Drawer','legacy drawer','Connects robots, algorithms, commands, and older computer science practice.','drawer:computers:0');
  }
  function injectIntoAnnex(root){
    if(!/Science and Engineering Quarter Annex|Science and Engineering Quarter/i.test(root.textContent || '')) return;
    if($('lr75rAnnexMapStrip')) return;
    var target = root.querySelector('.lr75oHero,.lr75oWingHero,.lr75oShell') || root.firstElementChild || root;
    if(!target || !target.parentNode) return;
    var strip = document.createElement('div');
    strip.id = 'lr75rAnnexMapStrip';
    strip.className = 'lr75rNote';
    strip.innerHTML = '<b>🔬 7.5R Science Quarter cleanup</b><p>Science roads and older drawers now share one connected map so loose science buttons have a proper in-world home.</p><div class="lr75rInlineBtns">' + navButton('Open Science Connected Map','map') + navButton('Chemistry Drawer','drawer:chemistry:0') + navButton('Robotics Drawer','drawer:computers:0') + '</div>';
    target.parentNode.insertBefore(strip, target.nextSibling);
  }
  function injectIntoScienceRoad(root){
    if(!/Science and Engineering Quarter|Quarter Room Map|Science Quarter|Copper|laboratory|weather|engineering/i.test(root.textContent || '')) return;
    var grid = root.querySelector('.se74Grid,.lr74rGrid,.lr74sGrid,.lr74tGrid,.lr74uGrid,.lr74vGrid,.lrCourseDoorGrid');
    if(!grid || $('lr75rQuarterMapCard')) return;
    var btn = libraryCard('lr75rQuarterMapCard','🔬 Science and Engineering Connected Map','cleanup map','Jump to the tidy 7.5R map for master roads and older science drawers.','map','lr75rCard lr75rAuditDoor');
    grid.insertBefore(btn, grid.firstChild);
  }
  function routeLooseScienceButtons(root){
    var buttons = Array.prototype.slice.call(root.querySelectorAll('button'));
    buttons.forEach(function(btn){
      if(btn.hasAttribute('data-lr75r-act')) return;
      var text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
      if(!text || text.length > 120) return;
      var act = null;
      if(/Aerospace|Flight|Rocket|Mission Wing/i.test(text)) act = 'road:aerospace';
      else if(/Inventions|Engineering Disasters|Blueprint|Rebuild/i.test(text)) act = 'road:inventions';
      else if(/Weather|Storm|Stormwatch/i.test(text)) act = 'road:weather';
      else if(/Animal|Creature|Field Guide/i.test(text)) act = 'road:animals';
      else if(/Nature\s*\/\s*Health|Nature & Health|Health Lodge|Living Woods/i.test(text)) act = 'road:natureHealth';
      else if(/Chemistry|Chemical/i.test(text)) act = 'drawer:chemistry:0';
      else if(/Astronomy|Observatory|Deep Space|Space Observatory/i.test(text)) act = 'drawer:astronomy:0';
      else if(/Earth Science|Volcano|Rock|Fossil/i.test(text)) act = 'drawer:earth:0';
      else if(/Botany|Plant|Garden Grounds/i.test(text)) act = 'drawer:botany:0';
      else if(/Electricity|Circuit/i.test(text)) act = 'drawer:electricity:0';
      else if(/Physics|Force|Motion|Energy Station/i.test(text)) act = 'drawer:physics:0';
      else if(/Robotics|Computer Science|Coding/i.test(text)) act = 'drawer:computers:0';
      else if(/Dinosaur/i.test(text)) act = 'drawer:dinosaurs:0';
      else if(/Insect/i.test(text)) act = 'drawer:insects:0';
      else if(/^Science$|Science Practice|Science Drawer|Marsh Laboratory|Science Marsh/i.test(text)) act = 'map';
      if(!act) return;
      btn.setAttribute('data-lr75r-act', act);
      /* 7.6W: preserve onclick fallback */
      btn.classList.add('lr75rAuditDoor');
    });
  }
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(runInject, 80);
  }
  function runInject(){
    installStyles();
    var roots = [$('actionText'), $('lrPopupBody'), $('se74ModalRoot')].filter(function(x){ return !!x; });
    for(var i=0;i<roots.length;i++){
      injectIntoRealmLibrary(roots[i]);
      injectIntoAnnex(roots[i]);
      injectIntoScienceRoad(roots[i]);
      routeLooseScienceButtons(roots[i]);
    }
  }
  function wrap(name){
    if(!has(name) || window[name].__lr75rWrapped) return;
    var old = window[name];
    var wrapped = function(){
      var out = old.apply(this, arguments);
      scheduleInject();
      setTimeout(scheduleInject, 250);
      return out;
    };
    wrapped.__lr75rWrapped = true;
    window[name] = wrapped;
  }
  function bind(){
    if(window.__LR75R_BOUND__) return;
    window.__LR75R_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr75r-act]') : null;
      if(!btn) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAct(btn.getAttribute('data-lr75r-act'));
    }, true);
  }
  function installObserver(){
    if(obsInstalled) return;
    obsInstalled = true;
    if(typeof MutationObserver === 'undefined') return;
    var mo = new MutationObserver(function(){ scheduleInject(); });
    [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; }).forEach(function(target){
      try{ mo.observe(target, {childList:true, subtree:false}); }catch(e){}
    });
  }
  function init(){
    installStyles();
    bind();
    ['openRealmLibrary75A','openRealCurriculumPicker','openLearningCenterAnnex75O','openLearningCenterConnectionAudit75O','openScienceEngineeringAdventure74M','openScienceEngineeringQuarter74M','openInventionsEngineeringMaster74R','openAerospaceEngineering74S','openNatureHealthDeepAdventure','openWeatherStormLab74U','openCreatureFieldGuide'].forEach(wrap);
    installObserver();
    setTimeout(scheduleInject, 250);
    window.LR_SCIENCE_ENGINEERING_CONNECTION_CLEANUP_75R = { patch:PATCH, open:renderScienceMap, drawers:DRAWERS, roads:ROADS };
  }

  window.openScienceEngineeringConnectionCleanup75R = renderScienceMap;
  window.openScienceEngineeringCleanup75R = renderScienceMap;
  window.openScienceQuarterConnectedMap75R = renderScienceMap;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
