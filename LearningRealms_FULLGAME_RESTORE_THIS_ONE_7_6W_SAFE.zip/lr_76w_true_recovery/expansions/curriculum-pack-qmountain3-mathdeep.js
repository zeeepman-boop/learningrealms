// Question Mountain Phase 3 - Math Deepening
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Math",[
{teach:"Subtraction takes away.",q:"5 - 2 = ?",c:["3","2","4"],a:"3"},
{teach:"Skip count by twos.",q:"2,4,6,... next?",c:["8","7","9"],a:"8"},
{teach:"Shapes have sides.",q:"A square has...",c:["4 sides","3 sides","5 sides"],a:"4 sides"},
{teach:"Length can be measured.",q:"We measure...",c:["length","stories","songs"],a:"length"},
{teach:"Tens groups help counting.",q:"10 ones make a...",c:["ten","hundred","pair"],a:"ten"}
]);

LR_addLessons("Ava","Math",[
{teach:"Proportions compare equal ratios.",q:"Proportions compare...",c:["equal ratios","weather","titles"],a:"equal ratios"},
{teach:"Percents can show discounts.",q:"Percent can show...",c:["discounts","planets","maps"],a:"discounts"},
{teach:"Data can be graphed.",q:"Graphs show...",c:["data","music","stories"],a:"data"},
{teach:"Integers use number lines.",q:"Integers can be shown on...",c:["number lines","books","maps"],a:"number lines"},
{teach:"Probability uses outcomes.",q:"Probability uses...",c:["outcomes","covers","coins"],a:"outcomes"}
]);

LR_addLessons("Michael","Math",[
{teach:"Equations may need many steps.",q:"Multi step equations need...",c:["steps","paint","covers"],a:"steps"},
{teach:"Coordinate planes use axes.",q:"Coordinate planes use...",c:["axes","chapters","coins"],a:"axes"},
{teach:"Functions can be graphed.",q:"Functions may be...",c:["graphed","folded","hidden"],a:"graphed"},
{teach:"Statistics study data.",q:"Statistics study...",c:["data","weather only","titles"],a:"data"},
{teach:"Expressions can simplify.",q:"Expressions may...",c:["simplify","freeze","sleep"],a:"simplify"}
]);
})();