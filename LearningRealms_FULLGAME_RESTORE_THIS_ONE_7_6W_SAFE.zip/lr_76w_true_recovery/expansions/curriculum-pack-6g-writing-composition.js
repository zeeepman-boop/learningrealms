// Curriculum Pack 6G - Writing / Composition Foundation
(function(){
 if(typeof LR_addLessons!=="function") return;

 LR_addLessons("Luna","Writing",[
 {teach:"A sentence is a complete thought.",q:"What is a sentence?",c:["a complete thought","one random word","a picture"],a:"a complete thought"},
 {teach:"Sentences begin with a capital letter.",q:"What goes at the beginning?",c:["capital letter","period","space"],a:"capital letter"},
 {teach:"Sentences end with punctuation.",q:"What ends a sentence?",c:["punctuation","color","number"],a:"punctuation"},
 {teach:"People names use capitals.",q:"Which needs a capital?",c:["Luna","cat","tree"],a:"Luna"},
 {teach:"Stories have first, next, last.",q:"Which means the ending part?",c:["last","first","next"],a:"last"},
 {teach:"Describe things with details.",q:"Which adds detail?",c:["big red apple","apple","thing"],a:"big red apple"},
 {teach:"Spaces help us read words.",q:"Why use spaces?",c:["to separate words","for decoration","to count"],a:"to separate words"},
 {teach:"Questions end with question marks.",q:"What ends a question?",c:["?","!","."],a:"?"},
 {teach:"Excited sentences may use exclamation marks.",q:"Which shows excitement?",c:["!","?","."],a:"!"},
 {teach:"Good writers reread their work.",q:"What should writers do after writing?",c:["reread","hide it","erase all"],a:"reread"}
 ]);

 LR_addLessons("Ava","Writing",[
 {teach:"Paragraphs group related ideas.",q:"A paragraph contains...",c:["related ideas","random facts","only one word"],a:"related ideas"},
 {teach:"A topic sentence tells the main idea.",q:"What tells the main idea?",c:["topic sentence","title only","ending"],a:"topic sentence"},
 {teach:"Details support ideas.",q:"What supports ideas?",c:["details","blank space","colors"],a:"details"},
 {teach:"Transitions connect thoughts.",q:"Which is a transition?",c:["next","chair","river"],a:"next"},
 {teach:"Writers revise to improve.",q:"Revise means...",c:["improve writing","throw away","copy"],a:"improve writing"},
 {teach:"Strong endings wrap up ideas.",q:"What should endings do?",c:["wrap up ideas","start over","ask names"],a:"wrap up ideas"},
 {teach:"Narratives tell stories.",q:"A narrative is...",c:["a story","a list","a chart"],a:"a story"},
 {teach:"Informative writing teaches.",q:"Informative writing does what?",c:["teaches","jokes only","rhymes"],a:"teaches"},
 {teach:"Opinion writing gives reasons.",q:"Opinion writing needs...",c:["reasons","nothing","pictures only"],a:"reasons"},
 {teach:"Editing checks mistakes.",q:"Editing checks...",c:["mistakes","weather","maps"],a:"mistakes"}
 ]);

 LR_addLessons("Michael","Writing",[
 {teach:"A thesis states the main argument.",q:"What states the main argument?",c:["thesis","caption","heading"],a:"thesis"},
 {teach:"Outlines organize ideas.",q:"What organizes ideas?",c:["outline","eraser","title"],a:"outline"},
 {teach:"Evidence supports claims.",q:"Claims need...",c:["evidence","volume","length"],a:"evidence"},
 {teach:"Revision improves structure and clarity.",q:"Revision improves...",c:["structure and clarity","paper color","font only"],a:"structure and clarity"},
 {teach:"Essays have introduction, body, conclusion.",q:"Which belongs in an essay?",c:["introduction","random list","credits"],a:"introduction"},
 {teach:"Sources should be cited.",q:"What should sources do?",c:["be cited","be hidden","be ignored"],a:"be cited"},
 {teach:"Counterarguments strengthen writing.",q:"Counterarguments can...",c:["strengthen writing","erase evidence","replace thesis"],a:"strengthen writing"},
 {teach:"Transitions improve flow.",q:"Transitions improve...",c:["flow","speed only","page count"],a:"flow"},
 {teach:"Audience matters.",q:"Writers should think about...",c:["audience","favorite snack","shoe size"],a:"audience"},
 {teach:"Drafts are not final.",q:"A draft is...",c:["not final","finished forever","published"],a:"not final"}
 ]);
})();