/* LearningRealms 7.5T - Homestead / Living World Connection Cleanup
   Small bridge patch only. No shell rebuild, no render loop, no loading curtain.
   Purpose: gather Homestead Workshop, life-skills drawers, home systems, companions,
   collections, seasons, shops, rare rotations, birthdays, quests, and the Town Notice Board
   into one safe in-world map. */
(function(){
  'use strict';

  if(window.__LR75T_HOMESTEAD_LIVING_CLEANUP__) return;
  window.__LR75T_HOMESTEAD_LIVING_CLEANUP__ = true;

  var PATCH = '7.5T Homestead / Living World Connection Cleanup';
  var injectTimer = null;
  var obsInstalled = false;

  function $(id){ return document.getElementById(id); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }
  function smallText(v, max){
    var s = String(v || '').replace(/\s+/g, ' ').trim();
    if(!max || s.length <= max) return s;
    return s.slice(0, max - 1).trim() + '…';
  }
  function callFirst(names){
    for(var i=0;i<names.length;i++){
      var item = names[i];
      try{
        if(Array.isArray(item) && has(item[0])){
          window[item[0]].apply(window, item.slice(1));
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }
        if(typeof item === 'string' && has(item)){
          window[item]();
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }
      }catch(e){ console.warn('LR75T route failed:', item, e); }
    }
    return false;
  }
  function actionMount(title, html){
    installStyles();
    var titleEl = $('actionTitle');
    var textEl = $('actionText');
    if(titleEl) titleEl.textContent = title || 'Homestead Workshop';
    if(textEl) textEl.innerHTML = html || '';
    try{
      if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title || 'Homestead Workshop');
      else if(has('lrOpenPopup')) window.lrOpenPopup(title || 'Homestead Workshop', html || '');
    }catch(e){}
    scheduleInject();
  }

  var ROADS = [
    {
      key:'map', icon:'🏡', title:'Homestead / Living World Connected Map', place:'Town Hearth Map',
      body:'The safe gathering place for practical rooms, home systems, companions, shops, seasons, quests, rare finds, collections, and older life-skills drawers.',
      kind:'map'
    },
    {
      key:'homestead', icon:'🧰', title:'Homestead Workshop Adventure', place:'Hearth Road and Practical Rooms',
      body:'The 7.4O adventure road for kitchen safety, measuring, garden planning, animal care, repair, mending, cleaning, budgeting, first-aid signals, weather readiness, and display rooms.',
      calls:['openHomesteadWorkshopAdventure74O']
    },
    {
      key:'life', icon:'🕰️', title:'Life Skills Workshop Road', place:'Homestead Gate / Toolbox Trail',
      body:'The older LifeSkills RPG road with timekeeping, chore boards, sorting, safety, measuring, and practical problem-solving rooms.',
      rooms:['homesteadGate','homesteadRoad1','timekeepingPorch'], drawer:'life'
    },
    {
      key:'home', icon:'🏠', title:'Home Hearth and Room Displays', place:'Home rooms, storage, decor, and expansion',
      body:'Home view, rooms, placement, storage, decor, earned displays, and expansion stay connected here instead of being loose buttons.',
      calls:['openHomeRenderer','openHomeViewPopup','openHomeView','openVisibleHome','openHomeRooms','openVisualHome','openHomeExpansionPopup','openHomeExpansion2'], lr74l:'home'
    },
    {
      key:'living', icon:'📌', title:'Town Notice Board / Living World Ledger', place:'Notice Board beside the Homestead Road',
      body:'Seasons, events, birthdays, shops, rare rotations, companions, collections, home rewards, quests, and town records belong on this board.',
      calls:['openLivingWorldSurface75H','openLivingWorldLedger74L','openLivingWorld'], lr74l:'ledger'
    },
    {
      key:'shops', icon:'🛒', title:'Shopkeepers and Merchant Row', place:'Lantern-lit market street',
      body:'Shopkeepers, themed currencies, goal items, money lessons, merchant square, and the route to rare stock stay tied together.',
      calls:['lr69OpenMerchantSquare','openShopHub','openShop','lrSafeBrowseShopPopup','openShopPopup'], lr74l:'merchants', drawer:'merchant'
    },
    {
      key:'rare', icon:'✨', title:'Rare Finds and Rotations', place:'Mystery merchant corner',
      body:'Rare daily or rotating finds are reached through the market street so the special stock does not become a scattered side button.',
      calls:['lr69OpenMerchantSquare','openShopHub','openShop','lrSafeBrowseShopPopup'], lr74l:'rare'
    },
    {
      key:'companions', icon:'🐾', title:'Companion Den and Pet Corner', place:'Quiet den near the workshop yard',
      body:'Pets, companions, pet records, bond progress, care routines, and animal-care connections stay together.',
      calls:['openCompanionDen','openPetJournal','openCompanionPopup','openCompanionEngine'], lr74l:'companions', drawer:'animal'
    },
    {
      key:'collections', icon:'🎒', title:'Collection Log / Treasure Registry', place:'Artifact and treasure desk',
      body:'Artifacts, badges, collectibles, decor pieces, museum items, storage records, and earned trophies stay reachable from here.',
      calls:['openCollectionLog','openBackpack','openInventoryPopup','openAchievementJournal','openCastlePrestige'], lr74l:'collections'
    },
    {
      key:'quests', icon:'📜', title:'Quest Board and Story Records', place:'Pinned errand board',
      body:'Daily goals, story quests, long journeys, campaigns, and challenge records are gathered as a town board instead of a floating menu.',
      calls:['openQuestBoard','openDailyQuestBoard','openQuestJournal','openLongQuestJournal','openStoryQuestJournal','openQuestPopup'], lr74l:'quests'
    },
    {
      key:'seasons', icon:'🌿', title:'Seasons, Festivals, and Special Days', place:'Festival calendar table',
      body:'Seasonal events, festival paths, birthday/special-day hooks, parent reward codes, and celebration chests stay connected respectfully.',
      calls:['openSeasonHall','openSeasonalCalendar','openSeasonQuests','openRewardCodeRedeemer','openParentRewardVault'], lr74l:'seasons'
    }
  ];

  var DRAWERS = {
    life:{
      icon:'🧰', title:'Life Skills Practice Drawer',
      note:'Older life-skills material for time, calendars, routines, safety, chores, sorting, planning, practical choices, and everyday responsibility.',
      include:/life\s*skills|lifeskills|routine|chore|timekeeping|calendar|safety|helping|responsib|daily order|task|checklist|preparedness|maintenance|organization|organizing/i,
      files:['content_packs/life_skills_real_curriculum_pack1.json','content_packs/life_skills_kingdom_heavy.json','content_packs/life_skills_kingdom_explosion_pack1.json'],
      empty:'No loose Life Skills quick rooms were found in the active lesson bank. The subject still lives safely in the Homestead Workshop road and older LifeSkills RPG rooms.',
      buttons:[['Homestead Workshop','road:homestead'],['Life Skills Road','road:life'],['Town Notice Board','road:living']]
    },
    cooking:{
      icon:'🍳', title:'Cooking Guild Drawer',
      note:'Older cooking and kitchen-safety material for recipes, measuring, food prep, cleanliness, heat rules, pantry care, and kitchen planning.',
      include:/cooking|kitchen|recipe|food|pantry|measure|measuring|ingredient|heat|stove|oven|clean hands|preservation/i,
      files:['content_packs/cooking_guild_real_curriculum_pack1.json'],
      empty:'No loose Cooking Guild quick rooms were found. Cooking still belongs under Homestead Workshop through the kitchen, measuring, safety, and pantry rooms.',
      buttons:[['Homestead Workshop','road:homestead'],['Life Skills Drawer','drawer:life:0']]
    },
    repair:{
      icon:'🔧', title:'Repair Shop Drawer',
      note:'Older repair and workshop material for tools, materials, fixing, safe handling, measuring, sorting parts, and practical problem solving.',
      include:/repair|builder|workshop|tool|tools|material|fix|mending|wrench|screw|hammer|clamp|maintenance|wood|metal|fabric|glass/i,
      files:['content_packs/repair_shop_real_curriculum_pack1.json','content_packs/builder_workshop_real_curriculum_pack1.json'],
      empty:'No loose Repair Shop quick rooms were found. Repair still connects through Homestead Workshop tool rooms and materials shelves.',
      buttons:[['Homestead Workshop','road:homestead'],['Life Skills Road','road:life']]
    },
    garden:{
      icon:'🌻', title:'Farm and Garden Drawer',
      note:'Older garden, farm, soil, compost, weather-readiness, plant care, animal-care, and seasonal work material.',
      include:/farm|garden|seed|soil|compost|plant|watering|weather-ready|animal_care|animal care|brooder|nesting|duckling|chick|crop|season/i,
      files:['content_packs/farm_valley_real_curriculum_pack1.json','content_packs/farm_valley_explosion_pack1.json','content_packs/garden_grounds_real_curriculum_pack1.json','content_packs/animal_care_real_curriculum_pack1.json'],
      empty:'No loose Farm and Garden quick rooms were found. Garden, soil, animal care, brooder, and weather-ready rooms stay available through Homestead Workshop.',
      buttons:[['Homestead Workshop','road:homestead'],['Companion Den','road:companions'],['Seasons','road:seasons']]
    },
    animal:{
      icon:'🐾', title:'Animal Care Drawer',
      note:'Animal-care material for gentle handling, clean water, safe shelter, routines, observation, companion care, and brooder basics.',
      include:/animal care|animal_care|animal|companion|pet|pets|brooder|nesting|duckling|chick|water dish|feed|shelter|gentle care/i,
      files:['content_packs/animal_care_real_curriculum_pack1.json'],
      empty:'No loose Animal Care quick rooms were found. Animal care remains connected through Homestead Workshop and Companion Den.',
      buttons:[['Companion Den','road:companions'],['Farm and Garden','drawer:garden:0'],['Homestead Workshop','road:homestead']]
    },
    budget:{
      icon:'🧾', title:'Budget Borough Drawer',
      note:'Older budget and household-planning material for needs, wants, saving, spending, supply lists, repair notes, pantry counts, and wise choices.',
      include:/budget|budgeting|money|saving|spend|spending|needs|wants|household planning|supplies|resources|tradeoff|choice/i,
      files:['content_packs/budget_borough_real_curriculum_pack1.json'],
      empty:'No loose Budget Borough quick rooms were found. Budget planning still belongs under Homestead Workshop and the Merchant Row connection.',
      buttons:[['Homestead Workshop','road:homestead'],['Merchant Row','road:shops']]
    },
    merchant:{
      icon:'🏪', title:'Merchant Square Drawer',
      note:'Older merchant material for shops, vendors, goods, services, trade, currencies, money choices, and shopkeeper goals.',
      include:/merchant|shop|vendor|market|goods|services|currency|trade|economy|price|supply|demand/i,
      files:['content_packs/merchant_square_real_curriculum_pack1.json','content_packs/merchant_economy_shop_engine_pack.json'],
      empty:'No loose Merchant Square quick rooms were found. Shopkeepers and rare rotations still route through Merchant Row and the Living World Ledger.',
      buttons:[['Merchant Row','road:shops'],['Rare Finds','road:rare'],['Town Notice Board','road:living']]
    }
  };

  function roadByKey(key){
    for(var i=0;i<ROADS.length;i++) if(ROADS[i].key === key) return ROADS[i];
    return null;
  }
  function navButton(label, act){
    return '<button class="lr75tSmallBtn" data-lr75t-act="' + esc(act) + '">' + esc(label) + '</button>';
  }
  function roadButton(r){
    return '<button class="lr75tCard" data-lr75t-act="road:' + esc(r.key) + '">' +
      '<b>' + esc(r.icon + ' ' + r.title) + '</b>' +
      '<small>' + esc(r.place) + '</small>' +
      '<span>' + esc(r.body) + '</span>' +
    '</button>';
  }
  function drawerButton(key){
    var d = DRAWERS[key];
    if(!d) return '';
    return '<button class="lr75tCard lr75tDrawerCard" data-lr75t-act="drawer:' + esc(key) + ':0">' +
      '<b>' + esc(d.icon + ' ' + d.title) + '</b>' +
      '<small>Connected older homestead drawer</small>' +
      '<span>' + esc(d.note) + '</span>' +
    '</button>';
  }

  function renderHomesteadMap(){
    installStyles();
    actionMount('🏡 Homestead / Living World Connected Map',
      '<div class="lr75tShell">' +
        '<div class="lr75tHero">' +
          '<div><b>🏡 Homestead / Living World Connected Map</b><p>This is a routing cleanup, not a new course. Homestead Workshop, LifeSkills rooms, home systems, companions, collections, seasons, shops, rare rotations, birthdays, quests, and older practical drawers now share one tidy town map.</p></div>' +
          '<div class="lr75tHeroBtns">' + navButton('Realm Library','library') + navButton('7.5O Connection Ledger','ledger') + navButton('Town Notice Board','road:living') + '</div>' +
        '</div>' +
        '<h3>Main homestead and living-world roads</h3>' +
        '<div class="lr75tGrid lr75tRoadGrid">' + ROADS.filter(function(r){ return r.key !== 'map'; }).map(roadButton).join('') + '</div>' +
        '<h3>Connected practical drawers</h3>' +
        '<div class="lr75tGrid">' + ['life','cooking','repair','garden','animal','budget','merchant'].map(drawerButton).join('') + '</div>' +
        '<div class="lr75tNote"><b>What 7.5T does</b><p>Visible Homestead and Living World buttons now have a safer home. Practical lessons stay in Homestead Workshop or drawers, while living systems stay on the Town Notice Board instead of becoming scattered menu clutter.</p></div>' +
      '</div>'
    );
  }

  function getRooms(){
    var rooms = [];
    try{ if(window.ROOMS) rooms.push(window.ROOMS); }catch(e){}
    try{ if(typeof ROOMS !== 'undefined') rooms.push(ROOMS); }catch(e){}
    try{ if(window.LR_ROOMS) rooms.push(window.LR_ROOMS); }catch(e){}
    return rooms;
  }
  function roomExists(id){
    var rs = getRooms();
    for(var i=0;i<rs.length;i++) if(rs[i] && rs[i][id]) return true;
    return false;
  }
  function goRoom(targets, note){
    targets = targets || [];
    var target = null;
    for(var i=0;i<targets.length;i++) if(roomExists(targets[i])){ target = targets[i]; break; }
    if(!target) return false;
    try{ if(window.LR68A && typeof window.LR68A.goTo === 'function') return !!window.LR68A.goTo(target); }catch(e){}
    try{ if(typeof window.lr68aGoTo === 'function') return !!window.lr68aGoTo(target); }catch(e){}
    var s = null;
    try{ s = window.state || (typeof state !== 'undefined' ? state : null); }catch(e){}
    if(s){
      try{ s.loc = target; s.room = Math.max(1, Number(s.room || 1)) + 1; }catch(e){}
      try{ if(typeof window.save === 'function') window.save(); else if(typeof save === 'function') save(); }catch(e){}
      try{ if(typeof window.renderStats === 'function') window.renderStats(); else if(typeof renderStats === 'function') renderStats(); }catch(e){}
      try{ if(typeof window.lr68Render === 'function') return !!window.lr68Render('room', note || 'You step onto the Homestead Workshop road.'); }catch(e){}
      try{ if(typeof window.lr67RenderDynamicScreen === 'function') return !!window.lr67RenderDynamicScreen('room', note || 'You step onto the Homestead Workshop road.'); }catch(e){}
      try{ if(typeof window.renderRoom === 'function') return !!window.renderRoom(); }catch(e){}
    }
    return false;
  }

  function openRoad(key){
    var r = roadByKey(key);
    if(!r || r.kind === 'map'){ renderHomesteadMap(); return; }
    if(r.lr74l && has('lr74lRoute')){
      try{ window.lr74lRoute(r.lr74l); scheduleInject(); setTimeout(scheduleInject, 180); return; }catch(e){}
    }
    if(r.rooms && goRoom(r.rooms, 'You walk toward the Homestead Workshop road.')) return;
    if(callFirst(r.calls || [])) return;
    if(r.drawer){ renderDrawer(r.drawer, 0); return; }
    softNote(r.title, 'This Homestead or Living World road is listed in the connected map, but its direct opener did not answer in this build. It remains an in-world signpost instead of a dead button.', [['Back to Homestead Map','map']]);
  }

  function lessonText(l){ return [l.source_pack,l.pack_region,l.region,l.mastery_tag,l.topic,l.skill,l.unit,l.question,l.explanation,l.prompt,l.miniLesson,l.workedExample,l.teach,l.q].join(' '); }
  function lessonMatches(l, drawer){ return !!(drawer && drawer.include && drawer.include.test(lessonText(l))); }
  async function getBank(){
    if(has('lrLoadRealCurriculumBank')){
      try{ return await window.lrLoadRealCurriculumBank(); }catch(e){}
    }
    return window.__lrRealCurriculumBank || [];
  }
  async function fetchPackSummary(file){
    try{
      var res = await fetch(file);
      if(!res.ok) return null;
      var data = await res.json();
      var zones = data && data.zones ? Object.keys(data.zones).slice(0,8) : [];
      var lessons = data && Array.isArray(data.lessons) ? data.lessons.length : (data && data.lesson_count ? data.lesson_count : 0);
      return {file:file, region:(data && (data.region || data.title)) || file.replace(/^content_packs\//,''), zones:zones, lessons:lessons, reward:(data && (data.achievement || data.museum || data.boss_exam || data.reward)) || ''};
    }catch(e){ return null; }
  }
  async function openDrawer(key, page){ return renderDrawer(key, page); }
  async function renderDrawer(key, page){
    installStyles();
    var d = DRAWERS[key];
    if(!d){ renderHomesteadMap(); return false; }
    page = Math.max(0, parseInt(page || 0, 10) || 0);
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75tShell"><div class="lr75tHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>Searching the existing lesson bank and pack notes for older homestead material. No new course is being added.</p></div></div><p class="lr75tFoot">Loading connected drawer…</p></div>'
    );
    var bank = await getBank();
    var matches = (bank || []).filter(function(l){ return lessonMatches(l, d); });
    var per = 12;
    var pages = Math.max(1, Math.ceil(matches.length / per));
    if(page >= pages) page = pages - 1;
    var sample = matches.slice(page * per, page * per + per);
    var packSummaries = [];
    for(var i=0;i<(d.files || []).length;i++){
      var summary = await fetchPackSummary(d.files[i]);
      if(summary) packSummaries.push(summary);
    }
    if(!sample.length && !packSummaries.length){
      actionMount(d.icon + ' ' + d.title,
        '<div class="lr75tShell">' +
          '<div class="lr75tHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p></div><div class="lr75tHeroBtns">' + navButton('Homestead Map','map') + '</div></div>' +
          '<div class="lr75tNote"><b>In-world route note</b><p>' + esc(d.empty) + '</p><div class="lr75tInlineBtns">' + (d.buttons || [['Back to Homestead Map','map']]).map(function(b){ return navButton(b[0], b[1]); }).join('') + navButton('Back to Homestead Map','map') + '</div></div>' +
        '</div>'
      );
      return false;
    }
    var lessonCards = sample.map(function(l){
      var idx = bank.indexOf(l);
      return '<button class="lr75tLesson" data-lr75t-act="lesson:' + idx + '"><b>' + esc(l.region || l.pack_region || l.unit || 'Homestead lesson') + '</b><small>' + esc(l.mastery_tag || l.source_pack || l.skill || l.topic || 'practice') + '</small><span>' + esc(smallText(l.question || l.q || l.explanation || l.prompt || l.miniLesson || l.teach || '', 170)) + '</span></button>';
    }).join('');
    var packCards = packSummaries.map(function(p){
      return '<div class="lr75tPack"><b>' + esc(p.region) + '</b><small>' + esc(p.file.replace('content_packs/','')) + '</small><p>' + esc((p.lessons ? p.lessons + ' entries. ' : '') + (p.reward || '')) + '</p>' + (p.zones.length ? '<p><b>Zones:</b> ' + p.zones.map(esc).join(' · ') + '</p>' : '') + '</div>';
    }).join('');
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75tShell">' +
        '<div class="lr75tHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p><p><small>' + matches.length + ' connected quick room' + (matches.length === 1 ? '' : 's') + ' found · ' + packSummaries.length + ' pack note' + (packSummaries.length === 1 ? '' : 's') + '</small></p></div><div class="lr75tHeroBtns">' + navButton('Homestead Map','map') + '</div></div>' +
        (lessonCards ? '<div class="lr75tLessonList">' + lessonCards + '</div>' : '<div class="lr75tNote"><b>No one-question rooms found</b><p>' + esc(d.empty) + '</p></div>') +
        (packCards ? '<div class="lr75tPackList"><h3>Pack notes and zones</h3>' + packCards + '</div>' : '') +
        '<div class="lr75tPager">' + (page > 0 ? navButton('← Previous','drawer:' + key + ':' + (page - 1)) : '') + '<span>Page ' + (page + 1) + ' of ' + pages + '</span>' + (page < pages - 1 ? navButton('Next →','drawer:' + key + ':' + (page + 1)) : '') + '</div>' +
      '</div>'
    );
    return true;
  }

  function softNote(title, body, buttons){
    installStyles();
    buttons = buttons || [['Back to Homestead Map','map']];
    actionMount(title || 'Homestead Route Note',
      '<div class="lr75tShell"><div class="lr75tNote"><b>' + esc(title || 'Homestead Route Note') + '</b><p>' + esc(body || '') + '</p><div class="lr75tInlineBtns">' + buttons.map(function(b){ return navButton(b[0], b[1]); }).join('') + '</div></div></div>'
    );
  }

  function openLesson(idx){
    idx = parseInt(idx, 10);
    if(!isFinite(idx) || idx < 0){ softNote('Lesson route note','That older homestead lesson pointer was not available.', [['Back to Homestead Map','map']]); return; }
    if(has('lrOpenRealLessonByIndex')){
      window.lrOpenRealLessonByIndex(idx);
      setTimeout(function(){
        var at = $('actionText');
        if(!at) return;
        var btns = at.querySelectorAll('button');
        for(var i=0;i<btns.length;i++){
          if(/Back to REAL Curriculum|Back to Curriculum|Return to Library/i.test(btns[i].textContent || '')){
            btns[i].setAttribute('data-lr75t-act','map');
            btns[i].removeAttribute('onclick');
            btns[i].textContent = 'Back to Homestead Map';
          }
        }
      }, 80);
      return;
    }
    softNote('Lesson route note','The authored lesson opener was not available in this build.', [['Back to Homestead Map','map']]);
  }

  function handleAct(act){
    if(!act) return;
    if(act === 'map'){ renderHomesteadMap(); return; }
    if(act === 'library'){
      if(has('openRealmLibrary75A')){ window.openRealmLibrary75A('homestead'); scheduleInject(); return; }
      if(has('openRealCurriculumPicker')){ window.openRealCurriculumPicker('life'); scheduleInject(); return; }
      renderHomesteadMap(); return;
    }
    if(act === 'ledger'){
      if(has('openLearningCenterAnnex75O')){ window.openLearningCenterAnnex75O('homestead'); scheduleInject(); return; }
      if(has('openLearningCenterConnectionAudit75O')){ window.openLearningCenterConnectionAudit75O(); scheduleInject(); return; }
      renderHomesteadMap(); return;
    }
    if(act.indexOf('road:') === 0){ openRoad(act.split(':')[1]); return; }
    if(act.indexOf('drawer:') === 0){ var bits = act.split(':'); renderDrawer(bits[1], bits[2] || 0); return; }
    if(act.indexOf('lesson:') === 0){ openLesson(act.split(':')[1]); return; }
  }

  function installStyles(){
    if($('lr75tStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr75tStyles';
    st.textContent =
      '.lr75tShell{padding:14px;color:#2b1a0b}.lr75tHero{display:flex;gap:12px;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#fff3d7,#e8ffe6);border:2px solid #7a6a2d;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 8px 20px rgba(55,45,20,.14)}' +
      '.lr75tHero b{font-size:1.18rem}.lr75tHero p{margin:.35rem 0 0;line-height:1.4}.lr75tHeroBtns,.lr75tInlineBtns{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.lr75tGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin:10px 0 18px}.lr75tCard,.lr75tLesson{display:block;text-align:left;width:100%;border:2px solid #8f7131;background:#fffaf0;border-radius:14px;padding:12px;cursor:pointer;color:#2b1a0b;box-shadow:0 4px 10px rgba(55,45,20,.10)}' +
      '.lr75tCard:hover,.lr75tLesson:hover,.lr75tSmallBtn:hover{transform:translateY(-1px);filter:brightness(1.03)}.lr75tCard b,.lr75tLesson b{display:block;margin-bottom:4px}.lr75tCard small,.lr75tLesson small{display:block;color:#6d5520;margin-bottom:6px}.lr75tCard span,.lr75tLesson span{display:block;line-height:1.32}.lr75tDrawerCard{background:#fffdf6;border-color:#7f7a3e}.lr75tSmallBtn{border:2px solid #775a25;background:#fffaf0;border-radius:999px;padding:8px 11px;cursor:pointer;color:#2b1a0b;font-weight:700}.lr75tNote{background:#fffdf6;border:2px dashed #8a7b44;border-radius:14px;padding:14px;margin:12px 0}.lr75tLessonList{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}.lr75tPager{display:flex;gap:10px;align-items:center;justify-content:center;margin:14px 0;flex-wrap:wrap}.lr75tFoot{color:#6d5520}.lr75tPackList{background:#fffdf6;border:2px solid #d1b879;border-radius:14px;padding:12px;margin-top:12px}.lr75tPack{border-top:1px solid #dac68d;padding:10px 0}.lr75tPack:first-of-type{border-top:0}.lr75tPack b{display:block}.lr75tPack small{display:block;color:#6d5520;margin:3px 0}.lr75tPack p{margin:5px 0}.lr75tAuditDoor{border-color:#7a6a2d!important;background:linear-gradient(135deg,#fff3d7,#e8ffe6)!important}.lr75tLibraryTiny{font-size:.84rem;color:#6d5520;margin-top:4px;display:block}';
    document.head.appendChild(st);
  }

  function libraryCard(id, title, small, body, act, className){
    var btn = document.createElement('button');
    btn.id = id;
    btn.className = className || 'lr75aDoorCard lr75tAuditDoor';
    btn.setAttribute('data-lr75t-act', act);
    btn.innerHTML = '<b>' + esc(title) + '</b><small class="lr75tLibraryTiny">' + esc(small) + '</small><span>' + esc(body) + '</span>';
    return btn;
  }
  function hasText(node, re){ return re.test((node && node.textContent) || ''); }
  function addCard(grid, id, re, title, small, body, act){
    if(!grid || $(id) || (re && hasText(grid, re))) return;
    grid.appendChild(libraryCard(id, title, small, body, act));
  }
  function injectIntoRealmLibrary(root){
    var grid = root.querySelector('.lr75aDoorGrid');
    if(!grid || !/Homestead Workshop|Living World|Life skills|Town Notice Board|companions|collections/i.test(root.textContent || '')) return;
    if(!$('lr75tHomesteadConnectedMapDoor')){
      grid.insertBefore(libraryCard('lr75tHomesteadConnectedMapDoor','🏡 Homestead / Living World Connected Map','workshop, home systems, town systems, drawers','A safe 7.5T map for Homestead Workshop, LifeSkills rooms, home, companions, collections, seasons, shops, rare finds, quests, birthdays, and older practical drawers.','map'), grid.firstChild);
    }
    addCard(grid,'lr75tLivingDoor',/Town Notice Board|Living World Ledger/i,'📌 Town Notice Board / Living World Ledger','seasons · shops · quests · home','Open the protected living-world hub instead of scattering those systems across loose buttons.','road:living');
    addCard(grid,'lr75tLifeDrawerDoor',/Life Skills Practice Drawer/i,'🧰 Life Skills Practice Drawer','older practical shelves','Connects older life-skills, routines, safety, time, and responsibility practice.','drawer:life:0');
    addCard(grid,'lr75tCookingDrawerDoor',/Cooking Guild Drawer/i,'🍳 Cooking Guild Drawer','older kitchen shelves','Connects cooking, measuring, pantry, food, and kitchen-safety practice.','drawer:cooking:0');
    addCard(grid,'lr75tRepairDrawerDoor',/Repair Shop Drawer/i,'🔧 Repair Shop Drawer','older tool shelves','Connects tools, repair, materials, mending, and practical workshop practice.','drawer:repair:0');
    addCard(grid,'lr75tGardenDrawerDoor',/Farm and Garden Drawer/i,'🌻 Farm and Garden Drawer','older garden shelves','Connects farm, garden, soil, compost, animal care, and seasonal practical work.','drawer:garden:0');
  }
  function injectIntoAnnex(root){
    if(!/Homestead Workshop|Living World|Town Notice Board|Life Practice Drawer/i.test(root.textContent || '')) return;
    if($('lr75tAnnexMapStrip')) return;
    var target = root.querySelector('.lr75oHero,.lr75oWingHero,.lr75oShell') || root.firstElementChild || root;
    if(!target || !target.parentNode) return;
    var strip = document.createElement('div');
    strip.id = 'lr75tAnnexMapStrip';
    strip.className = 'lr75tNote';
    strip.innerHTML = '<b>🏡 7.5T Homestead / Living World cleanup</b><p>Homestead Workshop, LifeSkills rooms, home systems, seasons, shopkeepers, rare finds, companions, collections, quests, birthdays, and old practical drawers now share one connected town map.</p><div class="lr75tInlineBtns">' + navButton('Open Homestead Connected Map','map') + navButton('Cooking Drawer','drawer:cooking:0') + navButton('Town Notice Board','road:living') + navButton('Companion Den','road:companions') + '</div>';
    target.parentNode.insertBefore(strip, target.nextSibling);
  }
  function injectIntoHomesteadRoad(root){
    if(!/Homestead Workshop|Kitchen Safety|Garden Planning|Animal Care|Tool Bench|Budget Jar|Companion Den|Home Display/i.test(root.textContent || '')) return;
    if(root.querySelector('.lr74oTopic')) return;
    var grid = root.querySelector('.lr74oGrid,.lrCourseDoorGrid,.lr74kChoices,.lr75aDoorGrid');
    if(!grid || $('lr75tHomesteadMapCard')) return;
    var btn = libraryCard('lr75tHomesteadMapCard','🏡 Homestead / Living World Connected Map','cleanup map','Jump to the tidy 7.5T map for practical roads, home systems, living-world doors, and older drawers.','map','lr75tCard lr75tAuditDoor');
    grid.insertBefore(btn, grid.firstChild);
  }
  function routeLooseHomesteadButtons(root){
    if(root.querySelector('.lr74oTopic')) return;
    var buttons = Array.prototype.slice.call(root.querySelectorAll('button'));
    buttons.forEach(function(btn){
      if(btn.hasAttribute('data-lr75t-act')) return;
      if(btn.closest && btn.closest('.lr74oTopic')) return;
      var text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
      if(!text || text.length > 140) return;
      var act = null;
      if(/Homestead \/ Living World|Homestead Connected Map|Connected Map/i.test(text)) act = 'map';
      else if(/Homestead Workshop Adventure|Homestead Workshop|Life Skills Workshop/i.test(text)) act = /Life Skills/i.test(text) ? 'road:life' : 'road:homestead';
      else if(/Town Notice Board|Living World Ledger|Living World|Notice Board/i.test(text)) act = 'road:living';
      else if(/Festival Board|Seasonal Calendar|Seasons|Season Hall|Festival|Birthday|Special Day|Reward Code|Parent Reward/i.test(text)) act = 'road:seasons';
      else if(/Seasonal Market/i.test(text)) act = 'road:shops';
      else if(/Merchant Row|Shopkeepers|Shops|Market Street|Merchant Square/i.test(text)) act = 'road:shops';
      else if(/Rare Finds|Rare Rotations|Mystery Merchant/i.test(text)) act = 'road:rare';
      else if(/Companion Den|Pet Corner|Companions|Pets/i.test(text)) act = 'road:companions';
      else if(/Collection Log|Treasure Registry|Collections|Inventory|Artifacts/i.test(text)) act = 'road:collections';
      else if(/Quest Board|Quests|Daily Quest|Story Quest|Long Journey/i.test(text)) act = 'road:quests';
      else if(/Home Hearth|Home View|Home Rooms|View Home|Expand Home|Home Display|Home Decor|Home Placement/i.test(text)) act = 'road:home';
      else if(/Cooking Guild|Kitchen|Recipe|Measuring Pantry/i.test(text)) act = 'drawer:cooking:0';
      else if(/Repair Shop|Tool Bench|Tool Shed|Mending|Materials Shelf/i.test(text)) act = 'drawer:repair:0';
      else if(/Farm|Garden|Soil|Compost|Animal Care|Brooder/i.test(text)) act = /Animal Care|Brooder/i.test(text) ? 'drawer:animal:0' : 'drawer:garden:0';
      else if(/Budget Borough|Budget Jar|Household Planning/i.test(text)) act = 'drawer:budget:0';
      else if(/Life Practice Drawer|Life Skills|Chore|Safety Barn|Sorting Loft/i.test(text)) act = 'drawer:life:0';
      if(!act) return;
      btn.setAttribute('data-lr75t-act', act);
      /* 7.6W: preserve onclick fallback */
      btn.classList.add('lr75tAuditDoor');
    });
  }
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(runInject, 80);
  }
  function runInject(){
    installStyles();
    var roots = [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; });
    for(var i=0;i<roots.length;i++){
      injectIntoRealmLibrary(roots[i]);
      injectIntoAnnex(roots[i]);
      injectIntoHomesteadRoad(roots[i]);
      routeLooseHomesteadButtons(roots[i]);
    }
  }
  function wrap(name){
    if(!has(name) || window[name].__lr75tWrapped) return;
    var old = window[name];
    var wrapped = function(){
      var out = old.apply(this, arguments);
      scheduleInject();
      setTimeout(scheduleInject, 250);
      return out;
    };
    wrapped.__lr75tWrapped = true;
    window[name] = wrapped;
  }
  function bind(){
    if(window.__LR75T_BOUND__) return;
    window.__LR75T_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr75t-act]') : null;
      if(!btn) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAct(btn.getAttribute('data-lr75t-act'));
    }, true);
  }
  function installObserver(){
    if(obsInstalled) return;
    obsInstalled = true;
    if(typeof MutationObserver === 'undefined') return;
    var mo = new MutationObserver(function(){ scheduleInject(); });
    [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; }).forEach(function(target){
      try{ mo.observe(target, {childList:true, subtree:false}); }catch(e){}
    });
  }
  function init(){
    installStyles();
    bind();
    ['openRealmLibrary75A','openRealCurriculumPicker','openLearningCenterAnnex75O','openLearningCenterConnectionAudit75O','openHomesteadWorkshopAdventure74O','openCreativeHomesteadAdventure74O','openLivingWorldSurface75H','openLivingWorldLedger74L','openHomeRenderer','openHomeView','openHomeViewPopup','openCollectionLog','openCompanionDen','openQuestBoard','openSeasonHall','lr69OpenMerchantSquare'].forEach(wrap);
    installObserver();
    setTimeout(scheduleInject, 250);
    window.LR_HOMESTEAD_LIVING_WORLD_CONNECTION_CLEANUP_75T = { patch:PATCH, open:renderHomesteadMap, drawers:DRAWERS, roads:ROADS };
  }

  window.openHomesteadLivingWorldConnectionCleanup75T = renderHomesteadMap;
  window.openHomesteadLivingWorldCleanup75T = renderHomesteadMap;
  window.openHomesteadConnectedMap75T = renderHomesteadMap;
  window.openHomesteadWorkshopConnectedMap75T = renderHomesteadMap;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
