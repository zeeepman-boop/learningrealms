// Curriculum Pack 4B: Unit-Tagged Checkpoints
// Small tagged checkpoint pack to deepen unit progress.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Reading",[
 {unit:"G1-READ-PHONICS",skill:"sight words",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Some words should be read quickly by sight.",practice:"said, was, they",q:"Which word is a sight word?",c:["said","zog","mip"],a:"said"},
 {unit:"G1-READ-PHONICS",skill:"word families",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Word families share ending sounds.",practice:"cat, hat, sat",q:"Which word belongs with cat and hat?",c:["sat","ship","tree"],a:"sat"},
 {unit:"G1-READ-COMP",skill:"sequence",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Sequence means the order things happen.",practice:"First seed, next sprout, last flower.",q:"Which comes first?",c:["seed","flower","bee"],a:"seed"},
 {unit:"G1-READ-COMP",skill:"details",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Details tell more about the main idea.",practice:"The owl had bright silver feathers.",q:"Which is a detail?",c:["silver feathers","owl story","book"],a:"silver feathers"},
 {unit:"G1-READ-FLUENCY",skill:"sentence reading",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Read the whole sentence to understand it.",practice:"The frog jumped into the pond.",q:"Where did the frog jump?",c:["pond","tree","gate"],a:"pond"}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-SENTENCES",skill:"punctuation",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A question ends with a question mark.",practice:"Where is the rabbit?",q:"Which mark ends a question?",c:["?","!","."],a:"?"},
 {unit:"G1-ELA-SENTENCES",skill:"verbs",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A verb shows action.",practice:"run, jump, read",q:"Which word is a verb?",c:["jump","green","table"],a:"jump"},
 {unit:"G1-ELA-WRITING",skill:"because answers",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Because can tell why.",practice:"The rabbit hid because it heard thunder.",q:"Which word tells why?",c:["because","the","rabbit"],a:"because"}
]);

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"doubles",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Doubles add the same number twice.",practice:"7 + 7 = 14.",q:"7 + 7 = ?",c:["14","13","15"],a:"14"},
 {unit:"G1-MATH-PLACE",skill:"compare numbers",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Greater means bigger.",practice:"58 is greater than 45.",q:"Which number is greater?",c:["58","45","same"],a:"58"},
 {unit:"G1-MATH-MEASURE",skill:"time",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Half past means 30 minutes after the hour.",practice:"Half past 4 is 4:30.",q:"Half past 4 is...",c:["4:30","4:00","5:30"],a:"4:30"},
 {unit:"G1-MATH-MEASURE",skill:"2D shapes",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A triangle has 3 sides.",practice:"Count each side.",q:"How many sides does a triangle have?",c:["3","4","5"],a:"3"}
]);

LR_addLessons("Luna","Science",[
 {unit:"G1-SCI-LIFE",skill:"animal groups",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Birds have feathers.",practice:"An owl is a bird.",q:"Which group has feathers?",c:["birds","fish","reptiles"],a:"birds"},
 {unit:"G1-SCI-PHYSICAL",skill:"sound",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Sound comes from vibrations.",practice:"A drum vibrates when hit.",q:"Sound comes from...",c:["vibrations","shadows","roots"],a:"vibrations"}
]);

LR_addLessons("Luna","History",[
 {unit:"G1-SS-MAPS",skill:"timelines",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A timeline shows events in order.",practice:"First, next, last.",q:"A timeline shows...",c:["order","sound","weight"],a:"order"}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-RATIO",skill:"constant of proportionality",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: In y = kx, k is the constant of proportionality.",practice:"In y = 5x, k is 5.",q:"In y = 5x, k = ?",c:["5","x","y"],a:"5"},
 {unit:"G7-MATH-INT",skill:"integer subtraction",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Subtracting an integer means adding its opposite.",practice:"8 - (-3) = 11.",q:"8 - (-3) = ?",c:["11","5","-11"],a:"11"},
 {unit:"G7-MATH-EQ",skill:"inequalities",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Dividing by a negative flips an inequality sign.",practice:"-2x > 10 becomes x < -5.",q:"When dividing by a negative, the inequality sign...",c:["flips","stays","vanishes"],a:"flips"},
 {unit:"G7-MATH-GEO-DATA",skill:"mean",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Mean is the average.",practice:"3, 6, 9 average to 6.",q:"Mean of 3, 6, 9?",c:["6","3","9"],a:"6"},
 {unit:"G7-MATH-GEO-DATA",skill:"probability",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Probability compares favorable outcomes to total outcomes.",practice:"Heads on a coin is 1 out of 2.",q:"Probability of heads on a fair coin?",c:["1 out of 2","2 out of 1","0 out of 2"],a:"1 out of 2"}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-EVIDENCE",skill:"central idea",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Central idea is the main point of nonfiction.",practice:"A passage explains how storms form.",q:"Central idea means...",c:["main point","tiny detail","page number"],a:"main point"},
 {unit:"G7-ELA-WRITING",skill:"reasoning",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Reasoning explains how evidence proves a claim.",practice:"This shows the character changed because...",q:"Reasoning explains why evidence...",c:["matters","is deleted","is random"],a:"matters"},
 {unit:"G7-ELA-LANGUAGE",skill:"prefixes",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A prefix comes before a root word.",practice:"replay has prefix re.",q:"In replay, the prefix is...",c:["re","play","lay"],a:"re"}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-LIFE",skill:"food webs",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Food webs show connected feeding relationships.",practice:"Grass feeds rabbits, rabbits feed foxes.",q:"A food web shows...",c:["feeding relationships","punctuation","taxes"],a:"feeding relationships"},
 {unit:"G7-SCI-EARTH",skill:"water cycle",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Water cycle steps include evaporation, condensation, and precipitation.",practice:"Rain is precipitation.",q:"Rain is...",c:["precipitation","evaporation","photosynthesis"],a:"precipitation"},
 {unit:"G7-SCI-PHYSICAL",skill:"data tables",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Data tables organize observations.",practice:"Rows and columns hold measurements.",q:"Data tables organize...",c:["observations","opinions only","characters"],a:"observations"}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"fact vs opinion",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A fact can be proven true or false.",practice:"The town was founded in 1802.",q:"A fact can be...",c:["proven","only felt","never checked"],a:"proven"},
 {unit:"G7-SS-CIVICS",skill:"limited government",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Limited government means power is restricted by law.",practice:"The Constitution limits government power.",q:"Limited government restricts...",c:["power","rain","fractions"],a:"power"},
 {unit:"G7-SS-ECON",skill:"demand",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Demand means how much people want something.",practice:"Many people want apples.",q:"Demand means how much people...",c:["want","divide","evaporate"],a:"want"}
]);

LR_addLessons("Ava","Reading",[
 {unit:"G7-ELA-EVIDENCE",skill:"tone",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Tone is the author's attitude toward a subject.",practice:"Words can sound worried, funny, or serious.",q:"Tone means author's...",c:["attitude","address","font"],a:"attitude"}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-EQ",skill:"linear equations",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Linear equations can often be solved with inverse operations.",practice:"4x - 8 = 20 gives x = 7.",q:"4x - 8 = 20. x = ?",c:["7","12","28"],a:"7"},
 {unit:"G8-MATH-FUNC",skill:"x-intercept",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: To find x-intercept, set y = 0.",practice:"At the x-axis, y is 0.",q:"For x-intercept, set y equal to...",c:["0","1","x"],a:"0"},
 {unit:"G8-MATH-FUNC",skill:"systems",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A system solution satisfies both equations.",practice:"Graphs intersect at the solution.",q:"A system solution is where graphs...",c:["intersect","vanish","end"],a:"intersect"},
 {unit:"G8-MATH-GEO-DATA",skill:"trend lines",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A trend line shows the general pattern in scatter plot data.",practice:"It approximates the data.",q:"A trend line shows...",c:["general pattern","only one dot","a title"],a:"general pattern"},
 {unit:"G8-MATH-NUMBERS",skill:"scientific notation",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Scientific notation uses powers of ten.",practice:"56,000 = 5.6 × 10^4.",q:"56,000 starts as...",c:["5.6 × 10","56 × 10","0.56 × 10"],a:"5.6 × 10"}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"rebuttal",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A rebuttal answers a counterclaim.",practice:"It explains why the original claim still stands.",q:"A rebuttal answers the...",c:["counterclaim","setting","title"],a:"counterclaim"},
 {unit:"G8-ELA-RESEARCH",skill:"citation",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: A citation gives credit to a source.",practice:"It helps readers find the source.",q:"A citation gives...",c:["credit","weather","volume"],a:"credit"},
 {unit:"G8-ELA-READING",skill:"inference",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Inference uses evidence and reasoning.",practice:"Clues plus thinking.",q:"A strong inference uses evidence and...",c:["reasoning","punctuation","volume"],a:"reasoning"}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-MATTER",skill:"conservation of mass",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Conservation of mass means mass is not lost in a closed system.",practice:"Mass before equals mass after.",q:"Conservation of mass means mass is not...",c:["lost","spelled","graphed"],a:"lost"},
 {unit:"G8-SCI-FORCE",skill:"work",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Work happens when a force moves an object over a distance.",practice:"Pushing a box across the floor.",q:"Work needs force and...",c:["distance","grammar","rights"],a:"distance"},
 {unit:"G8-SCI-WAVES-EARTH",skill:"frequency",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Frequency is how often waves pass a point.",practice:"More waves per second means higher frequency.",q:"Frequency means how often waves...",c:["pass a point","become laws","form claims"],a:"pass a point"}
]);

LR_addLessons("Michael","History",[
 {unit:"G8-SS-CIVICS",skill:"separation of powers",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Separation of powers divides authority among branches.",practice:"Legislative, executive, judicial.",q:"Separation of powers divides authority among...",c:["branches","markets","cells"],a:"branches"},
 {unit:"G8-SS-ECON",skill:"opportunity cost",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Opportunity cost is what you give up when choosing.",practice:"Choosing study time gives up other time.",q:"Opportunity cost is what you...",c:["give up","always gain","ignore"],a:"give up"},
 {unit:"G8-SS-HISTORICAL",skill:"historical context",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: Historical context means the conditions around an event.",practice:"Time, place, beliefs, and problems matter.",q:"Historical context means surrounding...",c:["conditions","forces","variables"],a:"conditions"}
]);

LR_addLessons("Michael","Civics",[
 {unit:"G8-SS-CIVICS",skill:"Bill of Rights",difficulty:"checkpoint",mode:"review",teach:"Checkpoint: The Bill of Rights protects important freedoms.",practice:"Speech and religion are examples.",q:"The Bill of Rights protects...",c:["freedoms","fractions","weather"],a:"freedoms"}
]);
