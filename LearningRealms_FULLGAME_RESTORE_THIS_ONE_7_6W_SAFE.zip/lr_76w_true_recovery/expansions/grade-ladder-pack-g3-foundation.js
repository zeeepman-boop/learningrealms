// Grade Ladder Pack G3: Grade 3 Foundation
// Tagged with gradeBand:"G3" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG3Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G3",unit:"G3-READ-VOCAB",skill:"prefixes",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A prefix is a word part added to the beginning of a word.",
     workedExample:"In reread, the prefix re means again. Reread means read again.",
     guidedPractice:"Look at the beginning of the word.",
     q:"In replay, what does the prefix re mean?",c:["again","not","before"],a:"again",
     explain:"The prefix re often means again."},

    {gradeBand:"G3",unit:"G3-READ-VOCAB",skill:"suffixes",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A suffix is a word part added to the end of a word.",
     workedExample:"In hopeful, the suffix ful means full of. Hopeful means full of hope.",
     guidedPractice:"Look at the ending of the word.",
     q:"In careful, what is the suffix?",c:["ful","care","car"],a:"ful",
     explain:"Ful is added to the end of care, so it is the suffix."},

    {gradeBand:"G3",unit:"G3-READ-COMP",skill:"theme",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Theme is a message or lesson in a story.",
     workedExample:"If a character tells the truth even when it is hard, the theme may be honesty matters.",
     guidedPractice:"Ask what the story teaches.",
     q:"A character admits a mistake and makes it right. Which theme fits?",c:["Honesty matters.","Rocks are heavy.","Maps have symbols."],a:"Honesty matters.",
     explain:"The character learns to be honest and fix the mistake."},

    {gradeBand:"G3",unit:"G3-READ-COMP",skill:"inference",difficulty:"grade 3",mode:"foundation",
     miniLesson:"An inference uses clues and thinking.",
     workedExample:"If a character grabs an umbrella and the sky is gray, you can infer rain may be coming.",
     guidedPractice:"Use clues from the text, not a wild guess.",
     q:"A character shivers and pulls on a coat. What can you infer?",c:["The character is cold.","The character is swimming.","The character is painting."],a:"The character is cold.",
     explain:"Shivering and putting on a coat are clues that the character is cold."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G3",unit:"G3-MATH-MULT",skill:"multiplication facts",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Multiplication is repeated addition.",
     workedExample:"4 x 3 means 4 groups of 3. That is 3 + 3 + 3 + 3 = 12.",
     guidedPractice:"Think about equal groups.",
     q:"4 x 3 = ?",c:["12","7","9"],a:"12",
     explain:"Four groups of three make twelve."},

    {gradeBand:"G3",unit:"G3-MATH-DIV",skill:"division basics",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Division splits a number into equal groups.",
     workedExample:"12 divided by 3 means split 12 into 3 equal groups. Each group has 4.",
     guidedPractice:"Ask how many are in each equal group.",
     q:"12 ÷ 3 = ?",c:["4","3","9"],a:"4",
     explain:"12 split into 3 equal groups gives 4 in each group."},

    {gradeBand:"G3",unit:"G3-MATH-FRAC",skill:"fractions",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A fraction can show part of a whole.",
     workedExample:"If a circle is split into 4 equal parts and 1 part is shaded, the shaded part is 1/4.",
     guidedPractice:"Look at how many equal parts the whole has.",
     q:"One part out of four equal parts is...",c:["1/4","4/1","1/2"],a:"1/4",
     explain:"One of four equal parts is written 1/4."},

    {gradeBand:"G3",unit:"G3-MATH-AREA",skill:"area",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Area measures the space inside a flat shape.",
     workedExample:"A rectangle that is 5 units long and 3 units wide has area 15 square units.",
     guidedPractice:"Multiply length by width for a rectangle.",
     q:"A rectangle is 5 by 3. What is its area?",c:["15","8","10"],a:"15",
     explain:"5 times 3 equals 15 square units."},

    {gradeBand:"G3",unit:"G3-MATH-TIME",skill:"elapsed time",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Elapsed time is how much time passes.",
     workedExample:"From 2:00 to 2:30, 30 minutes pass.",
     guidedPractice:"Count forward from the start time.",
     q:"How much time passes from 4:00 to 4:30?",c:["30 minutes","1 hour","10 minutes"],a:"30 minutes",
     explain:"4:30 is 30 minutes after 4:00."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G3",unit:"G3-ELA-PARTS",skill:"subjects and predicates",difficulty:"grade 3",mode:"foundation",
     miniLesson:"The subject tells who or what the sentence is about. The predicate tells what the subject does or is.",
     workedExample:"In The dragon flew, the dragon is the subject and flew is the predicate.",
     guidedPractice:"Find who or what first.",
     q:"In The owl watched, what is the predicate?",c:["watched","owl","the"],a:"watched",
     explain:"Watched tells what the owl did."},

    {gradeBand:"G3",unit:"G3-ELA-GRAMMAR",skill:"conjunctions",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A conjunction joins words or ideas.",
     workedExample:"And, but, and or are common conjunctions.",
     guidedPractice:"Look for the joining word.",
     q:"Which word is a conjunction?",c:["and","dragon","quickly"],a:"and",
     explain:"And joins words or ideas."},

    {gradeBand:"G3",unit:"G3-ELA-WRITING",skill:"paragraphs",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A paragraph is a group of sentences about one main idea.",
     workedExample:"A paragraph about frogs should include sentences that all tell about frogs.",
     guidedPractice:"Keep the sentences on the same topic.",
     q:"A paragraph should mostly stay on...",c:["one main idea","many random ideas","only one letter"],a:"one main idea",
     explain:"A paragraph is clearer when its sentences support one main idea."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G3",unit:"G3-SCI-FORCES",skill:"pushes and pulls",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A force is a push or a pull.",
     workedExample:"Pushing a cart is a force. Pulling a wagon is also a force.",
     guidedPractice:"Ask whether something is being pushed or pulled.",
     q:"Which is a force?",c:["pulling a wagon","reading quietly","looking at a map"],a:"pulling a wagon",
     explain:"Pulling is a force."},

    {gradeBand:"G3",unit:"G3-SCI-LIFE",skill:"life cycles",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Living things have life cycles.",
     workedExample:"A butterfly begins as an egg, becomes a caterpillar, forms a chrysalis, and becomes an adult butterfly.",
     guidedPractice:"Think about the stages in order.",
     q:"Which is a stage in a butterfly life cycle?",c:["caterpillar","rock","chair"],a:"caterpillar",
     explain:"A caterpillar is part of the butterfly life cycle."},

    {gradeBand:"G3",unit:"G3-SCI-EARTH",skill:"weather and climate",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Weather is what happens outside today. Climate is the usual weather pattern over a long time.",
     workedExample:"Rain today is weather. A desert being dry most of the year is climate.",
     guidedPractice:"Ask whether it is today or long-term.",
     q:"Rain falling today is...",c:["weather","climate","a fossil"],a:"weather",
     explain:"Weather describes conditions now or today."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G3",unit:"G3-SS-GEOGRAPHY",skill:"regions",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A region is an area with common features.",
     workedExample:"A mountain region may have high land, steep slopes, and cooler air.",
     guidedPractice:"Look for shared features.",
     q:"An area with common features is a...",c:["region","verb","fraction"],a:"region",
     explain:"A region is grouped by shared features."},

    {gradeBand:"G3",unit:"G3-SS-CIVICS",skill:"rights and responsibilities",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Citizens have rights and responsibilities.",
     workedExample:"A right may be free speech. A responsibility may be following laws.",
     guidedPractice:"Think about what people may do and what they should do.",
     q:"Following laws is a citizen...",c:["responsibility","landform","fraction"],a:"responsibility",
     explain:"Following laws is a responsibility."},

    {gradeBand:"G3",unit:"G3-SS-ECON",skill:"scarcity",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Scarcity means there is not enough of something to satisfy every want.",
     workedExample:"If there are only three apples and ten people want apples, apples are scarce.",
     guidedPractice:"Ask whether wants are greater than what is available.",
     q:"Scarcity means resources are...",c:["limited","unlimited","invisible"],a:"limited",
     explain:"Scarcity happens when resources are limited."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G3",unit:"G3-ART-VALUE",skill:"light and dark",difficulty:"grade 3",mode:"foundation",
     miniLesson:"Value is how light or dark something is in art.",
     workedExample:"A shaded side of a ball is darker. The side facing light is lighter.",
     guidedPractice:"Look for light and dark areas.",
     q:"Value means how light or dark something is.",c:["true","false","only in math"],a:"true",
     explain:"In art, value describes lightness and darkness."},

    {gradeBand:"G3",unit:"G3-ART-COMPOSITION",skill:"focal point",difficulty:"grade 3",mode:"foundation",
     miniLesson:"A focal point is the part of an artwork the viewer notices first.",
     workedExample:"A bright dragon in the middle of a dark picture may be the focal point.",
     guidedPractice:"Ask where your eye goes first.",
     q:"The part noticed first is the...",c:["focal point","footer","denominator"],a:"focal point",
     explain:"The focal point draws the viewer's attention."}
  ]);
}

LR_addG3Foundation("Luna");
LR_addG3Foundation("Ava");
LR_addG3Foundation("Michael");
