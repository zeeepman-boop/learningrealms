(function(){if(typeof LR_addLessons!=="function")return;
LR_addLessons("Luna","Reading",[
{teach:"Stories have a beginning, middle, and end.",q:"What comes after the beginning?",c:["middle","end","nothing"],a:"middle"},
{teach:"Characters are the people or animals in stories.",q:"Who is in a story?",c:["characters","weather","chairs"],a:"characters"},
{teach:"Setting tells where and when.",q:"Setting tells...",c:["where and when","favorite food","page number"],a:"where and when"},
{teach:"Dialogue is talking in a story.",q:"Dialogue means...",c:["talking","running","drawing"],a:"talking"},
{teach:"Details help us understand stories.",q:"Details help us...",c:["understand","sleep","erase"],a:"understand"}]);
LR_addLessons("Ava","Reading",[
{teach:"Plot is the order of story events.",q:"Plot means...",c:["story events","cover art","author age"],a:"story events"},
{teach:"Conflict is the problem in a story.",q:"Conflict is...",c:["the problem","the ending","the setting"],a:"the problem"},
{teach:"Inference uses clues from the text.",q:"Inference uses...",c:["clues","luck","speed"],a:"clues"},
{teach:"Text evidence supports answers.",q:"Answers should use...",c:["text evidence","guesses","noise"],a:"text evidence"}]);
LR_addLessons("Michael","Reading",[
{teach:"Foreshadowing hints at future events.",q:"Foreshadowing gives...",c:["hints","answers","titles"],a:"hints"},
{teach:"Author purpose explains why something was written.",q:"Author purpose asks...",c:["why it was written","page count","font"],a:"why it was written"},
{teach:"Character motivation explains actions.",q:"Motivation explains...",c:["actions","weather","maps"],a:"actions"}]);})();