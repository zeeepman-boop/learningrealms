/* LearningRealms Button Wiring + Redundancy Cleanup 7.3O
   Built on 7.3N, which finally recovered the better RPG layout.
   Purpose: keep the layout, remove redundant visible buttons, and make every obvious remaining navigation button route safely.
   No save reset. No lesson/content edits. No loading curtain. No render loop.
*/
(function(){
  'use strict';
  if(window.__LR73O_BUTTON_WIRING_CLEANUP__) return;
  window.__LR73O_BUTTON_WIRING_CLEANUP__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function text(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }
  function has(fn){ return typeof window[fn] === 'function'; }

  var oldM = null;
  var cleanTimer = 0;

  function call(fn){
    if(!has(fn)) return false;
    var args = Array.prototype.slice.call(arguments,1);
    try{ window[fn].apply(window,args); scheduleClean(); return true; }
    catch(e){ console.warn('LR73O guarded route failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var item = list[i];
      if(Array.isArray(item)){ if(call.apply(null,item)) return true; }
      else if(call(item)) return true;
    }
    return false;
  }

  function stateObj(){ try{ return window.state || state || {}; }catch(e){ return {}; } }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    var s = byId('studentSelect');
    if(s && s.value) return s.value;
    try{ return localStorage.getItem('lrActiveChild') || 'Michael'; }catch(e){}
    return 'Michael';
  }
  function avatarFor(name){
    name = String(name || '').toLowerCase();
    if(name.indexOf('michael') >= 0) return '🛡️';
    if(name.indexOf('ava') >= 0) return '🌺';
    if(name.indexOf('luna') >= 0) return '🌙';
    return '🧭';
  }
  function sceneName(){
    var h = q('#lrDynamicAdventureScreen h1');
    if(h && text(h)) return text(h);
    var rt = byId('roomTitle');
    return text(rt) || 'Home Hearth';
  }
  function statLine(){
    var s = stateObj();
    var room = text(byId('roomNumber')) || s.room || '1';
    var sparks = text(byId('sparks')) || s.sparks || '0';
    var streak = text(byId('streak')) || s.streak || '0';
    return 'Room ' + room + ' · ' + sparks + ' Sparks · Streak ' + streak;
  }

  function installStyles(){
    if(byId('lr73oCleanupStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr73oCleanupStyles';
    st.textContent = `
      body.lr73oCleanNav .lr73oHidden{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;}
      body.lr73oCleanNav .lr73mTopNav{justify-content:flex-end!important;gap:8px!important;}
      body.lr73oCleanNav .lr73mTopNav button{border-radius:12px!important;min-width:92px!important;}
      body.lr73oCleanNav #leftActionButtons{grid-template-columns:1fr 1fr!important;gap:7px!important;padding:10px!important;}
      body.lr73oCleanNav .lr73oCommandGroupTitle{grid-column:1 / -1;color:#ffe7a8;font-size:.68rem;font-weight:1000;text-transform:uppercase;letter-spacing:.1em;padding:5px 2px 1px;border-bottom:1px solid rgba(245,223,154,.14);}
      body.lr73oCleanNav .lr73oBtn{border:1px solid rgba(245,223,154,.34)!important;border-radius:10px!important;background:linear-gradient(180deg,#fff1bc,#c89a45)!important;color:#1c1106!important;font-weight:1000!important;cursor:pointer!important;box-shadow:0 5px 10px rgba(0,0,0,.22)!important;}
      body.lr73oCleanNav .lr73oCommandBtn{display:grid!important;grid-template-columns:34px 1fr!important;gap:7px!important;align-items:center!important;text-align:left!important;min-height:44px!important;padding:7px!important;}
      body.lr73oCleanNav .lr73oCommandBtn span{width:30px;height:30px;display:grid;place-items:center;border-radius:8px;background:linear-gradient(180deg,#183b34,#071715);color:#ffe7a8;font-size:1.15rem;}
      body.lr73oCleanNav .lr73oCommandBtn b{font-size:.78rem;line-height:1.05;}
      body.lr73oCleanNav .lr73oCommandBtn.primary{grid-column:1 / -1;grid-template-columns:38px 1fr;background:linear-gradient(180deg,#fff6cf,#e0b65d)!important;}
      body.lr73oCleanNav .lr73mIconRack{grid-template-columns:repeat(4,1fr)!important;}
      body.lr73oCleanNav .lr73mIconRack button{position:relative!important;}
      body.lr73oCleanNav .lr73mIconRack button:hover::after{content:attr(title);position:absolute;left:50%;bottom:42px;transform:translateX(-50%);white-space:nowrap;font-size:.68rem;background:#091614;color:#ffe7a8;border:1px solid rgba(245,223,154,.35);border-radius:6px;padding:3px 6px;z-index:20;}
      body.lr73oCleanNav .lr73mLedgerBtns{display:none!important;}
      body.lr73oCleanNav .lr73oLedgerHints{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:9px;}
      body.lr73oCleanNav .lr73oLedgerHints span{border:1px solid rgba(245,223,154,.14);border-radius:8px;padding:6px;background:rgba(0,0,0,.14);font-size:.73rem;font-weight:900;color:#d5eadc;}
      body.lr73oCleanNav .lr73oRouted{outline:none!important;}
      body.lr73oCleanNav .lr73oDisabledRoute{opacity:.55!important;filter:saturate(.65)!important;}
    `;
    document.head.appendChild(st);
  }

  function oldHub(kind){
    if(typeof oldM === 'function'){
      try{ oldM(kind || 'map'); scheduleClean(); return true; }
      catch(e){ console.warn('LR73O old hub failed:', kind, e); }
    }
    return false;
  }
  function simpleHub(title, desc, cards){
    var host = byId('lrDynamicAdventureScreen');
    if(!host){
      var firstCard = q('.main > .card:first-child') || q('section.main') || document.body;
      host = document.createElement('div');
      host.id = 'lrDynamicAdventureScreen';
      host.className = 'lrDynamicAdventureScreen lr73mScreen';
      firstCard.insertBefore(host, firstCard.firstChild || null);
    }
    host.innerHTML = '<section class="lr73mHero"><small>Adventure Navigation</small><h1>'+esc(title)+'</h1><p>'+esc(desc)+'</p></section><section class="lr73mChoiceGrid">'+cards+'</section>';
    scheduleClean(); return true;
  }
  function choice(icon,title,sub,act){
    return '<button type="button" class="lr73mChoice" data-lr73o-act="'+esc(act)+'"><span>'+esc(icon)+'</span><div><b>'+esc(title)+'</b><small>'+esc(sub)+'</small></div></button>';
  }

  function doAction(act){
    act = String(act || 'map').toLowerCase().replace(/[^a-z0-9]/g,'');
    if(act === 'scene') return first([['lr68Render','room','You return to the main scene.'],['lr68Render'],['renderRoom']]) || oldHub('scene') || simpleHub('Scene','The main scene is ready.', choice('🧭','Realm Map','Open the atlas.','map'));
    if(act === 'look') return first([['lr68Render','look','You inspect the room.'],['openSubjectAtlasRoom',sceneName()],['openAtlasPopup']]) || oldHub('map');
    if(act === 'talk') return first([['lr68Render','talk','You look for someone to talk to.'],['openNpcRelations'],['openQuestJournal'],['openQuestPopup']]) || oldHub('map');
    if(act === 'map' || act === 'realmmap' || act === 'atlas') return oldHub('map') || first([['openWorldAtlas'],['openAtlasPopup'],['openWorldMapEngine']]) || simpleHub('Realm Map','Choose a major road.', choice('📘','Go Learn','Course roads and lessons.','learn')+choice('🏛️','History Wing','History master courses.','history')+choice('⛪','Bible Road','Bible History realm.','bible')+choice('🏡','Home','Home hearth and storage.','home'));
    if(act === 'learn' || act === 'golearn') return oldHub('learn') || first([['lr68bOpenLearningTrails','featured'],['lr68OpenLearn'],['openRealCurriculumPicker'],['openLessonLauncher'],['openSubjectAtlasUI']]);
    if(act === 'featuredtrails') return first([['lr68bOpenLearningTrails','featured'],['lr68OpenLearn'],['openRealCurriculumPicker'],['openLessonLauncher'],['openSubjectAtlasUI']]) || oldHub('learn');
    if(act === 'history' || act === 'historywing') return oldHub('history') || first([['lr68bOpenLearningTrails','world'],['openSubjectAtlasUI'],['openWorldAtlas']]) || simpleHub('History Wing','Depression and Wild West live here under History.', choice('🏚️','Great Depression Road','Open the 1930s history master course.','depression')+choice('🤠','Wild West Frontier Trail','Open the kid-safe frontier master course.','wildwest')+choice('🗺️','Realm Map','Back to the atlas.','map'));
    if(act === 'historytrails') return first([['lr68bOpenLearningTrails','world'],['openWorldAtlas'],['openSubjectAtlasUI']]) || oldHub('history');
    if(act === 'depression' || act === 'greatdepression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse'],['openGreatDepressionRewards']]) || oldHub('history');
    if(act === 'wildwest') return first([['openWildWestTrail'],['openWildWestCourse'],['openWildWestShops']]) || oldHub('history');
    if(act === 'bible' || act === 'bibleroad' || act === 'biblehistory') return oldHub('bible') || first([['openBibleHistoryTrail'],['openBibleHistoryCourse']]);
    if(act === 'biblecourse') return first([['openBibleHistoryCourse'],['openBibleHistoryTrail']]) || oldHub('bible');
    if(act === 'bibletrail') return first([['openBibleHistoryTrail'],['openBibleHistoryCourse']]) || oldHub('bible');
    if(act === 'bibleartifacts' || act === 'artifacts' || act === 'artifacthall') return first([['openBibleHistoryArtifacts73B'],['openBibleHistoryArtifacts'],['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || oldHub('bible');
    if(act === 'bibleshops') return first([['openBibleHistoryShops'],['openBibleHistoryCourse']]) || oldHub('bible');
    if(act === 'biblerewards') return first([['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || oldHub('bible');
    if(act === 'biblereview') return first([['openBibleHistoryReview'],['openBibleHistoryCourse']]) || oldHub('bible');
    if(act === 'home' || act === 'homerooms' || act === 'storage') return first([['openHomeRooms'],['lr68OpenHome'],['openHomeView'],['openHomeRenderer'],['openVisualHome'],['openVisibleHome'],['openHomeViewPopup']]) || oldHub('map');
    if(act === 'items' || act === 'inventory' || act === 'collection' || act === 'collectionlog') return first([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openAchievementJournal'],['openMuseumHall']]) || oldHub('map');
    if(act === 'pets' || act === 'companions' || act === 'companionden') return first([['openCompanionDen'],['openPetJournal'],['openCompanionPopup'],['openCompanionEngine']]) || oldHub('map');
    if(act === 'quests' || act === 'questboard') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openQuestPopup'],['openStoryQuestJournal']]) || oldHub('map');
    if(act === 'shipwreck') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['openShipwreckCoveMap'],['openShipwreckCoveRewardCatalog']]) || oldHub('learn');
    if(act === 'inventions') return first([['openInventionsDeepCourse'],['openInventionsRewardCatalog'],['lr68bOpenLearningTrails','featured']]) || oldHub('learn');
    if(act === 'creative') return first([['openCreativeStudioCourse'],['openCreativeStudioByStudio'],['lr68bOpenLearningTrails','featured']]) || oldHub('learn');
    return oldHub('map');
  }

  window.lr73oDo = doAction;

  function reduceHeader(){
    var h = q('.compactHeader'); if(!h) return;
    var name = activeName();
    h.innerHTML = '<div class="lr73mHeaderRune">'+esc(avatarFor(name))+'</div>'+ 
      '<div class="lr73mBrand"><b>LearningRealms</b><small>'+esc(sceneName())+' · '+esc(statLine())+'</small></div>'+ 
      '<nav class="lr73mTopNav" aria-label="Primary navigation">'+
        '<button type="button" class="lr73oBtn" data-lr73o-act="scene">Scene</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73o-act="map">Realm Map</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73o-act="learn">Go Learn</button>'+ 
        '<button type="button" class="lr73oBtn" data-lr73o-act="home">Home</button>'+ 
      '</nav>';
  }

  function reduceCommands(){
    var side = q('.actionSidebar');
    var host = byId('leftActionButtons');
    if(!side || !host) return;
    var h2 = side.querySelector('h2'); if(h2) h2.textContent = 'Commands';
    var html = ''+
      '<div class="lr73oCommandGroupTitle">Adventure</div>'+
      cmd('📘','Go Learn','learn','primary')+
      cmd('🪟','Scene','scene')+cmd('🔎','Look','look')+cmd('💬','Talk','talk')+cmd('🗺️','Realm Map','map')+
      '<div class="lr73oCommandGroupTitle">Course Roads</div>'+
      cmd('🏛️','History Wing','history')+cmd('⛪','Bible Road','bible')+cmd('⚓','Shipwreck Cove','shipwreck')+cmd('🏡','Home Hearth','home')+
      '<div class="lr73oCommandGroupTitle">Records</div>'+
      cmd('🎒','Collection Log','items')+cmd('🐾','Companion Den','pets')+cmd('📜','Quest Board','quests');
    if(host.innerHTML !== html) host.innerHTML = html;
  }
  function cmd(icon,label,act,extra){
    return '<button type="button" class="lr73oBtn lr73oCommandBtn '+(extra||'')+'" data-lr73o-act="'+esc(act)+'"><span>'+esc(icon)+'</span><b>'+esc(label)+'</b></button>';
  }

  function reducePlayerIcons(){
    var rack = q('.lr73mIconRack'); if(!rack) return;
    var html = ''+
      icon('🧭','Realm Map','map')+icon('📘','Go Learn','learn')+icon('🏛️','History Wing','history')+icon('⛪','Bible Road','bible')+
      icon('🎒','Collection Log','items')+icon('🐾','Companion Den','pets')+icon('📜','Quest Board','quests')+icon('🏡','Home Hearth','home');
    if(rack.innerHTML !== html) rack.innerHTML = html;
  }
  function icon(symbol,title,act){
    return '<button type="button" title="'+esc(title)+'" aria-label="'+esc(title)+'" data-lr73o-act="'+esc(act)+'">'+esc(symbol)+'</button>';
  }

  function reduceLedger(){
    var ledger = q('.lr73mLedger');
    if(!ledger) return;
    var html = '<b>Current road</b><small>'+esc(sceneName())+'<br>'+esc(statLine())+'</small>'+ 
      '<div class="lr73oLedgerHints"><span>📈 Use the Show menu for records.</span><span>🧭 Use Commands for travel.</span></div>';
    if(ledger.innerHTML !== html) ledger.innerHTML = html;
  }

  function normalizeCapsAgain(){
    function one(container,title){
      if(!container) return;
      qa(':scope > .lr73mWindowLabel, :scope > .lr73iWindowLabel', container).forEach(function(el){ try{ el.remove(); }catch(e){} });
      var cap = document.createElement('div'); cap.className='lr73mWindowLabel'; cap.textContent=title;
      container.insertBefore(cap, container.firstChild || null);
    }
    one(q('.playerSidebar'), 'Player Sheet');
    one(q('.actionSidebar'), 'Command Window');
    one(q('.rightInfoCard') || q('.rightSidebar .card'), 'Records Ledger');
    one(q('.main > .card:first-child'), 'Main Adventure Window');
  }

  function installAliases(){
    if(!has('openBibleHistoryArtifacts') && has('openBibleHistoryArtifacts73B')) window.openBibleHistoryArtifacts = window.openBibleHistoryArtifacts73B;
    if(!has('openInventoryPopup') && has('openCollectionLog')) window.openInventoryPopup = window.openCollectionLog;
    if(!has('openBackpack') && has('openCollectionLog')) window.openBackpack = window.openCollectionLog;
    if(!has('openPetJournal') && has('openCompanionDen')) window.openPetJournal = window.openCompanionDen;
    if(!has('openDailyQuestBoard') && has('openQuestBoard')) window.openDailyQuestBoard = window.openQuestBoard;
    if(!has('openHomeRooms') && has('openHomeRenderer')) window.openHomeRooms = window.openHomeRenderer;
    window.openLearningRealmsHistoryWing = function(){ return doAction('history'); };
    window.openLearningRealmsBibleRoad = function(){ return doAction('bible'); };
    window.openLearningRealmsMainMap = function(){ return doAction('map'); };
  }

  function infer(txt){
    txt = String(txt || '').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();
    if(!txt) return '';
    if(txt.indexOf('open home rooms') >= 0 || txt.indexOf('home rooms') >= 0 || txt.indexOf('storage') >= 0) return 'homeRooms';
    if(txt.indexOf('companion den') >= 0 || txt.indexOf('pet') >= 0) return 'pets';
    if(txt.indexOf('collection log') >= 0 || txt.indexOf('inventory') >= 0 || txt === 'items') return 'items';
    if(txt.indexOf('quest board') >= 0 || txt === 'quests') return 'quests';
    if(txt.indexOf('great depression') >= 0 || txt === 'depression') return 'depression';
    if(txt.indexOf('wild west') >= 0) return 'wildwest';
    if(txt.indexOf('bible artifact') >= 0 || txt.indexOf('artifact hall') >= 0) return 'bibleArtifacts';
    if(txt.indexOf('bible road') >= 0 || txt.indexOf('bible history') >= 0 || txt === 'bible') return 'bible';
    if(txt.indexOf('history wing') >= 0 || txt === 'history') return 'history';
    if(txt.indexOf('go learn') >= 0 || txt.indexOf('learning trail') >= 0 || txt === 'learn') return 'learn';
    if(txt.indexOf('realm map') >= 0 || txt.indexOf('world atlas') >= 0 || txt === 'map') return 'map';
    if(txt.indexOf('shipwreck') >= 0) return 'shipwreck';
    if(txt === 'scene' || txt.indexOf('return to scene') >= 0) return 'scene';
    if(txt === 'look') return 'look';
    if(txt === 'talk') return 'talk';
    if(txt === 'home' || txt.indexOf('home hearth') >= 0) return 'home';
    return '';
  }

  function routeVisibleButtons(){
    var roots = qa('.compactHeader, .playerSidebar, .actionSidebar, .rightSidebar, .main, #lrDynamicAdventureScreen');
    roots.forEach(function(root){
      qa('button', root).forEach(function(btn){
        if(btn.disabled) return;
        if(btn.getAttribute('onclick')) return; // leave course quiz/page buttons alone
        var act = btn.getAttribute('data-lr73o-act') || btn.getAttribute('data-lr73m-act') || btn.getAttribute('data-lr73n-act') || infer(text(btn) || btn.getAttribute('title') || btn.getAttribute('aria-label'));
        if(!act) return;
        btn.removeAttribute('data-lr73m-act');
        btn.removeAttribute('data-lr73n-act');
        btn.setAttribute('data-lr73o-act', act);
        btn.classList.add('lr73oRouted');
      });
    });
  }

  function routeMenus(){
    var menu = byId('gameMenuSelect');
    if(menu && !menu.__lr73oMenuBound){
      menu.__lr73oMenuBound = true;
      menu.addEventListener('change', function(){
        var v = String(menu.value || '');
        var map = {
          collectionLog:'items', companionDen:'pets', eventLog:'quests', masteryPaths:'learn', reportCenter:'quests', classroomSchedule:'quests', storyCampaigns:'quests', adaptiveReview:'learn', bossGauntlets:'learn', worldAtlas:'map', systemHealth:'quests'
        };
        if(v === 'parentDashboard') return call('openParentDashboard') || call('openParentPopup');
        if(map[v]) doAction(map[v]);
        setTimeout(function(){ menu.value=''; }, 50);
      });
    }
  }

  function cleanNow(){
    cleanTimer = 0;
    try{ document.body.classList.add('lr73oCleanNav','lr73nCleanCaps','lr73mStable'); }catch(e){}
    installStyles(); installAliases(); normalizeCapsAgain(); reduceHeader(); reduceCommands(); reducePlayerIcons(); reduceLedger(); routeVisibleButtons(); routeMenus();
  }
  function scheduleClean(){
    if(cleanTimer) return;
    cleanTimer = setTimeout(cleanNow, 45);
  }

  function bindClicks(){
    if(window.__LR73O_CLICK_BOUND__) return;
    window.__LR73O_CLICK_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr73o-act]') : null;
      if(!btn) return;
      var root = btn.closest('.compactHeader, .playerSidebar, .actionSidebar, .rightSidebar, .main, #lrDynamicAdventureScreen');
      if(!root) return;
      ev.preventDefault(); ev.stopPropagation();
      doAction(btn.getAttribute('data-lr73o-act'));
      scheduleClean(); setTimeout(cleanNow,120); setTimeout(cleanNow,360);
    }, true);
  }

  function wrapM(){
    if(window.__LR73O_WRAPPED_M__) return;
    if(typeof window.lr73mDo !== 'function') return;
    oldM = window.lr73mDo;
    window.__LR73O_WRAPPED_M__ = true;
    window.lr73mDo = function(act){
      var a = String(act || 'map');
      var out = doAction(a);
      scheduleClean(); setTimeout(cleanNow,150); setTimeout(cleanNow,420);
      return out;
    };
  }

  function boot(){
    if(!oldM && typeof window.lr73mDo === 'function') oldM = window.lr73mDo;
    bindClicks(); wrapM(); cleanNow();
    setTimeout(function(){ if(!oldM && typeof window.lr73mDo === 'function') oldM = window.lr73mDo; wrapM(); cleanNow(); }, 120);
    setTimeout(cleanNow, 480);
    setTimeout(cleanNow, 1200);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,80); setTimeout(cleanNow,700); });
})();
