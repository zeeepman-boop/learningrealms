// Question Mountain Phase 5 - Nature Deepening
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Nature",[
{teach:"Seeds can grow into plants.",q:"Seeds can grow into...",c:["plants","clouds","books"],a:"plants"},
{teach:"Animals need food.",q:"Animals need...",c:["food","paper","coins"],a:"food"},
{teach:"Rain helps plants.",q:"Rain can help...",c:["plants","rocks","chairs"],a:"plants"},
{teach:"Trees have roots.",q:"Trees have...",c:["roots","wheels","windows"],a:"roots"},
{teach:"Habitats provide homes.",q:"Habitats provide...",c:["homes","titles","equations"],a:"homes"}
]);

LR_addLessons("Ava","Nature",[
{teach:"Predators and prey interact.",q:"Predators and prey...",c:["interact","sleep","freeze"],a:"interact"},
{teach:"Weather tools collect data.",q:"Weather tools collect...",c:["data","songs","coins"],a:"data"},
{teach:"Producers make food.",q:"Plants are often...",c:["producers","predators","consumers"],a:"producers"},
{teach:"Consumers eat plants or animals.",q:"Consumers...",c:["eat","sleep","glow"],a:"eat"},
{teach:"Balanced diets support health.",q:"Balanced diets support...",c:["health","maps","trade"],a:"health"}
]);

LR_addLessons("Michael","Nature",[
{teach:"Ecosystems can change over time.",q:"Ecosystems may...",c:["change","freeze","vanish"],a:"change"},
{teach:"Resources can be renewable.",q:"Renewable resources can...",c:["return","disappear forever","sing"],a:"return"},
{teach:"Climate influences habitats.",q:"Climate affects...",c:["habitats","fonts","titles"],a:"habitats"},
{teach:"Food webs connect organisms.",q:"Food webs show...",c:["connections","equations","maps"],a:"connections"},
{teach:"Stewardship protects environments.",q:"Stewardship helps...",c:["protect","erase","hide"],a:"protect"}
]);
})();