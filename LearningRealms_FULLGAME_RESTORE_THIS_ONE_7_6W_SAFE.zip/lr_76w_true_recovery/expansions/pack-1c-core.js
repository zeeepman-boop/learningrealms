// Expansion Pack 1C: 30 more lessons, curriculum only

LR_addLessons("Luna","Reading",[
 {teach:"A blend has two consonant sounds together.",practice:"stop begins with st.",q:"Which word starts with ST?",c:["stop","fish","apple"],a:"stop"},
 {teach:"BR is a blend in brush.",practice:"brush, brick, brown",q:"Which word starts with BR?",c:["brush","ship","cat"],a:"brush"},
 {teach:"CL is a blend in clap.",practice:"clap, clock, cloud",q:"Which word starts with CL?",c:["cloud","dog","sun"],a:"cloud"},
 {teach:"Setting means where a story happens.",practice:"The frog is in a pond.",q:"The pond is the...",c:["setting","character","ending"],a:"setting"},
 {teach:"A detail tells more about a story.",practice:"The rabbit has long ears.",q:"Which is a detail?",c:["long ears","the title","the cover"],a:"long ears"}
]);

LR_addLessons("Luna","Science",[
 {teach:"A mammal has hair or fur and drinks milk as a baby.",practice:"A rabbit is a mammal.",q:"Which is a mammal?",c:["rabbit","rock","chair"],a:"rabbit"},
 {teach:"A bird has feathers.",practice:"An owl has feathers.",q:"What does a bird have?",c:["feathers","wheels","roots"],a:"feathers"},
 {teach:"A plant has roots.",practice:"Roots help hold the plant.",q:"What helps hold a plant in the ground?",c:["roots","shoes","fur"],a:"roots"},
 {teach:"Rain is water falling from clouds.",practice:"Rain makes puddles.",q:"Rain falls from...",c:["clouds","rocks","books"],a:"clouds"},
 {teach:"A shadow happens when light is blocked.",practice:"Your body can block light.",q:"A shadow needs blocked...",c:["light","sound","smell"],a:"light"}
]);

LR_addLessons("Ava","Math",[
 {teach:"Distributive property multiplies across parentheses.",practice:"3(x + 4) = 3x + 12.",q:"3(x + 4) equals...",c:["3x + 12","x + 7","12x"],a:"3x + 12"},
 {teach:"Equivalent expressions have the same value.",practice:"2x + 2x = 4x.",q:"2x + 2x = ?",c:["4x","2x","x4"],a:"4x"},
 {teach:"A circle's diameter goes across the center.",practice:"Radius is half the diameter.",q:"Diameter goes through the...",c:["center","corner","edge only"],a:"center"},
 {teach:"A rational number can be written as a fraction.",practice:"0.5 = 1/2.",q:"0.5 equals...",c:["1/2","5/1","2/1"],a:"1/2"},
 {teach:"Inequalities compare values.",practice:"x > 5 means x is greater than 5.",q:"The symbol > means...",c:["greater than","less than","equal"],a:"greater than"}
]);

LR_addLessons("Ava","English",[
 {teach:"A central idea is what a passage is mostly about.",practice:"Find the main point.",q:"Central idea means...",c:["main point","tiny detail","font size"],a:"main point"},
 {teach:"An author's purpose may be to inform, entertain, or persuade.",practice:"A fact article often informs.",q:"A science article likely tries to...",c:["inform","hide","confuse"],a:"inform"},
 {teach:"A transition connects ideas.",practice:"First, next, finally.",q:"Which is a transition?",c:["however","table","blue"],a:"however"},
 {teach:"A synonym means nearly the same thing.",practice:"happy and glad.",q:"A synonym of happy is...",c:["glad","sad","angry"],a:"glad"},
 {teach:"An antonym means the opposite.",practice:"hot and cold.",q:"An antonym of hot is...",c:["cold","warm","heat"],a:"cold"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Slope can be found from two points.",practice:"Change in y divided by change in x.",q:"Slope is change in y over change in...",c:["x","z","area"],a:"x"},
 {teach:"A system of equations can have one solution.",practice:"Two lines cross at one point.",q:"The crossing point is the...",c:["solution","title","radius"],a:"solution"},
 {teach:"A transformation moves or changes a figure.",practice:"A translation slides a shape.",q:"A translation...",c:["slides","spins only","shrinks only"],a:"slides"},
 {teach:"Similar figures have the same shape but may differ in size.",practice:"Scale copies are similar.",q:"Similar figures have the same...",c:["shape","color only","name"],a:"shape"},
 {teach:"Exponents show repeated multiplication.",practice:"2^3 = 2 × 2 × 2.",q:"2^3 equals...",c:["8","6","5"],a:"8"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Newton's first law says objects resist changes in motion.",practice:"Inertia keeps motion steady.",q:"Inertia resists changes in...",c:["motion","spelling","government"],a:"motion"},
 {teach:"A compound is made of chemically joined elements.",practice:"Water is H2O.",q:"Water is a...",c:["compound","continent","paragraph"],a:"compound"},
 {teach:"Potential energy is stored energy.",practice:"A raised rock has stored energy.",q:"Stored energy is...",c:["potential energy","density","erosion"],a:"potential energy"},
 {teach:"Kinetic energy is energy of motion.",practice:"A moving cart has kinetic energy.",q:"A moving object has...",c:["kinetic energy","no energy","only volume"],a:"kinetic energy"},
 {teach:"Gravity pulls objects toward each other.",practice:"Earth pulls objects downward.",q:"Gravity is a...",c:["pull","sentence","chemical"],a:"pull"}
]);
