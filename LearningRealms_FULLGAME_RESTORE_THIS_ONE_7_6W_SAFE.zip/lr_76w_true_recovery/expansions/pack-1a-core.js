// Expansion Pack 1A: 30 lessons

LR_addLessons("Luna","Reading",[
 {teach:"WH can make a /w/ sound like whale.",practice:"whale, wheel, whisper",q:"Which word starts with WH?",c:["whale","ship","cat"],a:"whale"},
 {teach:"A short a sound is in cat.",practice:"cat, map, bag",q:"Which word has short a?",c:["cat","bike","moon"],a:"cat"},
 {teach:"First, next, and last help tell order.",practice:"First the seed is planted. Next it grows.",q:"Which word tells the beginning?",c:["first","last","after"],a:"first"},
 {teach:"A reader can use clues.",practice:"The dog is wet and shaking.",q:"How does the dog probably feel?",c:["cold","hungry","sleepy"],a:"cold"},
 {teach:"A sight word is learned quickly.",practice:"the, said, was",q:"Which is a sight word?",c:["the","zimp","brab"],a:"the"}
]);

LR_addLessons("Luna","English",[
 {teach:"A sentence ends with punctuation.",practice:"The bird sings.",q:"Which mark can end a sentence?",c:[".","b","7"],a:"."},
 {teach:"A verb is an action word.",practice:"run, jump, sing",q:"Which word is a verb?",c:["jump","table","blue"],a:"jump"},
 {teach:"A capital letter starts a name.",practice:"Luna, Ava, Michael",q:"Which is written like a name?",c:["Luna","luna","luNa"],a:"Luna"},
 {teach:"A question asks something.",practice:"Where is the frog?",q:"Which sentence asks something?",c:["Where is the frog?","The frog jumps.","Frog green"],a:"Where is the frog?"},
 {teach:"Words in a sentence need spaces.",practice:"The cat ran.",q:"Which has spaces?",c:["The cat ran.","Thecatran.","Th ecat ran"],a:"The cat ran."}
]);

LR_addLessons("Ava","Math",[
 {teach:"A unit rate compares something to one unit.",practice:"120 miles in 3 hours = 40 miles per hour.",q:"120 miles in 3 hours is how many miles per hour?",c:["40","60","30"],a:"40"},
 {teach:"To solve x + 7 = 19, subtract 7.",practice:"19 - 7 = 12.",q:"x + 7 = 19. x = ?",c:["12","26","11"],a:"12"},
 {teach:"Percent means out of 100.",practice:"25% = 25 out of 100.",q:"25% means 25 out of what?",c:["100","10","25"],a:"100"},
 {teach:"Area of a rectangle is length times width.",practice:"8 × 3 = 24.",q:"A rectangle is 8 by 3. Area?",c:["24","11","16"],a:"24"},
 {teach:"Probability can describe likelihood.",practice:"A coin has 2 sides.",q:"Chance of heads is 1 out of...",c:["2","3","4"],a:"2"}
]);

LR_addLessons("Ava","English",[
 {teach:"Text evidence is proof from what you read.",practice:"Quote the sentence that proves your answer.",q:"What is text evidence?",c:["proof from text","a guess","the cover"],a:"proof from text"},
 {teach:"Context clues help define unfamiliar words.",practice:"The frigid wind made her shiver.",q:"Frigid most likely means...",c:["very cold","very loud","very small"],a:"very cold"},
 {teach:"A claim is a statement you support.",practice:"The character is brave because she helped others.",q:"What supports a claim?",c:["evidence","random words","a color"],a:"evidence"},
 {teach:"Point of view is who tells the story.",practice:"I walked to the gate = first person.",q:"Which word often shows first person?",c:["I","they","castle"],a:"I"},
 {teach:"A summary tells the main idea briefly.",practice:"Keep only the most important points.",q:"A summary should be...",c:["brief","longer than the story","random"],a:"brief"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Solve 2x + 5 = 17 by subtracting 5 first.",practice:"2x = 12, so x = 6.",q:"2x + 5 = 17. x = ?",c:["6","11","12"],a:"6"},
 {teach:"Slope is rise over run.",practice:"Rise 6, run 3, slope = 2.",q:"Rise 6 and run 3 gives slope...",c:["2","3","9"],a:"2"},
 {teach:"A function gives one output for each input.",practice:"x = 2 gives y = 5.",q:"A function pairs input with...",c:["output","weather","paragraph"],a:"output"},
 {teach:"The Pythagorean theorem works for right triangles.",practice:"a² + b² = c².",q:"It works for which triangles?",c:["right triangles","all circles","rectangles only"],a:"right triangles"},
 {teach:"Scientific notation writes large numbers compactly.",practice:"3000 = 3 × 10³.",q:"3000 in scientific notation starts with...",c:["3 × 10","30 × 10","300 × 10"],a:"3 × 10"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Density compares mass to volume.",practice:"density = mass ÷ volume.",q:"Density compares mass and...",c:["volume","color","sound"],a:"volume"},
 {teach:"Chemical changes make new substances.",practice:"Rust forming is a chemical change.",q:"Rust forming is a...",c:["chemical change","map scale","sentence"],a:"chemical change"},
 {teach:"Forces can change motion.",practice:"A push can speed up a cart.",q:"What can change motion?",c:["force","name","color"],a:"force"},
 {teach:"Earth systems interact.",practice:"Rain can change land through erosion.",q:"Rain changing land is related to...",c:["erosion","capitalization","theme"],a:"erosion"},
 {teach:"Energy can transfer from one object to another.",practice:"Heat moves from hot to cold.",q:"Heat usually moves from hot to...",c:["cold","hotter","nothing"],a:"cold"}
]);
