// Grade Ladder Pack G5: Grade 5 Foundation
// Tagged with gradeBand:"G5" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG5Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G5",unit:"G5-READ-VOCAB",skill:"word roots",difficulty:"grade 5",mode:"foundation",
     miniLesson:"A root is the main word part that carries meaning.",
     workedExample:"The root port means carry. Transport means carry across. Portable means able to be carried.",
     guidedPractice:"Look for the shared word part and meaning.",
     q:"The root port often means...",
     c:["carry","write","water"],a:"carry",
     explain:"Port is a root that often means carry."},

    {gradeBand:"G5",unit:"G5-READ-COMP",skill:"compare and contrast",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Compare means tell how things are alike. Contrast means tell how they are different.",
     workedExample:"Two dragons may both fly, but one may breathe fire while the other breathes frost.",
     guidedPractice:"Ask what is the same and what is different.",
     q:"Contrast means tell how things are...",
     c:["different","exactly the same","alphabetical"],a:"different",
     explain:"Contrast focuses on differences."},

    {gradeBand:"G5",unit:"G5-READ-COMP",skill:"text structure",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Text structure is how information is organized.",
     workedExample:"Cause and effect explains why something happened and what resulted. Problem and solution explains a problem and how it is fixed.",
     guidedPractice:"Look for signal words like because, as a result, problem, or solution.",
     q:"A passage that explains why erosion happened and what changed is using...",
     c:["cause and effect","alphabet order","dialogue only"],a:"cause and effect",
     explain:"It tells why something happened and what happened because of it."},

    {gradeBand:"G5",unit:"G5-READ-COMP",skill:"theme with evidence",difficulty:"grade 5",mode:"foundation",
     miniLesson:"A strong theme answer needs evidence from the story.",
     workedExample:"If a character shares food during a hard winter, that evidence can support a theme about generosity.",
     guidedPractice:"Choose a theme that matches the character's actions.",
     q:"A character gives up comfort to help a friend. Which theme fits best?",
     c:["Sacrifice can show friendship.","Decimals use place value.","Maps show regions."],a:"Sacrifice can show friendship.",
     explain:"The character gives something up to help a friend, so the theme fits."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G5",unit:"G5-MATH-FRAC",skill:"adding fractions",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Fractions with the same denominator can be added by adding the numerators.",
     workedExample:"2/8 + 3/8 = 5/8 because the denominator stays 8 and the numerators add to 5.",
     guidedPractice:"Keep the denominator the same when the parts are the same size.",
     q:"2/8 + 3/8 = ?",
     c:["5/8","5/16","1/8"],a:"5/8",
     explain:"The denominators match, so add 2 + 3 to get 5/8."},

    {gradeBand:"G5",unit:"G5-MATH-FRAC",skill:"multiplying fractions",difficulty:"grade 5",mode:"foundation",
     miniLesson:"To multiply fractions, multiply the numerators and multiply the denominators.",
     workedExample:"1/2 x 3/4 = 3/8 because 1 x 3 = 3 and 2 x 4 = 8.",
     guidedPractice:"Multiply straight across.",
     q:"1/2 x 3/4 = ?",
     c:["3/8","4/6","3/4"],a:"3/8",
     explain:"Multiply numerators and denominators: 1 x 3 = 3 and 2 x 4 = 8."},

    {gradeBand:"G5",unit:"G5-MATH-DEC",skill:"decimal place value",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Decimals use place value to show parts of a whole.",
     workedExample:"In 3.47, the 4 is in the tenths place and the 7 is in the hundredths place.",
     guidedPractice:"Look at the digit's place after the decimal.",
     q:"In 3.47, which digit is in the tenths place?",
     c:["4","7","3"],a:"4",
     explain:"The first digit after the decimal is the tenths place."},

    {gradeBand:"G5",unit:"G5-MATH-VOLUME",skill:"volume",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Volume measures how much space a solid figure takes up.",
     workedExample:"A rectangular prism with length 4, width 3, and height 2 has volume 4 x 3 x 2 = 24 cubic units.",
     guidedPractice:"Multiply length, width, and height.",
     q:"Volume of a 4 by 3 by 2 rectangular prism is...",
     c:["24 cubic units","9 cubic units","14 cubic units"],a:"24 cubic units",
     explain:"4 x 3 x 2 equals 24."},

    {gradeBand:"G5",unit:"G5-MATH-ORDER",skill:"order of operations",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Order of operations tells which operations to do first.",
     workedExample:"In 3 + 4 x 2, multiply first: 4 x 2 = 8. Then add 3 to get 11.",
     guidedPractice:"Do multiplication before addition unless parentheses change the order.",
     q:"3 + 4 x 2 = ?",
     c:["11","14","10"],a:"11",
     explain:"Multiply 4 x 2 first, then add 3."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G5",unit:"G5-ELA-GRAMMAR",skill:"compound and complex sentences",difficulty:"grade 5",mode:"foundation",
     miniLesson:"A compound sentence joins two complete thoughts. A complex sentence has a dependent clause and an independent clause.",
     workedExample:"The dragon slept, and the knight waited is compound. Because it rained, the path flooded is complex.",
     guidedPractice:"Look for joined complete thoughts or a dependent starter like because.",
     q:"Which word can begin a dependent clause?",
     c:["because","dragon","quickly"],a:"because",
     explain:"Because can begin a dependent clause."},

    {gradeBand:"G5",unit:"G5-ELA-WRITING",skill:"informative writing",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Informative writing explains a topic using facts and details.",
     workedExample:"A paragraph about erosion should explain what erosion is and give examples like wind or water moving sediment.",
     guidedPractice:"Use facts, definitions, and examples.",
     q:"Informative writing should mainly...",
     c:["explain with facts","tell only jokes","hide the topic"],a:"explain with facts",
     explain:"Informative writing teaches or explains a topic."},

    {gradeBand:"G5",unit:"G5-ELA-WRITING",skill:"evidence",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Evidence supports a claim or answer.",
     workedExample:"If you claim a character is loyal, a detail showing the character staying to help a friend can be evidence.",
     guidedPractice:"Choose proof that matches the claim.",
     q:"Evidence should support the...",
     c:["claim","font","page color"],a:"claim",
     explain:"Evidence proves or supports the claim."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G5",unit:"G5-SCI-MATTER",skill:"properties of matter",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Matter has properties that can be observed and measured.",
     workedExample:"Mass, volume, color, texture, and state are properties of matter.",
     guidedPractice:"Choose a property that describes matter.",
     q:"Which is a property of matter?",
     c:["mass","theme","citizenship"],a:"mass",
     explain:"Mass is a measurable property of matter."},

    {gradeBand:"G5",unit:"G5-SCI-EARTH",skill:"Earth systems",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Earth has interacting systems, including land, water, air, and living things.",
     workedExample:"Rain from the atmosphere can shape land by causing erosion.",
     guidedPractice:"Look for systems affecting one another.",
     q:"Rain causing erosion shows interaction between air/water and...",
     c:["land","grammar","fractions"],a:"land",
     explain:"Rainwater can move soil and rock, changing land."},

    {gradeBand:"G5",unit:"G5-SCI-LIFE",skill:"food chains",difficulty:"grade 5",mode:"foundation",
     miniLesson:"A food chain shows how energy moves from one organism to another.",
     workedExample:"Grass → rabbit → fox shows energy moving from producer to consumer to predator.",
     guidedPractice:"Find the producer first.",
     q:"In grass → rabbit → fox, the producer is...",
     c:["grass","rabbit","fox"],a:"grass",
     explain:"Grass makes its own food, so it is the producer."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G5",unit:"G5-SS-HISTORY",skill:"primary and secondary sources",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Primary sources come from the time studied. Secondary sources are later accounts.",
     workedExample:"A letter written during an event is primary. A textbook chapter written later is secondary.",
     guidedPractice:"Ask when and by whom the source was made.",
     q:"Which is a primary source?",
     c:["letter from the event","modern textbook","recent cartoon"],a:"letter from the event",
     explain:"A letter from the event was created at the time being studied."},

    {gradeBand:"G5",unit:"G5-SS-CIVICS",skill:"branches of government",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Government power can be divided among branches.",
     workedExample:"The legislative branch makes laws, the executive carries them out, and the judicial branch interprets them.",
     guidedPractice:"Match each branch to its job.",
     q:"Which branch makes laws?",
     c:["legislative","judicial","weather"],a:"legislative",
     explain:"The legislative branch makes laws."},

    {gradeBand:"G5",unit:"G5-SS-ECON",skill:"supply and demand",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Supply and demand can affect prices.",
     workedExample:"If many people want a rare item, demand is high and supply is low, so price may rise.",
     guidedPractice:"Think about how much exists and how much people want it.",
     q:"High demand and low supply often make prices...",
     c:["rise","always disappear","become zero"],a:"rise",
     explain:"When people want more than is available, prices often rise."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G5",unit:"G5-ART-DESIGN",skill:"balance",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Balance is how visual weight is arranged in an artwork.",
     workedExample:"A large dragon on one side might be balanced by several smaller trees on the other side.",
     guidedPractice:"Ask whether one side feels too visually heavy.",
     q:"Balance deals with visual...",
     c:["weight","temperature","multiplication"],a:"weight",
     explain:"Balance is the arrangement of visual weight."},

    {gradeBand:"G5",unit:"G5-ART-ANALYSIS",skill:"artist choices",difficulty:"grade 5",mode:"foundation",
     miniLesson:"Artists make choices about color, line, space, and focus to create meaning.",
     workedExample:"Dark colors and sharp lines can make a picture feel tense or dramatic.",
     guidedPractice:"Use details you can see in the artwork.",
     q:"Art analysis should use...",
     c:["visual evidence","random guesses","only the frame"],a:"visual evidence",
     explain:"Visual evidence comes from what can be seen in the artwork."}
  ]);
}

LR_addG5Foundation("Luna");
LR_addG5Foundation("Ava");
LR_addG5Foundation("Michael");
