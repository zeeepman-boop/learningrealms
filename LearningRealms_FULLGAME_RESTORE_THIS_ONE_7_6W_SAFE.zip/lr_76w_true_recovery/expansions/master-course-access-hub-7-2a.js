/* LearningRealms Master Course Access Hub 7.2A
   Makes the Great Depression 7.1 and Wild West 7.2 master courses visible from the cleaned hard UI.
   Content-only/access patch: no room engine rewrite, no home rewrite, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR_MASTER_COURSE_ACCESS_HUB_72A__) return;
  window.__LR_MASTER_COURSE_ACCESS_HUB_72A__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }
  function can(fn){ return typeof window[fn] === 'function'; }
  function call(fn){ if(can(fn)) return window[fn](); }
  function activeName(){
    try{ return window.activeChild || (window.LR_STATE && LR_STATE.active && LR_STATE.active.name) || localStorage.getItem('lrActiveChild') || 'Scholar'; }
    catch(e){ return 'Scholar'; }
  }
  function activeGrade(){
    try{
      var n = String(activeName()).toLowerCase();
      if(n.indexOf('luna') >= 0) return '1';
      if(n.indexOf('ava') >= 0) return '7';
      if(n.indexOf('michael') >= 0) return '8';
      return (window.LR_STATE && LR_STATE.active && LR_STATE.active.grade) || localStorage.getItem('lrActiveGrade') || '5+';
    }catch(e){ return '5+'; }
  }

  function popup(title, html){
    if(typeof window.lrOpenPopup === 'function') return window.lrOpenPopup(title, html);
    var actionTitle = byId('actionTitle');
    var actionText = byId('actionText');
    if(actionTitle && actionText){
      actionTitle.textContent = title;
      actionText.innerHTML = html;
      if(typeof window.lrOpenActionPopup === 'function') window.lrOpenActionPopup(title);
      return;
    }
    var old = byId('lrMasterHubFallback');
    if(old) old.remove();
    var div = document.createElement('div');
    div.id = 'lrMasterHubFallback';
    div.innerHTML = '<div class="lrMasterHubBackdrop" onclick="document.getElementById(\'lrMasterHubFallback\').remove()"></div><div class="lrMasterHubModal"><div class="lrMasterHubHead"><b>'+esc(title)+'</b><button type="button" onclick="document.getElementById(\'lrMasterHubFallback\').remove()">✕</button></div><div class="lrMasterHubBody">'+html+'</div></div>';
    document.body.appendChild(div);
  }

  function courseButton(label, sub, fn, fallback){
    var ready = can(fn);
    return '<button type="button" class="lrMasterCourseBtn '+(ready?'':'disabled')+'" onclick="'+(ready ? fn+'()' : 'openMasterCourseHub72A()')+'">' +
      '<b>'+esc(label)+'</b><span>'+esc(ready ? sub : fallback)+'</span></button>';
  }

  function hubHtml(){
    return '<div class="lrMasterHub">' +
      '<section class="lrMasterHubHero"><small>Master Course Access Hub 7.2A</small><h2>Brittney\'s emphasized history courses</h2>' +
      '<p>These buttons open the big guided course zones directly. They were already loaded, but the cleaned UI was hiding them behind the Learning Trails layer.</p>' +
      '<p><b>Current learner:</b> '+esc(activeName())+' · <b>Grade:</b> '+esc(activeGrade())+'</p></section>' +
      '<div class="lrMasterHubGrid">' +
        courseButton('🏚️ The Great Depression', 'Open History Street, lessons, quizzes, review, and rewards.', 'openGreatDepressionTrail', 'Great Depression file is not loaded yet.') +
        courseButton('🤠 The Wild West', 'Open Frontier Trail, lessons, quizzes, shops, and rewards.', 'openWildWestTrail', 'Wild West file is not loaded yet.') +
      '</div>' +
      '<div class="lrMasterHubSubGrid">' +
        (can('openGreatDepressionCourse')?'<button type="button" onclick="openGreatDepressionCourse()">Great Depression full course map</button>':'') +
        (can('openGreatDepressionRewards')?'<button type="button" onclick="openGreatDepressionRewards()">Great Depression rewards</button>':'') +
        (can('openWildWestCourse')?'<button type="button" onclick="openWildWestCourse()">Wild West full course map</button>':'') +
        (can('openWildWestShops')?'<button type="button" onclick="openWildWestShops()">Wild West shops</button>':'') +
      '</div>' +
      '<p class="lrMasterHubNote">Luna will still be gated out by the Grade 5+ course checks where they apply. Michael and Ava should be able to open these.</p>' +
    '</div>';
  }

  function openHub(){ popup('📚 Master Courses', hubHtml()); }

  function shellPanelHtml(){
    return '<div class="lrMasterShellPanel" id="lrMasterShellPanel72A">' +
      '<div><b>📚 Brittney Master Courses</b><small>Direct access so the new courses are not hidden.</small></div>' +
      '<div class="lrMasterShellButtons">' +
        '<button type="button" onclick="openMasterCourseHub72A()">Course hub</button>' +
        (can('openGreatDepressionTrail')?'<button type="button" onclick="openGreatDepressionTrail()">Great Depression</button>':'') +
        (can('openWildWestTrail')?'<button type="button" onclick="openWildWestTrail()">Wild West</button>':'') +
      '</div>' +
    '</div>';
  }

  function injectShellPanel(){
    try{
      var shell = byId('lrCleanGameShell');
      if(!shell) return;
      var existing = byId('lrMasterShellPanel72A');
      if(existing) return;
      var target = shell.querySelector('.lrCleanActionZone') || shell;
      var wrap = document.createElement('div');
      wrap.innerHTML = shellPanelHtml();
      target.parentNode.insertBefore(wrap.firstChild, target.nextSibling);
    }catch(e){}
  }

  function injectMenuButtons(){
    try{
      var panel = document.querySelector('#actionText .lrCleanMenuPanel') || document.querySelector('.lrCleanMenuPanel');
      if(!panel || panel.querySelector('[data-masterhub72a]')) return;
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('data-masterhub72a','1');
      btn.innerHTML = '📚 Brittney Master Courses';
      btn.onclick = openHub;
      panel.insertBefore(btn, panel.firstChild);
      if(can('openGreatDepressionTrail')){
        var gd = document.createElement('button'); gd.type='button'; gd.innerHTML='🏚️ Great Depression'; gd.onclick=function(){ call('openGreatDepressionTrail'); }; panel.insertBefore(gd, btn.nextSibling);
      }
      if(can('openWildWestTrail')){
        var ww = document.createElement('button'); ww.type='button'; ww.innerHTML='🤠 Wild West'; ww.onclick=function(){ call('openWildWestTrail'); }; panel.insertBefore(ww, btn.nextSibling);
      }
    }catch(e){}
  }

  function wrapMenu(){
    try{
      if(typeof window.lrHardMenu === 'function' && !window.lrHardMenu.__masterHub72A){
        var old = window.lrHardMenu;
        var repl = function(){ var out = old.apply(this, arguments); setTimeout(injectMenuButtons, 40); setTimeout(injectMenuButtons, 180); return out; };
        repl.__masterHub72A = true;
        window.lrHardMenu = repl;
        try{ lrHardMenu = repl; }catch(e){}
      }
    }catch(e){}
  }

  function wrapLessonButton(){
    try{
      if(typeof window.lrHardLesson === 'function' && !window.lrHardLesson.__masterHub72A){
        var old = window.lrHardLesson;
        var repl = function(){
          openHub();
          var body = byId('lrPopupBody') || byId('actionText') || document.querySelector('.lrPopupBody');
          if(body && !body.querySelector('[data-real-curriculum-fallback]')){
            var extra = document.createElement('div');
            extra.setAttribute('data-real-curriculum-fallback','1');
            extra.className='lrMasterHubFallbackRow';
            extra.innerHTML='<button type="button" onclick="openRealCurriculumPicker && openRealCurriculumPicker()">Open regular REAL Curriculum picker</button>';
            body.appendChild(extra);
          }
          setTimeout(injectShellPanel,80);
          return false;
        };
        repl.__masterHub72A = true;
        window.lrHardLesson = repl;
        try{ lrHardLesson = repl; }catch(e){}
      }
    }catch(e){}
  }

  function styles(){
    if(byId('lrMasterHub72AStyles')) return;
    var st = document.createElement('style');
    st.id = 'lrMasterHub72AStyles';
    st.textContent = '.lrMasterShellPanel{margin:14px 0;padding:14px;border:2px solid #7b5a23;border-radius:18px;background:linear-gradient(135deg,#fff8dc,#f4e0ad);box-shadow:0 8px 20px rgba(0,0,0,.12);color:#2b2418}.lrMasterShellPanel b{display:block;font-size:1.05rem}.lrMasterShellPanel small{display:block;opacity:.82;margin-top:2px}.lrMasterShellButtons{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}.lrMasterShellButtons button,.lrMasterHub button{border:2px solid #5f421a;border-radius:14px;background:#fffef6;color:#2b2418;font-weight:900;padding:12px 14px;cursor:pointer}.lrMasterShellButtons button:hover,.lrMasterHub button:hover{transform:translateY(-1px);box-shadow:0 6px 14px rgba(0,0,0,.16)}.lrMasterHub{font-family:inherit;color:#2b2418;line-height:1.55}.lrMasterHubHero{padding:18px;border-radius:20px;background:linear-gradient(135deg,#fff7d6,#e8c77e);border:2px solid #7b5a23;margin-bottom:16px}.lrMasterHubHero h2{margin:.2rem 0 .5rem;font-size:clamp(1.6rem,4vw,2.4rem)}.lrMasterHubGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin:14px 0}.lrMasterCourseBtn{text-align:left;min-height:120px}.lrMasterCourseBtn b{display:block;font-size:1.15rem;margin-bottom:8px}.lrMasterCourseBtn span{display:block;font-weight:700;opacity:.84}.lrMasterCourseBtn.disabled{opacity:.62}.lrMasterHubSubGrid{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}.lrMasterHubNote{font-size:.95rem;opacity:.78}.lrMasterHubFallbackRow{margin-top:14px;padding-top:12px;border-top:1px solid rgba(0,0,0,.15)}.lrMasterHubBackdrop{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99998}.lrMasterHubModal{position:fixed;z-index:99999;left:50%;top:50%;transform:translate(-50%,-50%);width:min(980px,94vw);max-height:92vh;overflow:auto;background:#fffdf3;border:3px solid #5f421a;border-radius:22px;box-shadow:0 22px 80px rgba(0,0,0,.45)}.lrMasterHubHead{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;background:#e8c77e;border-bottom:2px solid #5f421a}.lrMasterHubHead button{font-size:1.2rem}.lrMasterHubBody{padding:18px}';
    document.head.appendChild(st);
  }

  function boot(){ styles(); wrapMenu(); wrapLessonButton(); injectShellPanel(); setTimeout(injectShellPanel,200); setTimeout(injectMenuButtons,500); }
  window.openMasterCourseHub72A = openHub;
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ boot(); setTimeout(boot,500); setTimeout(boot,1500); });
  try{ new MutationObserver(function(){ injectShellPanel(); wrapMenu(); wrapLessonButton(); }).observe(document.documentElement,{childList:true,subtree:true}); }catch(e){}
})();
