// Question Mountain Phase 9 - Nature Deepening III
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Nature",[
{teach:"Leaves help plants.",q:"Leaves belong to...",c:["plants","rocks","maps"],a:"plants"},
{teach:"Birds build nests.",q:"Bird homes can be...",c:["nests","equations","coins"],a:"nests"},
{teach:"The sun gives light.",q:"The sun gives...",c:["light","paper","books"],a:"light"},
{teach:"Water helps living things.",q:"Living things need...",c:["water","paint","titles"],a:"water"},
{teach:"Forests have many plants.",q:"Forests have many...",c:["plants","roads","tables"],a:"plants"}
]);

LR_addLessons("Ava","Nature",[
{teach:"Decomposers break down matter.",q:"Decomposers help...",c:["break down matter","freeze water","draw maps"],a:"break down matter"},
{teach:"Clouds are part of weather.",q:"Clouds are part of...",c:["weather","writing","geometry"],a:"weather"},
{teach:"Habitats provide resources.",q:"Habitats provide...",c:["resources","equations","stories"],a:"resources"},
{teach:"Pollination helps plants.",q:"Pollination helps...",c:["plants","coins","titles"],a:"plants"},
{teach:"Exercise supports health.",q:"Exercise supports...",c:["health","maps","trade"],a:"health"}
]);

LR_addLessons("Michael","Nature",[
{teach:"Biodiversity means variety of life.",q:"Biodiversity means...",c:["variety of life","one species","weather only"],a:"variety of life"},
{teach:"Watersheds move water.",q:"Watersheds relate to...",c:["water","graphs","titles"],a:"water"},
{teach:"Organisms adapt to environments.",q:"Adaptations help organisms...",c:["survive","sleep","hide"],a:"survive"},
{teach:"Weathering changes land.",q:"Weathering changes...",c:["land","fonts","coins"],a:"land"},
{teach:"Natural resources can be managed.",q:"Resources can be...",c:["managed","ignored","hidden"],a:"managed"}
]);
})();