LR_addLessons("Michael","Math",[
 {teach:"3x + 4 = 10. Subtract 4 first.",practice:"10 - 4 = 6, then 6 ÷ 3 = 2.",q:"x = ?",c:["2","3","4"],a:"2"},
 {teach:"y = mx + b is slope-intercept form.",practice:"In y = 2x + 3, slope is 2.",q:"In y = 2x + 3, slope is?",c:["2","3","5"],a:"2"}
]);
LR_addLessons("Michael","English",[
 {teach:"Claims need evidence.",practice:"A quote can support a claim.",q:"What supports a claim?",c:["evidence","guess","title"],a:"evidence"}
]);
LR_addLessons("Michael","Science",[
 {teach:"Atoms make matter.",practice:"Matter is made of atoms.",q:"Matter is made of?",c:["atoms","clouds","light"],a:"atoms"}
]);
LR_addLessons("Michael","History",[
 {teach:"Cause explains why something happened.",practice:"Heavy rain damaged the bridge.",q:"What caused the closure?",c:["heavy rain","the moon","a new map"],a:"heavy rain"}
]);
