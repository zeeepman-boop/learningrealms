/* LearningRealms Ancient Egypt Visibility + Route Fix 7.4B
   Purpose: make Ancient Egypt impossible to miss while keeping it under the History umbrella.
   Adds no new shell rewrite, no loading curtain, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR_ANCIENT_EGYPT_VISIBILITY_74B__) return;
  window.__LR_ANCIENT_EGYPT_VISIBILITY_74B__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function txt(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    if(!has(fn)) return false;
    try{ window[fn](); return true; }catch(e){ console.warn('Egypt route failed:', fn, e); return false; }
  }
  function openEgypt(){
    if(call('openAncientEgyptTrail')) return true;
    if(call('openAncientEgyptCourse')) return true;
    if(call('lr73pDo')){ try{ window.lr73pDo('history'); }catch(e){} return true; }
    if(call('openLearningRealmsHistoryWing')) return true;
    return false;
  }
  window.openLearningRealmsEgypt = openEgypt;

  function cardHtml(){
    return '<button type="button" class="lr73pCard lr74bEgyptCard" data-lr74b-act="egypt">'+
      '<span class="lr73pCardIcon">🏺</span><span><b>Ancient Egypt Expedition</b><small>History Master Road</small>'+ 
      '<p>Nile, pharaohs, pyramids, Sphinx, scribes, daily life, temples, tombs, archaeology, and real evidence habits.</p></span>'+ 
      '<span class="lr73pCardArrow">›</span></button>';
  }
  function miniDoorHtml(){
    return '<div class="lr74bEgyptDoor"><div><b>🏺 Ancient Egypt Expedition</b><small>History Wing Road</small><p>Brittney’s Egypt course lives here under History. Enter the Nile road for the deep reading chambers.</p></div><button type="button" data-lr74b-act="egypt">Enter Egypt</button></div>';
  }

  function installStyles(){
    if(byId('lr74bEgyptStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr74bEgyptStyles';
    st.textContent = `
      .lr74bEgyptCard{background:linear-gradient(180deg,#fff4bf,#d9b361 64%,#b9872e)!important;border:2px solid rgba(92,56,10,.45)!important;box-shadow:0 12px 24px rgba(0,0,0,.30), inset 0 0 0 1px rgba(255,255,255,.38)!important;}
      .lr74bEgyptCard .lr73pCardIcon{background:radial-gradient(circle at 35% 20%,#fff0ac,#b87d27 52%,#56300c)!important;}
      .lr74bEgyptDoor{margin:12px 14px 0;padding:13px;display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;border:1px solid rgba(245,223,154,.34);border-radius:16px;background:linear-gradient(135deg,rgba(255,242,189,.16),rgba(187,128,39,.16));color:#fff0bb;box-shadow:0 8px 18px rgba(0,0,0,.24);}
      .lr74bEgyptDoor b{display:block;color:#fff4ca;font-size:1.08rem;}.lr74bEgyptDoor small{display:block;color:#ebd393;text-transform:uppercase;letter-spacing:.06em;font-weight:1000;font-size:.68rem;margin:3px 0 5px;}.lr74bEgyptDoor p{margin:0;color:#dbeadf;font-weight:780;line-height:1.35;}.lr74bEgyptDoor button,.lr74bCommandEgypt{border:1px solid rgba(245,223,154,.42)!important;border-radius:999px!important;background:linear-gradient(180deg,#fff3bd,#d8a046)!important;color:#1f1205!important;font-weight:1000!important;padding:9px 13px!important;cursor:pointer!important;box-shadow:0 6px 12px rgba(0,0,0,.24)!important;}
      .lr74bCommandEgypt{display:grid!important;grid-template-columns:34px 1fr!important;gap:7px!important;align-items:center!important;text-align:left!important;border-radius:10px!important;min-height:44px!important;}
      .lr74bCommandEgypt span{width:30px;height:30px;display:grid;place-items:center;border-radius:8px;background:linear-gradient(180deg,#5b3510,#1a1008);color:#ffe8aa;font-size:1.1rem;}
      @media(max-width:760px){.lr74bEgyptDoor{grid-template-columns:1fr}.lr74bEgyptDoor button{width:100%;}}
    `;
    document.head.appendChild(st);
  }

  function isAtlasOrHistory(){
    var root = byId('lrDynamicAdventureScreen');
    if(!root) return false;
    var t = txt(root);
    return /Realm Atlas|Choose a wing|History and World Wing|Past roads|History Master Roads|World and Society Topics/i.test(t);
  }
  function screenIsAtlas(root){ return /Realm Atlas|Choose a wing of the realm/i.test(txt(root)); }
  function screenIsHistory(root){ return /History and World Wing|Past roads|History Master Roads/i.test(txt(root)); }

  function patchCards(){
    var root = byId('lrDynamicAdventureScreen');
    if(!root || !isAtlasOrHistory()) return;
    // Make any older Ancient Worlds/Heritage card explicitly become Egypt.
    qa('.lr73pCard', root).forEach(function(c){
      var t = txt(c);
      if(/Ancient Worlds Gate|Ancient Worlds|Heritage/i.test(t) && !/Ancient Egypt/i.test(t)){
        c.setAttribute('data-lr74b-act','egypt');
        c.removeAttribute('data-lr73p-act');
        c.classList.add('lr74bEgyptCard');
        c.innerHTML = '<span class="lr73pCardIcon">🏺</span><span><b>Ancient Egypt Expedition</b><small>History Master Road</small><p>Nile, pharaohs, pyramids, Sphinx, scribes, daily life, beliefs, archaeology, and evidence habits.</p></span><span class="lr73pCardArrow">›</span>';
      }
    });

    // On the main Atlas, add a visible Egypt card inside the History and World Wing section, not as a floating top button.
    if(screenIsAtlas(root) && !q('.lr74bEgyptCard', root)){
      var sections = qa('.lr73pSection', root);
      var historySection = null;
      sections.forEach(function(sec){ if(/History and World Wing/i.test(txt(sec))) historySection = sec; });
      var grid = historySection && q('.lr73pGrid', historySection);
      if(grid) grid.insertAdjacentHTML('beforeend', cardHtml());
    }

    // On the History Wing page, put a short in-world door above the cards so it is not buried below the fold.
    if(screenIsHistory(root) && !q('.lr74bEgyptDoor', root)){
      var target = q('.lr73pSections', root) || root;
      target.insertAdjacentHTML('afterbegin', miniDoorHtml());
    }
  }

  function patchCommands(){
    var host = byId('leftActionButtons');
    if(!host || q('[data-lr74b-act="egypt"]', host)) return;
    var historyBtn = q('[data-lr73p-act="history"], [data-lr73o-act="history"], [data-lr73m-act="history"]', host);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'lr74bCommandEgypt';
    btn.setAttribute('data-lr74b-act','egypt');
    btn.innerHTML = '<span>🏺</span><b>Egypt Road</b>';
    if(historyBtn && historyBtn.parentNode){ historyBtn.parentNode.insertBefore(btn, historyBtn.nextSibling); }
    else{ host.appendChild(btn); }
  }

  function patchHeaderBreadcrumb(){
    var root = byId('lrDynamicAdventureScreen');
    if(!root || !screenIsHistory(root)) return;
    var hero = q('.lr73pHero', root);
    if(!hero || q('.lr74bHistoryCrumb', hero)) return;
    var p = document.createElement('p');
    p.className = 'lr74bHistoryCrumb';
    p.innerHTML = '<small>History roads here: Great Depression · Wild West · Shipwreck Cove · <b>Ancient Egypt Expedition</b></small>';
    hero.appendChild(p);
  }

  function patch(){
    installStyles();
    patchCards();
    patchCommands();
    patchHeaderBreadcrumb();
  }

  function bind(){
    if(window.__LR74B_EGYPT_BIND__) return;
    window.__LR74B_EGYPT_BIND__ = true;
    window.addEventListener('click', function(ev){
      var t = ev.target && ev.target.closest ? ev.target.closest('[data-lr74b-act="egypt"]') : null;
      if(!t) return;
      ev.preventDefault();
      ev.stopImmediatePropagation();
      openEgypt();
      setTimeout(patch,120);
    }, true);
  }

  function boot(){
    bind(); patch();
    setTimeout(patch,160);
    setTimeout(patch,650);
    setTimeout(patch,1400);
    try{ var mo = new MutationObserver(function(){ setTimeout(patch,60); }); mo.observe(document.body,{subtree:true,childList:true}); }catch(e){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,80); setTimeout(patch,900); });
})();
