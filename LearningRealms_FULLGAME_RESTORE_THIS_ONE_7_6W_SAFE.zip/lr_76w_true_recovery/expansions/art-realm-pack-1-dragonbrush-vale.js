// Art Realm Pack 1: Dragonbrush Vale
// Adds a new Art subject zone and starter curriculum for Luna, Ava, and Michael.
// World + curriculum only. Minimal engine touch required.

// ---------- Rooms ----------
(function(){
  if(!window.ROOMS) return;

  const artRooms = {
    dragonbrushRoad1:{
      name:"Lantern Path",
      zone:"Dragonbrush Vale Road",
      desc:"A cobbled lane bends away from town beneath painted lanterns shaped like dragon eggs. A wooden sign shows a brush crossed with a dragon wing. The air smells faintly of pine, parchment, and paint.",
      exits:{west:"westGateRoad", east:"dragonbrushRoad2"}
    },
    dragonbrushRoad2:{
      name:"Painter's Rise",
      zone:"Dragonbrush Vale Road",
      desc:"The road climbs a gentle rise where ribbons hang from poles and flutter in the breeze like banners at a festival. A tiny lizard shaped almost like a hatchling dragon scampers through wildflowers.",
      exits:{west:"dragonbrushRoad1", east:"dragonbrushRoad3"}
    },
    dragonbrushRoad3:{
      name:"Bridge of Colors",
      zone:"Dragonbrush Vale Road",
      desc:"A bright arched bridge crosses a clear stream. Mineral streaks in the stones make the water sparkle with reds, blues, and golds. Beyond the bridge, high cliffs curve around a hidden valley.",
      exits:{west:"dragonbrushRoad2", east:"dragonbrushVale1"}
    },

    dragonbrushVale1:{
      name:"Dragonbrush Gate",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"You stand at the entrance to Dragonbrush Vale, a peaceful bowl of green hills and painted stone paths. Colorful streamers hang between carved dragon statues. Gentle music drifts from somewhere ahead.",
      npcs:[
        "A small ember scaled dragon perches on a gatepost, swishing its tail through the air as if sketching invisible lines.",
      ],
      exits:{west:"dragonbrushRoad3", east:"dragonbrushVale2", south:"dragonbrushVale4"}
    },
    dragonbrushVale2:{
      name:"Palette Meadow",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"Soft grass ripples through a meadow ringed by flowers in every shade. Painted easels stand under the open sky. A broad flat stone nearby is dotted with dry specks of color left by earlier students.",
      npcs:[
        "A cheerful paint splattered dragon hums to itself while tapping little jars of color with one claw.",
      ],
      exits:{west:"dragonbrushVale1", east:"dragonbrushVale3", south:"dragonbrushVale5"}
    },
    dragonbrushVale3:{
      name:"Winglight Overlook",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"A cliff overlook opens above the vale, where sunlight strikes crystal fragments set into the path. Looking out from here, the hills and trees make clear foreground and background layers, perfect for a lesson in perspective.",
      npcs:[
        "An old silver dragon sits neatly beside a viewing stand, eyes bright with patient wisdom.",
      ],
      exits:{west:"dragonbrushVale2", south:"dragonbrushVale6"}
    },
    dragonbrushVale4:{
      name:"Sketch Hollow",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"A quiet hollow beneath bent willow branches shelters long benches, charcoal sticks, and smooth paper boards. The hush here makes every scratch of pencil feel important.",
      npcs:[
        "A smoke gray dragon curls around a stump table, carefully arranging charcoal, chalk, and soft erasers.",
      ],
      exits:{north:"dragonbrushVale1", east:"dragonbrushVale5"}
    },
    dragonbrushVale5:{
      name:"Mural Court",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"Tall stone walls form an open court covered in bright murals of heroes, animals, castles, storms, and stars. Some pictures are simple and bold. Others are layered with tiny details that reward a long look.",
      npcs:[
        "A broad green dragon with paint on both horns studies a half finished mural and nods as if inviting you to notice its story.",
      ],
      exits:{north:"dragonbrushVale2", west:"dragonbrushVale4", east:"dragonbrushVale6"}
    },
    dragonbrushVale6:{
      name:"Hall of Bright Scales",
      zone:"Dragonbrush Vale",
      subject:"Art",
      desc:"This round teaching hall is roofed in overlapping tiles that gleam like dragon scales. Finished student paintings line the walls. Pedestals display carved masks, clay figures, and folded paper dragons.",
      npcs:[
        "A majestic blue dragon wearing a little ribboned satchel watches over the hall like a master art teacher.",
      ],
      exits:{north:"dragonbrushVale3", west:"dragonbrushVale5"}
    }
  };

  Object.assign(ROOMS, artRooms);
})();

// ---------- World hooks ----------
(function(){
  if(!window.ROOMS) return;
  // Connect from town gate road if it exists.
  if(ROOMS.eastGateRoad){
    ROOMS.eastGateRoad.exits = ROOMS.eastGateRoad.exits || {};
    if(!ROOMS.eastGateRoad.exits.south) ROOMS.eastGateRoad.exits.south = "dragonbrushRoad1";
  }
  if(ROOMS.mainStreetEast){
    ROOMS.mainStreetEast.exits = ROOMS.mainStreetEast.exits || {};
    if(!ROOMS.mainStreetEast.exits.east) ROOMS.mainStreetEast.exits.east = "dragonbrushRoad1";
  }
})();

// ---------- Curriculum ----------
LR_addLessons("Luna","Art",[
 {unit:"G1-ART-COLOR",skill:"primary colors",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Artists use color to make pictures bright and interesting. Some colors are called primary colors.",
  workedExample:"Red, blue, and yellow are primary colors. Many other colors can be made from them.",
  guidedPractice:"Say the primary colors aloud and picture them in your mind.",
  q:"Which color is a primary color?",
  c:["red","pink","brown"],a:"red",
  explain:"Red is one of the three primary colors: red, blue, and yellow."},

 {unit:"G1-ART-LINES",skill:"lines",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Lines can be straight, curved, zigzag, thick, or thin. Artists use lines to show shapes and movement.",
  workedExample:"A road might be drawn with straight lines. A snake might be drawn with curving lines.",
  guidedPractice:"Think about which kind of line looks bendy.",
  q:"Which kind of line looks bendy?",
  c:["curved line","straight line","dotted box"],a:"curved line",
  explain:"A curved line bends instead of going straight."},

 {unit:"G1-ART-SHAPES",skill:"shapes",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Shapes are everywhere in art. Circles, squares, triangles, and rectangles help build pictures.",
  workedExample:"A sun may be a circle. A house may use a square wall and a triangle roof.",
  guidedPractice:"Look for the shape that could be used for a roof.",
  q:"Which shape could make a roof on a simple house drawing?",
  c:["triangle","circle","oval"],a:"triangle",
  explain:"A triangle is often used for a pointed roof."},

 {unit:"G1-ART-PATTERN",skill:"patterns",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A pattern repeats in an expected way.",
  workedExample:"Red, blue, red, blue is a pattern because the colors repeat in order.",
  guidedPractice:"Look for what comes next in the repeat.",
  q:"What comes next in the pattern red, blue, red, blue, ...?",
  c:["red","green","yellow"],a:"red",
  explain:"The pattern repeats red, blue, so red comes next."},

 {unit:"G1-ART-STORY",skill:"picture storytelling",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Pictures can tell stories even without many words.",
  workedExample:"A picture of dark clouds, a running rabbit, and a puddle may tell about a storm.",
  guidedPractice:"Think about what details help show what is happening.",
  q:"Which detail best helps show that a picture tells a storm story?",
  c:["dark clouds","a blank wall","an empty page"],a:"dark clouds",
  explain:"Dark clouds help the viewer understand that a storm may be coming."}
]);

LR_addLessons("Ava","Art",[
 {unit:"G7-ART-COLOR",skill:"warm and cool colors",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Colors are often grouped as warm or cool. Warm colors can feel energetic. Cool colors can feel calm.",
  workedExample:"Red, orange, and yellow are usually warm. Blue, green, and violet are usually cool.",
  guidedPractice:"Think about which color family a calm lake scene might use.",
  q:"Which is usually a cool color?",
  c:["blue","orange","red"],a:"blue",
  explain:"Blue is commonly grouped with the cool colors."},

 {unit:"G7-ART-VALUE",skill:"value",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Value means how light or dark a color is.",
  workedExample:"A sphere can look rounder if one side is shaded darker and the other side stays lighter.",
  guidedPractice:"Look for the word that means lightness or darkness.",
  q:"In art, value means the...",
  c:["lightness or darkness of a color","size of the paper","name of the artist"],a:"lightness or darkness of a color",
  explain:"Value is about how light or dark something appears."},

 {unit:"G7-ART-COMPOSITION",skill:"composition",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Composition is how the parts of an artwork are arranged.",
  workedExample:"If the main subject is centered and everything else points toward it, the composition helps guide the viewer's eye.",
  guidedPractice:"Ask where the viewer looks first and why.",
  q:"Composition is the arrangement of...",
  c:["parts of an artwork","only paint colors","only words in a title"],a:"parts of an artwork",
  explain:"Composition is about how visual parts are placed together."},

 {unit:"G7-ART-PERSPECTIVE",skill:"foreground and background",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Artists can show depth by using foreground, middle ground, and background.",
  workedExample:"A large tree in front may be foreground. Hills behind it may be middle ground. Far mountains may be background.",
  guidedPractice:"Think about which part looks closest to the viewer.",
  q:"Which part of a picture usually looks closest to the viewer?",
  c:["foreground","background","caption"],a:"foreground",
  explain:"The foreground is the area nearest the viewer."},

 {unit:"G7-ART-CRITIQUE",skill:"art vocabulary",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"When talking about art, it helps to use precise words such as color, line, texture, and balance.",
  workedExample:"Instead of saying 'It looks nice,' you might say 'The artist uses rough texture and strong contrast.'",
  guidedPractice:"Choose the word that belongs to art vocabulary.",
  q:"Which word is part of art vocabulary?",
  c:["texture","denominator","legislature"],a:"texture",
  explain:"Texture is a common art term used to describe how a surface looks or feels."}
]);

LR_addLessons("Michael","Art",[
 {unit:"G8-ART-FORM",skill:"form",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Form is the three dimensional look of an object in art. Artists use light and shadow to make a flat drawing look solid.",
  workedExample:"A circle becomes a sphere-like form when one side is highlighted and the other side is shaded.",
  guidedPractice:"Think about what makes a shape look solid instead of flat.",
  q:"What helps a flat shape look more like a solid form?",
  c:["light and shadow","only a title","larger paper"],a:"light and shadow",
  explain:"Light and shadow make a form look rounded and three dimensional."},

 {unit:"G8-ART-PERSPECTIVE",skill:"one-point perspective",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"One point perspective uses a single vanishing point to show depth.",
  workedExample:"Railroad tracks seem to move toward one point in the distance. That point is the vanishing point.",
  guidedPractice:"Ask where receding lines seem to meet.",
  q:"In one point perspective, lines seem to meet at the...",
  c:["vanishing point","color wheel","frame edge"],a:"vanishing point",
  explain:"The vanishing point is where receding lines appear to come together."},

 {unit:"G8-ART-PROPORTION",skill:"proportion",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Proportion is the size relationship between parts of a figure or object.",
  workedExample:"If a hand is drawn bigger than a whole head by accident, the proportions may look incorrect.",
  guidedPractice:"Think about whether the parts fit together believably.",
  q:"Proportion is about the relationship of...",
  c:["sizes of parts","only background colors","the artist's signature"],a:"sizes of parts",
  explain:"Proportion compares the sizes of different parts of the artwork."},

 {unit:"G8-ART-DESIGN",skill:"contrast",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Contrast is a strong difference between elements, such as light and dark or rough and smooth.",
  workedExample:"A bright white shape on a black background creates strong contrast and stands out right away.",
  guidedPractice:"Look for the word that means a strong difference.",
  q:"A strong difference between light and dark is called...",
  c:["contrast","rhythm","suffix"],a:"contrast",
  explain:"Contrast helps important parts of an artwork stand out."},

 {unit:"G8-ART-ANALYSIS",skill:"analyzing art",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Analyzing art means looking carefully at what choices the artist made and what effect those choices have.",
  workedExample:"You might notice muted colors, empty space, and a small figure, then explain that the artwork feels lonely or quiet.",
  guidedPractice:"Move from observation to explanation.",
  q:"Which best describes analyzing art?",
  c:["studying the artist's choices and effects","counting only the frame corners","guessing without looking"],a:"studying the artist's choices and effects",
  explain:"Art analysis examines artistic choices and what they communicate to the viewer."}
]);

// ---------- Optional boss seeds for future use ----------
window.BOSS_QUESTIONS = window.BOSS_QUESTIONS || {};
if(!window.BOSS_QUESTIONS.Art){
  window.BOSS_QUESTIONS.Art = [
    {q:"Which term means how light or dark a color is?", c:["value","outline","plot"], a:"value"},
    {q:"In one point perspective, receding lines move toward the...", c:["vanishing point","horizon cloud","paint jar"], a:"vanishing point"},
    {q:"Which art principle uses strong differences to help something stand out?", c:["contrast","comma splice","evaporation"], a:"contrast"}
  ];
}
