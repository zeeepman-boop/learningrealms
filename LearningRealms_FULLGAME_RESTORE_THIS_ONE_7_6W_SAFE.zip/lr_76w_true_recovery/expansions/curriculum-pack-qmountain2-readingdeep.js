// Question Mountain Phase 2 - Reading Deepening
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Reading",[
{teach:"The middle comes after the beginning.",q:"The middle comes after the...",c:["beginning","ending","cover"],a:"beginning"},
{teach:"Pictures can help tell a story.",q:"Pictures can help tell...",c:["stories","weather","time"],a:"stories"},
{teach:"The ending finishes a story.",q:"What finishes a story?",c:["ending","middle","title"],a:"ending"},
{teach:"Characters can solve problems.",q:"Who solves problems?",c:["characters","rocks","maps"],a:"characters"},
{teach:"Events happen in order.",q:"Stories have event...",c:["order","colors","coins"],a:"order"}
]);

LR_addLessons("Ava","Reading",[
{teach:"Summaries keep important ideas.",q:"Summaries keep...",c:["important ideas","every detail","pictures"],a:"important ideas"},
{teach:"Authors use text evidence.",q:"Evidence comes from...",c:["the text","luck","maps"],a:"the text"},
{teach:"Sequence tracks order.",q:"Sequence means...",c:["order","shape","trade"],a:"order"},
{teach:"Compare means alike.",q:"Compare looks for...",c:["similarities","differences only","titles"],a:"similarities"},
{teach:"Contrast means different.",q:"Contrast looks for...",c:["differences","maps","coins"],a:"differences"}
]);

LR_addLessons("Michael","Reading",[
{teach:"Claims need support.",q:"Claims need...",c:["support","colors","covers"],a:"support"},
{teach:"Bias can affect texts.",q:"Bias can affect...",c:["texts","equations","maps"],a:"texts"},
{teach:"Tone affects meaning.",q:"Tone affects...",c:["meaning","paper color","fonts"],a:"meaning"},
{teach:"Central ideas develop over time.",q:"Central ideas can...",c:["develop","freeze","vanish"],a:"develop"},
{teach:"Sources should be evaluated.",q:"Readers should evaluate...",c:["sources","titles","covers"],a:"sources"}
]);
})();