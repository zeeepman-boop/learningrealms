/* LearningRealms Merchant Square Hardening 6.9A
   Stability-only patch for the new shopkeeper economy.
   No new lessons, no new rewards, no save reset.
   It hardens rendering, old-shop redirects, rapid-click protection,
   route checking, and dynamic-screen recovery for Merchant Square.
*/
(function(){
  'use strict';
  if(window.__LR69A_MERCHANT_SQUARE_HARDENING__) return;
  window.__LR69A_MERCHANT_SQUARE_HARDENING__ = true;

  var ACTIVE = false;
  var LAST = {type:'square', args:[]};
  var LOCKS = {};

  function byId(id){ return document.getElementById(id); }
  function esc(v){ return String(v === undefined || v === null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function text(el){ return (el && (el.textContent || el.innerText || '')) || ''; }
  function getState(){ try{ if(window.state) return window.state; }catch(e){} try{ if(typeof state !== 'undefined') return state; }catch(e){} return null; }
  function call(name){ var args=[].slice.call(arguments,1); try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR69A call failed', name, e); } return undefined; }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }
  function popupOpen(){
    var root=byId('lrPopupRoot') || document.querySelector('.popup,.modal,.overlay');
    if(!root) return false;
    if(root.classList && root.classList.contains('hidden')) return false;
    try{ var cs=getComputedStyle(root); if(cs.display==='none' || cs.visibility==='hidden' || cs.opacity==='0') return false; }catch(e){}
    return true;
  }

  function ensureMount(){
    try{
      document.body.classList.add('lrDynamicAdventureMode','lr68DynamicShell','lr69MerchantSquareMode','lr69aMerchantHardening');
      document.body.classList.remove('homeMode');
    }catch(e){}
    var main=document.querySelector('.main') || document.querySelector('main') || document.body;
    var first=document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; main.style.maxWidth='none'; main.style.minWidth='0'; }
      if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; first.style.minWidth='0'; first.style.overflow='hidden'; }
    }catch(e){}
    var mount=byId('lrDynamicAdventureScreen');
    if(!mount){
      mount=document.createElement('div'); mount.id='lrDynamicAdventureScreen'; mount.className='lrDynamicAdventureScreen lr69Screen lr69aHardenedScreen';
      if(first && first.firstChild) first.insertBefore(mount, first.firstChild); else (first || document.body).appendChild(mount);
    }
    try{
      mount.classList.add('lr69aHardenedScreen');
      mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none'; mount.style.minHeight='680px';
    }catch(e){}
    suppressLegacy();
    return mount;
  }

  function suppressLegacy(){
    ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','movementControls','leftActionButtons'].forEach(function(id){
      var el=byId(id); if(el){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
    });
    try{
      document.querySelectorAll('.compassBox,.compassGrid,.movementButtons,.travelButtons,.tinyTravelFooter,.lrAdventurePanel,.lrExplorePanel,.lr65ExplorePanel,.lr66AdventureChoiceNav,.lr66AdventureNav,.lr67ChoicePanelClone,[data-lr-legacy-nav],[data-old-navigation]').forEach(function(el){
        if(el.closest && (el.closest('#lrDynamicAdventureScreen') || el.closest('#lrPopupRoot'))) return;
        el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden';
      });
    }catch(e){}
  }

  function withLock(key, fn){
    if(LOCKS[key]) return false;
    LOCKS[key]=true;
    try{ return fn(); }
    finally{ setTimeout(function(){ LOCKS[key]=false; }, 850); }
  }

  function markActive(type, args){ ACTIVE=true; LAST={type:type||'square', args:args||[]}; ensureMount(); }
  function markInactive(){ ACTIVE=false; suppressLegacy(); }

  function enhance(){
    var mount=ensureMount();
    if(!mount) return;
    try{
      if(!mount.querySelector('[data-lr69a-status]')){
        var strip=document.createElement('div'); strip.className='lr69aStatusStrip'; strip.setAttribute('data-lr69a-status','1');
        strip.innerHTML='<b>Merchant Square route is hardened.</b><span>Shops, exchanges, starter pouch, and old shop buttons are being kept inside the dynamic main screen.</span>';
        var hero=mount.querySelector('.lr69Hero');
        if(hero && hero.nextSibling) hero.parentNode.insertBefore(strip, hero.nextSibling); else mount.insertBefore(strip, mount.firstChild);
      }
      var util=mount.querySelector('.lr69UtilityRow');
      if(util && !util.querySelector('[data-lr69a-route-check]')){
        var qa=document.createElement('button'); qa.type='button'; qa.setAttribute('data-lr69a-route-check','1'); qa.className='lr69aRouteCheckBtn';
        qa.innerHTML='Run Merchant Square route check<small>Checks shopkeeper buttons, old shop redirects, currencies, and dynamic screen mount.</small>';
        qa.onclick=function(){ return openRouteCheck(); };
        util.appendChild(qa);
      }
      var bottom=mount.querySelector('.lr69Bottom');
      if(bottom && !bottom.querySelector('[data-lr69a-square-shortcut]')){
        var sq=document.createElement('button'); sq.type='button'; sq.setAttribute('data-lr69a-square-shortcut','1'); sq.textContent='🏪 Merchant Square'; sq.onclick=function(){ return call('lr69OpenMerchantSquare'); };
        bottom.insertBefore(sq, bottom.firstChild);
      }
    }catch(e){}
    redirectLegacyShopButtons();
    stats();
  }

  function routeCheckHtml(){
    var s=getState() || {};
    var curr=s.lr69Currencies || {};
    var checks=[
      ['Dynamic main screen visible', !!byId('lrDynamicAdventureScreen')],
      ['Merchant Square opener loaded', typeof window.lr69OpenMerchantSquare === 'function'],
      ['Shopkeeper opener loaded', typeof window.lr69OpenShopkeeper === 'function'],
      ['Buy handler loaded', typeof window.lr69Buy === 'function'],
      ['Exchange booth loaded', typeof window.lr69Exchange === 'function'],
      ['Starter pouch handler loaded', typeof window.lr69ClaimStarterPouch === 'function'],
      ['Currency save bucket exists', !!s.lr69Currencies],
      ['Purchase record bucket exists', !!s.lr69Purchases],
      ['Daily claim bucket exists', !!s.lr69DailyClaims],
      ['Old shop renderer redirects safely', typeof window.openShopRenderer === 'function'],
      ['Old shop popup bug neutralized', typeof window.lrSafeBrowseShopPopup === 'function'],
      ['Learning Trails bridge available', typeof window.lr68bOpenLearningTrails === 'function' || typeof window.lr68OpenLearn === 'function']
    ];
    var wallet='<div class="lr69aWalletMini"><b>Current special currencies:</b> Merchant Tickets '+esc(curr.merchantTickets||0)+' · Sea Glass '+esc(curr.seaGlass||0)+' · Gear Tokens '+esc(curr.gearTokens||0)+' · Studio Tickets '+esc(curr.studioTickets||0)+' · History Seals '+esc(curr.historySeals||0)+' · Merit Stars '+esc(curr.meritStars||0)+'</div>';
    return '<section class="lr69Hero"><div class="lr69HeroTop"><span>Merchant Square 6.9A</span><span>Stability check</span></div><h1>Merchant Square route check</h1><p>This safe check does not spend currency, buy items, or change progress. It only confirms that the shopkeeper route is wired into the dynamic main screen.</p></section>'+
      '<section class="lr69aCheckGrid">'+checks.map(function(c){ return '<div class="lr69aCheck '+(c[1]?'ok':'warn')+'"><b>'+(c[1]?'✓ ':'! ')+esc(c[0])+'</b><small>'+(c[1]?'Ready':'Needs attention')+'</small></div>'; }).join('')+'</section>'+wallet+
      '<div class="lr69Bottom"><button type="button" onclick="lr69OpenMerchantSquare()">↩ Back to Merchant Square</button><button type="button" onclick="lr69OpenShopkeeper && lr69OpenShopkeeper(\'penny\')">🪙 Test-open Penny Pouch</button><button type="button" onclick="lr69OpenShopkeeper && lr69OpenShopkeeper(\'exchange\')">🔁 Test-open Exchange Booth</button><button type="button" onclick="lr69GoHome && lr69GoHome()">🏡 Home</button></div>';
  }

  function openRouteCheck(){
    markActive('routeCheck',[]);
    var mount=ensureMount();
    mount.innerHTML=routeCheckHtml();
    return false;
  }

  function redirectLegacyShopButtons(){
    try{
      document.querySelectorAll('button').forEach(function(btn){
        if(btn.closest && (btn.closest('#lrDynamicAdventureScreen') || btn.closest('#lrPopupRoot'))) return;
        var t=text(btn).toLowerCase(); var attr=(btn.getAttribute('onclick') || '').toLowerCase();
        var legacy = t.indexOf('browse shop')>=0 || t.indexOf('browse seasonal')>=0 || t.indexOf('browse picture')>=0 || t.indexOf('lucky kettle')>=0 || t.indexOf('open shop')>=0 || attr.indexOf('openshop')>=0 || attr.indexOf('lr safebrowseshoppopup'.replace(/ /g,''))>=0;
        if(!legacy || btn.dataset.lr69aRedirected) return;
        btn.dataset.lr69aRedirected='1';
        btn.onclick=function(ev){ try{ if(ev) ev.preventDefault(); }catch(e){} return call('lr69OpenMerchantSquare'); };
      });
    }catch(e){}
  }

  function wrapRenderers(){
    try{
      if(typeof window.lr69OpenMerchantSquare === 'function' && !window.lr69OpenMerchantSquare.__lr69aWrapped){
        var oldSquare=window.lr69OpenMerchantSquare;
        var newSquare=function(){ markActive('square', [].slice.call(arguments)); var out=oldSquare.apply(this, arguments); setTimeout(enhance,20); setTimeout(enhance,180); return out; };
        newSquare.__lr69aWrapped=true; newSquare.__lr69aOld=oldSquare; window.lr69OpenMerchantSquare=newSquare; try{ lr69OpenMerchantSquare=newSquare; }catch(e){}
      }
      if(typeof window.lr69OpenShopkeeper === 'function' && !window.lr69OpenShopkeeper.__lr69aWrapped){
        var oldShop=window.lr69OpenShopkeeper;
        var newShop=function(){ markActive('shop', [].slice.call(arguments)); var out=oldShop.apply(this, arguments); setTimeout(enhance,20); setTimeout(enhance,180); return out; };
        newShop.__lr69aWrapped=true; newShop.__lr69aOld=oldShop; window.lr69OpenShopkeeper=newShop; try{ lr69OpenShopkeeper=newShop; }catch(e){}
      }
      if(typeof window.lr69OpenMerchantGoals === 'function' && !window.lr69OpenMerchantGoals.__lr69aWrapped){
        var oldGoals=window.lr69OpenMerchantGoals;
        var newGoals=function(){ markActive('goals', [].slice.call(arguments)); var out=oldGoals.apply(this, arguments); setTimeout(enhance,20); setTimeout(enhance,180); return out; };
        newGoals.__lr69aWrapped=true; newGoals.__lr69aOld=oldGoals; window.lr69OpenMerchantGoals=newGoals; try{ lr69OpenMerchantGoals=newGoals; }catch(e){}
      }
      if(typeof window.lr69Buy === 'function' && !window.lr69Buy.__lr69aWrapped){
        var oldBuy=window.lr69Buy;
        var newBuy=function(shopId,index){ return withLock('buy:'+shopId+':'+index, function(){ markActive('shop',[shopId]); var out=oldBuy.apply(window, arguments); setTimeout(enhance,35); return out; }); };
        newBuy.__lr69aWrapped=true; newBuy.__lr69aOld=oldBuy; window.lr69Buy=newBuy; try{ lr69Buy=newBuy; }catch(e){}
      }
      if(typeof window.lr69Exchange === 'function' && !window.lr69Exchange.__lr69aWrapped){
        var oldExchange=window.lr69Exchange;
        var newExchange=function(id){ return withLock('exchange:'+id, function(){ markActive('exchange',[id]); var out=oldExchange.apply(window, arguments); setTimeout(enhance,35); return out; }); };
        newExchange.__lr69aWrapped=true; newExchange.__lr69aOld=oldExchange; window.lr69Exchange=newExchange; try{ lr69Exchange=newExchange; }catch(e){}
      }
      if(typeof window.lr69ClaimStarterPouch === 'function' && !window.lr69ClaimStarterPouch.__lr69aWrapped){
        var oldClaim=window.lr69ClaimStarterPouch;
        var newClaim=function(){ return withLock('starterPouch', function(){ markActive('square',[]); var out=oldClaim.apply(window, arguments); setTimeout(enhance,35); return out; }); };
        newClaim.__lr69aWrapped=true; newClaim.__lr69aOld=oldClaim; window.lr69ClaimStarterPouch=newClaim; try{ lr69ClaimStarterPouch=newClaim; }catch(e){}
      }
      if(typeof window.lr69BackToScene === 'function' && !window.lr69BackToScene.__lr69aWrapped){
        var oldBack=window.lr69BackToScene;
        var newBack=function(){ markInactive(); var out=oldBack.apply(window, arguments); setTimeout(function(){ suppressLegacy(); },60); return out; };
        newBack.__lr69aWrapped=true; newBack.__lr69aOld=oldBack; window.lr69BackToScene=newBack; try{ lr69BackToScene=newBack; }catch(e){}
      }
      if(typeof window.lr69GoHome === 'function' && !window.lr69GoHome.__lr69aWrapped){
        var oldHome=window.lr69GoHome;
        var newHome=function(){ markInactive(); var out=oldHome.apply(window, arguments); setTimeout(function(){ suppressLegacy(); },80); return out; };
        newHome.__lr69aWrapped=true; newHome.__lr69aOld=oldHome; window.lr69GoHome=newHome; try{ lr69GoHome=newHome; }catch(e){}
      }
      if(typeof window.lr69GoLearn === 'function' && !window.lr69GoLearn.__lr69aWrapped){
        var oldLearn=window.lr69GoLearn;
        var newLearn=function(){ markInactive(); var out=oldLearn.apply(window, arguments); setTimeout(function(){ suppressLegacy(); },80); return out; };
        newLearn.__lr69aWrapped=true; newLearn.__lr69aOld=oldLearn; window.lr69GoLearn=newLearn; try{ lr69GoLearn=newLearn; }catch(e){}
      }
    }catch(e){ console.warn('LR69A renderer wrap failed', e); }
  }

  function neutralizeOldShopPopups(){
    try{
      window.lrSafeBrowseShopPopup=function(){ return call('lr69OpenMerchantSquare'); };
      try{ lrSafeBrowseShopPopup=window.lrSafeBrowseShopPopup; }catch(e){}
      if(typeof window.openShopPopup === 'function' && !window.openShopPopup.__lr69aWrapped){ var oldPopup=window.openShopPopup; var repl=function(){ return call('lr69OpenMerchantSquare'); }; repl.__lr69aWrapped=true; repl.__lr69aOld=oldPopup; window.openShopPopup=repl; try{ openShopPopup=repl; }catch(e){} }
      if(typeof window.openShop === 'function' && !window.openShop.__lr69aWrapped){ var oldOpen=window.openShop; var repl2=function(){ return call('lr69OpenMerchantSquare'); }; repl2.__lr69aWrapped=true; repl2.__lr69aOld=oldOpen; window.openShop=repl2; try{ openShop=repl2; }catch(e){} }
      if(typeof window.openShopHub === 'function' && !window.openShopHub.__lr69aWrapped){ var oldHub=window.openShopHub; var repl3=function(){ return call('lr69OpenMerchantSquare'); }; repl3.__lr69aWrapped=true; repl3.__lr69aOld=oldHub; window.openShopHub=repl3; try{ openShopHub=repl3; }catch(e){} }
    }catch(e){}
  }

  function installObserver(){
    if(window.__LR69A_OBSERVER__) return; window.__LR69A_OBSERVER__=true;
    try{
      var obs=new MutationObserver(function(){ redirectLegacyShopButtons(); if(ACTIVE) setTimeout(enhance,30); });
      obs.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
    }catch(e){}
  }

  function restoreLast(){
    if(!ACTIVE || popupOpen()) return;
    var mount=byId('lrDynamicAdventureScreen');
    var hidden=false;
    if(!mount) hidden=true;
    else{
      try{ var cs=getComputedStyle(mount); hidden = cs.display==='none' || cs.visibility==='hidden' || cs.opacity==='0' || mount.offsetHeight < 30; }catch(e){ hidden=false; }
      if(!String(mount.innerHTML||'').trim()) hidden=true;
    }
    if(!hidden) return;
    if(LOCKS.restore) return;
    LOCKS.restore=true;
    try{
      if(LAST.type==='shop' && typeof window.lr69OpenShopkeeper === 'function') window.lr69OpenShopkeeper.apply(window,LAST.args||[]);
      else if(LAST.type==='goals' && typeof window.lr69OpenMerchantGoals === 'function') window.lr69OpenMerchantGoals.apply(window,LAST.args||[]);
      else if(LAST.type==='routeCheck') openRouteCheck();
      else if(typeof window.lr69OpenMerchantSquare === 'function') window.lr69OpenMerchantSquare.apply(window,LAST.args||[]);
    }catch(e){ console.warn('LR69A restore failed', e); }
    setTimeout(function(){ LOCKS.restore=false; },1000);
  }

  function injectStyles(){
    if(byId('lr69aHardeningStyle')) return;
    var st=document.createElement('style'); st.id='lr69aHardeningStyle';
    st.textContent = `
      body.lr69aMerchantHardening #lrDynamicAdventureScreen{display:block!important;visibility:visible!important;opacity:1!important;width:100%!important;max-width:none!important;min-height:680px!important;}
      .lr69aStatusStrip{display:flex;flex-wrap:wrap;justify-content:space-between;gap:10px;align-items:center;padding:11px 18px;background:#0d2c31;color:#fff3c6;border-top:1px solid rgba(255,230,160,.25);border-bottom:1px solid rgba(255,230,160,.25);font-weight:850}
      .lr69aStatusStrip span{color:#e9f4df;font-weight:760}.lr69aRouteCheckBtn{border-color:#d1a94c!important;background:#fff8d8!important;color:#153830!important}.lr69aRouteCheckBtn small{display:block;margin-top:5px;color:#52675e;font-weight:760}
      .lr69aCheckGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;padding:20px;background:linear-gradient(180deg,#f7fff1,#e7f1ea)}
      .lr69aCheck{border-radius:16px;padding:13px 14px;background:#fffdf4;border:1px solid rgba(30,78,60,.16);box-shadow:0 8px 16px rgba(0,0,0,.08);color:#163930}.lr69aCheck.ok{border-color:#68ad72}.lr69aCheck.warn{border-color:#d5a949;background:#fff7d8}.lr69aCheck b{display:block}.lr69aCheck small{display:block;margin-top:5px;color:#52675e;font-weight:760}
      .lr69aWalletMini{margin:0;padding:15px 20px;background:#fff7dd;color:#153830;border-top:1px solid rgba(40,80,60,.18);border-bottom:1px solid rgba(40,80,60,.18);font-weight:850;line-height:1.5}
      #lrDynamicAdventureScreen .lr69Bottom button[data-lr69a-square-shortcut]{background:#244b40;color:#fff4d2;border-color:rgba(255,230,160,.35)}
    `;
    document.head.appendChild(st);
  }

  function boot(){
    injectStyles(); neutralizeOldShopPopups(); wrapRenderers(); installObserver(); redirectLegacyShopButtons(); suppressLegacy();
    if(!window.__LR69A_WATCHDOG__){ window.__LR69A_WATCHDOG__=setInterval(function(){ try{ restoreLast(); suppressLegacy(); redirectLegacyShopButtons(); }catch(e){} }, 900); }
  }

  window.lr69aOpenMerchantRouteCheck = openRouteCheck;
  window.lr69aEnhanceMerchantSquare = enhance;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ boot(); [100,350,900,1800,3200].forEach(function(ms){ setTimeout(boot,ms); }); });
  else { boot(); [100,350,900,1800,3200].forEach(function(ms){ setTimeout(boot,ms); }); }
  window.addEventListener('load', function(){ boot(); setTimeout(boot,700); setTimeout(boot,1800); });
})();
