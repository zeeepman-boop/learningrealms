/* LearningRealms Dynamic Adventure Screen 6.7
   Main-window refactor: travel, looking, and guide interaction update the main screen instantly.
   Popups are reserved for lessons / learning windows. Existing rooms, lessons, rewards, and saves stay intact.
*/
(function(){
  'use strict';
  if(window.__LR67_DYNAMIC_ADVENTURE_SCREEN__) return;
  window.__LR67_DYNAMIC_ADVENTURE_SCREEN__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }
  function stripEmoji(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function cap(s){ s = String(s || ''); return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  function safe(fn){ try{ return fn(); }catch(e){ return null; } }

  function getState(){
    try{ if(typeof state !== 'undefined' && state) return state; }catch(e){}
    try{ if(window.state) return window.state; }catch(e){}
    return null;
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined' && ROOMS) return ROOMS; }catch(e){}
    return {};
  }
  function currentLoc(){
    var s = getState();
    return (s && s.loc) ? s.loc : 'crossroads';
  }
  function getRoom(){
    try{ if(typeof window.room === 'function') return window.room() || {}; }catch(e){}
    try{ if(typeof room === 'function') return room() || {}; }catch(e){}
    var rooms = getRooms();
    return rooms[currentLoc()] || rooms.crossroads || {};
  }
  function getNpc(){
    try{ if(typeof window.roomHasNpc === 'function' && window.roomHasNpc() && typeof window.npc === 'function') return window.npc(); }catch(e){}
    try{ if(typeof roomHasNpc === 'function' && roomHasNpc() && typeof npc === 'function') return npc(); }catch(e){}
    return null;
  }
  function hasFunction(name){ return typeof window[name] === 'function' || safe(function(){ return typeof eval(name) === 'function'; }); }
  function callFunction(name){
    try{ if(typeof window[name] === 'function') return window[name](); }catch(e){ console.warn(name, e); }
    try{ if(typeof eval(name) === 'function') return eval(name)(); }catch(e){ console.warn(name, e); }
  }

  function directionPhrase(dir, destTitle, zone, subject){
    var d = String(dir || '').toLowerCase();
    var t = String(destTitle || '').toLowerCase();
    var z = String(zone || '').toLowerCase();
    var s = String(subject || '').toLowerCase();
    if(d === 'home') return 'Return to';
    if(d === 'out') return 'Step back toward';
    if(d === 'up') return 'Climb up toward';
    if(d === 'down') return 'Climb down toward';
    if(t.indexOf('gate') >= 0) return 'Approach';
    if(t.indexOf('hall') >= 0 || t.indexOf('vault') >= 0 || t.indexOf('room') >= 0 || t.indexOf('archive') >= 0) return 'Step inside';
    if(t.indexOf('bridge') >= 0) return 'Cross toward';
    if(t.indexOf('shop') >= 0 || z.indexOf('shop') >= 0 || z.indexOf('market') >= 0) return 'Wander into';
    if(t.indexOf('road') >= 0 || t.indexOf('trail') >= 0 || t.indexOf('path') >= 0 || t.indexOf('lane') >= 0) return 'Follow the path to';
    if(s.indexOf('math') >= 0) return 'Head toward the problem-solving path at';
    if(s.indexOf('reading') >= 0) return 'Follow the story clues toward';
    if(s.indexOf('science') >= 0) return 'Follow the evidence trail toward';
    if(s.indexOf('history') >= 0) return 'Walk toward the old records at';
    return 'Travel to';
  }
  function subjectLine(subject){
    if(!subject) return '';
    var s = String(subject).toLowerCase();
    if(s.indexOf('reading') >= 0) return 'Story clues, careful reading, and proof from the text live here.';
    if(s.indexOf('math') >= 0) return 'Numbers, patterns, and problem solving are part of this place.';
    if(s.indexOf('science') >= 0) return 'Observation, evidence, and careful testing guide this room.';
    if(s.indexOf('writing') >= 0) return 'Words, sentences, records, and clear explanations matter here.';
    if(s.indexOf('history') >= 0) return 'Old evidence, dates, people, and cause-and-effect clues wait here.';
    if(s.indexOf('english') >= 0) return 'Language, grammar, spelling, and meaning shape this path.';
    if(s.indexOf('civics') >= 0) return 'Rules, responsibility, service, and community choices are studied here.';
    if(s.indexOf('geography') >= 0) return 'Maps, places, landforms, and location clues guide the next step.';
    if(s.indexOf('economics') >= 0) return 'Choices, trade, saving, needs, wants, and value are explored here.';
    if(s.indexOf('logic') >= 0) return 'Careful thinking, evidence, and avoiding bad reasoning unlock this area.';
    if(s.indexOf('nature') >= 0) return 'Outdoor clues, habitats, living things, and safe observation matter here.';
    if(s.indexOf('health') >= 0) return 'Safe habits, rest, food, movement, and body basics are practiced here.';
    if(s.indexOf('music') >= 0) return 'Rhythm, sound, listening, and patterns are part of the journey.';
    if(s.indexOf('copywork') >= 0) return 'Careful copying, neat language, and noticing sentence style happen here.';
    if(s.indexOf('life') >= 0) return 'Practical skills become small quests and useful habits here.';
    return 'This learning path is ready.';
  }
  function choiceText(dir, targetId){
    var rooms = getRooms();
    var t = rooms[targetId] || {};
    var dest = stripEmoji(t.title || targetId || 'the next place');
    var phrase = directionPhrase(dir, dest, t.zone, t.subject);
    var sub = subjectLine(t.subject);
    if(targetId === 'home' || dir === 'home') return 'Return to Home Hearth and check the family rooms, rewards, pets, and keepsakes.';
    if(sub) return phrase + ' ' + dest + '. ' + sub;
    if(t.zone) return phrase + ' ' + dest + ' and see what changes in ' + stripEmoji(t.zone) + '.';
    return phrase + ' ' + dest + ' and continue the adventure.';
  }
  function splitText(text){
    return String(text || '').split(/\n{2,}/).map(function(x){ return x.trim(); }).filter(Boolean);
  }
  function buildSceneText(roomObj, mode){
    var bits = [];
    if(roomObj.text) bits.push(roomObj.text);
    if(roomObj.subject) bits.push(subjectLine(roomObj.subject));
    var n = getNpc();
    if(n && (mode !== 'talk')) bits.push((n.desc || ('A guide named ' + (n.name || 'Realm Guide') + ' is nearby.')));
    if(mode === 'look'){
      bits.push('You slow down and study the room like a real explorer. The useful clues are not just in the path names. They are in the objects, sounds, maps, tools, doors, shelves, and little details that show what kind of learning belongs here.');
    }
    if(mode === 'talk'){
      if(n){
        bits.push((n.name || 'The guide') + ' says: "' + (n.text || n.desc || 'Take the next clear path and keep learning one step at a time.') + '"');
      }else{
        bits.push('There is no guide standing here right now, so you listen to the room itself: look at the clues, pick a path, or open a lesson when this place is ready.');
      }
    }
    if(!bits.length) bits.push('The room waits quietly for the next choice.');
    return bits;
  }
  function destinationMeta(id){
    var r = getRooms()[id] || {};
    var pieces = [];
    if(r.zone) pieces.push(stripEmoji(r.zone));
    if(r.subject) pieces.push(stripEmoji(r.subject));
    return pieces.join(' · ');
  }
  function exitButtons(r){
    var exits = (r && r.exits) || {};
    var keys = Object.keys(exits);
    if(!keys.length){
      return '<div class="lr67QuietBox">No travel path is marked from this room yet. Use Home, Go Learn, or look around while this area is expanded later.</div>';
    }
    return keys.map(function(k, i){
      var target = exits[k];
      var t = getRooms()[target] || {};
      return '<button type="button" class="lr67Choice" onclick="lr67ChoosePath(\'' + esc(k) + '\')">' +
        '<span class="lr67ChoiceNum">' + (i + 1) + '</span>' +
        '<span class="lr67ChoiceWords"><b>' + esc(choiceText(k, target)) + '</b>' +
        '<small>' + esc(t.title || target) + (destinationMeta(target) ? ' · ' + esc(destinationMeta(target)) : '') + '</small></span>' +
      '</button>';
    }).join('');
  }
  function roomActionButtons(r){
    var html = '';
    if(r && r.subject){
      html += '<button type="button" class="lr67SoftAction primary" onclick="lr67StartRoomLesson()">📘 Open a ' + esc(r.subject) + ' lesson</button>';
      html += '<button type="button" class="lr67SoftAction" onclick="lr67Call(\'showMasteryStatus\')">🏆 Check mastery</button>';
    }
    var loc = currentLoc();
    if(['seasonalShop','pictureShop','luckyKettle','shiftyTent'].indexOf(loc) >= 0){
      html += '<button type="button" class="lr67SoftAction" onclick="lr67ShowActionInScene(\'openShop\', \'Shop shelves\')">🏪 Browse this place</button>';
    }
    if(loc === 'questBoardPlaza') html += '<button type="button" class="lr67SoftAction" onclick="lr67ShowActionInScene(\'openQuestBoard\', \'Quest board\')">📜 Read the quest board</button>';
    if(loc === 'historicalSociety') html += '<button type="button" class="lr67SoftAction" onclick="lr67ShowActionInScene(\'openInvestigationBoard\', \'Investigation board\')">🗺 Check the investigation board</button>';
    try{ if(typeof moonClues !== 'undefined' && moonClues[loc]) html += '<button type="button" class="lr67SoftAction" onclick="lr67ShowActionInScene(\'recordMoonClue\', \'Moon Stair clue\')">🌙 Record Moon Stair clue</button>'; }catch(e){}
    return html ? '<div class="lr67RoomActions"><div class="lr67MiniTitle">Useful here</div>' + html + '</div>' : '';
  }
  function getLevelLine(){
    var s = getState();
    var parts = [];
    try{ if(typeof activeChild !== 'undefined') parts.push(activeChild); }catch(e){}
    try{ if(s && typeof s.room !== 'undefined') parts.push('Room ' + s.room); }catch(e){}
    try{ if(s && typeof s.sparks !== 'undefined') parts.push(s.sparks + ' Sparks'); }catch(e){}
    try{ if(s && typeof s.streak !== 'undefined') parts.push('Streak ' + s.streak); }catch(e){}
    return parts.join(' · ');
  }

  window.lr67RenderDynamicScreen = function(mode, note){
    try{
      ensureMount();
      var r = getRoom();
      var mount = byId('lrDynamicAdventureScreen');
      if(!mount) return;
      var scene = buildSceneText(r, mode || 'room');
      var loc = currentLoc();
      var n = getNpc();
      var npcLine = n ? '<span>Guide nearby: <b>' + esc(n.name || 'Realm Guide') + '</b></span>' : '<span>No guide standing here.</span>';
      var textHtml = scene.slice(0,4).map(function(p){ return '<p>' + esc(p) + '</p>'; }).join('');
      if(note) textHtml = '<p class="lr67TravelNote">' + esc(note) + '</p>' + textHtml;
      mount.innerHTML =
        '<div class="lr67Hero">' +
          '<div class="lr67HeroTop"><span class="lr67Kicker">Dynamic adventure screen</span><span class="lr67Status">' + esc(getLevelLine()) + '</span></div>' +
          '<h1>' + esc(r.title || 'LearningRealms') + '</h1>' +
          '<div class="lr67Meta"><span>' + esc(r.zone || 'Realm') + '</span>' + (r.subject ? '<span>' + esc(r.subject) + '</span>' : '') + npcLine + '</div>' +
          '<div class="lr67SceneText">' + textHtml + '</div>' +
        '</div>' +
        roomActionButtons(r) +
        '<div class="lr67ChoicePanel"><div class="lr67PanelTitle"><span>What do you do?</span><small>Choices update this main window. Lessons open big.</small></div>' + exitButtons(r) + '</div>' +
        '<div class="lr67BottomBar">' +
          '<button type="button" onclick="lr67RenderDynamicScreen(\'look\')">🔎 Look around</button>' +
          '<button type="button" onclick="lr67RenderDynamicScreen(\'talk\')">💬 Talk / listen</button>' +
          '<button type="button" onclick="lr67OpenLearn()">📘 Go Learn</button>' +
          '<button type="button" onclick="lr67GoHome()">🏡 Home</button>' +
        '</div>';
    }catch(e){
      console.error('6.7 dynamic render failed', e);
      var fb = byId('feedback'); if(fb) fb.textContent = 'Dynamic screen error: ' + (e.message || e);
    }
  };

  window.lr67ChoosePath = function(dir){
    try{
      var r = getRoom();
      var target = r.exits && r.exits[dir];
      var note = target ? choiceText(dir, target) : 'No path opens that way.';
      if(!target){ window.lr67RenderDynamicScreen('room', note); return; }
      if(typeof window.go === 'function') window.go(dir);
      else if(typeof go === 'function') go(dir);
      else {
        var s = getState();
        if(s){ s.loc = target; s.room = (s.room || 0) + 1; }
        if(typeof window.renderRoom === 'function') window.renderRoom();
      }
      setTimeout(function(){ window.lr67RenderDynamicScreen('room', note); }, 1);
      setTimeout(function(){ window.lr67RenderDynamicScreen('room'); }, 80);
    }catch(e){
      console.error(e);
      window.lr67RenderDynamicScreen('room', 'Something blocked that travel choice: ' + (e.message || e));
    }
  };
  window.lrAdventureChoiceGo = window.lr67ChoosePath;
  window.lrNavRestoreGo = window.lr67ChoosePath;

  window.lr67StartRoomLesson = function(){
    try{
      if(typeof window.startLesson === 'function') return window.startLesson();
      if(typeof startLesson === 'function') return startLesson();
      window.lr67OpenLearn();
    }catch(e){ console.error(e); }
  };
  window.lr67OpenLearn = function(){
    var names = ['lr62eOpenLearn','lr19OpenLearningChooser','openRealCurriculumPicker','openLessonLauncher','openSubjectAtlasUI'];
    for(var i=0;i<names.length;i++){
      try{ if(typeof window[names[i]] === 'function'){ window[names[i]](); enlargePopupSoon(); return; } }catch(e){}
      try{ if(typeof eval(names[i]) === 'function'){ eval(names[i])(); enlargePopupSoon(); return; } }catch(e){}
    }
    window.lr67RenderDynamicScreen('room', 'The learning menu is still loading.');
  };
  window.lr67GoHome = function(){
    try{
      if(typeof window.travelHome === 'function'){ window.travelHome(); setTimeout(window.lr67RenderDynamicScreen, 40); return; }
      if(typeof travelHome === 'function'){ travelHome(); setTimeout(window.lr67RenderDynamicScreen, 40); return; }
    }catch(e){}
    var s = getState();
    if(s) s.loc = 'home';
    try{ if(typeof window.renderRoom === 'function') window.renderRoom(); else if(typeof renderRoom === 'function') renderRoom(); }catch(e){}
    setTimeout(window.lr67RenderDynamicScreen, 30);
  };
  window.lr67Call = function(name){
    callFunction(name);
    setTimeout(function(){ window.lr67RenderDynamicScreen('room'); }, 80);
  };
  window.lr67ShowActionInScene = function(fnName, title){
    try{ callFunction(fnName); }catch(e){}
    setTimeout(function(){
      var action = byId('actionText');
      var body = action ? action.innerHTML : '';
      var mount = byId('lrDynamicAdventureScreen');
      if(mount && body){
        var r = getRoom();
        mount.innerHTML = '<div class="lr67Hero"><div class="lr67HeroTop"><span class="lr67Kicker">Room action</span><span class="lr67Status">' + esc(getLevelLine()) + '</span></div><h1>' + esc(title || r.title || 'Room action') + '</h1><div class="lr67SceneText actionEmbedded">' + body + '</div></div><div class="lr67BottomBar"><button type="button" onclick="lr67RenderDynamicScreen()">↩ Return to the room</button><button type="button" onclick="lr67OpenLearn()">📘 Go Learn</button><button type="button" onclick="lr67GoHome()">🏡 Home</button></div>';
      }else{
        window.lr67RenderDynamicScreen('room');
      }
    }, 80);
  };

  function ensureMount(){
    document.body.classList.add('lrDynamicAdventureMode');
    var firstCard = document.querySelector('.main > .card');
    if(!firstCard) return;
    if(!byId('lrDynamicAdventureScreen')){
      var mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen';
      firstCard.insertBefore(mount, firstCard.firstChild);
    }
  }

  function enlargePopupSoon(){
    setTimeout(function(){ document.body.classList.add('lrBigLessonPopup'); }, 20);
  }

  function patchLessonPopups(){
    try{
      if(typeof window.lrOpenPopup === 'function' && !window.lrOpenPopup.__lr67Big){
        var old = window.lrOpenPopup;
        var repl = function(title, html){
          var out = old.apply(this, arguments);
          document.body.classList.add('lrBigLessonPopup');
          return out;
        };
        repl.__lr67Big = true;
        window.lrOpenPopup = repl;
        try{ lrOpenPopup = repl; }catch(e){}
      }
    }catch(e){}
    try{
      if(typeof window.startLesson === 'function' && !window.startLesson.__lr67Wrapped){
        var oldStart = window.startLesson;
        var wrappedStart = function(){
          var out = oldStart.apply(this, arguments);
          enlargePopupSoon();
          return out;
        };
        wrappedStart.__lr67Wrapped = true;
        window.startLesson = wrappedStart;
        try{ startLesson = wrappedStart; }catch(e){}
      }
    }catch(e){}
  }

  function injectStyles(){
    if(byId('lrDynamicAdventureScreen67Style')) return;
    var css = `
      body.lrDynamicAdventureMode main{
        grid-template-columns:minmax(650px,1fr) 330px 245px !important;
        align-items:start !important;
      }
      body.lrDynamicAdventureMode .actionSidebar{display:none !important;}
      body.lrDynamicAdventureMode .main > .card:first-child{padding:0 !important;overflow:hidden;border-color:rgba(255,227,160,.34) !important;}
      body.lrDynamicAdventureMode .main > .card:nth-child(2){display:none !important;}
      body.lrDynamicAdventureMode #roomTitle,
      body.lrDynamicAdventureMode #roomText,
      body.lrDynamicAdventureMode #mainCompassNav,
      body.lrDynamicAdventureMode #mainGameplayActions,
      body.lrDynamicAdventureMode .lrAdventurePanel,
      body.lrDynamicAdventureMode .lrExplorePanel,
      body.lrDynamicAdventureMode .compassBox,
      body.lrDynamicAdventureMode .compassGrid{display:none !important;}
      .lrDynamicAdventureScreen{min-height:560px;color:#fff3cc;background:
        radial-gradient(circle at 18% 0%, rgba(255,211,112,.22), transparent 34%),
        radial-gradient(circle at 100% 8%, rgba(122,190,154,.14), transparent 36%),
        linear-gradient(180deg, rgba(12,28,24,.97), rgba(6,14,12,.98));}
      .lr67Hero{padding:22px 24px 18px;border-bottom:1px solid rgba(255,227,160,.2);}
      .lr67HeroTop{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:7px;}
      .lr67Kicker{font-weight:900;text-transform:uppercase;letter-spacing:.08em;color:#ffdf87;font-size:.76rem;}
      .lr67Status{font-size:.8rem;color:#d9e5c9;font-weight:700;text-align:right;}
      .lr67Hero h1{margin:.05rem 0 .45rem;color:#ffe9a8;text-shadow:0 3px 0 rgba(51,29,13,.7);font-size:clamp(2rem,4vw,3.45rem);line-height:1.05;}
      .lr67Meta{display:flex;flex-wrap:wrap;gap:7px;margin:8px 0 14px;}
      .lr67Meta span{border:1px solid rgba(255,227,160,.25);background:rgba(255,255,255,.07);border-radius:999px;padding:5px 9px;color:#fff0bd;font-size:.85rem;}
      .lr67SceneText{font-size:1.14rem;line-height:1.62;max-width:980px;}
      .lr67SceneText p{margin:.72rem 0;white-space:normal;}
      .lr67TravelNote{background:rgba(255,227,160,.13);border:1px solid rgba(255,227,160,.28);border-radius:14px;padding:10px 12px;color:#ffedba;font-weight:800;}
      .lr67RoomActions{padding:14px 24px;border-bottom:1px solid rgba(255,227,160,.14);background:rgba(255,255,255,.035);display:flex;flex-wrap:wrap;gap:8px;align-items:center;}
      .lr67MiniTitle{font-weight:900;color:#ffdf87;margin-right:4px;}
      .lr67SoftAction{border-radius:999px !important;padding:8px 12px !important;background:rgba(70,49,28,.95) !important;color:#fff0bd !important;border:1px solid rgba(255,220,142,.45) !important;}
      .lr67SoftAction.primary{background:linear-gradient(135deg,#7b5424,#3d704e) !important;}
      .lr67ChoicePanel{padding:18px 24px 20px;}
      .lr67PanelTitle{display:flex;justify-content:space-between;gap:12px;align-items:flex-end;margin-bottom:11px;color:#ffe8aa;font-weight:900;}
      .lr67PanelTitle span{font-size:1.15rem;}
      .lr67PanelTitle small{font-size:.78rem;color:#d9e5c9;text-align:right;}
      .lr67Choice{width:100% !important;min-height:74px !important;margin:0 0 10px !important;padding:12px 14px !important;border-radius:18px !important;border:1px solid rgba(255,232,171,.46) !important;background:linear-gradient(135deg, rgba(255,249,225,.98), rgba(230,240,221,.96)) !important;color:#17352d !important;display:flex !important;gap:12px !important;align-items:flex-start !important;text-align:left !important;box-shadow:0 8px 16px rgba(0,0,0,.22) !important;transition:transform .08s ease, filter .08s ease;}
      .lr67Choice:hover{transform:translateY(-1px);filter:brightness(1.035);}
      .lr67Choice:active{transform:translateY(1px) scale(.997);}
      .lr67ChoiceNum{flex:0 0 34px;height:34px;border-radius:999px;background:#25483d;color:#fff6d8;display:inline-flex;align-items:center;justify-content:center;font-weight:900;box-shadow:inset 0 0 0 1px rgba(255,255,255,.16);}
      .lr67ChoiceWords{display:flex;flex-direction:column;gap:5px;min-width:0;}
      .lr67ChoiceWords b{font-size:1rem;color:#18382f;line-height:1.28;}
      .lr67ChoiceWords small{color:#51675f;font-weight:800;font-size:.78rem;}
      .lr67QuietBox{border:1px solid rgba(255,227,160,.23);background:rgba(255,255,255,.08);padding:14px;border-radius:16px;color:#fff0bd;}
      .lr67BottomBar{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:9px;padding:16px 24px 24px;border-top:1px solid rgba(255,227,160,.14);background:rgba(0,0,0,.18);}
      .lr67BottomBar button{min-height:45px !important;border-radius:14px !important;font-weight:900 !important;background:rgba(47,72,55,.96) !important;border:1px solid rgba(255,227,160,.35) !important;color:#fff0bd !important;}
      .actionEmbedded{background:rgba(0,0,0,.18);border:1px solid rgba(255,227,160,.22);border-radius:16px;padding:14px;}
      body.lrBigLessonPopup .lrPopupRoot{z-index:9999 !important;}
      body.lrBigLessonPopup .lrPopupWindow{width:min(1120px,96vw) !important;max-width:1120px !important;min-height:min(650px,88vh) !important;max-height:92vh !important;border-radius:22px !important;}
      body.lrBigLessonPopup .lrPopupBody{max-height:calc(92vh - 76px) !important;overflow:auto !important;font-size:1.12rem !important;line-height:1.6 !important;padding:18px !important;}
      body.lrBigLessonPopup .popupLessonContent,
      body.lrBigLessonPopup .lrLessonCard,
      body.lrBigLessonPopup .lessonQuest{max-width:none !important;}
      body.lrBigLessonPopup .popupChoices,
      body.lrBigLessonPopup .choices{grid-template-columns:1fr 1fr !important;gap:12px !important;}
      body.lrBigLessonPopup .choice,
      body.lrBigLessonPopup #popupChoices button{min-height:58px !important;padding:12px !important;font-size:1.02rem !important;}
      @media(max-width:1250px){body.lrDynamicAdventureMode main{grid-template-columns:minmax(560px,1fr) 290px !important;}body.lrDynamicAdventureMode .playerSidebar{grid-column:1 / -1;}.lr67Hero h1{font-size:2.45rem;}}
      @media(max-width:950px){body.lrDynamicAdventureMode main{display:block !important;}.lr67Hero,.lr67ChoicePanel,.lr67BottomBar,.lr67RoomActions{padding-left:16px;padding-right:16px;}.lr67PanelTitle,.lr67HeroTop{display:block;}.lr67PanelTitle small,.lr67Status{display:block;text-align:left;margin-top:4px;}body.lrBigLessonPopup .popupChoices,body.lrBigLessonPopup .choices{grid-template-columns:1fr !important;}}
    `;
    var st = document.createElement('style');
    st.id = 'lrDynamicAdventureScreen67Style';
    st.textContent = css;
    document.head.appendChild(st);
  }

  function hideOldButtonWalls(){
    ['lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock'].forEach(function(id){
      var el = byId(id); if(el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  function wrapRender(){
    try{
      var oldRender = (typeof window.renderRoom === 'function') ? window.renderRoom : (typeof renderRoom === 'function' ? renderRoom : null);
      if(oldRender && !oldRender.__lr67Wrapped){
        var wrapped = function(){
          var out = oldRender.apply(this, arguments);
          hideOldButtonWalls();
          setTimeout(function(){ window.lr67RenderDynamicScreen('room'); }, 5);
          return out;
        };
        wrapped.__lr67Wrapped = true;
        window.renderRoom = wrapped;
        try{ renderRoom = wrapped; }catch(e){}
      }
    }catch(e){ console.warn('6.7 render wrap skipped', e); }
  }

  function boot(){
    injectStyles();
    ensureMount();
    patchLessonPopups();
    hideOldButtonWalls();
    if(typeof window.lrRenderExplorationNav === 'function') window.lrRenderExplorationNav = function(){ hideOldButtonWalls(); window.lr67RenderDynamicScreen('room'); };
    try{ lrRenderExplorationNav = window.lrRenderExplorationNav; }catch(e){}
    wrapRender();
    setTimeout(function(){ window.lr67RenderDynamicScreen('room'); }, 20);
    setTimeout(function(){ window.lr67RenderDynamicScreen('room'); }, 200);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 10);
  window.addEventListener('load', function(){ setTimeout(boot, 80); setTimeout(boot, 500); });
})();
