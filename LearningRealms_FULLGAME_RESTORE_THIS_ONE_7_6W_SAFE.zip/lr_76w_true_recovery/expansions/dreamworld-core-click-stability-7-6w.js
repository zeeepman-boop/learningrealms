/* LearningRealms 7.6W Dream World Click Stability Core
   Purpose: preserve the beautiful 7.6C museum/RPG shell while stopping automatic DOM observer loops
   and click-swallowing behaviors from freezing or blocking normal buttons. */
(function(){
  "use strict";
  window.__LR76W_CLICK_STABILITY_CORE__ = true;
  // The old stacked patch chain used MutationObserver to constantly rewrite visible panels.
  // That made the interface fragile and could keep the page busy enough that buttons looked hoverable but did not respond.
  // For this recovery branch, observers are disabled globally. Content should open through normal buttons/functions.
  try{
    var InertMutationObserver = function(){ return { observe:function(){}, disconnect:function(){}, takeRecords:function(){ return []; } }; };
    window.MutationObserver = InertMutationObserver;
    window.WebKitMutationObserver = InertMutationObserver;
  }catch(e){}
  // Keep empty/backdrop overlays from sitting above the game if an old popup script half-opens one.
  function clearBlockingEmptyOverlays(){
    try{
      var root = document.getElementById('lrPopupRoot');
      if(root && !root.classList.contains('hidden')){
        var body = document.getElementById('lrPopupBody');
        var text = body ? (body.textContent || '').trim() : '';
        if(!text){ root.classList.add('hidden'); }
      }
      document.querySelectorAll('.lrPopupBackdrop,.modalBackdrop,.overlayBackdrop').forEach(function(el){
        if(!el.closest('#lrPopupRoot:not(.hidden)')) el.style.pointerEvents='none';
      });
    }catch(e){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', clearBlockingEmptyOverlays, {once:true});
  else clearBlockingEmptyOverlays();
  window.addEventListener('load', clearBlockingEmptyOverlays, {once:true});
})();
