// Boss Content Pack 1
// Adds richer realm boss content without changing curriculum lessons.

window.LR_BOSS_CONTENT = {
  Luna:{
    Reading:[
      {title:"Silver Owl Story Boss",intro:"The Silver Owl spreads its wings over the Story Stone.",q:"Boss: Which answer shows character, setting, and problem?",c:["Rabbit in a pond with a broken bridge","A dime is 10 cents","The word ship starts with SH"],a:"Rabbit in a pond with a broken bridge",reward:"Moon Feather Banner"},
      {title:"Hidden Den Reading Boss",intro:"Reader Rabbit points to a glowing root under the den door.",q:"Boss: What is the solution in this story? The bridge broke, so the animals built a new bridge.",c:["built a new bridge","the bridge broke","animals"],a:"built a new bridge",reward:"Reader Rabbit Picture"}
    ],
    English:[
      {title:"Punctuation Arch Boss",intro:"The Grammar Gate glows with commas, periods, and question marks.",q:"Boss: Which sentence is written correctly?",c:["The owl flew over the gate.","the owl flew over the gate","Owl flew gate"],a:"The owl flew over the gate.",reward:"Grammar Star Scroll"}
    ],
    Math:[
      {title:"Number Bridge Boss",intro:"Stone numbers rise from the bridge like stepping stones.",q:"Boss: 8 + 7 = ?",c:["15","14","16"],a:"15",reward:"Number Lantern"}
    ],
    Science:[
      {title:"Marsh Observation Boss",intro:"A frog hops beside a beam of sunlight.",q:"Boss: A shadow forms when something blocks...",c:["light","sound","water"],a:"light",reward:"Shadow Frog Charm"}
    ],
    History:[
      {title:"Map Stone Boss",intro:"A tiny map glows on the old marker stone.",q:"Boss: Which tool helps show where places are?",c:["map","verb","magnet"],a:"map",reward:"Little Map Frame"}
    ],
    Civics:[
      {title:"Kind Rule Boss",intro:"A town bell rings softly near the rule stone.",q:"Boss: Good rules help people stay...",c:["safe","lost","hidden"],a:"safe",reward:"Kind Rule Ribbon"}
    ]
  },

  Ava:{
    Math:[
      {title:"Iron Hills Gear Boss",intro:"The Broken Lift groans as the gears begin to turn.",q:"Boss: Solve 3x + 4 = 22.",c:["6","8","18"],a:"6",reward:"Restored Gear Trophy"},
      {title:"Survey Camp Ratio Boss",intro:"Gear Fox scratches a ratio into the dirt beside the survey posts.",q:"Boss: Which ratio matches 2:3?",c:["4:6","3:5","5:6"],a:"4:6",reward:"Survey Banner"}
    ],
    English:[
      {title:"Evidence Hall Boss",intro:"A glowing scroll asks for proof, not guesses.",q:"Boss: In CER, what explains how evidence supports the claim?",c:["reasoning","setting","prefix"],a:"reasoning",reward:"Evidence Scroll"}
    ],
    Science:[
      {title:"Crystal Marsh Boss",intro:"The weather station clicks as the marsh grows quiet.",q:"Boss: In a controlled experiment, how many main variables should change?",c:["one","all","none"],a:"one",reward:"Weather Station Model"},
      {title:"Food Web Boss",intro:"Frog tracks, reeds, and owl feathers form a living pattern.",q:"Boss: Which organism is usually a producer?",c:["plant","fox","owl"],a:"plant",reward:"Food Web Plaque"}
    ],
    History:[
      {title:"Archive Source Boss",intro:"Historian Alder opens a case holding old papers.",q:"Boss: A diary written during an event is usually a...",c:["primary source","secondary source","fictional source"],a:"primary source",reward:"Primary Source Badge"}
    ],
    Civics:[
      {title:"Council Boss",intro:"The round table glows as the council waits for an answer.",q:"Boss: Citizenship includes rights and...",c:["responsibilities","evaporation","fractions"],a:"responsibilities",reward:"Council Seal"}
    ],
    Reading:[
      {title:"Theme Boss",intro:"A lantern shines on the final line of an old story.",q:"Boss: Theme is the story's...",c:["message or lesson","font size","page number"],a:"message or lesson",reward:"Theme Lantern"}
    ]
  },

  Michael:{
    Math:[
      {title:"Algebra Gate Boss",intro:"The gate locks rearrange themselves into equations.",q:"Boss: Solve 5x + 2 = 3x + 14.",c:["6","8","12"],a:"6",reward:"Algebra Gate Key"},
      {title:"Slope Tower Boss",intro:"A tower staircase rises at a steady angle.",q:"Boss: What is the slope from (2,3) to (4,9)?",c:["3","6","2"],a:"3",reward:"Slope Tower Sketch"}
    ],
    English:[
      {title:"Argument Boss",intro:"A debate chamber falls silent as the counterclaim appears.",q:"Boss: A rebuttal answers the...",c:["counterclaim","citation","setting"],a:"counterclaim",reward:"Rebuttal Banner"},
      {title:"Research Boss",intro:"Archive lamps shine on three old sources.",q:"Boss: A reliable source should be checked for author, evidence, and...",c:["date","color","page size"],a:"date",reward:"Research Seal"}
    ],
    Science:[
      {title:"Physical Science Boss",intro:"A metal orb hums as force symbols appear.",q:"Boss: Newton's second law is...",c:["F = ma","y = mx + b","C = πd"],a:"F = ma",reward:"Force Orb"},
      {title:"Chemistry Boss",intro:"Atoms rearrange on a glowing table.",q:"Boss: A chemical change makes...",c:["new substances","only a shape change","a paragraph"],a:"new substances",reward:"Atom Display"}
    ],
    History:[
      {title:"Constitution Boss",intro:"The Archive Guide unrolls a glowing copy of the old framework.",q:"Boss: Checks and balances help limit government...",c:["power","weather","density"],a:"power",reward:"Constitution Frame"},
      {title:"Economics Boss",intro:"A market scale balances wants and resources.",q:"Boss: Scarcity means resources are...",c:["limited","unlimited","unneeded"],a:"limited",reward:"Market Scale Relic"}
    ],
    Civics:[
      {title:"Republic Boss",intro:"A council seal glows on the chamber floor.",q:"Boss: Rule of law means laws apply to...",c:["everyone","only rulers","only children"],a:"everyone",reward:"Rule of Law Seal"}
    ],
    Reading:[
      {title:"Inference Boss",intro:"A shadow moves behind the archive shelves, leaving only clues.",q:"Boss: A strong inference uses evidence and...",c:["reasoning","punctuation","volume"],a:"reasoning",reward:"Inference Lens"}
    ]
  }
};
