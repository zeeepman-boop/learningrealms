// Curriculum Pack 6C: Economics Foundation Expansion
// Content-only pack. No engine changes.
// Adds economics lessons for Luna, Ava, and Michael.
// This is additive and open-ended: future economics packs can append thousands more lessons with LR_addLessons.

(function(){
  LR_addLessons("Luna","Economics",[
 {
  "teach": "A need is something people must have to live safely.",
  "practice": "Food, water, and shelter are needs.",
  "q": "Which is a need?",
  "c": [
   "water",
   "extra toy",
   "fancy sticker"
  ],
  "a": "water"
 },
 {
  "teach": "A want is something people would like to have.",
  "practice": "A toy can be a want.",
  "q": "Which is a want?",
  "c": [
   "clean water",
   "toy",
   "warm shelter"
  ],
  "a": "toy"
 },
 {
  "teach": "A good is a thing people can use or buy.",
  "practice": "A book, apple, or chair can be a good.",
  "q": "Which is a good?",
  "c": [
   "haircut",
   "helping",
   "apple"
  ],
  "a": "apple"
 },
 {
  "teach": "A service is work someone does for someone else.",
  "practice": "A haircut is a service.",
  "q": "Which is a service?",
  "c": [
   "haircut",
   "pencil",
   "apple"
  ],
  "a": "haircut"
 },
 {
  "teach": "A worker does a job.",
  "practice": "A baker, farmer, and mail carrier are workers.",
  "q": "Who does a job?",
  "c": [
   "puddle",
   "worker",
   "cloud"
  ],
  "a": "worker"
 },
 {
  "teach": "Money can buy goods and services.",
  "practice": "People may use money at a store.",
  "q": "What can money buy?",
  "c": [
   "only thunder",
   "nothing ever",
   "goods and services"
  ],
  "a": "goods and services"
 },
 {
  "teach": "Spending means using money to buy something.",
  "practice": "Buying bread is spending.",
  "q": "Spending uses...",
  "c": [
   "money",
   "rainbows",
   "sleep"
  ],
  "a": "money"
 },
 {
  "teach": "Saving means keeping money for later.",
  "practice": "Saving can help someone buy something later.",
  "q": "Saving means keeping money for...",
  "c": [
   "throwing away",
   "later",
   "noise"
  ],
  "a": "later"
 },
 {
  "teach": "A coin is a kind of money.",
  "practice": "Pennies, nickels, dimes, and quarters are coins.",
  "q": "Which is a coin?",
  "c": [
   "pillow",
   "carrot",
   "nickel"
  ],
  "a": "nickel"
 },
 {
  "teach": "A price tells how much money something costs.",
  "practice": "A sign may say an apple costs one dollar.",
  "q": "What does a price tell?",
  "c": [
   "cost",
   "weather",
   "direction"
  ],
  "a": "cost"
 },
 {
  "teach": "Cheap means something costs less money.",
  "practice": "A cheap pencil costs less than an expensive toy.",
  "q": "Cheap means costs...",
  "c": [
   "more",
   "less",
   "nothing"
  ],
  "a": "less"
 },
 {
  "teach": "Expensive means something costs more money.",
  "practice": "A bicycle usually costs more than a pencil.",
  "q": "Expensive means costs...",
  "c": [
   "less",
   "zero always",
   "more"
  ],
  "a": "more"
 },
 {
  "teach": "A choice means picking one thing instead of another.",
  "practice": "You may choose an apple or a banana.",
  "q": "A choice means...",
  "c": [
   "picking",
   "sleeping",
   "melting"
  ],
  "a": "picking"
 },
 {
  "teach": "Scarcity means there is not enough for every want.",
  "practice": "One cookie and two people wanting it shows scarcity.",
  "q": "Scarcity means not enough for every...",
  "c": [
   "map",
   "want",
   "cloud"
  ],
  "a": "want"
 },
 {
  "teach": "When things are scarce, people must choose.",
  "practice": "If you have one coin, you may choose one treat.",
  "q": "Scarcity makes people...",
  "c": [
   "float",
   "turn invisible",
   "choose"
  ],
  "a": "choose"
 },
 {
  "teach": "Trading means giving one thing to get another.",
  "practice": "A person may trade an apple for an orange.",
  "q": "Trading means giving one thing to get...",
  "c": [
   "another",
   "rain",
   "a shadow"
  ],
  "a": "another"
 },
 {
  "teach": "A producer makes or grows something.",
  "practice": "A farmer grows food.",
  "q": "Who grows food?",
  "c": [
   "consumer",
   "producer",
   "road"
  ],
  "a": "producer"
 },
 {
  "teach": "A consumer uses or buys goods and services.",
  "practice": "Someone eating an apple is a consumer.",
  "q": "Who uses or buys things?",
  "c": [
   "pencil",
   "hill",
   "consumer"
  ],
  "a": "consumer"
 },
 {
  "teach": "A farmer is a producer.",
  "practice": "Farmers grow food people can use.",
  "q": "What does a farmer produce?",
  "c": [
   "food",
   "moonlight",
   "rules"
  ],
  "a": "food"
 },
 {
  "teach": "A baker is a producer.",
  "practice": "A baker makes bread, cakes, or rolls.",
  "q": "What might a baker make?",
  "c": [
   "rivers",
   "bread",
   "cloud shoes"
  ],
  "a": "bread"
 },
 {
  "teach": "A customer buys something.",
  "practice": "A customer might buy apples at a store.",
  "q": "Who buys something?",
  "c": [
   "mountain",
   "lamp",
   "customer"
  ],
  "a": "customer"
 },
 {
  "teach": "A market is a place where people buy and sell.",
  "practice": "A farmer's market sells food.",
  "q": "What happens at a market?",
  "c": [
   "buying and selling",
   "only sleeping",
   "only raining"
  ],
  "a": "buying and selling"
 },
 {
  "teach": "People work to earn money.",
  "practice": "Money can help people buy needs and wants.",
  "q": "Why do many people work?",
  "c": [
   "to make clouds",
   "to earn money",
   "to hide food"
  ],
  "a": "to earn money"
 },
 {
  "teach": "A tool can help workers do a job.",
  "practice": "A shovel helps a gardener dig.",
  "q": "What can help a worker?",
  "c": [
   "dream",
   "shadow",
   "tool"
  ],
  "a": "tool"
 },
 {
  "teach": "A budget is a plan for money.",
  "practice": "A budget helps decide how to spend and save.",
  "q": "A budget is a money...",
  "c": [
   "plan",
   "song",
   "animal"
  ],
  "a": "plan"
 },
 {
  "teach": "Giving can help other people.",
  "practice": "A person may give food, time, or money to help.",
  "q": "Giving can help...",
  "c": [
   "only rocks",
   "other people",
   "no one"
  ],
  "a": "other people"
 },
 {
  "teach": "Borrowing means using something and giving it back.",
  "practice": "Borrowing a book means returning it later.",
  "q": "Borrowing means you should...",
  "c": [
   "hide it forever",
   "break it",
   "give it back"
  ],
  "a": "give it back"
 },
 {
  "teach": "Lending means letting someone use something for a while.",
  "practice": "If you lend a pencil, you expect it back.",
  "q": "Lending means someone uses something...",
  "c": [
   "for a while",
   "forever always",
   "only underwater"
  ],
  "a": "for a while"
 },
 {
  "teach": "A bank can help people keep money safe.",
  "practice": "People may save money in a bank.",
  "q": "What can a bank help keep safe?",
  "c": [
   "rain",
   "money",
   "grass"
  ],
  "a": "money"
 },
 {
  "teach": "Work can be paid or unpaid.",
  "practice": "Helping at home may be unpaid work.",
  "q": "Helping at home may be...",
  "c": [
   "a coin",
   "a store",
   "unpaid work"
  ],
  "a": "unpaid work"
 },
 {
  "teach": "People can share resources.",
  "practice": "Taking turns with crayons is sharing a resource.",
  "q": "Taking turns is a way to...",
  "c": [
   "share",
   "steal",
   "forget"
  ],
  "a": "share"
 },
 {
  "teach": "A resource is something people use.",
  "practice": "Wood, water, time, and money can be resources.",
  "q": "Which is a resource?",
  "c": [
   "empty sound",
   "water",
   "nothing"
  ],
  "a": "water"
 },
 {
  "teach": "People cannot have every want at the same time.",
  "practice": "They must choose what matters most.",
  "q": "Because people cannot have every want, they must...",
  "c": [
   "turn blue",
   "stop learning",
   "choose"
  ],
  "a": "choose"
 },
 {
  "teach": "Good choices think about needs first.",
  "practice": "Food and shelter usually come before extra toys.",
  "q": "Which should usually come first?",
  "c": [
   "needs",
   "extra wants",
   "random glitter"
  ],
  "a": "needs"
 },
 {
  "teach": "A job can help a family earn income.",
  "practice": "Income is money people receive.",
  "q": "Money from a job is called...",
  "c": [
   "a map key",
   "income",
   "a cloud"
  ],
  "a": "income"
 },
 {
  "teach": "A store sells goods.",
  "practice": "A grocery store sells food goods.",
  "q": "A store is a place that...",
  "c": [
   "makes thunder",
   "counts mountains",
   "sells goods"
  ],
  "a": "sells goods"
 },
 {
  "teach": "People can compare prices.",
  "practice": "One item may cost less than another.",
  "q": "Comparing prices helps people...",
  "c": [
   "choose wisely",
   "forget money",
   "make rivers"
  ],
  "a": "choose wisely"
 },
 {
  "teach": "A sale can mean a lower price.",
  "practice": "A store may lower a price for a sale.",
  "q": "A sale may make a price...",
  "c": [
   "heavier",
   "lower",
   "louder"
  ],
  "a": "lower"
 },
 {
  "teach": "People can save for a goal.",
  "practice": "Saving for a bike means keeping money over time.",
  "q": "Saving for a goal takes...",
  "c": [
   "magic only",
   "no choices",
   "time"
  ],
  "a": "time"
 },
 {
  "teach": "Economics helps people understand choices.",
  "practice": "Needs, wants, money, work, and trade are part of economics.",
  "q": "Economics helps us understand...",
  "c": [
   "choices",
   "only stars",
   "only spelling"
  ],
  "a": "choices"
 }
]);
  LR_addLessons("Ava","Economics",[
 {
  "teach": "Scarcity means resources are limited compared with wants.",
  "practice": "Because wants are greater than resources, people must choose.",
  "q": "Scarcity means resources are...",
  "c": [
   "limited",
   "unlimited",
   "imaginary"
  ],
  "a": "limited"
 },
 {
  "teach": "A need is necessary for basic well-being.",
  "practice": "Food, water, shelter, and basic safety are needs.",
  "q": "Which is a need?",
  "c": [
   "extra poster",
   "shelter",
   "fancy bracelet"
  ],
  "a": "shelter"
 },
 {
  "teach": "A want is something people would like but do not strictly need.",
  "practice": "Entertainment can be a want.",
  "q": "Which is a want?",
  "c": [
   "clean water",
   "basic food",
   "movie ticket"
  ],
  "a": "movie ticket"
 },
 {
  "teach": "Goods are physical things people can use.",
  "practice": "Shoes, books, and apples are goods.",
  "q": "Which is a good?",
  "c": [
   "book",
   "dentist visit",
   "haircut"
  ],
  "a": "book"
 },
 {
  "teach": "Services are actions or work provided to others.",
  "practice": "A repair job or doctor visit is a service.",
  "q": "Which is a service?",
  "c": [
   "apple",
   "repair job",
   "chair"
  ],
  "a": "repair job"
 },
 {
  "teach": "A producer makes goods or provides services.",
  "practice": "A farmer produces food; a mechanic provides repairs.",
  "q": "Who makes goods or services?",
  "c": [
   "consumer",
   "tax",
   "producer"
  ],
  "a": "producer"
 },
 {
  "teach": "A consumer buys or uses goods and services.",
  "practice": "A person buying bread is a consumer.",
  "q": "A consumer buys or uses...",
  "c": [
   "goods and services",
   "only laws",
   "only maps"
  ],
  "a": "goods and services"
 },
 {
  "teach": "A market connects buyers and sellers.",
  "practice": "Markets can be stores, websites, or farmer's markets.",
  "q": "A market connects buyers and...",
  "c": [
   "judges",
   "sellers",
   "weather"
  ],
  "a": "sellers"
 },
 {
  "teach": "A price is the amount paid for a good or service.",
  "practice": "Prices help buyers and sellers make decisions.",
  "q": "A price tells how much something...",
  "c": [
   "weighs always",
   "votes",
   "costs"
  ],
  "a": "costs"
 },
 {
  "teach": "Supply means how much sellers are willing and able to sell.",
  "practice": "If farmers grow more apples, supply may rise.",
  "q": "Supply is about how much sellers can...",
  "c": [
   "sell",
   "eat",
   "forget"
  ],
  "a": "sell"
 },
 {
  "teach": "Demand means how much buyers are willing and able to buy.",
  "practice": "If many people want apples, demand is high.",
  "q": "Demand is about how much buyers want and can...",
  "c": [
   "paint",
   "buy",
   "hide"
  ],
  "a": "buy"
 },
 {
  "teach": "Opportunity cost is what you give up when you choose one option.",
  "practice": "Spending money on a toy means giving up saving that money.",
  "q": "Opportunity cost is what you...",
  "c": [
   "always gain twice",
   "never consider",
   "give up"
  ],
  "a": "give up"
 },
 {
  "teach": "A tradeoff means choosing one thing instead of another.",
  "practice": "More time reading may mean less time playing.",
  "q": "A tradeoff means choosing one thing instead of...",
  "c": [
   "another",
   "nothing",
   "the same thing twice"
  ],
  "a": "another"
 },
 {
  "teach": "A budget plans income, spending, saving, and giving.",
  "practice": "Budgets help people manage limited money.",
  "q": "A budget is a plan for...",
  "c": [
   "weather",
   "money",
   "landforms"
  ],
  "a": "money"
 },
 {
  "teach": "Income is money received.",
  "practice": "Wages from a job are income.",
  "q": "Income is money...",
  "c": [
   "buried",
   "erased",
   "received"
  ],
  "a": "received"
 },
 {
  "teach": "Expenses are money spent.",
  "practice": "Food, clothing, and fuel can be expenses.",
  "q": "Expenses are money...",
  "c": [
   "spent",
   "grown on trees",
   "hidden from math"
  ],
  "a": "spent"
 },
 {
  "teach": "Saving means setting money aside for later.",
  "practice": "Saving helps people plan for future needs and wants.",
  "q": "Saving sets money aside for...",
  "c": [
   "immediate spending only",
   "later",
   "nothing"
  ],
  "a": "later"
 },
 {
  "teach": "Spending means using money to buy goods or services.",
  "practice": "Buying lunch is spending.",
  "q": "Spending means using money to...",
  "c": [
   "sleep",
   "vote",
   "buy"
  ],
  "a": "buy"
 },
 {
  "teach": "Interest can be money paid for saving or borrowing.",
  "practice": "A saver may earn interest; a borrower may pay it.",
  "q": "Interest connects saving and...",
  "c": [
   "borrowing",
   "climate",
   "directions"
  ],
  "a": "borrowing"
 },
 {
  "teach": "Credit means borrowing now and paying later.",
  "practice": "Credit can be useful but must be repaid.",
  "q": "Credit means borrowing now and paying...",
  "c": [
   "never",
   "later",
   "with rocks"
  ],
  "a": "later"
 },
 {
  "teach": "Debt is money owed.",
  "practice": "Borrowing creates debt until it is repaid.",
  "q": "Debt means money...",
  "c": [
   "saved forever",
   "donated only",
   "owed"
  ],
  "a": "owed"
 },
 {
  "teach": "Human capital means people's skills, knowledge, and experience.",
  "practice": "Education and practice can build human capital.",
  "q": "Human capital includes skills and...",
  "c": [
   "knowledge",
   "mountains",
   "coins only"
  ],
  "a": "knowledge"
 },
 {
  "teach": "Productivity means how much output is made from inputs.",
  "practice": "Better tools or training can increase productivity.",
  "q": "Productivity measures how much is...",
  "c": [
   "hidden",
   "produced",
   "taxed only"
  ],
  "a": "produced"
 },
 {
  "teach": "Specialization means focusing on a particular job or task.",
  "practice": "A baker specializes in baking.",
  "q": "Specialization means focusing on a...",
  "c": [
   "random hobby only",
   "border",
   "task"
  ],
  "a": "task"
 },
 {
  "teach": "Division of labor splits work into tasks.",
  "practice": "One worker cuts, another packages, another delivers.",
  "q": "Division of labor splits work into...",
  "c": [
   "tasks",
   "taxes",
   "continents"
  ],
  "a": "tasks"
 },
 {
  "teach": "Trade lets people get goods and services they do not produce themselves.",
  "practice": "A farmer may trade food for tools.",
  "q": "Trade helps people get what they do not...",
  "c": [
   "want at all",
   "produce themselves",
   "understand geographically"
  ],
  "a": "produce themselves"
 },
 {
  "teach": "Barter is trade without money.",
  "practice": "Trading eggs for cloth is barter.",
  "q": "Barter is trade without...",
  "c": [
   "people",
   "goods",
   "money"
  ],
  "a": "money"
 },
 {
  "teach": "Money makes trade easier than barter.",
  "practice": "People can use money instead of finding an exact trade.",
  "q": "Money makes trade...",
  "c": [
   "easier",
   "impossible",
   "illegal"
  ],
  "a": "easier"
 },
 {
  "teach": "A natural resource comes from nature.",
  "practice": "Land, water, timber, coal, and soil are natural resources.",
  "q": "Which is a natural resource?",
  "c": [
   "homework rule",
   "timber",
   "receipt"
  ],
  "a": "timber"
 },
 {
  "teach": "Capital resources are tools, buildings, and machines used to produce.",
  "practice": "A tractor is a capital resource for farming.",
  "q": "Which is a capital resource?",
  "c": [
   "sunlight",
   "worker skill",
   "tractor"
  ],
  "a": "tractor"
 },
 {
  "teach": "Entrepreneurs start or organize businesses.",
  "practice": "They take risks to offer goods or services.",
  "q": "An entrepreneur often starts a...",
  "c": [
   "business",
   "river",
   "court"
  ],
  "a": "business"
 },
 {
  "teach": "Profit is money left after costs are paid.",
  "practice": "A business earns profit if revenue is greater than cost.",
  "q": "Profit is money left after...",
  "c": [
   "weather",
   "costs",
   "voting"
  ],
  "a": "costs"
 },
 {
  "teach": "Loss happens when costs are greater than revenue.",
  "practice": "A business loses money if it spends more than it earns.",
  "q": "Loss happens when costs are greater than...",
  "c": [
   "latitude",
   "law",
   "revenue"
  ],
  "a": "revenue"
 },
 {
  "teach": "Taxes are money people or businesses pay to government.",
  "practice": "Taxes can fund roads, libraries, courts, and emergency services.",
  "q": "Taxes can pay for public...",
  "c": [
   "services",
   "private wishes only",
   "clouds"
  ],
  "a": "services"
 },
 {
  "teach": "Public services are services provided or supported by government.",
  "practice": "Road maintenance and emergency response can be public services.",
  "q": "Which is a public service?",
  "c": [
   "private candy stash",
   "road maintenance",
   "one person's toy"
  ],
  "a": "road maintenance"
 },
 {
  "teach": "A public good can be used by many people.",
  "practice": "Streetlights and public roads can benefit many people.",
  "q": "Which is closest to a public good?",
  "c": [
   "private toothbrush",
   "single lunch",
   "streetlight"
  ],
  "a": "streetlight"
 },
 {
  "teach": "Economic choices involve costs and benefits.",
  "practice": "A new bridge costs money but may improve travel.",
  "q": "A smart choice compares costs and...",
  "c": [
   "benefits",
   "riddles",
   "colors"
  ],
  "a": "benefits"
 },
 {
  "teach": "Incentives encourage or discourage people to act.",
  "practice": "A discount can encourage buying; a fine can discourage breaking rules.",
  "q": "An incentive affects people's...",
  "c": [
   "height",
   "choices",
   "state borders"
  ],
  "a": "choices"
 },
 {
  "teach": "A shortage means quantity demanded is greater than quantity supplied.",
  "practice": "If many want a toy but few are available, there may be a shortage.",
  "q": "A shortage means demand is greater than...",
  "c": [
   "weather",
   "taxes",
   "supply"
  ],
  "a": "supply"
 },
 {
  "teach": "A surplus means quantity supplied is greater than quantity demanded.",
  "practice": "If a store has too many unsold apples, it may have a surplus.",
  "q": "A surplus means supply is greater than...",
  "c": [
   "demand",
   "rainfall",
   "rights"
  ],
  "a": "demand"
 },
 {
  "teach": "Competition can encourage businesses to improve quality or lower prices.",
  "practice": "Sellers compete for buyers.",
  "q": "Competition can encourage better quality or lower...",
  "c": [
   "latitude",
   "prices",
   "rain"
  ],
  "a": "prices"
 },
 {
  "teach": "A monopoly means one seller controls a market.",
  "practice": "With little competition, buyers may have fewer choices.",
  "q": "A monopoly has one main...",
  "c": [
   "consumer",
   "taxpayer",
   "seller"
  ],
  "a": "seller"
 },
 {
  "teach": "Imports are goods or services brought into a country.",
  "practice": "A toy made elsewhere and sold here may be an import.",
  "q": "Imports are brought...",
  "c": [
   "into a country",
   "out of a country",
   "only into a room"
  ],
  "a": "into a country"
 },
 {
  "teach": "Exports are goods or services sold to another country.",
  "practice": "Farm products may be exported.",
  "q": "Exports are sold to...",
  "c": [
   "nobody",
   "another country",
   "only one shelf"
  ],
  "a": "another country"
 },
 {
  "teach": "Economic interdependence means people and places rely on each other.",
  "practice": "A store, farmer, truck driver, and customer may all be connected.",
  "q": "Interdependence means people rely on...",
  "c": [
   "nothing",
   "only maps",
   "each other"
  ],
  "a": "each other"
 },
 {
  "teach": "A household budget helps a family plan money choices.",
  "practice": "It may include food, fuel, saving, giving, and bills.",
  "q": "A household budget helps plan...",
  "c": [
   "money choices",
   "weather",
   "state borders"
  ],
  "a": "money choices"
 },
 {
  "teach": "A business uses resources to offer goods or services.",
  "practice": "Resources include workers, tools, buildings, and materials.",
  "q": "A business uses resources to offer...",
  "c": [
   "laws only",
   "goods or services",
   "rainfall"
  ],
  "a": "goods or services"
 },
 {
  "teach": "Revenue is money a business receives from selling.",
  "practice": "If a store sells bread, the payment is revenue.",
  "q": "Revenue is money a business...",
  "c": [
   "owes always",
   "throws away",
   "receives"
  ],
  "a": "receives"
 },
 {
  "teach": "Costs are what a business pays to operate.",
  "practice": "Wages, supplies, rent, and utilities can be costs.",
  "q": "Business costs are things it...",
  "c": [
   "pays",
   "votes",
   "maps"
  ],
  "a": "pays"
 },
 {
  "teach": "Economics helps explain daily choices and public decisions.",
  "practice": "Money, resources, taxes, trade, and incentives all matter.",
  "q": "Economics helps explain choices and...",
  "c": [
   "only spelling",
   "decisions",
   "only art"
  ],
  "a": "decisions"
 }
]);
  LR_addLessons("Michael","Economics",[
 {
  "teach": "Economics studies choices under scarcity.",
  "practice": "Scarcity exists because resources are limited and wants are not.",
  "q": "Economics studies choices under...",
  "c": [
   "scarcity",
   "gravity only",
   "spelling"
  ],
  "a": "scarcity"
 },
 {
  "teach": "Scarcity forces tradeoffs.",
  "practice": "When resources are limited, choosing one use means giving up another.",
  "q": "Scarcity forces...",
  "c": [
   "unlimited choices",
   "tradeoffs",
   "no decisions"
  ],
  "a": "tradeoffs"
 },
 {
  "teach": "Opportunity cost is the next best alternative given up.",
  "practice": "If you choose an hour of work, the cost might be an hour of rest.",
  "q": "Opportunity cost is the next best...",
  "c": [
   "thing bought twice",
   "price tag only",
   "alternative given up"
  ],
  "a": "alternative given up"
 },
 {
  "teach": "Marginal thinking compares extra benefit and extra cost.",
  "practice": "A person may ask whether one more hour of study is worth the extra time.",
  "q": "Marginal thinking compares extra benefit and extra...",
  "c": [
   "cost",
   "weather",
   "border"
  ],
  "a": "cost"
 },
 {
  "teach": "Incentives influence behavior.",
  "practice": "Rewards, prices, taxes, subsidies, and penalties can change choices.",
  "q": "Incentives influence...",
  "c": [
   "longitude",
   "behavior",
   "rainfall"
  ],
  "a": "behavior"
 },
 {
  "teach": "A positive incentive encourages an action.",
  "practice": "A bonus can encourage more work.",
  "q": "A positive incentive...",
  "c": [
   "always punishes",
   "removes choices",
   "encourages action"
  ],
  "a": "encourages action"
 },
 {
  "teach": "A negative incentive discourages an action.",
  "practice": "A fine can discourage speeding.",
  "q": "A negative incentive...",
  "c": [
   "discourages action",
   "always rewards",
   "creates goods"
  ],
  "a": "discourages action"
 },
 {
  "teach": "Utility means satisfaction or usefulness from a good or service.",
  "practice": "People choose partly based on expected utility.",
  "q": "Utility means satisfaction or...",
  "c": [
   "inflation only",
   "usefulness",
   "public law"
  ],
  "a": "usefulness"
 },
 {
  "teach": "Demand shows how much buyers are willing and able to buy at different prices.",
  "practice": "Demand usually falls when price rises, all else equal.",
  "q": "Demand is about buyers being willing and able to...",
  "c": [
   "sell",
   "tax",
   "buy"
  ],
  "a": "buy"
 },
 {
  "teach": "Supply shows how much sellers are willing and able to sell at different prices.",
  "practice": "Supply often rises when price rises, all else equal.",
  "q": "Supply is about sellers being willing and able to...",
  "c": [
   "sell",
   "consume",
   "vote"
  ],
  "a": "sell"
 },
 {
  "teach": "The law of demand says people usually buy less at higher prices.",
  "practice": "This assumes other factors stay the same.",
  "q": "Higher prices usually reduce quantity...",
  "c": [
   "supplied",
   "demanded",
   "taxed"
  ],
  "a": "demanded"
 },
 {
  "teach": "The law of supply says sellers usually offer more at higher prices.",
  "practice": "Higher prices can make production more attractive.",
  "q": "Higher prices usually increase quantity...",
  "c": [
   "demanded",
   "borrowed",
   "supplied"
  ],
  "a": "supplied"
 },
 {
  "teach": "Equilibrium price is where supply and demand meet.",
  "practice": "At equilibrium, quantity supplied and demanded are balanced.",
  "q": "Equilibrium balances quantity supplied and quantity...",
  "c": [
   "demanded",
   "taxed",
   "printed"
  ],
  "a": "demanded"
 },
 {
  "teach": "A shortage occurs when quantity demanded exceeds quantity supplied.",
  "practice": "Shortages can occur below equilibrium price.",
  "q": "A shortage means demand exceeds...",
  "c": [
   "income",
   "supply",
   "capital"
  ],
  "a": "supply"
 },
 {
  "teach": "A surplus occurs when quantity supplied exceeds quantity demanded.",
  "practice": "Surpluses can occur above equilibrium price.",
  "q": "A surplus means supply exceeds...",
  "c": [
   "utility",
   "debt",
   "demand"
  ],
  "a": "demand"
 },
 {
  "teach": "Price ceilings are legal maximum prices.",
  "practice": "If set below equilibrium, they can cause shortages.",
  "q": "A price ceiling is a legal price...",
  "c": [
   "maximum",
   "minimum",
   "tax credit"
  ],
  "a": "maximum"
 },
 {
  "teach": "Price floors are legal minimum prices.",
  "practice": "If set above equilibrium, they can cause surpluses.",
  "q": "A price floor is a legal price...",
  "c": [
   "maximum",
   "minimum",
   "import"
  ],
  "a": "minimum"
 },
 {
  "teach": "Inflation means a general rise in prices over time.",
  "practice": "When inflation is high, money buys less than before.",
  "q": "Inflation is a general rise in...",
  "c": [
   "latitude",
   "labor hours only",
   "prices"
  ],
  "a": "prices"
 },
 {
  "teach": "Purchasing power means what money can buy.",
  "practice": "Inflation reduces purchasing power if income does not keep up.",
  "q": "Purchasing power is what money can...",
  "c": [
   "buy",
   "weigh",
   "map"
  ],
  "a": "buy"
 },
 {
  "teach": "Interest is the price of borrowing money or the reward for saving.",
  "practice": "Borrowers pay interest; savers may earn it.",
  "q": "Interest is connected to borrowing and...",
  "c": [
   "climate",
   "saving",
   "jury duty"
  ],
  "a": "saving"
 },
 {
  "teach": "Credit allows borrowing now and repayment later.",
  "practice": "Credit can help with major purchases but creates repayment obligations.",
  "q": "Credit means borrowing now and repaying...",
  "c": [
   "never",
   "with landforms",
   "later"
  ],
  "a": "later"
 },
 {
  "teach": "Debt is money owed.",
  "practice": "Debt can be useful or risky depending on amount, purpose, and repayment ability.",
  "q": "Debt means money...",
  "c": [
   "owed",
   "saved",
   "taxed only"
  ],
  "a": "owed"
 },
 {
  "teach": "A budget plans income, expenses, saving, giving, and debt repayment.",
  "practice": "Budgets help manage scarcity at the household level.",
  "q": "A budget is a plan for...",
  "c": [
   "weather patterns",
   "money choices",
   "map symbols"
  ],
  "a": "money choices"
 },
 {
  "teach": "Fixed expenses stay about the same each period.",
  "practice": "Rent or a set subscription may be fixed.",
  "q": "A fixed expense stays about the...",
  "c": [
   "unknown always",
   "opposite",
   "same"
  ],
  "a": "same"
 },
 {
  "teach": "Variable expenses change.",
  "practice": "Food, fuel, or electricity may vary by use.",
  "q": "A variable expense...",
  "c": [
   "changes",
   "never changes",
   "is always free"
  ],
  "a": "changes"
 },
 {
  "teach": "Saving builds future options.",
  "practice": "Emergency savings can reduce risk.",
  "q": "Saving can build future...",
  "c": [
   "shortages always",
   "options",
   "imports only"
  ],
  "a": "options"
 },
 {
  "teach": "Investment uses resources now in hope of future benefits.",
  "practice": "Education, tools, or a business can be investments.",
  "q": "Investment uses resources now for future...",
  "c": [
   "confusion",
   "shortages",
   "benefits"
  ],
  "a": "benefits"
 },
 {
  "teach": "Human capital is knowledge, skills, health, and experience.",
  "practice": "Education and practice can increase human capital.",
  "q": "Human capital includes skills and...",
  "c": [
   "knowledge",
   "buildings only",
   "taxes"
  ],
  "a": "knowledge"
 },
 {
  "teach": "Physical capital includes tools, machines, buildings, and equipment.",
  "practice": "A factory machine is physical capital.",
  "q": "Which is physical capital?",
  "c": [
   "worker skill",
   "machine",
   "sunlight"
  ],
  "a": "machine"
 },
 {
  "teach": "Natural resources are land and materials from nature.",
  "practice": "Soil, timber, coal, water, and minerals are natural resources.",
  "q": "Which is a natural resource?",
  "c": [
   "calculator",
   "training",
   "coal"
  ],
  "a": "coal"
 },
 {
  "teach": "Entrepreneurship organizes resources and takes risk to create value.",
  "practice": "Entrepreneurs start businesses or new projects.",
  "q": "Entrepreneurship involves organizing resources and taking...",
  "c": [
   "risk",
   "votes only",
   "rainfall"
  ],
  "a": "risk"
 },
 {
  "teach": "Profit equals revenue minus costs.",
  "practice": "Profit signals that revenue exceeded expenses.",
  "q": "Profit equals revenue minus...",
  "c": [
   "latitude",
   "costs",
   "labor laws"
  ],
  "a": "costs"
 },
 {
  "teach": "Loss occurs when costs exceed revenue.",
  "practice": "A business with sustained losses may need to change or close.",
  "q": "Loss occurs when costs exceed...",
  "c": [
   "utility",
   "maps",
   "revenue"
  ],
  "a": "revenue"
 },
 {
  "teach": "Productivity measures output per unit of input.",
  "practice": "Better tools, training, or organization can raise productivity.",
  "q": "Productivity measures output per...",
  "c": [
   "input",
   "court",
   "border"
  ],
  "a": "input"
 },
 {
  "teach": "Specialization means focusing on a task or product.",
  "practice": "Specialization can increase efficiency.",
  "q": "Specialization means focusing on a...",
  "c": [
   "random rule",
   "task",
   "weather pattern"
  ],
  "a": "task"
 },
 {
  "teach": "Division of labor breaks production into separate tasks.",
  "practice": "Assembly lines use division of labor.",
  "q": "Division of labor breaks work into...",
  "c": [
   "taxes",
   "rights",
   "tasks"
  ],
  "a": "tasks"
 },
 {
  "teach": "Comparative advantage means producing at lower opportunity cost.",
  "practice": "Trade can benefit both sides when each specializes this way.",
  "q": "Comparative advantage is based on lower opportunity...",
  "c": [
   "cost",
   "price only",
   "tax"
  ],
  "a": "cost"
 },
 {
  "teach": "Trade allows specialization and access to more goods.",
  "practice": "Places trade because resources and skills differ.",
  "q": "Trade allows access to more...",
  "c": [
   "scarcity only",
   "goods",
   "polling places"
  ],
  "a": "goods"
 },
 {
  "teach": "Imports are goods and services bought from other countries.",
  "practice": "Imports enter a country.",
  "q": "Imports are brought...",
  "c": [
   "out of a country",
   "only into a budget",
   "into a country"
  ],
  "a": "into a country"
 },
 {
  "teach": "Exports are goods and services sold to other countries.",
  "practice": "Exports leave a country for sale abroad.",
  "q": "Exports are sold to...",
  "c": [
   "other countries",
   "nobody",
   "one household only"
  ],
  "a": "other countries"
 },
 {
  "teach": "Tariffs are taxes on imports.",
  "practice": "Tariffs can protect domestic producers but raise costs for consumers.",
  "q": "A tariff is a tax on...",
  "c": [
   "voting",
   "imports",
   "roads"
  ],
  "a": "imports"
 },
 {
  "teach": "Quotas limit the quantity of a good that can be imported.",
  "practice": "Quotas restrict trade by amount.",
  "q": "A quota limits import...",
  "c": [
   "quality always",
   "latitude",
   "quantity"
  ],
  "a": "quantity"
 },
 {
  "teach": "Free trade reduces barriers between buyers and sellers across borders.",
  "practice": "It can lower prices but increase competition.",
  "q": "Free trade reduces trade...",
  "c": [
   "barriers",
   "benefits",
   "currency"
  ],
  "a": "barriers"
 },
 {
  "teach": "Economic systems answer what to produce, how to produce, and who gets goods.",
  "practice": "Different systems answer these questions differently.",
  "q": "Economic systems answer production and distribution...",
  "c": [
   "weather reports",
   "questions",
   "court cases"
  ],
  "a": "questions"
 },
 {
  "teach": "A market economy relies mostly on private choices and prices.",
  "practice": "Consumers and producers make many decisions.",
  "q": "A market economy relies on private choices and...",
  "c": [
   "commands only",
   "random lists",
   "prices"
  ],
  "a": "prices"
 },
 {
  "teach": "A command economy relies heavily on government planning.",
  "practice": "Government decides many production and distribution questions.",
  "q": "A command economy relies on government...",
  "c": [
   "planning",
   "weather",
   "private prices only"
  ],
  "a": "planning"
 },
 {
  "teach": "A mixed economy combines markets and government roles.",
  "practice": "The United States is usually described as a mixed economy.",
  "q": "A mixed economy combines markets and...",
  "c": [
   "no choices",
   "government roles",
   "bartering only"
  ],
  "a": "government roles"
 },
 {
  "teach": "Public goods can be shared by many users.",
  "practice": "National defense and streetlights are common examples.",
  "q": "Public goods can be shared by...",
  "c": [
   "only one buyer",
   "no one",
   "many users"
  ],
  "a": "many users"
 },
 {
  "teach": "Externalities are side effects of economic activity on others.",
  "practice": "Pollution is a negative externality.",
  "q": "An externality is a side...",
  "c": [
   "effect",
   "tax only",
   "budget"
  ],
  "a": "effect"
 },
 {
  "teach": "Taxes fund government services and can change incentives.",
  "practice": "Taxes help pay for roads, courts, defense, and programs.",
  "q": "Taxes can fund government...",
  "c": [
   "private toys only",
   "services",
   "latitude lines"
  ],
  "a": "services"
 },
 {
  "teach": "Subsidies are government payments or support that lower costs or encourage activity.",
  "practice": "A subsidy can encourage production of a good.",
  "q": "A subsidy tends to lower costs or encourage...",
  "c": [
   "shortages only",
   "imports always",
   "activity"
  ],
  "a": "activity"
 },
 {
  "teach": "Cost-benefit analysis compares expected costs and benefits.",
  "practice": "Governments and households can use it for decisions.",
  "q": "Cost-benefit analysis compares costs and...",
  "c": [
   "benefits",
   "weather",
   "colors"
  ],
  "a": "benefits"
 },
 {
  "teach": "Public policy often has tradeoffs.",
  "practice": "A policy may help one goal while creating costs elsewhere.",
  "q": "Public policy often involves...",
  "c": [
   "no consequences",
   "tradeoffs",
   "one answer always"
  ],
  "a": "tradeoffs"
 },
 {
  "teach": "GDP estimates the market value of final goods and services produced in a country.",
  "practice": "GDP is one measure of economic output.",
  "q": "GDP estimates economic...",
  "c": [
   "latitude",
   "court rulings",
   "output"
  ],
  "a": "output"
 },
 {
  "teach": "Unemployment means people who want work cannot find work.",
  "practice": "The unemployment rate measures part of the labor market.",
  "q": "Unemployment concerns people who cannot find...",
  "c": [
   "work",
   "maps",
   "tax forms only"
  ],
  "a": "work"
 },
 {
  "teach": "The labor force includes people working or actively looking for work.",
  "practice": "It is one measure used to understand employment.",
  "q": "The labor force includes workers and job...",
  "c": [
   "imports",
   "seekers",
   "landforms"
  ],
  "a": "seekers"
 },
 {
  "teach": "Consumer choice sends signals to producers.",
  "practice": "When consumers buy more, businesses may produce more.",
  "q": "Consumer purchases send signals to...",
  "c": [
   "only courts",
   "weather",
   "producers"
  ],
  "a": "producers"
 },
 {
  "teach": "Prices help coordinate many market decisions.",
  "practice": "Prices communicate scarcity and preferences.",
  "q": "Prices help communicate scarcity and...",
  "c": [
   "preferences",
   "court rules",
   "map keys"
  ],
  "a": "preferences"
 },
 {
  "teach": "Economic reasoning asks what is scarce, what incentives matter, and what tradeoffs follow.",
  "practice": "This helps people think clearly about money, policy, and daily life.",
  "q": "Economic reasoning pays attention to scarcity, incentives, and...",
  "c": [
   "spelling only",
   "tradeoffs",
   "weather"
  ],
  "a": "tradeoffs"
 }
]);
})();
