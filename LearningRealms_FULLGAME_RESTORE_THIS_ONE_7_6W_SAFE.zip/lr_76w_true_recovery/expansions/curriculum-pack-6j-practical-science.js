// Curriculum Pack 6J - Practical Science Foundation
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Science",[
{teach:"Matter takes up space.",q:"Matter takes up...",c:["space","nothing","music"],a:"space"},
{teach:"Liquids can flow.",q:"Which can flow?",c:["liquids","rocks","chairs"],a:"liquids"},
{teach:"Plants need water and light.",q:"Plants need...",c:["water and light","sand only","noise"],a:"water and light"},
{teach:"Weather changes daily.",q:"Weather can...",c:["change","freeze forever","stay same"],a:"change"}
]);

LR_addLessons("Ava","Science",[
{teach:"Force can change motion.",q:"Force changes...",c:["motion","color","time"],a:"motion"},
{teach:"Energy can change forms.",q:"Energy can...",c:["change forms","vanish","sleep"],a:"change forms"},
{teach:"Observation is key in science.",q:"Science uses...",c:["observation","guessing only","luck"],a:"observation"},
{teach:"Simple machines reduce effort.",q:"Simple machines help by...",c:["reducing effort","making weather","growing plants"],a:"reducing effort"}
]);

LR_addLessons("Michael","Science",[
{teach:"Hypotheses are testable ideas.",q:"A hypothesis is...",c:["testable","final proof","random"],a:"testable"},
{teach:"Variables affect experiments.",q:"Experiments use...",c:["variables","legends","maps"],a:"variables"},
{teach:"Data supports conclusions.",q:"Conclusions use...",c:["data","guesses","stories"],a:"data"},
{teach:"Systems interact in science.",q:"Scientific systems can...",c:["interact","ignore each other","stop"],a:"interact"}
]);
})();