LR_addLessons("Ava","Math",[
 {teach:"Ratios compare quantities.",practice:"2:4 = 1:2",q:"Which matches 1:2?",c:["3:6","2:5","4:5"],a:"3:6"},
 {teach:"A proportion shows equal ratios.",practice:"1:2 = 2:4",q:"Which is proportional?",c:["2:4","2:5","3:5"],a:"2:4"}
]);
LR_addLessons("Ava","English",[
 {teach:"Inference uses clues.",practice:"A character shivers and pulls a coat tight.",q:"Inference means?",c:["use clues","copy text","guess only"],a:"use clues"}
]);
LR_addLessons("Ava","Science",[
 {teach:"Cells are basic life units.",practice:"Cells have parts.",q:"What is a cell?",c:["life unit","planet","rock"],a:"life unit"}
]);
LR_addLessons("Ava","History",[
 {teach:"A primary source comes from the time being studied.",practice:"A diary from the event.",q:"Which is a primary source?",c:["a diary from the event","a cartoon","a new summary"],a:"a diary from the event"}
]);
