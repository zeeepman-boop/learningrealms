// Curriculum Pack 6F - Nature / Health Foundation
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Nature",[
{teach:"Plants need sunlight, water, and soil.",q:"What do plants need?",c:["sunlight water and soil","music only","rocks only"],a:"sunlight water and soil"},
{teach:"Spring brings new growth.",q:"What season brings new growth?",c:["spring","winter","fall"],a:"spring"},
{teach:"Animals live in habitats.",q:"Where do animals live?",c:["habitats","desks","baskets"],a:"habitats"},
{teach:"Exercise helps bodies stay strong.",q:"Exercise helps bodies stay...",c:["strong","sleepy","invisible"],a:"strong"},
{teach:"Drinking water helps the body.",q:"What helps the body?",c:["water","paint","sand"],a:"water"},
{teach:"Weather changes each day.",q:"What can change daily?",c:["weather","mountains","oceans"],a:"weather"},
{teach:"Trees have roots.",q:"What helps hold trees?",c:["roots","bells","clouds"],a:"roots"},
{teach:"Animals need food and water.",q:"Animals need...",c:["food and water","toys only","books"],a:"food and water"}
]);

LR_addLessons("Ava","Nature",[
{teach:"Ecosystems are living things and their environment together.",q:"An ecosystem includes...",c:["living things and environment","only animals","only rocks"],a:"living things and environment"},
{teach:"Habitats provide food, water, and shelter.",q:"Habitats provide...",c:["food water shelter","only shade","only trees"],a:"food water shelter"},
{teach:"Hygiene helps prevent illness.",q:"Hygiene can help...",c:["prevent illness","grow rocks","change weather"],a:"prevent illness"},
{teach:"Food groups provide different nutrients.",q:"Food groups provide...",c:["different nutrients","identical nutrients","only sugar"],a:"different nutrients"},
{teach:"Seasons affect plants and animals.",q:"Seasons affect...",c:["plants and animals","mountains only","roads"],a:"plants and animals"},
{teach:"Clouds can help predict weather.",q:"Clouds may help predict...",c:["weather","music","time"],a:"weather"},
{teach:"Exercise supports health.",q:"Exercise supports...",c:["health","rust","erosion"],a:"health"},
{teach:"Observation helps scientists learn.",q:"Scientists use...",c:["observation","guessing only","noise"],a:"observation"}
]);

LR_addLessons("Michael","Nature",[
{teach:"Ecosystems contain interacting organisms and environments.",q:"Ecosystems contain...",c:["organisms and environments","only water","only animals"],a:"organisms and environments"},
{teach:"Biodiversity means variety of life.",q:"Biodiversity means...",c:["variety of life","weather patterns","soil only"],a:"variety of life"},
{teach:"Preparedness helps with storms and emergencies.",q:"Preparedness helps with...",c:["emergencies","erosion","gravity"],a:"emergencies"},
{teach:"Nutrition supports body function.",q:"Nutrition supports...",c:["body function","paint drying","road building"],a:"body function"},
{teach:"Weather systems affect regions.",q:"Weather systems affect...",c:["regions","alphabet order","currency"],a:"regions"},
{teach:"Conservation protects resources.",q:"Conservation helps...",c:["protect resources","increase waste","erase habitats"],a:"protect resources"},
{teach:"Field observation improves understanding.",q:"Field observation improves...",c:["understanding","noise","luck"],a:"understanding"},
{teach:"Healthy habits support long term wellness.",q:"Healthy habits support...",c:["wellness","erosion","rust"],a:"wellness"}
]);
})();