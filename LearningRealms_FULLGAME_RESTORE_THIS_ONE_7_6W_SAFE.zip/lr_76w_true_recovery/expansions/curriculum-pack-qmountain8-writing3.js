// Question Mountain Phase 8 - Writing Deepening III
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Writing",[
{teach:"Periods end telling sentences.",q:"A telling sentence ends with...",c:[".","?","!"],a:"."},
{teach:"Names begin with capitals.",q:"Names start with...",c:["capital letters","numbers","spaces"],a:"capital letters"},
{teach:"Words make sentences.",q:"Sentences are made of...",c:["words","maps","coins"],a:"words"},
{teach:"Spaces separate words.",q:"Words are separated by...",c:["spaces","commas","titles"],a:"spaces"},
{teach:"Sentence order matters.",q:"Words should be in...",c:["order","piles","stacks"],a:"order"}
]);

LR_addLessons("Ava","Writing",[
{teach:"Paragraphs group ideas.",q:"Paragraphs group...",c:["ideas","coins","maps"],a:"ideas"},
{teach:"Examples support details.",q:"Examples help...",c:["support details","count","measure"],a:"support details"},
{teach:"Narratives have events in order.",q:"Narratives use...",c:["sequence","graphs","trade"],a:"sequence"},
{teach:"Opinion writing needs reasons.",q:"Opinions need...",c:["reasons","luck","weather"],a:"reasons"},
{teach:"Editing improves clarity.",q:"Editing improves...",c:["clarity","distance","temperature"],a:"clarity"}
]);

LR_addLessons("Michael","Writing",[
{teach:"Hooks engage readers.",q:"Hooks help...",c:["engage readers","measure slopes","count money"],a:"engage readers"},
{teach:"Body paragraphs develop ideas.",q:"Body paragraphs...",c:["develop ideas","end essays","title maps"],a:"develop ideas"},
{teach:"Transitions guide readers.",q:"Transitions help readers...",c:["follow ideas","solve equations","trade"],a:"follow ideas"},
{teach:"Conclusions reinforce points.",q:"Conclusions...",c:["reinforce ideas","start essays","hide claims"],a:"reinforce ideas"},
{teach:"Revision strengthens writing.",q:"Revision can...",c:["strengthen writing","freeze drafts","erase everything"],a:"strengthen writing"}
]);
})();