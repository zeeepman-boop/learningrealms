/* LearningRealms Master Course Adventure Integration 7.3B
   Cleans the temporary visibility buttons and integrates the emphasized courses into the adventure:
   - Great Depression and Wild West live under History and World.
   - Bible History gets its own respectful sanctuary/road, not a floating shortcut.
   - Adds tasteful Bible artifact gallery and themed menu/card colors.
   - No save reset, no home rewrite, no core engine rewrite.
*/
(function(){
  'use strict';
  if(window.__LR_MASTER_COURSE_ADVENTURE_INTEGRATION_73B__) return;
  window.__LR_MASTER_COURSE_ADVENTURE_INTEGRATION_73B__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v == null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function can(fn){ return typeof window[fn] === 'function'; }
  function call(fn){ try{ if(can(fn)) return window[fn](); }catch(e){ console.warn('LR73B call failed', fn, e); } return false; }
  function activeName(){ try{ return window.activeChild || (window.LR_STATE && LR_STATE.active && LR_STATE.active.name) || localStorage.getItem('lrActiveChild') || 'Scholar'; }catch(e){ return 'Scholar'; } }
  function getState(){ try{ if(window.state) return window.state; }catch(e){} try{ if(typeof state !== 'undefined') return state; }catch(e){} return null; }
  function stats(){ try{ if(can('renderStats')) window.renderStats(); }catch(e){} }

  function ensureMount(){
    try{ document.body.classList.add('lrDynamicAdventureMode','lr68DynamicShell','lr68bLearningTrails','lr73bIntegratedCourses'); document.body.classList.remove('homeMode'); }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var first = document.querySelector('.main > .card:first-child') || main;
    try{ if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; } if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; } }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){ mount = document.createElement('div'); mount.id='lrDynamicAdventureScreen'; mount.className='lrDynamicAdventureScreen lr68DynamicScreen lr68bTrailScreen lr73bIntegratedScreen'; if(first && first.firstChild) first.insertBefore(mount, first.firstChild); else (first || document.body).appendChild(mount); }
    mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none';
    return mount;
  }

  function cleanupForcedAccess(){
    try{
      ['lrMasterQuickDock73A','lrMasterShellPanel73','lrMasterShellPanel72A'].forEach(function(id){ var el=byId(id); if(el) el.remove(); });
      document.querySelectorAll('[data-master-visible-73a], [data-master-card-73a], .lrMasterVisibleBanner, .lrMasterLearnNote73A, .lrMasterTrailCard73A, [data-gdp71-trail], [data-ww72-trail], [data-bh73-trail]').forEach(function(el){ el.remove(); });
      var sel = byId('gameMenuSelect');
      if(sel){ ['masterCourses73A','masterGreatDepression73A','masterWildWest73A','masterBible73A'].forEach(function(v){ var opt = sel.querySelector('option[value="'+v+'"]'); if(opt) opt.remove(); }); }
    }catch(e){}
  }

  var HISTORY_MASTER_CARDS = [
    { key:'depression', theme:'lr73bHistoryCourseCard', icon:'🏚️', title:'The Great Depression History Street', meta:'History master course · economics and daily life', body:'Study the 1930s through bank trust, Dust Bowl lessons, family budgets, relief work, New Deal basics, source evidence, and resilience.', fn:'openGreatDepressionTrail', course:'openGreatDepressionCourse', reward:'openGreatDepressionRewards' },
    { key:'wildwest', theme:'lr73bFrontierCourseCard', icon:'🤠', title:'The Wild West Frontier Trail', meta:'History master course · kid-safe frontier life', body:'Study trails, homesteads, railroads, cattle drives, boomtowns, grasslands, law, myths versus evidence, and daily frontier work.', fn:'openWildWestTrail', course:'openWildWestCourse', reward:'openWildWestRewards', shop:'openWildWestShops' }
  ];

  var BIBLE_ARTIFACTS = [
    {icon:'📖', name:'Illuminated Gospel Page', type:'Scripture artifact', unlock:1, note:'A study-room display for careful reading of the Gospels.'},
    {icon:'🕯️', name:'Advent Candle Stand', type:'Church year artifact', unlock:3, note:'A simple reminder of waiting, hope, and preparation.'},
    {icon:'⭐', name:'Bethlehem Star Tile', type:'Nativity artifact', unlock:5, note:'A blue and gold floor tile for the Pilgrim Road chapel.'},
    {icon:'🪚', name:'Saint Joseph Carpenter Square', type:'Holy Family artifact', unlock:7, note:'A workshop keepsake tied to patience, work, and quiet service.'},
    {icon:'🌊', name:'Jordan River Shell', type:'Baptism artifact', unlock:10, note:'A respectful symbol for baptism and preparation.'},
    {icon:'🗝️', name:'Saint Peter Key Emblem', type:'Apostolic artifact', unlock:13, note:'A wall emblem connected to Peter, leadership, and the early Church.'},
    {icon:'🕊️', name:'Pentecost Dove Window', type:'Holy Spirit artifact', unlock:16, note:'A stained-glass style window for courage and mission.'},
    {icon:'🔔', name:'Angel Bell Tower Bell', type:'Angel artifact', unlock:19, note:'A reverent bell that reminds students angels serve God, not luck.'},
    {icon:'💙', name:'Marian Blue Mantle Pin', type:'Mary artifact', unlock:22, note:'A gentle blue keepsake honoring Mary while pointing back to Jesus.'},
    {icon:'🌹', name:'Rosary Garden Box', type:'Prayer artifact', unlock:25, note:'A quiet garden display connected to prayer and Gospel mysteries.'},
    {icon:'🍞', name:'Upper Room Table Cloth', type:'Sacrament artifact', unlock:28, note:'A respectful table covering tied to the Last Supper lesson.'},
    {icon:'🪟', name:'Seven Sacraments Window', type:'Sacrament artifact', unlock:31, note:'A seven-panel study window for initiation, healing, and service.'},
    {icon:'🪴', name:'Works of Mercy Lantern', type:'Virtue artifact', unlock:35, note:'A warm lantern for charity, service, and mercy lessons.'},
    {icon:'🌅', name:'Easter Dawn Banner', type:'Hope artifact', unlock:40, note:'A bright banner for resurrection hope, kept gentle and kid-safe.'},
    {icon:'⛪', name:'Pilgrim Cathedral Reliquary Case', type:'Final display artifact', unlock:45, note:'A respectful display case for earned course symbols, not a magic item.'}
  ];

  function bibleProgress(){
    try{
      var c = window.__LR_BIBLE_HISTORY_COURSE_73__;
      var key = 'lrBibleHistory73_' + activeName().replace(/\W+/g,'_');
      var p = JSON.parse(localStorage.getItem(key) || '{}') || {};
      var done = 0;
      if(c && c.topics) c.topics.forEach(function(t){ if(p[t.id]) done++; });
      return {done:done,total:(c && c.topics ? c.topics.length : 45)};
    }catch(e){ return {done:0,total:45}; }
  }

  function courseCard(c){
    var ready = can(c.fn);
    var bits = '<button type="button" class="lr73bOpenBtn" onclick="'+(ready ? c.fn+'()' : 'lr73bMissingCourse()')+'">Open trail</button>';
    if(c.course && can(c.course)) bits += '<button type="button" onclick="'+c.course+'()">Course map</button>';
    if(c.reward && can(c.reward)) bits += '<button type="button" onclick="'+c.reward+'()">Rewards</button>';
    if(c.shop && can(c.shop)) bits += '<button type="button" onclick="'+c.shop+'()">Shops</button>';
    return '<article class="lr73bIntegratedCard '+esc(c.theme)+'">' +
      '<div class="lr73bIntegratedIcon">'+esc(c.icon)+'</div><div><h3>'+esc(c.title)+'</h3><small>'+esc(c.meta)+'</small><p>'+esc(c.body)+'</p><div class="lr73bCardButtons">'+bits+'</div></div>' +
    '</article>';
  }

  function addBibleTab(active){
    var tabs = document.querySelector('#lrDynamicAdventureScreen .lr68bTabs') || document.querySelector('.lr68bTabs');
    if(!tabs || tabs.querySelector('[data-lr73b-bible-tab]')) return;
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('data-lr73b-bible-tab','1');
    btn.className = active ? 'active lr73bBibleTab' : 'lr73bBibleTab';
    btn.onclick = function(){ return window.lr73bOpenBiblePlace(); };
    btn.innerHTML = '<b>Bible History</b><small>Separate Pilgrim Road</small>';
    tabs.appendChild(btn);
  }

  function themeCards(){
    try{
      document.querySelectorAll('.lr68bTrailCard').forEach(function(card){
        var text = (card.textContent || '').toLowerCase();
        card.classList.add('lr73bThemedTrailCard');
        if(text.indexOf('history') >= 0 || text.indexOf('timeline') >= 0 || text.indexOf('map room') >= 0 || text.indexOf('historical') >= 0) card.classList.add('lr73bThemeHistory');
        else if(text.indexOf('reading') >= 0 || text.indexOf('story') >= 0 || text.indexOf('copywork') >= 0) card.classList.add('lr73bThemeReading');
        else if(text.indexOf('math') >= 0 || text.indexOf('number') >= 0 || text.indexOf('forge') >= 0) card.classList.add('lr73bThemeMath');
        else if(text.indexOf('science') >= 0 || text.indexOf('nature') >= 0 || text.indexOf('health') >= 0) card.classList.add('lr73bThemeScience');
        else if(text.indexOf('creative') >= 0 || text.indexOf('art') >= 0 || text.indexOf('music') >= 0 || text.indexOf('gallery') >= 0) card.classList.add('lr73bThemeCreative');
        else if(text.indexOf('civics') >= 0 || text.indexOf('geography') >= 0 || text.indexOf('merchant') >= 0 || text.indexOf('economics') >= 0) card.classList.add('lr73bThemeWorld');
        else if(text.indexOf('home') >= 0 || text.indexOf('quest') >= 0 || text.indexOf('atlas') >= 0 || text.indexOf('collection') >= 0 || text.indexOf('companion') >= 0) card.classList.add('lr73bThemeTools');
      });
    }catch(e){}
  }

  function injectHistoryShelf(section){
    cleanupForcedAccess();
    addBibleTab(false);
    themeCards();
    if(section !== 'world') return;
    var grid = document.querySelector('#lrDynamicAdventureScreen .lr68bTrailGrid') || document.querySelector('.lr68bTrailGrid');
    if(!grid || grid.querySelector('[data-lr73b-history-shelf]')) return;
    var shelf = document.createElement('section');
    shelf.className = 'lr73bHistoryShelf';
    shelf.setAttribute('data-lr73b-history-shelf','1');
    shelf.innerHTML = '<div class="lr73bShelfHead"><small>History umbrella</small><h2>History Master Courses</h2><p>The Depression and Wild West courses now live here with the other history/world trails instead of being pinned above everything.</p></div><div class="lr73bShelfGrid">' + HISTORY_MASTER_CARDS.map(courseCard).join('') + '</div>';
    grid.appendChild(shelf);
  }

  function biblePlace(){
    cleanupForcedAccess();
    var mount = ensureMount();
    var p = bibleProgress();
    mount.innerHTML =
      '<section class="lr73bBibleHero"><div class="lr73bHeroTop"><span>Separate Place</span><span>'+esc(activeName())+' · '+p.done+' / '+p.total+' mastered</span></div><h1>Bible History Pilgrim Road</h1><p>A reverent Catholic-friendly adventure area for Scripture history, Jesus, Mary, apostles, saints, angels, sacraments, symbols, feast days, mercy, and virtue. It stays separate from the ordinary History umbrella because it is part history, part theology, and part sacred formation.</p></section>' +
      '<div class="lr68bTabs lr73bBibleTabs"><button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'world\')"><b>History and world</b><small>Depression and Wild West</small></button><button type="button" class="active"><b>Bible History</b><small>Pilgrim Road</small></button><button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'featured\')"><b>Featured trails</b><small>Back to main board</small></button></div>' +
      '<section class="lr73bBibleGrid">' +
        bibleCard('🛤️','Walk Pilgrim Road','Guided adventure route','Open the full Bible History zone with rooms, lessons, quiz buttons, rewards, and review.','openBibleHistoryTrail') +
        bibleCard('📚','Open course map','Lesson library','See all Bible History lessons in the larger reading window.','openBibleHistoryCourse') +
        bibleCard('🏺','Enter the artifact hall','Respectful collectibles','View tasteful Catholic study artifacts, decor, and symbols unlocked through course progress.','openBibleHistoryArtifacts73B') +
        bibleCard('🛒','Meet shopkeepers','Pilgrim Road shops','Visit saint cards, scriptorium, stained glass, sacrament, feast day, and pilgrim outfitters shops.','openBibleHistoryShops') +
        bibleCard('🏆','Reward catalog','Earned items','Review mastered rewards from Bible History lessons.','openBibleHistoryRewards') +
        bibleCard('🔎','Review missed','Proof of reading','Go back through missed Bible History quiz questions.','openBibleHistoryReview') +
      '</section><div class="lr73bBibleFoot"><button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'world\')">History umbrella</button><button type="button" onclick="lr68bOpenLearningTrails&&lr68bOpenLearningTrails(\'featured\')">Learning Trails</button><button type="button" onclick="window.lr68OpenHome&&window.lr68OpenHome()">Home</button></div>';
    stats();
    return false;
  }

  function bibleCard(icon,title,meta,body,fn){
    return '<button type="button" class="lr73bBibleCard" onclick="'+(can(fn) ? fn+'()' : 'lr73bMissingCourse()')+'"><span class="lr73bBibleIcon">'+esc(icon)+'</span><b>'+esc(title)+'</b><small>'+esc(meta)+'</small><p>'+esc(body)+'</p><i>›</i></button>';
  }

  function artifacts(){
    var p = bibleProgress();
    var cards = BIBLE_ARTIFACTS.map(function(a){
      var unlocked = p.done >= a.unlock;
      return '<article class="lr73bArtifact '+(unlocked?'got':'locked')+'"><div class="lr73bArtifactIcon">'+esc(unlocked ? a.icon : '🔒')+'</div><h3>'+esc(a.name)+'</h3><small>'+esc(a.type)+'</small><p>'+esc(a.note)+'</p><em>'+(unlocked ? 'Unlocked' : 'Unlocks after '+a.unlock+' Bible History lesson masteries')+'</em></article>';
    }).join('');
    var html = '<div class="lr73bArtifactShell"><section class="lr73bArtifactHero"><small>Respectful artifact hall</small><h2>Bible History Study Artifacts</h2><p>These are treated as study-room displays, chapel decor, wearable badges, and memory symbols. They are not magic items, lucky charms, or jokes. Each one points back to Scripture, Catholic worship, virtue, prayer, or careful learning.</p><p><b>Progress:</b> '+p.done+' / '+p.total+' Bible History lessons mastered.</p><div><button type="button" onclick="openBibleHistoryTrail&&openBibleHistoryTrail()">Pilgrim Road</button><button type="button" onclick="openBibleHistoryRewards&&openBibleHistoryRewards()">Rewards</button><button type="button" onclick="openBibleHistoryShops&&openBibleHistoryShops()">Shops</button><button type="button" onclick="lr73bOpenBiblePlace()">Bible place</button></div></section><section class="lr73bArtifactGrid">'+cards+'</section></div>';
    if(can('lrOpenPopup')) return window.lrOpenPopup('🏺 Bible History Artifact Hall', html);
    var mount = ensureMount(); mount.innerHTML = html; return false;
  }

  function decorateBibleScreens(){
    try{
      var foot = document.querySelector('.bhTrailFoot');
      if(foot && !foot.querySelector('[data-lr73b-artifact-button]')){
        var b = document.createElement('button'); b.type='button'; b.setAttribute('data-lr73b-artifact-button','1'); b.textContent='Artifact hall'; b.onclick=function(){ return window.openBibleHistoryArtifacts73B(); }; foot.insertBefore(b, foot.children[2] || null);
      }
      var heroBtns = document.querySelector('.bhHeroBtns');
      if(heroBtns && !heroBtns.querySelector('[data-lr73b-artifact-button]')){
        var hb = document.createElement('button'); hb.type='button'; hb.setAttribute('data-lr73b-artifact-button','1'); hb.textContent='Artifact hall'; hb.onclick=function(){ return window.openBibleHistoryArtifacts73B(); }; heroBtns.appendChild(hb);
      }
    }catch(e){}
  }

  function wrapLearningTrails(){
    try{
      var old = window.lr68bOpenLearningTrails;
      if(typeof old === 'function' && !old.__lr73bIntegrated){
        var repl = function(section){
          var chosen = section || 'featured';
          var out = old.apply(this, arguments);
          [60,180,420,850].forEach(function(ms){ setTimeout(function(){ injectHistoryShelf(chosen); }, ms); });
          return out;
        };
        repl.__lr73bIntegrated = true;
        repl.__old = old;
        window.lr68bOpenLearningTrails = repl;
        try{ lr68bOpenLearningTrails = repl; }catch(e){}
      }
      window.lr68OpenLearn = function(){ return window.lr68bOpenLearningTrails ? window.lr68bOpenLearningTrails('featured') : false; };
      try{ lr68OpenLearn = window.lr68OpenLearn; }catch(e){}
      window.lrHardLesson = window.lr68OpenLearn;
      try{ lrHardLesson = window.lrHardLesson; }catch(e){}
    }catch(e){}
  }

  function wrapBibleFunctions(){
    ['openBibleHistoryTrail','openBibleHistoryCourse','openBibleHistoryRewards','openBibleHistoryShops'].forEach(function(fn){
      try{
        var old = window[fn];
        if(typeof old === 'function' && !old.__lr73bArtifactDecorated){
          var repl = function(){ var out = old.apply(this, arguments); [80,220,500].forEach(function(ms){ setTimeout(decorateBibleScreens, ms); }); return out; };
          repl.__lr73bArtifactDecorated = true;
          repl.__old = old;
          window[fn] = repl;
          try{ eval(fn+' = window[fn];'); }catch(e){}
        }
      }catch(e){}
    });
  }

  function styles(){
    if(byId('lr73bIntegratedStyles')) return;
    var st = document.createElement('style'); st.id='lr73bIntegratedStyles';
    st.textContent = `
      #lrMasterQuickDock73A,.lrMasterVisibleBanner,.lrMasterLearnNote73A,.lrMasterTrailCard73A,#lrMasterShellPanel73,#lrMasterShellPanel72A{display:none!important;visibility:hidden!important;pointer-events:none!important;}
      .lr73bHistoryShelf{grid-column:1/-1;display:block;margin:6px 0 0;padding:18px;border-radius:24px;background:linear-gradient(135deg,#f4e2bf,#fff9e7 46%,#e8f1ee);border:2px solid rgba(93,68,31,.22);box-shadow:0 12px 24px rgba(48,37,19,.14)}
      .lr73bShelfHead small,.lr73bBibleHero .lr73bHeroTop,.lr73bArtifactHero small{font-weight:950;text-transform:uppercase;letter-spacing:.08em;color:#8c6721}.lr73bShelfHead h2{margin:.15rem 0 .25rem;color:#2d271e}.lr73bShelfHead p{margin:.2rem 0 1rem;color:#514636;font-weight:760;line-height:1.45}.lr73bShelfGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:13px}
      .lr73bIntegratedCard{display:grid;grid-template-columns:auto 1fr;gap:13px;min-height:165px;border-radius:20px;padding:15px;border:1px solid rgba(55,42,22,.22);box-shadow:0 9px 18px rgba(0,0,0,.12)}.lr73bIntegratedCard h3{margin:.05rem 0 .25rem;color:#2a2117}.lr73bIntegratedCard small{display:block;font-weight:950;text-transform:uppercase;letter-spacing:.04em;font-size:.72rem}.lr73bIntegratedCard p{font-weight:760;line-height:1.38;margin:.45rem 0;color:#4c4334}.lr73bIntegratedIcon{font-size:2rem;line-height:1}.lr73bHistoryCourseCard{background:linear-gradient(135deg,#fff6da,#f2ddad)}.lr73bFrontierCourseCard{background:linear-gradient(135deg,#fff0cf,#dcedd2)}.lr73bHistoryCourseCard small{color:#735008}.lr73bFrontierCourseCard small{color:#5f6817}.lr73bCardButtons{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.lr73bCardButtons button,.lr73bBibleFoot button,.lr73bArtifactHero button{border:1px solid rgba(64,50,25,.26);background:#fffdf3;color:#252015;border-radius:999px;padding:9px 11px;font-weight:900;cursor:pointer}.lr73bOpenBtn{background:#2d2419!important;color:#fff4cf!important;border-color:#e5bd59!important}
      .lr73bThemedTrailCard{overflow:hidden;position:relative}.lr73bThemedTrailCard:before{content:'';position:absolute;left:0;top:0;bottom:0;width:8px}.lr73bThemeHistory{background:linear-gradient(135deg,#fff6df,#f5e5c2)!important}.lr73bThemeHistory:before{background:#8b6422}.lr73bThemeReading{background:linear-gradient(135deg,#eef8ff,#fffdf0)!important}.lr73bThemeReading:before{background:#477ca4}.lr73bThemeMath{background:linear-gradient(135deg,#f1f0ff,#fffaf0)!important}.lr73bThemeMath:before{background:#6857c2}.lr73bThemeScience{background:linear-gradient(135deg,#ecfff1,#eff8ff)!important}.lr73bThemeScience:before{background:#32835b}.lr73bThemeCreative{background:linear-gradient(135deg,#fff0fb,#f1efff)!important}.lr73bThemeCreative:before{background:#9a5aa7}.lr73bThemeWorld{background:linear-gradient(135deg,#edf7ff,#fff9e7)!important}.lr73bThemeWorld:before{background:#2e778e}.lr73bThemeTools{background:linear-gradient(135deg,#f5f5f5,#fff8df)!important}.lr73bThemeTools:before{background:#77746b}
      .lr73bBibleTab{background:linear-gradient(135deg,#f2edff,#fff4ca)!important;color:#221b56!important;border-color:#dac072!important}.lr73bBibleHero{padding:30px 34px 24px;border-radius:24px 24px 0 0;background:linear-gradient(135deg,#211a52,#493c91 54%,#b48b2b);color:#fff9e8;box-shadow:inset 0 -1px 0 rgba(255,255,255,.08)}.lr73bBibleHero h1{margin:12px 0 10px;font-size:clamp(1.9rem,3.1vw,2.85rem);line-height:1.05}.lr73bBibleHero p{max-width:980px;line-height:1.55;font-weight:760;color:#fffdf0}.lr73bHeroTop{display:flex;justify-content:space-between;gap:12px}.lr73bBibleGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:13px;padding:20px;background:linear-gradient(180deg,#fff8dc,#f2f0ff)}.lr73bBibleCard{min-height:170px;position:relative;text-align:left;border:1px solid rgba(82,53,24,.22);border-radius:20px;background:#fffefa;color:#252236;padding:15px;box-shadow:0 10px 18px rgba(0,0,0,.13);cursor:pointer}.lr73bBibleCard b{display:block;font-size:1.08rem;line-height:1.25;color:#252236}.lr73bBibleCard small{display:block;margin-top:5px;font-weight:950;color:#6651c9;text-transform:uppercase;letter-spacing:.04em;font-size:.73rem}.lr73bBibleCard p{margin:8px 24px 0 0;color:#4b485e;font-weight:740;line-height:1.36}.lr73bBibleCard i{position:absolute;right:14px;bottom:12px;font-style:normal;font-size:2.2rem;color:#9a7420;font-weight:900}.lr73bBibleIcon{display:block;font-size:1.8rem;margin-bottom:8px}.lr73bBibleFoot{display:flex;flex-wrap:wrap;gap:10px;padding:16px 20px;background:#211a52;border-radius:0 0 22px 22px}.lr73bBibleTabs .active{background:#fff4d2!important;color:#211a52!important}
      .lr73bArtifactShell{color:#252236}.lr73bArtifactHero{padding:16px;border-radius:18px;background:linear-gradient(135deg,#f2edff,#fff8de 48%,#eaf6ff);border:2px solid rgba(67,55,117,.22);margin-bottom:13px}.lr73bArtifactHero h2{margin:.1rem 0 .4rem}.lr73bArtifactHero p{line-height:1.55;font-weight:740}.lr73bArtifactHero div{display:flex;flex-wrap:wrap;gap:8px}.lr73bArtifactGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.lr73bArtifact{border-radius:18px;padding:14px;border:1px solid rgba(58,52,85,.18);background:#fffefa;box-shadow:0 4px 12px rgba(0,0,0,.08)}.lr73bArtifact.got{background:linear-gradient(135deg,#fff8dc,#f3f0ff);border-color:#b99b35}.lr73bArtifact.locked{opacity:.72;background:#f5f3fb}.lr73bArtifactIcon{font-size:1.8rem}.lr73bArtifact h3{margin:.3rem 0 .15rem}.lr73bArtifact small{display:block;color:#6651c9;font-weight:950;text-transform:uppercase;font-size:.7rem}.lr73bArtifact p{line-height:1.42;font-weight:720;color:#4b485e}.lr73bArtifact em{display:inline-block;font-style:normal;border-radius:999px;background:#fff1b8;padding:5px 8px;font-weight:900;color:#4c3b14}
      @media(max-width:760px){.lr73bIntegratedCard{grid-template-columns:1fr}.lr73bBibleGrid,.lr73bArtifactGrid,.lr73bShelfGrid{grid-template-columns:1fr}.lr73bHeroTop{flex-direction:column}.lr73bBibleHero{padding:24px 18px 20px}.lr73bHistoryShelf{padding:14px}}
    `;
    document.head.appendChild(st);
  }

  function missing(){
    var mount = ensureMount();
    mount.insertAdjacentHTML('afterbegin','<div class="lr73bMissing">That course file is not loaded yet. Reopen the newest 7.3B build.</div>');
    return false;
  }

  function boot(){
    styles(); cleanupForcedAccess(); wrapLearningTrails(); wrapBibleFunctions();
    window.lr73bOpenBiblePlace = biblePlace;
    window.openBibleHistoryArtifacts73B = artifacts;
    window.lr73bMissingCourse = missing;
    setTimeout(function(){ cleanupForcedAccess(); addBibleTab(false); themeCards(); }, 250);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ boot(); [500,1300,2600].forEach(function(ms){ setTimeout(function(){ cleanupForcedAccess(); addBibleTab(false); themeCards(); }, ms); }); });
})();
