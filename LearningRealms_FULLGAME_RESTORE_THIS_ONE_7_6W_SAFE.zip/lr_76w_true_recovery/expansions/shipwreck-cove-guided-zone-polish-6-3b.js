/* Shipwreck Cove Guided Zone Polish 6.3B
   Safe patch on top of 6.3A: readability, room polish, clearer tour buttons, and no shell replacement.
*/
(function(){
  'use strict';
  if(window.__LR_SHIPWRECK_COVE_POLISH_63B__) return;
  window.__LR_SHIPWRECK_COVE_POLISH_63B__ = true;
  function byId(id){ return document.getElementById(id); }
  function install(){
    if(!byId('swczPolish63bStyles')){
      var st=document.createElement('style'); st.id='swczPolish63bStyles';
      st.textContent=[
        '.swczCShell{color:#172a36 !important;font-size:15.5px;line-height:1.48}',
        '.swczCModal{background:#fffaf0 !important;color:#172a36 !important}',
        '.swczCHero{background:linear-gradient(135deg,#d9eff8,#fff1c9) !important;border-color:rgba(21,74,96,.36) !important;box-shadow:0 12px 28px rgba(15,44,62,.18) !important}',
        '.swczCHero p,.swczCCard p,.swczCMapCard p{color:#172a36 !important}',
        '.swczCCard,.swczCTopic,.swczCMapCard{background:#fffaf0 !important;border-color:rgba(37,77,95,.28) !important;box-shadow:0 5px 14px rgba(18,45,58,.10) !important}',
        '.swczCCard h3,.swczCMapCard h3,.swczCHero h2{color:#123345 !important}',
        '.swczCHeroBtns button.swczCPrimary,.swczCPrimary,button.swczCPrimary{background:#174f67 !important;color:#ffffff !important;border-color:#0c2f40 !important;text-shadow:0 1px 1px rgba(0,0,0,.35) !important;box-shadow:0 4px 11px rgba(0,0,0,.22) !important}',
        '.swczCHeroBtns button:not(.swczCPrimary),.swczCNav button:not(.swczCPrimary),.swczCExits button:not(.swczCPrimary),.swczCTopic button:not(.swczCPrimary),.swczCCard button:not(.swczCPrimary),.swczCMapCard button:not(.swczCPrimary),.swczCChooser button:not(.swczCPrimary){background:#fffdf8 !important;color:#143244 !important;border-color:rgba(31,71,91,.42) !important}',
        '.swczCLocked{opacity:.72 !important;background:#ece6db !important;color:#44535b !important}',
        '.swczCBar{background:#c8d9df !important;border:1px solid rgba(20,65,82,.12)}',
        '.swczCBar i{background:#176b82 !important}',
        '.swczCHead{background:#ead9b4 !important;color:#143244 !important}',
        '.swczCChooser{background:linear-gradient(135deg,#d9eff8,#fff1c9) !important;color:#143244 !important}',
        '.swczCTourHint{display:block;margin-top:10px;padding:10px 12px;border-radius:12px;background:#eaf6fb;border:1px solid rgba(23,79,103,.25);color:#143244;font-weight:700}'
      ].join('\n');
      document.head.appendChild(st);
    }
    polishOpenModal();
  }
  function polishOpenModal(){
    try{
      var modal=document.querySelector('.swczCModal .swczCShell, #lrPopupBody .swczCShell, #actionText .swczCShell');
      if(!modal || modal.querySelector('.swczCTourHint')) return;
      var hero=modal.querySelector('.swczCHero');
      var primary=hero && hero.querySelector('.swczCHeroBtns .swczCPrimary');
      if(hero && primary){
        var hint=document.createElement('div');
        hint.className='swczCTourHint';
        hint.textContent='Tour tip: follow the anchor lesson in each room to unlock the next stop. Extra exhibit lessons can be explored any time after the room opens.';
        hero.appendChild(hint);
      }
    }catch(e){}
  }
  function wrap(fnName){
    if(typeof window[fnName] !== 'function' || window[fnName].__swczPolish63b) return;
    var old=window[fnName];
    var repl=function(){ var out=old.apply(this, arguments); setTimeout(install,10); setTimeout(install,80); return out; };
    repl.__swczPolish63b=true; window[fnName]=repl;
  }
  function boot(){
    install();
    ['shipwreckGuidedZoneOpen','shipwreckGuidedZoneContinue','shipwreckGuidedZoneTalk','shipwreckGuidedZoneMap','shipwreckGuidedZoneMove'].forEach(wrap);
  }
  boot();
  window.addEventListener('load', function(){ setTimeout(boot,100); setTimeout(boot,500); setTimeout(boot,1200); });
})();
