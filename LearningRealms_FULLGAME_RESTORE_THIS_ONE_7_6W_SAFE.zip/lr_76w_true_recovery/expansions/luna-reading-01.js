LR_addLessons("Luna","Reading",[
 {teach:"SH says /sh/ like shell.",practice:"ship, shell, fish",q:"Which begins with SH?",c:["ship","cat","log"],a:"ship"},
 {teach:"CH says /ch/ like chair.",practice:"chair, cheese, chin",q:"Which starts with CH?",c:["chair","fish","sun"],a:"chair"},
 {teach:"TH says /th/ like thumb.",practice:"thumb, thin, bath",q:"Which starts with TH?",c:["thumb","ship","cat"],a:"thumb"}
]);
LR_addLessons("Luna","English",[
 {teach:"A sentence begins with a capital letter.",practice:"dog runs → Dog runs.",q:"Which starts correctly?",c:["Dog runs","dog runs","dog Runs"],a:"Dog runs"},
 {teach:"A noun names a person, place, thing, or animal.",practice:"Bridge is a thing.",q:"Which is a noun?",c:["bridge","quickly","under"],a:"bridge"}
]);
LR_addLessons("Luna","Math",[
 {teach:"10 + 5 = 15.",practice:"Count ten blocks, then five more.",q:"10 + 5 = ?",c:["15","12","14"],a:"15"},
 {teach:"A dime is 10 cents.",practice:"One dime = 10.",q:"How much is a dime?",c:["10","5","25"],a:"10"}
]);
LR_addLessons("Luna","Science",[
 {teach:"Plants need sunlight.",practice:"A plant grows toward the sun.",q:"What helps plants grow?",c:["sunlight","rocks","paint"],a:"sunlight"}
]);
