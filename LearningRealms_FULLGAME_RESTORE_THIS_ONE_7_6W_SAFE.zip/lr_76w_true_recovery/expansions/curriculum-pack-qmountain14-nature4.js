// Question Mountain Phase 14 - Nature Deepening IV
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Nature",[
{teach:"Flowers can make seeds.",q:"Flowers may help make...",c:["seeds","maps","coins"],a:"seeds"},
{teach:"Fish live in water.",q:"Fish live in...",c:["water","trees","clouds"],a:"water"},
{teach:"Day and night repeat.",q:"Day and night...",c:["repeat","freeze","hide"],a:"repeat"},
{teach:"Soil helps plants grow.",q:"Plants grow in...",c:["soil","paper","books"],a:"soil"},
{teach:"Many animals need shelter.",q:"Animals need...",c:["shelter","titles","graphs"],a:"shelter"}
]);

LR_addLessons("Ava","Nature",[
{teach:"Evaporation moves water into air.",q:"Evaporation moves...",c:["water","coins","stories"],a:"water"},
{teach:"Consumers depend on producers.",q:"Consumers depend on...",c:["producers","maps","trade"],a:"producers"},
{teach:"Habitats can change.",q:"Habitats may...",c:["change","sleep","freeze"],a:"change"},
{teach:"Weather forecasts use data.",q:"Forecasts use...",c:["data","luck","titles"],a:"data"},
{teach:"Rest helps health.",q:"Rest supports...",c:["health","geometry","trade"],a:"health"}
]);

LR_addLessons("Michael","Nature",[
{teach:"Erosion moves soil and rock.",q:"Erosion moves...",c:["soil and rock","fonts","coins"],a:"soil and rock"},
{teach:"Cycles repeat in nature.",q:"Natural cycles...",c:["repeat","stop","hide"],a:"repeat"},
{teach:"Energy flows through ecosystems.",q:"Ecosystems transfer...",c:["energy","titles","maps"],a:"energy"},
{teach:"Species interact in ecosystems.",q:"Species can...",c:["interact","sleep","freeze"],a:"interact"},
{teach:"Conservation supports habitats.",q:"Conservation helps...",c:["habitats","equations","covers"],a:"habitats"}
]);
})();