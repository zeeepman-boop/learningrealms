/* LearningRealms Stable Adventure Navigation 7.3M
   Safe recovery after the broken 7.3L branch.
   This file does NOT use a render interval, does NOT replace the whole app, and does NOT touch saves or lesson data.
   It adds one stable RPG layout layer, restores icon-heavy player/command panels, and routes buttons through guarded calls.
*/
(function(){
  'use strict';
  if(window.__LR73M_STABLE_NAV__) return;
  window.__LR73M_STABLE_NAV__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel){ return document.querySelector(sel); }
  function qa(sel){ return Array.prototype.slice.call(document.querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function safe(fn){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); afterAction(); return true; }
    catch(e){ console.warn('LR73M guarded action failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var x = list[i];
      if(Array.isArray(x)){ if(safe.apply(null,x)) return true; }
      else if(safe(x)) return true;
    }
    return false;
  }
  function stateObj(){ try{ return window.state || state || {}; }catch(e){ return {}; } }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    var s = byId('studentSelect');
    if(s && s.value) return s.value;
    try{ return localStorage.getItem('lrActiveChild') || 'Michael'; }catch(e){}
    return 'Michael';
  }
  function avatarFor(name){
    name = String(name || '').toLowerCase();
    if(name.indexOf('michael') >= 0) return '🛡️';
    if(name.indexOf('ava') >= 0) return '🌺';
    if(name.indexOf('luna') >= 0) return '🌙';
    return '🧭';
  }
  function titleFor(name){
    name = String(name || '').toLowerCase();
    if(name.indexOf('michael') >= 0) return 'Shieldbearer Scholar';
    if(name.indexOf('ava') >= 0) return 'Pathfinder Scholar';
    if(name.indexOf('luna') >= 0) return 'Moonlit Reader';
    return 'Realm Adventurer';
  }
  function textFrom(id, fallback){
    var el = byId(id);
    var t = el && el.textContent ? el.textContent.replace(/\s+/g,' ').trim() : '';
    return t || fallback || '';
  }
  function sceneName(){
    var h = q('#lrDynamicAdventureScreen h1');
    if(h && h.textContent.trim()) return h.textContent.replace(/\s+/g,' ').trim();
    return textFrom('roomTitle','Home Hearth');
  }
  function statLine(){
    var s = stateObj();
    var room = textFrom('roomNumber', s.room || '1');
    var sparks = textFrom('sparks', s.sparks || '0');
    var streak = textFrom('streak', s.streak || '0');
    return 'Room ' + room + ' · ' + sparks + ' Sparks · Streak ' + streak;
  }
  function afterAction(){
    setTimeout(refreshChrome, 60);
    setTimeout(refreshChrome, 260);
  }

  function installStyles(){
    if(byId('lr73mStableStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr73mStableStyles';
    st.textContent = `
      body.lr73mStable{background:radial-gradient(circle at 8% 0%,rgba(255,218,126,.22),transparent 32%),radial-gradient(circle at 94% 4%,rgba(93,168,139,.18),transparent 33%),linear-gradient(180deg,#06110f,#0b211d 48%,#071412)!important;color:#fff0c1!important;}
      body.lr73mStable .shell{width:min(1780px,98vw)!important;max-width:1780px!important;margin:0 auto!important;padding:10px 14px 28px!important;background:linear-gradient(180deg,rgba(255,231,160,.055),rgba(255,255,255,.018))!important;border-left:1px solid rgba(255,224,147,.16)!important;border-right:1px solid rgba(255,224,147,.16)!important;box-shadow:0 0 80px rgba(0,0,0,.34)!important;}
      body.lr73mStable .compactHeader{display:grid!important;visibility:visible!important;opacity:1!important;height:auto!important;min-height:70px!important;margin:0 0 12px!important;padding:10px 12px!important;grid-template-columns:auto minmax(210px,1fr) auto!important;align-items:center!important;gap:12px!important;border:2px solid rgba(245,223,154,.32)!important;border-radius:16px!important;background:linear-gradient(135deg,#1b433a,#071716 55%,#352713)!important;box-shadow:0 12px 28px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.08)!important;overflow:visible!important;}
      body.lr73mStable .lr73mHeaderRune{width:54px;height:54px;border-radius:14px;display:grid;place-items:center;background:radial-gradient(circle at 35% 20%,#fff5b8,#e0b24b 48%,#5c3c11);font-size:1.9rem;box-shadow:0 8px 18px rgba(0,0,0,.35),inset 0 0 0 2px rgba(255,255,255,.22)}
      body.lr73mStable .lr73mBrand b{display:block;color:#fff4c5!important;font-size:1.35rem;line-height:1}.lr73mBrand small{display:block;color:#cce6d8!important;font-weight:850;margin-top:4px;line-height:1.2}.lr73mTopNav{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:7px}.lr73mTopNav button{border:1px solid rgba(255,229,151,.38);border-radius:999px;background:linear-gradient(180deg,#fff7d8,#d1a04a);color:#211506;font-weight:1000;padding:8px 10px;box-shadow:0 5px 10px rgba(0,0,0,.24);cursor:pointer;}
      @media(min-width:1050px){body.lr73mStable .shell>main{display:grid!important;grid-template-columns:300px minmax(610px,1fr) 340px!important;grid-template-areas:'player scene records' 'commands scene records'!important;gap:14px!important;align-items:start!important;width:100%!important;max-width:none!important;margin-top:0!important;}body.lr73mStable .shell>main>.playerSidebar{grid-area:player!important;}body.lr73mStable .shell>main>.actionSidebar{grid-area:commands!important;}body.lr73mStable .shell>main>section.main{grid-area:scene!important;}body.lr73mStable .shell>main>.rightSidebar{grid-area:records!important;}}
      body.lr73mStable .shell>main>.playerSidebar,body.lr73mStable .shell>main>.actionSidebar,body.lr73mStable .shell>main>.rightSidebar,body.lr73mStable .shell>main>section.main{display:block!important;visibility:visible!important;opacity:1!important;min-width:0!important;max-width:none!important;position:relative!important;top:auto!important;left:auto!important;right:auto!important;transform:none!important;width:auto!important;}
      body.lr73mStable .card,body.lr73mStable .playerSidebar,body.lr73mStable .rightInfoCard,body.lr73mStable .actionSidebar{border-radius:14px!important;border:1px solid rgba(245,223,154,.26)!important;background:linear-gradient(180deg,rgba(22,49,43,.96),rgba(7,20,18,.98))!important;box-shadow:0 12px 28px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.06)!important;color:#fff0c2!important;overflow:hidden!important;}
      body.lr73mStable .main>.card:first-child{padding:0!important;overflow:hidden!important;}body.lr73mStable .main>.card:nth-child(2){margin-top:12px!important;}
      body.lr73mStable .lr73iWindowLabel,body.lr73mStable .lr73mWindowLabel{display:block!important;margin:0!important;padding:6px 10px!important;border-radius:0!important;border:0!important;border-bottom:1px solid rgba(245,223,154,.18)!important;background:linear-gradient(180deg,rgba(255,226,143,.12),rgba(0,0,0,.04))!important;color:#ffe5a0!important;font-size:.68rem!important;text-transform:uppercase!important;letter-spacing:.10em!important;font-weight:1000!important;text-align:center!important;}
      body.lr73mStable .playerSidebar h2,body.lr73mStable .actionSidebar h2,body.lr73mStable .rightInfoCard h2{color:#fff2bd!important;margin:10px 12px 8px!important;}
      body.lr73mStable .lr73mPlayerDeck{margin:8px 10px 10px;padding:10px;border:1px solid rgba(245,223,154,.18);border-radius:12px;background:rgba(0,0,0,.20)}.lr73mPlayerHero{display:grid;grid-template-columns:52px 1fr;gap:10px;align-items:center;margin-bottom:9px}.lr73mAvatar{width:52px;height:52px;border-radius:12px;display:grid;place-items:center;background:radial-gradient(circle at 32% 20%,#fff6c5,#e1b350 50%,#5b3b10);font-size:1.8rem;box-shadow:0 6px 12px rgba(0,0,0,.3)}.lr73mPlayerHero b{display:block;color:#fff5cb;font-size:1.05rem}.lr73mPlayerHero small{display:block;color:#cde6d8;font-weight:850;line-height:1.2}.lr73mIconStats{display:grid;grid-template-columns:1fr 1fr;gap:6px}.lr73mIconStat{display:grid;grid-template-columns:25px 1fr;gap:5px;align-items:center;border:1px solid rgba(245,223,154,.14);border-radius:9px;background:rgba(0,0,0,.18);padding:6px}.lr73mIconStat span{text-align:center}.lr73mIconStat b{display:block;color:#ffe9a8;font-size:.82rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.lr73mIconStat small{display:block;color:#bad7c9;font-size:.65rem;font-weight:900;text-transform:uppercase}.lr73mIconRack{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-top:8px}.lr73mIconRack button{height:38px!important;padding:0!important;display:grid!important;place-items:center!important;border-radius:8px!important;background:linear-gradient(180deg,#183530,#081816)!important;color:#fff0bd!important;border:1px solid rgba(245,223,154,.24)!important;font-size:1.15rem!important;}
      body.lr73mStable .sideControls{display:grid!important;gap:7px!important;margin:10px!important;padding-top:8px!important;border-top:1px solid rgba(245,223,154,.15)!important}.sideControls label{display:grid!important;gap:4px!important;color:#ffe5a0!important;font-weight:950!important;font-size:.73rem!important;text-transform:uppercase!important;letter-spacing:.06em!important}body.lr73mStable select{width:100%!important;border-radius:7px!important;border:1px solid rgba(245,223,154,.38)!important;background:#f5e5b5!important;color:#1d1307!important;padding:7px!important;font-weight:900!important}body.lr73mStable .sideControls button{border-radius:8px!important;padding:8px!important;background:linear-gradient(180deg,#f3e4b4,#a6ba78)!important;color:#1d1307!important;font-weight:1000!important;}
      body.lr73mStable #leftActionButtons{display:grid!important;visibility:visible!important;opacity:1!important;height:auto!important;max-height:none!important;overflow:visible!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:7px!important;margin:8px 10px 10px!important;align-items:stretch!important}.lr73mCommandBtn{min-height:55px!important;display:grid!important;grid-template-rows:auto auto!important;place-items:center!important;text-align:center!important;gap:2px!important;border-radius:10px!important;border:1px solid rgba(245,223,154,.28)!important;background:linear-gradient(180deg,#f7e8b7,#c9973f)!important;color:#1a1006!important;font-weight:1000!important;box-shadow:0 5px 10px rgba(0,0,0,.22)!important;cursor:pointer!important}.lr73mCommandBtn span{font-size:1.35rem;line-height:1}.lr73mCommandBtn b{font-size:.74rem;line-height:1.05}.lr73mCommandBtn.primary{grid-column:1 / -1;background:linear-gradient(180deg,#fff3c3,#d4a14a)!important;}
      body.lr73mStable #lrDynamicAdventureScreen{display:block!important;visibility:visible!important;opacity:1!important;width:100%!important;max-width:none!important;min-height:520px!important;border-radius:0!important;border:0!important;background:linear-gradient(180deg,#0d2320,#071614)!important;box-shadow:none!important;overflow:hidden!important}.lr73mHero{padding:22px 24px 18px;background:radial-gradient(circle at 7% 0%,rgba(255,222,137,.18),transparent 36%),linear-gradient(135deg,#1c4a3f,#0b1918 58%,#392a14);border-bottom:1px solid rgba(245,223,154,.22)}.lr73mHero small{display:block;color:#ffe5a0;font-weight:1000;text-transform:uppercase;letter-spacing:.11em}.lr73mHero h1{margin:6px 0 8px;color:#fff5c8!important;font-size:clamp(1.7rem,2.2vw,2.4rem);line-height:1.05;text-shadow:0 2px 0 rgba(0,0,0,.45)}.lr73mHero p{margin:0;color:#e5f0d7!important;line-height:1.45;max-width:900px;font-weight:760}.lr73mChoiceGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;padding:17px}.lr73mChoice{display:grid!important;grid-template-columns:44px 1fr!important;gap:10px!important;align-items:center!important;text-align:left!important;min-height:86px!important;padding:11px!important;border-radius:13px!important;border:1px solid rgba(245,223,154,.36)!important;background:linear-gradient(135deg,#fff8df,#ead19b 62%,#d9eadb)!important;color:#211506!important;box-shadow:0 8px 16px rgba(0,0,0,.24)!important;cursor:pointer!important}.lr73mChoice span{width:42px;height:42px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(180deg,#1d4038,#0a1d1a);font-size:1.4rem;color:#ffe3a0}.lr73mChoice b{display:block;color:#221505!important;font-size:.98rem}.lr73mChoice small{display:block;color:#4a391c!important;font-weight:850;line-height:1.25}.lr73mFooter{display:flex;flex-wrap:wrap;gap:8px;padding:0 17px 17px}.lr73mFooter button{border-radius:999px!important;background:linear-gradient(180deg,#fff2bd,#c9963f)!important;color:#1b1006!important;font-weight:1000!important;border:1px solid rgba(245,223,154,.38)!important;padding:8px 11px!important;}
      body.lr73mStable .rightInfoPicker,body.lr73mStable .rightInfoPanel{margin:8px 10px!important}body.lr73mStable .rightInfoPanel{max-height:58vh!important;overflow:auto!important}.lr73mLedger{margin:8px 10px 10px;padding:10px;border:1px solid rgba(245,223,154,.17);border-radius:12px;background:rgba(0,0,0,.18)}.lr73mLedger b{display:block;color:#fff0bd;margin-bottom:4px}.lr73mLedger small{display:block;color:#cfe3d4;font-weight:850;line-height:1.25}.lr73mLedgerBtns{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px}.lr73mLedgerBtns button{border-radius:8px!important;padding:7px!important;font-weight:950!important;}
      @media(max-width:1049px){body.lr73mStable .shell>main{display:block!important}body.lr73mStable .playerSidebar,body.lr73mStable .actionSidebar,body.lr73mStable .rightSidebar,body.lr73mStable section.main{margin-bottom:12px!important}.lr73mTopNav{grid-column:1 / -1;justify-content:flex-start}.lr73mChoiceGrid{grid-template-columns:1fr!important}}
    `;
    document.head.appendChild(st);
  }

  function clearOldDamage(){
    try{ if(window.__LR68C_WATCHDOG_TIMER__){ clearInterval(window.__LR68C_WATCHDOG_TIMER__); window.__LR68C_WATCHDOG_TIMER__ = null; } }catch(e){}
    try{ document.body.classList.remove('lr68cInterfaceCleanup'); }catch(e){}
    qa('[data-lr63c-hidden-duplicate-golearn], .lrNukeOldButton').forEach(function(el){
      try{ el.style.display=''; el.style.visibility=''; el.style.opacity=''; el.classList.remove('lrNukeOldButton'); }catch(e){}
    });
    try{ var clean = byId('lrCleanGameShell'); if(clean) clean.remove(); }catch(e){}
  }

  function setLabel(el, text){
    if(!el) return;
    var label = el.querySelector(':scope > .lr73mWindowLabel, :scope > .lr73iWindowLabel');
    if(!label){ label = document.createElement('div'); label.className='lr73mWindowLabel'; el.insertBefore(label, el.firstChild); }
    label.className = 'lr73mWindowLabel';
    label.textContent = text;
  }
  function refreshHeader(){
    var h = q('.compactHeader'); if(!h) return;
    var name = activeName();
    h.innerHTML = '<div class="lr73mHeaderRune">'+esc(avatarFor(name))+'</div>'+ 
      '<div class="lr73mBrand"><b>LearningRealms</b><small>'+esc(sceneName())+' · '+esc(statLine())+'</small></div>'+ 
      '<nav class="lr73mTopNav">'+
        '<button type="button" data-lr73m-act="scene">Scene</button>'+ 
        '<button type="button" data-lr73m-act="map">Realm Map</button>'+ 
        '<button type="button" data-lr73m-act="learn">Go Learn</button>'+ 
        '<button type="button" data-lr73m-act="history">History Wing</button>'+ 
        '<button type="button" data-lr73m-act="bible">Bible Road</button>'+ 
        '<button type="button" data-lr73m-act="home">Home</button>'+ 
      '</nav>';
  }
  function refreshPlayer(){
    var box = q('.playerSidebar'); if(!box) return;
    setLabel(box, 'Player Sheet');
    var name = activeName();
    var html = '<div class="lr73mPlayerHero"><div class="lr73mAvatar">'+esc(avatarFor(name))+'</div><div><b>'+esc(name)+'</b><small>'+esc(titleFor(name))+'<br>'+esc(sceneName())+'</small></div></div>'+ 
      '<div class="lr73mIconStats">'+
        '<div class="lr73mIconStat"><span>🚪</span><div><b>'+esc(textFrom('roomNumber','1'))+'</b><small>Room</small></div></div>'+ 
        '<div class="lr73mIconStat"><span>✨</span><div><b>'+esc(textFrom('sparks','0'))+'</b><small>Sparks</small></div></div>'+ 
        '<div class="lr73mIconStat"><span>🔥</span><div><b>'+esc(textFrom('streak','0'))+'</b><small>Streak</small></div></div>'+ 
        '<div class="lr73mIconStat"><span>🗺️</span><div><b>'+esc(sceneName()).slice(0,24)+'</b><small>Scene</small></div></div>'+ 
      '</div>'+ 
      '<div class="lr73mIconRack">'+
        '<button title="Realm Map" data-lr73m-act="map">🧭</button><button title="Go Learn" data-lr73m-act="learn">📘</button><button title="Items" data-lr73m-act="items">🎒</button><button title="Quests" data-lr73m-act="quests">📜</button>'+ 
        '<button title="History" data-lr73m-act="history">🏛️</button><button title="Bible" data-lr73m-act="bible">⛪</button><button title="Shipwreck" data-lr73m-act="shipwreck">⚓</button><button title="Home" data-lr73m-act="home">🏡</button>'+ 
      '</div>';
    var deck = box.querySelector('[data-lr73m="player-deck"]');
    if(!deck){ deck = document.createElement('div'); deck.className='lr73mPlayerDeck'; deck.setAttribute('data-lr73m','player-deck'); var h2 = box.querySelector('h2'); if(h2) h2.insertAdjacentElement('afterend',deck); else box.appendChild(deck); }
    if(deck.innerHTML !== html) deck.innerHTML = html;
    var h2 = box.querySelector('h2'); if(h2) h2.textContent = 'Player';
  }
  function refreshCommands(){
    var side = q('.actionSidebar'); var host = byId('leftActionButtons');
    if(!side || !host) return;
    setLabel(side, 'Command Window');
    var h2 = side.querySelector('h2'); if(h2) h2.textContent = 'Commands';
    var items = [
      ['📘','Go Learn','learn','primary'],['🪟','Scene','scene',''],['🔎','Look','look',''],['💬','Talk','talk',''],
      ['🗺️','Map','map',''],['🏛️','History','history',''],['🏚️','Depression','depression',''],['🤠','Wild West','wildwest',''],
      ['⛪','Bible','bible',''],['🏺','Artifacts','bibleArtifacts',''],['⚓','Shipwreck','shipwreck',''],['🏡','Home','home',''],
      ['🎒','Items','items',''],['🐾','Pets','pets',''],['📜','Quests','quests','']
    ];
    var html = items.map(function(x){ return '<button type="button" class="lr73mCommandBtn '+x[3]+'" data-lr73m-act="'+esc(x[2])+'"><span>'+esc(x[0])+'</span><b>'+esc(x[1])+'</b></button>'; }).join('');
    if(host.innerHTML !== html) host.innerHTML = html;
  }
  function refreshLedger(){
    var right = q('.rightSidebar .card'); if(!right) return;
    setLabel(right, 'Records Ledger');
    var frame = right.querySelector('[data-lr73m="ledger"]');
    var html = '<b>Current road</b><small>'+esc(sceneName())+'<br>'+esc(statLine())+'</small>'+ 
      '<div class="lr73mLedgerBtns"><button type="button" data-lr73m-act="history">🏛️ History</button><button type="button" data-lr73m-act="bible">⛪ Bible</button><button type="button" data-lr73m-act="quests">📜 Quests</button><button type="button" data-lr73m-act="items">🎒 Items</button></div>';
    if(!frame){ frame = document.createElement('div'); frame.className='lr73mLedger'; frame.setAttribute('data-lr73m','ledger'); var picker = right.querySelector('.rightInfoPicker'); if(picker) right.insertBefore(frame, picker); else right.appendChild(frame); }
    if(frame.innerHTML !== html) frame.innerHTML = html;
  }
  function refreshChrome(){
    try{ document.body.classList.add('lr73mStable','lr73iAtmosphere','lrDynamicAdventureMode','lr68DynamicShell'); }catch(e){}
    clearOldDamage(); installStyles(); refreshHeader(); refreshPlayer(); refreshCommands(); refreshLedger();
    setLabel(q('.main > .card:first-child'), 'Main Adventure Window');
  }

  function mount(){
    var first = q('.main > .card:first-child') || q('section.main') || document.body;
    var m = byId('lrDynamicAdventureScreen');
    if(!m){ m = document.createElement('div'); m.id='lrDynamicAdventureScreen'; m.className='lrDynamicAdventureScreen lr73mScreen'; if(first.firstChild) first.insertBefore(m, first.firstChild); else first.appendChild(m); }
    m.style.display='block'; m.style.visibility='visible'; m.style.opacity='1';
    return m;
  }
  function choice(icon,title,sub,act){
    return '<button type="button" class="lr73mChoice" data-lr73m-act="'+esc(act)+'"><span>'+esc(icon)+'</span><div><b>'+esc(title)+'</b><small>'+esc(sub)+'</small></div></button>';
  }
  function renderHub(kind){
    var m = mount();
    var kicker='Adventure Atlas', title='Choose your next road', desc='A clean, safe navigation board. These are guarded buttons, so a missing feature falls back instead of breaking the screen.', cards='';
    if(kind === 'history'){
      kicker='History Wing'; title='History and World Master Roads'; desc='Great Depression and Wild West belong here under the History umbrella, with the broader world/history board nearby.';
      cards = choice('🏚️','Great Depression Road','1930s history, money systems, Dust Bowl, family life, recovery, and resilience.','depression')+
              choice('🤠','Wild West Frontier Trail','Kid-safe frontier towns, trails, railroads, homesteads, cattle drives, tools, maps, and myth checking.','wildwest')+
              choice('🏛️','History learning board','Open the broader History and World course trails.','historyTrails')+
              choice('🗺️','Realm Map','Return to the larger adventure atlas.','map');
    }else if(kind === 'bible'){
      kicker='Bible History Realm'; title='Bible History Pilgrim Road'; desc='A separate, respectful Catholic-friendly place with Scripture history, Jesus, Mary, apostles, saints, angels, sacraments, feast days, and tasteful artifacts.';
      cards = choice('⛪','Pilgrim Road course','Open the full Bible History course map.','bibleCourse')+
              choice('🛤️','Walk the Bible road','Open the guided Bible History trail.','bibleTrail')+
              choice('🏺','Artifact Hall','Respectful Catholic study artifacts and decor.','bibleArtifacts')+
              choice('🏪','Bible shops','Tasteful themed shopkeepers and rewards.','bibleShops')+
              choice('🏆','Bible rewards','View earned Bible History rewards.','bibleRewards')+
              choice('🔎','Missed review','Review missed proof-of-reading questions.','bibleReview');
    }else if(kind === 'learn'){
      kicker='Learning Roads'; title='Choose a course realm'; desc='This keeps learning organized: History has the History master courses, and Bible has its own separate road.';
      cards = choice('📖','Featured Learning Trails','Open the main learning trail board.','featuredTrails')+
              choice('🏛️','History Wing','Great Depression, Wild West, and History/World courses.','history')+
              choice('⛪','Bible History','Separate respectful Bible History realm.','bible')+
              choice('⚓','Shipwreck Cove','Maritime history, navigation, ships, weather, and evidence.','shipwreck')+
              choice('🛠️','Inventions Hall','Inventors, redesign, problem solving, and engineering disasters.','inventions')+
              choice('🎨','Creative Studio','Art, music, craft, theater, and creative work.','creative');
    }else{
      cards = choice('📘','Go Learn','Open course roads and lesson trails.','learn')+
              choice('🏛️','History Wing','Great Depression and Wild West under History.','history')+
              choice('⛪','Bible History','Separate Catholic-friendly Bible History road.','bible')+
              choice('⚓','Shipwreck Cove','Maritime history and guided cove zone.','shipwreck')+
              choice('🏡','Home Hearth','Home rooms, storage, pets, and decor.','home')+
              choice('🎒','Items and Collections','Inventory, rewards, and collection log.','items')+
              choice('🐾','Companions','Pets and companion den.','pets')+
              choice('📜','Quest Board','Quests, journals, and daily boards.','quests');
    }
    m.innerHTML = '<section class="lr73mHero"><small>'+esc(kicker)+'</small><h1>'+esc(title)+'</h1><p>'+esc(desc)+'</p></section><section class="lr73mChoiceGrid">'+cards+'</section><section class="lr73mFooter"><button type="button" data-lr73m-act="scene">↩ Return to scene</button><button type="button" data-lr73m-act="learn">📘 Go Learn</button><button type="button" data-lr73m-act="home">🏡 Home</button></section>';
    afterAction();
    return true;
  }

  window.lr73mDo = function(act){
    act = String(act || 'map');
    if(act === 'scene') return first([['lr68Render','room','You return to the main scene.'],['lr68Render'],['renderRoom']]) || renderHub('map');
    if(act === 'look') return first([['lr68Render','look','You inspect the room.'],['openSubjectAtlasRoom', sceneName()],['openWorldAtlas']]) || renderHub('map');
    if(act === 'talk') return first([['lr68Render','talk','You look for someone to talk to.'],['talk'],['openNpcRelations'],['openQuestJournal']]) || renderHub('map');
    if(act === 'map') return renderHub('map');
    if(act === 'learn') return renderHub('learn');
    if(act === 'featuredTrails') return first([['lr68bOpenLearningTrails','featured'],['lr68OpenLearn'],['openRealCurriculumPicker'],['openLessonLauncher'],['openSubjectAtlasUI']]) || renderHub('learn');
    if(act === 'history') return renderHub('history');
    if(act === 'historyTrails') return first([['lr68bOpenLearningTrails','world'],['openWorldAtlas'],['openSubjectAtlasUI']]) || renderHub('history');
    if(act === 'depression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || renderHub('history');
    if(act === 'wildwest') return first([['openWildWestTrail'],['openWildWestCourse']]) || renderHub('history');
    if(act === 'bible') return renderHub('bible');
    if(act === 'bibleCourse') return first([['openBibleHistoryCourse'],['openBibleHistoryTrail']]) || renderHub('bible');
    if(act === 'bibleTrail') return first([['openBibleHistoryTrail'],['openBibleHistoryCourse']]) || renderHub('bible');
    if(act === 'bibleArtifacts') return first([['openBibleHistoryArtifacts73B'],['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || renderHub('bible');
    if(act === 'bibleShops') return first([['openBibleHistoryShops'],['openBibleHistoryCourse']]) || renderHub('bible');
    if(act === 'bibleRewards') return first([['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || renderHub('bible');
    if(act === 'bibleReview') return first([['openBibleHistoryReview'],['openBibleHistoryCourse']]) || renderHub('bible');
    if(act === 'shipwreck') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['lr68bOpenLearningTrails','featured']]) || renderHub('map');
    if(act === 'inventions') return first([['openInventionsDeepCourse'],['openInventionsRewardCatalog'],['lr68bOpenLearningTrails','featured']]) || renderHub('learn');
    if(act === 'creative') return first([['openCreativeStudioCourse'],['openCreativeStudioByStudio'],['lr68bOpenLearningTrails','featured']]) || renderHub('learn');
    if(act === 'home') return first([['lr68OpenHome'],['openHomeView'],['openHomeRenderer'],['openVisualHome'],['renderHomeSlots']]) || (function(){ try{ if(window.state){ window.state.loc='home'; } }catch(e){} return first([['renderRoom']]) || renderHub('map'); })();
    if(act === 'items') return first([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openWorldAtlas']]) || renderHub('map');
    if(act === 'pets') return first([['openCompanionDen'],['openCompanionPopup'],['openCompanionEngine']]) || renderHub('map');
    if(act === 'quests') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openQuestPopup']]) || renderHub('map');
    return renderHub('map');
  };

  function bindClicks(){
    if(window.__LR73M_CLICK_BOUND__) return;
    window.__LR73M_CLICK_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr73m-act]') : null;
      if(!btn) return;
      ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
      window.lr73mDo(btn.getAttribute('data-lr73m-act'));
    }, true);
  }
  function boot(){
    bindClicks(); refreshChrome();
    setTimeout(refreshChrome, 120);
    setTimeout(refreshChrome, 420);
    setTimeout(refreshChrome, 1000);
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,80); setTimeout(refreshChrome,700); });
})();
