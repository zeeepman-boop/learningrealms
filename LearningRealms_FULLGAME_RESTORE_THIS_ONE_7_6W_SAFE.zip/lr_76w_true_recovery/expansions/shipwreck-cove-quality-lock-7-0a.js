/* LearningRealms Shipwreck Cove Quality Lock 7.0A
   Stability/quality patch only: locks Shipwreck Cove routes to the 7.0 real curriculum,
   strengthens proof-of-reading quiz questions, adds a route/quality check panel,
   and keeps all normal learning windows/popups intact.
*/
(function(){
  'use strict';
  if(window.__LR_SHIPWRECK_70A_QUALITY_LOCK__) return;
  window.__LR_SHIPWRECK_70A_QUALITY_LOCK__ = true;

  function byId(id){ return document.getElementById(id); }
  function text(v){ return String(v == null ? '' : v); }
  function esc(v){ return text(v).replace(/[&<>"']/g,function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function course(){ return window.__LR_SHIPWRECK_COVE_COURSE_70__ || null; }
  function popup(title, html){
    if(typeof window.lrOpenPopup === 'function') return window.lrOpenPopup(title, html);
    var root=byId('lrPopupRoot'), tit=byId('lrPopupTitle'), body=byId('lrPopupBody');
    if(root && tit && body){ tit.textContent=title; body.innerHTML=html; root.classList.remove('hidden'); return; }
    var old=byId('shipwreck70aPopup'); if(old) old.remove();
    var div=document.createElement('div'); div.id='shipwreck70aPopup';
    div.innerHTML='<div class="swc70aBackdrop"></div><div class="swc70aModal"><div class="swc70aHead"><b>'+esc(title)+'</b><button type="button" data-close="1">✕</button></div>'+html+'</div>';
    document.body.appendChild(div);
    var close=div.querySelector('[data-close]'); if(close) close.onclick=function(){ div.remove(); };
  }

  function condense(s){
    s = text(s).replace(/\s+/g,' ').trim();
    if(s.length > 185) s = s.slice(0,182).replace(/[ ,;:.]+$/,'') + '...';
    return s;
  }
  function firstPara(topic, screenIndex, offset){
    var screen = topic && topic.screens && topic.screens[screenIndex];
    var ps = screen && screen.paragraphs ? screen.paragraphs : [];
    return condense(ps[offset || 0] || ps[0] || topic.summary || topic.title || '');
  }
  function putCorrect(choices, correct, pos){
    var out=[], used={};
    function add(x){ x=condense(x); if(!x || used[x]) return false; used[x]=true; out.push(x); return true; }
    var wrongs = choices.filter(function(x){ return condense(x)!==condense(correct); });
    while(out.length < 4){
      var next = out.length === pos ? correct : wrongs.shift();
      if(!add(next)) add('A vague answer that does not match this exact Shipwreck Cove lesson.');
      if(out.length > 8) break;
    }
    if(out.indexOf(condense(correct)) < 0){ out[pos] = condense(correct); }
    while(out.length < 4) out.push('A shortcut answer that skips the route, evidence, design, or safety lesson.');
    return out.slice(0,4);
  }
  function buildQuizForTopic(c, topic, i){
    var headings = ['Core story','Place, route, and conditions','Evidence to examine','Design, procedure, or safety lesson','Cove steward challenge'];
    var qLabels = [
      'Which detail is taught in the core story for',
      'Which route, place, or condition detail belongs to',
      'Which evidence clue belongs to',
      'Which design, procedure, or safety point belongs to',
      'Which steward challenge belongs to',
      'Which second detail also appears in the lesson for'
    ];
    var quizzes=[];
    for(var si=0; si<6; si++){
      var screenIndex = si < 5 ? si : 0;
      var offset = si < 5 ? 0 : 1;
      var correct = firstPara(topic, screenIndex, offset);
      var wrongPool=[];
      [3,7,11,17,23].forEach(function(step){
        var other = c.topics[(i + step) % c.topics.length];
        wrongPool.push(firstPara(other, screenIndex, offset));
      });
      wrongPool.push('Only the famous name matters, not the route, evidence, design, or safety lesson.');
      wrongPool.push('The safest answer is to ignore uncertainty and choose the most dramatic explanation.');
      var pos=(i+si)%4;
      var choices=putCorrect(wrongPool, correct, pos);
      quizzes.push({
        q: qLabels[si] + ' "' + topic.title + '"?',
        choices: choices,
        a: choices.indexOf(condense(correct)),
        explain: 'This answer comes from the '+(headings[screenIndex]||'lesson')+' window, so it checks actual reading instead of a generic guess.'
      });
    }
    return quizzes;
  }

  function qualityLockCourse(){
    var c = course();
    if(!c || !Array.isArray(c.topics)) return false;
    c.id = 'shipwreck_cove_real_curriculum_grade6_plus_v70a_quality_locked';
    c.label = 'Shipwreck Cove: Real Maritime History & Wreck Steward Course';
    c.summary = 'A Grade 6+ maritime-history course built around real wrecks, route geography, weather, ship design, archaeology, conservation, rescue, folklore versus evidence, and safety reform.';
    c.version = '7.0A quality lock';
    c.topics.forEach(function(t,i){
      t.quiz = buildQuizForTopic(c,t,i);
      t.qualityLocked70A = true;
      if(t.summary) t.summary = text(t.summary).replace(/filler[^.]*\.?/ig,'').replace(/scaffolding[^.]*\.?/ig,'').replace(/\s+/g,' ').trim();
    });
    window.__LR_SHIPWRECK_COVE_COURSE_70__ = c;
    return true;
  }

  function scanCourse(){
    var c=course();
    var checks=[];
    function add(name, pass, detail){ checks.push({name:name, pass:!!pass, detail:detail||''}); }
    add('Real curriculum object loaded', !!c, c ? c.label : 'Missing course object');
    add('Topic count locked to 30 focused lessons', c && c.topics && c.topics.length===30, c && c.topics ? c.topics.length+' topics found' : 'No topics found');
    var screenOk = c && c.topics && c.topics.every(function(t){ return t.screens && t.screens.length>=5; });
    add('Each topic has multi-window teaching', screenOk, 'Expected at least 5 teaching windows per topic');
    var quizOk = c && c.topics && c.topics.every(function(t){ return t.quiz && t.quiz.length>=6 && t.qualityLocked70A; });
    add('Proof-of-reading quizzes installed', quizOk, 'Expected 6 quality-locked questions per topic');
    var textBlob = c ? JSON.stringify(c).toLowerCase() : '';
    var banned = ['a real lesson, not a filler page','not a filler page','giant stall tactic','placeholder lesson'];
    var bannedHit = banned.filter(function(x){ return textBlob.indexOf(x)>=0; });
    add('No obvious old placeholder headings in active course', bannedHit.length===0, bannedHit.length ? bannedHit.join(', ') : 'Clean');
    add('Guided zone opener loaded', typeof window.shipwreckGuidedZoneOpen === 'function', 'shipwreckGuidedZoneOpen');
    add('Guided continue route loaded', typeof window.shipwreckGuidedZoneContinue === 'function', 'shipwreckGuidedZoneContinue');
    add('Direct topic opener loaded', typeof window.shipwreckOpenTopic === 'function', 'shipwreckOpenTopic');
    add('Full course map loaded', typeof window.openShipwreckCoveDeepCourse === 'function', 'openShipwreckCoveDeepCourse');
    return checks;
  }

  function openQualityCheck(){
    qualityLockCourse();
    var c=course();
    var checks=scanCourse();
    var passed=checks.filter(function(x){return x.pass;}).length;
    var html='<div class="swc70aShell"><div class="swc70aHero"><div><h2>⚓ Shipwreck Cove quality lock</h2><p>This check confirms the active Shipwreck Cove buttons are pointing at the rebuilt real-curriculum lesson bank and proof-of-reading quizzes.</p><p><b>'+passed+' / '+checks.length+'</b> route and curriculum checks passed.</p></div><div class="swc70aActions"><button type="button" class="swc70aPrimary" onclick="openShipwreckCoveDeepCourse && openShipwreckCoveDeepCourse()">Open course map</button><button type="button" onclick="shipwreckGuidedZoneOpen && shipwreckGuidedZoneOpen()">Enter guided zone</button><button type="button" onclick="shipwreckOpenTopic && shipwreckOpenTopic(0,0)">Test first lesson</button></div></div><div class="swc70aChecks">'+
      checks.map(function(ch){return '<div class="swc70aCheck '+(ch.pass?'pass':'warn')+'"><b>'+(ch.pass?'✓':'!')+' '+esc(ch.name)+'</b><small>'+esc(ch.detail)+'</small></div>';}).join('')+
      '</div><div class="swc70aNote"><b>Active course:</b> '+esc(c ? c.label : 'Not found')+'<br><b>Version:</b> '+esc(c && c.version ? c.version : 'unknown')+'</div></div>';
    popup('⚓ Shipwreck Cove Route Check', html);
  }
  window.openShipwreckCoveQualityLockCheck = openQualityCheck;

  function addQualityButton(){
    qualityLockCourse();
    var body=byId('lrPopupBody') || document.querySelector('.swcModal');
    if(!body || body.querySelector('[data-swc70a-quality]')) return;
    var heroBtns = body.querySelector('.swcHeroBtns,.swczCHeroBtns') || body.querySelector('.swcHero,.swczCHero');
    if(!heroBtns) return;
    var btn=document.createElement('button');
    btn.type='button';
    btn.setAttribute('data-swc70a-quality','1');
    btn.textContent='Route / lesson check';
    btn.onclick=openQualityCheck;
    heroBtns.appendChild(btn);
  }
  function wrap(name){
    var old=window[name];
    if(typeof old !== 'function' || old.__swc70aWrapped) return;
    var wrapped=function(){ qualityLockCourse(); var out=old.apply(this,arguments); setTimeout(addQualityButton,40); return out; };
    wrapped.__swc70aWrapped=true;
    window[name]=wrapped;
  }
  function scrubOldVisibleLabels(){
    var roots=[byId('lrPopupBody'), byId('actionText'), byId('lrDynamicAdventureScreen')].filter(Boolean);
    roots.forEach(function(root){
      root.querySelectorAll('*').forEach(function(el){
        if(el.childNodes && el.childNodes.length===1 && el.childNodes[0].nodeType===3){
          el.textContent = text(el.textContent)
            .replace(/instead of filler pages/ig,'with route-checked real lessons')
            .replace(/old filler-style scaffolding/ig,'older draft lesson bank')
            .replace(/filler\/scaffolding/ig,'draft')
            .replace(/filler-style/ig,'draft')
            .replace(/scaffolding/ig,'draft');
        }
      });
    });
  }

  function install(){
    qualityLockCourse();
    wrap('openShipwreckCoveDeepCourse');
    wrap('shipwreckGuidedZoneOpen');
    wrap('shipwreckGuidedZoneContinue');
    wrap('openShipwreckCoveMap');
    wrap('shipwreckGuidedZoneMap');
    addQualityButton();
    scrubOldVisibleLabels();
  }

  function styles(){
    if(byId('shipwreck70aStyles')) return;
    var st=document.createElement('style');
    st.id='shipwreck70aStyles';
    st.textContent='.swc70aBackdrop{position:absolute;inset:0;background:rgba(0,0,0,.42)}.swc70aModal{position:relative;margin:4vh auto;background:#fffdf8;width:min(1120px,94vw);max-height:88vh;overflow:auto;border-radius:18px;box-shadow:0 25px 70px rgba(0,0,0,.4)}.swc70aHead{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid #ddd;background:#f5ead1}.swc70aHead button{border:0;background:#fff;border-radius:8px;padding:5px 9px;cursor:pointer}.swc70aShell{color:#20313f}.swc70aHero{display:grid;grid-template-columns:1.3fr .7fr;gap:14px;padding:16px;border-radius:18px;background:linear-gradient(135deg,#eaf8ff,#fff0c9);border:2px solid rgba(43,87,112,.22);margin-bottom:14px}.swc70aActions{display:flex;flex-direction:column;gap:8px}.swc70aActions button,.swc70aCheck button{border:1px solid rgba(51,76,94,.25);border-radius:12px;background:#fffdf6;padding:9px 11px;font-weight:900;cursor:pointer}.swc70aPrimary{background:#ffdf75!important;border-color:#9a6b00!important}.swc70aChecks{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}.swc70aCheck{border:1px solid rgba(54,76,90,.18);border-radius:14px;padding:12px;background:#fff}.swc70aCheck.pass{background:#f0fff2}.swc70aCheck.warn{background:#fff4e5}.swc70aCheck small{display:block;margin-top:5px;opacity:.8}.swc70aNote{margin-top:12px;padding:12px;border-radius:14px;background:#f7fbff;border:1px solid rgba(54,76,90,.18)}@media(max-width:760px){.swc70aHero{grid-template-columns:1fr}}';
    document.head.appendChild(st);
  }

  styles();
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(install,80); setTimeout(install,500); });
  else { setTimeout(install,80); setTimeout(install,500); }
  window.addEventListener('load', function(){ setTimeout(install,350); setTimeout(install,1200); });
  setInterval(function(){ try{ install(); }catch(e){} }, 3000);
})();
