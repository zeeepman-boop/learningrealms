// Curriculum Pack 6A: Civics Foundation Expansion
// Content-only pack. No engine changes.
// Adds civics lessons for Luna, Ava, and Michael.
// Focus: rules, rights, responsibilities, branches, federalism, courts, civic participation, reliable sources.

(function(){
  LR_addLessons("Luna","Civics",[
 {
  "teach": "A rule tells what people should do.",
  "practice": "A rule can say: Walk inside.",
  "q": "What does a rule tell?",
  "c": [
   "what people should do",
   "what color a frog is",
   "where clouds sleep"
  ],
  "a": "what people should do"
 },
 {
  "teach": "Rules can help people stay safe.",
  "practice": "Look both ways before crossing.",
  "q": "Why do we have safety rules?",
  "c": [
   "to make mud",
   "to stay safe",
   "to hide books"
  ],
  "a": "to stay safe"
 },
 {
  "teach": "A fair rule helps people take turns.",
  "practice": "Everyone gets a turn with the crayons.",
  "q": "Which rule sounds fair?",
  "c": [
   "grab everything",
   "never share",
   "take turns"
  ],
  "a": "take turns"
 },
 {
  "teach": "A responsibility is something you should do.",
  "practice": "Putting toys away can be a responsibility.",
  "q": "Which is a responsibility?",
  "c": [
   "putting toys away",
   "spilling on purpose",
   "yelling inside"
  ],
  "a": "putting toys away"
 },
 {
  "teach": "A choice is when you pick what to do.",
  "practice": "You can choose to help or not help.",
  "q": "What is a choice?",
  "c": [
   "a kind of cloud",
   "picking what to do",
   "a broken chair"
  ],
  "a": "picking what to do"
 },
 {
  "teach": "A consequence is what happens after a choice.",
  "practice": "If you clean up, the room is neat.",
  "q": "What comes after a choice?",
  "c": [
   "a dinosaur horn",
   "a snowflake",
   "a consequence"
  ],
  "a": "a consequence"
 },
 {
  "teach": "A helper is someone who helps others.",
  "practice": "A firefighter helps during emergencies.",
  "q": "Who is a community helper?",
  "c": [
   "firefighter",
   "pencil",
   "sandwich"
  ],
  "a": "firefighter"
 },
 {
  "teach": "A doctor helps sick or hurt people.",
  "practice": "Doctors, nurses, and helpers care for people.",
  "q": "Who helps sick or hurt people?",
  "c": [
   "puddle",
   "doctor",
   "blank wall"
  ],
  "a": "doctor"
 },
 {
  "teach": "A librarian helps people find books.",
  "practice": "The librarian shows where books belong.",
  "q": "Who helps people find books?",
  "c": [
   "lamp",
   "cookie",
   "librarian"
  ],
  "a": "librarian"
 },
 {
  "teach": "A mail carrier brings mail.",
  "practice": "Letters and packages can come in the mail.",
  "q": "Who brings mail?",
  "c": [
   "mail carrier",
   "zebra",
   "moon"
  ],
  "a": "mail carrier"
 },
 {
  "teach": "A mayor helps lead a town or city.",
  "practice": "A mayor works on town problems.",
  "q": "Who helps lead a town or city?",
  "c": [
   "spoon",
   "mayor",
   "cloud"
  ],
  "a": "mayor"
 },
 {
  "teach": "A citizen is a member of a community.",
  "practice": "People in a town are citizens of that town.",
  "q": "A citizen belongs to a...",
  "c": [
   "sand pile",
   "rainbow",
   "community"
  ],
  "a": "community"
 },
 {
  "teach": "People can help their community.",
  "practice": "Picking up trash helps keep a place clean.",
  "q": "Which helps a community?",
  "c": [
   "picking up trash",
   "breaking signs",
   "hiding tools"
  ],
  "a": "picking up trash"
 },
 {
  "teach": "People can listen when others speak.",
  "practice": "Good listening helps people work together.",
  "q": "What helps people work together?",
  "c": [
   "interrupting",
   "listening",
   "running away"
  ],
  "a": "listening"
 },
 {
  "teach": "Voting is a way to choose.",
  "practice": "A group can vote for which game to play.",
  "q": "Voting helps a group...",
  "c": [
   "sleep",
   "melt",
   "choose"
  ],
  "a": "choose"
 },
 {
  "teach": "The most votes usually wins a simple vote.",
  "practice": "Three votes for apples, one for pears.",
  "q": "In a simple vote, the most votes usually...",
  "c": [
   "wins",
   "hides",
   "floats"
  ],
  "a": "wins"
 },
 {
  "teach": "A law is a rule for a town, state, or country.",
  "practice": "Traffic laws help people travel safely.",
  "q": "A law is a kind of...",
  "c": [
   "sandwich",
   "rule",
   "song"
  ],
  "a": "rule"
 },
 {
  "teach": "A sign can tell a rule.",
  "practice": "A STOP sign tells drivers to stop.",
  "q": "What does a STOP sign tell drivers?",
  "c": [
   "sing",
   "jump",
   "stop"
  ],
  "a": "stop"
 },
 {
  "teach": "A right is something people are allowed to have or do.",
  "practice": "People have a right to be treated fairly.",
  "q": "A right is something people are...",
  "c": [
   "allowed to have or do",
   "never allowed to see",
   "supposed to break"
  ],
  "a": "allowed to have or do"
 },
 {
  "teach": "Respect means treating people properly.",
  "practice": "Kind words can show respect.",
  "q": "Which shows respect?",
  "c": [
   "mean teasing",
   "kind words",
   "pushing"
  ],
  "a": "kind words"
 },
 {
  "teach": "Honesty means telling the truth.",
  "practice": "Saying what really happened is honest.",
  "q": "What does honesty mean?",
  "c": [
   "hiding every answer",
   "making a mess",
   "telling the truth"
  ],
  "a": "telling the truth"
 },
 {
  "teach": "A promise is something you say you will do.",
  "practice": "Keeping a promise builds trust.",
  "q": "Keeping promises can build...",
  "c": [
   "trust",
   "mud",
   "thunder"
  ],
  "a": "trust"
 },
 {
  "teach": "A family can have rules.",
  "practice": "Wash hands before dinner can be a family rule.",
  "q": "Where can rules be found?",
  "c": [
   "inside a star",
   "in a family",
   "under every shoe"
  ],
  "a": "in a family"
 },
 {
  "teach": "A home job helps the household.",
  "practice": "Feeding a pet can be a home job.",
  "q": "Which can be a home job?",
  "c": [
   "breaking a plate",
   "drawing on walls",
   "feeding a pet"
  ],
  "a": "feeding a pet"
 },
 {
  "teach": "A neighborhood is an area where people live near each other.",
  "practice": "Homes on the same street can be in a neighborhood.",
  "q": "People live near each other in a...",
  "c": [
   "neighborhood",
   "volcano",
   "rocket"
  ],
  "a": "neighborhood"
 },
 {
  "teach": "A map can show places in a community.",
  "practice": "A map can show roads and buildings.",
  "q": "What can show places?",
  "c": [
   "a sock",
   "a map",
   "a cup"
  ],
  "a": "a map"
 },
 {
  "teach": "A school, library, and park can be public places.",
  "practice": "Public places are for people in the community.",
  "q": "Which can be a public place?",
  "c": [
   "private toothbrush",
   "closed lunchbox",
   "library"
  ],
  "a": "library"
 },
 {
  "teach": "A park is a public place people can share.",
  "practice": "People should keep parks clean.",
  "q": "What should people do at parks?",
  "c": [
   "keep them clean",
   "throw trash everywhere",
   "break benches"
  ],
  "a": "keep them clean"
 },
 {
  "teach": "Emergency helpers come when people need help quickly.",
  "practice": "Call for help if there is danger.",
  "q": "Emergency helpers come when people need help...",
  "c": [
   "next year",
   "quickly",
   "only at bedtime"
  ],
  "a": "quickly"
 },
 {
  "teach": "A firefighter can help with fires.",
  "practice": "Firefighters use trucks, hoses, and safety gear.",
  "q": "Who helps with fires?",
  "c": [
   "painter",
   "baker",
   "firefighter"
  ],
  "a": "firefighter"
 },
 {
  "teach": "A police officer helps enforce laws.",
  "practice": "Police officers help keep public order.",
  "q": "Who helps enforce laws?",
  "c": [
   "police officer",
   "butterfly",
   "pillow"
  ],
  "a": "police officer"
 },
 {
  "teach": "A judge works in a court.",
  "practice": "A judge listens to facts and rules.",
  "q": "Where does a judge work?",
  "c": [
   "tree nest",
   "court",
   "toy box"
  ],
  "a": "court"
 },
 {
  "teach": "A flag can stand for a country or state.",
  "practice": "The American flag stands for the United States.",
  "q": "A flag can stand for a...",
  "c": [
   "sandwich",
   "whistle",
   "country"
  ],
  "a": "country"
 },
 {
  "teach": "The United States is our country.",
  "practice": "A country has people, places, and government.",
  "q": "What is the United States?",
  "c": [
   "our country",
   "a fruit",
   "a shoe"
  ],
  "a": "our country"
 },
 {
  "teach": "Kentucky is a state.",
  "practice": "A state is part of a country.",
  "q": "Kentucky is a...",
  "c": [
   "planet",
   "state",
   "spoon"
  ],
  "a": "state"
 },
 {
  "teach": "A capital city is an important government city.",
  "practice": "Frankfort is Kentucky's capital.",
  "q": "What is Kentucky's capital?",
  "c": [
   "Atlantis",
   "Moon City",
   "Frankfort"
  ],
  "a": "Frankfort"
 },
 {
  "teach": "A president helps lead the country.",
  "practice": "The president is part of the national government.",
  "q": "Who helps lead the country?",
  "c": [
   "president",
   "mailbox",
   "kitten"
  ],
  "a": "president"
 },
 {
  "teach": "A governor helps lead a state.",
  "practice": "Kentucky has a governor.",
  "q": "Who helps lead a state?",
  "c": [
   "carpet",
   "governor",
   "crayon"
  ],
  "a": "governor"
 },
 {
  "teach": "People can solve problems by talking calmly.",
  "practice": "Calm words help solve disagreements.",
  "q": "What helps solve a disagreement?",
  "c": [
   "screaming louder",
   "grabbing",
   "talking calmly"
  ],
  "a": "talking calmly"
 },
 {
  "teach": "A good citizen helps and follows fair rules.",
  "practice": "Good citizens can be kind, honest, and helpful.",
  "q": "Which describes a good citizen?",
  "c": [
   "helpful",
   "mean on purpose",
   "always unfair"
  ],
  "a": "helpful"
 }
]);
  LR_addLessons("Ava","Civics",[
 {
  "teach": "Civics is the study of citizenship and government.",
  "practice": "A civics question may ask how laws, rights, and responsibilities work.",
  "q": "What does civics mainly study?",
  "c": [
   "citizenship and government",
   "only animal habitats",
   "how to bake bread"
  ],
  "a": "citizenship and government"
 },
 {
  "teach": "A citizen is a member of a community, state, or country.",
  "practice": "Citizens have rights and responsibilities.",
  "q": "A citizen usually has both rights and...",
  "c": [
   "weather maps",
   "responsibilities",
   "secret passwords"
  ],
  "a": "responsibilities"
 },
 {
  "teach": "A responsibility is a duty people are expected to carry out.",
  "practice": "Following laws and serving on a jury when called are civic responsibilities.",
  "q": "Which is a civic responsibility?",
  "c": [
   "ignoring all rules",
   "hiding public records",
   "following laws"
  ],
  "a": "following laws"
 },
 {
  "teach": "A right is a protected freedom or claim.",
  "practice": "Freedom of speech is one example of a protected right.",
  "q": "A right is best described as a protected...",
  "c": [
   "freedom",
   "shortcut",
   "decoration"
  ],
  "a": "freedom"
 },
 {
  "teach": "The Constitution is the highest law of the United States.",
  "practice": "Other laws must fit within the Constitution.",
  "q": "What is the highest law of the United States?",
  "c": [
   "a city rulebook",
   "the Constitution",
   "a store receipt"
  ],
  "a": "the Constitution"
 },
 {
  "teach": "The Bill of Rights is the first ten amendments.",
  "practice": "These amendments list important rights.",
  "q": "The Bill of Rights means the first ten...",
  "c": [
   "states",
   "presidents",
   "amendments"
  ],
  "a": "amendments"
 },
 {
  "teach": "An amendment is a formal change or addition to the Constitution.",
  "practice": "The Bill of Rights contains amendments.",
  "q": "An amendment is a formal...",
  "c": [
   "change or addition",
   "weather report",
   "court building"
  ],
  "a": "change or addition"
 },
 {
  "teach": "The First Amendment protects several freedoms.",
  "practice": "Speech, religion, press, assembly, and petition are included.",
  "q": "Which freedom is in the First Amendment?",
  "c": [
   "speeding",
   "speech",
   "tax collecting"
  ],
  "a": "speech"
 },
 {
  "teach": "The federal government is the national government.",
  "practice": "It handles national matters like defense and relations with other countries.",
  "q": "The federal government is the...",
  "c": [
   "neighborhood picnic group",
   "private club",
   "national government"
  ],
  "a": "national government"
 },
 {
  "teach": "A state government handles state matters.",
  "practice": "Kentucky's government makes and enforces state laws.",
  "q": "Kentucky's government is a...",
  "c": [
   "state government",
   "foreign embassy",
   "book club"
  ],
  "a": "state government"
 },
 {
  "teach": "Local government serves towns, cities, and counties.",
  "practice": "Local governments often handle roads, parks, and local services.",
  "q": "Which is usually local government work?",
  "c": [
   "declaring war",
   "maintaining local roads",
   "printing national currency"
  ],
  "a": "maintaining local roads"
 },
 {
  "teach": "Federalism divides power between national and state governments.",
  "practice": "Both levels have their own responsibilities.",
  "q": "Federalism divides power between national and...",
  "c": [
   "grocery stores",
   "sports teams",
   "state governments"
  ],
  "a": "state governments"
 },
 {
  "teach": "The legislative branch makes laws.",
  "practice": "Congress is the national legislative branch.",
  "q": "Which branch makes laws?",
  "c": [
   "legislative",
   "executive",
   "judicial"
  ],
  "a": "legislative"
 },
 {
  "teach": "The executive branch carries out laws.",
  "practice": "The president is part of the national executive branch.",
  "q": "Which branch carries out laws?",
  "c": [
   "judicial",
   "executive",
   "legislative"
  ],
  "a": "executive"
 },
 {
  "teach": "The judicial branch interprets laws.",
  "practice": "Courts decide what laws mean in cases.",
  "q": "Which branch interprets laws?",
  "c": [
   "executive",
   "legislative",
   "judicial"
  ],
  "a": "judicial"
 },
 {
  "teach": "Separation of powers divides government power among branches.",
  "practice": "This helps prevent one part from controlling everything.",
  "q": "Separation of powers divides power among...",
  "c": [
   "branches",
   "continents",
   "libraries"
  ],
  "a": "branches"
 },
 {
  "teach": "Checks and balances let each branch limit the others.",
  "practice": "A president can veto a bill, and courts can review laws.",
  "q": "Checks and balances help limit government...",
  "c": [
   "temperature",
   "power",
   "population"
  ],
  "a": "power"
 },
 {
  "teach": "A veto is a president's rejection of a bill.",
  "practice": "Congress may try to override a veto.",
  "q": "A veto rejects a...",
  "c": [
   "map",
   "courtroom",
   "bill"
  ],
  "a": "bill"
 },
 {
  "teach": "A bill is a proposed law.",
  "practice": "If approved through the process, a bill can become a law.",
  "q": "A bill is a proposed...",
  "c": [
   "law",
   "flag",
   "court"
  ],
  "a": "law"
 },
 {
  "teach": "A law is an official rule made by government.",
  "practice": "Laws apply to people in a place.",
  "q": "A law is an official...",
  "c": [
   "coin",
   "rule",
   "song"
  ],
  "a": "rule"
 },
 {
  "teach": "An ordinance is a local law.",
  "practice": "A city may pass an ordinance about noise or parking.",
  "q": "An ordinance is usually a...",
  "c": [
   "federal court",
   "state nickname",
   "local law"
  ],
  "a": "local law"
 },
 {
  "teach": "A court case is a legal dispute brought before a court.",
  "practice": "Courts use laws, facts, and evidence.",
  "q": "A court case should use facts and...",
  "c": [
   "evidence",
   "rumors",
   "loud guesses"
  ],
  "a": "evidence"
 },
 {
  "teach": "Evidence is information used to support a claim.",
  "practice": "A document or witness statement may be evidence.",
  "q": "Evidence supports a...",
  "c": [
   "holiday",
   "claim",
   "color"
  ],
  "a": "claim"
 },
 {
  "teach": "A reliable source can be checked for author, date, purpose, and evidence.",
  "practice": "Good civic thinking uses reliable sources.",
  "q": "Which is part of checking reliability?",
  "c": [
   "paper color only",
   "how funny it sounds",
   "author and evidence"
  ],
  "a": "author and evidence"
 },
 {
  "teach": "A primary source comes from the time or event being studied.",
  "practice": "A law text or speech transcript can be a primary source.",
  "q": "A primary source comes from the...",
  "c": [
   "time or event",
   "future only",
   "teacher's imagination"
  ],
  "a": "time or event"
 },
 {
  "teach": "A secondary source explains or discusses primary sources.",
  "practice": "A textbook summary about a law is a secondary source.",
  "q": "A secondary source usually...",
  "c": [
   "is always a law itself",
   "explains primary sources",
   "cannot be written"
  ],
  "a": "explains primary sources"
 },
 {
  "teach": "Voting is a formal way citizens choose leaders or decide issues.",
  "practice": "Elections use votes to make decisions.",
  "q": "Voting is a way to...",
  "c": [
   "erase laws automatically",
   "avoid responsibility",
   "choose leaders or issues"
  ],
  "a": "choose leaders or issues"
 },
 {
  "teach": "An election is a process for choosing leaders or deciding questions.",
  "practice": "People vote during elections.",
  "q": "An election is a process for...",
  "c": [
   "choosing leaders",
   "building bridges only",
   "writing dictionaries"
  ],
  "a": "choosing leaders"
 },
 {
  "teach": "A candidate is a person running for office.",
  "practice": "Voters compare candidates before choosing.",
  "q": "A candidate is someone...",
  "c": [
   "counting stars",
   "running for office",
   "fixing every road"
  ],
  "a": "running for office"
 },
 {
  "teach": "A ballot lists choices in an election.",
  "practice": "A voter marks a ballot.",
  "q": "A ballot lists election...",
  "c": [
   "recipes",
   "weather",
   "choices"
  ],
  "a": "choices"
 },
 {
  "teach": "Majority means more than half.",
  "practice": "If 11 people vote, 6 is a majority.",
  "q": "Majority means...",
  "c": [
   "more than half",
   "exactly zero",
   "less than all always"
  ],
  "a": "more than half"
 },
 {
  "teach": "Public service is work done for the community.",
  "practice": "Road repair, emergency response, and libraries can be public services.",
  "q": "Which is a public service?",
  "c": [
   "private toy sorting",
   "emergency response",
   "personal snack choice"
  ],
  "a": "emergency response"
 },
 {
  "teach": "Taxes help pay for many public services.",
  "practice": "Roads, schools, and emergency services can be funded by taxes.",
  "q": "Taxes often help pay for...",
  "c": [
   "private wishes only",
   "secret riddles",
   "public services"
  ],
  "a": "public services"
 },
 {
  "teach": "A budget is a plan for spending money.",
  "practice": "Governments use budgets to plan public spending.",
  "q": "A budget is a plan for...",
  "c": [
   "spending money",
   "drawing clouds",
   "naming streets"
  ],
  "a": "spending money"
 },
 {
  "teach": "A public good is something many people can use.",
  "practice": "A public road can serve many people.",
  "q": "Which is closest to a public good?",
  "c": [
   "private toothbrush",
   "public road",
   "one person's sandwich"
  ],
  "a": "public road"
 },
 {
  "teach": "The common good means what helps the community as a whole.",
  "practice": "Keeping water clean can serve the common good.",
  "q": "The common good helps...",
  "c": [
   "only one hidden person",
   "no one",
   "the community as a whole"
  ],
  "a": "the community as a whole"
 },
 {
  "teach": "Due process means government must follow fair legal steps.",
  "practice": "People should not be punished without fair procedures.",
  "q": "Due process requires fair legal...",
  "c": [
   "steps",
   "games",
   "paint colors"
  ],
  "a": "steps"
 },
 {
  "teach": "Equal protection means laws should protect people fairly.",
  "practice": "Government should not apply laws in an unfair way.",
  "q": "Equal protection means laws should protect people...",
  "c": [
   "randomly",
   "fairly",
   "secretly"
  ],
  "a": "fairly"
 },
 {
  "teach": "A jury is a group of citizens who may decide facts in a trial.",
  "practice": "Jury service is an important civic duty.",
  "q": "A jury may decide...",
  "c": [
   "the weather",
   "a sports score from memory",
   "facts in a trial"
  ],
  "a": "facts in a trial"
 },
 {
  "teach": "A constitution limits government power.",
  "practice": "Written limits help protect rights.",
  "q": "One purpose of a constitution is to limit...",
  "c": [
   "government power",
   "all reading",
   "every map"
  ],
  "a": "government power"
 },
 {
  "teach": "Civic virtue means habits that help a community work well.",
  "practice": "Honesty, responsibility, and respect can be civic virtues.",
  "q": "Which is a civic virtue?",
  "c": [
   "cheating",
   "responsibility",
   "carelessness"
  ],
  "a": "responsibility"
 },
 {
  "teach": "Compromise means each side gives up something to reach agreement.",
  "practice": "Compromise can help solve public problems.",
  "q": "Compromise helps people reach...",
  "c": [
   "confusion",
   "silence forever",
   "agreement"
  ],
  "a": "agreement"
 },
 {
  "teach": "A petition is a formal request, often signed by people.",
  "practice": "Citizens may petition government about an issue.",
  "q": "A petition is a formal...",
  "c": [
   "request",
   "tax",
   "courtroom"
  ],
  "a": "request"
 },
 {
  "teach": "Assembly means people gathering peacefully.",
  "practice": "The First Amendment protects peaceful assembly.",
  "q": "Peaceful assembly means people...",
  "c": [
   "break laws together",
   "gather peacefully",
   "hide every record"
  ],
  "a": "gather peacefully"
 },
 {
  "teach": "The press can share news and information.",
  "practice": "Freedom of the press helps people learn about public matters.",
  "q": "Freedom of the press helps people get...",
  "c": [
   "free candy",
   "private passwords",
   "information"
  ],
  "a": "information"
 },
 {
  "teach": "A county is a local government area.",
  "practice": "Kentucky has counties that provide local services.",
  "q": "A county is a kind of...",
  "c": [
   "local government area",
   "foreign country",
   "federal branch"
  ],
  "a": "local government area"
 },
 {
  "teach": "The Kentucky General Assembly makes state laws.",
  "practice": "It is Kentucky's legislative branch.",
  "q": "The Kentucky General Assembly is part of which branch?",
  "c": [
   "judicial",
   "legislative",
   "executive"
  ],
  "a": "legislative"
 },
 {
  "teach": "The governor is the head of Kentucky's executive branch.",
  "practice": "The governor helps carry out state laws.",
  "q": "Kentucky's governor belongs to the...",
  "c": [
   "judicial branch",
   "press",
   "executive branch"
  ],
  "a": "executive branch"
 },
 {
  "teach": "State courts are part of the judicial branch.",
  "practice": "They handle cases under state law.",
  "q": "State courts belong to the...",
  "c": [
   "judicial branch",
   "executive branch",
   "legislative branch"
  ],
  "a": "judicial branch"
 },
 {
  "teach": "Civic participation can include voting, volunteering, or contacting officials.",
  "practice": "People can participate in public life in many lawful ways.",
  "q": "Which is civic participation?",
  "c": [
   "breaking windows",
   "volunteering",
   "hiding facts"
  ],
  "a": "volunteering"
 }
]);
  LR_addLessons("Michael","Civics",[
 {
  "teach": "Civic life depends on ordered liberty: freedom protected by fair rules.",
  "practice": "A society needs liberty and lawful order, not just one or the other.",
  "q": "Ordered liberty means freedom protected by...",
  "c": [
   "fair rules",
   "random force",
   "no responsibilities"
  ],
  "a": "fair rules"
 },
 {
  "teach": "Popular sovereignty means government authority comes from the people.",
  "practice": "The Constitution begins with 'We the People.'",
  "q": "Popular sovereignty means authority comes from...",
  "c": [
   "a secret king",
   "the people",
   "the weather"
  ],
  "a": "the people"
 },
 {
  "teach": "A republic uses elected representatives to make many public decisions.",
  "practice": "Citizens vote for representatives rather than voting on every law directly.",
  "q": "In a republic, citizens choose...",
  "c": [
   "private chefs",
   "court buildings",
   "representatives"
  ],
  "a": "representatives"
 },
 {
  "teach": "Limited government means government has legal limits.",
  "practice": "The Constitution limits what government may do.",
  "q": "Limited government means government power is...",
  "c": [
   "restricted by law",
   "unlimited",
   "hidden from all rules"
  ],
  "a": "restricted by law"
 },
 {
  "teach": "Rule of law means everyone, including officials, is under the law.",
  "practice": "A government official cannot simply ignore the law.",
  "q": "Rule of law means the law applies to...",
  "c": [
   "only children",
   "everyone",
   "no officials"
  ],
  "a": "everyone"
 },
 {
  "teach": "Natural rights are basic rights government should protect.",
  "practice": "The Declaration of Independence names life, liberty, and the pursuit of happiness.",
  "q": "Natural rights are rights government should...",
  "c": [
   "erase",
   "sell",
   "protect"
  ],
  "a": "protect"
 },
 {
  "teach": "The Declaration of Independence explained why the colonies separated from Britain.",
  "practice": "It argued that government should protect rights.",
  "q": "The Declaration explained separation from...",
  "c": [
   "Britain",
   "France",
   "Canada"
  ],
  "a": "Britain"
 },
 {
  "teach": "The Articles of Confederation created a weak national government.",
  "practice": "Problems under the Articles helped lead to the Constitution.",
  "q": "The Articles of Confederation made the national government...",
  "c": [
   "all-powerful",
   "weak",
   "a court only"
  ],
  "a": "weak"
 },
 {
  "teach": "The Constitutional Convention produced the U.S. Constitution.",
  "practice": "Delegates debated representation, power, and structure.",
  "q": "The Constitutional Convention produced the...",
  "c": [
   "Bill of Rights only",
   "Kentucky constitution",
   "Constitution"
  ],
  "a": "Constitution"
 },
 {
  "teach": "The Great Compromise created a bicameral Congress.",
  "practice": "The House is based on population, while the Senate gives states equal representation.",
  "q": "The Great Compromise helped create...",
  "c": [
   "two houses of Congress",
   "one national judge",
   "no legislature"
  ],
  "a": "two houses of Congress"
 },
 {
  "teach": "Bicameral means having two chambers.",
  "practice": "Congress is bicameral: House and Senate.",
  "q": "Bicameral means...",
  "c": [
   "three presidents",
   "two chambers",
   "one court"
  ],
  "a": "two chambers"
 },
 {
  "teach": "Separation of powers divides lawmaking, law-enforcing, and law-interpreting power.",
  "practice": "This helps prevent concentration of power.",
  "q": "Separation of powers helps prevent concentrated...",
  "c": [
   "rain",
   "trade",
   "power"
  ],
  "a": "power"
 },
 {
  "teach": "Checks and balances give each branch ways to limit the others.",
  "practice": "Vetoes, confirmations, impeachment, and judicial review are examples.",
  "q": "Checks and balances let branches...",
  "c": [
   "limit each other",
   "do identical jobs",
   "avoid the Constitution"
  ],
  "a": "limit each other"
 },
 {
  "teach": "Judicial review is the power to decide whether laws or actions fit the Constitution.",
  "practice": "Marbury v. Madison is linked to judicial review.",
  "q": "Judicial review checks whether laws fit the...",
  "c": [
   "weather",
   "Constitution",
   "budget receipt"
  ],
  "a": "Constitution"
 },
 {
  "teach": "Federalism divides power between national and state governments.",
  "practice": "Delegated, reserved, and concurrent powers show this division.",
  "q": "Federalism divides power between national and...",
  "c": [
   "newspapers",
   "private stores",
   "state governments"
  ],
  "a": "state governments"
 },
 {
  "teach": "Delegated powers are powers given to the national government.",
  "practice": "Coining money and declaring war are delegated powers.",
  "q": "Which is a delegated power?",
  "c": [
   "declaring war",
   "issuing a local library card",
   "setting a family bedtime"
  ],
  "a": "declaring war"
 },
 {
  "teach": "Reserved powers are kept by the states.",
  "practice": "Many education and local safety rules are state matters.",
  "q": "Reserved powers belong to the...",
  "c": [
   "president only",
   "states",
   "Supreme Court only"
  ],
  "a": "states"
 },
 {
  "teach": "Concurrent powers are shared by national and state governments.",
  "practice": "Taxing can be a concurrent power.",
  "q": "Concurrent powers are...",
  "c": [
   "forbidden to everyone",
   "only local",
   "shared"
  ],
  "a": "shared"
 },
 {
  "teach": "The Supremacy Clause says the Constitution and valid federal law are supreme.",
  "practice": "State laws cannot override valid federal law.",
  "q": "The Supremacy Clause makes valid federal law...",
  "c": [
   "supreme",
   "optional",
   "local only"
  ],
  "a": "supreme"
 },
 {
  "teach": "The Necessary and Proper Clause lets Congress make laws needed to carry out its powers.",
  "practice": "It is sometimes called the elastic clause.",
  "q": "The Necessary and Proper Clause relates to powers of...",
  "c": [
   "the press",
   "Congress",
   "state courts only"
  ],
  "a": "Congress"
 },
 {
  "teach": "The legislative branch writes laws.",
  "practice": "Congress debates and passes bills.",
  "q": "The branch that writes laws is...",
  "c": [
   "executive",
   "judicial",
   "legislative"
  ],
  "a": "legislative"
 },
 {
  "teach": "The executive branch enforces laws.",
  "practice": "The president leads the executive branch nationally.",
  "q": "The branch that enforces laws is...",
  "c": [
   "executive",
   "legislative",
   "judicial"
  ],
  "a": "executive"
 },
 {
  "teach": "The judicial branch interprets laws and resolves cases.",
  "practice": "Federal courts are part of the judicial branch.",
  "q": "The branch that interprets laws is...",
  "c": [
   "executive",
   "judicial",
   "legislative"
  ],
  "a": "judicial"
 },
 {
  "teach": "Impeachment is a constitutional process for accusing certain officials of serious misconduct.",
  "practice": "The House impeaches; the Senate tries the case.",
  "q": "Which chamber brings impeachment charges?",
  "c": [
   "Supreme Court",
   "Cabinet",
   "House of Representatives"
  ],
  "a": "House of Representatives"
 },
 {
  "teach": "The Senate confirms many presidential appointments.",
  "practice": "This is a check on executive power.",
  "q": "Senate confirmation is a check on the...",
  "c": [
   "executive branch",
   "weather service",
   "local school club"
  ],
  "a": "executive branch"
 },
 {
  "teach": "A veto lets the president reject a bill.",
  "practice": "Congress can override a veto with enough votes.",
  "q": "A presidential veto rejects a...",
  "c": [
   "court opinion",
   "bill",
   "state border"
  ],
  "a": "bill"
 },
 {
  "teach": "The Bill of Rights was added to protect individual liberties.",
  "practice": "It helped answer fears that the new Constitution gave too much power.",
  "q": "The Bill of Rights protects...",
  "c": [
   "only tax rules",
   "weather forecasts",
   "individual liberties"
  ],
  "a": "individual liberties"
 },
 {
  "teach": "The First Amendment protects speech, religion, press, assembly, and petition.",
  "practice": "These freedoms support civic participation.",
  "q": "Which is protected by the First Amendment?",
  "c": [
   "petition",
   "counterfeiting",
   "speeding"
  ],
  "a": "petition"
 },
 {
  "teach": "The Fourth Amendment protects against unreasonable searches and seizures.",
  "practice": "Warrants require legal standards.",
  "q": "The Fourth Amendment concerns searches and...",
  "c": [
   "elections",
   "seizures",
   "tariffs"
  ],
  "a": "seizures"
 },
 {
  "teach": "The Fifth Amendment includes due process protections.",
  "practice": "It also protects against self-incrimination.",
  "q": "Due process is connected to fair legal...",
  "c": [
   "decorations",
   "weather",
   "procedures"
  ],
  "a": "procedures"
 },
 {
  "teach": "The Sixth Amendment protects rights of accused people in criminal trials.",
  "practice": "It includes the right to counsel and a speedy public trial.",
  "q": "The Sixth Amendment focuses on criminal...",
  "c": [
   "trials",
   "budgets",
   "foreign treaties"
  ],
  "a": "trials"
 },
 {
  "teach": "The Tenth Amendment supports federalism.",
  "practice": "Powers not delegated to the United States are reserved to the states or the people.",
  "q": "The Tenth Amendment is especially connected to...",
  "c": [
   "naval battles",
   "federalism",
   "map scales"
  ],
  "a": "federalism"
 },
 {
  "teach": "Due process limits how government may take life, liberty, or property.",
  "practice": "Government must follow fair legal steps.",
  "q": "Due process requires fair...",
  "c": [
   "private guesses",
   "rumors",
   "legal steps"
  ],
  "a": "legal steps"
 },
 {
  "teach": "Equal protection requires government to apply laws fairly.",
  "practice": "It is part of the Fourteenth Amendment.",
  "q": "Equal protection means laws must be applied...",
  "c": [
   "fairly",
   "randomly",
   "only at night"
  ],
  "a": "fairly"
 },
 {
  "teach": "Civil liberties are protections against government interference.",
  "practice": "Speech and religion are common examples.",
  "q": "Civil liberties protect against improper government...",
  "c": [
   "road repair",
   "interference",
   "weather"
  ],
  "a": "interference"
 },
 {
  "teach": "Civil rights involve equal treatment under the law.",
  "practice": "Voting rights and equal protection are civil rights topics.",
  "q": "Civil rights concern equal...",
  "c": [
   "temperature",
   "currency",
   "treatment"
  ],
  "a": "treatment"
 },
 {
  "teach": "A precedent is a legal example used in later cases.",
  "practice": "Courts may follow precedent for consistency.",
  "q": "A precedent is a legal...",
  "c": [
   "example",
   "tax",
   "election"
  ],
  "a": "example"
 },
 {
  "teach": "Majority opinion explains the decision of most justices in a case.",
  "practice": "It gives the court's controlling reasoning.",
  "q": "A majority opinion reflects the view of...",
  "c": [
   "no justices",
   "most justices",
   "only reporters"
  ],
  "a": "most justices"
 },
 {
  "teach": "A dissenting opinion disagrees with the majority.",
  "practice": "Dissents can influence future legal thinking.",
  "q": "A dissenting opinion...",
  "c": [
   "counts votes only",
   "signs bills",
   "disagrees"
  ],
  "a": "disagrees"
 },
 {
  "teach": "A reliable civic source should be evaluated for author, date, evidence, and purpose.",
  "practice": "Source checking helps avoid weak claims.",
  "q": "Which is best for source evaluation?",
  "c": [
   "author, date, evidence, purpose",
   "font color only",
   "whether it is short"
  ],
  "a": "author, date, evidence, purpose"
 },
 {
  "teach": "Bias is a leaning that may affect how information is presented.",
  "practice": "Recognizing bias helps evaluate arguments.",
  "q": "Bias can affect how information is...",
  "c": [
   "measured in inches",
   "presented",
   "stored in a desk"
  ],
  "a": "presented"
 },
 {
  "teach": "A claim is a statement someone argues is true.",
  "practice": "Evidence should support a claim.",
  "q": "A claim should be supported by...",
  "c": [
   "volume",
   "decor",
   "evidence"
  ],
  "a": "evidence"
 },
 {
  "teach": "A counterclaim is an opposing argument.",
  "practice": "Good civic reasoning can compare claims and counterclaims.",
  "q": "A counterclaim is an...",
  "c": [
   "opposing argument",
   "extra branch",
   "official holiday"
  ],
  "a": "opposing argument"
 },
 {
  "teach": "Public policy is a government plan or action addressing a public problem.",
  "practice": "Tax policy, road policy, and safety rules are examples.",
  "q": "Public policy addresses public...",
  "c": [
   "snacks",
   "problems",
   "bedtimes only"
  ],
  "a": "problems"
 },
 {
  "teach": "A stakeholder is someone affected by an issue or policy.",
  "practice": "Residents and businesses may be stakeholders in a road project.",
  "q": "A stakeholder is someone...",
  "c": [
   "who holds only money",
   "who writes every law",
   "affected by an issue"
  ],
  "a": "affected by an issue"
 },
 {
  "teach": "Costs and benefits help evaluate policy choices.",
  "practice": "A new road may cost money but improve travel.",
  "q": "Policy choices can be weighed by costs and...",
  "c": [
   "benefits",
   "rhymes",
   "secret codes"
  ],
  "a": "benefits"
 },
 {
  "teach": "A civic problem may have tradeoffs.",
  "practice": "One solution may help some goals but create costs.",
  "q": "A tradeoff means choosing one thing may require giving up...",
  "c": [
   "nothing ever",
   "another",
   "the Constitution"
  ],
  "a": "another"
 },
 {
  "teach": "Local governments often handle zoning, roads, police, fire, and local ordinances.",
  "practice": "These services affect daily life.",
  "q": "Which is often a local government issue?",
  "c": [
   "declaring war",
   "printing money",
   "zoning"
  ],
  "a": "zoning"
 },
 {
  "teach": "State governments handle many issues within state borders.",
  "practice": "Licensing, state courts, and state roads are examples.",
  "q": "State governments mainly work within...",
  "c": [
   "state borders",
   "foreign nations",
   "only one home"
  ],
  "a": "state borders"
 },
 {
  "teach": "National government handles issues that affect the whole country.",
  "practice": "Defense, immigration law, and interstate commerce are national issues.",
  "q": "Which is usually national?",
  "c": [
   "one city park schedule",
   "interstate commerce",
   "a household chore"
  ],
  "a": "interstate commerce"
 },
 {
  "teach": "Civic participation can include voting, petitioning, attending meetings, volunteering, and contacting officials.",
  "practice": "Citizens can participate lawfully in many ways.",
  "q": "Which is civic participation?",
  "c": [
   "destroying records",
   "spreading rumors",
   "contacting officials"
  ],
  "a": "contacting officials"
 },
 {
  "teach": "A citizen's duty differs from a voluntary responsibility.",
  "practice": "Obeying laws is required; volunteering is voluntary.",
  "q": "Which is usually required?",
  "c": [
   "obeying laws",
   "volunteering at every event",
   "joining every club"
  ],
  "a": "obeying laws"
 },
 {
  "teach": "Jury service helps ordinary citizens participate in justice.",
  "practice": "Juries evaluate evidence and facts.",
  "q": "Jury service connects citizens to the...",
  "c": [
   "weather system",
   "justice system",
   "postal route"
  ],
  "a": "justice system"
 },
 {
  "teach": "Civic virtue includes habits like honesty, courage, self-control, and concern for the common good.",
  "practice": "A free society depends on responsible citizens.",
  "q": "Which is a civic virtue?",
  "c": [
   "bribery",
   "carelessness",
   "honesty"
  ],
  "a": "honesty"
 },
 {
  "teach": "The common good refers to conditions that benefit the community broadly.",
  "practice": "Clean water and public safety can serve the common good.",
  "q": "The common good benefits...",
  "c": [
   "the community broadly",
   "only one person secretly",
   "no one"
  ],
  "a": "the community broadly"
 },
 {
  "teach": "Compromise can help resolve conflict, but it should not violate basic rights.",
  "practice": "Not every issue can be solved by simply splitting the difference.",
  "q": "A good compromise should not violate...",
  "c": [
   "calendar dates",
   "basic rights",
   "weather patterns"
  ],
  "a": "basic rights"
 },
 {
  "teach": "Civil discourse means discussing public issues respectfully and with reasons.",
  "practice": "It does not require agreement, but it does require self-control.",
  "q": "Civil discourse should be respectful and...",
  "c": [
   "insulting",
   "secret",
   "reasoned"
  ],
  "a": "reasoned"
 },
 {
  "teach": "A constitution creates a framework for government.",
  "practice": "It explains structure, powers, limits, and rights.",
  "q": "A constitution provides a government...",
  "c": [
   "framework",
   "recipe",
   "weather chart"
  ],
  "a": "framework"
 },
 {
  "teach": "An informed citizen uses evidence before forming a civic opinion.",
  "practice": "Good citizenship includes learning before deciding.",
  "q": "An informed citizen should use...",
  "c": [
   "rumors only",
   "evidence",
   "random guesses"
  ],
  "a": "evidence"
 }
]);
})();
