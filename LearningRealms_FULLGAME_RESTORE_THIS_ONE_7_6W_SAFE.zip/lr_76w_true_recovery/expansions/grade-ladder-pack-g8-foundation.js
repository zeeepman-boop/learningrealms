// Grade Ladder Pack G8: Grade 8 Foundation
// Tagged with gradeBand:"G8" for the Grade Ladder system.
// Future-ready band for when caps are raised.
// Curriculum only. No engine/world changes.

function LR_addG8Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G8",unit:"G8-READ-ANALYSIS",skill:"central idea and development",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A central idea is the main point of a text, and development is how the author builds that idea.",
     workedExample:"If a passage argues that preparation prevents failure, the author may develop that idea with examples, facts, and consequences.",
     guidedPractice:"Find the main point first, then look for how the author supports it.",
     q:"How does an author develop a central idea?",
     c:["with details, examples, and evidence","with random words only","by hiding the topic"],a:"with details, examples, and evidence",
     explain:"Authors develop central ideas by adding support such as details, examples, and evidence."},

    {gradeBand:"G8",unit:"G8-READ-ANALYSIS",skill:"analyzing theme",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A theme can be developed through conflict, character choices, and consequences.",
     workedExample:"If a character chooses truth over comfort and later earns trust, the theme may involve integrity.",
     guidedPractice:"Track what the character chooses and what happens because of it.",
     q:"A character tells the truth even though it costs him comfort. Which theme fits?",
     c:["Integrity can require sacrifice.","Graphs show data.","Rivers cause erosion."],a:"Integrity can require sacrifice.",
     explain:"The character sacrifices comfort for truth, which supports a theme about integrity."},

    {gradeBand:"G8",unit:"G8-READ-ARGUMENT",skill:"argument analysis",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Argument analysis looks at claims, reasons, evidence, and whether the evidence is strong enough.",
     workedExample:"A claim without evidence is weak. A claim supported by facts, examples, or reliable sources is stronger.",
     guidedPractice:"Ask what the author wants you to believe and what proof is given.",
     q:"A strong argument needs a claim plus...",
     c:["reasons and evidence","only a title","unrelated details"],a:"reasons and evidence",
     explain:"Reasons and evidence support the claim and make the argument stronger."},

    {gradeBand:"G8",unit:"G8-READ-SOURCES",skill:"conflicting information",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Different sources may present conflicting information because of purpose, evidence, bias, or perspective.",
     workedExample:"One source may praise a leader while another criticizes him. You compare evidence, authorship, purpose, and context.",
     guidedPractice:"Do not pick the louder source. Compare support and reliability.",
     q:"When sources conflict, what should you compare?",
     c:["evidence, purpose, and reliability","font size only","which one is shorter"],a:"evidence, purpose, and reliability",
     explain:"Comparing evidence, purpose, and reliability helps judge conflicting sources."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G8",unit:"G8-MATH-EQUATIONS",skill:"linear equations",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A linear equation can be solved by using inverse operations and keeping both sides balanced.",
     workedExample:"3x + 7 = 22. Subtract 7 to get 3x = 15. Divide by 3 to get x = 5.",
     guidedPractice:"Undo addition or subtraction first, then undo multiplication or division.",
     q:"3x + 7 = 22. What is x?",
     c:["5","15","29"],a:"5",
     explain:"Subtract 7, then divide 15 by 3 to get 5."},

    {gradeBand:"G8",unit:"G8-MATH-FUNCTIONS",skill:"slope",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Slope is the rate of change of a line.",
     workedExample:"From (1,2) to (4,11), y changes by 9 and x changes by 3. Slope is 9 divided by 3, which is 3.",
     guidedPractice:"Find change in y, then change in x, then divide.",
     q:"What is the slope from (1,2) to (4,11)?",
     c:["3","9","4"],a:"3",
     explain:"The change in y is 9 and the change in x is 3, so the slope is 3."},

    {gradeBand:"G8",unit:"G8-MATH-FUNCTIONS",skill:"slope-intercept form",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Slope-intercept form is y = mx + b.",
     workedExample:"In y = 2x + 5, the slope is 2 and the y-intercept is 5.",
     guidedPractice:"Find m for slope and b for y-intercept.",
     q:"In y = 2x + 5, what is the y-intercept?",
     c:["5","2","7"],a:"5",
     explain:"In y = mx + b, b is the y-intercept. Here b is 5."},

    {gradeBand:"G8",unit:"G8-MATH-GEOMETRY",skill:"Pythagorean theorem",difficulty:"grade 8",mode:"foundation",
     miniLesson:"The Pythagorean theorem works with right triangles.",
     workedExample:"If the legs are 9 and 12, then 9² + 12² = 81 + 144 = 225. The square root of 225 is 15.",
     guidedPractice:"Square both legs, add them, then take the square root.",
     q:"A right triangle has legs 9 and 12. What is the hypotenuse?",
     c:["15","21","13"],a:"15",
     explain:"81 + 144 = 225, and the square root of 225 is 15."},

    {gradeBand:"G8",unit:"G8-MATH-SYSTEMS",skill:"systems of equations",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A system of equations has a solution that makes both equations true.",
     workedExample:"If y = x + 4 and y = 10, then x must be 6 because 6 + 4 = 10.",
     guidedPractice:"Substitute the known value into the other equation.",
     q:"If y = x + 4 and y = 10, what is x?",
     c:["6","10","4"],a:"6",
     explain:"10 = x + 4, so x = 6."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G8",unit:"G8-ELA-ARGUMENT",skill:"thesis and claim",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A thesis is the main claim of an argument or essay.",
     workedExample:"The town should repair the bridge because it improves safety and trade is a thesis because it states a clear position and reasons.",
     guidedPractice:"Choose the statement that makes a defendable argument.",
     q:"Which is a thesis?",
     c:["The bridge should be repaired because it improves safety and trade.","The bridge is made of stone.","There is a bridge."],a:"The bridge should be repaired because it improves safety and trade.",
     explain:"It states a clear position and gives reasons."},

    {gradeBand:"G8",unit:"G8-ELA-ARGUMENT",skill:"counterclaim and rebuttal",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A counterclaim gives the opposing view. A rebuttal answers it.",
     workedExample:"Counterclaim: Repairs cost too much. Rebuttal: The cost is lower than the danger of a collapse.",
     guidedPractice:"Answer the other side directly.",
     q:"A rebuttal responds to the...",
     c:["counterclaim","title","setting"],a:"counterclaim",
     explain:"A rebuttal directly answers the opposing view."},

    {gradeBand:"G8",unit:"G8-ELA-RESEARCH",skill:"source credibility",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Source credibility depends on author expertise, evidence, purpose, date, and reliability.",
     workedExample:"A current article by a qualified author using clear evidence is usually stronger than an anonymous page with no sources.",
     guidedPractice:"Ask who made it, why, when, and what proof it gives.",
     q:"Which helps judge source credibility?",
     c:["author, date, purpose, and evidence","page color only","paragraph length only"],a:"author, date, purpose, and evidence",
     explain:"Those details help determine whether a source should be trusted."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G8",unit:"G8-SCI-MATTER",skill:"atoms",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Atoms are tiny particles that make up matter.",
     workedExample:"Atoms contain protons, neutrons, and electrons. Protons are positive, neutrons are neutral, and electrons are negative.",
     guidedPractice:"Remember that electrons carry negative charge.",
     q:"Which particle has a negative charge?",
     c:["electron","proton","neutron"],a:"electron",
     explain:"Electrons are negatively charged particles."},

    {gradeBand:"G8",unit:"G8-SCI-MATTER",skill:"physical and chemical changes",difficulty:"grade 8",mode:"foundation",
     miniLesson:"A physical change changes form or appearance without making a new substance. A chemical change creates a new substance.",
     workedExample:"Melting ice is physical. Rusting iron is chemical.",
     guidedPractice:"Ask whether a new substance formed.",
     q:"Rusting iron is a...",
     c:["chemical change","physical change","text structure"],a:"chemical change",
     explain:"Rusting creates a new substance, so it is a chemical change."},

    {gradeBand:"G8",unit:"G8-SCI-FORCE",skill:"Newton's second law",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Newton's second law connects force, mass, and acceleration.",
     workedExample:"F = ma. If mass increases and acceleration stays the same, more force is needed.",
     guidedPractice:"Use the formula force equals mass times acceleration.",
     q:"Newton's second law is...",
     c:["F = ma","y = mx + b","C = πd"],a:"F = ma",
     explain:"F = ma means force equals mass times acceleration."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G8",unit:"G8-SS-CIVICS",skill:"separation of powers",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Separation of powers divides government authority among branches.",
     workedExample:"The legislative branch makes laws, the executive branch carries them out, and the judicial branch interprets them.",
     guidedPractice:"Match each branch to its role.",
     q:"Which branch makes laws?",
     c:["legislative","judicial","executive only"],a:"legislative",
     explain:"The legislative branch makes laws."},

    {gradeBand:"G8",unit:"G8-SS-CIVICS",skill:"checks and balances",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Checks and balances allow branches of government to limit each other.",
     workedExample:"A court may review whether a law follows the Constitution. This checks the power of lawmakers.",
     guidedPractice:"Ask which branch is limiting another.",
     q:"Checks and balances help limit government...",
     c:["power","weather","multiplication"],a:"power",
     explain:"Checks and balances keep power from becoming too concentrated."},

    {gradeBand:"G8",unit:"G8-SS-ECON",skill:"opportunity cost",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Opportunity cost is the next best option given up when making a choice.",
     workedExample:"If a town uses stone to build a wall instead of a bridge, the bridge is the opportunity cost.",
     guidedPractice:"Ask what was given up.",
     q:"Opportunity cost means what you...",
     c:["give up","always gain","never consider"],a:"give up",
     explain:"Opportunity cost is the option given up when a choice is made."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G8",unit:"G8-ART-PERSPECTIVE",skill:"one-point perspective",difficulty:"grade 8",mode:"foundation",
     miniLesson:"One-point perspective uses a single vanishing point to create depth.",
     workedExample:"A road may appear to narrow toward one point on the horizon.",
     guidedPractice:"Find where receding lines appear to meet.",
     q:"In one-point perspective, receding lines meet at the...",
     c:["vanishing point","color wheel","signature"],a:"vanishing point",
     explain:"The vanishing point is where receding lines appear to come together."},

    {gradeBand:"G8",unit:"G8-ART-DESIGN",skill:"visual analysis",difficulty:"grade 8",mode:"foundation",
     miniLesson:"Visual analysis explains how art choices affect meaning.",
     workedExample:"Dark colors, sharp lines, and empty space may create a tense or lonely mood.",
     guidedPractice:"Use details you can see in the artwork.",
     q:"Good art analysis should use...",
     c:["visual evidence","random guessing","only the frame"],a:"visual evidence",
     explain:"Visual evidence is based on what can be seen in the artwork."}
  ]);
}

LR_addG8Foundation("Luna");
LR_addG8Foundation("Ava");
LR_addG8Foundation("Michael");
