/* LearningRealms Dynamic Shell Hardening 6.8A
   Stability-only patch. Keeps the dynamic adventure screen as the one true normal screen,
   hardens travel/actions against old UI layers, and adds descriptive learning-path shortcuts.
*/
(function(){
  'use strict';
  if(window.__LR68A_DYNAMIC_SHELL_HARDENING__) return;
  window.__LR68A_DYNAMIC_SHELL_HARDENING__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function clean(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){
    try{ if(window.state) return window.state; }catch(e){}
    try{ if(typeof state !== 'undefined' && state) return state; }catch(e){}
    return null;
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined' && ROOMS) return ROOMS; }catch(e){}
    return {};
  }
  function loc(){ var s=getState(); return (s && s.loc) ? s.loc : 'crossroads'; }
  function room(id){
    var rooms = getRooms();
    var key = id || loc();
    try{ if(!id && typeof window.room === 'function') return window.room() || rooms[key] || {}; }catch(e){}
    try{ if(!id && typeof room === 'function') return room() || rooms[key] || {}; }catch(e){}
    return rooms[key] || rooms.crossroads || {};
  }
  function call(name){
    var args = Array.prototype.slice.call(arguments,1);
    try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR68A call failed', name, e); }
    try{ if(typeof eval(name) === 'function') return eval(name).apply(window,args); }catch(e){}
    return undefined;
  }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }
  function hidePopup(){ try{ var root=byId('lrPopupRoot'); if(root) root.classList.add('hidden'); }catch(e){} }
  function popupOpen(){ try{ var root=byId('lrPopupRoot'); return root && !root.classList.contains('hidden'); }catch(e){ return false; } }
  function popupTitle(){ try{ var t=byId('lrPopupTitle'); return t ? String(t.textContent || '') : ''; }catch(e){ return ''; } }

  function ensureMount(){
    try{
      document.body.classList.add('lr68DynamicShell','lr68aHardening','lrDynamicAdventureMode');
      document.body.classList.remove('homeMode');
    }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var first = document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; }
      if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen lr68aScreen';
      if(first && first.firstChild) first.insertBefore(mount, first.firstChild);
      else (first || document.body).appendChild(mount);
    }
    mount.classList.add('lr68aScreen');
    mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none';
    return mount;
  }

  function suppressLegacySurfaces(){
    var ids = ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','movementControls','leftActionButtons'];
    ids.forEach(function(id){
      var el=byId(id);
      if(el){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
    });
    try{
      document.querySelectorAll('.compassBox,.compassGrid,.movementButtons,.travelButtons,.tinyTravelFooter,.lrAdventurePanel,.lrExplorePanel,.lr65ExplorePanel,.lr67ChoicePanelClone,.lr66AdventureChoices,.lrNavRestorePanel').forEach(function(el){
        if(el && !el.closest('#lrDynamicAdventureScreen')){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
      });
    }catch(e){}
    try{
      var first=document.querySelector('.main > .card:first-child');
      if(first){
        Array.from(first.children).forEach(function(el){
          if(el && el.id !== 'lrDynamicAdventureScreen' && !el.closest('#lrDynamicAdventureScreen')){
            if(el.id === 'roomTitle' || el.id === 'roomText' || el.id === 'mainCompassNav' || el.id === 'mainGameplayActions'){
              el.style.display='none';
            }
          }
        });
      }
    }catch(e){}
  }

  function isHub(){
    var id = loc();
    var r = room();
    var z = String((r && r.zone) || '').toLowerCase();
    return id === 'crossroads' || id === 'townSquare' || id === 'home' || /town|home/.test(z);
  }

  var pathDestinations = [
    {label:'Reading Woods', desc:'Follow the birch road toward story clues, careful reading, and proof from the text.', target:'whisperwood'},
    {label:'Math Iron Hills', desc:'Take the stone road toward gears, numbers, measuring, and problem solving.', target:'ironGate'},
    {label:'Science Marsh', desc:'Walk the creek road toward observation, nature evidence, weather, and experiments.', target:'crystalMarsh'},
    {label:'Writing and Archives', desc:'Climb the lantern road toward records, writing, history, and source clues.', target:'archiveRoad'},
    {label:'Civics Citadel', desc:'Travel to the banner road for rules, responsibility, service, and fair decisions.', target:'councilRoad1'},
    {label:'Geography Expanse', desc:'Step onto the mapmaker road for places, routes, landforms, and map skills.', target:'mapmakerRoad1'},
    {label:'Merchant Row', desc:'Enter the coinstone lane for choices, saving, trade, needs, wants, and value.', target:'merchantRoad1'},
    {label:'Logic Spire', desc:'Head to the puzzle road for evidence, reasoning, patterns, and careful thinking.', target:'puzzleRoad1'},
    {label:'Nature Preserve', desc:'Follow the wildroot trail for plants, animals, habitats, and safe outdoor observation.', target:'wildrootRoad1'},
    {label:'Health Clinic', desc:'Visit Hearthwell for safe lessons on food, rest, movement, hygiene, and body systems.', target:'hearthwellRoad1'},
    {label:'Music Hall', desc:'Step through Bardwood Gate for rhythm, sound, instruments, and listening skills.', target:'bardwoodGate'},
    {label:'Copywork Abbey', desc:'Go to the scribe road for handwriting, careful copying, and language practice.', target:'scribeRoad1'},
    {label:'Life Skills Workshop', desc:'Travel to Homestead Workshop for practical habits, chores, planning, and useful skills.', target:'homesteadRoad1'}
  ];
  var courseDestinations = [
    {label:'Shipwreck Cove Guided Tour', desc:'Open the foggy maritime tour with lighthouse guides, wreck evidence, pirates, legends, rescue, and safety.', fn:'shipwreckGuidedZoneOpen'},
    {label:'Shipwreck Cove Deep Course', desc:'Open the thick maritime history course map directly.', fn:'openShipwreckCoveDeepCourse'},
    {label:'Inventions and Engineering', desc:'Open prototypes, machines, bridges, flight, computers, failures, redesign, and safety culture.', fn:'openInventionsDeepCourse'},
    {label:'Creative Studio', desc:'Open drawing, painting, craft, pattern, theater, music, story making, and gallery practice.', fn:'openCreativeStudioCourse'}
  ];

  function pathCard(d){
    if(d.target && !getRooms()[d.target]) return '';
    if(d.fn && typeof window[d.fn] !== 'function') return '';
    var click = d.target ? "lr68aGoTo('" + esc(d.target) + "')" : "lr68aOpenCourse('" + esc(d.fn) + "')";
    return '<button type="button" class="lr68aPathCard" onclick="' + click + '"><b>' + esc(d.label) + '</b><small>' + esc(d.desc) + '</small></button>';
  }

  function appendPathPanel(){
    try{
      var mount = ensureMount();
      if(!mount || mount.querySelector('[data-lr68a-path-panel]')) return;
      if(!isHub()) return;
      var roomCards = pathDestinations.map(pathCard).filter(Boolean).join('');
      var courseCards = courseDestinations.map(pathCard).filter(Boolean).join('');
      if(!roomCards && !courseCards) return;
      var section = document.createElement('section');
      section.className = 'lr68aPathPanel';
      section.setAttribute('data-lr68a-path-panel','1');
      section.innerHTML = '<div class="lr68aPanelTitle"><span>Learning trails from here</span><small>These are descriptive travel choices, not a static map.</small></div>' +
        (roomCards ? '<div class="lr68aPathGrid"><h3>Realm roads</h3>' + roomCards + '</div>' : '') +
        (courseCards ? '<div class="lr68aPathGrid lr68aCourseGrid"><h3>Special courses</h3>' + courseCards + '</div>' : '');
      var bottom = mount.querySelector('.lr68BottomBar');
      if(bottom) mount.insertBefore(section, bottom);
      else mount.appendChild(section);
    }catch(e){ console.warn('LR68A path panel failed', e); }
  }

  function afterRender(){
    ensureMount();
    suppressLegacySurfaces();
    appendPathPanel();
  }

  function baseRender(mode, note){
    try{
      var fn = window.__LR68A_BASE_RENDER__;
      if(typeof fn === 'function') return fn(mode, note);
    }catch(e){}
    try{ if(window.LR68 && typeof window.LR68.render === 'function') return window.LR68.render(mode, note); }catch(e){}
    try{ if(typeof window.lr68Render === 'function') return window.lr68Render(mode, note); }catch(e){}
    return false;
  }

  function hardRender(mode, note){
    var out = false;
    try{ out = baseRender(mode || 'room', note); }catch(e){ console.warn('LR68A base render failed', e); }
    setTimeout(afterRender, 20);
    setTimeout(afterRender, 120);
    return out;
  }
  hardRender.__lr68aWrapped = true;

  function resolveTarget(keyOrTarget){
    var rooms=getRooms();
    var r=room();
    var exits=(r && r.exits) || {};
    if(exits[keyOrTarget]) return {target:exits[keyOrTarget], key:keyOrTarget};
    if(rooms[keyOrTarget]) return {target:keyOrTarget, key:''};
    return {target:null,key:keyOrTarget};
  }
  function destinationNote(target){
    var r=room(target);
    var title=clean((r && r.title) || target);
    var zone=clean((r && r.zone) || '');
    var subj=clean((r && r.subject) || '');
    if(target === 'home') return 'You return to Home Hearth. The home rooms, pets, storage, and collections stay inside the main adventure screen.';
    if(/shop|market|row|diner|tent/i.test(title + ' ' + zone)) return 'You walk toward ' + title + '. If this place has shelves, the shop opens from the main screen without a separate navigation pile.';
    if(subj) return 'You travel to ' + title + '. This is a ' + subj + ' learning area, so the lesson button is available right in the scene.';
    return 'You travel to ' + title + (zone ? ' in ' + zone : '') + '.';
  }
  function goTo(target){
    try{
      var rooms=getRooms();
      if(!rooms[target]){ hardRender('room','That path is not loaded yet.'); return false; }
      var s=getState();
      if(s){ s.loc=target; s.room=Math.max(1,Number(s.room||1))+1; }
      try{ call('recordGameFunEvent','roomVisits',1,{room:target}); }catch(e){}
      try{ var lb=byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
      try{ var sb=byId('storageBox'); if(sb) sb.classList.add('hidden'); }catch(e){}
      save(); stats();
      hardRender('room', destinationNote(target));
      return false;
    }catch(e){ hardRender('room','That travel choice was blocked: ' + (e.message || e)); return false; }
  }
  function hardTravel(keyOrTarget){
    var r=resolveTarget(keyOrTarget);
    if(!r.target){ hardRender('room','No path opens that way yet. Choose one of the story choices on the screen.'); return false; }
    return goTo(r.target);
  }
  hardTravel.__lr68aWrapped = true;

  function openCourse(fnName){
    try{
      if(typeof window[fnName] === 'function'){
        document.body.classList.add('lrBigLessonPopup','lr68BigLessonPopup','lr68aBigPopup');
        window[fnName]();
        setTimeout(afterRender,80);
        return false;
      }
    }catch(e){ hardRender('room','That course could not open: ' + (e.message || e)); return false; }
    hardRender('room','That course is not loaded yet.');
    return false;
  }

  function wrapMainAction(name, title){
    try{
      var old = window[name];
      if(typeof old !== 'function' || old.__lr68aWrapped) return;
      var wrapped = function(){
        var out;
        try{ out = old.apply(this, arguments); }catch(e){ hardRender('room',(title || name) + ' was blocked: ' + (e.message || e)); return false; }
        setTimeout(function(){
          try{
            var t = popupTitle();
            if(popupOpen() && !/lesson|quiz|reward|course|shipwreck|invention|creative|guided|learning/i.test(t)) hidePopup();
          }catch(e){}
          try{ if(window.LR68 && typeof window.LR68.embed === 'function') window.LR68.embed(title || name); }
          catch(e){ hardRender('room'); }
          setTimeout(afterRender,40);
        }, 35);
        return out;
      };
      wrapped.__lr68aWrapped = true;
      window[name] = wrapped;
      try{ eval(name + ' = window["' + name + '"];'); }catch(e){}
    }catch(e){}
  }

  function installActionBridges(){
    ['openHomeView','lrSafeStorageChest','chest','openCollectionLog','openCompanionDen','openWorldAtlas','openQuestBoard','openQuestJournal','lrSafeOpenQuestJournal','openLongQuestJournal','openStoryQuestJournal','openStoryCampaigns','openCastlePrestige','openSeasonalCalendar','openSeasonHall','openSeasonQuests','openSeasonalVendor','openSeasonalSearch','openHomeDecor','openHomeRooms','openLivingHome','openVisibleHome','openVisualHome','openHomeExpansion2','openHomePlacement','openWardrobe','openInventoryPopup','openBackpack','openAchievementsJournal','openAchievementJournal','openPetJournal','lrSafeOpenPetJournal','openMuseumHall','openMuseumRenderer','openCraftingRenderer','openCraftingStation','openJourneyWorld','openWorldDirectory','openLandmarkJournal','openStudentJournal','openEventLog','openReportCenter','openMasteryPaths','openAdaptiveReview','openBossGauntlets','showMasteryStatus','startBossChallenge','openSystemHealth','openNpcRelations','openInvestigationBoard','openShopHub'].forEach(function(n){ wrapMainAction(n, n.replace(/^open|^lrSafe|Renderer$/g,'').replace(/([A-Z])/g,' $1').trim() || n); });

    if(typeof window.lrOpenActionPopup === 'function' && !window.lrOpenActionPopup.__lr68aWrapped){
      if(!window.__LR68A_OLD_ACTION_POPUP__) window.__LR68A_OLD_ACTION_POPUP__ = window.lrOpenActionPopup;
      var ap = function(title){
        try{
          if(/lesson|quiz|reward|course|learning/i.test(String(title || ''))){ return window.__LR68A_OLD_ACTION_POPUP__.apply(this, arguments); }
          setTimeout(function(){ hidePopup(); if(window.LR68 && typeof window.LR68.embed === 'function') window.LR68.embed(title || 'Action'); afterRender(); }, 20);
        }catch(e){ hardRender('room'); }
        return false;
      };
      ap.__lr68aWrapped = true;
      window.lrOpenActionPopup = ap;
      try{ lrOpenActionPopup = ap; }catch(e){}
    }

    if(typeof window.lr67RenderShopScene === 'function'){
      window.lr68aOpenShop = function(){ return window.lr67RenderShopScene(); };
      window.openShop = window.lr68aOpenShop;
      try{ openShop = window.lr68aOpenShop; }catch(e){}
      window.lrSafeBrowseShopPopup = window.lr68aOpenShop;
      try{ lrSafeBrowseShopPopup = window.lr68aOpenShop; }catch(e){}
    }
  }

  function installRouting(){
    if(typeof window.lr68Render === 'function' && !window.lr68Render.__lr68aWrapped){
      window.__LR68A_BASE_RENDER__ = window.lr68Render;
    }
    window.lr68Render = hardRender;
    window.lr67RenderDynamicScreen = hardRender;
    try{ lr68Render = hardRender; }catch(e){}
    try{ lr67RenderDynamicScreen = hardRender; }catch(e){}
    if(window.LR68){ window.LR68.render = hardRender; }

    window.lr68Travel = hardTravel;
    window.lr67ChoosePath = hardTravel;
    window.lrAdventureChoiceGo = hardTravel;
    window.lrNavRestoreGo = hardTravel;
    window.go = hardTravel;
    try{ lr68Travel = hardTravel; }catch(e){}
    try{ lr67ChoosePath = hardTravel; }catch(e){}
    try{ lrAdventureChoiceGo = hardTravel; }catch(e){}
    try{ lrNavRestoreGo = hardTravel; }catch(e){}
    try{ go = hardTravel; }catch(e){}

    window.lr68aGoTo = goTo;
    window.lr68aOpenCourse = openCourse;
  }

  function injectStyles(){
    if(byId('lr68aHardeningStyle')) return;
    var st=document.createElement('style');
    st.id='lr68aHardeningStyle';
    st.textContent = `
      body.lr68aHardening main{grid-template-columns:minmax(0,1fr) 270px !important;}
      body.lr68aHardening .actionSidebar, body.lr68aHardening .rightSidebar{display:none !important;}
      body.lr68aHardening .main{width:100% !important;max-width:none !important;min-width:0 !important;}
      body.lr68aHardening .main > .card:first-child{width:100% !important;max-width:none !important;overflow:hidden !important;}
      body.lr68aHardening #roomTitle, body.lr68aHardening #roomText, body.lr68aHardening #mainCompassNav, body.lr68aHardening #mainGameplayActions, body.lr68aHardening #leftActionButtons{display:none !important;visibility:hidden !important;}
      body.lr68aHardening .compassBox:not(#lrDynamicAdventureScreen *), body.lr68aHardening .movementButtons:not(#lrDynamicAdventureScreen *), body.lr68aHardening .travelButtons:not(#lrDynamicAdventureScreen *){display:none !important;visibility:hidden !important;}
      body.lr68aHardening #lrDynamicAdventureScreen{display:block !important;visibility:visible !important;opacity:1 !important;width:100% !important;max-width:none !important;min-height:650px !important;}
      .lr68aPathPanel{padding:18px 26px;border-top:1px solid rgba(255,227,160,.18);background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(0,0,0,.08));}
      .lr68aPanelTitle{display:flex;align-items:end;justify-content:space-between;gap:10px;margin-bottom:12px;color:#fff4ce;}
      .lr68aPanelTitle span{font-weight:950;font-size:1.08rem;}.lr68aPanelTitle small{color:#d9e5c9;font-weight:780;}
      .lr68aPathGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px;margin:0 0 16px;}.lr68aPathGrid h3{grid-column:1/-1;color:#ffe8a4;margin:2px 0 2px;font-size:.98rem;letter-spacing:.02em;}
      .lr68aPathCard{width:100% !important;text-align:left !important;display:flex !important;flex-direction:column !important;gap:5px !important;border-radius:16px !important;border:1px solid rgba(255,227,160,.38) !important;background:rgba(255,250,226,.94) !important;color:#17352d !important;padding:12px 13px !important;box-shadow:0 8px 16px rgba(0,0,0,.20) !important;cursor:pointer !important;}
      .lr68aPathCard b{font-size:.98rem;line-height:1.2;}.lr68aPathCard small{font-size:.82rem;line-height:1.32;color:#526860;font-weight:800;}
      .lr68aCourseGrid .lr68aPathCard{background:linear-gradient(135deg,#fff6d8,#eaf7ff) !important;}
      body.lr68aBigPopup .lrPopupWindow{width:min(1160px,95vw) !important;max-height:93vh !important;}
      body.lr68aBigPopup .lrPopupBody{max-height:79vh !important;font-size:1.08rem !important;line-height:1.62 !important;}
      @media(max-width:950px){body.lr68aHardening main{grid-template-columns:1fr !important;}.lr68aPanelTitle{align-items:flex-start;flex-direction:column;}.lr68aPathPanel{padding-left:16px;padding-right:16px;}.lr68aPathGrid{grid-template-columns:1fr;}}
    `;
    document.head.appendChild(st);
  }

  function harden(){
    injectStyles();
    ensureMount();
    suppressLegacySurfaces();
    installRouting();
    installActionBridges();
    appendPathPanel();
    try{
      var mount=byId('lrDynamicAdventureScreen');
      var bad=!mount || !String(mount.innerHTML || '').trim();
      if(mount && window.getComputedStyle){ var cs=window.getComputedStyle(mount); if(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0') bad=true; }
      if(bad) hardRender('room','The dynamic screen was restored.');
    }catch(e){}
  }

  window.LR68A = {harden:harden, render:hardRender, travel:hardTravel, goTo:goTo, openCourse:openCourse};
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(harden,80); setTimeout(harden,300); });
  else { setTimeout(harden,80); setTimeout(harden,300); }
  window.addEventListener('load', function(){ setTimeout(harden,180); setTimeout(harden,700); });
  if(!window.__LR68A_HARDEN_TIMER__) window.__LR68A_HARDEN_TIMER__ = setInterval(harden,750);
})();
