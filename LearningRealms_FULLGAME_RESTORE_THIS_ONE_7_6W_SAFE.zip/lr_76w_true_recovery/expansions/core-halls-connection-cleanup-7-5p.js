/* LearningRealms 7.5P - Core Halls Connection Cleanup
   Small bridge patch only. No shell rebuild, no render loop, no loading curtain. */
(function(){
  'use strict';

  if(window.__LR75P_CORE_HALLS_CLEANUP__) return;
  window.__LR75P_CORE_HALLS_CLEANUP__ = true;

  var PATCH = '7.5P Core Halls Connection Cleanup';
  var obsInstalled = false;
  var injectTimer = null;

  function $(id){ return document.getElementById(id); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"]/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[ch];
    });
  }
  function smallText(v, max){
    var s = String(v || '').replace(/\s+/g, ' ').trim();
    if(!max || s.length <= max) return s;
    return s.slice(0, max - 1).trim() + '…';
  }
  function callFirst(names){
    for(var i=0;i<names.length;i++){
      var fn = names[i];
      if(has(fn)){
        window[fn]();
        scheduleInject();
        return true;
      }
    }
    return false;
  }
  function actionMount(title, html){
    var titleEl = $('actionTitle');
    var textEl = $('actionText');
    if(titleEl) titleEl.textContent = title || 'Core Halls';
    if(textEl) textEl.innerHTML = html || '';
    try{
      if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title || 'Core Halls');
    }catch(e){}
    scheduleInject();
  }

  var ROADS = [
    {
      key:'core', icon:'🏰', title:'Core Halls Adventure',
      place:'Main Core Halls',
      body:'Walk the central halls where reading, writing, math, logic, and word work connect like rooms in one large learning keep.',
      openers:['openCoreHallsNoFillerAdventure74N','openCoreHallsAdventure74N']
    },
    {
      key:'reading', icon:'📖', title:'Reading Comprehension Master Course',
      place:'Lantern Library',
      body:'Enter the reading road for story details, evidence, inference, main idea, character work, and proof-of-reading challenges.',
      openers:['openReadingComprehensionMasterCourse75C','openReadingComprehensionMasterCourse','openReadingComprehension','openReadingHallMaster','openLanternLibrary']
    },
    {
      key:'writing', icon:'✍️', title:'Writing Composition Master Course',
      place:'Author Guild',
      body:'Open the writing road for sentence craft, paragraph building, composition, revision, and clear written answers.',
      openers:['openWritingCompositionMasterCourse','openWritingCompositionMaster74W','openAuthorGuild']
    },
    {
      key:'math', icon:'🔢', title:'Math Adventure Master Course',
      place:'Number Vault',
      body:'Open the math road for number sense, fractions, geometry, equations, and older math practice drawers.',
      openers:['openMathAdventureMasterCourse75D','openMathAdventureMasterCourse','openMathAdventure','openNumberVault']
    },
    {
      key:'logic', icon:'🧩', title:'Logic Tower & Critical Thinking',
      place:'Logic Tower',
      body:'Open the logic road for patterns, sequences, careful reasoning, evidence, clues, and problem solving.',
      openers:['openLogicTowerCriticalThinking75E','openLogicTowerMasterCourse','openLogicTower','openCriticalThinking']
    },
    {
      key:'language', icon:'🛠️', title:'Grammar, Vocabulary & Language Forge',
      place:'Language Forge',
      body:'Open the word-work road for grammar, vocabulary, editing, roots, prefixes, suffixes, and spelling support.',
      openers:['openGrammarVocabularyLanguageForge75F','openLanguageForge','openWordForge','openGrammarWorkshop','openVocabularyMasterCourse','openGrammarMasterCourse']
    }
  ];

  var DRAWERS = {
    reading:{
      icon:'📚', title:'Reading Scroll Drawer',
      note:'Older reading practice, story forest lessons, proof details, character work, plot work, inference, and main idea practice.',
      include:/story|reading|library|character|plot|infer|main idea|text|fiction|nonfiction|poetry/i,
      empty:'The older Reading drawer did not find loose lessons yet. Use the Lantern Library master road for the richer reading path.',
      buttons:[['Open Lantern Library','road:reading']]
    },
    writing:{
      icon:'🖋️', title:'Writing Practice Drawer',
      note:'Older writing practice, sentence building, paragraph work, composition, grammar, punctuation, and revision.',
      include:/writing|sentence|paragraph|essay|author|grammar|punctuation|revision|composition/i,
      empty:'The older Writing drawer did not find loose lessons yet. Use the Author Guild master road for the connected writing path.',
      buttons:[['Open Author Guild','road:writing']]
    },
    math:{
      icon:'🔢', title:'Math Practice Drawer',
      note:'Older math practice across counting, fractions, geometry, equations, number sense, decimals, ratios, and algebra readiness.',
      include:/count|number|fraction|geometry|equation|decimal|ratio|algebra|place value|area|volume|budget/i,
      empty:'The older Math drawer did not find loose lessons yet. Use the Number Vault master road or the smaller math drawers below.',
      buttons:[['Open Number Vault','road:math'],['Counting Orchard','drawer:counting:0'],['Fraction Castle','drawer:fractions:0'],['Geometry Caverns','drawer:geometry:0'],['Equation Forge','drawer:equations:0']]
    },
    logic:{
      icon:'🧠', title:'Logic Practice Drawer',
      note:'Older logic and critical-thinking practice: patterns, sequences, clue work, reasoning, evidence, and careful choices.',
      include:/logic|pattern|sequence|reason|clue|critical|argument|evidence/i,
      empty:'The older Logic drawer did not find loose lessons yet. Use Logic Tower for the connected critical-thinking path.',
      buttons:[['Open Logic Tower','road:logic']]
    },
    language:{
      icon:'🔤', title:'Grammar & Vocabulary Drawer',
      note:'Older language practice connected to grammar, vocabulary, punctuation, sentence editing, roots, prefixes, and suffixes.',
      include:/grammar|vocabulary|word|prefix|suffix|root|punctuation|sentence|editing|language/i,
      empty:'The older Grammar/Vocabulary drawer did not find loose lessons yet. Use the Language Forge for the stronger word-work path.',
      buttons:[['Open Language Forge','road:language']]
    },
    copywork:{
      icon:'📜', title:'Copywork & Handwriting Drawer',
      note:'Copywork, scribe-style handwriting, careful sentence copying, neatness, and quiet written practice.',
      include:/copywork|scribe|abbey|handwriting|copy/i,
      empty:'No loose copywork lessons were found in the old bank. This drawer stays visible as an in-world signpost to Writing and Language Forge.',
      buttons:[['Open Author Guild','road:writing'],['Open Language Forge','road:language']]
    },
    spelling:{
      icon:'🧾', title:'Spelling & Word Study Drawer',
      note:'Spelling is now routed through Language Forge and the older word-study style practice bank instead of living as a loose stand-alone button.',
      include:/spelling|spell|phonics|syllable|word study|prefix|suffix|root|vocabulary|language|word/i,
      empty:'No separate spelling course was found. Spelling and word study now live inside the Language Forge, with extra support from Copywork.',
      buttons:[['Open Language Forge','road:language'],['Copywork Drawer','drawer:copywork:0']]
    },
    counting:{
      icon:'🍎', title:'Counting Orchard Drawer',
      note:'Older number-sense lessons for counting, place value, comparing, early operations, and foundation math.',
      include:/counting_orchard|count|number sense|place value|compare|addition|subtraction/i,
      empty:'No Counting Orchard lessons were found loose. Use Number Vault for the connected math path.',
      buttons:[['Open Number Vault','road:math']]
    },
    fractions:{
      icon:'🏰', title:'Fraction Castle Drawer',
      note:'Older fraction lessons for parts, wholes, equivalent fractions, comparing, adding, subtracting, and fraction reasoning.',
      include:/fraction_castle|fraction|denominator|numerator|equivalent/i,
      empty:'No Fraction Castle lessons were found loose. Use Number Vault for the connected math path.',
      buttons:[['Open Number Vault','road:math']]
    },
    geometry:{
      icon:'💎', title:'Geometry Caverns Drawer',
      note:'Older geometry lessons for shapes, angles, area, volume, perimeter, and spatial reasoning.',
      include:/geometry_caverns|geometry|shape|angle|area|volume|perimeter/i,
      empty:'No Geometry Caverns lessons were found loose. Use Number Vault for the connected math path.',
      buttons:[['Open Number Vault','road:math']]
    },
    equations:{
      icon:'⚙️', title:'Equation Forge Drawer',
      note:'Older equation and algebra-readiness lessons for variables, expressions, equations, inequalities, and careful solving.',
      include:/equation_forge|equation|variable|algebra|inequality|expression/i,
      empty:'No Equation Forge lessons were found loose. Use Number Vault for the connected math path.',
      buttons:[['Open Number Vault','road:math']]
    }
  };

  function roadByKey(key){
    for(var i=0;i<ROADS.length;i++) if(ROADS[i].key === key) return ROADS[i];
    return null;
  }
  function roadButton(r){
    return '<button class="lr75pCard" data-lr75p-act="road:' + esc(r.key) + '">' +
      '<b>' + esc(r.icon + ' ' + r.title) + '</b>' +
      '<small>' + esc(r.place) + '</small>' +
      '<span>' + esc(r.body) + '</span>' +
    '</button>';
  }
  function drawerButton(key){
    var d = DRAWERS[key];
    if(!d) return '';
    return '<button class="lr75pCard lr75pDrawerCard" data-lr75p-act="drawer:' + esc(key) + ':0">' +
      '<b>' + esc(d.icon + ' ' + d.title) + '</b>' +
      '<small>Connected legacy practice drawer</small>' +
      '<span>' + esc(d.note) + '</span>' +
    '</button>';
  }
  function navButton(label, act){
    return '<button class="lr75pSmallBtn" data-lr75p-act="' + esc(act) + '">' + esc(label) + '</button>';
  }

  function renderCoreMap(){
    installStyles();
    actionMount('🏰 Core Halls Connected Map',
      '<div class="lr75pShell">' +
        '<div class="lr75pHero">' +
          '<div><b>🏰 Core Halls Connected Map</b><p>This is not a new course. It is a tidy connection map for the core learning center so Reading, Writing, Math, Logic, Grammar/Vocabulary, Copywork, Spelling, old grade ladders, and older practice drawers all have a safe place to go.</p></div>' +
          '<div class="lr75pHeroBtns">' +
            navButton('Realm Library','library') + navButton('7.5O Connection Ledger','ledger') +
          '</div>' +
        '</div>' +
        '<h3>Master roads</h3>' +
        '<div class="lr75pGrid lr75pRoadGrid">' + ROADS.map(roadButton).join('') + '</div>' +
        '<h3>Connected practice drawers</h3>' +
        '<div class="lr75pGrid">' + ['reading','writing','math','logic','language','copywork','spelling'].map(drawerButton).join('') + '</div>' +
        '<h3>Old math chambers and grade ladders</h3>' +
        '<div class="lr75pGrid">' + ['counting','fractions','geometry','equations'].map(drawerButton).join('') +
          '<button class="lr75pCard lr75pDrawerCard" data-lr75p-act="gradeLadder"><b>🪜 Old Grade Ladders</b><small>Connected checkpoint map</small><span>Shows the existing grade ladder bands, child caps, reward gates, and routes back into the proper core roads.</span></button>' +
        '</div>' +
        '<p class="lr75pFoot">7.5P only connects and labels Core Halls routes. It does not rebuild the shell or add a big new course.</p>' +
      '</div>'
    );
  }

  function openRoad(key){
    var r = roadByKey(key);
    if(!r){ renderCoreMap(); return; }
    if(callFirst(r.openers)) return;
    softNote(r.title, 'This road is listed in the Core Halls map, but its opener is not present in this build. The route stays as an in-world signpost instead of turning into a dead button.', [['Back to Core Halls Map','map']]);
  }

  function lessonText(l){
    return [l.source_pack,l.pack_region,l.region,l.mastery_tag,l.topic,l.skill,l.question,l.explanation].join(' ');
  }
  function lessonMatches(l, drawer){
    if(!drawer || !drawer.include) return false;
    return drawer.include.test(lessonText(l));
  }
  async function getBank(){
    if(has('lrLoadRealCurriculumBank')){
      try{ return await window.lrLoadRealCurriculumBank(); }catch(e){}
    }
    return window.__lrRealCurriculumBank || [];
  }
  async function renderDrawer(key, page){
    installStyles();
    var d = DRAWERS[key];
    if(!d){ renderCoreMap(); return; }
    page = Math.max(0, parseInt(page || 0, 10) || 0);
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75pShell"><div class="lr75pHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>Searching the existing lesson bank for connected older Core Halls practice. No new course is being added.</p></div></div><p class="lr75pFoot">Loading connected drawer…</p></div>'
    );
    var bank = await getBank();
    var matches = (bank || []).filter(function(l){ return lessonMatches(l, d); });
    var per = 12;
    var pages = Math.max(1, Math.ceil(matches.length / per));
    if(page >= pages) page = pages - 1;
    var sample = matches.slice(page * per, page * per + per);
    if(!sample.length){
      actionMount(d.icon + ' ' + d.title,
        '<div class="lr75pShell">' +
          '<div class="lr75pHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p></div></div>' +
          '<div class="lr75pNote"><b>In-world route note</b><p>' + esc(d.empty) + '</p><div class="lr75pInlineBtns">' + (d.buttons || [['Back to Core Halls Map','map']]).map(function(b){ return navButton(b[0], b[1]); }).join('') + navButton('Back to Core Halls Map','map') + '</div></div>' +
        '</div>'
      );
      return;
    }
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75pShell">' +
        '<div class="lr75pHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p><p><small>' + matches.length + ' connected lesson' + (matches.length === 1 ? '' : 's') + ' found in the existing bank.</small></p></div><div class="lr75pHeroBtns">' + navButton('Core Map','map') + '</div></div>' +
        '<div class="lr75pLessonList">' + sample.map(function(l){
          var idx = bank.indexOf(l);
          return '<button class="lr75pLesson" data-lr75p-act="lesson:' + idx + '"><b>' + esc(l.region || l.pack_region || 'Core lesson') + '</b><small>' + esc(l.mastery_tag || l.source_pack || 'practice') + '</small><span>' + esc(smallText(l.question || l.explanation || '', 170)) + '</span></button>';
        }).join('') + '</div>' +
        '<div class="lr75pPager">' + (page > 0 ? navButton('← Previous','drawer:' + key + ':' + (page - 1)) : '') + '<span>Page ' + (page + 1) + ' of ' + pages + '</span>' + (page < pages - 1 ? navButton('Next →','drawer:' + key + ':' + (page + 1)) : '') + '</div>' +
      '</div>'
    );
  }

  function renderGradeLadder(){
    installStyles();
    var ladder = window.LR_GRADE_LADDER || {};
    var rewards = window.LR_GRADE_LADDER_REWARDS || {};
    var order = Array.isArray(ladder.order) ? ladder.order : [];
    var display = ladder.display || {};
    var starts = ladder.startBand || {};
    var caps = ladder.currentCaps || {};
    var bandRewards = rewards.bandRewards || {};
    var childNames = ['Luna','Ava','Michael'];
    var childRows = childNames.map(function(name){
      return '<tr><td>' + esc(name) + '</td><td>' + esc(display[starts[name]] || starts[name] || 'not set') + '</td><td>' + esc(display[caps[name]] || caps[name] || 'not set') + '</td></tr>';
    }).join('');
    var bandRows = order.map(function(code){
      var br = bandRewards[code] || {};
      var reward = br.item || br.badge || br.title || '';
      return '<tr><td>' + esc(code) + '</td><td>' + esc(display[code] || code) + '</td><td>' + esc(reward || 'existing checkpoint band') + '</td></tr>';
    }).join('');
    actionMount('🪜 Old Grade Ladders',
      '<div class="lr75pShell">' +
        '<div class="lr75pHero"><div><b>🪜 Old Grade Ladders</b><p>The old grade ladder data stays connected as a checkpoint map. It points back into the main Core Halls roads instead of becoming a loose menu.</p></div><div class="lr75pHeroBtns">' + navButton('Core Map','map') + '</div></div>' +
        '<h3>Child ladder caps</h3><table class="lr75pTable"><thead><tr><th>Child</th><th>Start band</th><th>Current cap</th></tr></thead><tbody>' + (childRows || '<tr><td colspan="3">No child ladder caps were found.</td></tr>') + '</tbody></table>' +
        '<h3>Existing grade bands</h3><table class="lr75pTable"><thead><tr><th>Code</th><th>Band</th><th>Reward hook</th></tr></thead><tbody>' + (bandRows || '<tr><td colspan="3">No ladder bands were found.</td></tr>') + '</tbody></table>' +
        '<div class="lr75pInlineBtns">' + navButton('Reading Drawer','drawer:reading:0') + navButton('Writing Drawer','drawer:writing:0') + navButton('Math Drawer','drawer:math:0') + navButton('Logic Drawer','drawer:logic:0') + '</div>' +
      '</div>'
    );
  }

  function softNote(title, body, buttons){
    installStyles();
    buttons = buttons || [['Back to Core Halls Map','map']];
    actionMount(title || 'Core Halls Note',
      '<div class="lr75pShell"><div class="lr75pNote"><b>' + esc(title || 'Core Halls Note') + '</b><p>' + esc(body || '') + '</p><div class="lr75pInlineBtns">' + buttons.map(function(b){ return navButton(b[0], b[1]); }).join('') + '</div></div></div>'
    );
  }

  function openLesson(idx){
    idx = parseInt(idx, 10);
    if(!isFinite(idx) || idx < 0){ softNote('Lesson route note','That older lesson pointer was not available.', [['Back to Core Halls Map','map']]); return; }
    if(has('lrOpenRealLessonByIndex')){
      window.lrOpenRealLessonByIndex(idx);
      setTimeout(function(){
        var at = $('actionText');
        if(!at) return;
        var backBtns = at.querySelectorAll('button');
        for(var i=0;i<backBtns.length;i++){
          if(/Back to REAL Curriculum/i.test(backBtns[i].textContent || '')){
            backBtns[i].setAttribute('data-lr75p-act','map');
            backBtns[i].removeAttribute('onclick');
            backBtns[i].textContent = 'Back to Core Halls Map';
          }
        }
      }, 80);
      return;
    }
    softNote('Lesson route note','The authored lesson opener was not available in this build.', [['Back to Core Halls Map','map']]);
  }

  function handleAct(act){
    if(!act) return;
    if(act === 'map'){ renderCoreMap(); return; }
    if(act === 'library'){
      if(has('openRealmLibrary75A')){ window.openRealmLibrary75A('core'); scheduleInject(); return; }
      if(has('openRealCurriculumPicker')){ window.openRealCurriculumPicker('all'); scheduleInject(); return; }
      renderCoreMap(); return;
    }
    if(act === 'ledger'){
      if(has('openLearningCenterAnnex75O')){ window.openLearningCenterAnnex75O('core'); scheduleInject(); return; }
      if(has('openLearningCenterConnectionAudit75O')){ window.openLearningCenterConnectionAudit75O(); scheduleInject(); return; }
      renderCoreMap(); return;
    }
    if(act === 'gradeLadder'){ renderGradeLadder(); return; }
    if(act.indexOf('road:') === 0){ openRoad(act.split(':')[1]); return; }
    if(act.indexOf('drawer:') === 0){
      var bits = act.split(':');
      renderDrawer(bits[1], bits[2] || 0);
      return;
    }
    if(act.indexOf('lesson:') === 0){ openLesson(act.split(':')[1]); return; }
  }

  function installStyles(){
    if($('lr75pStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr75pStyles';
    st.textContent =
      '.lr75pShell{padding:14px;color:#2b1d12}.lr75pHero{display:flex;gap:12px;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#fff6d8,#ffe7b0);border:2px solid #b98731;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 8px 20px rgba(80,45,10,.16)}' +
      '.lr75pHero b{font-size:1.18rem}.lr75pHero p{margin:.35rem 0 0}.lr75pHeroBtns,.lr75pInlineBtns{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.lr75pGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px;margin:10px 0 18px}.lr75pCard,.lr75pLesson{display:block;text-align:left;width:100%;border:2px solid #8c642b;background:#fffaf0;border-radius:14px;padding:12px;cursor:pointer;color:#251609;box-shadow:0 4px 10px rgba(60,35,10,.10)}' +
      '.lr75pCard:hover,.lr75pLesson:hover,.lr75pSmallBtn:hover{transform:translateY(-1px);filter:brightness(1.03)}.lr75pCard b,.lr75pLesson b{display:block;margin-bottom:4px}.lr75pCard small,.lr75pLesson small{display:block;color:#704d1c;margin-bottom:6px}.lr75pCard span,.lr75pLesson span{display:block;line-height:1.32}.lr75pDrawerCard{background:#f7fff7;border-color:#5f8f56}.lr75pSmallBtn{border:2px solid #704d1c;background:#fffaf0;border-radius:999px;padding:8px 11px;cursor:pointer;color:#251609;font-weight:700}.lr75pNote{background:#fffaf0;border:2px dashed #9b6a28;border-radius:14px;padding:14px;margin:12px 0}.lr75pLessonList{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}.lr75pPager{display:flex;gap:10px;align-items:center;justify-content:center;margin:14px 0;flex-wrap:wrap}.lr75pFoot{color:#704d1c}.lr75pTable{width:100%;border-collapse:collapse;background:#fffaf0;border-radius:12px;overflow:hidden;margin:8px 0 16px}.lr75pTable th,.lr75pTable td{border:1px solid #c39a55;padding:8px;text-align:left}.lr75pTable th{background:#ffe7b0}' +
      '.lr75pAuditDoor{border-color:#6d4aa6!important;background:linear-gradient(135deg,#f2ecff,#fff7d6)!important}.lr75pLibraryTiny{font-size:.84rem;color:#5d3e17;margin-top:4px;display:block}';
    document.head.appendChild(st);
  }

  function libraryCard(id, title, small, body, act, className){
    var btn = document.createElement('button');
    btn.id = id;
    btn.className = className || 'lr75aDoorCard lr75pAuditDoor';
    btn.setAttribute('data-lr75p-act', act);
    btn.innerHTML = '<b>' + esc(title) + '</b><small class="lr75pLibraryTiny">' + esc(small) + '</small><span>' + esc(body) + '</span>';
    return btn;
  }
  function hasText(node, re){
    return re.test((node && node.textContent) || '');
  }
  function addCard(grid, id, re, title, small, body, act){
    if(!grid || $(id) || (re && hasText(grid, re))) return;
    grid.appendChild(libraryCard(id, title, small, body, act));
  }
  function injectIntoRealmLibrary(root){
    var grid = root.querySelector('.lr75aDoorGrid');
    if(!grid || !/Core Halls/i.test(root.textContent || '')) return;
    if(!$('lr75pCoreConnectedMapDoor')){
      grid.insertBefore(libraryCard('lr75pCoreConnectedMapDoor','🏰 Core Halls Connected Map','Reading · Writing · Math · Logic · Grammar · Copywork · Spelling · Grade ladders','A safe connection map for every Core Halls road and older drawer; no new course added.','map'), grid.firstChild);
    }
    addCard(grid,'lr75pReadingRoadDoor',/Reading Comprehension Master Course/i,'📖 Reading Comprehension Master Course','Lantern Library','Opens the richer reading road with proof-of-reading challenge work.','road:reading');
    addCard(grid,'lr75pMathRoadDoor',/Math Adventure Master Course/i,'🔢 Math Adventure Master Course','Number Vault','Opens the richer math road and keeps old math drawers connected.','road:math');
    addCard(grid,'lr75pLogicRoadDoor',/Logic Tower|Critical Thinking/i,'🧩 Logic Tower & Critical Thinking','Logic Tower','Opens the connected reasoning, pattern, clue, and evidence road.','road:logic');
    addCard(grid,'lr75pLanguageRoadDoor',/Grammar, Vocabulary|Language Forge/i,'🛠️ Grammar, Vocabulary & Language Forge','Language Forge','Opens grammar, vocabulary, editing, roots, prefixes, suffixes, and spelling support.','road:language');
    addCard(grid,'lr75pCopyworkDoor',/Copywork|Handwriting/i,'📜 Copywork & Handwriting Drawer','legacy drawer','Keeps copywork and careful handwriting routed inside Core Halls.','drawer:copywork:0');
    addCard(grid,'lr75pSpellingDoor',/Spelling|Word Study/i,'🧾 Spelling & Word Study Drawer','legacy drawer','Routes spelling into Language Forge and older word-study practice instead of leaving a stray button.','drawer:spelling:0');
    addCard(grid,'lr75pGradeLadderDoor',/Grade Ladder|Grade Ladders/i,'🪜 Old Grade Ladders','checkpoint map','Shows the existing grade ladder bands and routes them back into the core roads.','gradeLadder');
  }
  function injectIntoAnnex(root){
    if(!/Core Halls Annex|Core Halls/i.test(root.textContent || '')) return;
    if($('lr75pAnnexMapStrip')) return;
    var target = root.querySelector('.lr75oHero,.lr75oWingHero,.lr75oShell') || root.firstElementChild || root;
    if(!target || !target.parentNode) return;
    var strip = document.createElement('div');
    strip.id = 'lr75pAnnexMapStrip';
    strip.className = 'lr75pNote';
    strip.innerHTML = '<b>🏰 7.5P Core Halls cleanup</b><p>Core Halls now has one connected map for master roads, spelling, copywork, grade ladders, and older drawers.</p><div class="lr75pInlineBtns">' + navButton('Open Core Halls Connected Map','map') + navButton('Spelling & Word Study','drawer:spelling:0') + navButton('Grade Ladders','gradeLadder') + '</div>';
    target.parentNode.insertBefore(strip, target.nextSibling);
  }
  function injectIntoCoreAdventure(root){
    if(!/Core Halls|Reading|Writing|Math|Logic/i.test(root.textContent || '')) return;
    var grid = root.querySelector('.core74Grid,.lr74nGrid,.lr74Grid,.lrCourseDoorGrid');
    if(!grid || $('lr75pCoreAdventureMapDoor')) return;
    var btn = libraryCard('lr75pCoreAdventureMapDoor','🏰 Core Halls Connected Map','cleanup map','Jump to the tidy 7.5P map for master roads, spelling, copywork, grade ladders, and old drawers.','map','lr75pCard lr75pAuditDoor');
    grid.insertBefore(btn, grid.firstChild);
  }
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(runInject, 80);
  }
  function runInject(){
    installStyles();
    var root = $('actionText');
    if(!root) return;
    injectIntoRealmLibrary(root);
    injectIntoAnnex(root);
    injectIntoCoreAdventure(root);
  }

  function wrap(name){
    if(!has(name) || window[name].__lr75pWrapped) return;
    var old = window[name];
    var wrapped = function(){
      var out = old.apply(this, arguments);
      scheduleInject();
      setTimeout(scheduleInject, 250);
      return out;
    };
    wrapped.__lr75pWrapped = true;
    window[name] = wrapped;
  }
  function bind(){
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr75p-act]') : null;
      if(!btn) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAct(btn.getAttribute('data-lr75p-act'));
    }, true);
  }
  function installObserver(){
    if(obsInstalled) return;
    obsInstalled = true;
    var target = $('actionText');
    if(!target || typeof MutationObserver === 'undefined') return;
    var mo = new MutationObserver(function(){ scheduleInject(); });
    mo.observe(target, {childList:true, subtree:false});
  }
  function init(){
    installStyles();
    bind();
    ['openRealmLibrary75A','openRealCurriculumPicker','openLearningCenterAnnex75O','openLearningCenterConnectionAudit75O','openCoreHallsNoFillerAdventure74N','openCoreHallsAdventure74N'].forEach(wrap);
    installObserver();
    setTimeout(scheduleInject, 250);
    window.LR_CORE_HALLS_CONNECTION_CLEANUP_75P = { patch:PATCH, open:renderCoreMap, drawers:DRAWERS, roads:ROADS };
  }

  window.openCoreHallsConnectionCleanup75P = renderCoreMap;
  window.openCoreHallsCleanup75P = renderCoreMap;
  window.openCoreHallsLearningCenter75P = renderCoreMap;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
