/* LearningRealms Startup + Button Stability 7.4X
   Conservative repair: remove render-watchdog leftovers, keep one stable RPG shell,
   add safe aliases for major course buttons, and prevent visible buttons from failing silently.
*/
(function(){
  'use strict';
  if(window.__LR74X_STARTUP_BUTTON_STABILITY__) return;
  window.__LR74X_STARTUP_BUTTON_STABILITY__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root||document).querySelector(sel); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); return true; }
    catch(e){ console.warn('LR74X route failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var r=list[i];
      if(Array.isArray(r)){ if(call.apply(null,r)) return true; }
      else if(call(r)) return true;
    }
    return false;
  }
  function writePanel(title, html){
    var t=byId('actionTitle'), b=byId('actionText');
    if(t) t.textContent=title || 'Learning Realms';
    if(b) b.innerHTML=html || '<div class="journalPage"><p>The path is ready.</p></div>';
    if(has('lrOpenActionPopup')){ try{ window.lrOpenActionPopup(title || 'Learning Realms'); }catch(e){} }
    else if(has('lrOpenPopup')){ try{ window.lrOpenPopup(title || 'Learning Realms', html || ''); }catch(e){} }
  }
  function stableRoute(act){
    act = String(act||'atlas').toLowerCase().replace(/[^a-z0-9]/g,'');
    if(act==='atlas'||act==='map'||act==='realmmap'||act==='learn'||act==='golearn') return first([['openLearningRealmsRealmAtlas74K'],['lr73pDo','atlas'],['lr73mDo','map'],['openLearningRealmsRealmAtlas']]) || fallbackAtlas();
    if(act==='scene'||act==='room') return first([['renderRoom']]) || fallbackAtlas();
    if(act==='home'||act==='homestead') return first([['openHomesteadWorkshopAdventure74O'],['openHomeRooms'],['openHomeViewPopup'],['openHomeView'],['openHomeRenderer'],['openVisualHome']]) || fallbackAtlas();
    if(act==='history'||act==='historywing') return first([['openLearningRealmsHistoryWing74K'],['lr73pDo','history'],['lr73mDo','history']]) || fallbackAtlas();
    if(act==='bible'||act==='bibleroad'||act==='biblehistory') return first([['openLearningRealmsBibleRoad74K'],['lr73pDo','bible'],['lr73mDo','bible']]) || fallbackAtlas();
    if(act==='egypt'||act==='ancientegypt') return first([['openAncientEgyptTrail'],['openAncientEgyptCourse'],['openLearningRealmsEgyptRoad'],['openLearningRealmsEgypt']]) || stableRoute('history');
    if(act==='egyptroyal') return first([['openAncientEgyptRoyalGallery'],['openAncientEgyptRoyalCourse']]) || stableRoute('egypt');
    if(act==='egyptworld') return first([['openAncientEgyptWorldExpansion'],['openAncientEgyptWorldCourse']]) || stableRoute('egypt');
    if(act==='depression'||act==='greatdepression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || stableRoute('history');
    if(act==='wildwest') return first([['openWildWestTrail'],['openWildWestCourse']]) || stableRoute('history');
    if(act==='shipwreck'||act==='shipwreckcove') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['openShipwreckCoveMap']]) || stableRoute('history');
    if(act==='england'||act==='kingsqueens') return first([['openEnglandKingsQueens74Q'],['openEnglandKingsQueensRoad74Q']]) || stableRoute('history');
    if(act==='geography'||act==='mapmakers') return first([['openMapmakersLoft74P'],['openHistoryWorldSupportAdventure74P']]) || stableRoute('history');
    if(act==='civics'||act==='civichall') return first([['openCivicHall74P'],['openHistoryWorldSupportAdventure74P']]) || stableRoute('history');
    if(act==='economics'||act==='marketsquare') return first([['openMarketSquare74P'],['openHistoryWorldSupportAdventure74P']]) || stableRoute('history');
    if(act==='science'||act==='sciencequarter'||act==='scienceengineering') return first([['openScienceEngineeringAdventure74M'],['openScienceEngineeringQuarter74M'],['lr73pDo','science']]) || fallbackAtlas();
    if(act==='inventions'||act==='engineering') return first([['openInventionsEngineeringMaster74R'],['openInventionsEngineeringDisasters74R'],['openInventionsDeepCourse']]) || stableRoute('science');
    if(act==='aerospace'||act==='aerospacemaster') return first([['openAerospaceEngineering74S'],['openAerospaceEngineering'],['openAerospaceDeepCourse']]) || stableRoute('science');
    if(act==='nature'||act==='naturehealth') return first([['openNatureHealthDeepAdventure'],['openNatureHealth74T'],['openNatureAndHealth']]) || stableRoute('science');
    if(act==='weather'||act==='weatherstorm') return first([['openWeatherStormLab74U'],['openWeatherStormLab'],['openStormwatchTower']]) || stableRoute('science');
    if(act==='animal'||act==='animals'||act==='creature'||act==='creatures'||act==='creaturefieldguide') return first([['openCreatureFieldGuide'],['openAnimalKingdom74V'],['openAnimalKingdom']]) || stableRoute('science');
    if(act==='core'||act==='corehalls'||act==='coreadventure') return first([['openCoreHallsNoFillerAdventure74N'],['openCoreHallsAdventure74N'],['lr73pDo','core']]) || fallbackAtlas();
    if(act==='writing'||act==='writingmaster'||act==='composition') return first([['openWritingCompositionMasterCourse'],['openWritingCompositionMaster74W'],['openAuthorGuild']]) || stableRoute('core');
    if(act==='creative'||act==='creativequarter'||act==='creativeadventure') return first([['openCreativeQuarterAdventure74O'],['openCreativeHomesteadAdventure74O'],['lr73pDo','creative']]) || fallbackAtlas();
    if(act==='livingworld'||act==='townnotice'||act==='noticeboard'||act==='ledger'||act==='worldledger') return first([['openLivingWorldLedger74L']]) || fallbackAtlas();
    if(act==='items'||act==='collection'||act==='collectionlog') return first([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openAchievementJournal']]) || fallbackAtlas();
    if(act==='pets'||act==='companions'||act==='companionden') return first([['openCompanionDen'],['openPetJournal'],['openCompanionPopup']]) || fallbackAtlas();
    if(act==='quests'||act==='questboard') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openStoryQuestJournal']]) || fallbackAtlas();
    return fallbackAtlas();
  }
  window.lr74xRoute = stableRoute;

  function fallbackAtlas(){
    writePanel('Realm Atlas', '<div class="lessonCard"><div class="lessonCardTitle">🗺️ Realm Atlas</div><div class="lessonCardText">The stable router is active. Use the command window for Core Halls, Science Quarter, History Wing, Bible Road, Homestead, Collections, Companions, and Quests.</div></div>');
    return true;
  }

  // Safe travelHome override. The older build accidentally trapped several old UI patches inside travelHome().
  window.travelHome = function(){
    try{ if(window.state){ window.state.loc = 'home'; window.state.room = Math.max(1, Number(window.state.room||1))+1; } }catch(e){}
    try{ if(has('save')) window.save(); }catch(e){}
    return stableRoute('homestead');
  };
  try{ travelHome = window.travelHome; }catch(e){}

  // Lightweight aliases for older buttons/menus.
  var aliases = {
    openLearningRealmsStableAtlas74X:function(){ return stableRoute('atlas'); },
    openHistoryWing:function(){ return stableRoute('history'); },
    openBibleRoad:function(){ return stableRoute('bible'); },
    openEgyptRoad:function(){ return stableRoute('egypt'); },
    openScienceQuarter:function(){ return stableRoute('science'); },
    openWritingRoad:function(){ return stableRoute('writing'); },
    openTownNoticeBoard:function(){ return stableRoute('livingworld'); },
    openSafeHome:function(){ return stableRoute('homestead'); }
  };
  Object.keys(aliases).forEach(function(k){ if(!window[k]) window[k]=aliases[k]; });

  function clearOldTimers(){
    ['__LR68_WATCHDOG_TIMER__','__LR68A_HARDEN_TIMER__','__LR68C_WATCHDOG_TIMER__'].forEach(function(k){
      try{ if(window[k]){ clearInterval(window[k]); window[k]=0; } }catch(e){}
    });
  }

  function removeLegacyMounts(){
    ['lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','lrSidebarDropdownCleanup'].forEach(function(id){
      var el=byId(id); if(el) try{ el.remove(); }catch(e){}
    });
    document.querySelectorAll('.lrOriginalSidebarButtonHidden,.lrLooseButtonHidden,.lrHomeOnlyHidden').forEach(function(el){
      try{ el.classList.remove('lrOriginalSidebarButtonHidden','lrLooseButtonHidden','lrHomeOnlyHidden'); if(el.style && el.style.display==='none') el.style.display=''; }catch(e){}
    });
  }

  function installStyles(){
    if(byId('lr74xStabilityStyles')) return;
    var st=document.createElement('style'); st.id='lr74xStabilityStyles';
    st.textContent = 'body{background:#071412!important;} body.lr74xStableLaunch .lr67Screen,body.lr74xStableLaunch .lr68DynamicScreen,body.lr74xStableLaunch .lr68aScreen,body.lr74xStableLaunch .lr68cScreen{display:none!important} #lrControlDock,#lrFixedGameplayDock,#lrCenterActionDock,#lrCenterGameplayDock,#lrSidebarDropdownCleanup{display:none!important} .lr74xHealth{margin-top:8px;padding:8px;border:1px solid rgba(245,223,154,.18);border-radius:10px;background:rgba(0,0,0,.16);color:#dcefe3;font-size:.78rem;font-weight:800}';
    document.head.appendChild(st);
  }

  function buttonHealthNote(){
    var right = q('.rightSidebar .card');
    if(!right || byId('lr74xHealth')) return;
    var n=document.createElement('div'); n.id='lr74xHealth'; n.className='lr74xHealth';
    n.textContent='Stability mode: one shell active, legacy launch layers disabled.';
    var ledger=q('.lr73mLedger', right); if(ledger) ledger.appendChild(n); else right.appendChild(n);
  }

  function boot(){
    document.body.classList.add('lr74xStableLaunch');
    clearOldTimers(); removeLegacyMounts(); installStyles();
    try{ if(has('lr73mDo')) window.lr73mDo('map'); else if(has('lr73pDo')) window.lr73pDo('atlas'); }catch(e){}
    setTimeout(function(){ clearOldTimers(); removeLegacyMounts(); buttonHealthNote(); },120);
    setTimeout(function(){ clearOldTimers(); removeLegacyMounts(); buttonHealthNote(); },650);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,80); setTimeout(function(){ clearOldTimers(); removeLegacyMounts(); },900); });
})();
