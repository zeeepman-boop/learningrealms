/* LearningRealms Merchant Square & Shopkeeper Goals 6.9
   Adds a dynamic-screen Merchant Square reward economy with many shopkeepers,
   simple themed currencies, goal items, and a daily surprise merchant.
   This is content/system additive: it does not replace lessons, saves, or the dynamic shell.
*/
(function(){
  'use strict';
  if(window.__LR69_MERCHANT_SQUARE__) return;
  window.__LR69_MERCHANT_SQUARE__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function clean(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){ try{ if(window.state) return window.state; }catch(e){} try{ if(typeof state !== 'undefined' && state) return state; }catch(e){} return null; }
  function childName(){ try{ if(window.activeChild) return window.activeChild; }catch(e){} try{ if(typeof activeChild !== 'undefined') return activeChild; }catch(e){} var s=byId('studentSelect'); return (s&&s.value)||'Learner'; }
  function call(name){ var args=[].slice.call(arguments,1); try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR69 call failed', name, e); } try{ if(typeof eval(name) === 'function') return eval(name).apply(window,args); }catch(e){} }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }
  function level(){ try{ if(typeof window.activeLevel === 'function') return window.activeLevel(); }catch(e){} try{ if(typeof activeLevel === 'function') return activeLevel(); }catch(e){} return 1; }
  function todayKey(){ var d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
  function daySeed(extra){ var s=todayKey()+':' + childName() + ':' + (extra || ''); var h=0; for(var i=0;i<s.length;i++){ h=((h<<5)-h)+s.charCodeAt(i); h|=0; } return Math.abs(h); }
  function pick(list, extra){ if(!list || !list.length) return null; return list[daySeed(extra)%list.length]; }

  function ensureMount(){
    try{ document.body.classList.add('lr69MerchantSquareMode','lrDynamicAdventureMode','lr68DynamicShell'); }catch(e){}
    var first=document.querySelector('.main > .card:first-child') || document.querySelector('.main') || document.querySelector('main') || document.body;
    var mount=byId('lrDynamicAdventureScreen');
    if(!mount){ mount=document.createElement('div'); mount.id='lrDynamicAdventureScreen'; mount.className='lrDynamicAdventureScreen lr69Screen'; if(first.firstChild) first.insertBefore(mount, first.firstChild); else first.appendChild(mount); }
    mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none';
    suppressOld();
    return mount;
  }
  function suppressOld(){
    ['lessonBox','storageBox'].forEach(function(id){ var el=byId(id); if(el) el.classList.add('hidden'); });
    ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock'].forEach(function(id){ var el=byId(id); if(el){ el.style.display='none'; el.style.visibility='hidden'; }});
  }
  function renderRoom(note){
    try{ if(typeof window.lr68Render === 'function') return window.lr68Render('room', note || 'You step away from Merchant Square.'); }catch(e){}
    try{ if(window.LR68 && typeof window.LR68.render === 'function') return window.LR68.render('room', note || 'You step away from Merchant Square.'); }catch(e){}
    return false;
  }
  function goHome(){ try{ if(typeof window.lr68OpenHome === 'function') return window.lr68OpenHome(); }catch(e){} try{ if(typeof window.lr68aGoTo === 'function') return window.lr68aGoTo('home'); }catch(e){} return renderRoom('Home is still available from the main scene.'); }
  function goLearn(){ try{ if(typeof window.lr68OpenLearn === 'function') return window.lr68OpenLearn(); }catch(e){} try{ if(typeof window.lr68bOpenLearningTrails === 'function') return window.lr68bOpenLearningTrails('featured'); }catch(e){} return renderRoom('Learning Trails are ready.'); }

  var CURRENCIES = {
    sparks:{icon:'✨', label:'Sparks', type:'profile', key:'sparks'},
    ancientCoins:{icon:'🪙', label:'Ancient Coins', type:'profile', key:'ancientCoins'},
    crowns:{icon:'👑', label:'Learning Crowns', type:'economy', key:'crowns'},
    merchantTickets:{icon:'🎫', label:'Merchant Tickets', key:'merchantTickets'},
    seaGlass:{icon:'🌊', label:'Sea Glass', key:'seaGlass'},
    gearTokens:{icon:'⚙️', label:'Gear Tokens', key:'gearTokens'},
    studioTickets:{icon:'🎟️', label:'Studio Tickets', key:'studioTickets'},
    historySeals:{icon:'🏺', label:'History Seals', key:'historySeals'},
    meritStars:{icon:'⭐', label:'Merit Stars', key:'meritStars'}
  };
  function ensureEconomy(){
    var s=getState(); if(!s) return {currencies:{}, purchases:{}, claims:{}, awards:{}};
    if(!s.lr69Currencies) s.lr69Currencies={merchantTickets:0,seaGlass:0,gearTokens:0,studioTickets:0,historySeals:0,meritStars:0};
    if(!s.lr69Purchases) s.lr69Purchases={};
    if(!s.lr69DailyClaims) s.lr69DailyClaims={};
    if(!s.lr69MasteryAwards) s.lr69MasteryAwards={};
    return {currencies:s.lr69Currencies, purchases:s.lr69Purchases, claims:s.lr69DailyClaims, awards:s.lr69MasteryAwards};
  }
  function oldCrowns(){ try{ if(typeof window.lrEnsureEconomyState === 'function') return window.lrEnsureEconomyState(); }catch(e){} try{ if(typeof lrEnsureEconomyState === 'function') return lrEnsureEconomyState(); }catch(e){} return null; }
  function amount(key){
    var s=getState() || {}; var c=CURRENCIES[key] || CURRENCIES.merchantTickets; var e=ensureEconomy();
    if(c.type === 'profile') return Number(s[c.key] || 0);
    if(c.type === 'economy'){ var econ=oldCrowns(); return Number((econ && econ.crowns) || 0); }
    return Number(e.currencies[c.key] || 0);
  }
  function addCurrency(key, n){
    n = Math.floor(Number(n)||0); if(!n) return;
    var s=getState(); if(!s) return;
    var c=CURRENCIES[key] || CURRENCIES.merchantTickets; var e=ensureEconomy();
    if(c.type === 'profile') s[c.key] = Number(s[c.key] || 0) + n;
    else if(c.type === 'economy'){ var econ=oldCrowns(); if(econ) econ.crowns = Number(econ.crowns || 0) + n; else e.currencies.merchantTickets = Number(e.currencies.merchantTickets || 0) + n; }
    else e.currencies[c.key] = Number(e.currencies[c.key] || 0) + n;
  }
  function spendCurrency(key, n){
    n = Math.floor(Number(n)||0); if(n < 0) return false;
    if(amount(key) < n) return false;
    addCurrency(key, -n);
    return true;
  }
  function labelCurrency(key){ var c=CURRENCIES[key] || CURRENCIES.merchantTickets; return c.icon + ' ' + c.label; }
  function walletHtml(){
    var keys=['sparks','ancientCoins','crowns','merchantTickets','seaGlass','gearTokens','studioTickets','historySeals','meritStars'];
    return '<div class="lr69Wallet">' + keys.map(function(k){ var c=CURRENCIES[k]; return '<span><b>'+esc(c.icon)+'</b> '+esc(c.label)+': <strong>'+esc(amount(k))+'</strong></span>'; }).join('') + '</div>';
  }

  var RARE_POOL = [
    {name:'Fog Lantern of the Old Pier', cost:9, currency:'seaGlass', slot:'shelf', minLevel:1, note:'A rare maritime glow item not carried by the normal Cove shops.'},
    {name:'Blueprint Compass Case', cost:9, currency:'gearTokens', slot:'desk', minLevel:1, note:'A little engineer display piece for inventions and redesign work.'},
    {name:'Golden Gallery Label Frame', cost:9, currency:'studioTickets', slot:'wall', minLevel:1, note:'A special art label frame for the home gallery.'},
    {name:'Pharaoh Cartouche Shelf Tag', cost:7, currency:'historySeals', slot:'shelf', minLevel:1, note:'A history display tag for future Egypt collections.'},
    {name:'Tiny Castle Tax Chest', cost:7, currency:'merchantTickets', slot:'shelf', minLevel:1, note:'A silly little money-history collectible for Merchant Square.'},
    {name:'Starred Mastery Ledger', cost:2, currency:'meritStars', slot:'desk', minLevel:3, note:'A higher-goal item for careful mastery work.'},
    {name:'Silver Shop Bell', cost:6, currency:'merchantTickets', slot:'shelf', minLevel:1, note:'A bright counter bell that only appears when the Mystery Merchant carries it.'},
    {name:'Ship-in-a-Bottle Coin Bank', cost:10, currency:'seaGlass', slot:'shelf', minLevel:2, note:'A surprise savings item that ties money goals to Shipwreck Cove.'}
  ];
  function dailyRareItem(){ var base=pick(RARE_POOL,'rare') || RARE_POOL[0]; return Object.assign({id:'rare_'+todayKey()}, base, {rare:true, unique:true}); }

  var SHOPS = [
    {id:'penny', icon:'🪙', name:'Penny Pouch', title:'Coin Counter', currency:'merchantTickets', tag:'Starter goals',
     scene:'Penny Pouch keeps neat rows of jars, price tags, and small counter tools. This is the best first stop for simple money rewards and little home pieces.',
     stock:[
       {name:'Coin Sorting Tray', cost:3, currency:'merchantTickets', slot:'desk', note:'A starter item for money practice.'},
       {name:'Small Counter Bell', cost:4, currency:'merchantTickets', slot:'shelf', note:'A shop counter keepsake.'},
       {name:'Price Tag Bundle', cost:5, currency:'merchantTickets', slot:'desk', note:'Good for pretend shop setups.'},
       {name:'Penny Jar Shelf', cost:7, currency:'merchantTickets', slot:'shelf', minLevel:2, note:'A goal item for saving.'}
     ]},
    {id:'budget', icon:'💰', name:'Savings Chest Sophie', title:'Budget House', currency:'merchantTickets', tag:'Saving goals',
     scene:'Sophie runs a quiet little budget house beside a locked chest. Her items are meant to feel like long-term goals, not quick throwaway prizes.',
     stock:[
       {name:'Savings Chest', cost:8, currency:'merchantTickets', slot:'shelf', note:'A basic saving display.'},
       {name:'Budget Ledger Desk Book', cost:12, currency:'merchantTickets', slot:'desk', minLevel:2, note:'A practical money-planning item.'},
       {name:'Goal Thermometer Poster', cost:14, currency:'merchantTickets', slot:'wall', minLevel:3, note:'A wall chart for working toward bigger goals.'},
       {name:'Locked Dream Box', cost:2, currency:'meritStars', slot:'shelf', minLevel:4, note:'A bigger goal item tied to mastery.'}
     ]},
    {id:'gearwright', icon:'⚙️', name:'Blueprint Ben', title:'Engineering Depot', currency:'gearTokens', tag:'STEM rewards',
     scene:'Blueprint Ben has brass gears, safety tags, bridge sketches, and tiny prototypes stacked in careful bins. Engineering lessons feed this shop best.',
     stock:[
       {name:'Prototype Gear Stand', cost:4, currency:'gearTokens', slot:'desk', note:'A small engineering desk piece.'},
       {name:'Bridge Inspector Crest', cost:7, currency:'gearTokens', slot:'wall', minLevel:2, note:'A badge for careful structure thinking.'},
       {name:'Workshop Safety Lantern', cost:8, currency:'gearTokens', slot:'shelf', minLevel:2, note:'A safety culture reward.'},
       {name:'Redesign Blueprint Board', cost:12, currency:'gearTokens', slot:'wall', minLevel:4, note:'A bigger engineering goal.'}
     ]},
    {id:'brine', icon:'⚓', name:'Captain Brine', title:'Cove Salvage Stall', currency:'seaGlass', tag:'Shipwreck Cove',
     scene:'Captain Brine sells only respectful maritime keepsakes: charts, lanterns, museum tags, and safe salvage-themed decor. No treasure-grabbing nonsense here.',
     stock:[
       {name:'Sea Glass Jar', cost:3, currency:'seaGlass', slot:'shelf', note:'A gentle Cove collectible.'},
       {name:'Lighthouse Sketch', cost:5, currency:'seaGlass', slot:'wall', note:'A maritime wall piece.'},
       {name:'Chart Table Token', cost:8, currency:'seaGlass', slot:'desk', minLevel:2, note:'For navigation and evidence lessons.'},
       {name:'Respectful Wreck Museum Plaque', cost:13, currency:'seaGlass', slot:'wall', minLevel:4, note:'A larger Shipwreck Cove goal.'}
     ]},
    {id:'studio', icon:'🎨', name:'Studio Stella', title:'Maker Supply Nook', currency:'studioTickets', tag:'Creative rewards',
     scene:'Studio Stella keeps safe craft supplies, sketchbooks, labels, display ribbons, and tidy maker tools in labeled baskets.',
     stock:[
       {name:'Sketchbook Stand', cost:3, currency:'studioTickets', slot:'desk', note:'A starter creative item.'},
       {name:'Painter Apron Hook', cost:5, currency:'studioTickets', slot:'wall', note:'A safe studio decor piece.'},
       {name:'Mini Gallery Rope', cost:8, currency:'studioTickets', slot:'wall', minLevel:2, note:'For a home gallery feel.'},
       {name:'Master Maker Table Sign', cost:12, currency:'studioTickets', slot:'table', minLevel:4, note:'A bigger creative goal item.'}
     ]},
    {id:'museum', icon:'🏛️', name:'Museum Mara', title:'Relic Trade Desk', currency:'historySeals', tag:'History rewards',
     scene:'Museum Mara cares more about labels, context, and careful memory than shiny treasure. Her stall is for history decor and evidence-minded keepsakes.',
     stock:[
       {name:'Archive Label Set', cost:3, currency:'historySeals', slot:'desk', note:'A historian starter item.'},
       {name:'Timeline Ribbon', cost:5, currency:'historySeals', slot:'wall', note:'A wall item for sequencing history.'},
       {name:'Old Map Display Pin', cost:8, currency:'historySeals', slot:'wall', minLevel:2, note:'A geography-history crossover.'},
       {name:'Museum Curator Badge', cost:12, currency:'historySeals', slot:'accessory', minLevel:4, note:'A careful history goal.'},
       {name:'Ancient Relic Case', cost:4, currency:'ancientCoins', slot:'shelf', minLevel:3, note:'Uses the older Ancient Coin currency.'}
     ]},
    {id:'wardrobe', icon:'🧢', name:'Wardrobe Wren', title:'Outfitter Cart', currency:'sparks', tag:'Wearables',
     scene:'Wardrobe Wren hangs simple hats, cloaks, belts, and badges from a rolling cart. Some items are cheap, and some are real goal pieces.',
     stock:[
       {name:'Shopkeeper Cap', cost:20, currency:'sparks', slot:'hat', note:'A simple wearable reward.'},
       {name:'Counter Apron', cost:28, currency:'sparks', slot:'torso', note:'A pretend shop outfit piece.'},
       {name:'Merchant Satchel', cost:7, currency:'merchantTickets', slot:'accessory', minLevel:2, note:'A money-trail wearable.'},
       {name:'Master Trader Cloak', cost:3, currency:'meritStars', slot:'cloak', minLevel:5, note:'A long-term mastery wearable.'}
     ]},
    {id:'pets', icon:'🐾', name:'Pet Keeper Pip', title:'Companion Corner', currency:'merchantTickets', tag:'Pets',
     scene:'Pip keeps tiny cushions, tags, and harmless companion decorations near a basket of soft blankets.',
     stock:[
       {name:'Companion Name Tag', cost:4, currency:'merchantTickets', slot:'pet1', note:'A companion keepsake.'},
       {name:'Tiny Pawprint Mat', cost:6, currency:'merchantTickets', slot:'rug', note:'Pet corner decor.'},
       {name:'Reader Rabbit Nibble Bowl', cost:22, currency:'sparks', slot:'food', unique:false, note:'A food-style collectible.'},
       {name:'Companion Trophy Cushion', cost:10, currency:'merchantTickets', slot:'shelf', minLevel:3, note:'A bigger pet goal.'}
     ]},
    {id:'mathmart', icon:'🧮', name:'Mabel Measure', title:'Math Mart', currency:'merchantTickets', tag:'Math goods',
     scene:'Mabel Measure sells tidy math-themed pieces: counters, rulers, shop signs, and little tools that make money practice feel concrete.',
     stock:[
       {name:'Counting Counter Set', cost:3, currency:'merchantTickets', slot:'desk', note:'A starter math money item.'},
       {name:'Measuring Tape Ribbon', cost:5, currency:'merchantTickets', slot:'wall', note:'A practical math display.'},
       {name:'Receipt Practice Slate', cost:7, currency:'merchantTickets', slot:'desk', minLevel:2, note:'A total-and-change practice item.'},
       {name:'Golden Abacus Shelf', cost:12, currency:'merchantTickets', slot:'shelf', minLevel:4, note:'A larger math shop goal.'}
     ]},
    {id:'kettle', icon:'🥣', name:'Kettle Kip', title:'Snack Counter', currency:'sparks', tag:'Food collectibles',
     scene:'Kettle Kip keeps warm, simple food collectibles near a tiny counter. These make home rooms feel lived in without becoming the main economy.',
     stock:[
       {name:'Warm Study Cocoa', cost:16, currency:'sparks', slot:'food', unique:false, note:'A repeatable cozy food item.'},
       {name:'Berry Hand Pie', cost:18, currency:'sparks', slot:'food', unique:false, note:'A repeatable food collectible.'},
       {name:'Lunch Tray Display', cost:5, currency:'merchantTickets', slot:'table', note:'A little table piece.'},
       {name:'Festival Cookie Tin', cost:30, currency:'sparks', slot:'shelf', minLevel:2, note:'A snack-counter goal.'}
     ]},
    {id:'exchange', icon:'🔁', name:'Rowan Rates', title:'Exchange Booth', currency:'sparks', tag:'Currency trades', exchange:true,
     scene:'Rowan runs the exchange booth with a chalkboard of simple rates. This is for converting some general effort into subject tokens when a learner is close to a goal.',
     stock:[]},
    {id:'mystery', icon:'🕯️', name:'The Mystery Merchant', title:'Surprise Cart', currency:'merchantTickets', tag:'Daily rare item', mystery:true,
     scene:'A little cart appears near the fountain with one unusual item for the day. It is not normally carried by the regular shopkeepers.',
     stock:[]}
  ];
  function shopById(id){ for(var i=0;i<SHOPS.length;i++){ if(SHOPS[i].id === id) return SHOPS[i]; } return SHOPS[0]; }
  function shopStock(shop){ if(shop.mystery) return [dailyRareItem()]; return (shop.stock || []).slice(); }
  function itemKey(item){ return String(item.name || '').toLowerCase().replace(/\s+/g,'_'); }
  function owned(item){
    if(item.unique === false) return false;
    try{ if(typeof window.ownsHomeItem === 'function' && window.ownsHomeItem(item.name)) return true; }catch(e){}
    try{ if(typeof ownsHomeItem === 'function' && ownsHomeItem(item.name)) return true; }catch(e){}
    var e=ensureEconomy(); return !!e.purchases[itemKey(item)];
  }
  function unlocked(item){ return !item.minLevel || level() >= item.minLevel; }
  function canBuy(item){ return unlocked(item) && !owned(item) && amount(item.currency) >= item.cost; }
  function itemStatus(item){ if(!unlocked(item)) return 'Requires Level ' + (item.minLevel || 1); if(owned(item)) return 'Owned'; if(amount(item.currency) < item.cost) return 'Need more ' + (CURRENCIES[item.currency]||CURRENCIES.merchantTickets).label; return 'Ready'; }
  function itemCard(item, index, shopId){
    return '<div class="lr69Item '+(canBuy(item)?'ready':'muted')+' '+(item.rare?'rare':'')+'">' +
      '<div class="lr69ItemTop"><b>'+esc(item.name)+'</b><span>'+esc(item.cost)+' '+esc(labelCurrency(item.currency))+'</span></div>' +
      '<p>'+esc(item.note || 'A shopkeeper reward item.')+'</p>' +
      '<small>Slot: '+esc(item.slot || 'shelf')+' · '+esc(itemStatus(item))+'</small>' +
      '<button type="button" '+(canBuy(item)?'':'disabled')+' onclick="lr69Buy(\''+esc(shopId)+'\','+index+')">'+(owned(item)?'Already owned':'Buy')+'</button>' +
    '</div>';
  }
  function shopCard(shop){
    var stock=shopStock(shop); var sample=stock[0];
    return '<button type="button" class="lr69ShopkeeperCard" onclick="lr69OpenShopkeeper(\''+esc(shop.id)+'\')">' +
      '<span class="lr69ShopIcon">'+esc(shop.icon)+'</span><span class="lr69ShopWords"><b>'+esc(shop.name)+'</b><small>'+esc(shop.title)+' · '+esc(shop.tag)+'</small><p>'+esc(shop.scene)+'</p>' +
      (sample?'<em>Featured: '+esc(sample.name)+'</em>':'<em>Special service booth</em>') + '</span><span class="lr69Arrow">›</span></button>';
  }
  function claimReady(){ return ensureEconomy().claims.starterPouch !== todayKey(); }
  function claimButtonHtml(){
    return '<button type="button" class="lr69Claim '+(claimReady()?'ready':'done')+'" onclick="lr69ClaimStarterPouch()">'+(claimReady()?'Claim today\'s shopkeeper starter pouch':'Starter pouch claimed today')+'<small>Small daily boost for testing goals: tickets, subject tokens, and a few sparks.</small></button>';
  }
  function renderSquare(message){
    var mount=ensureMount(); var rare=dailyRareItem();
    mount.innerHTML = '<section class="lr69Hero"><div class="lr69HeroTop"><span>Merchant Square 6.9</span><span>'+esc(childName())+' · Level '+esc(level())+'</span></div>' +
      '<h1>Merchant Square</h1><p>The fountain road opens into a busy reward market. Shopkeepers have their own counters, currencies, goals, and surprise stock. Learning earns the money. The shops give the kids something fun to work toward.</p>' +
      (message?'<div class="lr69Message">'+esc(message)+'</div>':'') + walletHtml() + '</section>' +
      '<section class="lr69Feature"><div><b>Today\'s surprise cart:</b><p>'+esc(rare.name)+' costs '+esc(rare.cost)+' '+esc(labelCurrency(rare.currency))+'. '+esc(rare.note)+'</p></div><button type="button" onclick="lr69OpenShopkeeper(\'mystery\')">Visit Mystery Merchant</button></section>' +
      '<section class="lr69UtilityRow">'+claimButtonHtml()+'<button type="button" onclick="lr69OpenShopkeeper(\'exchange\')">Open exchange booth<small>Trade some Sparks into subject tokens.</small></button><button type="button" onclick="lr69OpenMerchantGoals()">View goal board<small>See how currencies connect to learning.</small></button></section>' +
      '<section class="lr69Grid">' + SHOPS.map(shopCard).join('') + '</section>' +
      '<div class="lr69Bottom"><button type="button" onclick="lr69BackToScene()">↩ Return to current scene</button><button type="button" onclick="lr69GoLearn()">📘 Learning Trails</button><button type="button" onclick="lr69GoHome()">🏡 Home</button></div>';
    stats(); return false;
  }
  function renderShop(shopId, message){
    var shop=shopById(shopId); if(shop.exchange) return renderExchange(message);
    var mount=ensureMount(); var stock=shopStock(shop);
    mount.innerHTML = '<section class="lr69Hero lr69ShopHero"><div class="lr69HeroTop"><span>'+esc(shop.tag)+'</span><span>'+esc(labelCurrency(shop.currency))+'</span></div>' +
      '<h1>'+esc(shop.icon+' '+shop.name)+'</h1><p>'+esc(shop.scene)+'</p>' + (message?'<div class="lr69Message">'+esc(message)+'</div>':'') + walletHtml() + '</section>' +
      '<section class="lr69Shelf"><div class="lr69ShelfTitle"><span>'+esc(shop.title)+'</span><small>Choose a goal item. Purchases go to Home Storage.</small></div><div class="lr69Items">' + stock.map(function(item,i){ return itemCard(item,i,shop.id); }).join('') + '</div></section>' +
      '<div class="lr69Bottom"><button type="button" onclick="lr69OpenMerchantSquare()">↩ Back to Merchant Square</button><button type="button" onclick="lr69OpenShopkeeper(\'exchange\')">🔁 Exchange booth</button><button type="button" onclick="lr69GoLearn()">📘 Learning Trails</button><button type="button" onclick="lr69GoHome()">🏡 Home</button></div>';
    stats(); return false;
  }
  var EXCHANGES = [
    {id:'spark_ticket', give:{currency:'sparks', amount:15}, get:{currency:'merchantTickets', amount:1}, text:'Trade 15 Sparks for 1 Merchant Ticket'},
    {id:'ticket_gear', give:{currency:'merchantTickets', amount:3}, get:{currency:'gearTokens', amount:1}, text:'Trade 3 Merchant Tickets for 1 Gear Token'},
    {id:'ticket_studio', give:{currency:'merchantTickets', amount:3}, get:{currency:'studioTickets', amount:1}, text:'Trade 3 Merchant Tickets for 1 Studio Ticket'},
    {id:'ticket_sea', give:{currency:'merchantTickets', amount:4}, get:{currency:'seaGlass', amount:1}, text:'Trade 4 Merchant Tickets for 1 Sea Glass'},
    {id:'ticket_history', give:{currency:'merchantTickets', amount:4}, get:{currency:'historySeals', amount:1}, text:'Trade 4 Merchant Tickets for 1 History Seal'}
  ];
  function renderExchange(message){
    var mount=ensureMount(); var shop=shopById('exchange');
    mount.innerHTML = '<section class="lr69Hero"><div class="lr69HeroTop"><span>Exchange Booth</span><span>Simple rates</span></div><h1>🔁 Rowan Rates</h1><p>'+esc(shop.scene)+'</p>' + (message?'<div class="lr69Message">'+esc(message)+'</div>':'') + walletHtml() + '</section>' +
      '<section class="lr69ExchangeGrid">' + EXCHANGES.map(function(x){ var ok=amount(x.give.currency)>=x.give.amount; return '<button type="button" '+(ok?'':'disabled')+' onclick="lr69Exchange(\''+x.id+'\')"><b>'+esc(x.text)+'</b><small>You have '+esc(amount(x.give.currency))+' '+esc(labelCurrency(x.give.currency))+'</small></button>'; }).join('') + '</section>' +
      '<div class="lr69Bottom"><button type="button" onclick="lr69OpenMerchantSquare()">↩ Back to Merchant Square</button><button type="button" onclick="lr69GoLearn()">📘 Learning Trails</button><button type="button" onclick="lr69GoHome()">🏡 Home</button></div>';
    return false;
  }
  function renderGoals(){
    var mount=ensureMount();
    var rows=[
      ['🎫 Merchant Tickets','General shopkeeper goals, money practice, math money paths, and starter rewards.'],
      ['🌊 Sea Glass','Shipwreck Cove and maritime history rewards.'],
      ['⚙️ Gear Tokens','Engineering, inventions, math tools, and redesign rewards.'],
      ['🎟️ Studio Tickets','Creative Studio, music, writing, art, craft, and gallery rewards.'],
      ['🏺 History Seals','History, geography, civics, Egypt, England, museum, timeline, and source-evidence rewards.'],
      ['⭐ Merit Stars','Harder mastery goals and higher-level outfit/decor rewards.']
    ];
    mount.innerHTML = '<section class="lr69Hero"><div class="lr69HeroTop"><span>Goal board</span><span>Why shops matter</span></div><h1>Shopkeeper Goal Board</h1><p>Merchant Square turns learning into visible goals. Currencies are intentionally simple: each special subject can feed a matching shop, while Sparks still work for common items.</p>'+walletHtml()+'</section>' +
      '<section class="lr69GoalGrid">'+rows.map(function(r){return '<div><b>'+esc(r[0])+'</b><p>'+esc(r[1])+'</p></div>';}).join('')+'</section>'+
      '<section class="lr69GoalNote"><b>Design note:</b> Future areas can hide their own shopkeepers without changing the whole map. A descriptive travel choice can lead to a subject, a lesson, then a reward shop tied to that topic.</section>'+
      '<div class="lr69Bottom"><button type="button" onclick="lr69OpenMerchantSquare()">↩ Back to Merchant Square</button><button type="button" onclick="lr69GoLearn()">📘 Learning Trails</button><button type="button" onclick="lr69GoHome()">🏡 Home</button></div>';
    return false;
  }
  function addHomeItem(item){
    var s=getState(); if(!s) return;
    var stored=false;
    try{ if(typeof window.ensureHome === 'function'){ var h=window.ensureHome(); h.storage=h.storage||[]; h.storage.push({name:item.name, slot:item.slot || 'shelf', source:'Merchant Square'}); stored=true; } }catch(e){}
    try{ if(!stored && typeof ensureHome === 'function'){ var h2=ensureHome(); h2.storage=h2.storage||[]; h2.storage.push({name:item.name, slot:item.slot || 'shelf', source:'Merchant Square'}); stored=true; } }catch(e){}
    if(!stored){ s.inventory=Array.isArray(s.inventory)?s.inventory:[]; s.inventory.push(item.name); }
  }
  function buy(shopId, index){
    var shop=shopById(shopId); var stock=shopStock(shop); var item=stock[Number(index)];
    if(!item) return renderShop(shopId, 'That item could not be found.');
    if(!unlocked(item)) return renderShop(shopId, item.name + ' is locked until Level ' + (item.minLevel || 1) + '.');
    if(owned(item)) return renderShop(shopId, item.name + ' is already owned.');
    if(!spendCurrency(item.currency, item.cost)) return renderShop(shopId, 'Not enough ' + (CURRENCIES[item.currency]||CURRENCIES.merchantTickets).label + ' for ' + item.name + '.');
    ensureEconomy().purchases[itemKey(item)] = {name:item.name, shop:shopId, date:new Date().toISOString(), cost:item.cost, currency:item.currency};
    addHomeItem(item);
    try{ if(typeof window.addMemory === 'function') window.addMemory('Merchant Square Purchase', childName() + ' bought ' + item.name + ' from ' + shop.name + '.'); }catch(e){ try{ if(typeof addMemory === 'function') addMemory('Merchant Square Purchase', childName() + ' bought ' + item.name + ' from ' + shop.name + '.'); }catch(_e){} }
    save(); stats();
    return renderShop(shopId, 'Purchased ' + item.name + '. It was added to Home Storage.');
  }
  function claimStarter(){
    var e=ensureEconomy(); if(e.claims.starterPouch === todayKey()) return renderSquare('The starter pouch has already been claimed today.');
    e.claims.starterPouch = todayKey();
    addCurrency('sparks', 10); addCurrency('merchantTickets', 5); addCurrency('seaGlass', 1); addCurrency('gearTokens', 1); addCurrency('studioTickets', 1); addCurrency('historySeals', 1);
    save(); stats();
    return renderSquare('Claimed today\'s shopkeeper starter pouch: +10 Sparks, +5 Merchant Tickets, +1 Sea Glass, +1 Gear Token, +1 Studio Ticket, +1 History Seal.');
  }
  function doExchange(id){
    var x=EXCHANGES.filter(function(v){return v.id===id;})[0]; if(!x) return renderExchange('That exchange is not available.');
    if(!spendCurrency(x.give.currency, x.give.amount)) return renderExchange('Not enough ' + (CURRENCIES[x.give.currency]||{}).label + ' for that exchange.');
    addCurrency(x.get.currency, x.get.amount); save(); stats();
    return renderExchange('Exchange complete: -' + x.give.amount + ' ' + (CURRENCIES[x.give.currency]||{}).label + ', +' + x.get.amount + ' ' + (CURRENCIES[x.get.currency]||{}).label + '.');
  }

  function subjectAwardKey(subj, lesson){
    var txt=String([subj, lesson && (lesson.unit||lesson.zone||lesson.skill||lesson.title||lesson.q||'')].join(' ')).toLowerCase();
    if(/shipwreck|maritime|ocean|sea|cove|pirate|wreck|lighthouse|titanic|vasa/.test(txt)) return 'seaGlass';
    if(/invent|engineer|gear|machine|bridge|rocket|flight|computer|electric|design|physics|math|logic/.test(txt)) return 'gearTokens';
    if(/art|music|creative|studio|paint|draw|craft|theater|gallery|story|writing|english|copywork/.test(txt)) return 'studioTickets';
    if(/history|civic|geography|egypt|pharaoh|england|king|queen|archive|map|timeline|museum/.test(txt)) return 'historySeals';
    if(/economics|money|merchant|budget|trade|saving|shop/.test(txt)) return 'merchantTickets';
    return 'merchantTickets';
  }
  function awardForLesson(subj, lesson, amountBase){
    var key=subjectAwardKey(subj, lesson); var n=amountBase || 1;
    addCurrency(key, n);
    if(key !== 'merchantTickets') addCurrency('merchantTickets', 1);
    var bonus='';
    if(daySeed(String(Date.now()).slice(-5)+subj)%23===0){ addCurrency('meritStars',1); bonus=' +1 Merit Star surprise'; }
    save(); stats();
    var line = ' Merchant Square: +' + n + ' ' + (CURRENCIES[key]||{}).label + (key !== 'merchantTickets' ? ' and +1 Merchant Ticket' : '') + bonus + '.';
    try{ var fb=byId('feedback'); if(fb) fb.textContent = String(fb.textContent || '') + line; }catch(e){}
    return line;
  }
  function wrapBaseAnswer(){
    try{
      var old=window.answer;
      if(typeof old !== 'function' || old.__lr69Wrapped) return;
      var wrapped=function(choice,L,subj,idx,btn){
        var correct=false; try{ correct = choice === L.a; }catch(e){}
        var out=old.apply(this, arguments);
        if(correct){ try{ awardForLesson(subj, L, 1); }catch(e){ console.warn('LR69 lesson award failed', e); } }
        return out;
      };
      wrapped.__lr69Wrapped=true; window.answer=wrapped; try{ answer=wrapped; }catch(e){}
    }catch(e){}
  }
  function popupContainsPerfect(words){
    var txt=''; try{ var b=byId('lrPopupBody'); if(b) txt += ' ' + b.textContent; }catch(e){}
    try{ var p=byId('lrPopupTitle'); if(p) txt += ' ' + p.textContent; }catch(e){}
    return words.some(function(w){ return txt.toLowerCase().indexOf(w.toLowerCase()) >= 0; });
  }
  function appendPopupAward(text){
    try{ var b=byId('lrPopupBody'); if(!b) return; var div=document.createElement('div'); div.className='lr69PopupAward'; div.textContent=text; b.insertBefore(div,b.firstChild); }catch(e){}
  }
  function masteryAwardOnce(course, topic, awards, successWords){
    setTimeout(function(){
      if(!popupContainsPerfect(successWords)) return;
      var e=ensureEconomy(); e.awards[course]=e.awards[course]||{};
      var k=String(topic);
      if(e.awards[course][k]) return;
      e.awards[course][k]=todayKey();
      awards.forEach(function(a){ addCurrency(a.currency,a.amount); });
      save(); stats();
      appendPopupAward('Merchant Square bonus: ' + awards.map(function(a){ return '+'+a.amount+' '+(CURRENCIES[a.currency]||{}).label; }).join(', ') + '.');
    }, 80);
  }
  function wrapQuizChecker(name, course, awards, successWords){
    try{
      var old=window[name];
      if(typeof old !== 'function' || old.__lr69Wrapped) return;
      var wrapped=function(i){ var out=old.apply(this, arguments); masteryAwardOnce(course, i, awards, successWords); return out; };
      wrapped.__lr69Wrapped=true; window[name]=wrapped; try{ eval(name+'=window[name]'); }catch(e){}
    }catch(e){}
  }
  function installAwardHooks(){
    wrapBaseAnswer();
    wrapQuizChecker('shipwreckCheckQuiz','shipwreck',[{currency:'seaGlass',amount:4},{currency:'historySeals',amount:1},{currency:'merchantTickets',amount:1}],['perfect mastery']);
    wrapQuizChecker('inventionsCheckQuiz','inventions',[{currency:'gearTokens',amount:4},{currency:'meritStars',amount:1},{currency:'merchantTickets',amount:1}],['perfect mastery']);
    wrapQuizChecker('creativeCheckQuiz','creative',[{currency:'studioTickets',amount:4},{currency:'meritStars',amount:1},{currency:'merchantTickets',amount:1}],['creative mastery']);
  }

  function addLearningTrailButton(){
    try{
      var screen=byId('lrDynamicAdventureScreen'); if(!screen) return;
      var isTrails=screen.querySelector('.lr68bTrailGrid') || /Choose the next learning trail/i.test(screen.textContent || '');
      if(!isTrails || screen.querySelector('[data-lr69-trail]')) return;
      var grid=screen.querySelector('.lr68bTrailGrid') || screen;
      var btn=document.createElement('button');
      btn.type='button'; btn.className='lr68bTrailCard lr69TrailCard'; btn.setAttribute('data-lr69-trail','1');
      btn.innerHTML='<span class="lr68bTrailText"><b>Walk into Merchant Square.</b><small>Money, shops, goals, and surprise stock</small><p>Visit many shopkeepers, spend themed currencies, save for goal items, and check the Mystery Merchant for a daily rare item.</p></span><span class="lr68bTrailArrow">›</span>';
      btn.onclick=function(){ return renderSquare(); };
      grid.insertBefore(btn, grid.firstChild);
    }catch(e){}
  }
  function wrapLearningTrails(){
    try{
      if(typeof window.lr68bOpenLearningTrails === 'function' && !window.lr68bOpenLearningTrails.__lr69Wrapped){
        var old=window.lr68bOpenLearningTrails;
        var repl=function(){ var out=old.apply(this, arguments); [60,180,380].forEach(function(ms){ setTimeout(addLearningTrailButton, ms); }); return out; };
        repl.__lr69Wrapped=true; window.lr68bOpenLearningTrails=repl; try{ lr68bOpenLearningTrails=repl; }catch(e){}
      }
    }catch(e){}
  }
  function addHomePathButton(){
    try{
      var screen=byId('lrDynamicAdventureScreen'); if(!screen || screen.querySelector('[data-lr69-home-path]')) return;
      var txt=screen.textContent || '';
      if(!/Home|Fountain|Town|Learning trails from here|Great Fountain/i.test(txt)) return;
      var panel=screen.querySelector('.lr68aPathPanel') || screen.querySelector('.lr67ChoicePanel') || screen.querySelector('.lr68BottomBar') || screen.querySelector('.lr67BottomBar');
      if(!panel) return;
      var btn=document.createElement('button'); btn.type='button'; btn.className='lr69InlinePath'; btn.setAttribute('data-lr69-home-path','1');
      btn.innerHTML='<b>🏪 Follow the coinstone lane into Merchant Square.</b><small>Shopkeepers, goal items, surprise stock, and currency rewards.</small>';
      btn.onclick=function(){ return renderSquare(); };
      panel.insertBefore(btn, panel.firstChild);
    }catch(e){}
  }
  function installUiObserver(){
    try{ if(window.__LR69_OBSERVER__) return; window.__LR69_OBSERVER__=true; var obs=new MutationObserver(function(){ addLearningTrailButton(); addHomePathButton(); }); obs.observe(document.body,{childList:true,subtree:true}); }catch(e){}
  }
  function injectStyles(){
    if(byId('lr69MerchantSquareStyle')) return;
    var st=document.createElement('style'); st.id='lr69MerchantSquareStyle';
    st.textContent = `
      body.lr69MerchantSquareMode #lrDynamicAdventureScreen{width:100% !important;max-width:none !important;min-height:680px !important;}
      .lr69Hero{padding:28px 32px 22px;background:radial-gradient(circle at 10% 0%,rgba(255,219,122,.24),transparent 34%),linear-gradient(135deg,#123a35,#345b42 52%,#5a4424);color:#fff6d8;border-bottom:1px solid rgba(255,232,166,.28);}
      .lr69HeroTop{display:flex;justify-content:space-between;gap:10px;color:#ffe7a5;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem;font-weight:950}.lr69Hero h1{margin:10px 0;font-size:clamp(2rem,4vw,3.4rem);line-height:1.05;color:#fff1b8}.lr69Hero p{max-width:1000px;line-height:1.55;font-weight:760;color:#eef8e8}.lr69Message{margin:12px 0;padding:11px 13px;border-radius:14px;border:1px solid rgba(255,232,166,.42);background:rgba(255,255,255,.12);font-weight:900;color:#fff4cf}
      .lr69Wallet{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.lr69Wallet span{background:rgba(255,255,255,.13);border:1px solid rgba(255,232,166,.28);border-radius:999px;padding:7px 10px;font-weight:850;color:#fff9df}.lr69Wallet strong{color:#fff;}
      .lr69Feature{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:16px 24px;background:#fff7dd;color:#153830;border-bottom:1px solid rgba(45,73,54,.16)}.lr69Feature p{margin:.35rem 0 0;line-height:1.4}.lr69Feature button,.lr69UtilityRow button,.lr69Bottom button,.lr69Item button,.lr69ExchangeGrid button{border:1px solid rgba(40,72,54,.25);border-radius:14px;background:#214f43;color:#fff4d2;font-weight:950;padding:10px 13px;cursor:pointer}.lr69Feature button{white-space:nowrap}.lr69UtilityRow{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px;padding:14px 18px;background:#eaf5e8}.lr69UtilityRow button{min-height:70px;text-align:left;background:#fffdf2;color:#153830}.lr69UtilityRow button small,.lr69Claim small{display:block;margin-top:5px;font-weight:750;color:#52675e}.lr69Claim.ready{border-color:#d0a846!important;box-shadow:0 0 0 2px rgba(255,218,112,.22) inset}.lr69Claim.done{opacity:.68}
      .lr69Grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(295px,1fr));gap:13px;padding:20px;background:linear-gradient(180deg,#f4fbef,#e6f1e9)}.lr69ShopkeeperCard{width:100%;min-height:175px;display:flex;gap:13px;text-align:left;align-items:flex-start;border:1px solid rgba(20,78,59,.18);border-radius:22px;background:#fffdf2;color:#183a32;padding:15px;box-shadow:0 10px 20px rgba(0,0,0,.13);cursor:pointer}.lr69ShopkeeperCard:hover{transform:translateY(-1px);box-shadow:0 14px 24px rgba(0,0,0,.18)}.lr69ShopIcon{font-size:2.1rem;line-height:1}.lr69ShopWords{display:flex;flex-direction:column;gap:5px}.lr69ShopWords b{font-size:1.08rem;color:#123a31}.lr69ShopWords small{font-weight:950;color:#735d1e;text-transform:uppercase;letter-spacing:.04em}.lr69ShopWords p{margin:0;color:#425d53;font-weight:740;line-height:1.35}.lr69ShopWords em{font-style:normal;color:#8b4d23;font-weight:900}.lr69Arrow{margin-left:auto;align-self:center;font-size:2rem;color:#9d741e;font-weight:900}
      .lr69Shelf{padding:20px;background:linear-gradient(180deg,#f8fff4,#e7f2ea)}.lr69ShelfTitle{display:flex;justify-content:space-between;gap:10px;color:#153830;font-weight:950;margin-bottom:12px}.lr69ShelfTitle span{font-size:1.25rem}.lr69ShelfTitle small{font-weight:750;color:#546c62}.lr69Items{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}.lr69Item{background:#fffdf5;color:#183a32;border:1px solid rgba(34,78,61,.18);border-radius:18px;padding:14px;box-shadow:0 8px 16px rgba(0,0,0,.10)}.lr69Item.rare{border-color:#d6a928;box-shadow:0 0 0 3px rgba(255,222,117,.23) inset,0 8px 16px rgba(0,0,0,.12)}.lr69Item.muted{opacity:.72}.lr69ItemTop{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.lr69ItemTop b{font-size:1.02rem;color:#123a31}.lr69ItemTop span{white-space:nowrap;background:#244b40;color:#fff4d2;border-radius:999px;padding:4px 8px;font-weight:950;font-size:.78rem}.lr69Item p{margin:.6rem 0;color:#425d53;font-weight:730;line-height:1.38}.lr69Item small{display:block;color:#5b6e66;font-weight:850;margin-bottom:10px}.lr69Item button{width:100%}.lr69Item button:disabled,.lr69ExchangeGrid button:disabled{background:#8b938d!important;color:#eee6d3!important;cursor:not-allowed!important}
      .lr69ExchangeGrid,.lr69GoalGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:12px;padding:20px;background:#eef8eb}.lr69ExchangeGrid button{text-align:left;min-height:92px;background:#fffdf2;color:#153830}.lr69ExchangeGrid button small{display:block;margin-top:7px;color:#52675e;font-weight:750}.lr69GoalGrid div,.lr69GoalNote{background:#fffdf4;color:#173a31;border:1px solid rgba(34,78,61,.16);border-radius:18px;padding:15px;box-shadow:0 8px 16px rgba(0,0,0,.08)}.lr69GoalGrid b{color:#123a31}.lr69GoalGrid p{color:#425d53;font-weight:740;line-height:1.42}.lr69GoalNote{margin:0 20px 20px;font-weight:780;line-height:1.45}
      .lr69Bottom{display:flex;flex-wrap:wrap;gap:10px;padding:16px 20px;background:#08242a;border-top:1px solid rgba(255,232,166,.18)}.lr69Bottom button{background:#fff4d0;color:#163930;border-radius:999px}.lr69TrailCard{border-color:#cfa43a!important;box-shadow:0 0 0 3px rgba(255,220,105,.20) inset,0 10px 18px rgba(0,0,0,.13)!important}.lr69InlinePath{display:block;width:100%;margin:8px 0 10px;padding:13px 14px;border-radius:16px;border:1px solid rgba(207,164,58,.55);background:#fff6d5;color:#173a31;text-align:left;font-weight:900;box-shadow:0 8px 16px rgba(0,0,0,.12)}.lr69InlinePath small{display:block;margin-top:4px;color:#52675e;font-weight:760}.lr69PopupAward{margin:0 0 12px;padding:12px;border-radius:14px;background:#fff4ca;color:#173a31;border:1px solid #dab044;font-weight:900}
      @media(max-width:850px){.lr69Hero{padding:22px 18px}.lr69Feature{display:block}.lr69Feature button{margin-top:10px}.lr69Grid,.lr69Items,.lr69ExchangeGrid,.lr69GoalGrid{grid-template-columns:1fr;padding:14px}.lr69ShelfTitle,.lr69HeroTop{display:block}.lr69ItemTop{display:block}.lr69ItemTop span{display:inline-block;margin-top:7px}.lr69Bottom{display:grid;grid-template-columns:1fr}}
    `;
    document.head.appendChild(st);
  }
  function installRooms(){
    try{
      var rooms = window.LR_ROOMS || (typeof ROOMS !== 'undefined' ? ROOMS : null); if(!rooms) return;
      rooms.merchantSquare69 = {title:'Merchant Square', zone:'Town Market', subject:'Economics', text:'A coinstone square branches into shopkeeper counters, saving goals, surprise stock, and money practice.', exits:{out:'crossroads'}};
      if(rooms.crossroads && rooms.crossroads.exits && !rooms.crossroads.exits.merchantSquare) rooms.crossroads.exits.merchantSquare='merchantSquare69';
    }catch(e){}
  }
  function redirectOldShopRenderer(){
    try{
      if(typeof window.openShopRenderer === 'function' && !window.openShopRenderer.__lr69Wrapped){
        var old=window.openShopRenderer;
        var repl=function(shopKey){
          var map={home:'penny',seasonal:'penny',pictures:'museum',diner:'kettle',relics:'museum',engineering:'gearwright'};
          if(shopKey && map[shopKey]) return renderShop(map[shopKey]);
          return renderSquare();
        };
        repl.__lr69Wrapped=true; repl.__lr69Old=old; window.openShopRenderer=repl; try{ openShopRenderer=repl; }catch(e){}
      }
    }catch(e){}
  }
  function boot(){
    injectStyles(); ensureEconomy(); installRooms(); installAwardHooks(); wrapLearningTrails(); installUiObserver(); redirectOldShopRenderer(); addLearningTrailButton(); addHomePathButton();
  }
  window.lr69OpenMerchantSquare = renderSquare;
  window.lr69OpenShopkeeper = renderShop;
  window.lr69OpenMerchantGoals = renderGoals;
  window.lr69Buy = buy;
  window.lr69Exchange = doExchange;
  window.lr69ClaimStarterPouch = claimStarter;
  window.lr69BackToScene = renderRoom;
  window.lr69GoLearn = goLearn;
  window.lr69GoHome = goHome;
  window.lr69AwardForLesson = awardForLesson;
  window.lr69WalletAmount = amount;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ boot(); [150,500,1200,2400].forEach(function(ms){ setTimeout(boot, ms); }); });
  else { boot(); [150,500,1200,2400].forEach(function(ms){ setTimeout(boot, ms); }); }
  window.addEventListener('load', function(){ boot(); setTimeout(boot,650); setTimeout(boot,1800); });
})();
