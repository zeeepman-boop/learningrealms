// Expansion Pack 1D

LR_addLessons("Luna","History",[
 {teach:"A map shows places.",practice:"Maps help travelers.",q:"What shows places?",c:["map","shoe","tree"],a:"map"},
 {teach:"A community helper serves others.",practice:"Firefighters help people.",q:"Which is a helper?",c:["firefighter","rock","cloud"],a:"firefighter"},
 {teach:"Past means before now.",practice:"Yesterday is past.",q:"Yesterday is in the...",c:["past","future","moon"],a:"past"},
 {teach:"Families have members.",practice:"Parents and children.",q:"A family has...",c:["members","wheels","roots"],a:"members"},
 {teach:"Rules help groups.",practice:"Take turns.",q:"Rules help people...",c:["work together","get lost","sleep"],a:"work together"}
]);

LR_addLessons("Luna","Math",[
 {teach:"A square has 4 equal sides.",practice:"Count sides.",q:"A square has how many sides?",c:["4","3","5"],a:"4"},
 {teach:"Half means one of two equal parts.",practice:"Cut an apple.",q:"Half means...",c:["one of two parts","three parts","ten"],a:"one of two parts"},
 {teach:"30 is three tens.",practice:"10+10+10",q:"30 is how many tens?",c:["3","2","5"],a:"3"},
 {teach:"A penny is 1 cent.",practice:"One penny.",q:"Penny value?",c:["1","5","10"],a:"1"},
 {teach:"Long hand shows minutes.",practice:"Clock reading.",q:"Minute hand is the...",c:["long hand","short hand","red hand"],a:"long hand"}
]);

LR_addLessons("Ava","History",[
 {teach:"Citizens vote in elections.",practice:"Voting chooses leaders.",q:"Citizens may...",c:["vote","erode","multiply"],a:"vote"},
 {teach:"Supply and demand affect price.",practice:"Rare items cost more.",q:"Economics studies...",c:["choices","clouds","verbs"],a:"choices"},
 {teach:"Laws organize society.",practice:"Traffic laws.",q:"Laws help...",c:["organize","confuse","evaporate"],a:"organize"},
 {teach:"Scarcity means not enough resources.",practice:"Limited water.",q:"Scarcity means...",c:["limited","plentiful","equal"],a:"limited"},
 {teach:"Government has roles.",practice:"Services and rules.",q:"Government helps provide...",c:["services","volcanoes","suffixes"],a:"services"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Photosynthesis helps plants make food.",practice:"Sunlight helps plants.",q:"Plants make food by...",c:["photosynthesis","erosion","evaporation"],a:"photosynthesis"},
 {teach:"Evaporation changes liquid to gas.",practice:"Puddle dries.",q:"Drying puddle is...",c:["evaporation","freezing","melting"],a:"evaporation"},
 {teach:"Condensation forms droplets.",practice:"Foggy glass.",q:"Droplets forming are...",c:["condensation","erosion","gravity"],a:"condensation"},
 {teach:"Matter has mass.",practice:"Objects weigh.",q:"Matter has...",c:["mass","punctuation","theme"],a:"mass"},
 {teach:"Producers make food.",practice:"Plants.",q:"Producer example?",c:["plant","fox","rock"],a:"plant"}
]);

LR_addLessons("Michael","History",[
 {teach:"The Constitution created government structure.",practice:"Branches.",q:"Constitution created...",c:["government structure","weather","maps"],a:"government structure"},
 {teach:"Rights protect freedoms.",practice:"Speech rights.",q:"Rights protect...",c:["freedoms","rocks","angles"],a:"freedoms"},
 {teach:"A republic uses representatives.",practice:"People elect leaders.",q:"Republic uses...",c:["representatives","kings","clouds"],a:"representatives"},
 {teach:"Trade exchanges goods.",practice:"Markets.",q:"Trade exchanges...",c:["goods","verbs","gravity"],a:"goods"},
 {teach:"Scarcity drives choices.",practice:"Limited resources.",q:"Scarcity affects...",c:["choices","spelling","photosynthesis"],a:"choices"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Friction resists motion.",practice:"Sliding slows.",q:"Friction resists...",c:["motion","grammar","maps"],a:"motion"},
 {teach:"Mass measures amount of matter.",practice:"Objects have mass.",q:"Mass measures...",c:["matter","time","theme"],a:"matter"},
 {teach:"Velocity includes speed and direction.",practice:"North at 5 mph.",q:"Velocity includes...",c:["direction","punctuation","color"],a:"direction"},
 {teach:"Atoms contain protons.",practice:"Nucleus.",q:"Atom contains...",c:["protons","paragraphs","maps"],a:"protons"},
 {teach:"Weathering breaks rock.",practice:"Cracked stone.",q:"Weathering...",c:["breaks rock","creates laws","adds mass"],a:"breaks rock"}
]);
