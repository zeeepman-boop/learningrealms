/* LearningRealms Dynamic Adventure Screen 6.7B
   Home button fix: keeps Home inside the dynamic adventure screen instead of handing off to
   the older Home Portal action view, which could make the main adventure window disappear.
   Content, lessons, rewards, and rooms are not changed.
*/
(function(){
  'use strict';
  if(window.__LR67B_HOME_DYNAMIC_FIX__) return;
  window.__LR67B_HOME_DYNAMIC_FIX__ = true;

  function byId(id){ return document.getElementById(id); }
  function getState(){
    try{ if(typeof state !== 'undefined' && state) return state; }catch(e){}
    try{ if(window.state) return window.state; }catch(e){}
    return null;
  }
  function callSave(){
    try{ if(typeof window.save === 'function') window.save(); return; }catch(e){}
    try{ if(typeof save === 'function') save(); }catch(e){}
  }
  function callRenderRoom(){
    if(window.__LR67B_HOME_RENDERING__) return;
    window.__LR67B_HOME_RENDERING__ = true;
    try{
      if(typeof window.renderRoom === 'function') window.renderRoom();
      else if(typeof renderRoom === 'function') renderRoom();
    }catch(e){ console.warn('6.7B renderRoom skipped', e); }
    window.__LR67B_HOME_RENDERING__ = false;
  }
  function ensureDynamicMount(){
    try{ document.body.classList.add('lrDynamicAdventureMode'); }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(mount){
      mount.style.display = 'block';
      mount.style.visibility = 'visible';
      mount.style.opacity = '1';
      return mount;
    }
    var firstCard = document.querySelector('.main > .card') || document.querySelector('.main') || document.querySelector('main') || document.body;
    mount = document.createElement('div');
    mount.id = 'lrDynamicAdventureScreen';
    mount.className = 'lrDynamicAdventureScreen';
    if(firstCard.firstChild) firstCard.insertBefore(mount, firstCard.firstChild);
    else firstCard.appendChild(mount);
    return mount;
  }
  function hideOldHomeActionPanels(){
    /* Home storage/decor still exists through Home rooms and buttons, but the old Home Portal
       action panel should not swallow the main screen in dynamic mode. */
    try{ var lb = byId('lessonBox'); if(lb) lb.classList.add('hidden'); }catch(e){}
  }
  function renderDynamicHome(note){
    ensureDynamicMount();
    hideOldHomeActionPanels();
    try{
      if(typeof window.lr67RenderDynamicScreen === 'function'){
        window.lr67RenderDynamicScreen('room', note || 'You return to Home Hearth. The home rooms, rewards, pets, and keepsakes are part of the adventure screen now.');
      }
    }catch(e){ console.warn('6.7B dynamic home render skipped', e); }
    var mount = byId('lrDynamicAdventureScreen');
    if(mount){
      mount.style.display = 'block';
      mount.style.visibility = 'visible';
      mount.style.opacity = '1';
    }
  }

  function dynamicHomeTravel(){
    try{
      var s = getState();
      if(s){
        s.loc = 'home';
        s.room = Math.max(1, Number(s.room || 1)) + 1;
      }
      try{ if(typeof recordGameFunEvent === 'function') recordGameFunEvent('roomVisits',1,{room:'home'}); }catch(e){}
      /* Do not trigger the older Home Portal takeover here. Home is now just another fast
         adventure-screen room with story choices. */
      try{ document.body.classList.remove('homeMode'); }catch(e){}
      callSave();
      callRenderRoom();
      setTimeout(function(){ renderDynamicHome('You step back into Home Hearth.'); }, 5);
      setTimeout(function(){ renderDynamicHome(); }, 90);
      setTimeout(function(){ renderDynamicHome(); }, 300);
    }catch(e){
      console.error('6.7B Home travel failed', e);
      renderDynamicHome('Home tried to load, but something old blocked it: ' + (e.message || e));
    }
  }

  window.lr67GoHome = dynamicHomeTravel;
  window.travelHome = dynamicHomeTravel;
  window.enterHomePortal = dynamicHomeTravel;
  try{ lr67GoHome = dynamicHomeTravel; }catch(e){}
  try{ travelHome = dynamicHomeTravel; }catch(e){}
  try{ enterHomePortal = dynamicHomeTravel; }catch(e){}

  function injectStyles(){
    if(byId('lr67BHomeFixStyle')) return;
    var st = document.createElement('style');
    st.id = 'lr67BHomeFixStyle';
    st.textContent = `
      body.lrDynamicAdventureMode #lrDynamicAdventureScreen,
      body.lrDynamicAdventureMode.homeMode #lrDynamicAdventureScreen{
        display:block !important;
        visibility:visible !important;
        opacity:1 !important;
        min-height:560px !important;
      }
      body.lrDynamicAdventureMode .main > .card:first-child{
        display:block !important;
        visibility:visible !important;
        opacity:1 !important;
      }
      body.lrDynamicAdventureMode.homeMode .actionSidebar{
        display:none !important;
      }
    `;
    document.head.appendChild(st);
  }

  function boot(){
    injectStyles();
    ensureDynamicMount();
    if(getState() && getState().loc === 'home') setTimeout(function(){ renderDynamicHome(); }, 60);
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else setTimeout(boot, 10);
  window.addEventListener('load', function(){ setTimeout(boot, 120); setTimeout(boot, 600); });
})();
