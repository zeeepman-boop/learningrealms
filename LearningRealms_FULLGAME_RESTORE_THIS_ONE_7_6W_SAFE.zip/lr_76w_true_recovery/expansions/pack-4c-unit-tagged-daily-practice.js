// Curriculum Pack 4C: Unit-Tagged Daily Practice Drills
// Small tagged daily-practice pack to keep feeding unit progress.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Reading",[
 {unit:"G1-READ-PHONICS",skill:"short vowels",difficulty:"practice",mode:"daily-drill",teach:"Practice: Listen for the middle vowel sound.",practice:"bag has short a.",q:"Which word has short a?",c:["bag","bike","boat"],a:"bag"},
 {unit:"G1-READ-PHONICS",skill:"long vowels",difficulty:"practice",mode:"daily-drill",teach:"Practice: Final e can make a vowel long.",practice:"kit becomes kite.",q:"Which word has long i?",c:["kite","kit","kid"],a:"kite"},
 {unit:"G1-READ-PHONICS",skill:"consonant blends",difficulty:"practice",mode:"daily-drill",teach:"Practice: In a blend, both sounds are heard.",practice:"sl in slide.",q:"Which word starts with SL?",c:["slide","chip","thin"],a:"slide"},
 {unit:"G1-READ-COMP",skill:"problem",difficulty:"practice",mode:"daily-drill",teach:"Practice: A problem is what goes wrong.",practice:"The door was stuck.",q:"What is the problem?",c:["door was stuck","door was blue","the story ended"],a:"door was stuck"},
 {unit:"G1-READ-COMP",skill:"solution",difficulty:"practice",mode:"daily-drill",teach:"Practice: A solution fixes the problem.",practice:"They pushed the door open.",q:"What is the solution?",c:["pushed door open","door was stuck","door was old"],a:"pushed door open"}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-SENTENCES",skill:"nouns",difficulty:"practice",mode:"daily-drill",teach:"Practice: A noun names a person, place, thing, or animal.",practice:"rabbit, town, book",q:"Which is a noun?",c:["book","run","soft"],a:"book"},
 {unit:"G1-ELA-SENTENCES",skill:"adjectives",difficulty:"practice",mode:"daily-drill",teach:"Practice: An adjective describes a noun.",practice:"bright lantern",q:"Which word describes?",c:["bright","lantern","the"],a:"bright"},
 {unit:"G1-ELA-WRITING",skill:"restating questions",difficulty:"practice",mode:"daily-drill",teach:"Practice: Restate the question in your answer.",practice:"Where did the frog go? The frog went to the pond.",q:"Which answer restates?",c:["The frog went to the pond.","Pond.","Yes."],a:"The frog went to the pond."}
]);

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"addition within 20",difficulty:"practice",mode:"daily-drill",teach:"Practice: Use facts to add within 20.",practice:"6 + 8 = 14.",q:"6 + 8 = ?",c:["14","13","15"],a:"14"},
 {unit:"G1-MATH-FACTS",skill:"fact families",difficulty:"practice",mode:"daily-drill",teach:"Practice: Addition and subtraction facts are related.",practice:"9 + 4 = 13, so 13 - 4 = 9.",q:"13 - 4 = ?",c:["9","8","10"],a:"9"},
 {unit:"G1-MATH-PLACE",skill:"number lines",difficulty:"practice",mode:"daily-drill",teach:"Practice: A number line helps count jumps.",practice:"From 7 to 11 is 4 jumps.",q:"From 7 to 11 is how many jumps?",c:["4","3","5"],a:"4"},
 {unit:"G1-MATH-MEASURE",skill:"3D shapes",difficulty:"practice",mode:"daily-drill",teach:"Practice: A cube is a solid shape.",practice:"A block can look like a cube.",q:"Which is a 3D shape?",c:["cube","circle","line"],a:"cube"}
]);

LR_addLessons("Luna","Science",[
 {unit:"G1-SCI-LIFE",skill:"basic needs",difficulty:"practice",mode:"daily-drill",teach:"Practice: Living things need basic things to live.",practice:"Plants need water and light.",q:"Which does a plant need?",c:["water","shoes","paper"],a:"water"},
 {unit:"G1-SCI-PHYSICAL",skill:"magnets",difficulty:"practice",mode:"daily-drill",teach:"Practice: Magnets pull some metals.",practice:"A magnet may stick to a metal clip.",q:"Magnets can pull some...",c:["metals","leaves","clouds"],a:"metals"}
]);

LR_addLessons("Luna","History",[
 {unit:"G1-SS-COMMUNITY",skill:"services",difficulty:"practice",mode:"daily-drill",teach:"Practice: A service is work someone does for others.",practice:"A haircut is a service.",q:"Which is a service?",c:["haircut","apple","chair"],a:"haircut"}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-RATIO",skill:"proportions",difficulty:"practice",mode:"daily-drill",teach:"Practice: Proportions are equal ratios.",practice:"4/5 = 8/10.",q:"Which equals 4/5?",c:["8/10","5/8","4/10"],a:"8/10"},
 {unit:"G7-MATH-RATIO",skill:"scale factor",difficulty:"practice",mode:"daily-drill",teach:"Practice: Scale factor tells how dimensions change.",practice:"Scale factor 3 triples lengths.",q:"Scale factor 3 makes lengths...",c:["triple","half","unchanged"],a:"triple"},
 {unit:"G7-MATH-INT",skill:"integer multiplication",difficulty:"practice",mode:"daily-drill",teach:"Practice: Same signs give a positive product.",practice:"-6 × -2 = 12.",q:"-6 × -2 = ?",c:["12","-12","8"],a:"12"},
 {unit:"G7-MATH-EQ",skill:"multi-step equations",difficulty:"practice",mode:"daily-drill",teach:"Practice: Undo operations in reverse order.",practice:"2x + 6 = 18 gives x = 6.",q:"2x + 6 = 18. x = ?",c:["6","12","24"],a:"6"},
 {unit:"G7-MATH-GEO-DATA",skill:"area",difficulty:"practice",mode:"daily-drill",teach:"Practice: Area of a rectangle is length times width.",practice:"8 × 5 = 40.",q:"Area with length 8 and width 5?",c:["40","13","30"],a:"40"}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-EVIDENCE",skill:"context clues",difficulty:"practice",mode:"daily-drill",teach:"Practice: Context clues help reveal word meaning.",practice:"The frigid wind made everyone shiver.",q:"Frigid most likely means...",c:["very cold","very hot","very loud"],a:"very cold"},
 {unit:"G7-ELA-WRITING",skill:"topic sentence",difficulty:"practice",mode:"daily-drill",teach:"Practice: A topic sentence tells what the paragraph is mostly about.",practice:"The paragraph will explain frog habitats.",q:"A topic sentence gives the...",c:["main idea","last detail","source date"],a:"main idea"},
 {unit:"G7-ELA-LANGUAGE",skill:"suffixes",difficulty:"practice",mode:"daily-drill",teach:"Practice: A suffix comes after a root word.",practice:"hopeful has suffix ful.",q:"In hopeful, the suffix is...",c:["ful","hope","hop"],a:"ful"}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-LIFE",skill:"adaptations",difficulty:"practice",mode:"daily-drill",teach:"Practice: Adaptations help organisms survive.",practice:"Thick fur helps in cold places.",q:"Adaptations help living things...",c:["survive","spell","divide"],a:"survive"},
 {unit:"G7-SCI-EARTH",skill:"deposition",difficulty:"practice",mode:"daily-drill",teach:"Practice: Deposition drops sediment in a new place.",practice:"A river drops sand.",q:"Deposition means sediment is...",c:["dropped","burned","capitalized"],a:"dropped"},
 {unit:"G7-SCI-PHYSICAL",skill:"graphs",difficulty:"practice",mode:"daily-drill",teach:"Practice: Graphs can show relationships between variables.",practice:"Temperature over days can be graphed.",q:"Graphs can show relationships between...",c:["variables","only titles","only nouns"],a:"variables"}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"chronology",difficulty:"practice",mode:"daily-drill",teach:"Practice: Chronology is time order.",practice:"First, next, last.",q:"Chronology means...",c:["time order","mass","tone"],a:"time order"},
 {unit:"G7-SS-CIVICS",skill:"democracy",difficulty:"practice",mode:"daily-drill",teach:"Practice: Democracy gives people a voice in government.",practice:"Voting is one way.",q:"Democracy gives people a...",c:["voice","cell wall","fraction"],a:"voice"},
 {unit:"G7-SS-ECON",skill:"budget",difficulty:"practice",mode:"daily-drill",teach:"Practice: A budget is a plan for using money.",practice:"Families can make budgets.",q:"A budget is a money...",c:["plan","map","cell"],a:"plan"}
]);

LR_addLessons("Ava","Reading",[
 {unit:"G7-ELA-EVIDENCE",skill:"point of view",difficulty:"practice",mode:"daily-drill",teach:"Practice: Point of view affects how events are told.",practice:"Different narrators may describe things differently.",q:"Point of view affects how events are...",c:["told","multiplied","measured"],a:"told"}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-EQ",skill:"multi-step equations",difficulty:"practice",mode:"daily-drill",teach:"Practice: Solve equations one careful step at a time.",practice:"3x - 7 = 20 gives x = 9.",q:"3x - 7 = 20. x = ?",c:["9","13","27"],a:"9"},
 {unit:"G8-MATH-FUNC",skill:"slope-intercept form",difficulty:"practice",mode:"daily-drill",teach:"Practice: Slope-intercept form is y = mx + b.",practice:"m is slope and b is y-intercept.",q:"In y = mx + b, b is...",c:["y-intercept","slope","area"],a:"y-intercept"},
 {unit:"G8-MATH-FUNC",skill:"substitution",difficulty:"practice",mode:"daily-drill",teach:"Practice: Substitution can solve systems.",practice:"If y = x + 3 and y = 10, then x = 7.",q:"If y = x + 3 and y = 10, x = ?",c:["7","13","3"],a:"7"},
 {unit:"G8-MATH-GEO-DATA",skill:"dilations",difficulty:"practice",mode:"daily-drill",teach:"Practice: Dilations change size but not shape.",practice:"Scale factor 2 doubles lengths.",q:"A dilation changes...",c:["size","only color","only name"],a:"size"},
 {unit:"G8-MATH-NUMBERS",skill:"powers of ten",difficulty:"practice",mode:"daily-drill",teach:"Practice: Powers of ten help write very large or small numbers.",practice:"10^3 = 1000.",q:"10^3 equals...",c:["1000","100","10"],a:"1000"}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"evidence",difficulty:"practice",mode:"daily-drill",teach:"Practice: Evidence must support the claim.",practice:"Use proof that matches your point.",q:"Evidence should support the...",c:["claim","font","page color"],a:"claim"},
 {unit:"G8-ELA-ARG",skill:"transitions",difficulty:"practice",mode:"daily-drill",teach:"Practice: Transitions connect ideas.",practice:"Therefore shows result.",q:"Therefore shows...",c:["result","contrast only","time only"],a:"result"},
 {unit:"G8-ELA-RESEARCH",skill:"bias",difficulty:"practice",mode:"daily-drill",teach:"Practice: Bias can affect how information is presented.",practice:"A source may favor one side.",q:"Bias can affect source...",c:["presentation","volume","density"],a:"presentation"},
 {unit:"G8-ELA-READING",skill:"tone",difficulty:"practice",mode:"daily-drill",teach:"Practice: Tone is the author's attitude.",practice:"Words can sound serious or humorous.",q:"Tone means author's...",c:["attitude","address","font"],a:"attitude"}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-MATTER",skill:"mixtures",difficulty:"practice",mode:"daily-drill",teach:"Practice: A mixture combines substances physically.",practice:"Trail mix is a mixture.",q:"A mixture is combined...",c:["physically","only chemically","by voting"],a:"physically"},
 {unit:"G8-SCI-FORCE",skill:"acceleration",difficulty:"practice",mode:"daily-drill",teach:"Practice: Acceleration is change in velocity over time.",practice:"Speeding up is acceleration.",q:"Acceleration is change in...",c:["velocity","mass only","density"],a:"velocity"},
 {unit:"G8-SCI-WAVES-EARTH",skill:"thermal energy",difficulty:"practice",mode:"daily-drill",teach:"Practice: Thermal energy relates to particle motion.",practice:"Warmer particles move more.",q:"Thermal energy relates to particle...",c:["motion","citizenship","grammar"],a:"motion"}
]);

LR_addLessons("Michael","History",[
 {unit:"G8-SS-CIVICS",skill:"federalism",difficulty:"practice",mode:"daily-drill",teach:"Practice: Federalism divides power between national and state governments.",practice:"Both levels have roles.",q:"Federalism divides...",c:["power","energy","water"],a:"power"},
 {unit:"G8-SS-ECON",skill:"inflation",difficulty:"practice",mode:"daily-drill",teach:"Practice: Inflation is a general rise in prices over time.",practice:"Money buys less when prices rise.",q:"Inflation is a rise in...",c:["prices","gravity","cells"],a:"prices"},
 {unit:"G8-SS-HISTORICAL",skill:"interpretation",difficulty:"practice",mode:"daily-drill",teach:"Practice: Historical interpretation can change with new evidence.",practice:"A new document can alter understanding.",q:"New evidence can change historical...",c:["interpretation","gravity","volume"],a:"interpretation"}
]);

LR_addLessons("Michael","Civics",[
 {unit:"G8-SS-CIVICS",skill:"civil liberties",difficulty:"practice",mode:"daily-drill",teach:"Practice: Civil liberties protect individual freedoms.",practice:"Speech and religion can be liberties.",q:"Civil liberties protect individual...",c:["freedoms","rocks","variables"],a:"freedoms"}
]);
