/* LearningRealms Window Dedup + Button QA 7.3N
   Built on the stable 7.3M branch.
   Goal: keep the improved RPG layout, remove stacked/duplicate window caps, and make visible navigation buttons safer.
   No save reset. No lesson data changes. No render loop.
*/
(function(){
  'use strict';
  if(window.__LR73N_DEDUP_BUTTON_QA__) return;
  window.__LR73N_DEDUP_BUTTON_QA__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function cleanText(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }

  function installStyles(){
    if(byId('lr73nDedupStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr73nDedupStyles';
    st.textContent = `
      body.lr73nCleanCaps .lr73mWindowLabel,
      body.lr73nCleanCaps .lr73iWindowLabel{
        display:block!important;
        margin:0!important;
        padding:6px 10px!important;
        border-radius:0!important;
        border:0!important;
        border-bottom:1px solid rgba(245,223,154,.18)!important;
        background:linear-gradient(180deg,rgba(255,226,143,.12),rgba(0,0,0,.04))!important;
        color:#ffe5a0!important;
        font-size:.68rem!important;
        text-transform:uppercase!important;
        letter-spacing:.10em!important;
        font-weight:1000!important;
        text-align:center!important;
      }
      body.lr73nCleanCaps .lr73nGone{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;}
      body.lr73nCleanCaps .playerSidebar > .lr73mWindowLabel + .lr73mWindowLabel,
      body.lr73nCleanCaps .playerSidebar > .lr73iWindowLabel + .lr73iWindowLabel,
      body.lr73nCleanCaps .rightInfoCard > .lr73mWindowLabel + .lr73mWindowLabel,
      body.lr73nCleanCaps .rightInfoCard > .lr73iWindowLabel + .lr73iWindowLabel,
      body.lr73nCleanCaps .main > .card:first-child > .lr73mWindowLabel + .lr73mWindowLabel,
      body.lr73nCleanCaps .main > .card:first-child > .lr73iWindowLabel + .lr73iWindowLabel{
        display:none!important;
      }
      body.lr73nCleanCaps .lr73nDebugDead{outline:2px solid rgba(255,80,80,.35)!important;}
      body.lr73nCleanCaps .lr73nRoutedHint::after{content:'';display:none;}
    `;
    document.head.appendChild(st);
  }

  function normalizeWindowCap(container, title){
    if(!container) return;
    var caps = qa(':scope > .lr73mWindowLabel, :scope > .lr73iWindowLabel', container);
    // Remove every direct cap, then rebuild exactly one 7.3M-compatible cap.
    caps.forEach(function(el){ try{ el.remove(); }catch(e){} });
    var cap = document.createElement('div');
    cap.className = 'lr73mWindowLabel';
    cap.setAttribute('data-lr73n-single-cap','1');
    cap.textContent = title;
    container.insertBefore(cap, container.firstChild || null);
  }

  function dedupWindowCaps(){
    normalizeWindowCap(q('.playerSidebar'), 'Player Sheet');
    normalizeWindowCap(q('.actionSidebar'), 'Command Window');
    normalizeWindowCap(q('.rightInfoCard') || q('.rightSidebar .card'), 'Records Ledger');
    normalizeWindowCap(q('.main > .card:first-child'), 'Main Adventure Window');

    // Clean any older orphaned caps that got inserted into the wrong place by earlier branches.
    qa('.lr73iWindowLabel, .lr73mWindowLabel').forEach(function(el){
      var parent = el.parentElement;
      var allowed = parent && (parent.matches('.playerSidebar') || parent.matches('.actionSidebar') || parent.matches('.rightInfoCard') || parent.matches('.main > .card:first-child'));
      if(!allowed){
        var t = cleanText(el).toLowerCase();
        if(t === 'player sheet' || t === 'records ledger' || t === 'main adventure window' || t === 'realm scene window' || t === 'command window'){
          try{ el.classList.add('lr73nGone'); }catch(e){}
        }
      }
    });
  }

  function has(fn){ return typeof window[fn] === 'function'; }
  function tryCall(list){
    for(var i=0;i<list.length;i++){
      var item = list[i];
      var fn = item[0], args = item.slice(1);
      if(has(fn)){
        try{ window[fn].apply(window,args); scheduleClean(); return true; }
        catch(e){ console.warn('LR73N button route failed:', fn, e); }
      }
    }
    return false;
  }

  function openFallbackHub(kind){
    if(has('lr73mDo')){
      try{ window.lr73mDo(kind || 'map'); return true; }catch(e){}
    }
    return false;
  }

  function routeAction(act){
    act = String(act || '').toLowerCase();
    if(act === 'scene') return tryCall([['lr68Render','room','You return to the main scene.'],['lr68Render'],['renderRoom']]) || openFallbackHub('scene');
    if(act === 'learn' || act === 'golearn') return openFallbackHub('learn') || tryCall([['lr68bOpenLearningTrails','featured'],['lr68OpenLearn'],['openRealCurriculumPicker']]);
    if(act === 'map' || act === 'realmmap' || act === 'atlas') return openFallbackHub('map') || tryCall([['openWorldAtlas']]);
    if(act === 'history' || act === 'historywing') return openFallbackHub('history') || tryCall([['lr68bOpenLearningTrails','world']]);
    if(act === 'depression') return tryCall([['openGreatDepressionTrail'],['openGreatDepressionCourse'],['openGreatDepressionRewards']]) || openFallbackHub('history');
    if(act === 'wildwest' || act === 'wild west') return tryCall([['openWildWestTrail'],['openWildWestCourse'],['openWildWestShops']]) || openFallbackHub('history');
    if(act === 'bible' || act === 'bibleroad') return openFallbackHub('bible') || tryCall([['openBibleHistoryTrail'],['openBibleHistoryCourse']]);
    if(act === 'bibleartifacts' || act === 'artifacts') return tryCall([['openBibleHistoryArtifacts73B'],['openBibleHistoryRewards'],['openBibleHistoryCourse']]) || openFallbackHub('bible');
    if(act === 'home') return tryCall([['lr68OpenHome'],['openHomeView'],['openHomeRenderer'],['openVisualHome'],['openHomeRooms']]) || openFallbackHub('map');
    if(act === 'shipwreck') return tryCall([['shipwreckGuidedZoneOpen'],['openShipwreckCoveDeepCourse'],['openShipwreckCoveMap']]) || openFallbackHub('learn');
    if(act === 'items' || act === 'inventory') return tryCall([['openCollectionLog'],['openBackpack'],['openInventoryPopup'],['openWorldAtlas']]) || openFallbackHub('map');
    if(act === 'pets' || act === 'companions') return tryCall([['openCompanionDen'],['openCompanionPopup'],['openCompanionEngine']]) || openFallbackHub('map');
    if(act === 'quests') return tryCall([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openQuestPopup']]) || openFallbackHub('map');
    if(act === 'look') return tryCall([['lr68Render','look','You inspect the room.'],['openSubjectAtlasRoom'],['openWorldAtlas']]) || openFallbackHub('map');
    if(act === 'talk') return tryCall([['lr68Render','talk','You look for someone to talk to.'],['openNpcRelations'],['openQuestJournal']]) || openFallbackHub('map');
    return openFallbackHub('map');
  }

  function inferActionFromText(txt){
    txt = String(txt || '').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();
    if(!txt) return '';
    if(txt.indexOf('great depression') >= 0 || txt === 'depression') return 'depression';
    if(txt.indexOf('wild west') >= 0) return 'wildwest';
    if(txt.indexOf('bible artifact') >= 0 || txt === 'artifacts' || txt.indexOf('artifact hall') >= 0) return 'bibleartifacts';
    if(txt.indexOf('bible') >= 0) return 'bible';
    if(txt.indexOf('history') >= 0) return 'history';
    if(txt.indexOf('go learn') >= 0 || txt.indexOf('learning trail') >= 0 || txt === 'learn') return 'learn';
    if(txt.indexOf('realm map') >= 0 || txt.indexOf('world atlas') >= 0 || txt === 'map') return 'map';
    if(txt === 'scene' || txt.indexOf('return to scene') >= 0) return 'scene';
    if(txt.indexOf('shipwreck') >= 0) return 'shipwreck';
    if(txt.indexOf('home') >= 0) return 'home';
    if(txt.indexOf('collection') >= 0 || txt.indexOf('items') >= 0 || txt.indexOf('inventory') >= 0) return 'items';
    if(txt.indexOf('companion') >= 0 || txt.indexOf('pet') >= 0) return 'pets';
    if(txt.indexOf('quest') >= 0) return 'quests';
    if(txt === 'look') return 'look';
    if(txt === 'talk') return 'talk';
    return '';
  }

  function routeObviousNavButtons(){
    var navRoots = qa('.compactHeader, .playerSidebar, .actionSidebar, .rightSidebar, .lr73mFooter, .lr73mChoiceGrid, .lr73mLedger, .lr73mTopNav');
    navRoots.forEach(function(root){
      qa('button', root).forEach(function(btn){
        if(btn.hasAttribute('data-lr73n-skip')) return;
        var existing = btn.getAttribute('data-lr73m-act') || btn.getAttribute('data-lr73n-act');
        var act = existing || inferActionFromText(cleanText(btn));
        if(!act) return;
        btn.setAttribute('data-lr73n-act', act);
        btn.classList.add('lr73nRoutedHint');
      });
    });
  }

  function addAliases(){
    // Harmless aliases for old buttons that used older names.
    if(!has('openBibleHistoryArtifacts') && has('openBibleHistoryArtifacts73B')) window.openBibleHistoryArtifacts = window.openBibleHistoryArtifacts73B;
    if(!has('openInventoryPopup') && has('openCollectionLog')) window.openInventoryPopup = window.openCollectionLog;
    if(!has('openBackpack') && has('openCollectionLog')) window.openBackpack = window.openCollectionLog;
    if(!has('openPetJournal') && has('openCompanionDen')) window.openPetJournal = window.openCompanionDen;
    if(!has('openDailyQuestBoard') && has('openQuestBoard')) window.openDailyQuestBoard = window.openQuestBoard;
    if(!has('openHomeRooms') && has('openHomeRenderer')) window.openHomeRooms = window.openHomeRenderer;
  }

  var cleanTimer = 0;
  function cleanNow(){
    cleanTimer = 0;
    try{ document.body.classList.add('lr73nCleanCaps'); }catch(e){}
    installStyles(); addAliases(); dedupWindowCaps(); routeObviousNavButtons();
  }
  function scheduleClean(){
    if(cleanTimer) return;
    cleanTimer = setTimeout(cleanNow, 35);
  }

  function bindRouting(){
    if(window.__LR73N_ROUTING_BOUND__) return;
    window.__LR73N_ROUTING_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr73n-act]') : null;
      if(!btn) return;
      var root = btn.closest('.compactHeader, .playerSidebar, .actionSidebar, .rightSidebar, .lr73mFooter, .lr73mChoiceGrid, .lr73mLedger, .lr73mTopNav');
      if(!root) return;
      ev.preventDefault(); ev.stopPropagation();
      routeAction(btn.getAttribute('data-lr73n-act'));
    }, true);
  }

  function hook73m(){
    if(window.__LR73N_WRAPPED_73M__) return;
    if(typeof window.lr73mDo !== 'function') return;
    window.__LR73N_WRAPPED_73M__ = true;
    var old = window.lr73mDo;
    window.lr73mDo = function(act){
      var out = old.apply(window, arguments);
      scheduleClean(); setTimeout(cleanNow, 120); setTimeout(cleanNow, 360);
      return out;
    };
  }

  function boot(){
    bindRouting(); hook73m(); cleanNow();
    setTimeout(function(){ hook73m(); cleanNow(); }, 120);
    setTimeout(cleanNow, 450);
    setTimeout(cleanNow, 1100);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,80); setTimeout(cleanNow,700); });
})();
