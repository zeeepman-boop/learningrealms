// Curriculum Pack 6L Writing Forge
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Writing",[
{teach:"Sentences begin with capital letters.",q:"Sentences begin with...",c:["capital letters","numbers","spaces"],a:"capital letters"},
{teach:"Sentences end with punctuation.",q:"A sentence should end with...",c:["punctuation","a picture","nothing"],a:"punctuation"},
{teach:"Words are separated by spaces.",q:"Words need...",c:["spaces","commas only","boxes"],a:"spaces"},
{teach:"Names use capitals.",q:"People names use...",c:["capitals","lowercase only","numbers"],a:"capitals"}
]);

LR_addLessons("Ava","Writing",[
{teach:"Topic sentences introduce paragraphs.",q:"A paragraph starts with...",c:["topic sentence","ending","title only"],a:"topic sentence"},
{teach:"Opinion writing gives reasons.",q:"Opinions should include...",c:["reasons","random facts","maps"],a:"reasons"},
{teach:"Transitions connect ideas.",q:"Transitions help...",c:["connect ideas","draw pictures","count"],a:"connect ideas"},
{teach:"Revision improves writing.",q:"Revision means...",c:["improving","copying","erasing all"],a:"improving"}
]);

LR_addLessons("Michael","Writing",[
{teach:"Thesis statements guide essays.",q:"A thesis helps...",c:["guide essays","decorate","count"],a:"guide essays"},
{teach:"Evidence strengthens arguments.",q:"Arguments need...",c:["evidence","luck","titles"],a:"evidence"},
{teach:"Organization improves clarity.",q:"Good organization improves...",c:["clarity","paper color","font"],a:"clarity"},
{teach:"Editing checks conventions.",q:"Editing checks...",c:["conventions","maps","equations"],a:"conventions"}
]);
})();