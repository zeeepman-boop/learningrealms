// Health / Body Science Realm Pack 1: Hearthwell Clinic
// Adds a dedicated Health subject realm with body systems, nutrition basics, sleep, exercise, hygiene, safety, and healthy habits.
// Uses subject key "Health" for engine simplicity.
// Educational only. Not medical advice.
// Adds starter Health grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const healthRooms = {
    hearthwellRoad1:{
      title:"Cleanwater Walk",
      zone:"Hearthwell Road",
      text:"A bright path leaves town beside a clear little channel of running water. Painted signs show soap bubbles, apples, lungs, hearts, bones, sleep moons, and walking shoes.",
      exits:{southwest:"townSquare",east:"hearthwellRoad2"}
    },
    hearthwellRoad2:{
      title:"Wellness Bend",
      zone:"Hearthwell Road",
      text:"The road curves past benches shaped like leaves. A cheerful sign reads: Strong bodies learn better. Another sign shows food, water, rest, movement, and safety.",
      exits:{west:"hearthwellRoad1",east:"hearthwellGate"}
    },
    hearthwellGate:{
      title:"Hearthwell Gate",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"A warm stone clinic stands beside herb gardens and exercise paths. It feels calm, clean, and friendly. Lanterns glow over doorways marked Body, Food, Rest, Movement, and Safety.",
      npc:{name:"Nurse Briar",desc:"A kind clinic guide with a notebook and a gentle voice.",text:"Nurse Briar smiles. 'Health study is learning how the body works and how wise habits help us care for it.'"},
      exits:{west:"hearthwellRoad2",east:"bodyHall",south:"hygieneRoom"}
    },
    bodyHall:{
      title:"Body Systems Hall",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"Large friendly diagrams show the heart, lungs, stomach, brain, bones, muscles, and nerves. Nothing is scary here. Everything is labeled as part of a clever working body.",
      npc:{name:"Doctor Mapwell",desc:"A calm anatomy teacher who explains body systems in simple, careful language.",text:"Doctor Mapwell points to a diagram. 'The body is not one thing. It is many systems working together.'"},
      exits:{west:"hearthwellGate",east:"movementYard",south:"nutritionKitchen"}
    },
    hygieneRoom:{
      title:"Bubblewash Room",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"Gentle fountains, soapstone sinks, tooth models, clean towels, and handwashing posters fill this bright room. Bubbles drift lazily through the air.",
      npc:{name:"Suds the Soap Sprite",desc:"A bubbly little sprite who teaches hygiene, teeth, handwashing, and cleanliness.",text:"Suds bounces in a bubble. 'Tiny habits can stop big messes. Wash, brush, clean, repeat!'"},
      exits:{north:"hearthwellGate",east:"nutritionKitchen",south:"safetyWorkshop"}
    },
    nutritionKitchen:{
      title:"Nutrition Kitchen",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"A teaching kitchen displays colorful pretend foods: vegetables, fruit, grains, eggs, beans, meat, milk, water, and healthy fats. A big plate poster shows balance and variety.",
      npc:{name:"Chef Vita",desc:"A practical kitchen teacher who explains food groups, nutrients, hydration, and balanced meals.",text:"Chef Vita stirs a soup pot. 'Food is fuel, but also building material. Different foods help the body in different ways.'"},
      exits:{north:"bodyHall",west:"hygieneRoom",east:"sleepSanctum",south:"safetyWorkshop"}
    },
    movementYard:{
      title:"Movement Yard",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"A sunny yard holds stepping stones, balance beams, stretching ropes, and walking paths. Signs explain muscles, bones, heart, lungs, strength, balance, and endurance.",
      npc:{name:"Coach Rowan",desc:"A cheerful movement coach who teaches exercise, posture, balance, and active habits.",text:"Coach Rowan claps once. 'Movement helps the heart, lungs, muscles, bones, mood, and focus. Small steps count.'"},
      exits:{west:"bodyHall",south:"sleepSanctum"}
    },
    sleepSanctum:{
      title:"Sleep Sanctum",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"Soft moon lamps glow over quiet cushions and star charts. The walls show simple lessons about sleep, rest, routines, and how bodies recharge.",
      npc:{name:"Moonkeeper Sel",desc:"A soft-spoken guide who teaches sleep, rest, routines, and recovery.",text:"Sel lowers her voice. 'Sleep is not wasted time. It is when the body repairs, grows, and stores learning.'"},
      exits:{north:"movementYard",west:"nutritionKitchen",south:"safetyWorkshop"}
    },
    safetyWorkshop:{
      title:"Safety Workshop",
      zone:"Hearthwell Clinic",
      subject:"Health",
      text:"A tidy workshop holds helmets, bright vests, first-aid posters, safe-tool models, fire-safety cards, and weather-safety signs. The room feels practical and careful.",
      npc:{name:"Captain Safehand",desc:"A careful safety teacher who explains injury prevention, emergencies, and wise caution.",text:"Captain Safehand taps a helmet. 'Safety is not fear. Safety is paying attention before trouble starts.'"},
      exits:{north:"nutritionKitchen",west:"hygieneRoom",east:"sleepSanctum"}
    }
  };

  Object.assign(ROOMS, healthRooms);

  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.southwest) ROOMS.townSquare.exits.southwest = "hearthwellRoad1";
    else if(!ROOMS.townSquare.exits.west) ROOMS.townSquare.exits.west = "hearthwellRoad1";
  }
})();

(function(){
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Health = window.LR_REWARDS.Health || [];
  window.LR_REWARDS.Health.push(
    {name:"Tiny Heart Lantern",slot:"shelf"},
    {name:"Bubblewash Badge",slot:"wall"},
    {name:"Balanced Plate Tile",slot:"wall"},
    {name:"Sleep Moon Pillow",slot:"shelf"},
    {name:"Movement Yard Ribbon",slot:"wall"},
    {name:"Safety Helmet Model",slot:"shelf"},
    {name:"Water Cup Trophy",slot:"desk"},
    {name:"Body Systems Chart",slot:"wall"}
  );
})();

(function(){
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Health = {display:"Health / Body / Habits",targetCorrect:150,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Health = {display:"Health / Body Science / Safety",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Health = {display:"Health / Body Systems / Evidence",targetCorrect:240,bossTarget:1};
})();

(function(){
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Health")) cfg.assignmentSubjects[child].push("Health");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Health:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Health:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Health:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Health = {
    zone:"Hearthwell Clinic",
    units:[
      {id:"G1-HEALTH-BODY",title:"Body Basics",goal:"Recognize major body parts and simple body jobs.",targetLessons:100,skills:["heart","lungs","bones","muscles","brain","stomach"]},
      {id:"G1-HEALTH-HABITS",title:"Healthy Habits",goal:"Understand simple habits such as washing hands, brushing teeth, drinking water, sleeping, and moving.",targetLessons:120,skills:["handwashing","teeth","water","sleep","movement","cleanliness"]},
      {id:"G1-HEALTH-SAFETY",title:"Everyday Safety",goal:"Learn basic safety habits at home and outdoors.",targetLessons:90,skills:["helmet","fire safety","tool safety","weather safety","ask an adult"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Health = {
    zone:"Hearthwell Clinic",
    units:[
      {id:"G6-HEALTH-SYSTEMS",title:"Body Systems",goal:"Understand basic body systems and how they work together.",targetLessons:150,skills:["circulatory","respiratory","digestive","muscular","skeletal","nervous"]},
      {id:"G6-HEALTH-NUTRITION",title:"Nutrition and Energy",goal:"Understand nutrients, hydration, balanced meals, and food as fuel/building material.",targetLessons:150,skills:["protein","carbohydrate","fat","vitamin","mineral","water","fiber"]},
      {id:"G6-HEALTH-HABITS",title:"Sleep, Movement, Hygiene, Safety",goal:"Explain how habits support body function and safety.",targetLessons:140,skills:["sleep","exercise","hygiene","injury prevention","routine","recovery"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Health = {
    zone:"Hearthwell Clinic",
    units:[
      {id:"G7-HEALTH-SYSTEMS",title:"Body Systems and Interactions",goal:"Analyze how body systems interact and support activity, growth, and recovery.",targetLessons:170,skills:["homeostasis","circulation","respiration","digestion","nervous system","muscle function"]},
      {id:"G7-HEALTH-EVIDENCE",title:"Health Claims and Evidence",goal:"Evaluate simple health claims using evidence, source quality, and clear reasoning.",targetLessons:150,skills:["claim","evidence","source quality","correlation","causation","risk"]},
      {id:"G7-HEALTH-PRACTICAL",title:"Practical Health Habits",goal:"Connect sleep, nutrition, movement, hydration, hygiene, and safety to daily function.",targetLessons:140,skills:["sleep","hydration","nutrition","movement","hygiene","safety"]}
    ]
  };
})();

(function(){
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-HEALTH-HABIT-1",subject:"Health",unit:"G1-HEALTH-HABITS",title:"Healthy Habit Picture",prompt:"Draw or describe one healthy habit. Tell how it helps your body.",helper:"Try washing hands, brushing teeth, drinking water, sleeping, or moving.",estimatedMinutes:15},
    {id:"LUNA-HEALTH-SAFETY-1",subject:"Health",unit:"G1-HEALTH-SAFETY",title:"Safety Rule",prompt:"Write or tell one safety rule and why it matters.",helper:"Use: My safety rule is ___. It matters because ___.",estimatedMinutes:15}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-HEALTH-SYSTEMS-1",subject:"Health",unit:"G6-HEALTH-SYSTEMS",title:"Body Systems Work Together",prompt:"Choose two body systems and explain how they work together during movement.",helper:"Examples: heart/lungs, muscles/bones, brain/muscles.",estimatedMinutes:25},
    {id:"AVA-HEALTH-NUTRITION-1",subject:"Health",unit:"G6-HEALTH-NUTRITION",title:"Balanced Meal Explanation",prompt:"Describe a balanced meal and explain what different parts of it do for the body.",helper:"Mention protein, energy, water, fiber, vitamins, or minerals.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-HEALTH-EVIDENCE-1",subject:"Health",unit:"G7-HEALTH-EVIDENCE",title:"Evaluate a Health Claim",prompt:"Create a simple health claim, then explain what evidence would be needed before trusting it.",helper:"Mention source quality, evidence, and avoiding big claims without proof.",estimatedMinutes:30},
    {id:"MICHAEL-HEALTH-SYSTEMS-1",subject:"Health",unit:"G7-HEALTH-SYSTEMS",title:"Systems During Exercise",prompt:"Explain how the heart, lungs, muscles, and brain work together during physical activity.",helper:"Use cause and effect language.",estimatedMinutes:30}
  );
})();

(function(){
  function LR_addHealthLadder(child){
    LR_addLessons(child,"Health",[
      {gradeBand:"K",unit:"K-HEALTH-BODY",skill:"body parts",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Your body has many parts with different jobs.",
       workedExample:"Eyes help you see. Ears help you hear. Legs help you walk.",
       guidedPractice:"Choose the body part that helps you see.",
       q:"Which body part helps you see?",c:["eyes","feet","elbows"],a:"eyes",
       explain:"Eyes help you see."},

      {gradeBand:"G1",unit:"G1-HEALTH-HABITS",skill:"handwashing",difficulty:"grade 1",mode:"foundation",
       miniLesson:"Washing hands helps remove dirt and germs.",
       workedExample:"People wash hands before eating and after using the bathroom.",
       guidedPractice:"Choose when handwashing is helpful.",
       q:"When is handwashing helpful?",c:["before eating","after sleeping only","never"],a:"before eating",
       explain:"Washing hands before eating helps keep hands clean."},

      {gradeBand:"G2",unit:"G2-HEALTH-NUTRITION",skill:"food groups",difficulty:"grade 2",mode:"foundation",
       miniLesson:"Different foods help the body in different ways.",
       workedExample:"Fruits and vegetables can provide vitamins and fiber. Protein foods help build and repair body tissues.",
       guidedPractice:"Choose the food group that helps build and repair.",
       q:"Protein foods help the body...",c:["build and repair","turn invisible","read maps"],a:"build and repair",
       explain:"Protein helps support building and repairing body tissues."},

      {gradeBand:"G3",unit:"G3-HEALTH-SLEEP",skill:"sleep",difficulty:"grade 3",mode:"foundation",
       miniLesson:"Sleep helps the body rest, grow, repair, and store learning.",
       workedExample:"After a good night's sleep, many people can focus better and feel more ready for the day.",
       guidedPractice:"Think about what sleep helps.",
       q:"Sleep helps the body...",c:["rest and repair","forget all learning","avoid water forever"],a:"rest and repair",
       explain:"Sleep supports rest, repair, growth, and learning."},

      {gradeBand:"G4",unit:"G4-HEALTH-SYSTEMS",skill:"heart and lungs",difficulty:"grade 4",mode:"foundation",
       miniLesson:"The heart and lungs work together during activity.",
       workedExample:"The lungs bring in oxygen. The heart helps move blood carrying oxygen around the body.",
       guidedPractice:"Match the organ to its job.",
       q:"Which organ helps pump blood?",c:["heart","stomach","bone"],a:"heart",
       explain:"The heart pumps blood through the body."},

      {gradeBand:"G5",unit:"G5-HEALTH-SAFETY",skill:"injury prevention",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Injury prevention means making careful choices to reduce the chance of getting hurt.",
       workedExample:"Wearing a helmet while riding can help protect the head.",
       guidedPractice:"Choose the safety item.",
       q:"A helmet helps protect the...",c:["head","shoelace","lunch"],a:"head",
       explain:"A helmet is meant to help protect the head."},

      {gradeBand:"G6",unit:"G6-HEALTH-SYSTEMS",skill:"body systems",difficulty:"grade 6",mode:"foundation",
       miniLesson:"Body systems work together to keep the body functioning.",
       workedExample:"The digestive system breaks down food, and the circulatory system helps carry nutrients around the body.",
       guidedPractice:"Think about how systems cooperate.",
       q:"Which system helps break down food?",c:["digestive system","skeletal system","map system"],a:"digestive system",
       explain:"The digestive system breaks down food."},

      {gradeBand:"G7",unit:"G7-HEALTH-EVIDENCE",skill:"health claims",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Health claims should be checked with evidence and source quality.",
       workedExample:"A claim from an unknown source with no evidence is weaker than a claim supported by clear, reliable information.",
       guidedPractice:"Ask who made the claim and what proof they give.",
       q:"A health claim is stronger when it has...",c:["reliable evidence","only a loud promise","no source"],a:"reliable evidence",
       explain:"Reliable evidence makes a health claim stronger."},

      {gradeBand:"G8",unit:"G8-HEALTH-SYSTEMS",skill:"system interaction",difficulty:"grade 8",mode:"foundation",
       miniLesson:"During exercise, several body systems work together.",
       workedExample:"The lungs bring in oxygen, the heart moves blood, muscles use energy, and the brain coordinates movement.",
       guidedPractice:"Look for systems working together.",
       q:"During exercise, the heart helps move...",c:["blood","sunlight","paragraphs"],a:"blood",
       explain:"The heart pumps blood to help support the body's activity."}
    ]);
  }

  LR_addHealthLadder("Luna");
  LR_addHealthLadder("Ava");
  LR_addHealthLadder("Michael");
})();

(function(){
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Health = [
    {title:"Bubblewash Trial",intro:"Suds the Soap Sprite bounces beside a sink.",q:"Washing hands helps remove dirt and...",c:["germs","maps","coins"],a:"germs",reward:"Bubblewash Badge"},
    {title:"Sleep Moon Trial",intro:"Moonkeeper Sel points to a soft moon lamp.",q:"Sleep helps the body rest and...",c:["repair","turn to stone","forget everything"],a:"repair",reward:"Sleep Moon Star"}
  ];

  window.LR_BOSS_CONTENT.Ava.Health = [
    {title:"Body Systems Trial",intro:"Doctor Mapwell points to diagrams of lungs and heart.",q:"The heart helps pump...",c:["blood","air only","food pieces"],a:"blood",reward:"Body Systems Chart"},
    {title:"Nutrition Kitchen Trial",intro:"Chef Vita sets out several balanced food models.",q:"Protein helps the body...",c:["build and repair","read maps","make thunder"],a:"build and repair",reward:"Balanced Plate Tile"}
  ];

  window.LR_BOSS_CONTENT.Michael.Health = [
    {title:"Health Evidence Trial",intro:"Nurse Briar asks for proof before trusting a big claim.",q:"A health claim is stronger when it has...",c:["reliable evidence","no source","only hype"],a:"reliable evidence",reward:"Evidence Lantern"},
    {title:"Exercise Systems Trial",intro:"Coach Rowan points to heart, lungs, muscles, and brain diagrams.",q:"During exercise, the lungs bring in...",c:["oxygen","coins","map symbols"],a:"oxygen",reward:"Movement Yard Medal"}
  ];
})();
