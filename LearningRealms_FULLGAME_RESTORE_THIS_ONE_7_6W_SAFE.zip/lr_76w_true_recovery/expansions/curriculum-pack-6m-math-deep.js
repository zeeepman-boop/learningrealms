// Curriculum Pack 6M Math Deep Expansion
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Math",[
{teach:"Count by ones.",q:"What comes after 7?",c:["8","6","10"],a:"8"},
{teach:"Addition combines groups.",q:"2 + 3 = ?",c:["5","4","6"],a:"5"},
{teach:"Place value gives digit meaning.",q:"In 14, the 1 means...",c:["ten","one","hundred"],a:"ten"},
{teach:"Clocks tell time.",q:"Time is shown on a...",c:["clock","map","book"],a:"clock"},
{teach:"Coins have value.",q:"Money uses...",c:["coins","clouds","rocks"],a:"coins"}
]);

LR_addLessons("Ava","Math",[
{teach:"Ratios compare amounts.",q:"Ratios compare...",c:["amounts","letters","maps"],a:"amounts"},
{teach:"Percent means per hundred.",q:"Percent means...",c:["per hundred","per ten","per thousand"],a:"per hundred"},
{teach:"Probability measures chance.",q:"Probability measures...",c:["chance","distance","time"],a:"chance"},
{teach:"Geometry studies shapes.",q:"Geometry studies...",c:["shapes","weather","plants"],a:"shapes"},
{teach:"Integers include negatives.",q:"Integers can be...",c:["negative","only positive","fractions only"],a:"negative"}
]);

LR_addLessons("Michael","Math",[
{teach:"Variables represent values.",q:"Variables stand for...",c:["values","colors","rooms"],a:"values"},
{teach:"Expressions contain operations.",q:"Expressions use...",c:["operations","chapters","maps"],a:"operations"},
{teach:"Functions relate inputs and outputs.",q:"Functions connect...",c:["inputs and outputs","pages","coins"],a:"inputs and outputs"},
{teach:"Equations can be solved.",q:"Equations are...",c:["solved","painted","ignored"],a:"solved"},
{teach:"Graphs show relationships.",q:"Graphs display...",c:["relationships","stories","songs"],a:"relationships"}
]);
})();