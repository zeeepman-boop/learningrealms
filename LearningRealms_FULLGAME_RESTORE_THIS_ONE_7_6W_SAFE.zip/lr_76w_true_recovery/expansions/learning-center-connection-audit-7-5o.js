/* LearningRealms Learning Center Connection Audit 7.5O
   Built from 7.5N. Conservative navigation/connection pass only.
   Goal: make sure existing subjects, legacy packs, practice drawers, and living-world systems
   are reachable from the Realm Library without adding a heavy render loop or rewriting the shell.
*/
(function(){
  'use strict';
  if(window.__LR75O_CONNECTION_AUDIT__) return;
  window.__LR75O_CONNECTION_AUDIT__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function callAny(list){
    for(var i=0;i<list.length;i++){
      var fn=list[i];
      if(has(fn)){
        try{ window[fn](); return true; }
        catch(e){ console.warn('LR75O route failed:', fn, e); }
      }
    }
    return false;
  }
  function actionMount(title, html){
    installStyles();
    var t=byId('actionTitle'), b=byId('actionText');
    if(t) t.textContent = title || 'Learning Center';
    if(b) b.innerHTML = html;
    if(has('lrOpenActionPopup')){ try{ window.lrOpenActionPopup(title || 'Learning Center'); }catch(e){} }
    else if(has('lrOpenPopup')){ try{ window.lrOpenPopup(title || 'Learning Center', html); }catch(e){} }
  }
  function soft(title, body){
    actionMount(title || 'Door Note', '<div class="lr75oShell"><div class="lr75oHero"><div class="lr75oHeroIcon">🧭</div><div><h2>'+esc(title||'Door Note')+'</h2><p>'+esc(body||'This path is connected through the Learning Center, but its older room uses a legacy drawer or fallback surface. Use the exit rail to return when finished.')+'</p></div></div><div class="lr75oNav"><button data-lr75o-act="library">Realm Library</button><button data-lr75o-act="audit">Connection Ledger</button></div></div>');
  }
  function openLibrary(){
    if(has('openRealmLibrary75A')){ window.openRealmLibrary75A(); return true; }
    if(has('openRealmLibrary75B')){ window.openRealmLibrary75B(); return true; }
    if(has('openRealCurriculumPicker')){ window.openRealCurriculumPicker(); return true; }
    soft('Realm Library', 'The Realm Library route is present, but the opener did not answer in this build.');
    return false;
  }
  function openWing(key){
    if(has('openRealmLibrary75A')){ window.openRealmLibrary75A(key); return true; }
    if(has('openRealmLibrary75B')){ window.openRealmLibrary75B(key); return true; }
    openLibrary(); return true;
  }

  var CONNECTIONS = [
    {wing:'core', type:'master', icon:'📚', title:'Reading Comprehension Master Course', call:['openReadingComprehensionMasterCourse75C','openReadingComprehensionMasterCourse','openReadingComprehension'], note:'Lantern Library and reading strategy chambers.'},
    {wing:'core', type:'master', icon:'🪶', title:'Writing Composition Master Course', call:['openWritingCompositionMasterCourse','openWritingCompositionMaster74W','openAuthorGuild'], note:'Ink Tower, Story Forge, essay craft, revision, and portfolios.'},
    {wing:'core', type:'master', icon:'🧮', title:'Math Adventure Master Course', call:['openMathAdventureMasterCourse75D','openMathAdventureMasterCourse','openMathAdventure'], note:'Number Vault, fractions, geometry, equations, data, ratios, and problem solving.'},
    {wing:'core', type:'master', icon:'🧠', title:'Logic Tower & Critical Thinking', call:['openLogicTowerCriticalThinking75E','openLogicTowerMasterCourse','openLogicTower'], note:'Riddle Tower, evidence rooms, pattern gates, arguments, and puzzle logic.'},
    {wing:'core', type:'master', icon:'🔤', title:'Grammar, Vocabulary & Language Forge', call:['openGrammarVocabularyLanguageForge75F','openGrammarMasterCourse','openWordForge'], note:'Word Forge, grammar workshop, vocabulary, editing, and punctuation.'},
    {wing:'core', type:'drawer', icon:'✍️', title:'Copywork & Handwriting Drawer', drawer:'copywork', note:'Legacy copywork practice is placed under Core Halls instead of floating elsewhere.'},
    {wing:'core', type:'drawer', icon:'🌳', title:'Counting Orchard Drawer', drawer:'counting', note:'Early number sense and counting practice.'},
    {wing:'core', type:'drawer', icon:'🏰', title:'Fraction Castle Drawer', drawer:'fractions', note:'Fraction foundations and equivalent fraction practice.'},
    {wing:'core', type:'drawer', icon:'💎', title:'Geometry Caverns Drawer', drawer:'geometry', note:'Shapes, angles, area, volume, and geometry practice.'},
    {wing:'core', type:'drawer', icon:'⚖️', title:'Equation Forge Drawer', drawer:'equations', note:'Variables, equations, inequalities, and algebra foundations.'},
    {wing:'core', type:'drawer', icon:'🎒', title:'Grade Ladder Drawer', drawer:'gradeladder', note:'Older grade ladder material is connected as a Core Halls drawer.'},

    {wing:'science', type:'master', icon:'🔬', title:'Science and Engineering Expedition', call:['openScienceEngineeringAdventure74M','openScienceEngineeringQuarter74M'], note:'Matter, forces, machines, energy, circuits, plants, habitats, and design.'},
    {wing:'science', type:'master', icon:'🛠️', title:'Inventions & Engineering Disasters', call:['openInventionsEngineeringMaster74R','openInventionsEngineeringDisasters74R','openInventionsDeepCourse'], note:'Blueprints, failures, redesign, safety, and engineering evidence.'},
    {wing:'science', type:'master', icon:'🚀', title:'Aerospace Engineering Mission Wing', call:['openAerospaceEngineering74S','openAerospaceEngineering','openAerospaceMissionWing74S'], note:'Flight, rockets, orbits, satellites, mission control, and space tools.'},
    {wing:'science', type:'master', icon:'🌿', title:'Nature & Health Deep Adventure', call:['openNatureHealthDeepAdventure','openNatureHealth74T','openNatureAndHealth'], note:'Field trails, ecosystems, safe health systems, hygiene, sleep, and readiness.'},
    {wing:'science', type:'master', icon:'🌦️', title:'Weather & Storm Lab', call:['openWeatherStormLab74U','openWeatherStormLab','openStormwatchTower'], note:'Clouds, pressure, storms, maps, radar, satellites, and safety planning.'},
    {wing:'science', type:'master', icon:'🐾', title:'Animal Kingdom & Creature Field Guide', call:['openCreatureFieldGuide','openAnimalKingdom74V','openAnimalKingdom'], note:'Creature groups, habitats, tracks, animal care, and field journals.'},
    {wing:'science', type:'drawer', icon:'⚗️', title:'Chemistry Institute Drawer', drawer:'chemistry', note:'Older chemistry packs are grouped here.'},
    {wing:'science', type:'drawer', icon:'🪐', title:'Astronomy Observatory Drawer', drawer:'astronomy', note:'Astronomy and space observatory practice.'},
    {wing:'science', type:'drawer', icon:'🌎', title:'Earth Science Drawer', drawer:'earth', note:'Rocks, erosion, volcanoes, weathering, and Earth systems.'},
    {wing:'science', type:'drawer', icon:'🌱', title:'Botany Conservatory Drawer', drawer:'botany', note:'Plants, seeds, flowers, roots, and gardens.'},
    {wing:'science', type:'drawer', icon:'⚡', title:'Electricity Lab Drawer', drawer:'electricity', note:'Circuits, magnets, conductors, and safe electricity basics.'},
    {wing:'science', type:'drawer', icon:'🧲', title:'Physics Forge Drawer', drawer:'physics', note:'Motion, force, energy, machines, and physical science.'},
    {wing:'science', type:'drawer', icon:'🤖', title:'Robotics & Computer Science Drawer', drawer:'computers', note:'Robotics, algorithms, commands, and computer science basics.'},
    {wing:'science', type:'drawer', icon:'🦖', title:'Dinosaur & Fossil Drawer', drawer:'dinosaurs', note:'Older dinosaur/fossil material is connected as science legacy.'},
    {wing:'science', type:'drawer', icon:'🐜', title:'Insect Kingdom Drawer', drawer:'insects', note:'Insects, pollinators, habitats, and observation practice.'},

    {wing:'history', type:'master', icon:'𓂀', title:'Ancient Egypt Expedition', call:['openAncientEgyptCourse','openAncientEgyptTrail','openLearningRealmsEgyptRoad'], note:'Nile, pharaohs, monuments, temples, daily life, archaeology, and artifacts.'},
    {wing:'history', type:'master', icon:'🏛️', title:'Ancient Greece & Rome Road', call:['openAncientGreeceRome75N','openAncientGreeceRomeRoad','openGreeceRomeRoad'], note:'Aegean worlds, city-states, Roman roads, law, engineering, and legacy.'},
    {wing:'history', type:'master', icon:'👑', title:'England: Kings and Queens Road', call:['openEnglandKingsQueens74Q','openEnglandKingsQueensRoad74Q'], note:'English monarchy, castles, charters, Parliament, and modern crown.'},
    {wing:'history', type:'master', icon:'🏰', title:'Medieval World: Castles & Knights', call:['openMedievalWorldCastles75L','openMedievalWorldRoad'], note:'Castles, villages, guilds, monasteries, law, towns, and medieval change.'},
    {wing:'history', type:'master', icon:'🇺🇸', title:'American History Road', call:['openAmericanHistoryRoad75K','openAmericanHistoryRoad'], note:'American history handled through evidence, geography, systems, and kid-safe context.'},
    {wing:'history', type:'master', icon:'🏚️', title:'Great Depression History Street', call:['openGreatDepressionTrail','openGreatDepressionCourse'], note:'Banking, family life, Dust Bowl, public works, recovery, and legacy.'},
    {wing:'history', type:'master', icon:'🤠', title:'Wild West Frontier Trail', call:['openWildWestTrail','openWildWestCourse'], note:'Frontier towns, trails, railroads, homesteads, tools, newspapers, and evidence.'},
    {wing:'history', type:'master', icon:'⚓', title:'Shipwreck Cove', call:['openShipwreckCoveMap','openShipwreckCoveDeepCourse','shipwreckGuidedZoneOpen'], note:'Navigation, wrecks, weather, rescue, archaeology, and folklore handled carefully.'},
    {wing:'history', type:'master', icon:'🧭', title:'Mapmaker’s Loft', call:['openMapmakersLoft74P','openHistoryWorldSupportAdventure74P'], note:'Geography support road under History and World.'},
    {wing:'history', type:'master', icon:'🏛️', title:'Civic Hall', call:['openCivicHall74P','openHistoryWorldSupportAdventure74P'], note:'Rules, laws, government, courts, services, and public symbols.'},
    {wing:'history', type:'master', icon:'🏪', title:'Market Square', call:['openMarketSquare74P','openHistoryWorldSupportAdventure74P'], note:'Economics support road under History and World.'},
    {wing:'history', type:'drawer', icon:'🍀', title:'Celtic Heritage Drawer', drawer:'celtic', note:'Older Celtic/heritage material is kept under History and World.'},
    {wing:'history', type:'drawer', icon:'🏺', title:'Ancient Worlds Legacy Drawer', drawer:'ancientworlds', note:'Older ancient-world packs connect here without competing with Egypt/Greece/Rome.'},
    {wing:'history', type:'drawer', icon:'🌐', title:'Geography Legacy Drawer', drawer:'geography', note:'Older geography packs connect behind the richer Mapmaker’s Loft.'},
    {wing:'history', type:'drawer', icon:'⚖️', title:'Civics Legacy Drawer', drawer:'civics', note:'Older civics packs connect behind Civic Hall.'},
    {wing:'history', type:'drawer', icon:'🪙', title:'Economics Legacy Drawer', drawer:'economics', note:'Older economics and market packs connect behind Market Square.'},

    {wing:'bible', type:'master', icon:'📖', title:'Bible History Road', call:['openBibleHistoryTrail','openBibleHistoryCourse'], note:'Catholic-friendly sacred history and New Testament road.'},
    {wing:'bible', type:'master', icon:'🕯️', title:'Saints, Angels, and Early Church Road', call:['openBibleRoadSaintsAngelsEarlyChurch75M','openBibleRoadExpansion75M','openSaintsAngelsEarlyChurchRoad75M'], note:'Saints Gallery, Angel Tower, and Early Church Road.'},
    {wing:'bible', type:'drawer', icon:'🪟', title:'Bible Artifact Room', drawer:'bibleartifacts', note:'Respectful artifact and sacred symbol access.'},

    {wing:'creative', type:'master', icon:'🎨', title:'Creative Quarter Adventure', call:['openCreativeQuarterAdventure74O','openCreativeHomesteadAdventure74O'], note:'Drawing, painting, sculpture, music, theater, stories, puppets, and gallery care.'},
    {wing:'creative', type:'drawer', icon:'🖌️', title:'Art Realm Drawer', drawer:'art', note:'Art Realm, Dragonbrush Vale, painting, craft, and drawing practice.'},
    {wing:'creative', type:'drawer', icon:'🎵', title:'Music Hall Drawer', drawer:'music', note:'Music and bard-hall practice material.'},
    {wing:'creative', type:'drawer', icon:'🎭', title:'Theater Stage Drawer', drawer:'theater', note:'Theater, stage, voice, movement, props, and performance basics.'},
    {wing:'creative', type:'drawer', icon:'🧵', title:'Craft Cottage Drawer', drawer:'craft', note:'Craft, design, pattern, making, and maker skills.'},
    {wing:'creative', type:'drawer', icon:'🐉', title:'Dragon Lore / Story Drawer', drawer:'story', note:'Story Forest, Dragon Library, and older story-making material.'},

    {wing:'homestead', type:'master', icon:'🏡', title:'Homestead Workshop Adventure', call:['openHomesteadWorkshopAdventure74O','openCreativeHomesteadAdventure74O'], note:'Kitchen safety, repair, gardening, animals, storage, budgeting, readiness, and home display.'},
    {wing:'homestead', type:'living', icon:'📌', title:'Town Notice Board / Living World Ledger', call:['openLivingWorldSurface75H','openLivingWorldLedger74L','openLivingWorld'], note:'Seasons, events, birthdays, shops, rare finds, companions, quests, collections, and home systems.'},
    {wing:'homestead', type:'living', icon:'🐾', title:'Companion Den', call:['openCompanionDen','openPetJournal','openCompanionPopup'], note:'Pets and companions.'},
    {wing:'homestead', type:'living', icon:'💎', title:'Collection Log / Treasure Registry', call:['openCollectionLog','openBackpack','openInventoryPopup','openAchievementJournal'], note:'Artifacts, treasures, collections, and storage records.'},
    {wing:'homestead', type:'living', icon:'📜', title:'Quest Board', call:['openQuestBoard','openDailyQuestBoard','openQuestJournal','openStoryQuestJournal'], note:'Daily goals, quests, campaigns, and challenge boards.'},
    {wing:'homestead', type:'drawer', icon:'🍳', title:'Cooking Guild Drawer', drawer:'cooking', note:'Cooking and kitchen safety legacy material.'},
    {wing:'homestead', type:'drawer', icon:'🔧', title:'Repair Shop Drawer', drawer:'repair', note:'Repair, tools, materials, and practical workshop practice.'},
    {wing:'homestead', type:'drawer', icon:'🌻', title:'Farm & Garden Drawer', drawer:'garden', note:'Farm Valley, Garden Grounds, compost, crops, animal care, and seasonal chores.'},
    {wing:'homestead', type:'drawer', icon:'🧾', title:'Budget Borough Drawer', drawer:'budget', note:'Budgeting, money choices, shopping, and household planning.'},
    {wing:'homestead', type:'drawer', icon:'🏪', title:'Merchant Square Drawer', drawer:'merchant', note:'Shopkeepers, market practice, and merchant/economy systems.'}
  ];

  var DRAWERS = {
    copywork:{wing:'core', label:'Copywork & Handwriting', include:/copywork|scribe|abbey/i, files:['content_packs/writing_guild_real_curriculum_pack1.json']},
    counting:{wing:'core', label:'Counting Orchard', include:/counting_orchard|count|number sense|place value/i, files:['content_packs/counting_orchard_real_curriculum_pack1.json']},
    fractions:{wing:'core', label:'Fraction Castle', include:/fraction_castle|fraction/i, files:['content_packs/fraction_castle_real_curriculum_pack1.json']},
    geometry:{wing:'core', label:'Geometry Caverns', include:/geometry_caverns|geometry|shape|angle|area|volume/i, files:['content_packs/geometry_caverns_real_curriculum_pack1.json']},
    equations:{wing:'core', label:'Equation Forge', include:/equation_forge|equation|variable|algebra|inequality/i, files:['content_packs/equation_forge_real_curriculum_pack1.json']},
    gradeladder:{wing:'core', label:'Grade Ladder', include:/grade|ladder|checkpoint|foundation/i, packNotes:['GRADE_LADDER_V1.txt','GRADE_LADDER_REWARD_GATES_V1.txt']},

    chemistry:{wing:'science', label:'Chemistry Institute', include:/chemistry|chem_|element|mixture|crystal|states of matter/i, files:['content_packs/chemistry_institute_real_curriculum_pack1.json','content_packs/chemistry_institute_deep_pack1.json','content_packs/chemistry_lessons_pack1.json']},
    astronomy:{wing:'science', label:'Astronomy Observatory', include:/astronomy|astro|space_observatory|planet|star|moon|telescope/i, files:['content_packs/astronomy_observatory_real_curriculum_pack1.json','content_packs/space_observatory_deep_pack1.json','content_packs/space_lessons_pack1.json']},
    earth:{wing:'science', label:'Earth Science', include:/earth_science|volcano|rock|erosion|mineral|earth/i, files:['content_packs/earth_science_real_curriculum_pack1.json','content_packs/volcano_lessons_pack1.json']},
    botany:{wing:'science', label:'Botany Conservatory', include:/botany|plant|seed|flower|root|garden/i, files:['content_packs/botany_conservatory_real_curriculum_pack1.json','content_packs/botany_conservatory_heavy.json']},
    electricity:{wing:'science', label:'Electricity Lab', include:/electricity|electric|circuit|magnet|conductor/i, files:['content_packs/electricity_lab_real_curriculum_pack1.json']},
    physics:{wing:'science', label:'Physics Forge', include:/physics|force|motion|energy|machine|mechanical|machines_motion/i, files:['content_packs/physics_forge_real_curriculum_pack1.json','content_packs/machines_motion_real_curriculum_pack1.json','content_packs/mechanical_workshop_real_curriculum_pack1.json','content_packs/energy_lessons_pack1.json']},
    computers:{wing:'science', label:'Robotics & Computer Science', include:/robot|computer|algorithm|coding|command/i, files:['content_packs/robotics_lab_real_curriculum_pack1.json','content_packs/computer_science_real_curriculum_pack1.json']},
    dinosaurs:{wing:'science', label:'Dinosaur & Fossil', include:/dinosaur|fossil/i, files:['content_packs/dinosaur_lessons_pack1.json']},
    insects:{wing:'science', label:'Insect Kingdom', include:/insect|pollinator|bee|butterfly/i, files:['content_packs/insect_kingdom_real_curriculum_pack1.json','content_packs/insect_lessons_pack1.json']},

    celtic:{wing:'history', label:'Celtic Heritage', include:/celtic|heritage/i, files:['content_packs/celtic_heritage_real_curriculum_pack1.json','content_packs/celtic_heritage_expansion_pack2.json','content_packs/celtic_heritage_realm_explosion_pack1.json']},
    ancientworlds:{wing:'history', label:'Ancient Worlds Legacy', include:/ancient_worlds|ancient|civilization/i, files:['content_packs/ancient_worlds_real_curriculum_pack1.json','content_packs/ancient_worlds_expansion_pack1.json']},
    geography:{wing:'history', label:'Geography Legacy', include:/map_hall|geography|landform|region|climate/i, files:['content_packs/map_hall_real_curriculum_pack1.json','content_packs/geography_world_explosion_pack1.json','content_packs/geography_world_heavy.json']},
    civics:{wing:'history', label:'Civics Legacy', include:/civics|council|law|government|citizen/i, files:['civics_hall_mega_pack.json']},
    economics:{wing:'history', label:'Economics Legacy', include:/economics|merchant|market|money|budget|goods|services/i, files:['content_packs/merchant_square_real_curriculum_pack1.json','content_packs/budget_borough_real_curriculum_pack1.json','content_packs/merchant_economy_shop_engine_pack.json']},

    bibleartifacts:{wing:'bible', label:'Bible Artifact Room', include:/bible|saint|angel|church|sacrament|gospel/i, files:[]},

    art:{wing:'creative', label:'Art Realm', include:/art|paint|drawing|studio|brush|gallery/i, files:['content_packs/arts_kingdom_real_curriculum_pack1.json','content_packs/painting_studio_real_curriculum_pack1.json','content_packs/arts_kingdom_explosion_pack1.json']},
    music:{wing:'creative', label:'Music Hall', include:/music|bard|melody|instrument|rhythm/i, files:['content_packs/music_hall_real_curriculum_pack1.json']},
    theater:{wing:'creative', label:'Theater Stage', include:/theater|stage|drama|props|performance/i, files:['content_packs/theater_stage_real_curriculum_pack1.json']},
    craft:{wing:'creative', label:'Craft Cottage', include:/craft|cottage|maker|pattern|design/i, files:['content_packs/craft_cottage_real_curriculum_pack1.json']},
    story:{wing:'creative', label:'Story / Dragon Library', include:/story_forest|story|dragon|library|plot|character/i, files:['content_packs/story_forest_real_curriculum_pack1.json','content_packs/dragon_lore_realm_pack1.json']},

    cooking:{wing:'homestead', label:'Cooking Guild', include:/cooking|kitchen|recipe|food/i, files:['content_packs/cooking_guild_real_curriculum_pack1.json']},
    repair:{wing:'homestead', label:'Repair Shop', include:/repair|builder|workshop|tool|material/i, files:['content_packs/repair_shop_real_curriculum_pack1.json','content_packs/builder_workshop_real_curriculum_pack1.json']},
    garden:{wing:'homestead', label:'Farm & Garden', include:/farm|garden|animal_care|plant|compost|soil/i, files:['content_packs/farm_valley_real_curriculum_pack1.json','content_packs/garden_grounds_real_curriculum_pack1.json','content_packs/animal_care_real_curriculum_pack1.json']},
    budget:{wing:'homestead', label:'Budget Borough', include:/budget|money|saving|spend|choice/i, files:['content_packs/budget_borough_real_curriculum_pack1.json']},
    merchant:{wing:'homestead', label:'Merchant Square', include:/merchant|shop|vendor|market/i, files:['content_packs/merchant_square_real_curriculum_pack1.json','content_packs/merchant_economy_shop_engine_pack.json']}
  };

  var WING_TITLES = {
    core:'Core Halls', science:'Science and Engineering Quarter', history:'History and World Wing', bible:'Bible Road', creative:'Creative Quarter', homestead:'Homestead Workshop / Living World'
  };
  var WING_ICONS = {core:'🏰', science:'🔬', history:'🗺️', bible:'✝️', creative:'🎨', homestead:'🏡'};

  function statusFor(c){
    if(c.type === 'drawer') return 'Connected drawer';
    if(c.type === 'living') return c.call && c.call.some(has) ? 'Live door' : 'Fallback door';
    if(c.call && c.call.some(has)) return 'Live road';
    return 'Needs fallback check';
  }
  function statusClass(s){ return /Live/.test(s) ? 'ok' : (/drawer|Fallback/i.test(s) ? 'drawer' : 'warn'); }

  function wingConnections(wing){ return CONNECTIONS.filter(function(c){return c.wing===wing;}); }
  function masterCount(){ return CONNECTIONS.filter(function(c){return c.type==='master';}).length; }
  function drawerCount(){ return CONNECTIONS.filter(function(c){return c.type==='drawer';}).length; }

  function renderAudit(){
    var rows = ['core','science','history','bible','creative','homestead'].map(function(w){
      var cs = wingConnections(w), live = cs.filter(function(c){return /Live/.test(statusFor(c));}).length;
      var drawers = cs.filter(function(c){return c.type==='drawer';}).length;
      return '<button class="lr75oWingStatus" data-lr75o-act="annex:'+esc(w)+'"><span>'+esc(WING_ICONS[w])+'</span><b>'+esc(WING_TITLES[w])+'</b><small>'+live+' live roads · '+drawers+' drawers · '+cs.length+' total doors</small><i>Open annex ›</i></button>';
    }).join('');
    var html = '<div class="lr75oShell"><div class="lr75oHero"><div class="lr75oHeroIcon">🧭</div><div><h2>Learning Center Connection Ledger</h2><p>This is a light audit pass, not a content dump. It keeps the cool Realm Library design while making older topics reachable through the right umbrella instead of scattering them around the game.</p><small>'+masterCount()+' master roads · '+drawerCount()+' legacy drawers · living-world systems preserved</small></div></div><div class="lr75oGrid">'+rows+'</div><div class="lr75oPanel"><h3>What this pass does</h3><p>Every big subject now has either a polished road, an appropriate wing annex, or a legacy practice drawer. Older quick questions are intentionally tucked into drawers so they do not become another mile-long shelf.</p><p>No shell rewrite, no loading curtain, no save reset, and no heavy startup scan.</p></div><div class="lr75oNav"><button data-lr75o-act="library">Realm Library</button><button data-lr75o-act="living">Living World Doors</button><button data-lr75o-act="home">Homestead</button></div></div>';
    actionMount('🧭 Connection Ledger', html);
  }

  function card(c){
    var st = statusFor(c);
    var act = c.type === 'drawer' ? 'drawer:'+c.drawer+':0' : (c.type === 'living' ? 'live:'+c.title : 'course:'+c.title);
    return '<button class="lr75oDoor '+statusClass(st)+'" data-lr75o-act="'+esc(act)+'"><span>'+esc(c.icon||'🚪')+'</span><b>'+esc(c.title)+'</b><small>'+esc(st)+'</small><p>'+esc(c.note||'Connected through the Learning Center.')+'</p><i>'+(c.type==='drawer'?'Open drawer':'Enter')+' ›</i></button>';
  }
  function renderAnnex(wing){
    if(!WING_TITLES[wing]) wing='core';
    var cs = wingConnections(wing);
    var html = '<div class="lr75oShell"><div class="lr75oHero"><div class="lr75oHeroIcon">'+esc(WING_ICONS[wing])+'</div><div><h2>'+esc(WING_TITLES[wing])+' Annex</h2><p>All known roads and legacy drawers for this umbrella are gathered here. The deep roads stay first; older material stays as drawers.</p><small>'+cs.length+' connected doors</small></div></div><div class="lr75oDoorGrid">'+cs.map(card).join('')+'</div><div class="lr75oNav"><button data-lr75o-act="audit">Connection Ledger</button><button data-lr75o-act="wing:'+esc(wing)+'">Parent Wing</button><button data-lr75o-act="library">Realm Library</button></div></div>';
    actionMount(WING_ICONS[wing]+' '+WING_TITLES[wing]+' Annex', html);
  }

  function findConnectionByTitle(title){
    title = String(title||'');
    for(var i=0;i<CONNECTIONS.length;i++) if(CONNECTIONS[i].title === title) return CONNECTIONS[i];
    return null;
  }
  function openConnection(title){
    var c = findConnectionByTitle(title);
    if(!c) return renderAudit();
    if(c.call && callAny(c.call)) return true;
    soft(c.title, 'This road is listed in the Learning Center, but its direct opener did not answer. It is still connected through the correct annex and/or drawer so it is not stranded.');
  }
  function openLiving(title){ return openConnection(title); }

  async function loadBank(){
    try{ if(has('lrLoadRealCurriculumBank')) return await window.lrLoadRealCurriculumBank(); }catch(e){}
    return window.__lrRealCurriculumBank || [];
  }
  function matchDrawerLesson(l, d){
    var text = ((l.source_pack||'')+' '+(l.region||'')+' '+(l.pack_region||'')+' '+(l.mastery_tag||'')+' '+(l.question||'')+' '+(l.topic||'')).toLowerCase();
    if(d.include && d.include.test(text)) return true;
    if(d.files){
      for(var i=0;i<d.files.length;i++) if(text.indexOf(String(d.files[i]).toLowerCase())>=0) return true;
    }
    return false;
  }
  async function fetchPackSummary(file){
    try{
      var res = await fetch(file);
      if(!res.ok) return null;
      var data = await res.json();
      var zones = data && data.zones ? Object.keys(data.zones).slice(0,8) : [];
      var lessons = data && Array.isArray(data.lessons) ? data.lessons.length : (data && data.lesson_count ? data.lesson_count : 0);
      return {file:file, region:(data && data.region)||file.replace(/^content_packs\//,''), zones:zones, lessons:lessons, reward:(data && (data.achievement||data.museum||data.boss_exam))||''};
    }catch(e){ return null; }
  }
  async function renderDrawer(key, page){
    page=Math.max(0,Number(page)||0);
    var d = DRAWERS[key] || DRAWERS.copywork;
    installStyles();
    var bank = await loadBank();
    var list = bank.filter(function(l){ return matchDrawerLesson(l,d); });
    var per=10, pages=Math.max(1,Math.ceil(list.length/per));
    if(page>=pages) page=pages-1;
    var sample=list.slice(page*per,page*per+per);
    var packSummaries=[];
    if(d.files){
      for(var i=0;i<d.files.length;i++){
        var s=await fetchPackSummary(d.files[i]);
        if(s) packSummaries.push(s);
      }
    }
    var cards = sample.map(function(l){
      var idx=(window.__lrRealCurriculumBank||bank).indexOf(l); if(idx<0) idx=bank.indexOf(l);
      return '<button class="lr75oMini" data-lr75o-act="lesson:'+idx+'"><b>'+esc(l.region||l.pack_region||'Practice room')+'</b><small>'+esc(l.mastery_tag||l.topic||'quick challenge')+'</small><p>'+esc(l.question||'Open the challenge room.')+'</p></button>';
    }).join('');
    if(!cards) cards = '<div class="lr75oPanel"><h3>No quick-question rooms loaded here yet</h3><p>This drawer is still connected as the proper home for the topic. It may contain older zone metadata, rewards, or a course shell rather than one-question practice rooms.</p></div>';
    var packs = packSummaries.map(function(p){
      return '<div class="lr75oPack"><b>'+esc(p.region)+'</b><small>'+esc(p.file.replace('content_packs/',''))+'</small><p>'+esc((p.lessons? p.lessons+' entries. ' : '')+(p.reward||''))+'</p>'+(p.zones.length?'<p><b>Zones:</b> '+p.zones.map(esc).join(' · ')+'</p>':'')+'</div>';
    }).join('');
    var html = '<div class="lr75oShell"><div class="lr75oHero"><div class="lr75oHeroIcon">📚</div><div><h2>'+esc(d.label)+' Drawer</h2><p>Legacy and quick-practice material for this topic lives here so it remains reachable without cluttering the main roads.</p><small>'+list.length+' quick rooms found · drawer page '+(page+1)+' / '+pages+'</small></div></div><div class="lr75oMiniGrid">'+cards+'</div>'+(packs?'<div class="lr75oPackList"><h3>Pack notes and zones</h3>'+packs+'</div>':'')+'<div class="lr75oNav">'+(page>0?'<button data-lr75o-act="drawer:'+esc(key)+':'+(page-1)+'">‹ Previous</button>':'')+(page<pages-1?'<button data-lr75o-act="drawer:'+esc(key)+':'+(page+1)+'">Next ›</button>':'')+'<button data-lr75o-act="annex:'+esc(d.wing||'core')+'">Back to annex</button><button data-lr75o-act="library">Realm Library</button></div></div>';
    actionMount('📚 '+d.label+' Drawer', html);
  }
  function openLesson(idx){
    idx=Number(idx)||0;
    if(has('lrOpenRealLessonByIndex')){ try{ window.lrOpenRealLessonByIndex(idx); return true; }catch(e){} }
    soft('Practice Room', 'That quick practice room could not open directly, but its drawer remains connected.');
  }

  function injectIntoRealmLibrary(){
    installStyles();
    var action = byId('actionText');
    if(!action) return;
    if(action.querySelector('#lr75oConnectionLedgerDoor')) return;
    var hero = action.querySelector('.lr75aLibrary .lr75aHero, .lr75aWingRoom .lr75aHero');
    if(!hero) return;
    var door=document.createElement('div');
    door.id='lr75oConnectionLedgerDoor';
    door.className='lr75oLedgerStrip';
    door.innerHTML='<button type="button" data-lr75o-act="audit"><span>🧭</span><b>Connection Ledger</b><small>Check every road, drawer, and old topic home</small></button>';
    hero.parentNode.insertBefore(door, hero.nextSibling);
    var h2=(hero.textContent||'').toLowerCase();
    var wing = h2.indexOf('core halls')>=0?'core':h2.indexOf('science')>=0?'science':h2.indexOf('history')>=0?'history':h2.indexOf('bible')>=0?'bible':h2.indexOf('creative')>=0?'creative':h2.indexOf('homestead')>=0?'homestead':null;
    if(wing){
      var grid = action.querySelector('.lr75aDoorGrid');
      if(grid && !grid.querySelector('#lr75oAnnexDoor_'+wing)){
        var b=document.createElement('button'); b.type='button'; b.id='lr75oAnnexDoor_'+wing; b.className='lr75aDoorCard lr75oAnnexCard'; b.setAttribute('data-lr75o-act','annex:'+wing);
        b.innerHTML='<span class="lr75aDoorIcon">'+WING_ICONS[wing]+'</span><span><b>'+esc(WING_TITLES[wing])+' full annex</b><small>all connected roads and legacy drawers</small><p>Open this if something feels missing. It gathers old packs, support topics, practice drawers, and new master roads under this umbrella.</p></span><i>Open annex ›</i>';
        grid.appendChild(b);
      }
    }
  }

  var injectTimer=null;
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer=setTimeout(injectIntoRealmLibrary,80);
  }
  function bind(){
    if(window.__LR75O_BOUND__) return;
    window.__LR75O_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var el = ev.target && ev.target.closest ? ev.target.closest('[data-lr75o-act]') : null;
      if(!el) { setTimeout(scheduleInject,50); return; }
      ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
      var act = el.getAttribute('data-lr75o-act') || 'audit';
      if(act === 'audit') return renderAudit();
      if(act === 'library') return openLibrary();
      if(act === 'living') return callAny(['openLivingWorldSurface75H','openLivingWorldLedger74L','openLivingWorld']) || soft('Living World Doors','Living world fallback opened.');
      if(act === 'home') return callAny(['travelHome','openHomeView','openCozyHome']) || soft('Homestead','Homestead fallback opened.');
      if(act.indexOf('wing:')===0) return openWing(act.slice(5));
      if(act.indexOf('annex:')===0) return renderAnnex(act.slice(6));
      if(act.indexOf('drawer:')===0){ var p=act.split(':'); return renderDrawer(p[1], p[2]); }
      if(act.indexOf('course:')===0) return openConnection(act.slice(7));
      if(act.indexOf('live:')===0) return openLiving(act.slice(5));
      if(act.indexOf('lesson:')===0) return openLesson(act.split(':')[1]);
      return renderAudit();
    }, true);
  }
  function wrapOpeners(){
    if(window.__LR75O_OPENERS_WRAPPED__) return;
    window.__LR75O_OPENERS_WRAPPED__ = true;
    ['openRealmLibrary75A','openRealmLibrary75B','openRealCurriculumPicker'].forEach(function(name){
      var old=window[name];
      if(typeof old === 'function'){
        window[name]=function(){ var r=old.apply(this,arguments); scheduleInject(); setTimeout(scheduleInject,250); return r; };
        try{ if(name==='openRealmLibrary75A') openRealmLibrary75A=window[name]; if(name==='openRealCurriculumPicker') openRealCurriculumPicker=window[name]; }catch(e){}
      }
    });
  }
  function installStyles(){
    if(byId('lr75oStyles')) return;
    var st=document.createElement('style'); st.id='lr75oStyles';
    st.textContent = '\n.lr75oShell{display:grid;gap:14px;color:#f7ecd0;max-width:1120px;margin:0 auto;}\n.lr75oHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;border:1px solid rgba(244,209,134,.35);border-radius:18px;background:linear-gradient(135deg,rgba(44,31,18,.95),rgba(18,45,50,.9));box-shadow:0 16px 36px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.08);}\n.lr75oHeroIcon{width:58px;height:58px;border-radius:17px;display:grid;place-items:center;font-size:2rem;background:rgba(255,240,190,.13);border:1px solid rgba(255,231,165,.36);}\n.lr75oHero h2{margin:0 0 5px;color:#fff5cf}.lr75oHero p{margin:0;line-height:1.5;color:#e9dcc0}.lr75oHero small{display:block;margin-top:8px;color:#aee8d0;font-weight:900;text-transform:uppercase;letter-spacing:.04em}\n.lr75oGrid,.lr75oDoorGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}.lr75oMiniGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px}\n.lr75oWingStatus,.lr75oDoor,.lr75oMini{cursor:pointer;text-align:left;color:#f7ecd0;border:1px solid rgba(244,209,134,.30);border-radius:16px;background:linear-gradient(145deg,rgba(14,31,31,.94),rgba(48,30,18,.92));box-shadow:0 10px 24px rgba(0,0,0,.26),inset 0 1px 0 rgba(255,255,255,.07);padding:13px;display:grid;gap:5px;position:relative;}\n.lr75oWingStatus{grid-template-columns:auto 1fr auto;align-items:center}.lr75oWingStatus span{font-size:1.8rem}.lr75oWingStatus b,.lr75oDoor b,.lr75oMini b{display:block;color:#fff2bd}.lr75oWingStatus small,.lr75oDoor small,.lr75oMini small{display:block;color:#aee8d0;font-size:.73rem;font-weight:900;text-transform:uppercase;letter-spacing:.05em}.lr75oWingStatus i,.lr75oDoor i{font-style:normal;color:#ffe49c;font-weight:900;align-self:center;white-space:nowrap}.lr75oDoor{grid-template-columns:auto 1fr auto;min-height:126px}.lr75oDoor span{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:rgba(255,236,176,.12);border:1px solid rgba(255,232,166,.28);font-size:1.45rem}.lr75oDoor p,.lr75oMini p{margin:0;color:#dcccae;line-height:1.4}.lr75oDoor.ok{border-color:rgba(126,229,180,.38)}.lr75oDoor.drawer{border-color:rgba(255,232,166,.34)}.lr75oDoor.warn{border-color:rgba(255,142,116,.45)}\n.lr75oNav,.lr75oLedgerStrip{display:flex;flex-wrap:wrap;gap:10px;padding:12px;border:1px solid rgba(244,209,134,.24);border-radius:14px;background:rgba(0,0,0,.22)}.lr75oNav button,.lr75oLedgerStrip button{border:1px solid rgba(255,232,166,.34);border-radius:999px;background:rgba(255,231,165,.12);color:#fff3cf;font-weight:900;padding:9px 13px;cursor:pointer}.lr75oLedgerStrip button{display:flex;align-items:center;gap:8px;text-align:left}.lr75oLedgerStrip small{display:block;color:#aee8d0;font-size:.72rem}.lr75oPanel,.lr75oPackList{border:1px solid rgba(244,209,134,.24);border-radius:16px;background:rgba(0,0,0,.18);padding:13px}.lr75oPanel h3,.lr75oPackList h3{margin-top:0;color:#fff2bd}.lr75oPack{border-top:1px solid rgba(244,209,134,.18);padding:10px 0}.lr75oPack:first-of-type{border-top:0}.lr75oPack b{color:#fff2bd}.lr75oPack small{display:block;color:#aee8d0}.lr75oAnnexCard{outline:1px solid rgba(126,229,180,.28)}@media(max-width:900px){.lr75oHero,.lr75oDoor,.lr75oWingStatus{grid-template-columns:1fr}.lr75oDoor i,.lr75oWingStatus i{justify-self:start}}';
    document.head.appendChild(st);
  }
  function boot(){ installStyles(); bind(); wrapOpeners(); scheduleInject(); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,120); setTimeout(scheduleInject,700); });

  window.openLearningCenterConnectionAudit75O = renderAudit;
  window.openLearningCenterAnnex75O = renderAnnex;
})();
