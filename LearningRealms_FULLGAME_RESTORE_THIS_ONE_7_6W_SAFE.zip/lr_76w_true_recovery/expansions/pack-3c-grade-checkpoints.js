// Curriculum Pack 3C: Grade Checkpoints / Mixed Mastery
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Reading",[
 {teach:"Checkpoint: Read the word carefully and notice the vowel sound.",practice:"cake has long a because of final e.",q:"Which word has a long a sound?",c:["cake","cat","cap"],a:"cake"},
 {teach:"Checkpoint: Digraphs use two letters for one sound.",practice:"sh, ch, th",q:"Which word begins with a digraph?",c:["ship","frog","tree"],a:"ship"},
 {teach:"Checkpoint: Blends keep both sounds.",practice:"br in brush keeps b and r.",q:"Which word begins with a blend?",c:["brush","chair","thumb"],a:"brush"},
 {teach:"Checkpoint: The setting is where the story happens.",practice:"The owl sat in a tall tree.",q:"What is the setting?",c:["tall tree","owl","sat"],a:"tall tree"},
 {teach:"Checkpoint: The problem is what goes wrong.",practice:"The gate would not open.",q:"What is the problem?",c:["gate would not open","gate is tall","the story ends"],a:"gate would not open"},
 {teach:"Checkpoint: The solution fixes the story problem.",practice:"They found the key and opened the gate.",q:"What is the solution?",c:["found the key","gate would not open","owl watched"],a:"found the key"},
 {teach:"Checkpoint: Main idea means what something is mostly about.",practice:"A passage tells how frogs grow.",q:"What is the main idea?",c:["how frogs grow","one frog is green","the page number"],a:"how frogs grow"},
 {teach:"Checkpoint: A detail tells more about the main idea.",practice:"Frogs start as tadpoles.",q:"Which is a detail?",c:["frogs start as tadpoles","frogs","main idea"],a:"frogs start as tadpoles"}
]);

LR_addLessons("Luna","English",[
 {teach:"Checkpoint: A complete sentence has a complete thought.",practice:"The rabbit hopped home.",q:"Which is a complete sentence?",c:["The rabbit hopped home.","rabbit hopped","home"],a:"The rabbit hopped home."},
 {teach:"Checkpoint: Sentences begin with capital letters.",practice:"The fox ran.",q:"Which sentence starts correctly?",c:["The fox ran.","the fox ran.","the Fox ran."],a:"The fox ran."},
 {teach:"Checkpoint: Questions end with a question mark.",practice:"Where is the owl?",q:"Which mark should end a question?",c:["?","!","."],a:"?"},
 {teach:"Checkpoint: A noun names a person, place, thing, or animal.",practice:"castle, rabbit, town",q:"Which word is a noun?",c:["castle","quickly","under"],a:"castle"},
 {teach:"Checkpoint: A verb shows action.",practice:"jump, read, build",q:"Which word is a verb?",c:["build","green","table"],a:"build"},
 {teach:"Checkpoint: Adjectives describe nouns.",practice:"silver owl",q:"Which word describes?",c:["silver","owl","the"],a:"silver"}
]);

LR_addLessons("Luna","Math",[
 {teach:"Checkpoint: Use addition facts within 20.",practice:"9 + 8 = 17.",q:"9 + 8 = ?",c:["17","16","18"],a:"17"},
 {teach:"Checkpoint: Use subtraction facts within 20.",practice:"16 - 7 = 9.",q:"16 - 7 = ?",c:["9","8","10"],a:"9"},
 {teach:"Checkpoint: Teen numbers have one ten.",practice:"18 has 1 ten and 8 ones.",q:"18 has how many ones?",c:["8","1","18"],a:"8"},
 {teach:"Checkpoint: Compare two numbers.",practice:"42 is greater than 24.",q:"Which number is greater?",c:["42","24","same"],a:"42"},
 {teach:"Checkpoint: Count coins by value.",practice:"A dime and two nickels are 20 cents.",q:"10 + 5 + 5 cents = ?",c:["20 cents","15 cents","25 cents"],a:"20 cents"},
 {teach:"Checkpoint: Time can be read to the hour and half hour.",practice:"Half past 3 means 3:30.",q:"Half past 3 is...",c:["3:30","3:00","4:30"],a:"3:30"}
]);

LR_addLessons("Ava","Math",[
 {teach:"Checkpoint: Equivalent ratios have equal value.",practice:"3:4 equals 6:8.",q:"Which ratio equals 3:4?",c:["6:8","4:6","7:8"],a:"6:8"},
 {teach:"Checkpoint: Unit rate compares to one.",practice:"240 miles in 4 hours = 60 miles per hour.",q:"240 miles in 4 hours is...",c:["60 miles per hour","244 miles per hour","40 miles per hour"],a:"60 miles per hour"},
 {teach:"Checkpoint: Solve two-step equations with inverse operations.",practice:"4x + 5 = 33 gives x = 7.",q:"4x + 5 = 33. x = ?",c:["7","8","28"],a:"7"},
 {teach:"Checkpoint: Combine like terms before solving.",practice:"2x + 3x = 5x.",q:"2x + 3x = ?",c:["5x","6x","x"],a:"5x"},
 {teach:"Checkpoint: Integer addition depends on signs.",practice:"-9 + 4 = -5.",q:"-9 + 4 = ?",c:["-5","13","5"],a:"-5"},
 {teach:"Checkpoint: Integer multiplication with different signs gives negative.",practice:"-7 × 3 = -21.",q:"-7 × 3 = ?",c:["-21","21","10"],a:"-21"},
 {teach:"Checkpoint: Percent means out of 100.",practice:"35% means 35 out of 100.",q:"35% means 35 out of...",c:["100","35","10"],a:"100"},
 {teach:"Checkpoint: Circle radius is half the diameter.",practice:"Diameter 18 gives radius 9.",q:"If diameter is 18, radius is...",c:["9","18","36"],a:"9"},
 {teach:"Checkpoint: Mean is the average.",practice:"4, 6, 8 average to 6.",q:"Mean of 4, 6, 8?",c:["6","4","8"],a:"6"},
 {teach:"Checkpoint: Probability compares favorable outcomes to total outcomes.",practice:"One heads side out of two coin sides.",q:"Probability of heads on a fair coin is...",c:["1 out of 2","2 out of 1","0 out of 2"],a:"1 out of 2"}
]);

LR_addLessons("Ava","English",[
 {teach:"Checkpoint: A claim is a clear answer or position.",practice:"The character is brave.",q:"Which is a claim?",c:["The character is brave.","Page 4","Because"],a:"The character is brave."},
 {teach:"Checkpoint: Evidence proves the claim.",practice:"The character entered the cave to help others.",q:"What proves a claim?",c:["evidence","font","page color"],a:"evidence"},
 {teach:"Checkpoint: Reasoning explains why evidence matters.",practice:"This shows bravery because helping was dangerous.",q:"Reasoning explains...",c:["why evidence matters","only the title","where the book was printed"],a:"why evidence matters"},
 {teach:"Checkpoint: Theme is a story message.",practice:"Keep trying even when something is hard.",q:"Theme means...",c:["message","setting","punctuation"],a:"message"},
 {teach:"Checkpoint: Inference uses clues and reasoning.",practice:"A character hides under blankets during thunder.",q:"What can you infer?",c:["The character is scared.","The character is cooking.","The character is swimming."],a:"The character is scared."},
 {teach:"Checkpoint: Context clues help with word meaning.",practice:"The ancient gate was very old.",q:"Ancient means...",c:["very old","very loud","very tiny"],a:"very old"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Checkpoint: Producers make food, usually using sunlight.",practice:"Plants are producers.",q:"Which is a producer?",c:["grass","fox","owl"],a:"grass"},
 {teach:"Checkpoint: Consumers get energy by eating.",practice:"A rabbit eats grass.",q:"A consumer gets energy by...",c:["eating","making laws","writing claims"],a:"eating"},
 {teach:"Checkpoint: Decomposers break down dead material.",practice:"Fungi can break down old logs.",q:"A decomposer breaks down...",c:["dead material","equations","sentences"],a:"dead material"},
 {teach:"Checkpoint: Weathering breaks rock, erosion moves it.",practice:"Water carries sediment away.",q:"Erosion means sediment is...",c:["moved","spelled","voted on"],a:"moved"},
 {teach:"Checkpoint: A controlled experiment changes one main variable.",practice:"Only sunlight changes.",q:"A controlled experiment changes...",c:["one main variable","all variables","no variables"],a:"one main variable"}
]);

LR_addLessons("Ava","History",[
 {teach:"Checkpoint: A primary source comes from the time studied.",practice:"An old diary from the event.",q:"Which is a primary source?",c:["old diary","modern textbook","new movie"],a:"old diary"},
 {teach:"Checkpoint: Cause explains why, effect explains what happened because of it.",practice:"Heavy rain caused flooding.",q:"Heavy rain is the...",c:["cause","effect","opinion"],a:"cause"},
 {teach:"Checkpoint: Limited government restricts power by law.",practice:"The Constitution limits government.",q:"Limited government restricts...",c:["power","rain","fractions"],a:"power"},
 {teach:"Checkpoint: Supply is how much is available.",practice:"More apples means more supply.",q:"Supply means how much is...",c:["available","wanted","hidden"],a:"available"},
 {teach:"Checkpoint: Demand is how much people want something.",practice:"Many people want apples.",q:"Demand means how much people...",c:["want","divide","evaporate"],a:"want"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Checkpoint: Solve equations with variables on both sides.",practice:"6x - 4 = 2x + 20 gives 4x = 24.",q:"6x - 4 = 2x + 20. x = ?",c:["6","24","4"],a:"6"},
 {teach:"Checkpoint: Distribute before solving.",practice:"3(x + 5) = 30 gives 3x + 15 = 30.",q:"3(x + 5) = 30. x = ?",c:["5","10","15"],a:"5"},
 {teach:"Checkpoint: Slope is change in y divided by change in x.",practice:"From (1,4) to (3,10), slope is 6/2.",q:"Slope from (1,4) to (3,10)?",c:["3","6","2"],a:"3"},
 {teach:"Checkpoint: y-intercept happens when x = 0.",practice:"In y = -2x + 5, intercept is 5.",q:"In y = -2x + 5, y-intercept is...",c:["5","-2","3"],a:"5"},
 {teach:"Checkpoint: A system solution satisfies both equations.",practice:"It is where graphs intersect.",q:"A system solution is where graphs...",c:["intersect","end","become parallel"],a:"intersect"},
 {teach:"Checkpoint: Scientific notation uses a number from 1 to less than 10 times a power of 10.",practice:"72,000 = 7.2 × 10^4.",q:"72,000 starts as...",c:["7.2 × 10","72 × 10","0.72 × 10"],a:"7.2 × 10"},
 {teach:"Checkpoint: Pythagorean theorem finds missing side lengths in right triangles.",practice:"5-12-13 is a right triangle.",q:"In a 5,12,13 right triangle, hypotenuse is...",c:["13","12","5"],a:"13"},
 {teach:"Checkpoint: A line of best fit models a trend.",practice:"It approximates scatter plot data.",q:"Line of best fit shows...",c:["trend","only one dot","a citation"],a:"trend"}
]);

LR_addLessons("Michael","English",[
 {teach:"Checkpoint: A thesis states the main argument.",practice:"The essay proves this claim.",q:"A thesis states...",c:["main argument","font","weather"],a:"main argument"},
 {teach:"Checkpoint: Evidence must be relevant and credible.",practice:"Use reliable sources that support the claim.",q:"Relevant evidence must support the...",c:["claim","page color","title only"],a:"claim"},
 {teach:"Checkpoint: Reasoning explains how evidence proves a claim.",practice:"This matters because...",q:"Reasoning connects evidence to...",c:["claim","setting","date only"],a:"claim"},
 {teach:"Checkpoint: A counterclaim gives the opposing view.",practice:"Some may argue differently.",q:"A counterclaim gives an opposing...",c:["view","source date","paragraph length"],a:"view"},
 {teach:"Checkpoint: Rebuttal answers the counterclaim.",practice:"It explains why the claim still stands.",q:"A rebuttal answers the...",c:["counterclaim","citation","title"],a:"counterclaim"},
 {teach:"Checkpoint: Source reliability depends on author, purpose, evidence, and date.",practice:"Check who made it and why.",q:"Which helps judge reliability?",c:["author and purpose","font size only","page number only"],a:"author and purpose"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Checkpoint: Atoms contain protons, neutrons, and electrons.",practice:"Electrons are negative.",q:"Which particle is negative?",c:["electron","proton","neutron"],a:"electron"},
 {teach:"Checkpoint: Atomic number equals protons.",practice:"Carbon has 6 protons.",q:"Atomic number tells number of...",c:["protons","neutrons only","molecules"],a:"protons"},
 {teach:"Checkpoint: Chemical changes create new substances.",practice:"Rusting forms a new substance.",q:"Rusting is a...",c:["chemical change","physical change","graph"],a:"chemical change"},
 {teach:"Checkpoint: Conservation of mass means mass is not lost in a closed system.",practice:"Matter is conserved.",q:"Conservation of mass means mass is not...",c:["lost","measured","written"],a:"lost"},
 {teach:"Checkpoint: Newton's second law is F = ma.",practice:"Force equals mass times acceleration.",q:"F = ma connects force, mass, and...",c:["acceleration","density","frequency"],a:"acceleration"},
 {teach:"Checkpoint: Waves transfer energy.",practice:"Sound and light involve waves.",q:"Waves transfer...",c:["energy","government power","claims"],a:"energy"}
]);

LR_addLessons("Michael","History",[
 {teach:"Checkpoint: Federalism divides power between national and state governments.",practice:"Both levels have powers.",q:"Federalism divides...",c:["power","water","energy"],a:"power"},
 {teach:"Checkpoint: Separation of powers divides authority among branches.",practice:"Legislative, executive, judicial.",q:"Separation of powers divides authority among...",c:["branches","markets","cells"],a:"branches"},
 {teach:"Checkpoint: Checks and balances limit government power.",practice:"Branches check each other.",q:"Checks and balances limit...",c:["power","density","theme"],a:"power"},
 {teach:"Checkpoint: Rule of law means everyone is subject to the law.",practice:"Leaders must follow laws too.",q:"Rule of law applies to...",c:["everyone","only rulers","only children"],a:"everyone"},
 {teach:"Checkpoint: Scarcity forces choices because resources are limited.",practice:"People cannot have unlimited everything.",q:"Scarcity means resources are...",c:["limited","unlimited","invisible"],a:"limited"},
 {teach:"Checkpoint: Bias can affect how a source presents information.",practice:"A source may favor one side.",q:"Bias affects source...",c:["presentation","volume","speed"],a:"presentation"}
]);
