/* LearningRealms Global Exit Paths 7.5G
   Conservative navigation safety patch built on 7.5F.
   Goal: every major wing, road, chamber, shelf, popup, and course-style screen gets a clear exit path.
   No lesson rewrite, no shell rewrite, no render loop, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR75G_GLOBAL_EXITS__) return;
  window.__LR75G_GLOBAL_EXITS__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ try{ return (root||document).querySelector(sel); }catch(e){ return null; } }
  function qa(sel, root){ try{ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }catch(e){ return []; } }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    if(!has(fn)) return false;
    try{ window[fn].apply(window, Array.prototype.slice.call(arguments,1)); return true; }
    catch(e){ console.warn('LR75G route failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var x=list[i];
      if(Array.isArray(x)){ if(call.apply(null,x)) return true; }
      else if(call(x)) return true;
    }
    return false;
  }
  function norm(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,''); }

  var WING_HINTS = [
    {key:'core', label:'Core Halls', icon:'🏰', re:/core halls|reading comprehension|lantern library|writing composition|author|story forge|math adventure|number vault|logic tower|critical thinking|grammar|vocabulary|language forge|word forge/i},
    {key:'history', label:'History and World Wing', icon:'🗺️', re:/history and world|ancient egypt|egypt|royal gallery|england|kings and queens|great depression|wild west|shipwreck|mapmaker|civic hall|market square|geography|civics|economics/i},
    {key:'science', label:'Science and Engineering Quarter', icon:'🔬', re:/science and engineering|inventions|engineering disasters|aerospace|rocket|weather|storm|animal kingdom|creature|nature|health|field guide|sky dock|mission wing/i},
    {key:'bible', label:'Bible Road', icon:'✝️', re:/bible road|bible history|gospel|sacrament|saints|angels|mary|apostles|church year/i},
    {key:'creative', label:'Creative Quarter', icon:'🎨', re:/creative quarter|art studio|drawing|painting|music|theater|story maker|craft|gallery/i},
    {key:'homestead', label:'Homestead Workshop', icon:'🏡', re:/homestead|life skills|town notice|living world|companion|collection|quest board|home rooms|season|festival|merchant|rare item|pet/i}
  ];

  function detectWing(root){
    var text = '';
    try{ text = (root && root.textContent) ? root.textContent.slice(0,6000) : ''; }catch(e){}
    var cls = '';
    try{ cls = (root && root.className) ? String(root.className) : ''; }catch(e){}
    text = text + ' ' + cls;
    for(var i=0;i<WING_HINTS.length;i++) if(WING_HINTS[i].re.test(text)) return WING_HINTS[i];
    return null;
  }

  function closeKnownOverlays(){
    try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){}
    try{ var root=byId('lrPopupRoot'); if(root) root.classList.add('hidden'); }catch(e){}
    qa('[id^="lr74"][id$="Overlay"], [id^="lr75"][id$="Overlay"], .lr74tOverlay, .lr74vOverlay').forEach(function(o){
      try{
        if(o.id === 'lr75gSafeExitOverlay') return;
        if(o.classList && o.classList.contains('show')) o.classList.remove('show');
        if(o.style) o.style.display = 'none';
        if(o.parentNode && /lr74wOverlay|lr74tOverlay|lr74vOverlay|lr75cOverlay|lr75dOverlay|lr75eOverlay|lr75fOverlay/.test(o.id||o.className||'')){
          // Some course overlays are created fresh every time. Hiding is safer for reusable ones; removing is safer for one-off modals.
          if(/lr74wOverlay|lr74tOverlay|lr74vOverlay/.test(o.id||o.className||'')) o.parentNode.removeChild(o);
        }
      }catch(e){}
    });
  }

  function openLibrary(subject){
    closeKnownOverlays();
    if(has('openRealmLibrary75B')) return window.openRealmLibrary75B(subject || 'all');
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(subject || 'all');
    if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker(subject || 'all');
    if(has('openRealmAtlas')) return window.openRealmAtlas();
    return first([['lr74xRoute','learn'],['lr74kRoute','atlas'],['lr73pDo','atlas'],['renderRoom']]);
  }

  function openWing(key){
    closeKnownOverlays();
    if(!key) return openLibrary('all');
    if(has('openRealmLibrary75B')) return window.openRealmLibrary75B(key);
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(key);
    if(key === 'home' || key === 'homestead') return goHome();
    return first([['lr74xRoute',key],['lr74kRoute',key],['lr73pDo',key],['lr73mDo',key]]) || openLibrary('all');
  }

  function goHome(){
    closeKnownOverlays();
    return first([['lr74xRoute','home'],['lr74kRoute','home'],['lr73pDo','home'],['lr73mDo','home'],['renderRoom']]);
  }

  function goScene(){
    closeKnownOverlays();
    return first([['lr74xRoute','scene'],['lr73mDo','scene'],['renderRoom']]);
  }

  function railHtml(wing, inPopup){
    var wingBtn = wing ? '<button type="button" data-lr75g-exit="wing">'+wing.icon+' '+wing.label+'</button>' : '<button type="button" data-lr75g-exit="library">🏛️ Realm Library</button>';
    return '<div class="lr75gExitRail" data-lr75g-exitrail="1">' +
      '<span class="lr75gExitLabel">🧭 Exit path</span>' +
      '<button type="button" data-lr75g-exit="library">🏛️ Realm Library</button>' +
      wingBtn +
      '<button type="button" data-lr75g-exit="home">🏡 Homestead</button>' +
      '<button type="button" data-lr75g-exit="scene">↩ Scene</button>' +
      (inPopup ? '<button type="button" data-lr75g-exit="close">✕ Close window</button>' : '') +
    '</div>';
  }

  function shouldRail(root){
    if(!root || !root.children || root.children.length === 0) return false;
    if(root.querySelector && root.querySelector('[data-lr75g-exitrail]')) return false;
    var txt=''; try{ txt=(root.textContent||'').trim(); }catch(e){}
    if(txt.length < 20) return false;
    var html=''; try{ html=root.innerHTML||''; }catch(e){}
    return /lr75aLibrary|lr75aWingRoom|lr74kRealm|lr74l|lr75c|lr75d|lr75e|lr75f|lr74w|lr74u|lr74t|lr74v|lr74s|lr74r|lr74q|egypt|shipwreck|wild west|great depression|bible|course|chamber|road map|artifact shelf|review shelf|realm library|core halls|history and world|science and engineering/i.test(html + ' ' + txt);
  }

  function addRail(root, where){
    if(!root || !shouldRail(root)) return;
    var wing = detectWing(root);
    var inPopup = !!(root.closest && root.closest('#lrPopupRoot, [id$="Overlay"], .lr74tOverlay, .lr74vOverlay, .lrPopupWindow'));
    var wrap=document.createElement('div');
    wrap.innerHTML=railHtml(wing, inPopup);
    var rail=wrap.firstElementChild;
    rail.setAttribute('data-lr75g-wing', wing ? wing.key : 'all');
    rail.setAttribute('data-lr75g-where', where || 'screen');
    try{
      var firstHero = q('[class*="Hero"], .lr75aHero, h1, h2', root);
      if(firstHero && firstHero.parentNode === root && firstHero.nextSibling) root.insertBefore(rail, firstHero.nextSibling);
      else root.insertBefore(rail, root.firstChild);
    }catch(e){ try{ root.appendChild(rail); }catch(_){} }
  }

  function addBottomRail(root, where){
    if(!root || !shouldRail(root)) return;
    if(root.querySelector && root.querySelector('[data-lr75g-bottomrail]')) return;
    var wing = detectWing(root);
    var inPopup = !!(root.closest && root.closest('#lrPopupRoot, [id$="Overlay"], .lr74tOverlay, .lr74vOverlay, .lrPopupWindow'));
    var wrap=document.createElement('div');
    wrap.innerHTML=railHtml(wing, inPopup);
    var rail=wrap.firstElementChild;
    rail.setAttribute('data-lr75g-bottomrail','1');
    rail.setAttribute('data-lr75g-wing', wing ? wing.key : 'all');
    rail.setAttribute('data-lr75g-where', where || 'screen');
    try{ root.appendChild(rail); }catch(e){}
  }

  function scan(){
    installStyles();
    var targets = [
      byId('actionText'),
      byId('lrPopupBody'),
      byId('lr75cBody'),
      byId('lr75dContent'),
      byId('lr75eContent'),
      byId('lr75fContent')
    ].filter(Boolean);
    qa('.lr74wBody, .lr74tBody, .lr74uBody, .lr74vBody, .lr74rBody, .lr74sBody, .lr74qBody, .lr74pBody, .lr74oBody, .lr74nBody').forEach(function(x){ targets.push(x); });
    targets.forEach(function(t){ addRail(t,'top'); addBottomRail(t,'bottom'); });
  }

  function handleExit(el){
    var act = el.getAttribute('data-lr75g-exit') || 'library';
    var rail = el.closest('[data-lr75g-exitrail]');
    var wingKey = rail ? rail.getAttribute('data-lr75g-wing') : null;
    if(act === 'library') return openLibrary('all');
    if(act === 'wing') return openWing(wingKey && wingKey !== 'all' ? wingKey : 'all');
    if(act === 'home') return goHome();
    if(act === 'scene') return goScene();
    if(act === 'close') return closeKnownOverlays();
    return openLibrary('all');
  }

  function bind(){
    if(window.__LR75G_BOUND__) return;
    window.__LR75G_BOUND__=true;
    window.addEventListener('click', function(ev){
      var el = ev.target && ev.target.closest ? ev.target.closest('[data-lr75g-exit]') : null;
      if(!el) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleExit(el);
    }, true);
  }

  function wrapOpeners(){
    if(window.__LR75G_OPENERS_WRAPPED__) return;
    window.__LR75G_OPENERS_WRAPPED__ = true;
    var names = ['openRealmLibrary75A','openRealmLibrary75B','openRealCurriculumPicker','lrOpenPopup','lrOpenActionPopup'];
    names.forEach(function(name){
      if(typeof window[name] !== 'function') return;
      var old = window[name];
      if(old.__lr75gWrapped) return;
      var wrapped = function(){
        var out = old.apply(this, arguments);
        scheduleScan();
        return out;
      };
      wrapped.__lr75gWrapped = true;
      window[name] = wrapped;
      try{ eval(name + ' = window["' + name + '"];'); }catch(e){}
    });
  }

  var scanTimer = null;
  function scheduleScan(){
    if(scanTimer) clearTimeout(scanTimer);
    scanTimer = setTimeout(function(){ scanTimer=null; scan(); }, 60);
  }

  function installStyles(){
    if(byId('lr75gExitStyles')) return;
    var st=document.createElement('style'); st.id='lr75gExitStyles';
    st.textContent = `
      .lr75gExitRail{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:10px 0 14px;padding:10px 12px;border:1px solid rgba(255,232,166,.30);border-radius:15px;background:linear-gradient(135deg,rgba(20,32,38,.82),rgba(65,43,22,.74));box-shadow:0 10px 24px rgba(0,0,0,.20),inset 0 1px 0 rgba(255,255,255,.06);color:#fff2cf;}
      .lr75gExitLabel{font-weight:950;color:#ffe6a6;letter-spacing:.03em;margin-right:2px;}
      .lr75gExitRail button{border:1px solid rgba(255,232,166,.38);border-radius:999px;background:rgba(255,239,194,.12);color:#fff5d6;padding:8px 11px;font-weight:900;cursor:pointer;line-height:1.15;box-shadow:inset 0 1px 0 rgba(255,255,255,.06);}
      .lr75gExitRail button:hover{background:rgba(255,239,194,.21);border-color:rgba(255,232,166,.65);}
      .lr75gExitRail[data-lr75g-bottomrail]{margin-top:18px;margin-bottom:4px;}
      @media(max-width:760px){.lr75gExitRail{gap:6px}.lr75gExitRail button{padding:8px 9px;font-size:.9rem}.lr75gExitLabel{flex-basis:100%;}}
    `;
    document.head.appendChild(st);
  }

  function boot(){
    installStyles(); bind(); wrapOpeners(); scan();
    setTimeout(scan,200); setTimeout(scan,900); setTimeout(scan,1800);
    try{
      var mo = new MutationObserver(function(){ scheduleScan(); });
      mo.observe(document.body,{childList:true,subtree:true});
    }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();

  window.lr75gOpenExitLibrary = openLibrary;
  window.lr75gOpenExitWing = openWing;
  window.lr75gAddExitPaths = scan;
})();
