// Question Mountain Phase 7 - Math Deepening IV
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Math",[
{teach:"Skip count by fives.",q:"5,10,15,... next?",c:["20","18","25"],a:"20"},
{teach:"A rectangle has four sides.",q:"Rectangle sides?",c:["4","3","5"],a:"4"},
{teach:"Heavier means more weight.",q:"Weight compares...",c:["heaviness","sound","stories"],a:"heaviness"},
{teach:"Patterns repeat.",q:"Math patterns may...",c:["repeat","sleep","hide"],a:"repeat"},
{teach:"Subtraction finds what remains.",q:"Subtraction finds...",c:["what remains","weather","maps"],a:"what remains"}
]);

LR_addLessons("Ava","Math",[
{teach:"Rates compare values.",q:"Rates compare...",c:["values","chapters","covers"],a:"values"},
{teach:"Area measures surface.",q:"Area measures...",c:["surface","time","songs"],a:"surface"},
{teach:"Mean is an average.",q:"Mean is a type of...",c:["average","shape","equation"],a:"average"},
{teach:"Negative numbers are below zero.",q:"Negative numbers are...",c:["below zero","above 100","fractions only"],a:"below zero"},
{teach:"Percent can represent parts.",q:"Percent represents...",c:["parts","maps","covers"],a:"parts"}
]);

LR_addLessons("Michael","Math",[
{teach:"Slope measures steepness.",q:"Slope measures...",c:["steepness","weight","chapters"],a:"steepness"},
{teach:"Variables may change.",q:"Variables can...",c:["change","freeze","sleep"],a:"change"},
{teach:"Statistics use samples.",q:"Statistics may use...",c:["samples","stories","titles"],a:"samples"},
{teach:"Inequalities compare values.",q:"Inequalities...",c:["compare values","draw maps","paint"],a:"compare values"},
{teach:"Functions show relationships.",q:"Functions show...",c:["relationships","weather","coins"],a:"relationships"}
]);
})();