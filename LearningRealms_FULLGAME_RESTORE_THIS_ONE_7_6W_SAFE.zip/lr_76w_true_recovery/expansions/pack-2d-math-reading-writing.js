// Curriculum Pack 2D: Math / Reading Fluency / Writing Practice
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Reading",[
 {teach:"A long a sound can be spelled with final e.",practice:"cap becomes cape.",q:"Which word has long a?",c:["cape","cap","cat"],a:"cape"},
 {teach:"A long i sound can be spelled with final e.",practice:"pin becomes pine.",q:"Which word has long i?",c:["pine","pin","pig"],a:"pine"},
 {teach:"A long o sound can be spelled with final e.",practice:"hop becomes hope.",q:"Which word has long o?",c:["hope","hop","hot"],a:"hope"},
 {teach:"A long u sound can be spelled with final e.",practice:"cub becomes cube.",q:"Which word has long u?",c:["cube","cub","cup"],a:"cube"},
 {teach:"The blend TR is in tree.",practice:"tree, trip, truck",q:"Which starts with TR?",c:["tree","ship","cat"],a:"tree"},
 {teach:"The blend SN is in snail.",practice:"snail, snow, snack",q:"Which starts with SN?",c:["snail","flag","chair"],a:"snail"},
 {teach:"The digraph CK usually comes after a short vowel.",practice:"duck, lock, back",q:"Which word ends with CK?",c:["duck","dog","cake"],a:"duck"},
 {teach:"A sight word should be read quickly.",practice:"said, was, they",q:"Which is a sight word?",c:["said","glorp","zib"],a:"said"}
]);

LR_addLessons("Luna","English",[
 {teach:"A sentence can tell who and what happened.",practice:"The fox ran.",q:"Who ran?",c:["fox","ran","the"],a:"fox"},
 {teach:"A good retell includes beginning, middle, and end.",practice:"First, next, last.",q:"A retell should include...",c:["beginning, middle, end","only the last word","only the title"],a:"beginning, middle, end"},
 {teach:"A pronoun can take the place of a noun.",practice:"Luna becomes she.",q:"Which word can replace Luna?",c:["she","tree","run"],a:"she"},
 {teach:"A comma can separate items in a list.",practice:"apples, pears, and grapes",q:"Which mark separates list items?",c:[",",".","?"],a:","},
 {teach:"A writer can add where something happened.",practice:"The rabbit hopped in the garden.",q:"Which tells where?",c:["in the garden","rabbit","hopped"],a:"in the garden"},
 {teach:"A writer can add when something happened.",practice:"The owl called at night.",q:"Which tells when?",c:["at night","owl","called"],a:"at night"}
]);

LR_addLessons("Luna","Math",[
 {teach:"Adding three numbers can be easier by making ten first.",practice:"8 + 2 + 5 = 15.",q:"8 + 2 + 5 = ?",c:["15","10","12"],a:"15"},
 {teach:"Subtraction can be checked with addition.",practice:"12 - 5 = 7, and 7 + 5 = 12.",q:"Check 12 - 5 with...",c:["7 + 5","12 + 5","5 - 7"],a:"7 + 5"},
 {teach:"Teen numbers are one ten and some ones.",practice:"14 is 1 ten and 4 ones.",q:"14 has 1 ten and how many ones?",c:["4","14","1"],a:"4"},
 {teach:"A number line helps show counting forward and backward.",practice:"Start at 6 and jump to 9.",q:"From 6 to 9 is how many jumps?",c:["3","2","4"],a:"3"},
 {teach:"Equal means the same amount.",practice:"5 + 2 equals 7.",q:"Which means equal?",c:["same amount","bigger only","smaller only"],a:"same amount"},
 {teach:"A half dollar is 50 cents.",practice:"Half of 100 cents is 50 cents.",q:"How much is a half dollar?",c:["50","25","10"],a:"50"}
]);

LR_addLessons("Ava","Math",[
 {teach:"A ratio can be written with a colon, fraction, or words.",practice:"3 to 5, 3:5, and 3/5.",q:"Which shows 3 to 5?",c:["3:5","5:3 only","8"],a:"3:5"},
 {teach:"Cross products can test proportions.",practice:"2/3 = 4/6 because 2×6 = 3×4.",q:"2/3 and 4/6 are...",c:["proportional","never equal","opposites"],a:"proportional"},
 {teach:"Adding integers with different signs means subtract and keep the sign of the larger absolute value.",practice:"-8 + 3 = -5.",q:"-8 + 3 = ?",c:["-5","11","5"],a:"-5"},
 {teach:"Subtracting an integer is adding its opposite.",practice:"5 - (-2) = 5 + 2.",q:"5 - (-2) = ?",c:["7","3","-7"],a:"7"},
 {teach:"A variable represents an unknown or changing number.",practice:"x can stand for a number.",q:"A variable represents...",c:["a number","a paragraph","a cell"],a:"a number"},
 {teach:"To solve x/4 = 9, multiply both sides by 4.",practice:"9 × 4 = 36.",q:"x/4 = 9. x = ?",c:["36","13","5"],a:"36"},
 {teach:"Percent of a number can be found by converting to a decimal.",practice:"10% of 80 is 8.",q:"10% of 80 is...",c:["8","10","80"],a:"8"},
 {teach:"The circumference formula is C = πd.",practice:"Diameter times pi.",q:"Circumference equals pi times...",c:["diameter","radius only","height"],a:"diameter"}
]);

LR_addLessons("Ava","English",[
 {teach:"Claim, evidence, and reasoning form a strong response.",practice:"State answer, prove it, explain it.",q:"CER stands for claim, evidence, and...",c:["reasoning","reading","result"],a:"reasoning"},
 {teach:"A direct quote copies exact words from a text.",practice:"Use quotation marks around exact words.",q:"Exact words from a text are a...",c:["direct quote","summary","prediction"],a:"direct quote"},
 {teach:"Paraphrasing restates an idea in your own words.",practice:"Keep the meaning but change wording.",q:"Paraphrasing uses...",c:["your own words","only exact copy","no meaning"],a:"your own words"},
 {teach:"A paragraph conclusion wraps up the main idea.",practice:"It should not introduce a completely new topic.",q:"A conclusion should...",c:["wrap up","start random topic","ignore the paragraph"],a:"wrap up"},
 {teach:"A character's motivation is why the character acts.",practice:"A character trains because he wants to win.",q:"Motivation means...",c:["why someone acts","where they live","what color"],a:"why someone acts"},
 {teach:"Conflict is a struggle or problem in a story.",practice:"A locked gate creates conflict.",q:"Conflict means...",c:["struggle or problem","title only","author name"],a:"struggle or problem"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Speed is distance divided by time.",practice:"60 miles in 2 hours is 30 miles per hour.",q:"Speed equals distance divided by...",c:["time","mass","volume"],a:"time"},
 {teach:"A graph can show how variables are related.",practice:"Temperature over days can be graphed.",q:"Graphs can show relationships between...",c:["variables","only nouns","citizens"],a:"variables"},
 {teach:"Rocks can be igneous, sedimentary, or metamorphic.",practice:"These are three rock types.",q:"Which is a rock type?",c:["igneous","photosynthesis","claim"],a:"igneous"},
 {teach:"Fossils give evidence about past life.",practice:"Bones or prints can become fossils.",q:"Fossils are evidence of...",c:["past life","future weather","grammar"],a:"past life"},
 {teach:"Inherited traits come from parents.",practice:"Eye color can be inherited.",q:"Inherited traits come from...",c:["parents","weather","books"],a:"parents"},
 {teach:"Learned behaviors are gained through experience.",practice:"A dog learning a trick.",q:"A learned behavior comes from...",c:["experience","only DNA","gravity"],a:"experience"}
]);

LR_addLessons("Michael","Math",[
 {teach:"A multi-step equation may need distributing, combining like terms, and inverse operations.",practice:"2(x + 3) = 14 gives x = 4.",q:"2(x + 3) = 14. x = ?",c:["4","7","11"],a:"4"},
 {teach:"Equations with variables on both sides can be solved by moving variable terms together.",practice:"5x + 2 = 3x + 10 gives 2x = 8.",q:"5x + 2 = 3x + 10. x = ?",c:["4","8","2"],a:"4"},
 {teach:"Slope is the change in y divided by the change in x.",practice:"From (1,2) to (3,6), slope is 4/2.",q:"Slope from (1,2) to (3,6)?",c:["2","4","1"],a:"2"},
 {teach:"The equation y = 3x has slope 3 and y-intercept 0.",practice:"It is proportional.",q:"y = 3x has y-intercept...",c:["0","3","1"],a:"0"},
 {teach:"Systems can be solved by substitution.",practice:"If y = x + 2 and y = 6, then x = 4.",q:"If y = x + 2 and y = 6, x = ?",c:["4","8","2"],a:"4"},
 {teach:"A scatter plot with points rising left to right shows positive association.",practice:"More study time, higher score.",q:"Rising points show...",c:["positive association","negative association","no relationship"],a:"positive association"},
 {teach:"A right triangle satisfies a² + b² = c².",practice:"3² + 4² = 5².",q:"For 3, 4, 5 triangle, hypotenuse is...",c:["5","4","3"],a:"5"},
 {teach:"Dilations change size but not shape.",practice:"Scale factor 2 doubles dimensions.",q:"A dilation changes...",c:["size","only color","only name"],a:"size"}
]);

LR_addLessons("Michael","English",[
 {teach:"A strong argument anticipates opposing views.",practice:"Address what another side might say.",q:"A strong argument considers...",c:["opposing views","only pictures","weather"],a:"opposing views"},
 {teach:"A rebuttal explains why the counterclaim does not defeat the claim.",practice:"It answers the other side.",q:"A rebuttal answers the...",c:["counterclaim","title","setting"],a:"counterclaim"},
 {teach:"Credible sources use evidence and can be checked.",practice:"Look for author, date, and support.",q:"Credible sources can be...",c:["checked","random","anonymous only"],a:"checked"},
 {teach:"A research outline organizes ideas before drafting.",practice:"Main points first, evidence under each.",q:"An outline helps organize...",c:["ideas","weather","volume"],a:"ideas"},
 {teach:"A topic sentence controls the paragraph's direction.",practice:"Details should connect back to it.",q:"Details should connect to the...",c:["topic sentence","font size","page color"],a:"topic sentence"},
 {teach:"Academic tone is clear, focused, and not too casual.",practice:"Avoid slang in formal writing.",q:"Academic tone avoids...",c:["slang","evidence","clear words"],a:"slang"}
]);

LR_addLessons("Michael","Science",[
 {teach:"A balanced chemical equation has the same number of atoms on both sides.",practice:"Atoms are conserved.",q:"Balanced equations conserve...",c:["atoms","paragraphs","votes"],a:"atoms"},
 {teach:"The law of conservation of mass says matter is not lost in a closed system.",practice:"Mass before equals mass after.",q:"Conservation of mass means mass is...",c:["not lost","always doubled","ignored"],a:"not lost"},
 {teach:"Acceleration is change in velocity over time.",practice:"Speeding up means accelerating.",q:"Acceleration is change in...",c:["velocity","mass only","density only"],a:"velocity"},
 {teach:"Unbalanced forces cause acceleration.",practice:"A stronger push changes motion.",q:"Unbalanced forces cause...",c:["acceleration","no change","only spelling"],a:"acceleration"},
 {teach:"Mechanical waves require a medium.",practice:"Sound travels through air.",q:"Sound needs a...",c:["medium","vacuum only","claim"],a:"medium"},
 {teach:"Electromagnetic waves can travel through space.",practice:"Light from the sun travels through space.",q:"Light can travel through...",c:["space","only water","only soil"],a:"space"}
]);

LR_addLessons("Michael","History",[
 {teach:"The rule of law means everyone is subject to the law.",practice:"Leaders and citizens must follow laws.",q:"Rule of law means laws apply to...",c:["everyone","only children","only rulers"],a:"everyone"},
 {teach:"Popular sovereignty means the people are the source of government power.",practice:"People consent to government.",q:"Popular sovereignty means power comes from...",c:["the people","the weather","the market only"],a:"the people"},
 {teach:"A market economy uses voluntary exchange between buyers and sellers.",practice:"Prices help guide choices.",q:"A market economy uses...",c:["voluntary exchange","only commands","no choices"],a:"voluntary exchange"},
 {teach:"Inflation means a general rise in prices over time.",practice:"Money buys less when prices rise.",q:"Inflation is a rise in...",c:["prices","gravity","cell parts"],a:"prices"},
 {teach:"Historical context means the conditions surrounding an event.",practice:"Time, place, beliefs, and problems matter.",q:"Historical context means surrounding...",c:["conditions","equations","shapes"],a:"conditions"},
 {teach:"Continuity means what stayed the same over time.",practice:"Some traditions continue for generations.",q:"Continuity means what...",c:["stayed the same","changed instantly","was deleted"],a:"stayed the same"}
]);
