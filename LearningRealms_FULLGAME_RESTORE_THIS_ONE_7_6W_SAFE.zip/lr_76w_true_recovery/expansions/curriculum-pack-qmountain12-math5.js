// Question Mountain Phase 12 - Math Deepening V
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Math",[
{teach:"Skip count by tens.",q:"10,20,30,... next?",c:["40","35","50"],a:"40"},
{teach:"Circles are round.",q:"Which shape is round?",c:["circle","square","triangle"],a:"circle"},
{teach:"Longer means more length.",q:"Length compares...",c:["distance","weather","stories"],a:"distance"},
{teach:"Addition joins groups.",q:"Addition helps...",c:["combine","separate","hide"],a:"combine"},
{teach:"Patterns can grow.",q:"Patterns may...",c:["grow","sleep","freeze"],a:"grow"}
]);

LR_addLessons("Ava","Math",[
{teach:"Perimeter measures around shapes.",q:"Perimeter measures...",c:["around","inside","time"],a:"around"},
{teach:"Decimals show parts of wholes.",q:"Decimals show...",c:["parts","maps","coins"],a:"parts"},
{teach:"Tables organize data.",q:"Tables organize...",c:["data","songs","titles"],a:"data"},
{teach:"Ratios compare quantities.",q:"Ratios compare...",c:["quantities","weather","stories"],a:"quantities"},
{teach:"Coordinate grids use axes.",q:"Coordinate grids use...",c:["axes","covers","coins"],a:"axes"}
]);

LR_addLessons("Michael","Math",[
{teach:"Systems use multiple equations.",q:"Systems contain...",c:["equations","chapters","maps"],a:"equations"},
{teach:"Linear graphs make lines.",q:"Linear graphs form...",c:["lines","circles","songs"],a:"lines"},
{teach:"Probability studies chance.",q:"Probability studies...",c:["chance","weather","trade"],a:"chance"},
{teach:"Data sets have ranges.",q:"Range relates to...",c:["data","titles","covers"],a:"data"},
{teach:"Exponents show repeated multiplication.",q:"Exponents show...",c:["repeated multiplication","division only","weather"],a:"repeated multiplication"}
]);
})();