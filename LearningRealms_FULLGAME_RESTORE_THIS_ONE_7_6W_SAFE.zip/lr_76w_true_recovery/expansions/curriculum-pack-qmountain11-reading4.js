// Question Mountain Phase 11 - Reading Deepening IV
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Reading",[
{teach:"Readers can predict.",q:"Predict means...",c:["guess what may happen","measure","count"],a:"guess what may happen"},
{teach:"Stories have endings.",q:"Stories have...",c:["endings","equations","maps"],a:"endings"},
{teach:"Words make sentences.",q:"Sentences use...",c:["words","coins","rocks"],a:"words"},
{teach:"Readers look at pictures.",q:"Pictures help readers...",c:["understand","sleep","trade"],a:"understand"},
{teach:"Stories happen in order.",q:"Stories have...",c:["sequence","weather","money"],a:"sequence"}
]);

LR_addLessons("Ava","Reading",[
{teach:"Headings organize texts.",q:"Headings help...",c:["organize","measure","graph"],a:"organize"},
{teach:"Captions explain pictures.",q:"Captions explain...",c:["images","equations","coins"],a:"images"},
{teach:"Readers identify themes.",q:"Themes are...",c:["messages","maps","titles"],a:"messages"},
{teach:"Evidence supports answers.",q:"Answers use...",c:["evidence","luck","guessing"],a:"evidence"},
{teach:"Authors choose structure.",q:"Authors use...",c:["organization","weather","trade"],a:"organization"}
]);

LR_addLessons("Michael","Reading",[
{teach:"Authors may compare ideas.",q:"Compare means...",c:["show similarities","count","graph"],a:"show similarities"},
{teach:"Arguments contain claims.",q:"Arguments use...",c:["claims","covers","maps"],a:"claims"},
{teach:"Reliable sources matter.",q:"Readers seek...",c:["reliable sources","colors","coins"],a:"reliable sources"},
{teach:"Purpose affects writing.",q:"Purpose affects...",c:["content","weather","trade"],a:"content"},
{teach:"Readers analyze structure.",q:"Analyze means...",c:["study closely","sleep","hide"],a:"study closely"}
]);
})();