/* LearningRealms Living World Preservation Pass 7.4L
   Built on the good 7.4K Subject Room Polish base.
   Purpose: keep the living-game systems visible and reachable without rewriting
   the RPG shell, changing saves, or touching enriched subject content.
   Adds a Town Notice Board / Living World Ledger as an in-world hub for seasons,
   festivals, birthdays/special-day rewards, merchants, rare rotations, pets,
   quests, collections, home, parent reward codes, and event records.
*/
(function(){
  'use strict';
  if(window.__LR74L_LIVING_WORLD_PRESERVATION__) return;
  window.__LR74L_LIVING_WORLD_PRESERVATION__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function has(name){ return typeof window[name] === 'function'; }
  function call(name){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(name)) return false;
    try{ window[name].apply(window,args); return true; }
    catch(e){ console.warn('LR74L call failed:', name, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var item=list[i];
      if(Array.isArray(item)){ if(call.apply(null,item)) return true; }
      else if(call(item)) return true;
    }
    return false;
  }
  function activeName(){
    try{ if(window.activeChild) return window.activeChild; }catch(e){}
    var s=byId('studentSelect');
    return (s && s.value) || 'Adventurer';
  }
  function mount(){
    var firstCard = q('.main > .card:first-child') || q('section.main') || q('.main') || document.body;
    var m = byId('lrDynamicAdventureScreen');
    if(!m){
      m = document.createElement('div');
      m.id = 'lrDynamicAdventureScreen';
      m.className = 'lrDynamicAdventureScreen';
      if(firstCard.firstChild) firstCard.insertBefore(m, firstCard.firstChild); else firstCard.appendChild(m);
    }
    m.style.display='block'; m.style.visibility='visible'; m.style.opacity='1';
    return m;
  }
  function popup(title, html){
    if(has('lrOpenPopup')){ window.lrOpenPopup(title, html); return; }
    var at=byId('actionTitle'), ax=byId('actionText');
    if(at) at.textContent = title;
    if(ax) ax.innerHTML = html;
    if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title);
  }
  function todayKey(){
    var d=new Date();
    return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
  }
  function activeSeasons(){
    try{
      if(has('lrActiveSeasons')){
        var s = window.lrActiveSeasons();
        if(Array.isArray(s) && s.length) return s;
      }
    }catch(e){}
    return ['Everyday Kingdom'];
  }
  function systemStatus(list){
    for(var i=0;i<list.length;i++){ if(has(list[i])) return true; }
    return false;
  }
  function addHomeItem(name, slot){
    slot = slot || 'shelf';
    try{
      if(has('ensureHome')){
        var h = window.ensureHome();
        h.storage = h.storage || [];
        var exists = h.storage.some(function(it){ return (it && (it.name || it) === name); });
        if(!exists) h.storage.push({name:name, slot:slot});
        if(has('save')) window.save();
        toast(exists ? 'Already stored: '+name : 'Added to home storage: '+name);
        return true;
      }
    }catch(e){}
    try{
      var key='LR74L_LIVING_WORLD_TOKENS_'+activeName();
      var list=[];
      try{ list=JSON.parse(localStorage.getItem(key)||'[]'); }catch(e){}
      if(list.indexOf(name)<0) list.push(name);
      localStorage.setItem(key, JSON.stringify(list));
      toast('Token remembered: '+name);
      return true;
    }catch(e){}
    toast('Token noted: '+name);
    return false;
  }
  function toast(msg){
    var old=byId('lr74lToast'); if(old) old.remove();
    var d=document.createElement('div'); d.id='lr74lToast'; d.className='lr74lToast'; d.textContent=msg;
    document.body.appendChild(d);
    setTimeout(function(){ try{ d.remove(); }catch(e){} },2300);
  }

  var ROUTES = {
    seasons:{
      title:'Seasonal Calendar', icon:'🌿', place:'Festival Notice Board',
      detail:'Active seasons, rotating event displays, seasonal drops, and vendor catalogs belong here.',
      calls:['openSeasonalCalendar','openSeasonHall','openSeasonQuests']
    },
    seasonalMarket:{
      title:'Seasonal Market', icon:'🧺', place:'Festival Market Stall',
      detail:'This opens the rotating vendor and discovery hooks for the active season.',
      calls:['openSeasonalVendor','openSeasonalSearch','openSeasonHall']
    },
    merchants:{
      title:'Merchant Row', icon:'🛒', place:'Lantern-Lit Shop Street',
      detail:'Shopkeepers, themed currencies, goal items, and the daily surprise merchant live here.',
      calls:['lr69OpenMerchantSquare','openShop','openShopHub','lrSafeBrowseShopPopup','openShopPopup']
    },
    rare:{
      title:'Rare Finds Shelf', icon:'✨', place:'Mystery Merchant Corner',
      detail:'Rare daily rotations are reached through Merchant Row so the special stock stays connected to the shop system.',
      calls:['lr69OpenMerchantSquare','openShop','openShopHub','lrSafeBrowseShopPopup']
    },
    collections:{
      title:'Treasure Registry', icon:'🎒', place:'Collection Ledger Desk',
      detail:'Badges, artifacts, decor, museum pieces, and found treasures should be checked from here.',
      calls:['openCollectionLog','openBackpack','openInventoryPopup','openAchievementJournal','openCastlePrestige']
    },
    companions:{
      title:'Companion Den', icon:'🐾', place:'Pet Corner Gate',
      detail:'Pets, companions, pet records, and bond progress remain protected here.',
      calls:['openCompanionDen','openPetJournal','openCompanionPopup','openCompanionEngine']
    },
    quests:{
      title:'Quest Board', icon:'📜', place:'Pinned Errand Board',
      detail:'Daily jobs, story paths, long journeys, and quest records gather on this board.',
      calls:['openQuestBoard','openDailyQuestBoard','openQuestJournal','openLongQuestJournal','openStoryQuestJournal','openQuestPopup']
    },
    home:{
      title:'Home Hearth', icon:'🏡', place:'Home Room Door',
      detail:'Home rooms, storage, decor, placement, expansion, and displays remain reachable from this door.',
      calls:['openHomeRenderer','openHomeViewPopup','openHomeView','openVisibleHome','openHomeRooms','openVisualHome','openHomeExpansionPopup','openHomeExpansion2']
    },
    celebration:{
      title:'Birthday and Special Day Chest', icon:'🎂', place:'Family Celebration Chest',
      detail:'Birthday and celebration rewards are kept with parent reward codes and the seasonal calendar rather than scattered around the map.',
      calls:['openRewardCodeRedeemer','openSeasonalCalendar','openSeasonHall']
    },
    parentVault:{
      title:'Parent Reward Vault', icon:'🔐', place:'Reward Code Desk',
      detail:'Parent reward codes, celebration vouchers, decor chests, and bigger unlocks are preserved here.',
      calls:['openRewardCodeRedeemer','openParentRewardVault','openParentDashboard']
    },
    events:{
      title:'Event Log', icon:'🗓️', place:'Town Chronicle Book',
      detail:'Random events, treasure-map style discoveries, and realm happenings can be reviewed from here when the system is available.',
      calls:['openEventLog','openStoryCampaigns','openWorldAtlas','openAtlasPopup']
    },
    world:{
      title:'World Directory', icon:'🗺️', place:'Atlas Cabinet',
      detail:'The broader map, landmarks, world records, and route directories stay connected here.',
      calls:['openWorldAtlas','openWorldDirectory','openAtlasPopup','openLearningRealmsRealmAtlas74K','openLearningRealmsRealmAtlas']
    }
  };

  var CARDS = [
    ['seasons','Check the active season and event calendar.'],
    ['seasonalMarket','Browse seasonal vendor tables and discovery hooks.'],
    ['merchants','Visit shopkeepers, currencies, and goal items.'],
    ['rare','Look for the rare daily rotation through the merchant street.'],
    ['collections','Open artifacts, badges, decor, museum pieces, and treasures.'],
    ['companions','Check pets, companions, and companion records.'],
    ['quests','Open daily jobs, quest paths, story records, and long journeys.'],
    ['home','Return to rooms, storage, decor, and home displays.'],
    ['celebration','Reach birthday and special-day reward paths respectfully.'],
    ['parentVault','Open the parent reward code desk when needed.'],
    ['events','Review random events, campaigns, and town happenings.'],
    ['world','Open the larger atlas and world directory.']
  ];

  function styles(){
    if(byId('lr74lStyles')) return;
    var st=document.createElement('style'); st.id='lr74lStyles';
    st.textContent = `
      .lr74lRealm{min-height:650px;color:#f7ecc4;background:radial-gradient(circle at 16% 0%,rgba(255,227,150,.20),transparent 32%),radial-gradient(circle at 88% 16%,rgba(78,160,130,.12),transparent 28%),linear-gradient(180deg,#071f1c,#0b1714 58%,#170f08)!important;border-radius:18px;overflow:hidden;box-shadow:0 18px 38px rgba(0,0,0,.30)}
      .lr74lHero{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(280px,.85fr);gap:18px;padding:24px;background:linear-gradient(135deg,rgba(20,63,54,.95),rgba(9,24,21,.97) 58%,rgba(96,64,20,.87));border-bottom:1px solid rgba(246,218,142,.22)}
      .lr74lBadge{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(246,218,142,.28);background:rgba(0,0,0,.24);border-radius:999px;padding:7px 11px;color:#ffeab2;font-weight:1000;text-transform:uppercase;letter-spacing:.09em;font-size:.72rem}.lr74lHero h1{margin:12px 0 8px;color:#fff6d4;font-size:clamp(2rem,3.6vw,3.35rem);line-height:1;text-shadow:0 3px 0 rgba(0,0,0,.25)}.lr74lHero p{margin:.35rem 0;color:#d9eee2;font-weight:820;line-height:1.52}.lr74lToday{border:1px solid rgba(246,218,142,.24);background:linear-gradient(180deg,rgba(255,248,211,.11),rgba(0,0,0,.15));border-radius:17px;padding:14px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.04)}.lr74lToday h3{margin:0 0 7px;color:#fff1bd}.lr74lToday p{font-size:.94rem;line-height:1.45;margin:.3rem 0;color:#d6eadf}.lr74lBody{display:grid;grid-template-columns:minmax(0,1fr) 310px;gap:16px;padding:18px}.lr74lGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:12px}.lr74lCard{display:grid!important;grid-template-columns:48px 1fr auto;gap:11px;align-items:start;text-align:left;min-height:132px;border:1px solid rgba(246,218,142,.25)!important;border-radius:18px!important;background:linear-gradient(180deg,#fff8d8,#d9c087)!important;color:#211607!important;padding:13px!important;box-shadow:0 10px 18px rgba(0,0,0,.25)!important;cursor:pointer!important;font-weight:900!important}.lr74lCard:hover{transform:translateY(-1px);box-shadow:0 14px 26px rgba(0,0,0,.33)!important}.lr74lIcon{width:46px;height:46px;border-radius:13px;background:linear-gradient(180deg,#173831,#071715);display:grid;place-items:center;color:#fff0bd;font-size:1.35rem}.lr74lCard b{display:block;color:#211607;font-size:1.02rem;line-height:1.15}.lr74lCard small{display:block;color:#745515;text-transform:uppercase;letter-spacing:.04em;font-weight:1000;font-size:.68rem;margin:3px 0 5px}.lr74lCard span p{margin:0;color:#3d3322;line-height:1.32;font-weight:780}.lr74lArrow{align-self:center;font-size:1.85rem;color:#6e4b0f}.lr74lSide{display:grid;gap:12px;align-content:start}.lr74lPanel{border:1px solid rgba(246,218,142,.20);border-radius:16px;background:linear-gradient(180deg,rgba(255,247,212,.10),rgba(0,0,0,.17));padding:13px}.lr74lPanel h3{margin:0 0 8px;color:#fff0bd}.lr74lPanel p{margin:.3rem 0;color:#d2e9dd;line-height:1.42;font-weight:780}.lr74lShelf{display:flex;flex-wrap:wrap;gap:7px}.lr74lShelf span{border:1px solid rgba(246,218,142,.24);border-radius:999px;background:rgba(0,0,0,.20);color:#ffe8ab;padding:6px 8px;font-weight:900;font-size:.78rem}.lr74lStatusGrid{display:grid;grid-template-columns:1fr;gap:7px}.lr74lStatus{display:flex;justify-content:space-between;gap:8px;align-items:center;border:1px solid rgba(246,218,142,.18);border-radius:12px;padding:8px 9px;background:rgba(0,0,0,.17);color:#ffe8ab;font-weight:900}.lr74lStatus i{font-style:normal;color:#d5eadf}.lr74lStatus.ok strong{color:#95ffac}.lr74lStatus.warn strong{color:#ffd36e}.lr74lActions{display:grid;gap:8px}.lr74lActions button,.lr74lFoot button{border:1px solid rgba(246,218,142,.34)!important;border-radius:12px!important;background:linear-gradient(180deg,#fff3bf,#d2a04b)!important;color:#1c1106!important;font-weight:1000!important;padding:10px!important;cursor:pointer!important}.lr74lFoot{display:flex;flex-wrap:wrap;gap:9px;padding:14px 18px;background:#071413;border-top:1px solid rgba(246,218,142,.16)}.lr74lToast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:99999;border:1px solid rgba(246,218,142,.45);border-radius:999px;background:#071413;color:#fff0bd;box-shadow:0 10px 24px rgba(0,0,0,.35);padding:10px 14px;font-weight:1000}.lr74lInjectDoor{margin-top:12px!important}.lr74lMiniDoor{border:1px solid rgba(246,218,142,.30)!important;border-radius:14px!important;background:linear-gradient(180deg,#fff3bf,#d1a04d)!important;color:#1c1106!important;font-weight:1000!important;padding:10px!important;cursor:pointer!important}.lr74lPopup{color:#261904}.lr74lPopup p{line-height:1.5}.lr74lSmallGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px;margin-top:10px}.lr74lSmallGrid button{border-radius:12px!important;padding:9px!important;font-weight:1000!important}
      @media(max-width:1050px){.lr74lHero,.lr74lBody{grid-template-columns:1fr}.lr74lBody{padding:12px}.lr74lHero{padding:18px}.lr74lGrid{grid-template-columns:1fr}}
    `;
    document.head.appendChild(st);
  }
  function cardHtml(key, note){
    var r=ROUTES[key];
    var status=systemStatus(r.calls) ? 'Detected' : 'Fallback';
    return '<button type="button" class="lr74lCard" data-lr74l-act="'+esc(key)+'"><span class="lr74lIcon">'+esc(r.icon)+'</span><span><b>'+esc(r.title)+'</b><small>'+esc(r.place)+' · '+esc(status)+'</small><p>'+esc(note || r.detail)+'</p></span><i class="lr74lArrow">›</i></button>';
  }
  function statusRow(title, ok){ return '<div class="lr74lStatus '+(ok?'ok':'warn')+'"><i>'+esc(title)+'</i><strong>'+(ok?'ready':'fallback')+'</strong></div>'; }
  function renderLedger(){
    styles();
    var m=mount();
    var seasons=activeSeasons();
    var html='<div class="lr74lRealm lr74kRealm" data-lr74k-room="living-world" data-lr74l-room="ledger">'+
      '<section class="lr74lHero"><div><span class="lr74lBadge">🏮 Living World · Preservation Pass 7.4L</span><h1>Town Notice Board</h1><p>The game systems that make the realm feel alive are gathered here as places: festival boards, merchant streets, rare shelves, companion corners, home rooms, collections, and special-day reward paths.</p><p>This is not a new shell. It is a safe in-world access room so the fun systems stay reachable while the lessons become richer.</p></div><div class="lr74lToday"><h3>Today in the realm</h3><p><b>Active season:</b> '+esc(seasons.join(', '))+'</p><p><b>Date key:</b> '+esc(todayKey())+'</p><p><b>Player:</b> '+esc(activeName())+'</p><p>The market lanterns, rare shelf, event notices, and home displays are kept together so they do not vanish behind course menus.</p></div></section>'+
      '<section class="lr74lBody"><div class="lr74lGrid">'+CARDS.map(function(c){ return cardHtml(c[0], c[1]); }).join('')+'</div><aside class="lr74lSide"><div class="lr74lPanel"><h3>🔎 Preservation check</h3><div class="lr74lStatusGrid">'+
        statusRow('Season systems', systemStatus(['openSeasonalCalendar','openSeasonHall','openSeasonQuests']))+
        statusRow('Shopkeepers', systemStatus(['lr69OpenMerchantSquare','openShop','openShopHub']))+
        statusRow('Rare rotations', systemStatus(['lr69OpenMerchantSquare']))+
        statusRow('Collections', systemStatus(['openCollectionLog','openCastlePrestige']))+
        statusRow('Companions', systemStatus(['openCompanionDen','openPetJournal']))+
        statusRow('Quests', systemStatus(['openQuestBoard','openDailyQuestBoard','openQuestJournal']))+
        statusRow('Home rooms', systemStatus(['openHomeRenderer','openHomeViewPopup','openHomeView']))+
        statusRow('Reward codes', systemStatus(['openRewardCodeRedeemer']))+
        '</div></div><div class="lr74lPanel"><h3>🏺 Shelf items</h3><div class="lr74lShelf"><span>Festival notice pin</span><span>Merchant bell tag</span><span>Rare shelf lantern</span><span>Companion paw token</span><span>Home room key</span><span>Birthday chest ribbon</span></div></div><div class="lr74lPanel"><h3>🎒 Room token</h3><p>Collect the Town Notice Board Token if you want a small home-storage marker for this living-world hub.</p><div class="lr74lActions"><button data-lr74l-act="collect">Collect Town Notice Board Token</button><button data-lr74l-act="health">Open preservation report</button></div></div></aside></section>'+
      '<div class="lr74lFoot"><button data-lr74l-act="home">🏡 Home Hearth</button><button data-lr74l-act="merchants">🛒 Merchant Row</button><button data-lr74l-act="seasons">🌿 Seasons</button><button data-lr74l-act="collections">🎒 Collections</button><button data-lr74l-act="back">🗺️ Back to roads</button></div></div>';
    m.innerHTML=html;
    return false;
  }
  function fallback(key){
    var r=ROUTES[key];
    if(!r) return renderLedger();
    popup(r.icon+' '+r.title, '<div class="lr74lPopup"><h3>'+esc(r.place)+'</h3><p>'+esc(r.detail)+'</p><p>The direct system hook was not found in this branch, so this door is preserved as a safe marker instead of becoming a dead button.</p><div class="lr74lSmallGrid"><button data-lr74l-act="ledger">Return to Town Notice Board</button><button data-lr74l-act="health">Preservation report</button></div></div>');
    return false;
  }
  function openSystem(key){
    var r=ROUTES[key];
    if(!r) return renderLedger();
    if(first(r.calls)) return false;
    return fallback(key);
  }
  function health(){
    var rows = Object.keys(ROUTES).map(function(k){ var r=ROUTES[k]; return '<div class="lr74lStatus '+(systemStatus(r.calls)?'ok':'warn')+'"><i>'+esc(r.icon+' '+r.title)+'</i><strong>'+(systemStatus(r.calls)?'hook detected':'safe fallback')+'</strong></div>'; }).join('');
    popup('🏮 Living World Preservation Report','<div class="lr74lPopup"><h3>Preservation report</h3><p>This report checks whether each living-world doorway can find its underlying system hook. A fallback means the button will still open a safe note instead of doing nothing.</p><div class="lr74lStatusGrid">'+rows+'</div><div class="lr74lSmallGrid"><button data-lr74l-act="ledger">Return to Town Notice Board</button><button data-lr74l-act="back">Back to roads</button></div></div>');
    return false;
  }
  function route(act){
    var raw = String(act||'ledger');
    var norm = raw.toLowerCase().replace(/[^a-z0-9]/g,'');
    var keyMap = {seasonalmarket:'seasonalMarket', parentvault:'parentVault', livingworld:'ledger', noticeboard:'ledger', town:'ledger'};
    act = keyMap[norm] || norm;
    if(act==='ledger') return renderLedger();
    if(act==='collect'){ addHomeItem('Town Notice Board Token','shelf'); return false; }
    if(act==='health' || act==='report') return health();
    if(act==='back' || act==='roads' || act==='atlas'){
      return first(['openLearningRealmsRealmAtlas74K','openLearningRealmsRealmAtlas','lr74kRoute']) || renderLedger();
    }
    return openSystem(act);
  }

  function injectDoor(){
    styles();
    var root=q('#lrDynamicAdventureScreen .lr74kRealm');
    if(!root || root.getAttribute('data-lr74l-patched')==='1') return;
    var txt=(root.textContent||'').replace(/\s+/g,' ');
    var room=root.getAttribute('data-lr74k-room')||'';
    var isGood=/Realm Crossroads|Homestead Workshop|Home Hearth|Quest Board|Collection Log|Companion Den/i.test(txt) || /atlas|homestead/i.test(room);
    if(!isGood) return;
    root.setAttribute('data-lr74l-patched','1');
    var choices=q('.lr74kChoices', root);
    if(choices && !q('[data-lr74l-act="ledger"]', choices)){
      var wrap=document.createElement('div');
      wrap.className='lr74lInjectDoor';
      wrap.innerHTML=cardHtml('ledger' in ROUTES ? 'world' : 'world','Open the Town Notice Board for seasons, shopkeepers, rare finds, companions, quests, home rooms, and special-day rewards.');
      // The world card opens a broader atlas, so force this injected door to the living-world ledger.
      var btn=q('button', wrap); if(btn){ btn.setAttribute('data-lr74l-act','ledger'); btn.querySelector('b').textContent='Town Notice Board'; var sm=btn.querySelector('small'); if(sm) sm.textContent='Living World Ledger · Safe hub'; }
      choices.insertBefore(wrap.firstChild, choices.firstChild);
    }
    var foot=q('.lr74kFooter', root);
    if(foot && !q('[data-lr74l-act="ledger"]', foot)){
      var b=document.createElement('button'); b.type='button'; b.className='lr74lMiniDoor'; b.setAttribute('data-lr74l-act','ledger'); b.textContent='🏮 Town Notice Board'; foot.appendChild(b);
    }
  }
  function bind(){
    if(window.__LR74L_BOUND__) return;
    window.__LR74L_BOUND__=true;
    window.addEventListener('click', function(ev){
      var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr74l-act]') : null;
      if(!el) return;
      var act=el.getAttribute('data-lr74l-act');
      if(!act) return;
      ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
      route(act);
    }, true);
  }
  var timer=0;
  function schedule(){ if(timer) return; timer=setTimeout(function(){ timer=0; injectDoor(); },160); }
  function boot(){
    styles(); bind(); schedule();
    setTimeout(schedule,400); setTimeout(schedule,1000); setTimeout(schedule,2200);
    try{ var mo=new MutationObserver(schedule); mo.observe(document.body,{childList:true,subtree:true}); }catch(e){}
  }

  window.openLivingWorldLedger74L = renderLedger;
  window.lr74lRoute = route;
  window.LR74L_LIVING_WORLD_SYSTEMS = ROUTES;

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,120); setTimeout(schedule,900); });
})();
