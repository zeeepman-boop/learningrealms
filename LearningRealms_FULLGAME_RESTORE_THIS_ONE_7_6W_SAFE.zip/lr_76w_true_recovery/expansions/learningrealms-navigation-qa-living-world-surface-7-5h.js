/* LearningRealms 7.5H - Full Game Navigation QA + Living World Surface Pass
   Built on 7.5G. Conservative patch only: no shell rewrite, no lesson rewrite,
   no save reset, no loading curtain, and no render loop.
   Goals:
   - Surface seasons/events/shops/rare rotations/companions/collections/home/quests in-world.
   - Add a Navigation Ledger with route checks and safe fallbacks.
   - Patch obvious dead/plain buttons by label without overriding working data-driven buttons.
   - Keep everything under logical umbrellas.
*/
(function(){
  'use strict';
  if(window.__LR75H_NAV_QA_LIVING_SURFACE__) return;
  window.__LR75H_NAV_QA_LIVING_SURFACE__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ try{ return (root||document).querySelector(sel); }catch(e){ return null; } }
  function qa(sel, root){ try{ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }catch(e){ return []; } }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function norm(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,''); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    var args=Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); return true; }
    catch(e){ console.warn('LR75H route failed:',fn,e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var x=list[i];
      if(Array.isArray(x)){ if(call.apply(null,x)) return true; }
      else if(call(x)) return true;
    }
    return false;
  }
  function activeName(){ var s=byId('studentSelect'); return (s&&s.value)||window.activeChild||'Adventurer'; }
  function closePopups(){
    try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){}
    try{ var p=byId('lrPopupRoot'); if(p) p.classList.add('hidden'); }catch(e){}
  }
  function mount(title, html){
    installStyles();
    closePopups();
    var at=byId('actionTitle'), ax=byId('actionText');
    if(at) at.textContent = title || 'Navigation Ledger';
    if(ax) ax.innerHTML = html;
    try{ if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title||'Navigation Ledger'); }catch(e){}
    setTimeout(scanButtons,30);
    setTimeout(surfaceLivingWorld,70);
  }
  function popup(title, html){
    installStyles();
    if(has('lrOpenPopup')){ try{ window.lrOpenPopup(title, html); setTimeout(scanButtons,40); return true; }catch(e){} }
    mount(title, html);
    return true;
  }

  var UMBRELLAS = {
    core:{icon:'🏰', title:'Core Halls', key:'core', note:'Reading, Writing, Math, Logic, Grammar, and Vocabulary belong together here.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'core', hooks:['openReadingComprehensionMasterCourse75C','openWritingCompositionMasterCourse','openMathAdventureMasterCourse75D','openLogicTowerCriticalThinking75E','openGrammarVocabularyLanguageForge75F']},
    science:{icon:'🔬', title:'Science and Engineering Quarter', key:'science', note:'Science, Nature, Weather, Animals, Inventions, Aerospace, and Engineering stay in one big quarter.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'science', hooks:['openScienceEngineeringAdventure74M','openInventionsEngineeringMaster74R','openAerospaceEngineering74S','openNatureHealthDeepAdventure','openWeatherStormLab74U','openAnimalKingdom74V']},
    history:{icon:'🗺️', title:'History and World Wing', key:'history', note:'Egypt, England, Shipwreck Cove, Wild West, Great Depression, Geography, Civics, and Economics live here.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'history', hooks:['openAncientEgyptCourse','openEnglandKingsQueens74Q','openShipwreckCoveDeepCourse','openWildWestCourse','openGreatDepressionCourse','openHistoryWorldSupportAdventure74P']},
    bible:{icon:'✝️', title:'Bible Road', key:'bible', note:'Bible History stays separate, respectful, and artifact-rich.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'bible', hooks:['openBibleHistoryCourse','openBibleHistoryTrail','openBibleHistoryArtifacts']},
    creative:{icon:'🎨', title:'Creative Quarter', key:'creative', note:'Art, music, theater, storytelling, crafting, and design stay in the maker quarter.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'creative', hooks:['openCreativeQuarterAdventure74O','openCreativeStudioCourse']},
    homestead:{icon:'🏡', title:'Homestead Workshop', key:'homestead', note:'Life skills, home rooms, storage, animal care, companions, collections, and practical work stay cozy and reachable.', calls:['openRealmLibrary75B','openRealmLibrary75A'], arg:'homestead', hooks:['openHomesteadWorkshopAdventure74O','openLivingWorldLedger74L','openHomeRenderer']},
    living:{icon:'🏮', title:'Living World Ledger', key:'living', note:'Seasons, events, birthdays, shopkeepers, rare rotations, companions, collections, home rewards, and quests are surfaced as town places.', calls:['openLivingWorldLedger74L'], hooks:['openLivingWorldLedger74L','lr74lRoute']}
  };

  var SYSTEMS = [
    {key:'seasons', icon:'🌿', title:'Festival Board', note:'Seasons, rotating event hooks, and active calendar paths.', calls:['openSeasonalCalendar','openSeasonHall','openSeasonQuests'], lr74l:'seasons'},
    {key:'market', icon:'🧺', title:'Seasonal Market', note:'Season vendor tables, discovery hooks, and limited-time finds.', calls:['openSeasonalVendor','openSeasonalSearch','openSeasonHall'], lr74l:'seasonalMarket'},
    {key:'merchants', icon:'🛒', title:'Merchant Row', note:'Shopkeepers, goal items, themed currencies, and shop browsing.', calls:['lr69OpenMerchantSquare','openShop','openShopHub','lrSafeBrowseShopPopup'], lr74l:'merchants'},
    {key:'rare', icon:'✨', title:'Rare Finds Shelf', note:'Rare rotations and surprise stock reached through the merchant street.', calls:['lr69OpenMerchantSquare','openShop','openShopHub'], lr74l:'rare'},
    {key:'companions', icon:'🐾', title:'Companion Den', note:'Pets, companions, companion records, and bond progress.', calls:['openCompanionDen','openPetJournal','openCompanionPopup','openCompanionEngine'], lr74l:'companions'},
    {key:'collections', icon:'🎒', title:'Treasure Registry', note:'Artifacts, badges, decor, museum pieces, and collections.', calls:['openCollectionLog','openBackpack','openInventoryPopup','openAchievementJournal','openCastlePrestige'], lr74l:'collections'},
    {key:'quests', icon:'📜', title:'Quest Board', note:'Daily jobs, story records, long journeys, and quest paths.', calls:['openQuestBoard','openDailyQuestBoard','openQuestJournal','openLongQuestJournal','openStoryQuestJournal'], lr74l:'quests'},
    {key:'home', icon:'🏡', title:'Home Hearth', note:'Home rooms, storage, decor placement, and display systems.', calls:['openHomeRenderer','openHomeViewPopup','openHomeView','openVisibleHome','openHomeRooms','openVisualHome'], lr74l:'home'},
    {key:'birthday', icon:'🎂', title:'Birthday Chest', note:'Birthday and special-day reward paths gathered respectfully with parent rewards.', calls:['openRewardCodeRedeemer','openParentRewardVault','openParentDashboard'], lr74l:'celebration'},
    {key:'events', icon:'🗓️', title:'Town Chronicle', note:'Random events, campaigns, treasure-map style discoveries, and world happenings.', calls:['openEventLog','openStoryCampaigns','openWorldAtlas','openAtlasPopup'], lr74l:'events'}
  ];

  function okList(arr){ return (arr||[]).filter(has).length; }
  function statusText(arr){ var n=okList(arr); return n ? 'ready' : 'safe fallback'; }
  function openUmbrella(key){
    var u=UMBRELLAS[key] || UMBRELLAS.living;
    if(key==='living') return openLivingWorld();
    closePopups();
    if(has('openRealmLibrary75B')) return window.openRealmLibrary75B(u.arg || key);
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(u.arg || key);
    if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker(u.arg || key);
    if(has('openLearningRealmsRealmAtlas74K')) return window.openLearningRealmsRealmAtlas74K();
    if(has('openRealmAtlas')) return window.openRealmAtlas();
    return renderNavigationLedger();
  }
  function openLivingWorld(){
    closePopups();
    if(has('openLivingWorldLedger74L')) return window.openLivingWorldLedger74L();
    if(has('lr74lRoute')) return window.lr74lRoute('ledger');
    return renderLivingFallback();
  }
  function openSystem(key){
    var s=SYSTEMS.filter(function(x){return x.key===key;})[0];
    if(!s) return openLivingWorld();
    closePopups();
    if(s.lr74l && has('lr74lRoute')) return window.lr74lRoute(s.lr74l);
    if(first(s.calls)) return true;
    return popup(s.icon+' '+s.title, '<div class="lr75hPopup"><h3>'+esc(s.title)+'</h3><p>'+esc(s.note)+'</p><p>This doorway is preserved as a safe fallback so the button does not feel dead in this branch.</p><div class="lr75hMiniGrid"><button data-lr75h-act="living">🏮 Town Notice Board</button><button data-lr75h-act="navqa">🧭 Navigation Ledger</button></div></div>');
  }
  function renderLivingFallback(){
    var cards=SYSTEMS.map(function(s){ return systemCard(s); }).join('');
    mount('🏮 Living World Ledger','<div class="lr75hLedger"><section class="lr75hHero"><span class="lr75hHeroIcon">🏮</span><div><h2>Town Notice Board</h2><p>Seasons, festivals, birthdays, shopkeepers, rare finds, companions, collections, home rooms, and quest records are gathered as town places so they do not get buried under lesson roads.</p></div></section><div class="lr75hGrid">'+cards+'</div><div class="lr75hFoot"><button data-lr75h-act="library">🏛️ Realm Library</button><button data-lr75h-act="navqa">🧭 Navigation Ledger</button></div></div>');
  }
  function systemCard(s){ return '<button type="button" class="lr75hCard" data-lr75h-act="system:'+esc(s.key)+'"><span>'+esc(s.icon)+'</span><b>'+esc(s.title)+'</b><small>'+statusText(s.calls)+'</small><p>'+esc(s.note)+'</p></button>'; }
  function umbrellaCard(u){ return '<button type="button" class="lr75hCard" data-lr75h-act="wing:'+esc(u.key)+'"><span>'+esc(u.icon)+'</span><b>'+esc(u.title)+'</b><small>'+statusText(u.hooks||u.calls)+' · umbrella</small><p>'+esc(u.note)+'</p></button>'; }

  function renderNavigationLedger(){
    installStyles();
    var wingCards=Object.keys(UMBRELLAS).map(function(k){ return umbrellaCard(UMBRELLAS[k]); }).join('');
    var systemCards=SYSTEMS.map(systemCard).join('');
    var counts = auditButtonCounts();
    var html='<div class="lr75hLedger">'+
      '<section class="lr75hHero"><span class="lr75hHeroIcon">🧭</span><div><h2>Navigation Ledger</h2><p>This desk checks the big roads and gathers the living-world doors without changing the game shell. It is a safe QA surface: if a system hook is not present, the button opens a useful fallback instead of silently doing nothing.</p><small>Player: '+esc(activeName())+' · 7.5H stability surface</small></div></section>'+
      '<section class="lr75hPanel"><h3>Big places</h3><div class="lr75hGrid">'+wingCards+'</div></section>'+
      '<section class="lr75hPanel"><h3>Living world places</h3><div class="lr75hGrid">'+systemCards+'</div></section>'+
      '<section class="lr75hPanel"><h3>Button QA snapshot</h3><div class="lr75hStatusGrid">'+
        '<div><b>'+counts.buttons+'</b><span>visible buttons seen</span></div>'+
        '<div><b>'+counts.patched+'</b><span>plain buttons given safe labels</span></div>'+
        '<div><b>'+counts.hooks+'</b><span>major route hooks detected</span></div>'+
        '<div><b>'+counts.fallbacks+'</b><span>living-world fallbacks protected</span></div>'+
      '</div><p class="lr75hNote">A fallback is not a failure. It means the doorway will show a safe in-world note rather than acting broken while older game systems are still settling.</p></section>'+
      '<div class="lr75hFoot"><button data-lr75h-act="library">🏛️ Realm Library</button><button data-lr75h-act="living">🏮 Town Notice Board</button><button data-lr75h-act="home">🏡 Home Hearth</button><button data-lr75h-act="scene">↩ Scene</button></div>'+
      '</div>';
    mount('🧭 Navigation Ledger', html);
  }

  function auditButtonCounts(){
    var buttons=qa('button').filter(function(b){ return !!(b.offsetWidth||b.offsetHeight||b.getClientRects().length); });
    var patched=buttons.filter(function(b){ return b.getAttribute('data-lr75h-patched')==='1'; }).length;
    var hookNames=[];
    Object.keys(UMBRELLAS).forEach(function(k){ hookNames=hookNames.concat(UMBRELLAS[k].hooks||UMBRELLAS[k].calls||[]); });
    SYSTEMS.forEach(function(s){ hookNames=hookNames.concat(s.calls||[]); });
    var hooks={}; hookNames.forEach(function(n){ if(has(n)) hooks[n]=true; });
    var fallbacks=SYSTEMS.filter(function(s){ return !okList(s.calls); }).length;
    return {buttons:buttons.length, patched:patched, hooks:Object.keys(hooks).length, fallbacks:fallbacks};
  }

  var LABEL_ROUTES = [
    [/^(go learn|realm library|all wings|back to realm library)$/i, 'library'],
    [/^(navigation ledger|route check|qa ledger|button audit)$/i, 'navqa'],
    [/^(town notice board|living world ledger|living world|notice board)$/i, 'living'],
    [/^(festival board|seasonal calendar|seasons)$/i, 'system:seasons'],
    [/^(seasonal market|festival market)$/i, 'system:market'],
    [/^(merchant row|shops|shopkeepers|market street)$/i, 'system:merchants'],
    [/^(rare finds shelf|rare finds|rare rotations)$/i, 'system:rare'],
    [/^(companion den|companions|pets)$/i, 'system:companions'],
    [/^(treasure registry|collection log|collections|inventory)$/i, 'system:collections'],
    [/^(quest board|quests|daily quests)$/i, 'system:quests'],
    [/^(home hearth|home|homestead)$/i, 'home'],
    [/^(birthday chest|special day chest|birthday rewards)$/i, 'system:birthday'],
    [/^(town chronicle|event log|events)$/i, 'system:events'],
    [/^(core halls)$/i, 'wing:core'],
    [/^(history and world wing|history wing)$/i, 'wing:history'],
    [/^(science and engineering quarter|science quarter)$/i, 'wing:science'],
    [/^(bible road)$/i, 'wing:bible'],
    [/^(creative quarter)$/i, 'wing:creative'],
    [/^(homestead workshop)$/i, 'wing:homestead'],
    [/^(scene|return to scene)$/i, 'scene']
  ];
  function routeForLabel(text){
    text=String(text||'').replace(/\s+/g,' ').trim();
    text=text.replace(/[›»]+$/,'').trim();
    for(var i=0;i<LABEL_ROUTES.length;i++){ if(LABEL_ROUTES[i][0].test(text)) return LABEL_ROUTES[i][1]; }
    return null;
  }
  function hasActionAttrs(btn){
    if(!btn) return true;
    if(btn.getAttribute('onclick')) return true;
    if(btn.closest && btn.closest('[data-lr75h-act]')) return true;
    var attrs=btn.attributes||[];
    for(var i=0;i<attrs.length;i++) if(/^data-lr/i.test(attrs[i].name) && attrs[i].name!=='data-lr75h-patched') return true;
    return false;
  }
  function scanButtons(){
    qa('button').forEach(function(btn){
      if(!btn || btn.getAttribute('data-lr75h-act')) return;
      var txt=(btn.textContent||'').replace(/\s+/g,' ').trim();
      var act=routeForLabel(txt);
      if(!act) return;
      if(hasActionAttrs(btn)) return;
      btn.setAttribute('data-lr75h-act', act);
      btn.setAttribute('data-lr75h-patched','1');
      btn.classList.add('lr75hPatchedButton');
    });
  }

  function handleAction(act){
    act=String(act||'navqa');
    if(act==='navqa') return renderNavigationLedger();
    if(act==='living') return openLivingWorld();
    if(act==='library') return openUmbrella('all') || (has('openRealmLibrary75A')?window.openRealmLibrary75A('all'):renderNavigationLedger());
    if(act.indexOf('wing:')===0) return openUmbrella(act.slice(5));
    if(act.indexOf('system:')===0) return openSystem(act.slice(7));
    if(act==='home') return openSystem('home');
    if(act==='scene') return first([['lr74xRoute','scene'],['lr73mDo','scene'],['renderRoom']]) || renderNavigationLedger();
    return renderNavigationLedger();
  }

  function surfaceLivingWorld(){
    installStyles();
    var roots=[];
    var ax=byId('actionText'); if(ax) roots.push(ax);
    var popupBody=byId('lrPopupBody'); if(popupBody) roots.push(popupBody);
    qa('.lr75aLibrary, .lr74kRealm').forEach(function(r){ roots.push(r); });
    roots.forEach(function(root){
      if(!root || root.getAttribute('data-lr75h-surfaced')==='1') return;
      var txt=(root.textContent||'').slice(0,5000);
      var isLibrary=/Realm Library|Core Halls|History and World|Science and Engineering|Bible Road|Creative Quarter|Homestead Workshop/i.test(txt) || (root.className&&/lr75aLibrary|lr74kRealm/.test(String(root.className)));
      if(!isLibrary) return;
      root.setAttribute('data-lr75h-surfaced','1');
      var band=document.createElement('div');
      band.className='lr75hSurfaceBand';
      band.innerHTML='<div class="lr75hSurfaceTitle"><b>🏮 Living world doors</b><span>seasons · shops · companions · quests · home</span></div><div class="lr75hSurfaceBtns">'+
        '<button data-lr75h-act="navqa">🧭 Navigation Ledger</button>'+
        '<button data-lr75h-act="living">🏮 Town Notice Board</button>'+
        '<button data-lr75h-act="system:merchants">🛒 Merchant Row</button>'+
        '<button data-lr75h-act="system:rare">✨ Rare Finds</button>'+
        '<button data-lr75h-act="system:companions">🐾 Companions</button>'+
        '<button data-lr75h-act="system:collections">🎒 Collections</button>'+
        '<button data-lr75h-act="system:quests">📜 Quests</button>'+
      '</div>';
      var hero=q('.lr75aHero,.lr74kHero,h1,h2',root);
      try{
        if(hero && hero.parentNode===root && hero.nextSibling) root.insertBefore(band, hero.nextSibling);
        else if(root.firstChild) root.insertBefore(band, root.firstChild);
        else root.appendChild(band);
      }catch(e){ try{ root.appendChild(band); }catch(_){} }
    });
  }

  function wrapOpeners(){
    if(window.__LR75H_WRAPPED_OPENERS__) return;
    window.__LR75H_WRAPPED_OPENERS__=true;
    ['openRealmLibrary75A','openRealmLibrary75B','openRealCurriculumPicker','openLearningRealmsRealmAtlas74K','openLivingWorldLedger74L','lrOpenPopup','lrOpenActionPopup'].forEach(function(name){
      if(typeof window[name] !== 'function') return;
      var old=window[name];
      if(old.__lr75hWrapped) return;
      var wrapped=function(){ var out=old.apply(this,arguments); setTimeout(scanButtons,40); setTimeout(surfaceLivingWorld,80); setTimeout(scanButtons,180); return out; };
      wrapped.__lr75hWrapped=true;
      window[name]=wrapped;
      try{ eval(name+' = window["'+name+'"]'); }catch(e){}
    });
  }
  function bind(){
    if(window.__LR75H_BOUND__) return;
    window.__LR75H_BOUND__=true;
    window.addEventListener('click', function(ev){
      var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr75h-act]') : null;
      if(!el) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAction(el.getAttribute('data-lr75h-act'));
      setTimeout(scanButtons,60); setTimeout(surfaceLivingWorld,120);
    }, true);
  }
  function installMenuOption(){
    var sel=byId('gameMenuSelect');
    if(!sel || q('option[value="navigationLedger75H"]',sel)) return;
    var opt=document.createElement('option'); opt.value='navigationLedger75H'; opt.textContent='Navigation Ledger';
    sel.appendChild(opt);
    if(!sel.__lr75hWrapped){
      sel.__lr75hWrapped=true;
      sel.addEventListener('change',function(){ if(sel.value==='navigationLedger75H'){ renderNavigationLedger(); sel.value=''; } });
    }
  }
  function installTopShortcut(){
    // In-world, not floating: add one command/action button only if an action area exists and no shortcut is present.
    var box=byId('leftActionButtons') || q('.actionButtons');
    if(!box || q('[data-lr75h-act="navqa"]',box)) return;
    var b=document.createElement('button'); b.type='button'; b.className='lr75hCommandShortcut'; b.setAttribute('data-lr75h-act','navqa'); b.textContent='🧭 Navigation Ledger';
    try{ box.appendChild(b); }catch(e){}
  }
  function installStyles(){
    if(byId('lr75hStyles')) return;
    var st=document.createElement('style'); st.id='lr75hStyles';
    st.textContent = `
      .lr75hLedger{display:grid;gap:14px;color:#f7ecd0;max-width:1160px;margin:0 auto;}
      .lr75hHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;border:1px solid rgba(244,209,134,.36);border-radius:18px;background:linear-gradient(135deg,rgba(15,45,42,.95),rgba(74,44,18,.90));box-shadow:0 14px 34px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.08)}
      .lr75hHeroIcon{width:58px;height:58px;border-radius:18px;display:grid;place-items:center;background:rgba(255,238,184,.13);border:1px solid rgba(255,232,166,.35);font-size:2rem;}
      .lr75hHero h2{margin:0 0 6px;color:#fff4c7;text-shadow:0 2px 0 rgba(0,0,0,.35)}.lr75hHero p{margin:0;color:#e8d8b9;line-height:1.5}.lr75hHero small{display:block;margin-top:8px;color:#aee8d0;font-weight:900;letter-spacing:.04em;text-transform:uppercase;}
      .lr75hPanel{padding:14px;border:1px solid rgba(244,209,134,.25);border-radius:16px;background:rgba(0,0,0,.20);}.lr75hPanel h3{margin:0 0 10px;color:#ffe7a7;}
      .lr75hGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:11px;}.lr75hCard{cursor:pointer;text-align:left;display:grid;grid-template-columns:auto 1fr;grid-template-areas:'ic title' 'ic stat' 'ic body';gap:2px 10px;align-items:start;border:1px solid rgba(244,209,134,.30)!important;border-radius:16px!important;background:linear-gradient(145deg,rgba(14,31,31,.95),rgba(48,31,18,.93))!important;color:#f7ecd0!important;padding:13px!important;box-shadow:0 8px 22px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.06);}
      .lr75hCard:hover{border-color:rgba(255,230,153,.65)!important;transform:translateY(-1px);}.lr75hCard span{grid-area:ic;width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:rgba(255,238,184,.12);border:1px solid rgba(255,232,166,.25);font-size:1.45rem;}.lr75hCard b{grid-area:title;color:#fff1bd;font-size:1rem;}.lr75hCard small{grid-area:stat;color:#aee8d0;font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;font-weight:950;}.lr75hCard p{grid-area:body;margin:4px 0 0;color:#dcccae;line-height:1.38;font-size:.9rem;}
      .lr75hStatusGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;}.lr75hStatusGrid div{border:1px solid rgba(244,209,134,.22);border-radius:14px;padding:12px;background:rgba(0,0,0,.18)}.lr75hStatusGrid b{display:block;color:#fff1bd;font-size:1.4rem}.lr75hStatusGrid span{color:#d8c9ab;font-size:.84rem}.lr75hNote{margin:10px 0 0;color:#d8c9ab;line-height:1.4}.lr75hFoot,.lr75hMiniGrid{display:flex;flex-wrap:wrap;gap:9px;padding:12px;border:1px solid rgba(244,209,134,.22);border-radius:14px;background:rgba(0,0,0,.18)}.lr75hFoot button,.lr75hMiniGrid button,.lr75hSurfaceBand button,.lr75hCommandShortcut,.lr75hPatchedButton{border:1px solid rgba(255,232,166,.38)!important;border-radius:999px!important;background:rgba(255,232,166,.14)!important;color:#fff3cf!important;font-weight:950!important;padding:9px 12px!important;cursor:pointer!important;}
      .lr75hSurfaceBand{margin:12px 0;padding:12px;border:1px solid rgba(244,209,134,.28);border-radius:16px;background:linear-gradient(135deg,rgba(9,32,30,.88),rgba(54,35,19,.82));box-shadow:0 8px 22px rgba(0,0,0,.20);}.lr75hSurfaceTitle{display:flex;flex-wrap:wrap;gap:8px;align-items:baseline;margin-bottom:8px}.lr75hSurfaceTitle b{color:#ffe7a7}.lr75hSurfaceTitle span{color:#aee8d0;font-size:.82rem;font-weight:850;text-transform:uppercase;letter-spacing:.04em}.lr75hSurfaceBtns{display:flex;flex-wrap:wrap;gap:8px}.lr75hPopup{color:#2a1c08}.lr75hPopup p{line-height:1.5}.lr75hCommandShortcut{width:100%;border-radius:12px!important;margin-top:8px!important;background:linear-gradient(180deg,#fff0b8,#d3a046)!important;color:#211305!important;}.lr75hPatchedButton{outline:1px solid rgba(174,232,208,.35)!important;}
      @media(max-width:820px){.lr75hHero{grid-template-columns:1fr}.lr75hGrid{grid-template-columns:1fr}.lr75hSurfaceTitle{display:block}}
    `;
    document.head.appendChild(st);
  }
  function boot(){
    installStyles(); bind(); wrapOpeners(); installMenuOption(); installTopShortcut(); scanButtons(); surfaceLivingWorld();
    setTimeout(function(){ installMenuOption(); installTopShortcut(); scanButtons(); surfaceLivingWorld(); },250);
    setTimeout(function(){ scanButtons(); surfaceLivingWorld(); },900);
    setTimeout(function(){ scanButtons(); surfaceLivingWorld(); },2200);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,180); });

  window.openNavigationLedger75H = renderNavigationLedger;
  window.openLivingWorldSurface75H = openLivingWorld;
  window.lr75hRoute = handleAction;
})();
