/* LearningRealms 7.5J - Sidebar containment + route audit
   Built on 7.5I. Conservative UI/function patch only.
   Fixes seen in screenshot:
   - left Player Sheet stat text spilling outside the panel
   - old icon/sidebar/header buttons using stale data-lr73m routes
   - generic course control buttons such as Artifact Shelf / Road Map bouncing or doing nothing
   No lesson rewrite, no shell rewrite, no render loop, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR75J_SIDEBAR_ROUTE_AUDIT__) return;
  window.__LR75J_SIDEBAR_ROUTE_AUDIT__ = true;
  function byId(id){return document.getElementById(id)}
  function has(fn){return typeof window[fn]==='function'}
  function qa(sel,root){try{return Array.prototype.slice.call((root||document).querySelectorAll(sel))}catch(e){return[]}}
  function q(sel,root){try{return (root||document).querySelector(sel)}catch(e){return null}}
  function norm(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'')}
  function text(root){return String((root||document.body).textContent||'').replace(/\s+/g,' ').trim()}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;')}
  function closePopups(){try{if(has('lrClosePopup'))window.lrClosePopup()}catch(e){} try{var r=byId('lrPopupRoot'); if(r)r.classList.add('hidden')}catch(e){}}
  function call(fn){var args=Array.prototype.slice.call(arguments,1); if(!has(fn))return false; try{window[fn].apply(window,args); return true}catch(e){console.warn('LR75J route failed',fn,e); return false}}
  function first(list){for(var i=0;i<list.length;i++){var x=list[i]; if(Array.isArray(x)){if(call.apply(null,x))return true}else if(call(x))return true}return false}
  function openLibrary(wing){closePopups(); if(has('openRealmLibrary75B')) return window.openRealmLibrary75B(wing||'all'); if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(wing||'all'); if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker(wing||'all'); return note('Realm Library','The library door is present, but the route hook did not answer.')}
  function note(title,body){installStyles(); var html='<div class="lr75jNotice"><h3>'+esc(title||'Doorway')+'</h3><p>'+esc(body||'This button is protected instead of silently doing nothing.')+'</p><div><button data-lr75j-route="library">🏛️ Realm Library</button><button data-lr75j-route="scene">↩ Scene</button></div></div>'; if(has('lrOpenPopup')){try{window.lrOpenPopup(title||'Doorway',html); return true}catch(e){}} var ax=byId('actionText'); if(ax){ax.innerHTML=html; return true} return false}
  function clickButton(selector){var b=q(selector); if(b){try{b.click(); return true}catch(e){}} return false}
  function screenKey(){var t=text();
    if(/England: Kings and Queens|Royal Shelf|Anglo-Saxon|William the Conqueror/i.test(t)) return 'england';
    if(/Ancient Egypt Royal|Royal Gallery|Narmer|Djoser|Ramesses|Cleopatra VII/i.test(t)) return 'egyptroyal';
    if(/Ancient Egypt World|Nile boats|Karnak|Rosetta Stone|Tutankhamun/i.test(t)) return 'egyptworld';
    if(/Ancient Egypt Expedition|Egypt Road|Great Pyramid|Sphinx/i.test(t)) return 'egypt';
    if(/Shipwreck Cove|Harbor|Lighthouse|Wreck Gallery/i.test(t)) return 'shipwreck';
    if(/Bible History|Pilgrim Road|Sacraments|Apostles|Mary/i.test(t)) return 'bible';
    if(/Wild West|Frontier|Longhorn|Homestead Claim/i.test(t)) return 'wildwest';
    if(/Great Depression|Dust Bowl|bank holiday|New Deal/i.test(t)) return 'depression';
    if(/Aerospace|Mission Wing|Rocket|Wind tunnel/i.test(t)) return 'aerospace';
    if(/Inventions|Engineering Disasters|Blueprint|Rebuild/i.test(t)) return 'inventions';
    if(/Weather|Storm Lab|Forecast|Cloud/i.test(t)) return 'weather';
    if(/Animal Kingdom|Creature Field|Ranger/i.test(t)) return 'animals';
    if(/Nature & Health|Field Journal|Health Lodge/i.test(t)) return 'nature';
    if(/Writing Composition|Ink Tower|Story Forge/i.test(t)) return 'writing';
    if(/Reading Comprehension|Lantern Library/i.test(t)) return 'reading';
    if(/Math Adventure|Number Vault/i.test(t)) return 'math';
    if(/Logic Tower|Critical Thinking|Puzzle Spire/i.test(t)) return 'logic';
    if(/Grammar, Vocabulary|Language Forge|Word Forge/i.test(t)) return 'grammar';
    return '';
  }
  function routeArtifact(){var k=screenKey(); closePopups();
    if(k==='england') return clickButton('[data-lr74q-act="rewards"]') || (first([['openEnglandKingsQueens74Q']]) && setTimeout(function(){clickButton('[data-lr74q-act="rewards"]')},80), true);
    if(k==='egyptroyal') return first([['openAncientEgyptRoyalArtifacts'],['openAncientEgyptArtifacts']]) || route('egyptroyal');
    if(k==='egyptworld') return first([['openAncientEgyptWorldArtifacts'],['openAncientEgyptArtifacts']]) || route('egyptworld');
    if(k==='egypt') return first([['openAncientEgyptArtifacts'],['openAncientEgyptWorldArtifacts'],['openAncientEgyptRoyalArtifacts']]) || route('egypt');
    if(k==='shipwreck') return first([['openShipwreckCoveRewardCatalog']]) || route('shipwreck');
    if(k==='bible') return first([['openBibleHistoryArtifacts73B'],['openBibleHistoryArtifacts'],['openBibleHistoryRewards']]) || route('bible');
    if(k==='wildwest') return first([['openWildWestRewards']]) || route('wildwest');
    if(k==='depression') return first([['openGreatDepressionRewards']]) || route('depression');
    if(k==='aerospace') return clickButton('[data-lr74s-act="rewards"]') || route('aerospace');
    if(k==='inventions') return first([['openInventionsRewardCatalog']]) || route('inventions');
    if(k==='weather') return first([['openWeatherArtifactShelf']]) || route('weather');
    if(k==='animals') return first([['openCreatureBadgeShelf']]) || route('animals');
    if(k==='nature') return first([['openNatureHealthRewardShelf']]) || route('nature');
    if(k==='writing') return first([['openWritingArtifactShelf']]) || route('writing');
    if(k==='reading') return first([['openReadingArtifactShelf75C']]) || route('reading');
    if(k==='math') return first([['openMathArtifactShelf75D']]) || route('math');
    if(k==='logic') return first([['openLogicArtifactShelf75E']]) || route('logic');
    if(k==='grammar') return first([['openLanguageArtifactShelf75F']]) || route('grammar');
    return note('Artifact Shelf','Open a course road first, then use its shelf. I kept this button from going nowhere.');
  }
  function routeMap(){var k=screenKey(); if(k) return route(k); return openLibrary('all')}
  function routeParent(){var k=screenKey(); if(/egypt|england|shipwreck|wildwest|depression|geography|civics|economics/.test(k)) return openLibrary('history'); if(/aerospace|inventions|weather|animals|nature/.test(k)) return openLibrary('science'); if(/reading|writing|math|logic|grammar/.test(k)) return openLibrary('core'); if(k==='bible') return openLibrary('bible'); return openLibrary('all')}

  var actMap={
    map:'library', learn:'library', golearn:'library', featuredtrails:'library', realmmap:'library', realmatlas:'library', worldatlas:'library', library:'library', atlas:'library',
    historytrails:'history', historywing:'history', history:'history', corehalls:'core', core:'core', sciencequarter:'science', science:'science', bibleroad:'bible', bible:'bible', creativequarter:'creative', creative:'creative', homesteadworkshop:'homestead', homestead:'homestead',
    items:'collections', item:'collections', pets:'companions', pet:'companions', quests:'quests', quest:'quests', bibleartifacts:'artifact', artifacts:'artifact', artifactshelf:'artifact', rewards:'artifact', rewardshelf:'artifact', roadmap:'roadmap', parentwing:'parent', returntoparentwing:'parent', scene:'scene', home:'home'
  };
  function route(raw){var key=norm(actMap[norm(raw)] || raw);
    if(key==='library') return openLibrary('all');
    if(key==='core') return openLibrary('core');
    if(key==='science') return openLibrary('science');
    if(key==='history') return openLibrary('history');
    if(key==='bible') return openLibrary('bible');
    if(key==='creative') return openLibrary('creative');
    if(key==='homestead') return openLibrary('homestead');
    if(key==='scene') {closePopups(); return first([['renderRoom'],['lr68Render']]) || note('Scene','The scene route did not answer.');}
    if(key==='home') {closePopups(); return first([['openHomeRenderer'],['openHomeViewPopup'],['openHomeView'],['openVisibleHome'],['openHomeRooms'],['lr75hRoute','home']]) || openLibrary('homestead');}
    if(key==='roadmap') return routeMap();
    if(key==='parent') return routeParent();
    if(key==='artifact') return routeArtifact();
    if(key==='egypt') return first([['openAncientEgyptCourse'],['openAncientEgyptTrail'],['openLearningRealmsEgyptRoad'],['openLearningRealmsEgypt']]) || openLibrary('history');
    if(key==='egyptroyal') return first([['openAncientEgyptRoyalGallery'],['openAncientEgyptRoyalCourse']]) || route('egypt');
    if(key==='egyptworld') return first([['openAncientEgyptWorldExpansion'],['openAncientEgyptWorldCourse']]) || route('egypt');
    if(key==='england'||key==='kingsqueens') return first([['openEnglandKingsQueens74Q'],['openEnglandKingsQueensRoad74Q']]) || openLibrary('history');
    if(key==='depression'||key==='greatdepression') return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || openLibrary('history');
    if(key==='wildwest') return first([['openWildWestTrail'],['openWildWestCourse']]) || openLibrary('history');
    if(key==='shipwreck'||key==='shipwreckcove') return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveMap'],['openShipwreckCoveDeepCourse']]) || openLibrary('history');
    if(key==='geography') return first([['openMapmakersLoft74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history');
    if(key==='civics') return first([['openCivicHall74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history');
    if(key==='economics') return first([['openMarketSquare74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history');
    if(key==='scienceexpedition') return first([['openScienceEngineeringAdventure74M'],['openScienceEngineeringQuarter74M']]) || openLibrary('science');
    if(key==='inventions'||key==='engineering') return first([['openInventionsEngineeringMaster74R'],['openInventionsEngineeringDisasters74R'],['openInventionsDeepCourse']]) || openLibrary('science');
    if(key==='aerospace') return first([['openAerospaceEngineering74S'],['openAerospaceMissionWing74S'],['openAerospaceEngineering']]) || openLibrary('science');
    if(key==='nature'||key==='naturehealth') return first([['openNatureHealthDeepAdventure'],['openNatureHealth74T'],['openNatureAndHealth']]) || openLibrary('science');
    if(key==='weather') return first([['openWeatherStormLab74U'],['openWeatherStormLab'],['openWeatherStation']]) || openLibrary('science');
    if(key==='animals'||key==='animal'||key==='creatures') return first([['openAnimalKingdom74V'],['openAnimalKingdom'],['openCreatureFieldGuide']]) || openLibrary('science');
    if(key==='reading') return first([['openReadingComprehensionMasterCourse75C'],['openReadingComprehensionMasterCourse']]) || openLibrary('core');
    if(key==='writing') return first([['openWritingCompositionMasterCourse'],['openWritingCompositionMaster74W']]) || openLibrary('core');
    if(key==='math') return first([['openMathAdventureMasterCourse75D'],['openMathAdventureMasterCourse']]) || openLibrary('core');
    if(key==='logic') return first([['openLogicTowerCriticalThinking75E'],['openLogicTowerMasterCourse']]) || openLibrary('core');
    if(key==='grammar'||key==='vocabulary'||key==='languageforge') return first([['openGrammarVocabularyLanguageForge75F'],['openGrammarMasterCourse']]) || openLibrary('core');
    if(key==='living'||key==='townnotice') return first([['openLivingWorldLedger74L'],['lr75hRoute','living']]) || note('Town Notice Board','The town system did not answer.');
    if(key==='merchants'||key==='shops') return first([['lr74lRoute','merchants'],['lr75hRoute','system:merchants'],['openShopHub'],['lr69OpenMerchantSquare']]) || route('living');
    if(key==='rare') return first([['lr74lRoute','rare'],['lr75hRoute','system:rare'],['openShopHub']]) || route('merchants');
    if(key==='collections') return first([['openCollectionLog'],['openInventoryPopup'],['openAchievementJournal'],['lr75hRoute','system:collections']]) || route('living');
    if(key==='companions') return first([['openCompanionDen'],['openCompanionPopup'],['openPetJournal'],['lr75hRoute','system:companions']]) || route('living');
    if(key==='quests') return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openStoryQuestJournal'],['lr75hRoute','system:quests']]) || route('living');
    if(key==='seasons'||key==='festivalboard') return first([['openSeasonHall'],['openSeasonalCalendar'],['openSeasonQuests'],['lr75hRoute','system:seasons']]) || route('living');
    if(key==='events'||key==='eventlog'||key==='townchronicle') return first([['openEventLog'],['openStoryCampaigns'],['lr75hRoute','system:events']]) || route('living');
    return openLibrary('all');
  }
  window.lr75jRoute=route;

  function labelRoute(txt){txt=String(txt||'').replace(/\s+/g,' ').trim().replace(/[›»]+$/,'').trim();
    var pairs=[[/^Realm Library$/i,'library'],[/^Realm Atlas$/i,'library'],[/^Go Learn$/i,'library'],[/^Road Map$/i,'roadmap'],[/^Artifact Shelf$/i,'artifact'],[/^Treasure Shelf$/i,'artifact'],[/^Reward Shelf$/i,'artifact'],[/^Review Shelf$/i,'review'],[/^Parent Wing$/i,'parent'],[/^Return to Parent Wing$/i,'parent'],[/^History Wing$/i,'history'],[/^History and World Wing$/i,'history'],[/^Bible Road$/i,'bible'],[/^Egypt Road$/i,'egypt'],[/^Ancient Egypt/i,'egypt'],[/^England: Kings and Queens/i,'england'],[/^Kings and Queens/i,'england'],[/^Great Depression/i,'depression'],[/^Wild West/i,'wildwest'],[/^Shipwreck Cove/i,'shipwreck'],[/^Core Halls$/i,'core'],[/^Science and Engineering Quarter$/i,'science'],[/^Science Quarter$/i,'science'],[/^Creative Quarter$/i,'creative'],[/^Homestead Workshop$/i,'homestead'],[/^Home$/i,'home'],[/^Scene$/i,'scene'],[/^Items$/i,'collections'],[/^Collections$/i,'collections'],[/^Quests$/i,'quests'],[/^Companion Den$/i,'companions'],[/^Pets$/i,'companions']];
    for(var i=0;i<pairs.length;i++) if(pairs[i][0].test(txt)) return pairs[i][1]; return '';
  }
  function bindButton(btn,key){if(!btn||!key)return; btn.setAttribute('data-lr75j-route',key); btn.classList.add('lr75jRouted'); try{btn.onclick=null}catch(e){} }
  function scan(root){root=root||document;
    // Fix old navigation attrs so they do not fall back to stale 7.3 routes.
    qa('[data-lr73m-act],[data-lr73p-act]',root).forEach(function(el){var k=el.getAttribute('data-lr73m-act')||el.getAttribute('data-lr73p-act'); if(k) bindButton(el,k)});
    // Only override obvious navigation buttons by visible label. Do not touch deep topic/challenge buttons.
    qa('button',root).forEach(function(b){
      if(!b||b.disabled) return;
      if(b.closest('[class*="Topic"],[class*="Question"],[class*="Choices"]')) return;
      var k=labelRoute(b.textContent||b.getAttribute('title')||b.getAttribute('aria-label')||'');
      if(k) bindButton(b,k);
    });
  }
  function installStyles(){if(byId('lr75jStyles'))return; var st=document.createElement('style'); st.id='lr75jStyles'; st.textContent=`
    body.lr73mStable .shell{width:min(1880px,98vw)!important;max-width:1880px!important;}
    @media(min-width:1050px){body.lr73mStable .shell>main{grid-template-columns:minmax(310px,335px) minmax(0,1fr) minmax(300px,340px)!important;gap:16px!important;}}
    body.lr73mStable .playerSidebar,body.lr73mStable .actionSidebar{min-width:0!important;overflow:hidden!important;contain:layout paint;}
    body.lr73mStable .lr73mPlayerDeck,body.lr73mStable .lr73mPlayerDeck *,body.lr73mStable #leftActionButtons,body.lr73mStable #leftActionButtons *{box-sizing:border-box!important;min-width:0!important;max-width:100%;}
    body.lr73mStable .lr73mPlayerHero{grid-template-columns:50px minmax(0,1fr)!important;}
    body.lr73mStable .lr73mPlayerHero small{display:block!important;max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important;line-height:1.16!important;}
    body.lr73mStable .lr73mIconStats{grid-template-columns:1fr 1fr!important;gap:6px!important;width:100%!important;}
    body.lr73mStable .lr73mIconStat{grid-template-columns:22px minmax(0,1fr)!important;padding:5px 6px!important;overflow:hidden!important;width:100%!important;}
    body.lr73mStable .lr73mIconStat>div{min-width:0!important;overflow:hidden!important;}
    body.lr73mStable .lr73mIconStat b{display:block!important;max-width:100%!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;font-size:.78rem!important;}
    body.lr73mStable .lr73mIconStat small{display:block!important;max-width:100%!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;font-size:.58rem!important;letter-spacing:.02em!important;}
    body.lr73mStable .lr73mIconRack{grid-template-columns:repeat(4,minmax(0,1fr))!important;width:100%!important;}
    body.lr73mStable .lr73mIconRack button{width:100%!important;min-width:0!important;overflow:hidden!important;text-align:center!important;padding:0!important;}
    body.lr73mStable #leftActionButtons{display:grid!important;grid-template-columns:1fr!important;gap:7px!important;width:100%!important;}
    body.lr73mStable #leftActionButtons button,body.lr73mStable .lr73mCommandBtn{width:100%!important;min-width:0!important;max-width:100%!important;display:grid!important;grid-template-columns:24px minmax(0,1fr)!important;align-items:center!important;text-align:left!important;overflow:hidden!important;padding:8px 9px!important;}
    body.lr73mStable .lr73mCommandBtn b,body.lr73mStable #leftActionButtons button b{min-width:0!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}
    body.lr73mStable .playerSidebar .stats{display:grid!important;grid-template-columns:1fr!important;gap:7px!important;}
    body.lr73mStable .playerSidebar .stats div{min-width:0!important;overflow:hidden!important;}
    body.lr73mStable .playerSidebar .stats span{display:block!important;max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;}
    .lr75jRouted{outline:1px solid rgba(174,232,208,.14)!important;}
    .lr75jNotice{padding:14px;border:1px solid rgba(244,209,134,.28);border-radius:16px;background:rgba(18,32,29,.94);color:#f7ecd0}.lr75jNotice h3{color:#ffe6a7;margin-top:0}.lr75jNotice div{display:flex;gap:8px;flex-wrap:wrap}.lr75jNotice button{width:auto!important;text-align:center!important;}
    @media(max-width:1250px){body.lr73mStable .shell>main{grid-template-columns:minmax(280px,310px) minmax(0,1fr) minmax(260px,300px)!important;}body.lr73mStable #leftActionButtons button,body.lr73mStable .lr73mCommandBtn{font-size:.86rem!important;}}
    @media(max-width:980px){body.lr73mStable .shell>main{display:block!important}.playerSidebar,.actionSidebar,.rightSidebar{contain:none!important;max-width:none!important;width:auto!important;}}
  `; document.head.appendChild(st)}
  function wrap(){
    // Replace the older 7.3M router with the current 7.5J route map while preserving the same data attributes.
    window.lr73mDo=function(act){return route(act)}; try{lr73mDo=window.lr73mDo}catch(e){}
    // Safe aliases for generic course-polish buttons that were calling guessed names.
    window.openEnglandKingsQueensShelf74Q = window.openEnglandRoyalShelf74Q = window.openEnglandKingsQueensArtifacts74Q = function(){return route('artifact')};
  }
  function boot(){installStyles(); wrap(); scan(document); setTimeout(function(){installStyles(); wrap(); scan(document)},100); setTimeout(function(){scan(document)},450)}
  document.addEventListener('click',function(ev){var el=ev.target&&ev.target.closest?ev.target.closest('[data-lr75j-route]'):null; if(!el)return; ev.preventDefault(); /* 7.6W: do not swallow normal clicks */ route(el.getAttribute('data-lr75j-route')); setTimeout(function(){scan(document)},80)},true);
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
  window.addEventListener('load',function(){setTimeout(boot,120)});
})();
