/* LearningRealms 7.5S - Creative Quarter Connection Cleanup
   Small bridge patch only. No shell rebuild, no render loop, no loading curtain.
   Purpose: gather the Creative Quarter roads, Creative Studio Specialists, art/music world routes,
   and older creative drawers into one safe in-world map. */
(function(){
  'use strict';

  if(window.__LR75S_CREATIVE_QUARTER_CLEANUP__) return;
  window.__LR75S_CREATIVE_QUARTER_CLEANUP__ = true;

  var PATCH = '7.5S Creative Quarter Connection Cleanup';
  var injectTimer = null;
  var obsInstalled = false;

  function $(id){ return document.getElementById(id); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }
  function smallText(v, max){
    var s = String(v || '').replace(/\s+/g, ' ').trim();
    if(!max || s.length <= max) return s;
    return s.slice(0, max - 1).trim() + '…';
  }
  function callFirst(names){
    for(var i=0;i<names.length;i++){
      var fn = names[i];
      if(has(fn)){
        try{
          window[fn]();
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }catch(e){ console.warn('LR75S route failed:', fn, e); }
      }
    }
    return false;
  }
  function actionMount(title, html){
    installStyles();
    var titleEl = $('actionTitle');
    var textEl = $('actionText');
    if(titleEl) titleEl.textContent = title || 'Creative Quarter';
    if(textEl) textEl.innerHTML = html || '';
    try{
      if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title || 'Creative Quarter');
      else if(has('lrOpenPopup')) window.lrOpenPopup(title || 'Creative Quarter', html || '');
    }catch(e){}
    scheduleInject();
  }

  var ROADS = [
    {
      key:'quarter', icon:'🎨', title:'Creative Quarter Adventure', place:'Maker Street and Studio Rooms',
      body:'The main creative road for drawing, color, watercolor, sculpture, pattern, design, music, theater, puppets, story making, and gallery habits.',
      openers:['openCreativeQuarterAdventure74O','openCreativeHomesteadAdventure74O']
    },
    {
      key:'studio', icon:'🧰', title:'Creative Studio Specialists', place:'Studio Specialist Course Map',
      body:'The older but useful specialist course with maker lessons, practice steps, safety notes, challenges, missed-question review, and themed creative rewards.',
      openers:['openCreativeStudioCourse']
    },
    {
      key:'drawing', icon:'✏️', title:'Drawing Desk and Painting Studio', place:'Drawing Desk / Painting Studio',
      body:'A focused Creative Studio route for line, shape, color, watercolor, brush control, composition, and careful looking.',
      studioFilter:'Drawing Desk', altFilter:'Painting Studio', openers:['openCreativeStudioCourse']
    },
    {
      key:'artvale', icon:'🐉', title:'Art Realm: Dragonbrush Vale', place:'Dragonbrush Gate',
      body:'The older art world road with painting dragons, palette meadows, sketch hollows, mural courts, and visual art practice.',
      roomTargets:['dragonbrushVale1','dragonbrushRoad1'], openers:['openDragonbrushVale75S']
    },
    {
      key:'music', icon:'🎵', title:'Music Corner and Bardwood Hall', place:'Music Corner / Bardwood Hall',
      body:'Beat, rhythm, meter, melody, pitch, instruments, listening, tempo, and music-only lesson routes.',
      studioFilter:'Music Corner', openers:['lr69cGoMusicHall','openMusicRealCurriculum','openCreativeStudioCourse']
    },
    {
      key:'theater', icon:'🎭', title:'Theater Stage', place:'Theater Stage',
      body:'Safe theater basics: voice, movement, props, stage pictures, rehearsal habits, puppets, audience respect, and clear storytelling.',
      studioFilter:'Theater Stage', openers:['openCreativeStudioCourse']
    },
    {
      key:'craft', icon:'🧵', title:'Craft Cottage and Pattern Workshop', place:'Craft Cottage / Pattern Workshop',
      body:'Hands-on making, safe tools, patterns, symmetry, design choices, materials, layout, and tidy maker habits.',
      studioFilter:'Craft Cottage', altFilter:'Pattern Workshop', openers:['openCreativeStudioCourse']
    },
    {
      key:'story', icon:'📖', title:'Story Maker Room and Mini Gallery', place:'Story Maker Room / Mini Gallery',
      body:'Visual storytelling, character details, sequence, display labels, gallery care, and explaining creative choices.',
      studioFilter:'Story Maker Room', altFilter:'Mini Gallery', openers:['openCreativeStudioCourse']
    }
  ];

  var DRAWERS = {
    art:{
      icon:'🖌️', title:'Art Realm Drawer',
      note:'Older art material for drawing, painting, color, brushwork, shape, value, gallery display, and Dragonbrush Vale practice.',
      include:/art|paint|painting|drawing|draw|brush|color|shape|value|gallery|dragonbrush|palette|mural|sketch/i,
      empty:'No loose Art Realm lessons were found in the loaded bank. Art still belongs inside Creative Quarter through the studio road and Dragonbrush Vale route.',
      buttons:[['Open Creative Quarter','road:quarter'],['Open Creative Studio','road:studio'],['Dragonbrush Vale','road:artvale']]
    },
    music:{
      icon:'🎵', title:'Music Hall Drawer',
      note:'Older music material for beat, rhythm, meter, tempo, melody, pitch, instruments, listening, dynamics, and Bardwood Hall.',
      include:/music|bard|bardwood|rhythm|beat|tempo|melody|pitch|instrument|listening|dynamics|meter/i,
      empty:'No loose Music Hall lessons were found in the loaded bank. Music still routes through Music Corner, Bardwood Hall, and the music-only lesson drawer when present.',
      buttons:[['Music Corner','road:music'],['Open Creative Studio','road:studio']]
    },
    theater:{
      icon:'🎭', title:'Theater Stage Drawer',
      note:'Older theater material for stage movement, voice, props, audience habits, rehearsal, puppets, dramatic scenes, and clear performance choices.',
      include:/theater|theatre|stage|drama|dramatic|performance|perform|prop|puppet|audience|rehearsal|voice|movement/i,
      empty:'No loose Theater Stage lessons were found. Theater now has a safe home in Creative Studio and the Creative Quarter map.',
      buttons:[['Theater Stage','road:theater'],['Open Creative Quarter','road:quarter']]
    },
    craft:{
      icon:'🧵', title:'Craft Cottage Drawer',
      note:'Older craft material for making, pattern, design, symmetry, layout, tools, material choices, safe cutting, and handmade projects.',
      include:/craft|cottage|maker|making|pattern|symmetry|design|layout|material|tool|thread|weave|weaving|cut|fold/i,
      empty:'No loose Craft Cottage lessons were found. Craft and design routes now live under Creative Quarter instead of floating as separate buttons.',
      buttons:[['Craft Cottage','road:craft'],['Open Creative Quarter','road:quarter']]
    },
    story:{
      icon:'📚', title:'Story Maker / Dragon Library Drawer',
      note:'Older story-making material for character, setting, plot, sequence, scenes, picture storytelling, Dragon Lore, and Story Forest practice.',
      include:/story|story_forest|dragon|lore|character|setting|plot|scene|sequence|picture storytelling|storytelling|library/i,
      empty:'No loose Story Maker lessons were found. Story making now routes through the Creative Quarter and can also connect back to Core Halls writing when needed.',
      buttons:[['Story Maker Room','road:story'],['Open Creative Quarter','road:quarter'],['Writing in Core Halls','coreWriting']]
    },
    gallery:{
      icon:'🖼️', title:'Gallery and Display Drawer',
      note:'Older gallery material for displaying work, labels, curation, contrast, focus, mini galleries, observation, and explaining creative choices.',
      include:/gallery|display|curat|label|portfolio|exhibit|exhibition|focus|contrast|observation|viewer/i,
      empty:'No loose Gallery lessons were found. Gallery habits are still kept as a Creative Quarter room and Creative Studio filter.',
      buttons:[['Mini Gallery','road:story'],['Drawing/Painting Studio','road:drawing']]
    },
    older:{
      icon:'🎪', title:'Older Creative Practice Drawer',
      note:'General older creative lessons that do not fit one exact room: art, music, theater, stories, maker habits, projects, and creative vocabulary.',
      include:/creative|art|music|theater|theatre|craft|maker|story|gallery|paint|draw|rhythm|design|project/i,
      empty:'No general creative bank lessons were found. Use the Creative Quarter Adventure and Creative Studio Specialists as the connected creative roads.',
      buttons:[['Open Creative Quarter','road:quarter'],['Open Creative Studio','road:studio']]
    }
  };

  function roadByKey(key){
    for(var i=0;i<ROADS.length;i++) if(ROADS[i].key === key) return ROADS[i];
    return null;
  }
  function navButton(label, act){
    return '<button class="lr75sSmallBtn" data-lr75s-act="' + esc(act) + '">' + esc(label) + '</button>';
  }
  function roadButton(r){
    return '<button class="lr75sCard" data-lr75s-act="road:' + esc(r.key) + '">' +
      '<b>' + esc(r.icon + ' ' + r.title) + '</b>' +
      '<small>' + esc(r.place) + '</small>' +
      '<span>' + esc(r.body) + '</span>' +
    '</button>';
  }
  function drawerButton(key){
    var d = DRAWERS[key];
    if(!d) return '';
    return '<button class="lr75sCard lr75sDrawerCard" data-lr75s-act="drawer:' + esc(key) + ':0">' +
      '<b>' + esc(d.icon + ' ' + d.title) + '</b>' +
      '<small>Connected older creative drawer</small>' +
      '<span>' + esc(d.note) + '</span>' +
    '</button>';
  }

  function renderCreativeMap(){
    installStyles();
    actionMount('🎨 Creative Quarter Connected Map',
      '<div class="lr75sShell">' +
        '<div class="lr75sHero">' +
          '<div><b>🎨 Creative Quarter Connected Map</b><p>This is a routing cleanup, not a new course. The Creative Quarter Adventure, Creative Studio Specialists, art/music world routes, and older creative drawers now share one tidy maker map.</p></div>' +
          '<div class="lr75sHeroBtns">' + navButton('Realm Library','library') + navButton('7.5O Connection Ledger','ledger') + '</div>' +
        '</div>' +
        '<h3>Main creative roads</h3>' +
        '<div class="lr75sGrid lr75sRoadGrid">' + ROADS.map(roadButton).join('') + '</div>' +
        '<h3>Connected creative drawers</h3>' +
        '<div class="lr75sGrid">' + ['art','music','theater','craft','story','gallery','older'].map(drawerButton).join('') + '</div>' +
        '<div class="lr75sNote"><b>What 7.5S does</b><p>Visible creative buttons now have a safer home: art, music, theater, crafts, story making, gallery habits, Dragonbrush Vale, Bardwood Hall, and the older creative practice bank. It does not rebuild the shell or add heavy content.</p></div>' +
      '</div>'
    );
  }

  function openStudioFilter(filter){
    if(!filter) return false;
    if(has('openCreativeStudioCourse')){
      try{
        window.openCreativeStudioCourse(filter);
        scheduleInject();
        setTimeout(scheduleInject, 180);
        return true;
      }catch(e){ console.warn('LR75S studio filter failed:', filter, e); }
    }
    if(has('openCreativeStudioByStudio')){
      var names = ['Drawing Desk','Painting Studio','Craft Cottage','Pattern Workshop','Theater Stage','Music Corner','Story Maker Room','Mini Gallery'];
      var idx = names.indexOf(filter);
      if(idx >= 0){
        try{ window.openCreativeStudioByStudio(idx); scheduleInject(); setTimeout(scheduleInject, 180); return true; }catch(e){}
      }
    }
    return false;
  }

  function getRooms(){
    var rooms = [];
    try{ if(window.ROOMS) rooms.push(window.ROOMS); }catch(e){}
    try{ if(typeof ROOMS !== 'undefined') rooms.push(ROOMS); }catch(e){}
    try{ if(window.LR_ROOMS) rooms.push(window.LR_ROOMS); }catch(e){}
    return rooms;
  }
  function roomExists(id){
    var rs = getRooms();
    for(var i=0;i<rs.length;i++) if(rs[i] && rs[i][id]) return true;
    return false;
  }
  function goRoom(targets, note){
    targets = targets || [];
    var target = null;
    for(var i=0;i<targets.length;i++) if(roomExists(targets[i])){ target = targets[i]; break; }
    if(!target) return false;
    try{ if(window.LR68A && typeof window.LR68A.goTo === 'function') return !!window.LR68A.goTo(target); }catch(e){}
    try{ if(typeof window.lr68aGoTo === 'function') return !!window.lr68aGoTo(target); }catch(e){}
    var s = null;
    try{ s = window.state || (typeof state !== 'undefined' ? state : null); }catch(e){}
    if(s){
      try{ s.loc = target; s.room = Math.max(1, Number(s.room || 1)) + 1; }catch(e){}
      try{ if(typeof window.save === 'function') window.save(); else if(typeof save === 'function') save(); }catch(e){}
      try{ if(typeof window.renderStats === 'function') window.renderStats(); else if(typeof renderStats === 'function') renderStats(); }catch(e){}
      try{ if(typeof window.lr68Render === 'function') return !!window.lr68Render('room', note || 'You step onto the Creative Quarter road.'); }catch(e){}
      try{ if(typeof window.lr67RenderDynamicScreen === 'function') return !!window.lr67RenderDynamicScreen('room', note || 'You step onto the Creative Quarter road.'); }catch(e){}
      try{ if(typeof window.renderRoom === 'function') return !!window.renderRoom(); }catch(e){}
    }
    return false;
  }

  function openRoad(key){
    var r = roadByKey(key);
    if(!r){ renderCreativeMap(); return; }
    if(r.key === 'artvale'){
      if(goRoom(r.roomTargets, 'You follow the painted lantern path into Dragonbrush Vale.')) return;
      if(openDrawer('art',0)) return;
      return softNote(r.title, 'Dragonbrush Vale is listed as an older art world route, but its room renderer did not answer in this build. The route stays connected here instead of becoming a dead button.', [['Back to Creative Map','map'],['Art Drawer','drawer:art:0']]);
    }
    if(r.key === 'music'){
      if(has('lr69cGoMusicHall')){ try{ if(window.lr69cGoMusicHall()) return; }catch(e){} }
      if(openStudioFilter('Music Corner')) return;
      if(callFirst(['openMusicRealCurriculum'])) return;
      return softNote(r.title, 'Music is connected here through Music Corner, Bardwood Hall, and the older music drawer. The direct opener did not answer in this build.', [['Back to Creative Map','map'],['Music Drawer','drawer:music:0']]);
    }
    if(r.studioFilter && openStudioFilter(r.studioFilter)) return;
    if(r.altFilter && openStudioFilter(r.altFilter)) return;
    if(callFirst(r.openers || [])) return;
    softNote(r.title, 'This creative road is listed in the connected map, but its opener did not answer in this build. It remains an in-world signpost instead of a dead button.', [['Back to Creative Map','map']]);
  }
  function openCoreWriting(){
    if(callFirst(['openWritingCompositionMasterCourse','openWritingCompositionMaster74W','openAuthorGuild'])) return;
    softNote('Story-to-Writing route note','Story making belongs in Creative Quarter, but written composition can connect back to the Author Guild in Core Halls.', [['Back to Creative Map','map'],['Story Drawer','drawer:story:0']]);
  }

  function lessonText(l){ return [l.source_pack,l.pack_region,l.region,l.mastery_tag,l.topic,l.skill,l.unit,l.question,l.explanation,l.prompt,l.miniLesson,l.workedExample].join(' '); }
  function lessonMatches(l, drawer){ return !!(drawer && drawer.include && drawer.include.test(lessonText(l))); }
  async function getBank(){
    if(has('lrLoadRealCurriculumBank')){
      try{ return await window.lrLoadRealCurriculumBank(); }catch(e){}
    }
    return window.__lrRealCurriculumBank || [];
  }
  async function openDrawer(key, page){
    return renderDrawer(key, page);
  }
  async function renderDrawer(key, page){
    installStyles();
    var d = DRAWERS[key];
    if(!d){ renderCreativeMap(); return false; }
    page = Math.max(0, parseInt(page || 0, 10) || 0);
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75sShell"><div class="lr75sHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>Searching the existing lesson bank for older creative material. No new course is being added.</p></div></div><p class="lr75sFoot">Loading connected drawer…</p></div>'
    );
    var bank = await getBank();
    var matches = (bank || []).filter(function(l){ return lessonMatches(l, d); });
    var per = 12;
    var pages = Math.max(1, Math.ceil(matches.length / per));
    if(page >= pages) page = pages - 1;
    var sample = matches.slice(page * per, page * per + per);
    if(!sample.length){
      actionMount(d.icon + ' ' + d.title,
        '<div class="lr75sShell">' +
          '<div class="lr75sHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p></div><div class="lr75sHeroBtns">' + navButton('Creative Map','map') + '</div></div>' +
          '<div class="lr75sNote"><b>In-world route note</b><p>' + esc(d.empty) + '</p><div class="lr75sInlineBtns">' + (d.buttons || [['Back to Creative Map','map']]).map(function(b){ return navButton(b[0], b[1]); }).join('') + navButton('Back to Creative Map','map') + '</div></div>' +
        '</div>'
      );
      return false;
    }
    actionMount(d.icon + ' ' + d.title,
      '<div class="lr75sShell">' +
        '<div class="lr75sHero"><div><b>' + esc(d.icon + ' ' + d.title) + '</b><p>' + esc(d.note) + '</p><p><small>' + matches.length + ' connected lesson' + (matches.length === 1 ? '' : 's') + ' found in the existing bank.</small></p></div><div class="lr75sHeroBtns">' + navButton('Creative Map','map') + '</div></div>' +
        '<div class="lr75sLessonList">' + sample.map(function(l){
          var idx = bank.indexOf(l);
          return '<button class="lr75sLesson" data-lr75s-act="lesson:' + idx + '"><b>' + esc(l.region || l.pack_region || l.unit || 'Creative lesson') + '</b><small>' + esc(l.mastery_tag || l.source_pack || l.skill || 'practice') + '</small><span>' + esc(smallText(l.question || l.explanation || l.prompt || l.miniLesson || '', 170)) + '</span></button>';
        }).join('') + '</div>' +
        '<div class="lr75sPager">' + (page > 0 ? navButton('← Previous','drawer:' + key + ':' + (page - 1)) : '') + '<span>Page ' + (page + 1) + ' of ' + pages + '</span>' + (page < pages - 1 ? navButton('Next →','drawer:' + key + ':' + (page + 1)) : '') + '</div>' +
      '</div>'
    );
    return true;
  }

  function softNote(title, body, buttons){
    installStyles();
    buttons = buttons || [['Back to Creative Map','map']];
    actionMount(title || 'Creative Quarter Note',
      '<div class="lr75sShell"><div class="lr75sNote"><b>' + esc(title || 'Creative Quarter Note') + '</b><p>' + esc(body || '') + '</p><div class="lr75sInlineBtns">' + buttons.map(function(b){ return navButton(b[0], b[1]); }).join('') + '</div></div></div>'
    );
  }

  function openLesson(idx){
    idx = parseInt(idx, 10);
    if(!isFinite(idx) || idx < 0){ softNote('Lesson route note','That older lesson pointer was not available.', [['Back to Creative Map','map']]); return; }
    if(has('lrOpenRealLessonByIndex')){
      window.lrOpenRealLessonByIndex(idx);
      setTimeout(function(){
        var at = $('actionText');
        if(!at) return;
        var btns = at.querySelectorAll('button');
        for(var i=0;i<btns.length;i++){
          if(/Back to REAL Curriculum|Back to Curriculum|Return to Library/i.test(btns[i].textContent || '')){
            btns[i].setAttribute('data-lr75s-act','map');
            btns[i].removeAttribute('onclick');
            btns[i].textContent = 'Back to Creative Map';
          }
        }
      }, 80);
      return;
    }
    softNote('Lesson route note','The authored lesson opener was not available in this build.', [['Back to Creative Map','map']]);
  }

  function handleAct(act){
    if(!act) return;
    if(act === 'map'){ renderCreativeMap(); return; }
    if(act === 'library'){
      if(has('openRealmLibrary75A')){ window.openRealmLibrary75A('arts'); scheduleInject(); return; }
      if(has('openRealCurriculumPicker')){ window.openRealCurriculumPicker('arts'); scheduleInject(); return; }
      renderCreativeMap(); return;
    }
    if(act === 'ledger'){
      if(has('openLearningCenterAnnex75O')){ window.openLearningCenterAnnex75O('creative'); scheduleInject(); return; }
      if(has('openLearningCenterConnectionAudit75O')){ window.openLearningCenterConnectionAudit75O(); scheduleInject(); return; }
      renderCreativeMap(); return;
    }
    if(act === 'coreWriting'){ openCoreWriting(); return; }
    if(act.indexOf('road:') === 0){ openRoad(act.split(':')[1]); return; }
    if(act.indexOf('drawer:') === 0){ var bits = act.split(':'); renderDrawer(bits[1], bits[2] || 0); return; }
    if(act.indexOf('lesson:') === 0){ openLesson(act.split(':')[1]); return; }
  }

  function installStyles(){
    if($('lr75sStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr75sStyles';
    st.textContent =
      '.lr75sShell{padding:14px;color:#2c1b10}.lr75sHero{display:flex;gap:12px;justify-content:space-between;align-items:flex-start;background:linear-gradient(135deg,#fff4d9,#ffe7f1);border:2px solid #a96a2d;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 8px 20px rgba(80,45,20,.14)}' +
      '.lr75sHero b{font-size:1.18rem}.lr75sHero p{margin:.35rem 0 0;line-height:1.4}.lr75sHeroBtns,.lr75sInlineBtns{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.lr75sGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:10px;margin:10px 0 18px}.lr75sCard,.lr75sLesson{display:block;text-align:left;width:100%;border:2px solid #a96a2d;background:#fffaf0;border-radius:14px;padding:12px;cursor:pointer;color:#2c1b10;box-shadow:0 4px 10px rgba(80,45,20,.10)}' +
      '.lr75sCard:hover,.lr75sLesson:hover,.lr75sSmallBtn:hover{transform:translateY(-1px);filter:brightness(1.03)}.lr75sCard b,.lr75sLesson b{display:block;margin-bottom:4px}.lr75sCard small,.lr75sLesson small{display:block;color:#7a4b22;margin-bottom:6px}.lr75sCard span,.lr75sLesson span{display:block;line-height:1.32}.lr75sDrawerCard{background:#fffdf6;border-color:#8f6c35}.lr75sSmallBtn{border:2px solid #8c4f28;background:#fffaf0;border-radius:999px;padding:8px 11px;cursor:pointer;color:#2c1b10;font-weight:700}.lr75sNote{background:#fffdf6;border:2px dashed #9b7b44;border-radius:14px;padding:14px;margin:12px 0}.lr75sLessonList{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}.lr75sPager{display:flex;gap:10px;align-items:center;justify-content:center;margin:14px 0;flex-wrap:wrap}.lr75sFoot{color:#7a4b22}.lr75sAuditDoor{border-color:#a96a2d!important;background:linear-gradient(135deg,#fff4d9,#ffe7f1)!important}.lr75sLibraryTiny{font-size:.84rem;color:#7a4b22;margin-top:4px;display:block}';
    document.head.appendChild(st);
  }

  function libraryCard(id, title, small, body, act, className){
    var btn = document.createElement('button');
    btn.id = id;
    btn.className = className || 'lr75aDoorCard lr75sAuditDoor';
    btn.setAttribute('data-lr75s-act', act);
    btn.innerHTML = '<b>' + esc(title) + '</b><small class="lr75sLibraryTiny">' + esc(small) + '</small><span>' + esc(body) + '</span>';
    return btn;
  }
  function hasText(node, re){ return re.test((node && node.textContent) || ''); }
  function addCard(grid, id, re, title, small, body, act){
    if(!grid || $(id) || (re && hasText(grid, re))) return;
    grid.appendChild(libraryCard(id, title, small, body, act));
  }
  function injectIntoRealmLibrary(root){
    var grid = root.querySelector('.lr75aDoorGrid');
    if(!grid || !/Creative Quarter|Art|music|theater|story making|maker village/i.test(root.textContent || '')) return;
    if(!$('lr75sCreativeConnectedMapDoor')){
      grid.insertBefore(libraryCard('lr75sCreativeConnectedMapDoor','🎨 Creative Quarter Connected Map','master roads plus old drawers','A safe 7.5S map for Creative Quarter, Creative Studio, Dragonbrush Vale, Bardwood Hall, art, music, theater, crafts, story making, gallery habits, and older creative practice.','map'), grid.firstChild);
    }
    addCard(grid,'lr75sCreativeStudioDoor',/Creative Studio Specialists/i,'🧰 Creative Studio Specialists','specialist course','Open the older hands-on creative course without letting it float loose.','road:studio');
    addCard(grid,'lr75sMusicDoor',/Bardwood Hall|Music Corner/i,'🎵 Music Corner and Bardwood Hall','music route','Beat, rhythm, melody, pitch, instruments, listening, and music-only lesson routes.','road:music');
    addCard(grid,'lr75sTheaterDrawerDoor',/Theater Stage Drawer/i,'🎭 Theater Stage Drawer','legacy drawer','Connects older theater, stage, props, and performance practice.','drawer:theater:0');
    addCard(grid,'lr75sStoryDrawerDoor',/Story Maker|Dragon Library/i,'📚 Story Maker / Dragon Library Drawer','legacy drawer','Connects story-making, Dragon Lore, Story Forest, characters, scenes, and visual storytelling.','drawer:story:0');
  }
  function injectIntoAnnex(root){
    if(!/Creative Quarter Annex|Creative Quarter/i.test(root.textContent || '')) return;
    if($('lr75sAnnexMapStrip')) return;
    var target = root.querySelector('.lr75oHero,.lr75oWingHero,.lr75oShell') || root.firstElementChild || root;
    if(!target || !target.parentNode) return;
    var strip = document.createElement('div');
    strip.id = 'lr75sAnnexMapStrip';
    strip.className = 'lr75sNote';
    strip.innerHTML = '<b>🎨 7.5S Creative Quarter cleanup</b><p>Creative roads and older drawers now share one connected maker map so art, music, theater, craft, story, and gallery buttons have a proper in-world home.</p><div class="lr75sInlineBtns">' + navButton('Open Creative Connected Map','map') + navButton('Music Drawer','drawer:music:0') + navButton('Story Drawer','drawer:story:0') + '</div>';
    target.parentNode.insertBefore(strip, target.nextSibling);
  }
  function injectIntoCreativeRoad(root){
    if(!/Creative Quarter|Creative Studio|Drawing Desk|Painting Studio|Theater Stage|Music Corner|Story Maker|Craft Cottage/i.test(root.textContent || '')) return;
    if(root.querySelector('.cs65Shell,.lr74oTopic')) return;
    var grid = root.querySelector('.lr74oGrid,.cs65Grid,.lrCourseDoorGrid,.lr74kChoices,.lr75aDoorGrid');
    if(!grid || $('lr75sQuarterMapCard')) return;
    var btn = libraryCard('lr75sQuarterMapCard','🎨 Creative Quarter Connected Map','cleanup map','Jump to the tidy 7.5S map for creative roads and older drawers.','map','lr75sCard lr75sAuditDoor');
    grid.insertBefore(btn, grid.firstChild);
  }
  function routeLooseCreativeButtons(root){
    if(root.querySelector('.cs65Shell,.lr74oMap,.lr74oTopic')) return;
    var buttons = Array.prototype.slice.call(root.querySelectorAll('button'));
    buttons.forEach(function(btn){
      if(btn.hasAttribute('data-lr75s-act')) return;
      if(btn.closest && btn.closest('.cs65Shell,.lr74oMap,.lr74oTopic')) return;
      var text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
      if(!text || text.length > 130) return;
      var act = null;
      if(/Creative Quarter|Creative Adventure|Maker Quarter|Creative Road/i.test(text)) act = 'map';
      else if(/Creative Studio Specialists|Creative Studio Course|All studios/i.test(text)) act = 'road:studio';
      else if(/Dragonbrush|Art Realm|Art Studio|Painting Studio|Drawing Desk|Paint|Drawing/i.test(text)) act = /Dragonbrush|Art Realm/i.test(text) ? 'road:artvale' : 'road:drawing';
      else if(/Music Corner|Bardwood|Music Hall|Music Lessons/i.test(text)) act = 'road:music';
      else if(/Theater Stage|Theatre Stage|Drama|Puppet|Stage/i.test(text)) act = 'road:theater';
      else if(/Craft Cottage|Pattern Workshop|Design Workshop|Maker Skills/i.test(text)) act = 'road:craft';
      else if(/Story Maker|Story Forest|Dragon Library|Dragon Lore/i.test(text)) act = 'road:story';
      else if(/Gallery|Mini Gallery|Display/i.test(text)) act = 'drawer:gallery:0';
      else if(/^Art$|Arts|Creative Practice|Art and Music|Older art/i.test(text)) act = 'map';
      if(!act) return;
      btn.setAttribute('data-lr75s-act', act);
      /* 7.6W: preserve onclick fallback */
      btn.classList.add('lr75sAuditDoor');
    });
  }
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(runInject, 80);
  }
  function runInject(){
    installStyles();
    var roots = [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; });
    for(var i=0;i<roots.length;i++){
      injectIntoRealmLibrary(roots[i]);
      injectIntoAnnex(roots[i]);
      injectIntoCreativeRoad(roots[i]);
      routeLooseCreativeButtons(roots[i]);
    }
  }
  function wrap(name){
    if(!has(name) || window[name].__lr75sWrapped) return;
    var old = window[name];
    var wrapped = function(){
      var out = old.apply(this, arguments);
      scheduleInject();
      setTimeout(scheduleInject, 250);
      return out;
    };
    wrapped.__lr75sWrapped = true;
    window[name] = wrapped;
  }
  function bind(){
    if(window.__LR75S_BOUND__) return;
    window.__LR75S_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr75s-act]') : null;
      if(!btn) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAct(btn.getAttribute('data-lr75s-act'));
    }, true);
  }
  function installObserver(){
    if(obsInstalled) return;
    obsInstalled = true;
    if(typeof MutationObserver === 'undefined') return;
    var mo = new MutationObserver(function(){ scheduleInject(); });
    [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; }).forEach(function(target){
      try{ mo.observe(target, {childList:true, subtree:false}); }catch(e){}
    });
  }
  function init(){
    installStyles();
    bind();
    ['openRealmLibrary75A','openRealCurriculumPicker','openLearningCenterAnnex75O','openLearningCenterConnectionAudit75O','openCreativeQuarterAdventure74O','openCreativeHomesteadAdventure74O','openCreativeStudioCourse','openCreativeStudioByStudio','openMusicRealCurriculum','lr69cGoMusicHall'].forEach(wrap);
    installObserver();
    setTimeout(scheduleInject, 250);
    window.LR_CREATIVE_QUARTER_CONNECTION_CLEANUP_75S = { patch:PATCH, open:renderCreativeMap, drawers:DRAWERS, roads:ROADS };
  }

  window.openCreativeQuarterConnectionCleanup75S = renderCreativeMap;
  window.openCreativeQuarterCleanup75S = renderCreativeMap;
  window.openCreativeQuarterConnectedMap75S = renderCreativeMap;
  window.openDragonbrushVale75S = function(){ return goRoom(['dragonbrushVale1','dragonbrushRoad1'], 'You follow the painted lantern path into Dragonbrush Vale.'); };

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
