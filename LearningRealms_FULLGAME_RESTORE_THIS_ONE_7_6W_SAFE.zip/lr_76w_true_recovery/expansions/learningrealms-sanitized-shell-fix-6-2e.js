
(function(){
  'use strict';
  if(window.__LR62E_SANITIZED_SHELL__) return;
  window.__LR62E_SANITIZED_SHELL__ = true;
  function byId(id){return document.getElementById(id);} function text(v){return String(v==null?'':v);} function esc(s){return text(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function safe(fn){try{if(typeof window[fn]==='function'){window[fn]();return true;}}catch(e){console.warn('LR62E action failed',fn,e);}return false;}
  function openLearn(){ if(safe('lr19OpenLearningChooser')) return; if(safe('openRealCurriculumPicker')) return; if(safe('openLessonLauncher')) return; if(safe('openSubjectAtlasUI')) return; writeAction('Go Learn','The learning menu is still loading.'); }
  function openShip(){ if(safe('shipwreckGuidedZoneOpen')) return; if(safe('openShipwreckCoveDeepCourse')) return; writeAction('Shipwreck Cove','Shipwreck Cove is still loading.'); }
  function contShip(){ if(safe('shipwreckGuidedZoneContinue')) return openShip(); }
  function move(dir){ try{ if(typeof window.move==='function'){window.move(String(dir).toLowerCase()); return;} }catch(e){} try{ if(typeof window.go==='function'){window.go(String(dir).toLowerCase()); return;} }catch(e){} writeAction('Move','Movement hooks are ready, but the room engine did not accept that direction yet.'); }
  function writeAction(title, msg){ var t=byId('actionTitle'), b=byId('actionText'); if(t)t.textContent=title; if(b)b.innerHTML='<div class="lr62ePanel"><p>'+esc(msg)+'</p></div>'; }
  function css(){ if(byId('lr62eStyles')) return; var st=document.createElement('style'); st.id='lr62eStyles'; st.textContent='body{min-height:100vh!important}.shell,main,.card,.main,.actionSidebar,.rightSidebar,.playerSidebar{visibility:visible!important;opacity:1!important}.shell{display:block!important}main{display:grid!important;grid-template-columns:220px 1fr 340px!important;gap:16px!important}body>button{display:none!important}.lrNukeOldButton{display:inline-block!important}.actionSidebar .lrNukeOldButton, .main .lrNukeOldButton, .playerSidebar .lrNukeOldButton{display:inline-block!important}#lrFixedGameplayDock,#lrCenterActionDock,#lrCenterGameplayDock{display:none!important}.lr62ePanel{background:rgba(255,227,160,.08);border:1px solid rgba(255,227,160,.2);border-radius:14px;padding:12px;margin:8px 0}.lr62eBtns,#mainGameplayActions,#leftActionButtons{display:flex!important;gap:8px!important;flex-wrap:wrap!important}.actionButtons{display:flex!important;flex-direction:column!important}#leftActionButtons{flex-direction:column!important;align-items:flex-start!important}#leftActionButtons button{width:100%;text-align:left}.lr62eBtns button,#mainGameplayActions button,#leftActionButtons button,#mainCompassNav button{display:inline-block!important;visibility:visible!important;opacity:1!important}.lr62eCompass,#mainCompassNav{display:grid!important;grid-template-columns:repeat(3,minmax(64px,1fr))!important;gap:7px!important;max-width:340px!important;margin-top:10px!important}@media(max-width:1000px){main{display:block!important}}'; document.head.appendChild(st); }

  function dedupeGoLearn(){
    try{
      var buttons=[].slice.call(document.querySelectorAll('button'));
      var seen=false;
      buttons.forEach(function(b){
        var label=(b.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
        if(label==='📘 go learn' || label==='go learn'){
          if(seen){ b.style.display='none'; b.setAttribute('data-lr63c-hidden-duplicate-golearn','1'); }
          else { seen=true; b.style.display=''; b.removeAttribute('data-lr63c-hidden-duplicate-golearn'); }
        }
      });
    }catch(e){}
  }
  function fill(){ css(); var rt=byId('roomTitle'), rx=byId('roomText'); if(rt && (!rt.textContent || rt.textContent==='Room')) rt.textContent='LearningRealms Hub'; if(rx && !rx.textContent.trim()) rx.textContent='Choose Go Learn, Shipwreck Cove, or use the room controls.'; var left=byId('leftActionButtons'); if(left){left.innerHTML=''; [['📘 Go Learn',openLearn],['⚓ Shipwreck Cove',openShip],['🧭 Continue Tour',contShip],['📜 Quests',function(){safe('openQuestBoard')||safe('openDailyQuestBoard')||writeAction('Quests','Quest tools are still loading.')}],['🏠 Home',function(){safe('openHomeRenderer')||safe('openVisualHome')||writeAction('Home','Home is still loading.')}]].forEach(function(x){var b=document.createElement('button'); b.type='button'; b.textContent=x[0]; b.onclick=x[1]; left.appendChild(b);});}
    var comp=byId('mainCompassNav'); if(comp){comp.innerHTML=''; [['NW','↖'],['N','↑'],['NE','↗'],['W','←'],['HOME','🏠'],['E','→'],['SW','↙'],['S','↓'],['SE','↘']].forEach(function(x){var b=document.createElement('button'); b.type='button'; b.textContent=x[1]+' '+x[0]; b.onclick=function(){move(x[0]);}; comp.appendChild(b);});}
    var acts=byId('mainGameplayActions'); if(acts){acts.innerHTML=''; [['⚓ Enter Shipwreck Cove',openShip],['🧭 Continue Shipwreck Tour',contShip],['🎒 Backpack',function(){safe('openBackpack')||writeAction('Backpack','Backpack is still loading.');}],['📚 Subject Atlas',function(){safe('openSubjectAtlasUI')||writeAction('Subjects','Subject Atlas is still loading.');}]].forEach(function(x){var b=document.createElement('button'); b.type='button'; b.textContent=x[0]; b.onclick=x[1]; acts.appendChild(b);});}
    dedupeGoLearn();
    var action=byId('actionText'); if(action && (/Choose an action/i.test(action.textContent||'') || !action.innerHTML.trim())){ action.innerHTML='<div class="lr62ePanel"><h3>Ready</h3><p>The shell is visible. Shipwreck Cove opens as a guided zone popup and will not replace the whole game screen.</p><div class="lr62eBtns"><button type="button" onclick="lr62eOpenShip()">⚓ Shipwreck Cove</button><button type="button" onclick="lr62eContShip()">🧭 Continue Tour</button></div></div>'; }
    dedupeGoLearn();
  }
  window.lr62eOpenLearn=openLearn; window.lr62eOpenShip=openShip; window.lr62eContShip=contShip; window.lr62eFillShell=fill;
  // prevent old hard refresh from rebuilding a blank/odd shell after this fix runs
  window.lrHardRefreshRoom = fill; try{lrHardRefreshRoom=fill;}catch(e){}
  document.addEventListener('DOMContentLoaded',function(){fill(); setTimeout(fill,50); setTimeout(fill,300); setTimeout(fill,1000);});
  window.addEventListener('load',function(){fill(); setTimeout(fill,250); setTimeout(fill,900);});
})();
