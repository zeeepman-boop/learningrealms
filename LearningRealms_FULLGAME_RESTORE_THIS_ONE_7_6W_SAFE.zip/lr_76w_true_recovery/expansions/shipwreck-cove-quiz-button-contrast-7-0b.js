(function(){
  'use strict';
  var STYLE_ID = 'shipwreckCoveQuizButtonContrast70b';

  function addStyles(){
    if(document.getElementById(STYLE_ID)) return;
    var st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = [
      '/* LearningRealms 7.0B: high contrast lesson/quiz action buttons */',
      '.swcShell .swcNav button.swcPrimary,',
      '.swcShell .swcHeroBtns button.swcPrimary,',
      '.swcShell button.lr70bQuizAction,',
      '.lrPopupBody button.lr70bQuizAction,',
      'button.lr70bQuizAction{',
      '  background:linear-gradient(135deg,#082f3f,#0f5f75)!important;',
      '  color:#ffffff!important;',
      '  border:3px solid #ffd766!important;',
      '  box-shadow:0 5px 14px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.2)!important;',
      '  text-shadow:0 1px 2px rgba(0,0,0,.55)!important;',
      '  font-weight:950!important;',
      '  letter-spacing:.01em!important;',
      '  padding:12px 16px!important;',
      '  min-height:44px!important;',
      '  border-radius:14px!important;',
      '}',
      '.swcShell .swcNav button.swcPrimary:hover,',
      '.swcShell .swcHeroBtns button.swcPrimary:hover,',
      '.swcShell button.lr70bQuizAction:hover,',
      '.lrPopupBody button.lr70bQuizAction:hover,',
      'button.lr70bQuizAction:hover{',
      '  filter:brightness(1.08)!important;',
      '  transform:translateY(-1px)!important;',
      '}',
      '.swcShell .swcNav button.swcPrimary:focus,',
      '.swcShell .swcHeroBtns button.swcPrimary:focus,',
      '.swcShell button.lr70bQuizAction:focus,',
      '.lrPopupBody button.lr70bQuizAction:focus,',
      'button.lr70bQuizAction:focus{',
      '  outline:3px solid #ffffff!important;',
      '  outline-offset:2px!important;',
      '}',
      '.swcShell .swcNav{',
      '  align-items:center!important;',
      '}',
      '.swcShell .swcNav button.swcPrimary::after,',
      '.lrPopupBody button.lr70bQuizAction::after{',
      '  content:"";',
      '}'
    ].join('\n');
    document.head.appendChild(st);
  }

  function normalizeText(s){
    return String(s || '').replace(/\s+/g,' ').trim().toLowerCase();
  }

  function markQuizButtons(root){
    try{
      root = root || document;
      var buttons = root.querySelectorAll ? root.querySelectorAll('button') : [];
      for(var i=0;i<buttons.length;i++){
        var b = buttons[i];
        var text = normalizeText(b.textContent);
        if(text === 'take quiz' || text === 'check quiz' || text.indexOf('take quiz') >= 0 || text.indexOf('check quiz') >= 0){
          b.classList.add('lr70bQuizAction');
          if(text.indexOf('take quiz') >= 0 && b.textContent.indexOf('🧭') < 0){
            b.setAttribute('aria-label','Take quiz');
          }
        }
      }
    }catch(e){}
  }

  function run(){
    addStyles();
    markQuizButtons(document);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();

  try{
    var obs = new MutationObserver(function(muts){
      addStyles();
      for(var i=0;i<muts.length;i++){
        var nodes = muts[i].addedNodes || [];
        for(var j=0;j<nodes.length;j++){
          var n = nodes[j];
          if(n && n.nodeType === 1) markQuizButtons(n);
        }
      }
    });
    obs.observe(document.documentElement, {childList:true, subtree:true});
  }catch(e){}

  window.LR70B_applyQuizButtonContrast = function(){ run(); };
})();
