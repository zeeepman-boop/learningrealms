/* LearningRealms 7.5U - World Directory / Umbrella Verification Pass
   Conservative bridge patch only. No shell rebuild, no render loop, no loading curtain.
   Purpose: keep the Realm Library / World Directory organized around major umbrellas after
   the 7.5P-7.5T cleanup chain, and route obvious loose subject buttons back into the right
   connected map or annex instead of opening old scattered drawers. */
(function(){
  'use strict';

  if(window.__LR75U_WORLD_DIRECTORY_VERIFICATION__) return;
  window.__LR75U_WORLD_DIRECTORY_VERIFICATION__ = true;

  var PATCH = '7.5U World Directory / Umbrella Verification Pass';
  var injectTimer = null;
  var observerInstalled = false;

  function $(id){ return document.getElementById(id); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function esc(v){
    return String(v == null ? '' : v).replace(/[&<>"']/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }
  function callFirst(list){
    for(var i=0;i<list.length;i++){
      var item = list[i];
      try{
        if(Array.isArray(item) && has(item[0])){
          window[item[0]].apply(window, item.slice(1));
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }
        if(typeof item === 'string' && has(item)){
          window[item]();
          scheduleInject();
          setTimeout(scheduleInject, 180);
          return true;
        }
      }catch(e){ console.warn('LR75U route failed:', item, e); }
    }
    return false;
  }
  function actionMount(title, html){
    installStyles();
    var t = $('actionTitle'), b = $('actionText');
    if(t) t.textContent = title || 'World Directory';
    if(b) b.innerHTML = html || '';
    try{
      if(has('lrOpenActionPopup')) window.lrOpenActionPopup(title || 'World Directory');
      else if(has('lrOpenPopup')) window.lrOpenPopup(title || 'World Directory', html || '');
    }catch(e){}
    scheduleInject();
  }
  function softNote(title, body, buttons){
    buttons = buttons || [['Realm Library','library'],['Verification Map','map']];
    actionMount(title || 'Route note', '<div class="lr75uShell"><div class="lr75uNote"><b>' + esc(title || 'Route note') + '</b><p>' + esc(body || '') + '</p><div class="lr75uInlineBtns">' + buttons.map(function(b){ return navButton(b[0], b[1]); }).join('') + '</div></div></div>');
  }
  function navButton(label, act){ return '<button class="lr75uSmallBtn" data-lr75u-act="' + esc(act) + '">' + esc(label) + '</button>'; }

  var UMBRELLAS = [
    {
      key:'core', icon:'🏰', title:'Core Halls', small:'Reading · Writing · Math · Logic · Language',
      body:'Reading, writing, math, logic, grammar, vocabulary, copywork, spelling, grade ladders, and old core drawers belong in this hall.',
      cleanup:'7.5P connected map',
      calls:['openCoreHallsConnectionCleanup75P','openCoreHallsLearningCenter75P','openCoreHallsCleanup75P', ['openRealmLibrary75A','core'], ['openLearningCenterAnnex75O','core']]
    },
    {
      key:'history', icon:'🗺️', title:'History and World Wing', small:'Egypt · Greece/Rome · England · Shipwrecks · Civics',
      body:'History, geography, civics, economics, Egypt, Greece/Rome, England, Medieval World, America, Wild West, Great Depression, and Shipwreck Cove stay under one museum wing.',
      cleanup:'7.5O annex with master-course roads',
      calls:[['openRealmLibrary75A','history'], ['openLearningCenterAnnex75O','history'], 'openLearningCenterConnectionAudit75O']
    },
    {
      key:'science', icon:'🔬', title:'Science and Engineering Quarter', small:'Science · Inventions · Aerospace · Weather · Animals',
      body:'Labs, field stations, storm rooms, inventions, aerospace, nature/health, animal work, and old science drawers belong in this quarter.',
      cleanup:'7.5R connected map',
      calls:['openScienceEngineeringConnectionCleanup75R','openScienceQuarterConnectedMap75R','openScienceEngineeringCleanup75R', ['openRealmLibrary75A','science'], ['openLearningCenterAnnex75O','science']]
    },
    {
      key:'bible', icon:'✝️', title:'Bible Road', small:'Catholic-friendly sacred history · saints · angels',
      body:'Bible History, saints, angels, early Church, respectful review shelves, and Catholic-friendly artifacts stay on a separate reverent road.',
      cleanup:'7.5Q text cleanup bridge',
      calls:['openBibleRoadCleanup75Q','openBibleRoadCleanMap75Q', ['openRealmLibrary75A','bible'], ['openLearningCenterAnnex75O','bible']]
    },
    {
      key:'creative', icon:'🎨', title:'Creative Quarter', small:'Art · music · theater · crafts · story maker',
      body:'Drawing, painting, music, theater, crafts, patterns, gallery work, and story making belong in the maker village.',
      cleanup:'7.5S connected map',
      calls:['openCreativeQuarterConnectionCleanup75S','openCreativeQuarterConnectedMap75S','openCreativeQuarterCleanup75S', ['openRealmLibrary75A','creative'], ['openLearningCenterAnnex75O','creative']]
    },
    {
      key:'homestead', icon:'🏡', title:'Homestead Workshop / Living World', small:'Life skills · home · shops · companions · seasons',
      body:'Life skills, cooking, repair, farm/garden, home rooms, Town Notice Board, shops, companions, collections, quests, birthdays, seasons, and rare rotations stay in the living-world umbrella.',
      cleanup:'7.5T connected town map',
      calls:['openHomesteadLivingWorldConnectionCleanup75T','openHomesteadConnectedMap75T','openHomesteadWorkshopConnectedMap75T', ['openRealmLibrary75A','homestead'], ['openLearningCenterAnnex75O','homestead']]
    }
  ];

  var LOOSE_ROUTES = [
    {re:/\b(Reading|Comprehension|Lantern Library|Writing|Composition|Author Guild|Math|Number Vault|Logic|Riddle|Grammar|Vocabulary|Language Forge|Copywork|Spelling|Grade Ladder|Counting Orchard|Fraction Castle|Geometry Caverns|Equation Forge)\b/i, act:'umbrella:core'},
    {re:/\b(Egypt|Pharaoh|Pyramid|Sphinx|Greece|Rome|England|Kings|Queens|Medieval|Castle|American History|Wild West|Great Depression|Shipwreck|Cove|Geography|Mapmaker|Civics|Civic Hall|Economics|Market Square)\b/i, act:'umbrella:history'},
    {re:/\b(Science|Engineering|Inventions|Aerospace|Rocket|Flight|Nature|Health|Weather|Storm|Animals|Creature|Chemistry|Astronomy|Earth Science|Botany|Electricity|Physics|Robotics|Computer Science|Dinosaur|Fossil|Insect)\b/i, act:'umbrella:science'},
    {re:/\b(Bible|Saints|Angels|Early Church|Gospel|Apostles|Catholic|Sacred|Chapel|Scripture)\b/i, act:'umbrella:bible'},
    {re:/\b(Creative|Art|Drawing|Painting|Music|Theater|Craft|Pattern|Story Maker|Gallery|Dragonbrush|Bardwood)\b/i, act:'umbrella:creative'},
    {re:/\b(Homestead|Life Skills|Cooking|Kitchen|Repair|Tools|Farm|Garden|Companion|Pet Corner|Collection Log|Quest Board|Town Notice|Living World|Seasons|Festival|Birthday|Shopkeepers|Merchant|Rare Finds|Home View|Expand Home)\b/i, act:'umbrella:homestead'}
  ];

  function umbrellaByKey(key){
    for(var i=0;i<UMBRELLAS.length;i++) if(UMBRELLAS[i].key === key) return UMBRELLAS[i];
    return null;
  }
  function statusFor(u){
    if(!u) return 'Unknown';
    for(var i=0;i<u.calls.length;i++){
      var c = u.calls[i];
      var name = Array.isArray(c) ? c[0] : c;
      if(has(name)) return 'Connected';
    }
    return 'Fallback';
  }
  function card(u){
    var st = statusFor(u);
    return '<button class="lr75uCard ' + (st === 'Connected' ? 'ok' : 'warn') + '" data-lr75u-act="umbrella:' + esc(u.key) + '">' +
      '<span class="lr75uIcon">' + esc(u.icon) + '</span>' +
      '<span><b>' + esc(u.title) + '</b><small>' + esc(u.small) + '</small><p>' + esc(u.body) + '</p><em>' + esc(u.cleanup + ' · ' + st) + '</em></span>' +
      '<i>Open ›</i>' +
    '</button>';
  }
  function renderMap(){
    var connected = UMBRELLAS.filter(function(u){ return statusFor(u) === 'Connected'; }).length;
    actionMount('🧭 World Directory Verification',
      '<div class="lr75uShell">' +
        '<div class="lr75uHero"><div class="lr75uHeroIcon">🧭</div><div><h2>World Directory / Umbrella Verification</h2><p>This is a small verification bridge after 7.5P–7.5T. Every big subject is treated as part of a larger place instead of a scattered school-menu button. The cards below open the safest connected map or annex for each umbrella.</p><small>' + connected + ' / ' + UMBRELLAS.length + ' umbrellas have live connected routes</small></div></div>' +
        '<div class="lr75uGrid">' + UMBRELLAS.map(card).join('') + '</div>' +
        '<div class="lr75uPanel"><h3>Cleanup rule now applied</h3><p>Visible subject shortcuts should lead into one of these umbrellas. When an older loose button is spotted, this patch turns it into an umbrella doorway instead of letting it open a confusing old shelf or dead popup.</p><p>No new course content was added here. This pass is only routing, verification, and safer doorway behavior.</p></div>' +
        '<div class="lr75uFooter">' + navButton('Realm Library','library') + navButton('7.5O Connection Ledger','ledger') + navButton('Scan visible window','scan') + '</div>' +
      '</div>'
    );
  }
  function renderScan(){
    var root = $('actionText') || $('lrPopupBody') || document.body;
    var buttons = Array.prototype.slice.call(root.querySelectorAll ? root.querySelectorAll('button') : []);
    var counts = {core:0,history:0,science:0,bible:0,creative:0,homestead:0,other:0};
    var samples = [];
    buttons.forEach(function(btn){
      var text = (btn.textContent || '').replace(/\s+/g,' ').trim();
      if(!text || text.length > 120) return;
      var hit = null;
      for(var i=0;i<LOOSE_ROUTES.length;i++) if(LOOSE_ROUTES[i].re.test(text)){ hit = LOOSE_ROUTES[i].act.split(':')[1]; break; }
      if(hit) counts[hit]++; else counts.other++;
      if(samples.length < 16) samples.push((hit ? hit : 'other') + ': ' + text);
    });
    var rows = UMBRELLAS.map(function(u){ return '<tr><td>' + esc(u.icon + ' ' + u.title) + '</td><td>' + (counts[u.key] || 0) + '</td><td>' + esc(statusFor(u)) + '</td></tr>'; }).join('') + '<tr><td>Other / system buttons</td><td>' + counts.other + '</td><td>left alone</td></tr>';
    actionMount('🧭 Visible Window Scan',
      '<div class="lr75uShell"><div class="lr75uHero"><div class="lr75uHeroIcon">🔎</div><div><h2>Visible Window Scan</h2><p>This quick surface scan looks only at the currently open popup/window and classifies visible buttons by umbrella. It does not rewrite lessons or rebuild the shell.</p></div></div>' +
      '<table class="lr75uTable"><thead><tr><th>Umbrella</th><th>Detected buttons</th><th>Route state</th></tr></thead><tbody>' + rows + '</tbody></table>' +
      '<div class="lr75uPanel"><h3>Sample visible labels</h3><p>' + esc(samples.length ? samples.join(' · ') : 'No visible buttons were found in the current action window.') + '</p></div>' +
      '<div class="lr75uFooter">' + navButton('Verification Map','map') + navButton('Realm Library','library') + '</div></div>'
    );
  }
  function openUmbrella(key){
    var u = umbrellaByKey(key);
    if(!u){ renderMap(); return; }
    if(callFirst(u.calls)) return;
    softNote(u.title, 'This umbrella is recognized by the verification pass, but its direct route did not answer. Open the Realm Library or Connection Ledger to reach its parent wing.', [['Realm Library','library'],['Connection Ledger','ledger'],['Verification Map','map']]);
  }
  function openLibrary(){
    if(callFirst(['openRealmLibrary75A','openRealmLibrary75B','openRealCurriculumPicker'])) return;
    softNote('Realm Library', 'The Realm Library opener did not answer in this build.', [['Verification Map','map']]);
  }
  function openLedger(){
    if(callFirst(['openLearningCenterConnectionAudit75O','openLearningCenterAudit75O'])) return;
    softNote('Connection Ledger', 'The 7.5O Connection Ledger opener did not answer in this build.', [['Verification Map','map'],['Realm Library','library']]);
  }
  function handleAct(act){
    if(!act) return;
    if(act === 'map'){ renderMap(); return; }
    if(act === 'library'){ openLibrary(); return; }
    if(act === 'ledger'){ openLedger(); return; }
    if(act === 'scan'){ renderScan(); return; }
    if(act.indexOf('umbrella:') === 0){ openUmbrella(act.split(':')[1]); return; }
  }

  function installStyles(){
    if($('lr75uStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr75uStyles';
    st.textContent =
      '.lr75uShell{font-family:inherit;color:#f7ecd0;display:grid;gap:14px;max-width:1120px;margin:0 auto;padding:12px}.lr75uHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;border:1px solid rgba(244,209,134,.35);border-radius:18px;background:linear-gradient(135deg,rgba(70,38,12,.92),rgba(20,47,43,.88));box-shadow:0 18px 40px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.08)}' +
      '.lr75uHeroIcon,.lr75uIcon{width:54px;height:54px;border-radius:16px;display:grid;place-items:center;font-size:1.8rem;background:rgba(255,240,190,.13);border:1px solid rgba(255,231,165,.36)}.lr75uHero h2{margin:0 0 6px;color:#fff5cf}.lr75uHero p{margin:0;color:#e9dcc0;line-height:1.48}.lr75uHero small{display:block;margin-top:8px;color:#aee8d0;font-weight:900;text-transform:uppercase;letter-spacing:.05em}' +
      '.lr75uGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:12px}.lr75uCard{cursor:pointer;text-align:left;color:#f7ecd0;border:1px solid rgba(244,209,134,.30);border-radius:16px;background:linear-gradient(145deg,rgba(14,31,31,.94),rgba(47,31,18,.92));box-shadow:0 10px 24px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.07);display:grid;grid-template-columns:auto 1fr auto;gap:12px;padding:14px;align-items:start;min-height:150px}' +
      '.lr75uCard:hover,.lr75uSmallBtn:hover{transform:translateY(-1px);filter:brightness(1.04)}.lr75uCard b{display:block;color:#fff2bd;font-size:1.03rem;margin-bottom:3px}.lr75uCard small{display:block;color:#aee8d0;font-size:.73rem;text-transform:uppercase;letter-spacing:.05em;font-weight:900;margin-bottom:6px}.lr75uCard p{margin:0;color:#dcccae;line-height:1.42;font-size:.92rem}.lr75uCard em{display:block;color:#ffe49c;font-style:normal;font-weight:900;margin-top:8px;font-size:.82rem}.lr75uCard i{font-style:normal;color:#ffe49c;font-weight:900;align-self:center;white-space:nowrap}.lr75uCard.ok{border-color:rgba(174,232,208,.45)}.lr75uCard.warn{border-color:rgba(255,212,132,.48)}' +
      '.lr75uPanel,.lr75uNote{border:1px solid rgba(244,209,134,.26);border-radius:16px;background:rgba(0,0,0,.23);padding:14px;color:#eadcbd}.lr75uPanel h3{margin:0 0 7px;color:#fff2bd}.lr75uPanel p,.lr75uNote p{line-height:1.48;margin:.35rem 0}.lr75uNote b{color:#fff2bd}.lr75uFooter,.lr75uInlineBtns{display:flex;flex-wrap:wrap;gap:10px;align-items:center}.lr75uSmallBtn{border:1px solid rgba(255,232,166,.34);border-radius:999px;background:rgba(255,231,165,.12);color:#fff3cf;font-weight:900;padding:9px 13px;cursor:pointer}.lr75uTable{width:100%;border-collapse:separate;border-spacing:0;border:1px solid rgba(244,209,134,.25);border-radius:14px;overflow:hidden;background:rgba(0,0,0,.20);color:#f7ecd0}.lr75uTable th,.lr75uTable td{padding:10px;border-bottom:1px solid rgba(244,209,134,.16);text-align:left}.lr75uTable th{color:#fff2bd;background:rgba(255,231,165,.08)}.lr75uStrip{margin:10px 0;border:1px solid rgba(174,232,208,.35);border-radius:14px;background:rgba(10,34,30,.74);color:#f7ecd0;padding:12px}.lr75uStrip b{display:block;color:#fff2bd;margin-bottom:4px}.lr75uStrip p{margin:0 0 8px;line-height:1.4;color:#e9dcc0}.lr75uRouteLocked{outline:2px solid rgba(174,232,208,.28)!important;outline-offset:2px}.lr75uRouteTiny{display:block;color:#aee8d0;font-size:.78rem;font-weight:900;margin-top:4px}' +
      '@media(max-width:900px){.lr75uHero,.lr75uCard{grid-template-columns:1fr}.lr75uCard i{justify-self:start}.lr75uHeroIcon,.lr75uIcon{width:44px;height:44px}}';
    document.head.appendChild(st);
  }

  function stripHtml(){
    return '<div class="lr75uStrip" id="lr75uDirectoryStrip"><b>🧭 7.5U World Directory verification</b><p>Core Halls, History and World, Science and Engineering, Bible Road, Creative Quarter, and Homestead/Living World are checked as umbrella places. Use this if an old subject button feels loose or confusing.</p><div class="lr75uInlineBtns">' + navButton('Open Verification Map','map') + navButton('Connection Ledger','ledger') + '</div></div>';
  }
  function injectStrip(root){
    if(!root || $('lr75uDirectoryStrip')) return;
    var text = root.textContent || '';
    if(!/Realm Library|Connection Ledger|Core Halls|History and World|Science and Engineering|Bible Road|Creative Quarter|Homestead|World Directory/i.test(text)) return;
    var anchor = root.querySelector('.lr75aHero,.lr75oHero,.lr75aLibrary,.lr75oShell') || root.firstElementChild;
    if(!anchor) return;
    var holder = document.createElement('div');
    holder.innerHTML = stripHtml();
    var strip = holder.firstElementChild;
    if(anchor.classList && (anchor.classList.contains('lr75aLibrary') || anchor.classList.contains('lr75oShell'))){
      anchor.insertBefore(strip, anchor.children[1] || null);
    }else if(anchor.parentNode){
      anchor.parentNode.insertBefore(strip, anchor.nextSibling);
    }
  }
  function insideLesson(btn){
    return !!(btn.closest && btn.closest('.lrCleanLessonWindow,.lrCleanTestWindow,.lr74oTopic,.lr75qTopic,.lr75mTopic,.lr75cLesson,.lr75dLesson,.lr75eLesson,.lr75fLesson'));
  }
  function routeLooseButtons(root){
    if(!root || !root.querySelectorAll) return;
    var buttons = Array.prototype.slice.call(root.querySelectorAll('button'));
    buttons.forEach(function(btn){
      if(btn.hasAttribute('data-lr75u-act') || insideLesson(btn)) return;
      if(btn.hasAttribute('data-lr75a-act') || btn.hasAttribute('data-lr75o-act')) return;
      if(btn.hasAttribute('data-lr75p-act') || btn.hasAttribute('data-lr75q-act') || btn.hasAttribute('data-lr75r-act') || btn.hasAttribute('data-lr75s-act') || btn.hasAttribute('data-lr75t-act')) return;
      var text = (btn.textContent || '').replace(/\s+/g,' ').trim();
      if(!text || text.length > 120) return;
      if(/Back|Previous|Next|Check|Submit|Quiz|Answer|Continue|Close|Exit|Start Lesson|Take Quiz|Review Missed|Reward Catalog|All studios|All labs|All rooms|All wings/i.test(text)) return;
      for(var i=0;i<LOOSE_ROUTES.length;i++){
        if(LOOSE_ROUTES[i].re.test(text)){
          btn.setAttribute('data-lr75u-act', LOOSE_ROUTES[i].act);
          /* 7.6W: preserve onclick fallback */
          btn.classList.add('lr75uRouteLocked');
          if(!btn.querySelector('.lr75uRouteTiny') && !/lr75aDoorCard|lr75aWingCard|lr75oDoor|lr75uCard/.test(btn.className || '')){
            var span = document.createElement('span');
            span.className = 'lr75uRouteTiny';
            span.textContent = 'Routed through umbrella map';
            btn.appendChild(span);
          }
          break;
        }
      }
    });
  }
  function runInject(){
    installStyles();
    var roots = [$('actionText'), $('lrPopupBody')].filter(function(x){ return !!x; });
    for(var i=0;i<roots.length;i++){
      injectStrip(roots[i]);
      routeLooseButtons(roots[i]);
    }
  }
  function scheduleInject(){
    if(injectTimer) clearTimeout(injectTimer);
    injectTimer = setTimeout(runInject, 90);
  }
  function wrap(name){
    if(!has(name) || window[name].__lr75uWrapped) return;
    var old = window[name];
    var wrapped = function(){
      var out = old.apply(this, arguments);
      scheduleInject();
      setTimeout(scheduleInject, 250);
      return out;
    };
    wrapped.__lr75uWrapped = true;
    window[name] = wrapped;
  }
  function bind(){
    if(window.__LR75U_BOUND__) return;
    window.__LR75U_BOUND__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('[data-lr75u-act]') : null;
      if(!btn) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      handleAct(btn.getAttribute('data-lr75u-act'));
    }, true);
  }
  function installObserver(){
    if(observerInstalled) return;
    observerInstalled = true;
    if(typeof MutationObserver === 'undefined') return;
    try{
      var mo = new MutationObserver(function(){ scheduleInject(); });
      if($('actionText')) mo.observe($('actionText'), {childList:true, subtree:false});
      if($('lrPopupBody')) mo.observe($('lrPopupBody'), {childList:true, subtree:false});
    }catch(e){}
  }
  function init(){
    installStyles();
    bind();
    ['openRealmLibrary75A','openRealmLibrary75B','openRealCurriculumPicker','openLearningCenterConnectionAudit75O','openLearningCenterAnnex75O','openCoreHallsConnectionCleanup75P','openBibleRoadCleanup75Q','openScienceEngineeringConnectionCleanup75R','openCreativeQuarterConnectionCleanup75S','openHomesteadLivingWorldConnectionCleanup75T'].forEach(wrap);
    installObserver();
    setTimeout(scheduleInject, 260);
    window.LR_WORLD_DIRECTORY_UMBRELLA_VERIFICATION_75U = { patch:PATCH, open:renderMap, umbrellas:UMBRELLAS };
  }

  window.openWorldDirectoryVerification75U = renderMap;
  window.openUmbrellaVerification75U = renderMap;
  window.openLearningRealmsWorldDirectory75U = renderMap;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
