/* LearningRealms Dynamic Interface Cleanup + Route QA 6.8C
   Stability-only patch. Keeps content intact while smoothing the dynamic shell transition.
   Goals: one main screen, popup-only lessons/quizzes/rewards, cleaner route bridges, and stronger UI consistency.
*/
(function(){
  'use strict';
  if(window.__LR68C_DYNAMIC_INTERFACE_CLEANUP__) return;
  window.__LR68C_DYNAMIC_INTERFACE_CLEANUP__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function clean(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){ try{ if(window.state) return window.state; }catch(e){} try{ if(typeof state !== 'undefined') return state; }catch(e){} return null; }
  function getRooms(){ try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){} try{ if(typeof ROOMS !== 'undefined') return ROOMS; }catch(e){} return {}; }
  function loc(){ var s=getState(); return (s && s.loc) ? s.loc : 'crossroads'; }
  function room(id){ var rooms=getRooms(); return rooms[id || loc()] || rooms.crossroads || {}; }
  function call(name){
    var args=Array.prototype.slice.call(arguments,1);
    try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR68C call failed', name, e); }
    return undefined;
  }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }

  function ensureMount(){
    try{
      document.body.classList.add('lrDynamicAdventureMode','lr68DynamicShell','lr68aHardening','lr68bLearningTrails','lr68cInterfaceCleanup');
      document.body.classList.remove('homeMode');
    }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var first = document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; main.style.maxWidth='none'; main.style.minWidth='0'; }
      if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; first.style.minWidth='0'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen lr68cScreen';
      if(first && first.firstChild) first.insertBefore(mount, first.firstChild);
      else (first || document.body).appendChild(mount);
    }
    try{
      mount.classList.add('lr68cScreen');
      mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1';
      mount.style.width='100%'; mount.style.maxWidth='none'; mount.style.minHeight='660px';
    }catch(e){}
    return mount;
  }

  function isLearningPopupTitle(t){
    t = String(t || '').toLowerCase();
    return /lesson|quiz|result|reward|course|guided|shipwreck|invention|creative|egypt|england|reading|math|writing|science|review|mastery|learn|trail/.test(t);
  }
  function popupRoot(){ return byId('lrPopupRoot') || document.querySelector('.popup,.modal,.overlay'); }
  function popupTitle(){ var t=byId('lrPopupTitle'); return t ? (t.textContent || '') : ''; }
  function popupBody(){ return byId('lrPopupBody') || document.querySelector('.lrPopupBody,.popupBody,.modalBody'); }
  function popupOpen(){
    var root=popupRoot();
    if(!root) return false;
    if(root.classList && root.classList.contains('hidden')) return false;
    try{ var cs=getComputedStyle(root); if(cs.display==='none' || cs.visibility==='hidden' || cs.opacity==='0') return false; }catch(e){}
    return true;
  }
  function hideNonLearningPopup(){
    try{
      if(!popupOpen()) return;
      var title = popupTitle();
      if(isLearningPopupTitle(title)) return;
      var root=popupRoot();
      if(root && root.classList) root.classList.add('hidden');
      if(root){ root.style.display='none'; root.style.visibility='hidden'; }
    }catch(e){}
  }

  function suppressLegacySurfaces(){
    var ids = ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','movementControls','leftActionButtons'];
    ids.forEach(function(id){
      var el=byId(id);
      if(el){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
    });
    try{
      document.querySelectorAll('.compassBox,.compassGrid,.movementButtons,.travelButtons,.tinyTravelFooter,.lrAdventurePanel,.lrExplorePanel,.lr65ExplorePanel,.lr66AdventureChoiceNav,.lr66AdventureNav,.lr67ChoicePanelClone,[data-lr-legacy-nav],[data-old-navigation]').forEach(function(el){
        if(el.closest && (el.closest('#lrDynamicAdventureScreen') || el.closest('#lrPopupRoot'))) return;
        el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden';
      });
    }catch(e){}
  }

  function mainActionHtml(title, bodyHtml, note){
    return '<section class="lr68cEmbeddedTop">' +
      '<div><span class="lr68cKicker">Main screen panel</span><h1>' + esc(title || 'LearningRealms') + '</h1>' +
      (note ? '<p>' + esc(note) + '</p>' : '<p>This tool now stays inside the main adventure screen, so the old panels cannot hide the room view.</p>') + '</div>' +
      '<button type="button" onclick="lr68Render && lr68Render(\'room\',\'You return to the current scene.\')">Return to scene</button>' +
    '</section><section class="lr68cEmbeddedBody"><div class="lr68ActionHost">' + (bodyHtml || '<div class="lr68Quiet">This panel is ready.</div>') + '</div></section>';
  }

  function captureActionText(title, note){
    var mount = ensureMount();
    var action = byId('actionText');
    var atitle = byId('actionTitle');
    var html = action ? String(action.innerHTML || '').trim() : '';
    var plain = action ? String(action.textContent || '').trim() : '';
    if(!html || /Choose an action to begin/i.test(plain)){
      if(window.LR68 && typeof window.LR68.embed === 'function'){
        try{ window.LR68.embed(title || (atitle ? atitle.textContent : 'Action'), note || 'That panel is ready in the dynamic screen.'); return true; }catch(e){}
      }
      mount.innerHTML = mainActionHtml(title || 'Action', '<div class="lr68Quiet">That panel did not return visible content, but the dynamic screen stayed open.</div>', note);
      return true;
    }
    mount.innerHTML = mainActionHtml(title || (atitle ? atitle.textContent : 'Action'), html, note);
    return true;
  }

  function renderRoom(note){
    ensureMount(); suppressLegacySurfaces();
    try{ if(window.LR68 && typeof window.LR68.render === 'function') return window.LR68.render('room', note); }catch(e){}
    try{ if(typeof window.lr68Render === 'function') return window.lr68Render('room', note); }catch(e){}
    return false;
  }
  function travel(targetOrKey){
    ensureMount(); suppressLegacySurfaces();
    try{ if(window.LR68A && typeof window.LR68A.travel === 'function') return window.LR68A.travel(targetOrKey); }catch(e){}
    try{ if(window.LR68 && typeof window.LR68.travel === 'function') return window.LR68.travel(targetOrKey); }catch(e){}
    try{ if(window.__LR68C_OLD_TRAVEL__ && window.__LR68C_OLD_TRAVEL__ !== travel) return window.__LR68C_OLD_TRAVEL__(targetOrKey); }catch(e){}
    renderRoom('That path is being protected by the dynamic shell.');
    return false;
  }
  function goTo(target){
    var rooms=getRooms();
    if(!rooms[target]){ renderRoom('That learning path is not loaded yet.'); return false; }
    try{ if(window.LR68A && typeof window.LR68A.goTo === 'function') return window.LR68A.goTo(target); }catch(e){}
    var s=getState(); if(s){ s.loc=target; s.room=Math.max(1,Number(s.room||1))+1; }
    save(); stats();
    renderRoom('You follow the descriptive path to ' + clean((rooms[target] && rooms[target].title) || target) + '.');
    return false;
  }

  function wrapFunction(name, title){
    try{
      var old = window[name];
      if(typeof old !== 'function' || old.__lr68cWrapped) return;
      var wrapped = function(){
        ensureMount(); suppressLegacySurfaces();
        var out;
        try{ out = old.apply(this, arguments); }
        catch(e){
          renderRoom((title || name) + ' was blocked before it could hide the screen: ' + (e.message || e));
          return false;
        }
        setTimeout(function(){
          try{
            if(popupOpen() && !isLearningPopupTitle(popupTitle())) hideNonLearningPopup();
            if(!popupOpen() || !isLearningPopupTitle(popupTitle())) captureActionText(title || name);
          }catch(e){ renderRoom(); }
          suppressLegacySurfaces();
        }, 45);
        setTimeout(function(){ ensureMount(); suppressLegacySurfaces(); }, 180);
        return out;
      };
      wrapped.__lr68cWrapped = true;
      wrapped.__lr68cOld = old;
      window[name] = wrapped;
      try{ eval(name + ' = window["' + name + '"];'); }catch(e){}
    }catch(e){}
  }

  function installActionBridges(){
    [
      ['openHomeView','Home Hearth'],['openHomeRooms','Home Rooms'],['openLivingHome','Living Home'],['openVisibleHome','Home View'],['openVisualHome','Home View'],['openHomeExpansion2','Expand Home'],['openHomeDecor','Home Decor'],['openHomePlacement','Home Placement'],
      ['lrSafeStorageChest','Storage Chest'],['chest','Storage Chest'],['openBackpack','Backpack'],['openInventoryPopup','Inventory'],['openWardrobe','Wardrobe'],
      ['openCollectionLog','Collection Log'],['openCompanionDen','Companion Den'],['openPetJournal','Pet Journal'],['lrSafeOpenPetJournal','Pet Journal'],['openNpcRelations','Realm Friends'],
      ['openWorldAtlas','World Atlas'],['openWorldDirectory','World Directory'],['openLandmarkJournal','Landmarks'],['openJourneyWorld','Journey World'],
      ['openQuestBoard','Quest Board'],['openQuestJournal','Quest Journal'],['lrSafeOpenQuestJournal','Quest Journal'],['openLongQuestJournal','Long Quest Journal'],['lrSafeOpenLongQuestJournal','Long Quest Journal'],['openStoryQuestJournal','Story Quests'],['openStoryCampaigns','Story Campaigns'],
      ['openSeasonalCalendar','Season Calendar'],['openSeasonHall','Season Hall'],['openSeasonQuests','Season Quests'],['openSeasonalVendor','Season Vendor'],['openSeasonalSearch','Season Search'],
      ['openMuseumHall','Museum Hall'],['openMuseumRenderer','Museum Hall'],['openCraftingRenderer','Crafting'],['openCraftingStation','Crafting'],['openCastlePrestige','Prestige'],
      ['openStudentJournal','Learning Log'],['openEventLog','Event Log'],['openReportCenter','Report Center'],['openMasteryPaths','Mastery Paths'],['openAdaptiveReview','Adaptive Review'],['openBossGauntlets','Boss Gauntlets'],['showMasteryStatus','Mastery Status'],['startBossChallenge','Realm Boss'],['openSystemHealth','System Health'],['openInvestigationBoard','Investigation Board'],
      ['openShopHub','Shop Lantern Hub'],['lrSafeBrowseShopPopup','Shop Shelves']
    ].forEach(function(pair){ wrapFunction(pair[0], pair[1]); });
  }

  function installLearningRoutes(){
    if(!window.__LR68C_OLD_OPEN_LEARN__ && typeof window.lr68OpenLearn === 'function') window.__LR68C_OLD_OPEN_LEARN__ = window.lr68OpenLearn;
    window.lr68OpenLearn = function(){
      ensureMount(); suppressLegacySurfaces();
      try{ if(typeof window.lr68bOpenLearningTrails === 'function') return window.lr68bOpenLearningTrails('featured'); }catch(e){}
      try{ if(window.__LR68C_OLD_OPEN_LEARN__) return window.__LR68C_OLD_OPEN_LEARN__.call(window); }catch(e){}
      return renderRoom('The Learning Trails board could not open, but the adventure screen stayed visible.');
    };
    try{ lr68OpenLearn = window.lr68OpenLearn; }catch(e){}
    if(window.LR68) window.LR68.learn = window.lr68OpenLearn;

    if(!window.__LR68C_OLD_TRAVEL__ && typeof window.lr68Travel === 'function') window.__LR68C_OLD_TRAVEL__ = window.lr68Travel;
    window.lr68Travel = travel;
    try{ lr68Travel = window.lr68Travel; }catch(e){}

    window.lr68cGoTo = goTo;
    window.lr68cRenderRoom = renderRoom;
  }

  function routeQaHtml(){
    var rooms=getRooms();
    var checks = [
      ['Dynamic screen exists', !!byId('lrDynamicAdventureScreen')],
      ['Go Learn opens Learning Trails', typeof window.lr68OpenLearn === 'function'],
      ['Home bridge available', typeof window.lr68OpenHome === 'function' || typeof window.openHomeView === 'function'],
      ['Shop bridge available', typeof window.openShop === 'function' || typeof window.openShopHub === 'function' || typeof window.lrSafeBrowseShopPopup === 'function'],
      ['Storage bridge available', typeof window.lrSafeStorageChest === 'function' || typeof window.chest === 'function'],
      ['Pets/companions bridge available', typeof window.openCompanionDen === 'function' || typeof window.openPetJournal === 'function'],
      ['Wardrobe bridge available', typeof window.openWardrobe === 'function'],
      ['Shipwreck guided zone loaded', typeof window.shipwreckGuidedZoneOpen === 'function'],
      ['Inventions course loaded', typeof window.openInventionsDeepCourse === 'function'],
      ['Creative Studio course loaded', typeof window.openCreativeStudioCourse === 'function'],
      ['Crossroads room loaded', !!rooms.crossroads]
    ];
    return '<div class="lr68cQaGrid">' + checks.map(function(c){
      return '<div class="lr68cQaItem ' + (c[1] ? 'ok' : 'warn') + '"><b>' + (c[1] ? '✓' : '!') + ' ' + esc(c[0]) + '</b><small>' + (c[1] ? 'Ready' : 'Not detected') + '</small></div>';
    }).join('') + '</div>';
  }
  function openRouteQa(){
    var mount=ensureMount(); suppressLegacySurfaces();
    mount.innerHTML = '<section class="lr68cEmbeddedTop"><div><span class="lr68cKicker">Route QA</span><h1>Dynamic shell route check</h1><p>This is a safe check panel. It does not change saves or add content. It simply confirms that the major bridge points are loaded.</p></div><button type="button" onclick="lr68Render && lr68Render(\'room\',\'Route check closed.\')">Return to scene</button></section><section class="lr68cEmbeddedBody">' + routeQaHtml() + '</section>';
    return false;
  }
  function addQaButtonToTrails(){
    try{
      var foot=document.querySelector('.lr68bFooter');
      if(!foot || foot.querySelector('[data-lr68c-route-qa]')) return;
      var btn=document.createElement('button');
      btn.type='button'; btn.setAttribute('data-lr68c-route-qa','1');
      btn.textContent='Run route check';
      btn.onclick=function(){ return openRouteQa(); };
      foot.appendChild(btn);
    }catch(e){}
  }

  function normalizeVisibleText(){
    try{
      document.querySelectorAll('#lrDynamicAdventureScreen button').forEach(function(btn){
        if(btn.textContent && btn.textContent.trim().length < 2) btn.style.display='none';
      });
    }catch(e){}
  }

  function injectStyles(){
    if(byId('lr68cInterfaceCleanupStyle')) return;
    var st=document.createElement('style');
    st.id='lr68cInterfaceCleanupStyle';
    st.textContent = `
      body.lr68cInterfaceCleanup main{display:grid !important;grid-template-columns:minmax(0,1fr) 270px !important;gap:16px !important;align-items:start !important;width:100% !important;max-width:none !important;}
      body.lr68cInterfaceCleanup .main{display:block !important;width:100% !important;max-width:none !important;min-width:0 !important;}
      body.lr68cInterfaceCleanup .main > .card:first-child{width:100% !important;max-width:none !important;min-width:0 !important;overflow:hidden !important;padding:0 !important;}
      body.lr68cInterfaceCleanup #lrDynamicAdventureScreen{width:100% !important;max-width:none !important;min-height:660px !important;display:block !important;visibility:visible !important;opacity:1 !important;}
      body.lr68cInterfaceCleanup #roomTitle,body.lr68cInterfaceCleanup #roomText,body.lr68cInterfaceCleanup #mainCompassNav,body.lr68cInterfaceCleanup #mainGameplayActions,body.lr68cInterfaceCleanup #leftActionButtons{display:none !important;visibility:hidden !important;height:0 !important;max-height:0 !important;overflow:hidden !important;}
      body.lr68cInterfaceCleanup .compassBox,body.lr68cInterfaceCleanup .compassGrid,body.lr68cInterfaceCleanup .movementButtons,body.lr68cInterfaceCleanup .travelButtons,body.lr68cInterfaceCleanup .tinyTravelFooter,body.lr68cInterfaceCleanup .lrAdventurePanel,body.lr68cInterfaceCleanup .lrExplorePanel,body.lr68cInterfaceCleanup .lr65ExplorePanel,body.lr68cInterfaceCleanup .lr66AdventureNav{display:none !important;visibility:hidden !important;height:0 !important;max-height:0 !important;overflow:hidden !important;}
      body.lr68cInterfaceCleanup #lrDynamicAdventureScreen .lr68ChoicePanel,body.lr68cInterfaceCleanup #lrDynamicAdventureScreen .lr68ActionStrip,body.lr68cInterfaceCleanup #lrDynamicAdventureScreen .lr68EmbeddedPanel,body.lr68cInterfaceCleanup #lrDynamicAdventureScreen .lr68bTrailGrid{max-width:none !important;}
      body.lr68cInterfaceCleanup #lrDynamicAdventureScreen button:not(.lr68bTrailCard):not(.lr68ChoiceCard){min-height:42px;border-radius:14px;font-weight:900;}
      .lr68cEmbeddedTop{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;padding:26px 30px;background:linear-gradient(135deg,rgba(15,44,60,.98),rgba(31,76,65,.94));border-bottom:1px solid rgba(255,227,160,.22);color:#fff5d2;}
      .lr68cEmbeddedTop h1{margin:6px 0 8px;font-size:clamp(1.8rem,3vw,2.7rem);line-height:1.05;color:#fff8dc;}.lr68cEmbeddedTop p{max-width:900px;margin:0;color:#e7f1d7;font-weight:760;line-height:1.5;}.lr68cKicker{font-weight:950;text-transform:uppercase;letter-spacing:.09em;color:#ffdf87;font-size:.76rem;}
      .lr68cEmbeddedTop button{background:#fff2c8;color:#193b32;border:1px solid rgba(255,227,160,.44);padding:10px 14px;border-radius:999px;font-weight:950;cursor:pointer;white-space:nowrap;}
      .lr68cEmbeddedBody{padding:22px 28px 30px;background:linear-gradient(180deg,rgba(242,252,239,.96),rgba(225,241,234,.96));color:#17352d;min-height:420px;}.lr68cEmbeddedBody button{background:#fffdf3;color:#17352d;border:1px solid rgba(19,75,65,.22);padding:10px 12px;box-shadow:0 6px 12px rgba(0,0,0,.10);}
      .lr68cEmbeddedBody .journalPage,.lr68cEmbeddedBody .journalBook,.lr68cEmbeddedBody .lessonCard,.lr68cEmbeddedBody .card{color:#17352d !important;background:#fffdf3 !important;border-radius:18px !important;border:1px solid rgba(19,75,65,.18) !important;padding:16px !important;box-shadow:0 8px 16px rgba(0,0,0,.10) !important;}
      .lr68cQaGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;}.lr68cQaItem{border-radius:16px;padding:14px;background:#fffdf3;border:1px solid rgba(19,75,65,.18);box-shadow:0 7px 14px rgba(0,0,0,.10);}.lr68cQaItem b{display:block;color:#183a32;}.lr68cQaItem small{font-weight:850;color:#526a61;}.lr68cQaItem.ok{border-left:6px solid #2f745d;}.lr68cQaItem.warn{border-left:6px solid #b97a20;}
      body.lr68cInterfaceCleanup .lrPopupWindow,body.lr68cInterfaceCleanup body .lrPopupWindow{width:min(1180px,96vw) !important;max-height:94vh !important;}.lrPopupBody,#lrPopupBody{font-size:1.07rem !important;line-height:1.62 !important;}.lrPopupBody p,#lrPopupBody p{line-height:1.62 !important;}
      @media(max-width:950px){body.lr68cInterfaceCleanup main{grid-template-columns:1fr !important}.lr68cEmbeddedTop{flex-direction:column;padding:20px 16px}.lr68cEmbeddedBody{padding:16px}.lr68cEmbeddedTop button{white-space:normal}}
    `;
    document.head.appendChild(st);
  }

  function postProcess(){
    ensureMount(); suppressLegacySurfaces(); normalizeVisibleText(); addQaButtonToTrails(); hideNonLearningPopup();
  }

  function watchdog(){
    try{
      postProcess();
      var mount=byId('lrDynamicAdventureScreen');
      var bad=!mount || !String(mount.innerHTML||'').trim();
      if(mount && window.getComputedStyle){ var cs=getComputedStyle(mount); if(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0') bad=true; }
      if(bad) renderRoom('The dynamic screen restored itself after an older panel tried to hide it.');
    }catch(e){}
  }

  function boot(){
    injectStyles(); ensureMount(); installActionBridges(); installLearningRoutes(); postProcess();
    setTimeout(postProcess,60); setTimeout(postProcess,220); setTimeout(postProcess,700);
    if(!window.__LR68C_WATCHDOG_TIMER__) window.__LR68C_WATCHDOG_TIMER__ = setInterval(watchdog, 700);
  }

  window.lr68cOpenRouteQA = openRouteQa;
  window.LR68C = {mount:ensureMount, post:postProcess, qa:openRouteQa, goTo:goTo, travel:travel, render:renderRoom, capture:captureActionText};

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(boot,120); setTimeout(boot,520); });
  else { setTimeout(boot,120); setTimeout(boot,520); }
  window.addEventListener('load', function(){ setTimeout(boot,250); setTimeout(watchdog,900); });
})();
