// Curriculum Pack 5A: Rich Teaching Lessons
// First full pack built for Teaching Encounter Engine v1.
// Rich format: miniLesson, workedExample, guidedPractice, q, choices, answer, explain.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"make ten",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Making ten helps you add faster because ten is easy to work with.",
  workedExample:"9 + 6 can become 10 + 5. The 9 needs 1 to make 10. Take 1 from the 6, leaving 5. Now the problem is 10 + 5.",
  guidedPractice:"Ask yourself: What does the first number need to become 10?",
  q:"9 + 6 = ?",
  c:["15","14","16"],a:"15",
  explain:"9 needs 1 to become 10. The 6 becomes 5. So 10 + 5 = 15."},

 {unit:"G1-MATH-FACTS",skill:"subtraction within 20",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Subtraction can be checked with addition.",
  workedExample:"14 - 6 = 8 because 8 + 6 = 14. The addition fact helps prove the subtraction fact.",
  guidedPractice:"After subtracting, add your answer back to the number you took away.",
  q:"14 - 6 = ?",
  c:["8","7","9"],a:"8",
  explain:"8 + 6 = 14, so 14 - 6 = 8."},

 {unit:"G1-MATH-PLACE",skill:"tens and ones",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Two-digit numbers are made of tens and ones.",
  workedExample:"47 has 4 tens and 7 ones. The 4 is in the tens place, so it means 40. The 7 is in the ones place, so it means 7.",
  guidedPractice:"Look at the first digit for tens and the second digit for ones.",
  q:"How many tens are in 47?",
  c:["4","7","47"],a:"4",
  explain:"The 4 is in the tens place, so 47 has 4 tens."},

 {unit:"G1-MATH-MEASURE",skill:"coins",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Coins have different values. A dime is 10 cents and a nickel is 5 cents.",
  workedExample:"One dime plus one nickel is 10 + 5. That equals 15 cents.",
  guidedPractice:"Count the dime first, then add the nickel.",
  q:"A dime and a nickel make...",
  c:["15 cents","10 cents","5 cents"],a:"15 cents",
  explain:"A dime is 10 cents and a nickel is 5 cents. 10 + 5 = 15."}
]);

LR_addLessons("Luna","Reading",[
 {unit:"G1-READ-PHONICS",skill:"short vowels",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Short vowel sounds are quick sounds in the middle of many small words.",
  workedExample:"In the word pig, the middle sound is short i. You can hear /i/ in p-i-g.",
  guidedPractice:"Say the word slowly and listen to the middle sound.",
  q:"Which word has the short i sound?",
  c:["pig","cake","boat"],a:"pig",
  explain:"Pig has the quick short i sound in the middle."},

 {unit:"G1-READ-PHONICS",skill:"final e",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A final e can make the vowel say its name.",
  workedExample:"Cap has short a. When e is added, cape has long a. The a says its name.",
  guidedPractice:"Look for an e at the end and listen for the long vowel.",
  q:"Which word has long a?",
  c:["cape","cap","cat"],a:"cape",
  explain:"Cape has final e, so the a says its name."},

 {unit:"G1-READ-COMP",skill:"problem and solution",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"The problem is what goes wrong. The solution is how it gets fixed.",
  workedExample:"If the bridge breaks, that is the problem. If the animals build a new bridge, that is the solution.",
  guidedPractice:"Ask: What went wrong? Then ask: How was it fixed?",
  q:"The gate was locked, so the fox found a key. What is the solution?",
  c:["the fox found a key","the gate was locked","the fox saw the gate"],a:"the fox found a key",
  explain:"Finding the key fixed the locked gate problem."}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-SENTENCES",skill:"complete sentences",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A complete sentence tells a whole thought.",
  workedExample:"The owl flew over the tree. This is complete because it tells who and what happened.",
  guidedPractice:"Check whether the sentence tells who and what happened.",
  q:"Which is a complete sentence?",
  c:["The owl flew.","owl","flew over"],a:"The owl flew.",
  explain:"The owl flew tells who and what happened."},

 {unit:"G1-ELA-WRITING",skill:"adding details",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Details make writing clearer and more interesting.",
  workedExample:"The frog jumped is okay. The green frog jumped into the pond gives more detail.",
  guidedPractice:"Try adding what kind, where, or when.",
  q:"Which sentence has more detail?",
  c:["The green frog jumped into the pond.","The frog jumped.","Frog."],a:"The green frog jumped into the pond.",
  explain:"It tells what kind of frog and where it jumped."},

 {unit:"G1-ELA-WRITING",skill:"restating questions",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A strong answer often restates the question.",
  workedExample:"Question: Where did the rabbit go? Answer: The rabbit went to the den.",
  guidedPractice:"Use words from the question in your answer.",
  q:"Which answer restates the question: Where did the rabbit go?",
  c:["The rabbit went to the den.","Den.","Yes."],a:"The rabbit went to the den.",
  explain:"This answer uses the words rabbit and went, so it restates the question."}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-EQ",skill:"two-step equations",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A two-step equation is solved by undoing operations in reverse order.",
  workedExample:"For 4x + 7 = 31, subtract 7 first. That gives 4x = 24. Then divide by 4, so x = 6.",
  guidedPractice:"Undo addition or subtraction first, then undo multiplication or division.",
  q:"4x + 7 = 31. What is x?",
  c:["6","8","24"],a:"6",
  explain:"Subtract 7 to get 4x = 24. Then divide by 4 to get x = 6."},

 {unit:"G7-MATH-RATIO",skill:"unit rates",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A unit rate tells how much for one unit.",
  workedExample:"150 miles in 3 hours means 150 ÷ 3 = 50 miles in one hour.",
  guidedPractice:"Divide the total amount by the number of units.",
  q:"150 miles in 3 hours is...",
  c:["50 miles per hour","153 miles per hour","45 miles per hour"],a:"50 miles per hour",
  explain:"150 divided by 3 is 50, so the unit rate is 50 miles per hour."},

 {unit:"G7-MATH-INT",skill:"integer addition",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"When adding integers with different signs, subtract the smaller absolute value from the larger one.",
  workedExample:"-9 + 4 means the negative side is bigger. 9 - 4 = 5, so the answer is -5.",
  guidedPractice:"Compare the sizes first, then keep the sign of the larger absolute value.",
  q:"-9 + 4 = ?",
  c:["-5","13","5"],a:"-5",
  explain:"9 is farther from zero than 4, so the answer keeps the negative sign. 9 - 4 = 5, so the answer is -5."},

 {unit:"G7-MATH-RATIO",skill:"percent",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Percent means out of 100. To find a percent of a number, change the percent to a decimal.",
  workedExample:"20% of 80 is 0.20 × 80. That equals 16.",
  guidedPractice:"Change 20% to 0.20, then multiply.",
  q:"20% of 80 is...",
  c:["16","20","8"],a:"16",
  explain:"0.20 times 80 equals 16."}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-WRITING",skill:"CER",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A CER response has a Claim, Evidence, and Reasoning.",
  workedExample:"Claim: The character is brave. Evidence: She enters the cave to help her brother. Reasoning: This shows bravery because she acts even though the cave is dangerous.",
  guidedPractice:"After evidence, always explain why the evidence proves the claim.",
  q:"In CER, what explains how evidence supports the claim?",
  c:["reasoning","setting","prefix"],a:"reasoning",
  explain:"Reasoning connects the evidence back to the claim."},

 {unit:"G7-ELA-EVIDENCE",skill:"inference",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"An inference uses clues plus reasoning.",
  workedExample:"If a character is shivering and pulling on a coat, you can infer the character is cold.",
  guidedPractice:"Do not guess wildly. Use clues from the text.",
  q:"A character whispers and checks the door twice. What can you infer?",
  c:["The character is nervous.","The character is asleep.","The character is swimming."],a:"The character is nervous.",
  explain:"Whispering and checking the door are clues that suggest nervousness."},

 {unit:"G7-ELA-EVIDENCE",skill:"theme",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Theme is a message or lesson that grows from the story.",
  workedExample:"If a character keeps practicing and succeeds, the theme might be that persistence matters.",
  guidedPractice:"Ask what the character learned or what the story teaches.",
  q:"A character fails twice, keeps trying, and finally succeeds. Which theme fits?",
  c:["Persistence matters.","Weather changes.","Maps show places."],a:"Persistence matters.",
  explain:"The character succeeds because of continued effort, so persistence matters fits best."}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-PHYSICAL",skill:"controlled experiment",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A controlled experiment changes only one main variable at a time.",
  workedExample:"If you test how sunlight affects plant growth, the amount of sunlight changes. Water, soil, and plant type should stay the same.",
  guidedPractice:"Find what changes and what must stay constant.",
  q:"In a fair test, how many main variables should change?",
  c:["one","all","none"],a:"one",
  explain:"Changing one variable helps show what caused the result."}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"primary sources",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A primary source comes from the time or person being studied.",
  workedExample:"A diary written during an event is a primary source. A textbook written years later is usually a secondary source.",
  guidedPractice:"Ask whether the source was created during the event.",
  q:"Which is a primary source?",
  c:["a diary from the event","a modern textbook summary","a new cartoon"],a:"a diary from the event",
  explain:"The diary was created during the event, so it is primary."}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-FUNC",skill:"slope",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Slope is the rate of change of a line.",
  workedExample:"From (2,3) to (5,12), y changes by 9 and x changes by 3. Slope is 9 ÷ 3 = 3.",
  guidedPractice:"Find change in y, then change in x, then divide.",
  q:"What is the slope from (2,3) to (5,12)?",
  c:["3","9","6"],a:"3",
  explain:"The y-value changes by 9 and the x-value changes by 3. 9 divided by 3 is 3."},

 {unit:"G8-MATH-EQ",skill:"variables both sides",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"When variables are on both sides, move variable terms together first.",
  workedExample:"5x + 4 = 2x + 19. Subtract 2x from both sides: 3x + 4 = 19. Subtract 4: 3x = 15. Divide by 3: x = 5.",
  guidedPractice:"Move the smaller variable term first to avoid negatives when possible.",
  q:"5x + 4 = 2x + 19. What is x?",
  c:["5","15","3"],a:"5",
  explain:"Subtract 2x, subtract 4, then divide by 3. x = 5."},

 {unit:"G8-MATH-FUNC",skill:"y-intercept",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"The y-intercept is where a graph crosses the y-axis.",
  workedExample:"In y = 4x + 7, the y-intercept is 7 because b = 7 in y = mx + b.",
  guidedPractice:"Look for the number added or subtracted after mx.",
  q:"In y = 4x + 7, the y-intercept is...",
  c:["7","4","11"],a:"7",
  explain:"In y = mx + b, b is the y-intercept. Here b = 7."},

 {unit:"G8-MATH-GEO-DATA",skill:"Pythagorean theorem",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"The Pythagorean theorem works for right triangles.",
  workedExample:"If the legs are 6 and 8, then 6² + 8² = 36 + 64 = 100. The square root of 100 is 10.",
  guidedPractice:"Square both legs, add them, then take the square root.",
  q:"A right triangle has legs 6 and 8. What is the hypotenuse?",
  c:["10","14","7"],a:"10",
  explain:"6 squared is 36 and 8 squared is 64. Together they make 100, and the square root is 10."}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"counterclaim",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A counterclaim is the opposing side of an argument.",
  workedExample:"Claim: The gate should stay closed. Counterclaim: Some people believe it should open for trade.",
  guidedPractice:"Ask what a reasonable person on the other side might say.",
  q:"A counterclaim gives the...",
  c:["opposing view","main title","setting"],a:"opposing view",
  explain:"A counterclaim presents the other side of the argument."},

 {unit:"G8-ELA-RESEARCH",skill:"source reliability",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A reliable source can be checked for author, date, evidence, and purpose.",
  workedExample:"A signed article with sources and a clear date is usually stronger than an anonymous page with no evidence.",
  guidedPractice:"Check who made the source, when, and why.",
  q:"Which helps judge source reliability?",
  c:["author, date, evidence, and purpose","font color only","page length only"],a:"author, date, evidence, and purpose",
  explain:"Those details help show whether the source can be trusted."},

 {unit:"G8-ELA-ARG",skill:"rebuttal",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A rebuttal answers a counterclaim.",
  workedExample:"Counterclaim: The rule is too strict. Rebuttal: The rule is strict because it protects people from real danger.",
  guidedPractice:"Do not ignore the other side. Answer it directly.",
  q:"A rebuttal answers the...",
  c:["counterclaim","citation","chapter title"],a:"counterclaim",
  explain:"The rebuttal responds to the opposing view."}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-FORCE",skill:"Newton's laws",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Newton's second law connects force, mass, and acceleration.",
  workedExample:"F = ma means force equals mass times acceleration. If mass increases, more force is needed for the same acceleration.",
  guidedPractice:"Remember: force depends on both mass and acceleration.",
  q:"Newton's second law is...",
  c:["F = ma","y = mx + b","C = πd"],a:"F = ma",
  explain:"F = ma means force equals mass times acceleration."}
]);
