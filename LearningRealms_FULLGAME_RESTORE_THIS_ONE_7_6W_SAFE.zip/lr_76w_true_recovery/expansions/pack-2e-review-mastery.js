// Curriculum Pack 2E: Review / Mastery / Boss Prep
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Reading",[
 {teach:"Review: SH, CH, and TH are digraphs. Two letters make one sound.",practice:"ship, chair, thumb",q:"Which word starts with TH?",c:["thumb","chair","ship"],a:"thumb"},
 {teach:"Review: A CVC word has consonant, vowel, consonant.",practice:"cat, hen, dog",q:"Which is a CVC word?",c:["dog","tree","cake"],a:"dog"},
 {teach:"Review: Final e can make the vowel long.",practice:"hop becomes hope.",q:"Which word has final e?",c:["hope","hop","hot"],a:"hope"},
 {teach:"Review: A story character is who the story is about.",practice:"The owl found the map.",q:"Who is the character?",c:["owl","map","found"],a:"owl"},
 {teach:"Review: Setting means where the story happens.",practice:"The frog sat in the marsh.",q:"What is the setting?",c:["marsh","frog","sat"],a:"marsh"},
 {teach:"Review: Problem means what goes wrong.",practice:"The bridge broke.",q:"What is the problem?",c:["bridge broke","bridge is brown","the title"],a:"bridge broke"},
 {teach:"Review: Solution means how the problem is fixed.",practice:"They built a new bridge.",q:"What is the solution?",c:["built a new bridge","the bridge broke","frog sat"],a:"built a new bridge"},
 {teach:"Boss Prep: Put story events in order using first, next, and last.",practice:"First seed. Next sprout. Last flower.",q:"Which comes first?",c:["seed","flower","bee"],a:"seed"}
]);

LR_addLessons("Luna","English",[
 {teach:"Review: Sentences begin with capital letters.",practice:"the fox runs → The fox runs.",q:"Which starts correctly?",c:["The fox runs.","the fox runs.","the Fox runs."],a:"The fox runs."},
 {teach:"Review: A sentence ends with punctuation.",practice:"The owl hoots.",q:"Which mark ends a telling sentence?",c:[".","?","!"],a:"."},
 {teach:"Review: A question asks something.",practice:"Where is the rabbit?",q:"Which is a question?",c:["Where is the rabbit?","The rabbit hops.","Rabbit."],a:"Where is the rabbit?"},
 {teach:"Review: A noun names a person, place, thing, or animal.",practice:"owl, town, gate",q:"Which is a noun?",c:["gate","quickly","under"],a:"gate"},
 {teach:"Review: A verb shows action.",practice:"jump, read, swim",q:"Which is a verb?",c:["read","blue","table"],a:"read"},
 {teach:"Boss Prep: A better sentence can add details.",practice:"The owl flew over the silver gate.",q:"Which sentence has more detail?",c:["The owl flew over the silver gate.","The owl flew.","Owl."],a:"The owl flew over the silver gate."}
]);

LR_addLessons("Luna","Math",[
 {teach:"Review: Addition puts numbers together.",practice:"8 + 4 = 12.",q:"8 + 4 = ?",c:["12","11","13"],a:"12"},
 {teach:"Review: Subtraction takes away.",practice:"14 - 6 = 8.",q:"14 - 6 = ?",c:["8","9","7"],a:"8"},
 {teach:"Review: Teen numbers have one ten and some ones.",practice:"17 = 1 ten and 7 ones.",q:"17 has how many ones?",c:["7","1","17"],a:"7"},
 {teach:"Review: A dime is 10 cents and a nickel is 5 cents.",practice:"10 + 5 = 15.",q:"A dime and nickel together make...",c:["15 cents","10 cents","5 cents"],a:"15 cents"},
 {teach:"Review: A triangle has 3 sides.",practice:"Count the sides.",q:"How many sides does a triangle have?",c:["3","4","5"],a:"3"},
 {teach:"Review: A rectangle has 4 sides.",practice:"A door can look like a rectangle.",q:"How many sides does a rectangle have?",c:["4","3","5"],a:"4"}
]);

LR_addLessons("Ava","Math",[
 {teach:"Review: Equivalent ratios have the same value.",practice:"2:3 = 4:6.",q:"Which ratio equals 2:3?",c:["4:6","3:4","5:6"],a:"4:6"},
 {teach:"Review: Unit rate means per one.",practice:"150 miles in 3 hours = 50 miles per hour.",q:"150 miles in 3 hours is...",c:["50 miles per hour","153 miles per hour","45 miles per hour"],a:"50 miles per hour"},
 {teach:"Review: To solve x + 9 = 22, subtract 9.",practice:"22 - 9 = 13.",q:"x + 9 = 22. x = ?",c:["13","31","11"],a:"13"},
 {teach:"Review: To solve 5x = 45, divide by 5.",practice:"45 ÷ 5 = 9.",q:"5x = 45. x = ?",c:["9","40","50"],a:"9"},
 {teach:"Review: Percent means out of 100.",practice:"30% means 30 out of 100.",q:"30% means 30 out of...",c:["100","30","10"],a:"100"},
 {teach:"Review: Area of a rectangle is length times width.",practice:"9 × 4 = 36.",q:"Rectangle area with length 9 and width 4?",c:["36","13","18"],a:"36"},
 {teach:"Boss Prep: Combine like terms before solving.",practice:"3x + 2x = 5x.",q:"3x + 2x = ?",c:["5x","6x","x"],a:"5x"},
 {teach:"Boss Prep: Integer signs matter.",practice:"-6 + 2 = -4.",q:"-6 + 2 = ?",c:["-4","8","4"],a:"-4"}
]);

LR_addLessons("Ava","English",[
 {teach:"Review: Theme is the lesson or message.",practice:"A character learns not to give up.",q:"Theme means...",c:["lesson or message","title","setting"],a:"lesson or message"},
 {teach:"Review: Text evidence proves an answer.",practice:"Use a quote or detail from the passage.",q:"Text evidence is...",c:["proof from text","a guess","a cover picture"],a:"proof from text"},
 {teach:"Review: Inference uses clues and reasoning.",practice:"A character shivers and grabs a coat.",q:"What can you infer?",c:["The character is cold.","The character is flying.","The character is painting."],a:"The character is cold."},
 {teach:"Review: Central idea is the main point.",practice:"A passage explains how frogs grow.",q:"Central idea means...",c:["main point","small detail","page number"],a:"main point"},
 {teach:"Review: Context clues help with word meaning.",practice:"The enormous gate towered over them.",q:"Enormous means...",c:["very large","very tiny","very quiet"],a:"very large"},
 {teach:"Boss Prep: CER means claim, evidence, reasoning.",practice:"Answer, prove, explain.",q:"In CER, R stands for...",c:["reasoning","reading","result"],a:"reasoning"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Review: Producers make their own food.",practice:"Plants use sunlight.",q:"Which is a producer?",c:["plant","fox","rabbit"],a:"plant"},
 {teach:"Review: Consumers eat other organisms.",practice:"A fox eats a rabbit.",q:"Which is a consumer?",c:["fox","grass","sunlight"],a:"fox"},
 {teach:"Review: Decomposers break down dead material.",practice:"Fungi can break down logs.",q:"A decomposer breaks down...",c:["dead material","equations","claims"],a:"dead material"},
 {teach:"Review: Evaporation changes liquid water to gas.",practice:"A puddle dries.",q:"A drying puddle shows...",c:["evaporation","freezing","gravity"],a:"evaporation"},
 {teach:"Review: Condensation forms droplets.",practice:"Water on cold glass.",q:"Droplets forming is...",c:["condensation","erosion","friction"],a:"condensation"},
 {teach:"Boss Prep: Controlled experiments change one variable at a time.",practice:"Only sunlight changes.",q:"A fair experiment changes how many main variables?",c:["one","three","all"],a:"one"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Review: Distribute first when parentheses are present.",practice:"4(x + 3) = 4x + 12.",q:"4(x + 3) = ?",c:["4x + 12","x + 12","4x + 3"],a:"4x + 12"},
 {teach:"Review: Combine like terms.",practice:"6x - 2x = 4x.",q:"6x - 2x = ?",c:["4x","8x","3x"],a:"4x"},
 {teach:"Review: Move variables together when solving equations.",practice:"7x + 5 = 3x + 21 gives 4x = 16.",q:"7x + 5 = 3x + 21. x = ?",c:["4","16","26"],a:"4"},
 {teach:"Review: Slope is change in y over change in x.",practice:"From (2,3) to (4,9), slope is 6/2.",q:"Slope from (2,3) to (4,9)?",c:["3","6","2"],a:"3"},
 {teach:"Review: In y = mx + b, b is the y-intercept.",practice:"y = 2x + 7 has intercept 7.",q:"In y = 2x + 7, y-intercept is...",c:["7","2","9"],a:"7"},
 {teach:"Review: A system solution is where equations agree.",practice:"The graphs cross at the solution.",q:"System solution is where graphs...",c:["cross","end","vanish"],a:"cross"},
 {teach:"Boss Prep: Scientific notation uses powers of ten.",practice:"42,000 = 4.2 × 10^4.",q:"42,000 starts as...",c:["4.2 × 10","42 × 10","0.42 × 10"],a:"4.2 × 10"},
 {teach:"Boss Prep: Pythagorean theorem uses a² + b² = c².",practice:"6² + 8² = 10².",q:"Hypotenuse for 6,8,10 triangle?",c:["10","8","6"],a:"10"}
]);

LR_addLessons("Michael","English",[
 {teach:"Review: An argument needs claim, evidence, and reasoning.",practice:"The claim says what you are proving.",q:"What supports a claim?",c:["evidence","random opinion","font"],a:"evidence"},
 {teach:"Review: Reasoning explains how evidence proves the claim.",practice:"Quote plus explanation.",q:"Reasoning connects evidence to the...",c:["claim","title","weather"],a:"claim"},
 {teach:"Review: A counterclaim gives the opposing view.",practice:"Some people may argue the opposite.",q:"A counterclaim is an opposing...",c:["view","setting","formula"],a:"view"},
 {teach:"Review: A rebuttal answers the counterclaim.",practice:"It explains why the claim still stands.",q:"A rebuttal answers...",c:["counterclaim","topic sentence only","citation"],a:"counterclaim"},
 {teach:"Review: Reliable sources should be checked for author, evidence, and date.",practice:"Trustworthy sources can be verified.",q:"Which helps judge reliability?",c:["author and evidence","page color","font size only"],a:"author and evidence"},
 {teach:"Boss Prep: A thesis states the main argument.",practice:"The essay proves this point.",q:"A thesis states the...",c:["main argument","bibliography","page number"],a:"main argument"}
]);

LR_addLessons("Michael","Science",[
 {teach:"Review: Elements are made of one kind of atom.",practice:"Gold is an element.",q:"An element is made of one kind of...",c:["atom","cell","claim"],a:"atom"},
 {teach:"Review: Compounds form when elements chemically combine.",practice:"Water is H2O.",q:"Water is a...",c:["compound","function","source"],a:"compound"},
 {teach:"Review: Physical changes do not make a new substance.",practice:"Ice melting is still water.",q:"Ice melting is a...",c:["physical change","chemical change","new element"],a:"physical change"},
 {teach:"Review: Chemical changes make new substances.",practice:"Rust forms a new substance.",q:"Rusting is a...",c:["chemical change","sentence","graph"],a:"chemical change"},
 {teach:"Review: Newton's second law is F = ma.",practice:"Force depends on mass and acceleration.",q:"F = ma connects force, mass, and...",c:["acceleration","density","theme"],a:"acceleration"},
 {teach:"Review: Waves transfer energy.",practice:"Sound and light are wave-related.",q:"Waves transfer...",c:["energy","laws","paragraphs"],a:"energy"}
]);

LR_addLessons("Michael","History",[
 {teach:"Review: The Constitution creates the structure of government.",practice:"It sets up branches and powers.",q:"The Constitution creates government...",c:["structure","weather","density"],a:"structure"},
 {teach:"Review: Federalism divides power between national and state governments.",practice:"Both levels have powers.",q:"Federalism divides...",c:["power","water","paragraphs"],a:"power"},
 {teach:"Review: Checks and balances limit government power.",practice:"Branches can check each other.",q:"Checks and balances limit...",c:["power","erosion","syntax"],a:"power"},
 {teach:"Review: The Bill of Rights protects freedoms.",practice:"Speech and religion are examples.",q:"The Bill of Rights protects...",c:["freedoms","fractions","weather"],a:"freedoms"},
 {teach:"Review: Scarcity means resources are limited.",practice:"Limited resources force choices.",q:"Scarcity means resources are...",c:["limited","unlimited","unneeded"],a:"limited"},
 {teach:"Boss Prep: Cause and effect explain why events happened and what changed.",practice:"Tax anger led to protest.",q:"Cause and effect explain why and...",c:["what changed","how to spell","how to measure"],a:"what changed"}
]);
