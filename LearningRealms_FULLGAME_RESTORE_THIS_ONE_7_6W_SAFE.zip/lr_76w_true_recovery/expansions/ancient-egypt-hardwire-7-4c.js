/* LearningRealms Ancient Egypt Hardwire 7.4C
   Purpose: make Egypt genuinely reachable from the real active game shell,
   not just technically present in hidden course data.
   Built to be tiny, stable, and non-destructive.
*/
(function(){
  'use strict';
  if(window.__LR_ANCIENT_EGYPT_HARDWIRE_74C__) return;
  window.__LR_ANCIENT_EGYPT_HARDWIRE_74C__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ return (root || document).querySelector(sel); }
  function qa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function text(el){ return (el && el.textContent ? el.textContent : '').replace(/\s+/g,' ').trim(); }
  function call(fn){
    if(typeof window[fn] !== 'function') return false;
    try{ window[fn](); return true; }catch(e){ console.warn('Egypt 7.4C route failed:', fn, e); return false; }
  }

  function openEgypt(){
    if(call('openAncientEgyptTrail')) return false;
    if(call('openAncientEgyptCourse')) return false;
    var msg = '<div style="padding:16px;line-height:1.5"><h2>🏺 Ancient Egypt Expedition</h2><p>The Egypt doorway is here, but the Egypt course script did not finish loading. Use the 7.4C build and refresh the page once.</p></div>';
    if(typeof window.lrOpenPopup === 'function') window.lrOpenPopup('🏺 Ancient Egypt Expedition', msg);
    else {
      var box = byId('actionText') || byId('roomText') || document.body;
      box.innerHTML = msg;
    }
    return false;
  }
  window.openLearningRealmsEgyptRoad = openEgypt;
  window.openLearningRealmsEgypt = openEgypt;

  function addStyles(){
    if(byId('lr74cEgyptHardwireStyles')) return;
    var st = document.createElement('style');
    st.id = 'lr74cEgyptHardwireStyles';
    st.textContent = `
      .lr74cEgyptCommand,.lr74cEgyptTopBtn{border-color:rgba(255,231,150,.5)!important;background:linear-gradient(180deg,#fff4bd,#d69b32)!important;color:#211304!important;}
      .lr74cEgyptCommand span,.lr74cEgyptTopBtn span{background:linear-gradient(180deg,#5e3a11,#1b1005)!important;color:#ffe8a8!important;}
      .lr74cEgyptCard{background:linear-gradient(180deg,#fff5c2,#d7ae55 68%,#b07825)!important;border:2px solid rgba(105,67,15,.42)!important;}
      .lr74cEgyptDoor{margin:12px 14px 0;padding:14px;display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;border-radius:17px;border:1px solid rgba(255,231,150,.35);background:linear-gradient(135deg,rgba(255,241,184,.18),rgba(154,92,22,.18));box-shadow:0 9px 18px rgba(0,0,0,.25);color:#fff0bd;}
      .lr74cEgyptDoor .icon{width:46px;height:46px;display:grid;place-items:center;border-radius:13px;background:linear-gradient(180deg,#5e3a11,#1b1005);font-size:1.45rem;}
      .lr74cEgyptDoor b{display:block;color:#fff7d2;font-size:1.08rem;}.lr74cEgyptDoor small{display:block;color:#e8d294;text-transform:uppercase;letter-spacing:.06em;font-weight:1000;font-size:.7rem;margin:3px 0 5px;}.lr74cEgyptDoor p{margin:0;color:#dbeadf;font-weight:780;line-height:1.35;}.lr74cEgyptDoor button{border:1px solid rgba(255,231,150,.48);border-radius:999px;background:linear-gradient(180deg,#fff4bd,#d69b32);color:#211304;font-weight:1000;padding:10px 14px;cursor:pointer;box-shadow:0 5px 12px rgba(0,0,0,.24);}
      @media(max-width:760px){.lr74cEgyptDoor{grid-template-columns:auto 1fr}.lr74cEgyptDoor button{grid-column:1 / -1;width:100%;}}
    `;
    document.head.appendChild(st);
  }

  function egyptCardHtml(){
    return '<button type="button" class="lr73pCard lr74cEgyptCard" data-lr73p-act="egypt">'+
      '<span class="lr73pCardIcon">🏺</span><span><b>Ancient Egypt Expedition</b><small>History Master Road</small><p>Nile, pharaohs, pyramids, Sphinx, scribes, temples, tombs, daily life, and archaeology.</p></span><span class="lr73pCardArrow">›</span></button>';
  }

  function patchCommandWindow(){
    var host = byId('leftActionButtons');
    if(!host) return;
    // If the command rewrite already includes Egypt, just style it.
    var existing = q('[data-lr73p-act="egypt"],[data-lr74c-act="egypt"]', host);
    if(existing){ existing.classList.add('lr74cEgyptCommand'); return; }
    var history = q('[data-lr73p-act="history"],[data-lr73o-act="history"],[data-lr73m-act="history"]', host);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'lr73pCommandBtn lr74cEgyptCommand';
    btn.setAttribute('data-lr73p-act','egypt');
    btn.innerHTML = '<span>🏺</span><b>Egypt Road</b>';
    if(history && history.parentNode) history.parentNode.insertBefore(btn, history.nextSibling);
    else host.appendChild(btn);
  }

  function patchTopNav(){
    var nav = q('.lr73mTopNav');
    if(!nav) return;
    var existing = q('[data-lr73p-act="egypt"],[data-lr74c-act="egypt"]', nav);
    if(existing){ existing.classList.add('lr74cEgyptTopBtn'); return; }
    var history = q('[data-lr73p-act="history"],[data-lr73o-act="history"],[data-lr73m-act="history"]', nav);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'lr73oBtn lr74cEgyptTopBtn';
    btn.setAttribute('data-lr73p-act','egypt');
    btn.textContent = 'Egypt Road';
    if(history && history.parentNode) history.parentNode.insertBefore(btn, history.nextSibling);
    else nav.appendChild(btn);
  }

  function patchPlayerIcons(){
    var rack = q('.lr73mIconRack,.lr73pIconRack');
    if(!rack) return;
    if(q('[data-lr73p-act="egypt"],[data-lr74c-act="egypt"]', rack)) return;
    var history = q('[data-lr73p-act="history"],[data-lr73o-act="history"],[data-lr73m-act="history"]', rack);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.title = 'Egypt Road';
    btn.setAttribute('aria-label','Egypt Road');
    btn.setAttribute('data-lr73p-act','egypt');
    btn.textContent = '🏺';
    if(history && history.parentNode) history.parentNode.insertBefore(btn, history.nextSibling);
    else rack.appendChild(btn);
  }

  function patchAtlasAndHistory(){
    var root = byId('lrDynamicAdventureScreen');
    if(!root) return;
    var t = text(root);
    var onAtlas = /Realm Atlas|Choose a wing of the realm/i.test(t);
    var onHistory = /History and World Wing|History Master Roads|Past roads/i.test(t);
    if(!onAtlas && !onHistory) return;

    // Convert any placeholder Ancient Worlds/Heritage card into the real Egypt road.
    qa('.lr73pCard', root).forEach(function(card){
      var tx = text(card);
      if(/Ancient Worlds Gate|Ancient Worlds|Heritage/i.test(tx) && !/Ancient Egypt Expedition/i.test(tx)){
        card.disabled = false;
        card.classList.add('lr74cEgyptCard');
        card.setAttribute('data-lr73p-act','egypt');
        card.innerHTML = '<span class="lr73pCardIcon">🏺</span><span><b>Ancient Egypt Expedition</b><small>History Master Road</small><p>Nile, pharaohs, pyramids, Sphinx, scribes, daily life, beliefs, archaeology, and evidence habits.</p></span><span class="lr73pCardArrow">›</span>';
      }
    });

    // If the History section/grid does not visibly show Egypt, add one inside that section.
    if(!/Ancient Egypt Expedition/i.test(text(root))){
      var targetGrid = null;
      qa('.lr73pSection', root).forEach(function(sec){
        if(!targetGrid && /History and World Wing|History Master Roads|History/i.test(text(sec))) targetGrid = q('.lr73pGrid', sec);
      });
      if(!targetGrid) targetGrid = q('.lr73pGrid', root);
      if(targetGrid) targetGrid.insertAdjacentHTML('beforeend', egyptCardHtml());
    }

    if(onHistory && !q('.lr74cEgyptDoor', root)){
      var sections = q('.lr73pSections', root) || root;
      sections.insertAdjacentHTML('afterbegin','<div class="lr74cEgyptDoor"><span class="icon">🏺</span><div><b>Ancient Egypt Expedition</b><small>History Wing Road</small><p>This is Brittney’s deep Egypt road: Nile geography, pharaohs, pyramids, the Sphinx, scribes, daily life, temples, tombs, and archaeology.</p></div><button type="button" data-lr73p-act="egypt">Enter Egypt</button></div>');
    }
  }

  function wrapRouter(){
    if(window.__LR74C_ROUTER_WRAPPED__) return;
    if(typeof window.lr73pDo !== 'function') return;
    window.__LR74C_ROUTER_WRAPPED__ = true;
    var old = window.lr73pDo;
    window.lr73pDo = function(act){
      var norm = String(act || '').toLowerCase().replace(/[^a-z0-9]/g,'');
      if(norm === 'egypt' || norm === 'ancientegypt' || norm === 'egyptroad') return openEgypt();
      return old.apply(window, arguments);
    };
    try{ lr73pDo = window.lr73pDo; }catch(e){}
  }

  function bindClicks(){
    if(window.__LR74C_EGYPT_CLICK_BIND__) return;
    window.__LR74C_EGYPT_CLICK_BIND__ = true;
    window.addEventListener('click', function(ev){
      var hit = ev.target && ev.target.closest ? ev.target.closest('[data-lr73p-act="egypt"],[data-lr73p-act="ancientegypt"],[data-lr74c-act="egypt"]') : null;
      if(!hit) return;
      ev.preventDefault();
      ev.stopImmediatePropagation();
      openEgypt();
      setTimeout(patch,80);
    }, true);
  }

  var timer = 0;
  function patch(){
    timer = 0;
    addStyles(); wrapRouter(); patchCommandWindow(); patchTopNav(); patchPlayerIcons(); patchAtlasAndHistory();
  }
  function schedule(){ if(timer) return; timer = setTimeout(patch, 80); }
  function boot(){
    bindClicks(); patch();
    setTimeout(patch,180); setTimeout(patch,700); setTimeout(patch,1500);
    try{ var mo = new MutationObserver(schedule); mo.observe(document.body,{subtree:true,childList:true}); }catch(e){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,100); setTimeout(patch,900); });
})();
