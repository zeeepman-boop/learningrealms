// Curriculum Pack 3B: Science and History Depth
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Science",[
 {teach:"Animals can be grouped by what they have.",practice:"Birds have feathers. Fish have fins.",q:"Which animal group has feathers?",c:["birds","fish","worms"],a:"birds"},
 {teach:"Mammals usually have hair or fur and feed milk to babies.",practice:"Cats and rabbits are mammals.",q:"Which is a mammal?",c:["rabbit","frog","fish"],a:"rabbit"},
 {teach:"Reptiles often have dry scales.",practice:"Lizards and snakes are reptiles.",q:"Which animal has dry scales?",c:["lizard","bird","cat"],a:"lizard"},
 {teach:"Amphibians often live part of life in water and part on land.",practice:"Frogs are amphibians.",q:"Which is an amphibian?",c:["frog","dog","owl"],a:"frog"},
 {teach:"Weather can be observed and described.",practice:"Sunny, rainy, cloudy, windy.",q:"Which word describes weather?",c:["cloudy","yesterday","map"],a:"cloudy"},
 {teach:"Seasons bring different weather patterns.",practice:"Winter is often cold. Summer is often warm.",q:"Which season is often cold?",c:["winter","summer","spring"],a:"winter"},
 {teach:"Light helps us see.",practice:"A lamp makes a room brighter.",q:"What helps us see?",c:["light","silence","gravity"],a:"light"},
 {teach:"Sound comes from vibrations.",practice:"A guitar string vibrates.",q:"Sound comes from...",c:["vibrations","roots","shadows"],a:"vibrations"},
 {teach:"A magnet has poles.",practice:"Magnets have north and south poles.",q:"A magnet has...",c:["poles","leaves","feathers"],a:"poles"},
 {teach:"Some objects float and some sink.",practice:"A cork may float. A rock may sink.",q:"A rock often...",c:["sinks","flies","melts"],a:"sinks"}
]);

LR_addLessons("Luna","History",[
 {teach:"A timeline shows events in order.",practice:"First birthday, next trip, last today.",q:"A timeline shows events in...",c:["order","color","shape"],a:"order"},
 {teach:"A symbol stands for something else.",practice:"A heart can stand for love.",q:"A symbol...",c:["stands for something","counts by tens","makes rain"],a:"stands for something"},
 {teach:"A flag is a symbol for a place or group.",practice:"A state flag can represent a state.",q:"A flag is a...",c:["symbol","verb","magnet"],a:"symbol"},
 {teach:"Needs are things people must have.",practice:"Food, water, shelter.",q:"Which is a need?",c:["water","toy","painting"],a:"water"},
 {teach:"Wants are things people would like to have.",practice:"A toy can be a want.",q:"Which is a want?",c:["toy","water","shelter"],a:"toy"},
 {teach:"Goods are things people make or use.",practice:"Bread and books are goods.",q:"Which is a good?",c:["book","helper","rule"],a:"book"},
 {teach:"Services are jobs people do for others.",practice:"A barber gives a service.",q:"Which is a service?",c:["haircut","apple","chair"],a:"haircut"},
 {teach:"A rule tells what people should or should not do.",practice:"Take turns is a rule.",q:"A rule tells people what to...",c:["do","eat only","draw only"],a:"do"},
 {teach:"Leaders help guide groups.",practice:"A mayor is a town leader.",q:"A leader helps...",c:["guide","melt","float"],a:"guide"},
 {teach:"A citizen is a member of a community.",practice:"People in a town are citizens.",q:"A citizen belongs to a...",c:["community","cloud","clock"],a:"community"}
]);

LR_addLessons("Ava","Science",[
 {teach:"Organisms have structures that support survival.",practice:"A bird's beak can help it eat certain foods.",q:"A beak can help a bird...",c:["eat","write","vote"],a:"eat"},
 {teach:"Behavioral adaptations are actions that help survival.",practice:"Migration helps some animals find food.",q:"Migration is a type of...",c:["behavioral adaptation","cell wall","igneous rock"],a:"behavioral adaptation"},
 {teach:"Structural adaptations are body features that help survival.",practice:"Thick fur helps in cold climates.",q:"Thick fur is a...",c:["structural adaptation","learned paragraph","weather map"],a:"structural adaptation"},
 {teach:"Predators hunt other organisms for food.",practice:"A hawk hunting a mouse is a predator.",q:"A predator...",c:["hunts other organisms","makes its own food","is always a plant"],a:"hunts other organisms"},
 {teach:"Prey are organisms that are hunted.",practice:"A mouse hunted by a hawk is prey.",q:"Prey are organisms that are...",c:["hunted","always producers","made of rocks"],a:"hunted"},
 {teach:"Energy moves through ecosystems from producers to consumers.",practice:"Grass to rabbit to fox.",q:"Energy in a food chain usually starts with...",c:["producer","top predator","decomposer"],a:"producer"},
 {teach:"Biodiversity means variety of living things.",practice:"A forest with many species has biodiversity.",q:"Biodiversity means variety of...",c:["living things","punctuation marks","equations"],a:"living things"},
 {teach:"A watershed is land where water drains to the same place.",practice:"Water drains into streams and rivers.",q:"A watershed is about where water...",c:["drains","freezes only","is spelled"],a:"drains"},
 {teach:"Weathering breaks rock into smaller pieces.",practice:"Ice can crack rock.",q:"Weathering breaks...",c:["rock","laws","sentences"],a:"rock"},
 {teach:"Deposition drops sediment in a new place.",practice:"A river can drop sand.",q:"Deposition means sediment is...",c:["dropped","burned","capitalized"],a:"dropped"}
]);

LR_addLessons("Ava","History",[
 {teach:"Historical context means the conditions around an event.",practice:"Time, place, beliefs, and problems matter.",q:"Historical context means surrounding...",c:["conditions","fractions","weather"],a:"conditions"},
 {teach:"Chronological order means events are arranged by time.",practice:"First, next, last.",q:"Chronological order uses...",c:["time","color","mass"],a:"time"},
 {teach:"Cause explains why an event happened.",practice:"A drought caused crop problems.",q:"Cause explains...",c:["why it happened","how tall it was","what color"],a:"why it happened"},
 {teach:"Effect explains what happened because of a cause.",practice:"Crop problems caused food shortages.",q:"Effect means what...",c:["happened because of a cause","came first always","is unrelated"],a:"happened because of a cause"},
 {teach:"A fact can be proven true or false.",practice:"The town was founded in 1802.",q:"A fact can be...",c:["proven","only felt","never checked"],a:"proven"},
 {teach:"An opinion tells what someone thinks or feels.",practice:"That was the best speech.",q:"An opinion tells...",c:["what someone thinks","a proven date","a measurement"],a:"what someone thinks"},
 {teach:"A democracy lets people have a voice in government.",practice:"Voting is one way.",q:"Democracy gives people a...",c:["voice","cell wall","rain cycle"],a:"voice"},
 {teach:"Taxes help pay for public services.",practice:"Roads and emergency services can be funded by taxes.",q:"Taxes help pay for...",c:["public services","photosynthesis","adjectives"],a:"public services"},
 {teach:"Trade happens when people exchange goods or services.",practice:"A farmer sells grain for money.",q:"Trade means exchange of...",c:["goods or services","weather only","punctuation"],a:"goods or services"},
 {teach:"A budget is a plan for using money.",practice:"Families and governments can have budgets.",q:"A budget is a money...",c:["plan","map","cell"],a:"plan"}
]);

LR_addLessons("Ava","English",[
 {teach:"A historical explanation should use evidence, not just guesses.",practice:"Use documents or artifacts.",q:"Historical explanations should use...",c:["evidence","random guesses","only feelings"],a:"evidence"},
 {teach:"Cause-and-effect writing explains why something happened and what resulted.",practice:"Because rainfall was low, crops failed.",q:"Cause-and-effect writing explains why and...",c:["what resulted","how to rhyme","font size"],a:"what resulted"},
 {teach:"A compare-and-contrast response discusses similarities and differences.",practice:"Both leaders were brave, but one was cautious.",q:"Compare and contrast means alike and...",c:["different","round","silent"],a:"different"},
 {teach:"A precise verb makes writing stronger.",practice:"sprinted is more precise than went.",q:"Which verb is more precise?",c:["sprinted","went","did"],a:"sprinted"},
 {teach:"A domain-specific word belongs to a subject area.",practice:"ecosystem is a science term.",q:"Ecosystem is a...",c:["domain-specific word","punctuation mark","transition only"],a:"domain-specific word"}
]);

LR_addLessons("Michael","Science",[
 {teach:"The periodic table organizes elements by properties.",practice:"Elements are arranged by atomic number.",q:"The periodic table organizes...",c:["elements","sentences","governments"],a:"elements"},
 {teach:"Atomic number tells the number of protons.",practice:"Carbon has atomic number 6.",q:"Atomic number equals number of...",c:["protons","neutrons only","electrons only"],a:"protons"},
 {teach:"Isotopes are atoms of the same element with different numbers of neutrons.",practice:"Carbon-12 and carbon-14 are isotopes.",q:"Isotopes differ in number of...",c:["neutrons","protons","paragraphs"],a:"neutrons"},
 {teach:"A pure substance has a fixed composition.",practice:"An element or compound can be pure.",q:"A pure substance has fixed...",c:["composition","font","citizenship"],a:"composition"},
 {teach:"A mixture combines substances physically, not chemically.",practice:"Trail mix is a mixture.",q:"A mixture is combined...",c:["physically","only chemically","by laws"],a:"physically"},
 {teach:"Solutions are mixtures where one substance dissolves in another.",practice:"Salt water is a solution.",q:"Salt water is a...",c:["solution","element","force"],a:"solution"},
 {teach:"Potential energy depends on position or arrangement.",practice:"A stretched rubber band has potential energy.",q:"Potential energy can depend on...",c:["position","source date","claim"],a:"position"},
 {teach:"Kinetic energy increases with mass and speed.",practice:"A faster object has more kinetic energy.",q:"Kinetic energy is energy of...",c:["motion","government","syntax"],a:"motion"},
 {teach:"Conservation of energy means energy changes form but is not destroyed.",practice:"Potential can become kinetic.",q:"Energy is not...",c:["destroyed","measured","observed"],a:"destroyed"},
 {teach:"The rock cycle changes rocks among igneous, sedimentary, and metamorphic forms.",practice:"Heat and pressure can form metamorphic rock.",q:"Heat and pressure can form...",c:["metamorphic rock","a thesis","a republic"],a:"metamorphic rock"}
]);

LR_addLessons("Michael","History",[
 {teach:"Natural rights are basic rights people have by nature.",practice:"Life, liberty, and property are examples in some traditions.",q:"Natural rights are basic...",c:["rights","weather events","food chains"],a:"rights"},
 {teach:"Separation of powers divides government authority among branches.",practice:"Legislative, executive, judicial.",q:"Separation of powers divides...",c:["authority","water","energy"],a:"authority"},
 {teach:"Judicial review allows courts to evaluate laws against the Constitution.",practice:"Courts can rule a law unconstitutional.",q:"Judicial review is done by...",c:["courts","markets","weather stations"],a:"courts"},
 {teach:"Civil liberties protect individual freedoms from government interference.",practice:"Speech and religion can be civil liberties.",q:"Civil liberties protect individual...",c:["freedoms","rocks","variables"],a:"freedoms"},
 {teach:"Civic virtue means acting for the good of the community.",practice:"Helping solve community problems.",q:"Civic virtue focuses on community...",c:["good","profit only","weather"],a:"good"},
 {teach:"Supply and demand influence prices.",practice:"High demand and low supply can raise prices.",q:"Supply and demand influence...",c:["prices","atoms","paragraphs"],a:"prices"},
 {teach:"Specialization means focusing on one kind of work or product.",practice:"A bakery specializes in bread.",q:"Specialization means focusing on...",c:["one kind of work","every job at once","weather"],a:"one kind of work"},
 {teach:"Opportunity cost is the next best choice given up.",practice:"Choosing to study means giving up other time.",q:"Opportunity cost is what you...",c:["give up","always gain","ignore"],a:"give up"},
 {teach:"Historical interpretation can change when new evidence is found.",practice:"A new document can alter understanding.",q:"New evidence can change...",c:["interpretation","gravity","cell parts"],a:"interpretation"},
 {teach:"Bias can affect how a source presents information.",practice:"A writer may favor one side.",q:"Bias can affect source...",c:["presentation","volume","orbit"],a:"presentation"}
]);

LR_addLessons("Michael","English",[
 {teach:"A historical argument should use accurate evidence and clear reasoning.",practice:"Evidence alone is not enough without explanation.",q:"A historical argument needs evidence and...",c:["reasoning","decoration","weather"],a:"reasoning"},
 {teach:"A source's purpose can shape what it includes or leaves out.",practice:"A speech may persuade.",q:"Source purpose can shape...",c:["content","mass","slope"],a:"content"},
 {teach:"Corroboration means comparing sources to see where they agree.",practice:"Two diaries may confirm an event.",q:"Corroboration compares...",c:["sources","shapes","forces"],a:"sources"},
 {teach:"Sourcing means asking who made a source, when, and why.",practice:"Author, date, purpose.",q:"Sourcing asks who, when, and...",c:["why","where only","how tall"],a:"why"},
 {teach:"A nuanced claim recognizes complexity.",practice:"It avoids oversimplifying.",q:"A nuanced claim recognizes...",c:["complexity","only one detail","random facts"],a:"complexity"}
]);
