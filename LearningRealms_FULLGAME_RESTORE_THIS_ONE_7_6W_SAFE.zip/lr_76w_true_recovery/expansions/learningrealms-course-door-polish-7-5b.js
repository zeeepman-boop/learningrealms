/* LearningRealms Course Door Polish + Button Audit 7.5B
   Conservative presentation and navigation pass built on 7.5A.
   - No shell rewrite
   - No lesson rewrite
   - No save reset
   - Adds shared course controls, adventure-door styling, button dedupe, and safer fallbacks.
*/
(function(){
  'use strict';
  if(window.__LR75B_COURSE_DOOR_POLISH__) return;
  window.__LR75B_COURSE_DOOR_POLISH__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function norm(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,''); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    if(!has(fn)) return false;
    try{ window[fn].apply(window, Array.prototype.slice.call(arguments,1)); return true; }
    catch(e){ console.warn('LR75B route failed:', fn, e); return false; }
  }
  function callAny(list){
    list = Array.isArray(list) ? list : String(list||'').split('|');
    for(var i=0;i<list.length;i++){ if(call(list[i])) return true; }
    return false;
  }
  function roots(){
    var arr=[];
    ['lrPopupBody','actionText','lrDynamicAdventureScreen','main','app'].forEach(function(id){ var el=byId(id); if(el) arr.push(el); });
    return arr;
  }
  function visible(el){
    if(!el) return false;
    if(el.id === 'lrPopupBody'){
      var pr = byId('lrPopupRoot');
      return pr && !pr.classList.contains('hidden') && (el.textContent||'').trim().length;
    }
    return (el.textContent||'').trim().length > 0;
  }

  var COURSE_HINTS = [
    {key:'england', wing:'history', wingLabel:'History and World Wing', label:'England: Kings and Queens Road', icon:'👑', artifact:'openEnglandKingsQueensShelf74Q|openEnglandRoyalShelf74Q|openEnglandKingsQueensArtifacts74Q', opener:'openEnglandKingsQueens74Q|openEnglandKingsQueensRoad74Q', match:/England: Kings and Queens|Royal Shelf|Anglo-Saxon|William the Conqueror/i},
    {key:'egypt', wing:'history', wingLabel:'History and World Wing', label:'Ancient Egypt Expedition', icon:'𓂀', artifact:'openAncientEgyptArtifacts|openAncientEgyptRoyalArtifacts|openAncientEgyptWorldArtifacts', opener:'openAncientEgyptTrail|openAncientEgyptCourse', match:/Ancient Egypt|Nile|pharaoh|pyramid|Egyptian/i},
    {key:'shipwreck', wing:'history', wingLabel:'History and World Wing', label:'Shipwreck Cove', icon:'⚓', artifact:'openShipwreckCoveRewards|openShipwreckCoveArtifacts|shipwreckOpenRewards', opener:'shipwreckGuidedZoneOpen|openShipwreckCoveMap|openShipwreckCoveDeepCourse', match:/Shipwreck Cove|maritime|lighthouse|harbor|wreck/i},
    {key:'depression', wing:'history', wingLabel:'History and World Wing', label:'Great Depression History Street', icon:'🏚️', artifact:'openGreatDepressionRewards|openGreatDepressionArtifacts', opener:'openGreatDepressionTrail|openGreatDepressionCourse', match:/Great Depression|Dust Bowl|bank run|Hooverville/i},
    {key:'wildwest', wing:'history', wingLabel:'History and World Wing', label:'Wild West Frontier Trail', icon:'🤠', artifact:'openWildWestRewards|openWildWestArtifacts', opener:'openWildWestTrail|openWildWestCourse', match:/Wild West|Frontier Trail|homestead|cattle drive/i},
    {key:'bible', wing:'bible', wingLabel:'Bible Road', label:'Bible History Road', icon:'✝️', artifact:'openBibleHistoryArtifacts|openBibleHistoryRewards|openBibleHistoryArtifacts73B', opener:'openBibleHistoryTrail|openBibleHistoryCourse', match:/Bible History|Bible Road|Gospel|sacrament|apostles/i},
    {key:'science', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Science and Engineering Expedition', icon:'🔬', artifact:'openScienceEngineeringRewards74M|openScienceEngineeringArtifacts74M', opener:'openScienceEngineeringAdventure74M|openScienceEngineeringQuarter74M', match:/Science and Engineering|forces|matter|circuits|engineering design/i},
    {key:'inventions', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Inventions & Engineering Disasters', icon:'🛠️', artifact:'openInventionsEngineeringShelf74R|openInventionsEngineeringArtifacts74R', opener:'openInventionsEngineeringMaster74R|openInventionsEngineeringDisasters74R', match:/Inventions|Engineering Disasters|blueprint|redesign/i},
    {key:'aerospace', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Aerospace Engineering Mission Wing', icon:'🚀', artifact:'openAerospaceArtifactShelf74S|openAerospaceRewards74S', opener:'openAerospaceEngineering74S|openAerospaceEngineering|openAerospaceMissionWing74S', match:/Aerospace|Mission Wing|rocket|flight|orbit/i},
    {key:'nature', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Nature & Health Deep Adventure', icon:'🌿', artifact:'openNatureHealthShelf74T|openNatureHealthArtifacts74T', opener:'openNatureHealthDeepAdventure|openNatureHealth74T', match:/Nature & Health|Living Woods|Health Lodge|ecosystem/i},
    {key:'weather', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Weather & Storm Lab', icon:'🌦️', artifact:'openWeatherStormLabShelf74U|openWeatherArtifacts74U', opener:'openWeatherStormLab74U|openWeatherStormLab', match:/Weather & Storm|Storm Lab|forecast|clouds|lightning/i},
    {key:'animals', wing:'science', wingLabel:'Science and Engineering Quarter', label:'Animal Kingdom & Creature Field Guide', icon:'🐾', artifact:'openAnimalKingdomShelf74V|openCreatureFieldGuideShelf74V', opener:'openCreatureFieldGuide|openAnimalKingdom74V|openAnimalKingdom', match:/Animal Kingdom|Creature Field|wildlife|habitat|tracks/i},
    {key:'writing', wing:'core', wingLabel:'Core Halls', label:'Writing Composition Master Course', icon:'🪶', artifact:'openWritingArtifactShelf|openWritingCompositionShelf74W', opener:'openWritingCompositionMasterCourse|openWritingCompositionMaster74W|openAuthorGuild', match:/Writing Composition|Author Guild|Story Forge|paragraph|proofreading/i},
    {key:'core', wing:'core', wingLabel:'Core Halls', label:'Core Halls Adventure', icon:'🏰', artifact:'openCoreHallsRewards74N|openCoreHallsArtifacts74N', opener:'openCoreHallsNoFillerAdventure74N', match:/Core Halls|Reading Hall|Math Hall|Logic Tower/i},
    {key:'creative', wing:'creative', wingLabel:'Creative Quarter', label:'Creative Quarter Adventure', icon:'🎨', artifact:'openCreativeQuarterShelf74O|openCreativeHomesteadShelf74O', opener:'openCreativeQuarterAdventure74O|openCreativeHomesteadAdventure74O', match:/Creative Quarter|Art Studio|Music Corner|Theater Stage/i},
    {key:'homestead', wing:'homestead', wingLabel:'Homestead Workshop', label:'Homestead Workshop Adventure', icon:'🏡', artifact:'openHomesteadWorkshopShelf74O|openCreativeHomesteadShelf74O', opener:'openHomesteadWorkshopAdventure74O|openCreativeHomesteadAdventure74O', match:/Homestead Workshop|kitchen safety|animal care|repair bench/i},
    {key:'worldsupport', wing:'history', wingLabel:'History and World Wing', label:'Mapmaker, Civic, and Market Halls', icon:'🗺️', artifact:'openHistoryWorldSupportShelf74P|openHistoryWorldSupportArtifacts74P', opener:'openHistoryWorldSupportAdventure74P', match:/Mapmaker|Civic Hall|Market Square|Geography|Economics/i}
  ];

  function inferCourse(root){
    var txt = (root && root.textContent) || '';
    for(var i=0;i<COURSE_HINTS.length;i++){ if(COURSE_HINTS[i].match.test(txt)) return COURSE_HINTS[i]; }
    return null;
  }
  function openLibrary(){
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A('all');
    if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker('all');
    return false;
  }
  function openWing(wing){
    var subject = wing === 'history' ? 'history' : wing === 'science' ? 'science' : wing === 'bible' ? 'bible' : wing === 'creative' ? 'arts' : wing === 'homestead' ? 'life' : 'math';
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(subject);
    if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker(subject);
    return openLibrary();
  }
  function routeAction(act){
    act = String(act||'');
    if(act === 'library') return openLibrary();
    if(act.indexOf('wing:') === 0) return openWing(act.slice(5));
    if(act.indexOf('call:') === 0) return callAny(act.slice(5).split('|')) || showSoftFallback('That door did not answer yet. Try entering from the Realm Library.');
    if(act.indexOf('stable:') === 0){ var r=act.slice(7); return call('lr74xRoute',r) || call('lr74kRoute',r) || call('lr73pDo',r) || openLibrary(); }
  }
  function showSoftFallback(msg){
    var root=byId('actionText') || byId('lrPopupBody');
    if(root) root.insertAdjacentHTML('afterbegin','<div class="lr75bNotice"><b>Door note:</b> '+esc(msg||'This door is still settling.')+'</div>');
    return false;
  }

  function courseRail(cfg){
    var artifact = cfg.artifact || '';
    return '<div class="lr75bCourseRail" data-lr75b-rail="'+esc(cfg.key)+'">' +
      '<div class="lr75bRailBadge"><span>'+esc(cfg.icon||'🚪')+'</span><b>'+esc(cfg.label||'Adventure Road')+'</b><small>'+esc(cfg.wingLabel||'Realm Library')+'</small></div>' +
      '<div class="lr75bRailButtons">' +
        '<button type="button" data-lr75b-act="library">🏛️ Realm Library</button>' +
        '<button type="button" data-lr75b-act="wing:'+esc(cfg.wing||'core')+'">🧭 '+esc(cfg.wingLabel||'Wing')+'</button>' +
        '<button type="button" data-lr75b-act="call:'+esc(cfg.opener||'')+'">🚪 Road Map</button>' +
        (artifact ? '<button type="button" data-lr75b-act="call:'+esc(artifact)+'">🏺 Artifact Shelf</button>' : '') +
      '</div>' +
    '</div>';
  }
  function insertAfterHero(root, html){
    var hero = root.querySelector('[class*="Hero"], [class*="hero"], .lr75aHero, h1, h2');
    if(hero && hero.parentNode){
      if(hero.tagName === 'H1' || hero.tagName === 'H2') hero.insertAdjacentHTML('afterend', html);
      else hero.insertAdjacentHTML('afterend', html);
    }else root.insertAdjacentHTML('afterbegin', html);
  }
  function polishRoot(root, cfg){
    if(!root || !visible(root)) return;
    cfg = cfg || inferCourse(root);
    if(cfg && !root.querySelector('.lr75bCourseRail')) insertAfterHero(root, courseRail(cfg));
    root.classList.add('lr75bPolishedCourseSurface');
    decorateDoors(root);
    scrubSurfaceText(root);
    dedupeNavButtons(root);
  }
  function decorateDoors(root){
    var selectors = [
      '.lr75aDoorCard','.lr75aWingCard','.lr74qCard','.egypt74TopicCard','.gdpTopic','.gdpTrailCard','.wwTopic','.wwTrailCard','.bhTopic','.bhTrailCard','.sw74Topic','.sw74MapCard','.se74Topic','.se74MapCard','.core74Door','.lr74oDoor','.lr74pDoor','.lr74rCard','.lr74rRoadCard','.lr74sTopic','.lr74sArea','.lr74tTopic','.lr74tAreaCard','.lr74uTopic','.lr74uCard','.lr74vDoor','.lr74wDoor'
    ].join(',');
    root.querySelectorAll(selectors).forEach(function(el){ el.classList.add('lr75bAdventureDoor'); });
  }
  function scrubSurfaceText(root){
    // Only surface labels, never lesson paragraphs.
    root.querySelectorAll('button, h1, h2, h3, small, .lr75aHero p, .lr75aDoorCard p').forEach(function(el){
      if(el.closest('.egypt74Page,.lr74qPage,.lr74uParagraph,.lr74vPage,.lr74wPage,[class*="Reading"],[class*="Question"],[class*="question"],article')) return;
      var txt = el.textContent || '';
      var repl = txt
        .replace(/Scroll Shelf/gi,'Realm Library')
        .replace(/REAL Curriculum/gi,'Realm Library')
        .replace(/Lesson Bank/gi,'Practice Drawers')
        .replace(/Course map/gi,'Road Map')
        .replace(/Reward catalog/gi,'Artifact Shelf')
        .replace(/Review missed/gi,'Review Shelf')
        .replace(/Take quiz/gi,'Enter challenge')
        .replace(/Test/gi,'Challenge');
      if(repl !== txt) el.textContent = repl;
    });
  }
  function isNavContainer(el){
    if(!el || !el.className) return false;
    var c = String(el.className);
    return /Nav|Foot|Footer|Btns|HeroBtns|RailButtons|TrailFoot|PopupTop|ModalHead/i.test(c);
  }
  function dedupeNavButtons(root){
    var containers = [];
    root.querySelectorAll('div,section,footer').forEach(function(el){ if(isNavContainer(el)) containers.push(el); });
    containers.forEach(function(box){
      var seen={};
      Array.prototype.slice.call(box.querySelectorAll(':scope > button, :scope > .lr75bRailButtons > button')).forEach(function(btn){
        var key = norm(btn.textContent) + '|' + norm(btn.getAttribute('onclick')||'') + '|' + norm(btn.getAttribute('data-lr75b-act')||btn.getAttribute('data-lr75a-act')||btn.getAttribute('data-lr73p-act')||'');
        if(seen[key]) btn.remove(); else seen[key]=true;
      });
    });
  }
  function polishAll(){ installStyles(); roots().forEach(function(r){ polishRoot(r); }); }

  function wrap(fnName, cfg){
    if(!has(fnName)) return;
    var old = window[fnName];
    if(old.__lr75bWrapped) return;
    var wrapped = function(){
      var out = old.apply(this, arguments);
      setTimeout(function(){ roots().forEach(function(r){ polishRoot(r, cfg); }); }, 0);
      setTimeout(function(){ roots().forEach(function(r){ polishRoot(r, cfg); }); }, 80);
      setTimeout(function(){ roots().forEach(function(r){ polishRoot(r, cfg); }); }, 240);
      return out;
    };
    wrapped.__lr75bWrapped = true;
    window[fnName] = wrapped;
    try{ eval(fnName + ' = window["' + fnName + '"];'); }catch(e){}
  }
  function wrapKnownCourseDoors(){
    COURSE_HINTS.forEach(function(cfg){ String(cfg.opener||'').split('|').forEach(function(fn){ wrap(fn,cfg); }); });
    // Artifacts and shelves get the same return rail if they open their own windows.
    COURSE_HINTS.forEach(function(cfg){ String(cfg.artifact||'').split('|').forEach(function(fn){ wrap(fn,cfg); }); });
  }

  function makeLibraryMoreGameLike(){
    // 7.5A already replaced the link wall. This adds a cleaner hall-of-doors frame around it.
    if(has('openRealmLibrary75A') && !window.openRealmLibrary75B){
      window.openRealmLibrary75B = function(subject){
        var out = window.openRealmLibrary75A(subject||'all');
        setTimeout(polishAll,0); setTimeout(polishAll,80); return out;
      };
    }
    if(has('openRealmLibrary75A') && !window.__LR75B_LIBRARY_WRAPPED__){
      var old = window.openRealmLibrary75A;
      window.openRealmLibrary75A = function(subject){ var out=old.apply(this,arguments); setTimeout(polishAll,0); setTimeout(polishAll,80); return out; };
      window.__LR75B_LIBRARY_WRAPPED__ = true;
    }
  }

  function installFallbackButtonAudit(){
    if(window.__LR75B_BUTTON_AUDIT__) return;
    window.__LR75B_BUTTON_AUDIT__ = true;
    document.addEventListener('click', function(ev){
      var btn = ev.target && ev.target.closest ? ev.target.closest('button') : null;
      if(!btn) return;
      var act = btn.getAttribute('data-lr75b-act');
      if(act){ ev.preventDefault(); /* 7.6W: do not swallow normal clicks */ routeAction(act); return; }
      // If a visible button has no handler but uses obvious game wording, catch it and route safely.
      var hasHandler = !!(btn.getAttribute('onclick') || btn.getAttribute('data-lr75a-act') || btn.getAttribute('data-lr73p-act') || btn.getAttribute('data-lr74x-act') || btn.getAttribute('data-lr74k-act'));
      if(hasHandler) return;
      var t = norm(btn.textContent || '');
      var map = {
        realmlibrary:'library', allwings:'library', backtorealmlibrary:'library', returntorealmlibrary:'library',
        historywing:'wing:history', historyandworldwing:'wing:history', bibleroad:'wing:bible', sciencequarter:'wing:science', scienceandengineeringquarter:'wing:science', corehalls:'wing:core', creativequarter:'wing:creative', homesteadworkshop:'wing:homestead',
        realmatlas:'stable:atlas', townnoticeboard:'stable:livingworld', livingworldledger:'stable:livingworld', home:'stable:home', homestead:'stable:home'
      };
      if(map[t]){ ev.preventDefault(); /* 7.6W: do not swallow normal clicks */ routeAction(map[t]); }
    }, true);
  }

  function installStyles(){
    if(byId('lr75bCourseDoorPolishStyles')) return;
    var st=document.createElement('style'); st.id='lr75bCourseDoorPolishStyles';
    st.textContent = `
      .lr75bCourseRail{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;margin:12px 0 14px;padding:12px;border:1px solid rgba(255,225,150,.34);border-radius:18px;background:linear-gradient(135deg,rgba(17,37,36,.94),rgba(66,39,15,.88));box-shadow:0 14px 30px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.08);color:#f7ecd0;}
      .lr75bRailBadge{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:center;min-width:0;}
      .lr75bRailBadge span{grid-row:1/3;width:46px;height:46px;border-radius:15px;display:grid;place-items:center;font-size:1.55rem;background:rgba(255,237,178,.12);border:1px solid rgba(255,232,166,.32);}
      .lr75bRailBadge b{color:#fff2bd;font-size:1rem;line-height:1.15;}
      .lr75bRailBadge small{color:#aee8d0;font-size:.72rem;font-weight:900;text-transform:uppercase;letter-spacing:.06em;}
      .lr75bRailButtons{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;}
      .lr75bRailButtons button,.lr75bPolishedCourseSurface .lr75bCourseRail button{border:1px solid rgba(255,232,166,.38);border-radius:999px;background:rgba(255,231,165,.13);color:#fff3cf;font-weight:900;padding:9px 12px;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.06);}
      .lr75bRailButtons button:hover{background:rgba(255,231,165,.22);border-color:rgba(255,238,185,.7);}
      .lr75bAdventureDoor{position:relative;overflow:hidden;border-radius:16px !important;box-shadow:0 12px 26px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.07) !important;}
      .lr75bAdventureDoor:after{content:'';position:absolute;inset:0;pointer-events:none;background:linear-gradient(120deg,rgba(255,238,168,.10),transparent 32%,rgba(95,205,186,.06));opacity:.7;}
      .lr75bPolishedCourseSurface [class*='Grid'],.lr75bPolishedCourseSurface [class*='grid']{gap:12px;}
      .lr75bPolishedCourseSurface [class*='Nav'],.lr75bPolishedCourseSurface [class*='Foot'],.lr75bPolishedCourseSurface [class*='Footer']{gap:8px;flex-wrap:wrap;}
      .lr75bNotice{margin:10px 0;padding:10px 12px;border:1px solid rgba(255,220,140,.35);border-radius:14px;background:rgba(52,32,10,.82);color:#f7ecd0;}
      .lr75aDoorCard.lr75bAdventureDoor{min-height:146px;}
      @media(max-width:850px){.lr75bCourseRail{grid-template-columns:1fr}.lr75bRailButtons{justify-content:flex-start}.lr75bRailButtons button{width:100%;}}
    `;
    document.head.appendChild(st);
  }

  function boot(){ installStyles(); wrapKnownCourseDoors(); makeLibraryMoreGameLike(); installFallbackButtonAudit(); setTimeout(polishAll,40); setTimeout(polishAll,500); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,150); setTimeout(polishAll,1000); });
  window.lr75bPolishAll = polishAll;
  window.openRealmLibrary75B = window.openRealmLibrary75B || function(subject){ return has('openRealmLibrary75A') ? window.openRealmLibrary75A(subject||'all') : openLibrary(); };
})();
