// Grade Ladder Pack G7: Grade 7 Foundation
// Tagged with gradeBand:"G7" for the Grade Ladder system.
// Curriculum only. No engine/world changes.

function LR_addG7Foundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"G7",unit:"G7-READ-EVIDENCE",skill:"strong text evidence",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Strong text evidence directly supports an answer or claim.",
     workedExample:"If the claim is that a character is cautious, evidence should show careful actions, such as checking the path before crossing.",
     guidedPractice:"Choose the detail that proves the idea most directly.",
     q:"Which detail best proves a character is cautious?",
     c:["The character tested the bridge before stepping on it.","The bridge was old.","The sky was cloudy."],a:"The character tested the bridge before stepping on it.",
     explain:"Testing the bridge before stepping shows cautious behavior."},

    {gradeBand:"G7",unit:"G7-READ-INFERENCE",skill:"inference with evidence",difficulty:"grade 7",mode:"foundation",
     miniLesson:"A strong inference must be supported by evidence.",
     workedExample:"If a character hides a letter and refuses to meet anyone's eyes, you can infer the character is keeping a secret.",
     guidedPractice:"Use actions and details as clues.",
     q:"A character hides a letter and avoids eye contact. What can you infer?",
     c:["The character may be hiding something.","The character is flying.","The character is measuring a circle."],a:"The character may be hiding something.",
     explain:"Hiding the letter and avoiding eye contact support the inference."},

    {gradeBand:"G7",unit:"G7-READ-ANALYSIS",skill:"theme analysis",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Theme analysis explains how a theme develops across a text.",
     workedExample:"If a character begins fearful but later faces danger to help others, the theme may develop around courage.",
     guidedPractice:"Look at how the character changes.",
     q:"A fearful character learns to act bravely for others. Which theme fits?",
     c:["Courage can grow through choice.","Decimals use place value.","Maps have symbols."],a:"Courage can grow through choice.",
     explain:"The character's change supports a theme about courage growing through action."},

    {gradeBand:"G7",unit:"G7-READ-STRUCTURE",skill:"author's structure",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Authors organize texts in different ways, such as cause/effect, problem/solution, comparison, or sequence.",
     workedExample:"A passage that explains a village's water problem and then describes how people solved it uses problem/solution.",
     guidedPractice:"Find whether the text presents a problem and a fix.",
     q:"A passage explains a food shortage and then describes a new farming plan. Which structure is likely used?",
     c:["problem and solution","alphabet order","rhyme only"],a:"problem and solution",
     explain:"The text presents a problem and then a solution."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"G7",unit:"G7-MATH-RATIO",skill:"proportional relationships",difficulty:"grade 7",mode:"foundation",
     miniLesson:"A proportional relationship has a constant ratio between two quantities.",
     workedExample:"If y = 4x, then every x value is multiplied by 4 to get y. The constant of proportionality is 4.",
     guidedPractice:"Look for the number multiplied by x.",
     q:"In y = 4x, the constant of proportionality is...",
     c:["4","x","y"],a:"4",
     explain:"The value multiplying x is 4."},

    {gradeBand:"G7",unit:"G7-MATH-PERCENT",skill:"percent change",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Percent change compares the amount of change to the original amount.",
     workedExample:"If a value goes from 50 to 60, the increase is 10. 10 out of 50 is 20%, so the increase is 20%.",
     guidedPractice:"Find change first, then compare it to the original.",
     q:"A value goes from 50 to 60. What is the increase?",
     c:["10","20","60"],a:"10",
     explain:"60 minus 50 equals an increase of 10."},

    {gradeBand:"G7",unit:"G7-MATH-INTEGERS",skill:"integer operations",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Integer operations follow sign rules.",
     workedExample:"A negative times a negative is positive. So -6 × -3 = 18.",
     guidedPractice:"Check the signs before multiplying.",
     q:"-6 × -3 = ?",
     c:["18","-18","9"],a:"18",
     explain:"Two negative factors multiply to a positive product."},

    {gradeBand:"G7",unit:"G7-MATH-EQUATIONS",skill:"two-step equations",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Solve two-step equations by undoing addition or subtraction first, then multiplication or division.",
     workedExample:"5x - 4 = 31. Add 4 to get 5x = 35. Divide by 5 to get x = 7.",
     guidedPractice:"Undo the subtraction first.",
     q:"5x - 4 = 31. What is x?",
     c:["7","5","35"],a:"7",
     explain:"Add 4 to both sides, then divide 35 by 5."},

    {gradeBand:"G7",unit:"G7-MATH-GEOMETRY",skill:"circle basics",difficulty:"grade 7",mode:"foundation",
     miniLesson:"The circumference is the distance around a circle.",
     workedExample:"The formula C = πd uses diameter to find circumference.",
     guidedPractice:"Remember that circumference is around the circle, not inside it.",
     q:"Circumference means...",
     c:["distance around a circle","space inside a circle","the middle point"],a:"distance around a circle",
     explain:"Circumference is the distance around the circle."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"G7",unit:"G7-ELA-WRITING",skill:"claim evidence reasoning",difficulty:"grade 7",mode:"foundation",
     miniLesson:"A strong written response often uses claim, evidence, and reasoning.",
     workedExample:"Claim: The character is loyal. Evidence: He stays to protect his friend. Reasoning: This shows loyalty because he risks his own safety for someone else.",
     guidedPractice:"Make sure the reasoning explains why the evidence proves the claim.",
     q:"In CER, reasoning explains...",
     c:["how evidence supports the claim","only the title","where the page number is"],a:"how evidence supports the claim",
     explain:"Reasoning connects the evidence to the claim."},

    {gradeBand:"G7",unit:"G7-ELA-WRITING",skill:"argument writing",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Argument writing states a claim and supports it with evidence and reasoning.",
     workedExample:"A strong argument might claim that the bridge should be repaired, then use evidence about safety and travel.",
     guidedPractice:"Choose the statement that can be defended with reasons.",
     q:"Which is an argument claim?",
     c:["The bridge should be repaired for safety.","The bridge is brown.","The bridge has stones."],a:"The bridge should be repaired for safety.",
     explain:"This takes a position that can be supported with reasons."},

    {gradeBand:"G7",unit:"G7-ELA-LANGUAGE",skill:"precise language",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Precise language makes writing clearer.",
     workedExample:"Instead of saying 'the thing moved,' write 'the lantern swung' or 'the cart rolled.'",
     guidedPractice:"Choose the specific word.",
     q:"Which word is more precise than moved?",
     c:["sprinted","thing","stuff"],a:"sprinted",
     explain:"Sprinted gives a more specific action than moved."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"G7",unit:"G7-SCI-CELLS",skill:"cell structures",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Cells have structures that do different jobs.",
     workedExample:"The nucleus stores instructions. The cell membrane controls what enters and leaves.",
     guidedPractice:"Match the structure to its job.",
     q:"Which cell structure controls what enters and leaves?",
     c:["cell membrane","nucleus","ribosome"],a:"cell membrane",
     explain:"The cell membrane controls movement into and out of the cell."},

    {gradeBand:"G7",unit:"G7-SCI-ECOSYSTEMS",skill:"food webs",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Food webs show feeding relationships in an ecosystem.",
     workedExample:"Grass feeds rabbits, rabbits feed foxes, and decomposers break down dead matter.",
     guidedPractice:"Follow the energy from producers to consumers.",
     q:"In a food web, producers usually get energy from...",
     c:["sunlight","foxes","rocks"],a:"sunlight",
     explain:"Plants and many producers use sunlight to make food."},

    {gradeBand:"G7",unit:"G7-SCI-EARTH",skill:"weathering erosion deposition",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Weathering breaks material down, erosion moves it, and deposition drops it in a new place.",
     workedExample:"A river erodes soil from a bank and later deposits sediment downstream.",
     guidedPractice:"Ask whether material is breaking, moving, or being dropped.",
     q:"Sediment being dropped in a new place is...",
     c:["deposition","erosion","weathering"],a:"deposition",
     explain:"Deposition happens when sediment is laid down."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"G7",unit:"G7-SS-SOURCES",skill:"bias and perspective",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Bias or perspective can affect how a source presents information.",
     workedExample:"A merchant and a farmer may describe the same tax differently because it affects them differently.",
     guidedPractice:"Ask who made the source and what they might care about.",
     q:"Source perspective can affect how events are...",
     c:["described","multiplied","evaporated"],a:"described",
     explain:"A source's point of view can shape its description of events."},

    {gradeBand:"G7",unit:"G7-SS-CIVICS",skill:"limited government",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Limited government means government power is restricted by law.",
     workedExample:"A constitution can limit what leaders are allowed to do.",
     guidedPractice:"Look for rules that keep power from becoming unlimited.",
     q:"Limited government restricts...",
     c:["power","weather","division"],a:"power",
     explain:"Limited government prevents unlimited power."},

    {gradeBand:"G7",unit:"G7-SS-ECON",skill:"scarcity and choices",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Scarcity means resources are limited, so people must make choices.",
     workedExample:"If a town has only enough stone for one wall, leaders must choose where to build it.",
     guidedPractice:"Ask what is limited and what choice must be made.",
     q:"Scarcity forces people to make...",
     c:["choices","clouds","digraphs"],a:"choices",
     explain:"When resources are limited, people must choose how to use them."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"G7",unit:"G7-ART-COLOR",skill:"color mood",difficulty:"grade 7",mode:"foundation",
     miniLesson:"Artists use color to affect mood.",
     workedExample:"Cool blues and greens may feel calm. Hot reds and oranges may feel energetic or tense.",
     guidedPractice:"Match the color family to the mood.",
     q:"Which colors often feel cool or calm?",
     c:["blue and green","red and orange","yellow and red only"],a:"blue and green",
     explain:"Blue and green are usually cool colors and can create a calm mood."},

    {gradeBand:"G7",unit:"G7-ART-COMPOSITION",skill:"focal point",difficulty:"grade 7",mode:"foundation",
     miniLesson:"A focal point is the area the viewer notices first.",
     workedExample:"An artist can create a focal point with size, contrast, placement, or detail.",
     guidedPractice:"Ask where your eye goes first and why.",
     q:"A focal point is the area viewers notice...",
     c:["first","last only","never"],a:"first",
     explain:"The focal point draws the viewer's attention first."}
  ]);
}

LR_addG7Foundation("Luna");
LR_addG7Foundation("Ava");
LR_addG7Foundation("Michael");
