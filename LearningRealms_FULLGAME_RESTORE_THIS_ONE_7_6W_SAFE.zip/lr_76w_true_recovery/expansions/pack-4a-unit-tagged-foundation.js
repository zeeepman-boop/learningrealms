// Curriculum Pack 4A: First Unit-Tagged Foundation Pack
// Small tagged pack to activate unit-progress tracking.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Reading",[
 {unit:"G1-READ-PHONICS",skill:"short vowels",difficulty:"core",mode:"lesson",teach:"Short vowels usually make a quick sound.",practice:"cat, bed, pig, hop, sun",q:"Which word has the short i sound?",c:["pig","cake","tree"],a:"pig"},
 {unit:"G1-READ-PHONICS",skill:"digraphs",difficulty:"core",mode:"lesson",teach:"SH is a digraph. S and H work together to make one sound.",practice:"ship, shell, shop",q:"Which word starts with SH?",c:["ship","tree","flag"],a:"ship"},
 {unit:"G1-READ-PHONICS",skill:"long vowels",difficulty:"core",mode:"lesson",teach:"Final e can help a vowel say its name.",practice:"cap becomes cape.",q:"Which word has a long a sound?",c:["cape","cap","cat"],a:"cape"},
 {unit:"G1-READ-COMP",skill:"character",difficulty:"core",mode:"lesson",teach:"A character is who the story is about.",practice:"The fox found a lantern.",q:"Who is the character?",c:["fox","lantern","found"],a:"fox"},
 {unit:"G1-READ-COMP",skill:"setting",difficulty:"core",mode:"lesson",teach:"The setting is where the story happens.",practice:"The frog sat beside the pond.",q:"What is the setting?",c:["pond","frog","sat"],a:"pond"}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-SENTENCES",skill:"complete sentences",difficulty:"core",mode:"lesson",teach:"A complete sentence tells a whole idea.",practice:"The owl flew.",q:"Which is a complete sentence?",c:["The owl flew.","owl","flew"],a:"The owl flew."},
 {unit:"G1-ELA-SENTENCES",skill:"capital letters",difficulty:"core",mode:"lesson",teach:"A sentence begins with a capital letter.",practice:"The rabbit hops.",q:"Which starts correctly?",c:["The rabbit hops.","the rabbit hops.","Rabbit hops"],a:"The rabbit hops."},
 {unit:"G1-ELA-WRITING",skill:"adding details",difficulty:"core",mode:"lesson",teach:"Details tell more.",practice:"The fox ran through the quiet woods.",q:"Which sentence has more detail?",c:["The fox ran through the quiet woods.","The fox ran.","Fox."],a:"The fox ran through the quiet woods."}
]);

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"make ten",difficulty:"core",mode:"lesson",teach:"Making ten can make addition easier.",practice:"8 + 2 + 4 = 14.",q:"8 + 2 + 4 = ?",c:["14","10","12"],a:"14"},
 {unit:"G1-MATH-FACTS",skill:"subtraction within 20",difficulty:"core",mode:"lesson",teach:"Subtraction means taking away.",practice:"15 - 6 = 9.",q:"15 - 6 = ?",c:["9","8","10"],a:"9"},
 {unit:"G1-MATH-PLACE",skill:"tens and ones",difficulty:"core",mode:"lesson",teach:"Two-digit numbers have tens and ones.",practice:"42 has 4 tens and 2 ones.",q:"42 has how many tens?",c:["4","2","42"],a:"4"},
 {unit:"G1-MATH-MEASURE",skill:"coins",difficulty:"core",mode:"lesson",teach:"A nickel is 5 cents.",practice:"Two nickels make 10 cents.",q:"Two nickels equal...",c:["10 cents","5 cents","25 cents"],a:"10 cents"}
]);

LR_addLessons("Luna","Science",[
 {unit:"G1-SCI-LIFE",skill:"plant parts",difficulty:"core",mode:"lesson",teach:"Roots help hold a plant in the ground.",practice:"Roots are usually under the soil.",q:"Which plant part holds the plant in soil?",c:["roots","flower","leaf"],a:"roots"},
 {unit:"G1-SCI-EARTH",skill:"weather",difficulty:"core",mode:"lesson",teach:"Weather tells what the sky and air are like today.",practice:"sunny, rainy, windy",q:"Which word describes weather?",c:["windy","yesterday","map"],a:"windy"}
]);

LR_addLessons("Luna","History",[
 {unit:"G1-SS-COMMUNITY",skill:"needs",difficulty:"core",mode:"lesson",teach:"Needs are things people must have.",practice:"Food and water are needs.",q:"Which is a need?",c:["water","toy","painting"],a:"water"}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-RATIO",skill:"unit rates",difficulty:"core",mode:"lesson",teach:"A unit rate compares a quantity to one unit.",practice:"120 miles in 3 hours is 40 miles per hour.",q:"120 miles in 3 hours is...",c:["40 miles per hour","123 miles per hour","30 miles per hour"],a:"40 miles per hour"},
 {unit:"G7-MATH-RATIO",skill:"percent",difficulty:"core",mode:"lesson",teach:"Percent means out of 100.",practice:"18 out of 100 is 18%.",q:"18% means 18 out of...",c:["100","18","10"],a:"100"},
 {unit:"G7-MATH-INT",skill:"integer addition",difficulty:"core",mode:"lesson",teach:"When adding numbers with different signs, subtract and keep the sign of the larger absolute value.",practice:"-10 + 4 = -6.",q:"-10 + 4 = ?",c:["-6","14","6"],a:"-6"},
 {unit:"G7-MATH-EQ",skill:"two-step equations",difficulty:"core",mode:"lesson",teach:"Undo addition or subtraction before multiplication or division.",practice:"3x + 5 = 20 gives x = 5.",q:"3x + 5 = 20. x = ?",c:["5","15","25"],a:"5"},
 {unit:"G7-MATH-GEO-DATA",skill:"circumference",difficulty:"core",mode:"lesson",teach:"Circumference is the distance around a circle.",practice:"C = πd.",q:"Circumference means...",c:["distance around a circle","inside area","middle point"],a:"distance around a circle"}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-EVIDENCE",skill:"text evidence",difficulty:"core",mode:"lesson",teach:"Text evidence proves an answer using words or details from the text.",practice:"Use a quote or specific detail.",q:"Text evidence is...",c:["proof from the text","a random guess","the cover color"],a:"proof from the text"},
 {unit:"G7-ELA-EVIDENCE",skill:"inference",difficulty:"core",mode:"lesson",teach:"An inference uses clues plus reasoning.",practice:"A character shivers and pulls on a coat.",q:"What can you infer?",c:["The character is cold.","The character is swimming.","The character is cooking."],a:"The character is cold."},
 {unit:"G7-ELA-WRITING",skill:"claim",difficulty:"core",mode:"lesson",teach:"A claim is a clear answer or position.",practice:"The character is brave.",q:"Which is a claim?",c:["The character is brave.","Because","Page 4"],a:"The character is brave."}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-LIFE",skill:"producers",difficulty:"core",mode:"lesson",teach:"Producers make their own food, usually using sunlight.",practice:"Most plants are producers.",q:"Which is a producer?",c:["plant","fox","owl"],a:"plant"},
 {unit:"G7-SCI-EARTH",skill:"erosion",difficulty:"core",mode:"lesson",teach:"Erosion moves weathered rock or soil.",practice:"Water can carry soil downhill.",q:"Erosion means soil or rock is...",c:["moved","spelled","voted on"],a:"moved"},
 {unit:"G7-SCI-PHYSICAL",skill:"controlled experiment",difficulty:"core",mode:"lesson",teach:"A controlled experiment changes one main variable at a time.",practice:"Only the water amount changes.",q:"A controlled experiment changes how many main variables?",c:["one","all","none"],a:"one"}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"primary sources",difficulty:"core",mode:"lesson",teach:"A primary source comes from the time being studied.",practice:"A diary written during an event is primary.",q:"Which is a primary source?",c:["diary from the event","modern textbook","new cartoon"],a:"diary from the event"},
 {unit:"G7-SS-CIVICS",skill:"citizenship",difficulty:"core",mode:"lesson",teach:"Citizenship includes rights and responsibilities.",practice:"Voting and obeying laws are civic actions.",q:"Citizenship includes rights and...",c:["responsibilities","evaporation","fractions"],a:"responsibilities"},
 {unit:"G7-SS-ECON",skill:"supply",difficulty:"core",mode:"lesson",teach:"Supply means how much of something is available.",practice:"More apples in a market means higher supply.",q:"Supply means how much is...",c:["available","wanted","hidden"],a:"available"}
]);

LR_addLessons("Ava","Reading",[
 {unit:"G7-ELA-EVIDENCE",skill:"theme",difficulty:"core",mode:"lesson",teach:"Theme is a message or lesson developed by a story.",practice:"Keep trying even when something is hard.",q:"Theme means...",c:["message or lesson","font size","chapter number"],a:"message or lesson"}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-EQ",skill:"variables both sides",difficulty:"core",mode:"lesson",teach:"Move variable terms together when solving equations.",practice:"7x + 4 = 3x + 20 gives 4x = 16.",q:"7x + 4 = 3x + 20. x = ?",c:["4","16","24"],a:"4"},
 {unit:"G8-MATH-EQ",skill:"distributive property",difficulty:"core",mode:"lesson",teach:"Use the distributive property before solving.",practice:"2(x + 6) = 24 gives x = 6.",q:"2(x + 6) = 24. x = ?",c:["6","12","18"],a:"6"},
 {unit:"G8-MATH-FUNC",skill:"slope",difficulty:"core",mode:"lesson",teach:"Slope is change in y divided by change in x.",practice:"From (1,2) to (3,8), slope is 6/2.",q:"What is the slope?",c:["3","6","2"],a:"3"},
 {unit:"G8-MATH-FUNC",skill:"y-intercept",difficulty:"core",mode:"lesson",teach:"The y-intercept is where the graph crosses the y-axis.",practice:"In y = 4x + 9, the y-intercept is 9.",q:"In y = 4x + 9, the y-intercept is...",c:["9","4","13"],a:"9"},
 {unit:"G8-MATH-GEO-DATA",skill:"Pythagorean theorem",difficulty:"core",mode:"lesson",teach:"The Pythagorean theorem is used with right triangles.",practice:"a² + b² = c².",q:"Pythagorean theorem applies to...",c:["right triangles","all circles","all graphs"],a:"right triangles"}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"thesis",difficulty:"core",mode:"lesson",teach:"A thesis states the main argument.",practice:"The essay will prove this point.",q:"A thesis states the...",c:["main argument","page number","weather"],a:"main argument"},
 {unit:"G8-ELA-ARG",skill:"counterclaim",difficulty:"core",mode:"lesson",teach:"A counterclaim gives an opposing view.",practice:"Some people may argue differently.",q:"A counterclaim is an opposing...",c:["view","source date","paragraph title"],a:"view"},
 {unit:"G8-ELA-RESEARCH",skill:"source reliability",difficulty:"core",mode:"lesson",teach:"Reliable sources can be checked for author, date, evidence, and purpose.",practice:"Check who made it and why.",q:"Which helps judge source reliability?",c:["author and evidence","font size only","page color"],a:"author and evidence"}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-MATTER",skill:"atoms",difficulty:"core",mode:"lesson",teach:"Atoms contain protons, neutrons, and electrons.",practice:"Electrons have a negative charge.",q:"Which particle is negative?",c:["electron","proton","neutron"],a:"electron"},
 {unit:"G8-SCI-MATTER",skill:"chemical change",difficulty:"core",mode:"lesson",teach:"A chemical change makes a new substance.",practice:"Rusting forms a new substance.",q:"Rusting is a...",c:["chemical change","physical change","function"],a:"chemical change"},
 {unit:"G8-SCI-FORCE",skill:"Newton's laws",difficulty:"core",mode:"lesson",teach:"Newton's second law connects force, mass, and acceleration.",practice:"F = ma.",q:"Newton's second law is...",c:["F = ma","y = mx + b","C = πd"],a:"F = ma"}
]);

LR_addLessons("Michael","History",[
 {unit:"G8-SS-CIVICS",skill:"checks and balances",difficulty:"core",mode:"lesson",teach:"Checks and balances help limit government power.",practice:"Branches can check one another.",q:"Checks and balances limit...",c:["power","weather","density"],a:"power"},
 {unit:"G8-SS-ECON",skill:"scarcity",difficulty:"core",mode:"lesson",teach:"Scarcity means resources are limited compared with wants.",practice:"People must make choices.",q:"Scarcity means resources are...",c:["limited","unlimited","unused"],a:"limited"},
 {unit:"G8-SS-HISTORICAL",skill:"bias",difficulty:"core",mode:"lesson",teach:"Bias can affect how a source presents information.",practice:"A writer may favor one side.",q:"Bias can affect source...",c:["presentation","volume","speed"],a:"presentation"}
]);

LR_addLessons("Michael","Civics",[
 {unit:"G8-SS-CIVICS",skill:"rule of law",difficulty:"core",mode:"lesson",teach:"Rule of law means everyone is subject to the law.",practice:"Leaders and citizens must follow laws.",q:"Rule of law applies to...",c:["everyone","only rulers","only children"],a:"everyone"}
]);
