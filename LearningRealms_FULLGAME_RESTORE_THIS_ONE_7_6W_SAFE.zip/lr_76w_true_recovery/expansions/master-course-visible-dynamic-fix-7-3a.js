/* LearningRealms Master Course Visible Dynamic Fix 7.3A
   Fixes the hidden-course problem by wiring the three emphasized courses into the ACTIVE dynamic screen:
   - visible banner on the main adventure screen
   - first cards in Go Learn / Learning Trails
   - direct quick dock fallback
   - game menu select options
   Content-only visibility patch. No save reset, no engine rewrite.
*/
(function(){
  'use strict';
  if(window.__LR_MASTER_COURSE_VISIBLE_FIX_73A__) return;
  window.__LR_MASTER_COURSE_VISIBLE_FIX_73A__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v == null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function can(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    try{ if(can(fn)) return window[fn](); }
    catch(e){ console.warn('Master course button failed:', fn, e); }
    return false;
  }
  function mount(){ return byId('lrDynamicAdventureScreen') || byId('lrCleanGameShell') || document.querySelector('.main > .card:first-child') || document.querySelector('main') || document.body; }

  var COURSES = [
    { key:'depression', icon:'🏚️', title:'The Great Depression', meta:'Master Course 7.1 · history and economics', body:'Open History Street with the 1930s lessons, proof quizzes, reward catalog, and missed-question review.', trail:'openGreatDepressionTrail', course:'openGreatDepressionCourse', reward:'openGreatDepressionRewards', shop:'' },
    { key:'wildwest', icon:'🤠', title:'The Wild West', meta:'Master Course 7.2 · kid-safe frontier history', body:'Open Frontier Trail with trails, homesteads, railroads, cattle drives, shops, rewards, and myth checking.', trail:'openWildWestTrail', course:'openWildWestCourse', reward:'openWildWestRewards', shop:'openWildWestShops' },
    { key:'bible', icon:'⛪', title:'Bible History: Catholic Theology', meta:'Master Course 7.3 · reverent and kid-safe', body:'Open Pilgrim Road for Scripture history, Jesus, Mary, apostles, saints, angels, sacraments, feast days, virtue, and mercy.', trail:'openBibleHistoryTrail', course:'openBibleHistoryCourse', reward:'openBibleHistoryRewards', shop:'openBibleHistoryShops' }
  ];

  function availableCourse(c){ return can(c.trail) || can(c.course); }
  function runCourse(key, which){
    var c = null;
    COURSES.forEach(function(x){ if(x.key === key) c = x; });
    if(!c) return false;
    var fn = c[which] || c.trail || c.course;
    if(can(fn)) return call(fn);
    var m = mount();
    if(m) m.insertAdjacentHTML('afterbegin','<div class="lrMasterVisibleWarn">That course file is not loaded yet. Close and reopen the newest zip build.</div>');
    return false;
  }

  function bannerHtml(){
    return '<section class="lrMasterVisibleBanner" data-master-visible-73a="banner">' +
      '<div class="lrMasterVisibleHead"><span>📚 Brittney Master Courses</span><small>Direct buttons added to the active Dynamic Learning screen.</small></div>' +
      '<div class="lrMasterVisibleCards">' + COURSES.map(function(c){
        var disabled = availableCourse(c) ? '' : ' disabled';
        var onclick = availableCourse(c) ? 'lrMasterRun73A(\''+c.key+'\',\'trail\')' : 'lrMasterOpenHub73A()';
        return '<button type="button" class="lrMasterVisibleCard"'+disabled+' onclick="'+onclick+'">' +
          '<b>'+esc(c.icon+' '+c.title)+'</b><small>'+esc(c.meta)+'</small><p>'+esc(c.body)+'</p>' +
        '</button>';
      }).join('') + '</div>' +
    '</section>';
  }

  function hubHtml(){
    return '<div class="lrMasterVisibleHub">' +
      '<section class="lrMasterVisibleHero"><small>Visibility Fix 7.3A</small><h2>Brittney Master Courses</h2><p>These are direct access buttons for the three emphasized courses. They are now wired into the dynamic screen, not only the older menu layer.</p></section>' +
      '<div class="lrMasterVisibleHubGrid">' + COURSES.map(function(c){
        var bits = '<button type="button" class="lrMasterVisibleOpen" onclick="lrMasterRun73A(\''+c.key+'\',\'trail\')">Open guided trail</button>';
        if(c.course) bits += '<button type="button" onclick="lrMasterRun73A(\''+c.key+'\',\'course\')">Course map</button>';
        if(c.reward) bits += '<button type="button" onclick="lrMasterRun73A(\''+c.key+'\',\'reward\')">Rewards</button>';
        if(c.shop) bits += '<button type="button" onclick="lrMasterRun73A(\''+c.key+'\',\'shop\')">Shops</button>';
        return '<article><h3>'+esc(c.icon+' '+c.title)+'</h3><small>'+esc(c.meta)+'</small><p>'+esc(c.body)+'</p><div>'+bits+'</div></article>';
      }).join('') + '</div>' +
      '<div class="lrMasterVisibleFoot"><button type="button" onclick="window.lr68OpenLearn&&window.lr68OpenLearn()">Back to Learning Trails</button><button type="button" onclick="window.lr68Render&&window.lr68Render(\'room\',\'Master course hub closed.\')">Back to current scene</button></div>' +
    '</div>';
  }

  function openHub(){
    var m = mount();
    if(!m) return false;
    try{ document.body.classList.add('lrDynamicAdventureMode','lrMasterVisibleMode'); }catch(e){}
    m.innerHTML = hubHtml();
    return false;
  }

  function injectBanner(){
    try{
      var m = byId('lrDynamicAdventureScreen');
      if(!m) return;
      if(m.querySelector('[data-master-visible-73a="banner"]')) return;
      var firstSection = m.querySelector('.lr68SceneHero,.lr68bHero,.lr68cEmbeddedTop');
      var div = document.createElement('div');
      div.innerHTML = bannerHtml();
      var node = div.firstChild;
      if(firstSection && firstSection.nextSibling) firstSection.parentNode.insertBefore(node, firstSection.nextSibling);
      else if(firstSection) firstSection.parentNode.appendChild(node);
      else m.insertBefore(node, m.firstChild);
    }catch(e){ console.warn('Master banner injection failed', e); }
  }

  function courseTrailCard(c){
    var onclick = availableCourse(c) ? 'lrMasterRun73A(\''+c.key+'\',\'trail\')' : 'lrMasterOpenHub73A()';
    return '<button type="button" class="lr68bTrailCard lrMasterTrailCard73A" data-master-card-73a="'+esc(c.key)+'" onclick="'+onclick+'">' +
      '<span class="lr68bTrailText"><b>'+esc(c.icon+' '+c.title)+'</b><small>'+esc(c.meta)+'</small><p>'+esc(c.body)+'</p></span><span class="lr68bTrailArrow">›</span>' +
    '</button>';
  }

  function injectTrailCards(){
    try{
      var grid = document.querySelector('#lrDynamicAdventureScreen .lr68bTrailGrid') || document.querySelector('.lr68bTrailGrid');
      if(!grid) return;
      if(!grid.querySelector('[data-master-card-73a="bible"]')){
        var wrap = document.createElement('div');
        wrap.innerHTML = COURSES.map(courseTrailCard).join('');
        for(var i=wrap.childNodes.length-1;i>=0;i--) grid.insertBefore(wrap.childNodes[i], grid.firstChild);
      }
      var hero = document.querySelector('#lrDynamicAdventureScreen .lr68bHero');
      if(hero && !hero.querySelector('[data-master-visible-73a="learn-note"]')){
        var note = document.createElement('div');
        note.setAttribute('data-master-visible-73a','learn-note');
        note.className = 'lrMasterLearnNote73A';
        note.innerHTML = '<b>Now visible:</b> Great Depression, Wild West, and Bible History are pinned as the first course cards below.';
        hero.appendChild(note);
      }
    }catch(e){ console.warn('Master trail injection failed', e); }
  }

  function installQuickDock(){
    try{
      if(byId('lrMasterQuickDock73A')) return;
      var dock = document.createElement('div');
      dock.id = 'lrMasterQuickDock73A';
      dock.innerHTML = '<button type="button" onclick="lrMasterOpenHub73A()">📚 Master Courses</button>' +
        '<button type="button" onclick="lrMasterRun73A(\'depression\',\'trail\')">Depression</button>' +
        '<button type="button" onclick="lrMasterRun73A(\'wildwest\',\'trail\')">Wild West</button>' +
        '<button type="button" onclick="lrMasterRun73A(\'bible\',\'trail\')">Bible</button>';
      document.body.appendChild(dock);
    }catch(e){}
  }

  function addMenuOptions(){
    try{
      var sel = byId('gameMenuSelect');
      if(!sel || sel.querySelector('option[value="masterCourses73A"]')) return;
      var opts = [
        ['masterCourses73A','📚 Master Courses'],
        ['masterGreatDepression73A','🏚️ Great Depression'],
        ['masterWildWest73A','🤠 Wild West'],
        ['masterBible73A','⛪ Bible History']
      ];
      opts.forEach(function(o){ var opt=document.createElement('option'); opt.value=o[0]; opt.textContent=o[1]; sel.appendChild(opt); });
      sel.addEventListener('change', function(){
        if(sel.value === 'masterCourses73A') openHub();
        if(sel.value === 'masterGreatDepression73A') runCourse('depression','trail');
        if(sel.value === 'masterWildWest73A') runCourse('wildwest','trail');
        if(sel.value === 'masterBible73A') runCourse('bible','trail');
      }, true);
    }catch(e){}
  }

  function wrap(name, after){
    try{
      var old = window[name];
      if(typeof old !== 'function' || old.__masterVisible73A) return;
      var repl = function(){
        var out = old.apply(this, arguments);
        [40,160,420,900].forEach(function(ms){ setTimeout(after, ms); });
        return out;
      };
      repl.__masterVisible73A = true;
      repl.__old = old;
      window[name] = repl;
      try{ eval(name + ' = window["' + name + '"];'); }catch(e){}
    }catch(e){}
  }

  function wireLearn(){
    wrap('lr68OpenLearn', function(){ injectTrailCards(); injectBanner(); });
    wrap('lr68bOpenLearningTrails', function(){ injectTrailCards(); injectBanner(); });
    wrap('lr68Render', function(){ injectBanner(); });
    wrap('lrHardRefreshRoom', function(){ injectBanner(); });
  }

  function styles(){
    if(byId('lrMasterVisible73AStyles')) return;
    var st = document.createElement('style'); st.id = 'lrMasterVisible73AStyles';
    st.textContent = `
      .lrMasterVisibleBanner{margin:0;padding:18px 22px;background:linear-gradient(135deg,#fff3c2,#f1f7ff 45%,#fff8df);border-bottom:1px solid rgba(41,63,86,.20);color:#203437;box-shadow:0 8px 18px rgba(0,0,0,.10)}
      .lrMasterVisibleHead{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px;font-weight:950;color:#193c43}.lrMasterVisibleHead span{font-size:1.08rem}.lrMasterVisibleHead small{font-weight:850;color:#596860}
      .lrMasterVisibleCards{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:11px}.lrMasterVisibleCard{min-height:116px;text-align:left;border:2px solid rgba(126,89,25,.26);border-radius:17px;background:#fffefa;color:#243739;padding:13px 14px;box-shadow:0 7px 15px rgba(0,0,0,.12);cursor:pointer}.lrMasterVisibleCard b{display:block;font-size:1.04rem;line-height:1.25;color:#152f35}.lrMasterVisibleCard small{display:block;margin-top:5px;font-weight:950;color:#76541b;text-transform:uppercase;letter-spacing:.035em;font-size:.72rem}.lrMasterVisibleCard p{margin:7px 0 0;line-height:1.34;font-weight:740;color:#3e514d}.lrMasterVisibleCard:disabled{opacity:.55;cursor:not-allowed}
      .lrMasterTrailCard73A{border:3px solid #f2cf5b!important;background:linear-gradient(135deg,#fff9dc,#ffffff)!important}.lrMasterLearnNote73A{margin-top:12px;padding:10px 12px;border-radius:13px;background:#fff6cf;color:#193b35;font-weight:850;border:1px solid rgba(255,231,165,.38)}
      .lrMasterVisibleHub{min-height:650px;background:linear-gradient(180deg,#edf8f4,#fff8df);color:#213737}.lrMasterVisibleHero{padding:28px 32px;background:linear-gradient(135deg,#153942,#316153);color:#fff8d9}.lrMasterVisibleHero h2{margin:8px 0 8px;font-size:clamp(1.9rem,3vw,2.8rem)}.lrMasterVisibleHero p{max-width:920px;line-height:1.55;font-weight:760}.lrMasterVisibleHero small{font-weight:950;text-transform:uppercase;letter-spacing:.08em;color:#ffe38c}.lrMasterVisibleHubGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;padding:22px}.lrMasterVisibleHubGrid article{background:#fffefa;border:1px solid rgba(38,72,68,.20);border-radius:19px;padding:16px;box-shadow:0 10px 18px rgba(0,0,0,.13)}.lrMasterVisibleHubGrid h3{margin:.1rem 0 .35rem}.lrMasterVisibleHubGrid small{font-weight:950;color:#7a5918}.lrMasterVisibleHubGrid p{line-height:1.45;color:#40514d;font-weight:740}.lrMasterVisibleHubGrid article div{display:flex;flex-wrap:wrap;gap:8px}.lrMasterVisibleHubGrid button,.lrMasterVisibleFoot button{border:1px solid rgba(31,69,62,.22);border-radius:999px;background:#fff5d6;color:#1c4039;padding:10px 13px;font-weight:950;cursor:pointer}.lrMasterVisibleHubGrid .lrMasterVisibleOpen{background:#214e43;color:#fff8dc;border-color:#ffe49b}.lrMasterVisibleFoot{display:flex;gap:10px;flex-wrap:wrap;padding:18px 22px;background:#153942}
      .lrMasterVisibleWarn{margin:10px;padding:12px;border-radius:12px;background:#fff0c2;border:1px solid #c58a22;color:#352818;font-weight:900}
      #lrMasterQuickDock73A{position:fixed;left:50%;bottom:10px;transform:translateX(-50%);z-index:99998;display:flex;gap:7px;flex-wrap:wrap;justify-content:center;background:rgba(18,45,45,.92);border:1px solid rgba(255,232,166,.35);border-radius:999px;padding:8px 9px;box-shadow:0 12px 28px rgba(0,0,0,.28)}#lrMasterQuickDock73A button{border:1px solid rgba(255,232,166,.42);background:#fff6d7;color:#193d38;border-radius:999px;padding:8px 10px;font-weight:950;cursor:pointer;min-height:36px}
      @media(max-width:720px){.lrMasterVisibleHead{display:block}.lrMasterVisibleCards,.lrMasterVisibleHubGrid{grid-template-columns:1fr}.lrMasterVisibleBanner{padding:14px}.lrMasterVisibleHero{padding:22px 16px}#lrMasterQuickDock73A{left:8px;right:8px;transform:none;border-radius:18px}#lrMasterQuickDock73A button{flex:1}}
    `;
    document.head.appendChild(st);
  }

  function boot(){
    styles();
    wireLearn();
    addMenuOptions();
    installQuickDock();
    injectBanner();
    injectTrailCards();
  }

  window.lrMasterRun73A = runCourse;
  window.lrMasterOpenHub73A = openHub;

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,150); setTimeout(boot,700); setTimeout(boot,1500); });
  setInterval(function(){ addMenuOptions(); injectBanner(); }, 2500);
})();
