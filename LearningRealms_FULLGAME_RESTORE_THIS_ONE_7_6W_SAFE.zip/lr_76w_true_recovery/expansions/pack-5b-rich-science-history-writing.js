// Curriculum Pack 5B: Rich Teaching Science / History / Writing
// Built for Teaching Encounter Engine v1.
// Rich format: miniLesson, workedExample, guidedPractice, q, choices, answer, explain.
// Curriculum only. No engine/world changes.

LR_addLessons("Luna","Science",[
 {unit:"G1-SCI-LIFE",skill:"plant parts",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Plants have parts that help them live. Roots, stems, and leaves each have a job.",
  workedExample:"Roots hold the plant in the soil and help take in water. The stem holds the plant up. Leaves help the plant use sunlight.",
  guidedPractice:"Ask what job each plant part does.",
  q:"Which plant part helps hold the plant in the soil?",
  c:["roots","flower","leaf"],a:"roots",
  explain:"Roots are usually under the soil. They help hold the plant in place and take in water."},

 {unit:"G1-SCI-LIFE",skill:"animal parts",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Animals have body parts that help them live.",
  workedExample:"Birds have wings for flying. Fish have fins for swimming. Rabbits have strong back legs for hopping.",
  guidedPractice:"Look at the animal and ask how that body part helps it.",
  q:"What helps a fish swim?",
  c:["fins","feathers","roots"],a:"fins",
  explain:"Fish use fins to move and steer in water."},

 {unit:"G1-SCI-EARTH",skill:"weather",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Weather tells what the sky and air are like today.",
  workedExample:"If the sky is gray and water is falling, the weather is rainy. If the trees are moving a lot, it may be windy.",
  guidedPractice:"Think about the sky, wind, temperature, rain, or snow.",
  q:"Which word describes weather?",
  c:["rainy","yesterday","map"],a:"rainy",
  explain:"Rainy tells what the weather is like today."},

 {unit:"G1-SCI-PHYSICAL",skill:"light and shadows",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A shadow forms when something blocks light.",
  workedExample:"If sunlight shines on a tree, the tree blocks some light. A shadow appears on the ground.",
  guidedPractice:"Ask what is blocking the light.",
  q:"A shadow forms when something blocks...",
  c:["light","sound","water"],a:"light",
  explain:"Shadows happen because light cannot pass through some objects."}
]);

LR_addLessons("Luna","History",[
 {unit:"G1-SS-MAPS",skill:"maps",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A map helps show where places are.",
  workedExample:"A town map might show roads, rivers, homes, and gates. You can use it to find where to go.",
  guidedPractice:"Ask what the map is showing.",
  q:"What helps show where places are?",
  c:["map","verb","magnet"],a:"map",
  explain:"A map shows places and helps people find their way."},

 {unit:"G1-SS-MAPS",skill:"timelines",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A timeline shows events in order.",
  workedExample:"First you wake up. Next you eat breakfast. Later you start schoolwork. A timeline puts those events in order.",
  guidedPractice:"Look for what happened first, next, and last.",
  q:"A timeline shows events in...",
  c:["order","color","weight"],a:"order",
  explain:"Timelines help show when things happened."},

 {unit:"G1-SS-COMMUNITY",skill:"community helpers",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Community helpers do jobs that help people.",
  workedExample:"A firefighter helps during fires. A doctor helps sick people. A mail carrier delivers mail.",
  guidedPractice:"Ask how the person's job helps others.",
  q:"Which is a community helper?",
  c:["firefighter","rock","cloud"],a:"firefighter",
  explain:"A firefighter helps keep people safe during emergencies."}
]);

LR_addLessons("Luna","English",[
 {unit:"G1-ELA-WRITING",skill:"weather sentence",difficulty:"teaching",mode:"guided writing",
  miniLesson:"A sentence can tell about something you observe.",
  workedExample:"The sky is gray. That sentence tells one thing someone can see.",
  guidedPractice:"Start with The, then name what you see.",
  q:"Which is a complete weather sentence?",
  c:["The sky is gray.","sky gray","Rain."],a:"The sky is gray.",
  explain:"The sky is gray is a complete thought with a capital letter and period."},

 {unit:"G1-ELA-WRITING",skill:"because answers",difficulty:"teaching",mode:"guided writing",
  miniLesson:"The word because helps tell why.",
  workedExample:"The rabbit hid because it heard thunder. The because part explains why the rabbit hid.",
  guidedPractice:"Use because when you want to explain why something happened.",
  q:"Which word helps tell why?",
  c:["because","and","the"],a:"because",
  explain:"Because gives a reason."},

 {unit:"G1-ELA-WRITING",skill:"retell sentence",difficulty:"teaching",mode:"guided writing",
  miniLesson:"A retell can use first, next, and last.",
  workedExample:"First the frog sat on a log. Next it jumped into the pond. Last it swam away.",
  guidedPractice:"Choose the event that happened at the end.",
  q:"In a retell, which word can show the final event?",
  c:["last","first","next"],a:"last",
  explain:"Last tells what happened at the end."}
]);

LR_addLessons("Ava","Science",[
 {unit:"G7-SCI-LIFE",skill:"food webs",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A food web shows how organisms get energy in an ecosystem.",
  workedExample:"Grass is a producer. A rabbit eats grass. A fox eats the rabbit. Energy moves from grass to rabbit to fox.",
  guidedPractice:"Find the producer first, then follow who eats what.",
  q:"In grass → rabbit → fox, which organism is the producer?",
  c:["grass","rabbit","fox"],a:"grass",
  explain:"Grass makes its own food using sunlight, so it is the producer."},

 {unit:"G7-SCI-LIFE",skill:"adaptations",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Adaptations are traits or behaviors that help organisms survive.",
  workedExample:"A thick coat helps an animal stay warm in cold places. A long beak may help a bird reach food.",
  guidedPractice:"Ask how the trait helps the organism live.",
  q:"Thick fur in a cold climate is an example of...",
  c:["an adaptation","a budget","a timeline"],a:"an adaptation",
  explain:"Thick fur helps the animal survive cold conditions."},

 {unit:"G7-SCI-EARTH",skill:"water cycle",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"The water cycle moves water through evaporation, condensation, precipitation, and collection.",
  workedExample:"Water evaporates into the air, condenses into clouds, and falls as precipitation like rain.",
  guidedPractice:"Name the step where water falls from clouds.",
  q:"Rain is an example of...",
  c:["precipitation","evaporation","erosion"],a:"precipitation",
  explain:"Precipitation is water falling from the sky, such as rain or snow."},

 {unit:"G7-SCI-EARTH",skill:"weathering and erosion",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Weathering breaks rock down. Erosion moves the broken pieces.",
  workedExample:"If ice cracks a rock, that is weathering. If water carries the pieces away, that is erosion.",
  guidedPractice:"Ask whether rock is being broken or moved.",
  q:"Water carrying soil downhill is...",
  c:["erosion","punctuation","photosynthesis"],a:"erosion",
  explain:"Erosion moves sediment, soil, or broken rock from one place to another."}
]);

LR_addLessons("Ava","History",[
 {unit:"G7-SS-SOURCES",skill:"primary sources",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A primary source comes from the time or person being studied.",
  workedExample:"A diary written during an event is primary. A later textbook summary is secondary.",
  guidedPractice:"Ask: Was this made during the event?",
  q:"Which is a primary source?",
  c:["a diary from the event","a modern textbook summary","a new cartoon"],a:"a diary from the event",
  explain:"The diary was created during the event, so it is a primary source."},

 {unit:"G7-SS-CIVICS",skill:"limited government",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Limited government means government power is restricted by law.",
  workedExample:"A constitution can limit what leaders are allowed to do.",
  guidedPractice:"Look for rules or laws that limit power.",
  q:"Limited government restricts government...",
  c:["power","weather","fractions"],a:"power",
  explain:"Limited government keeps power from being unlimited."},

 {unit:"G7-SS-ECON",skill:"supply and demand",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Supply is how much is available. Demand is how much people want.",
  workedExample:"If many people want apples but only a few apples are available, demand is high and supply is low.",
  guidedPractice:"Ask how much exists and how much people want it.",
  q:"Demand means how much people...",
  c:["want","divide","evaporate"],a:"want",
  explain:"Demand is about how much people want a good or service."}
]);

LR_addLessons("Ava","English",[
 {unit:"G7-ELA-WRITING",skill:"CER",difficulty:"teaching",mode:"guided writing",
  miniLesson:"A CER paragraph includes a claim, evidence, and reasoning.",
  workedExample:"Claim: The character is determined. Evidence: She keeps working after failing twice. Reasoning: This proves determination because she does not quit.",
  guidedPractice:"Do not stop after evidence. Explain why it proves the claim.",
  q:"In CER, what explains why the evidence matters?",
  c:["reasoning","setting","suffix"],a:"reasoning",
  explain:"Reasoning connects the evidence to the claim."},

 {unit:"G7-ELA-WRITING",skill:"summary",difficulty:"teaching",mode:"guided writing",
  miniLesson:"A summary tells the important points without every tiny detail.",
  workedExample:"A full passage may describe every step of frog growth. A summary might say: Frogs grow from eggs to tadpoles to adult frogs.",
  guidedPractice:"Keep only the most important ideas.",
  q:"A summary should include...",
  c:["important points","every tiny detail","only the title"],a:"important points",
  explain:"A summary is shorter than the original but keeps the main ideas."},

 {unit:"G7-ELA-EVIDENCE",skill:"text evidence",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Text evidence is proof from the passage.",
  workedExample:"If you claim a character is worried, a line saying the character trembled and whispered can be evidence.",
  guidedPractice:"Find the exact detail that supports the answer.",
  q:"What should support a reading answer?",
  c:["text evidence","random guessing","cover color"],a:"text evidence",
  explain:"Text evidence proves that your answer comes from the passage."}
]);

LR_addLessons("Michael","Science",[
 {unit:"G8-SCI-MATTER",skill:"atoms",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Atoms are the tiny building blocks of matter.",
  workedExample:"Atoms contain protons, neutrons, and electrons. Protons are positive, neutrons are neutral, and electrons are negative.",
  guidedPractice:"Remember: electron sounds like electric, and electrons carry a negative charge.",
  q:"Which particle has a negative charge?",
  c:["electron","proton","neutron"],a:"electron",
  explain:"Electrons are the negatively charged particles in atoms."},

 {unit:"G8-SCI-MATTER",skill:"chemical change",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A chemical change creates a new substance.",
  workedExample:"When iron rusts, a new substance forms. Melting ice is different because it is still water.",
  guidedPractice:"Ask whether a new substance formed.",
  q:"Rusting is a...",
  c:["chemical change","physical change","graph"],a:"chemical change",
  explain:"Rusting creates a new substance, so it is chemical change."},

 {unit:"G8-SCI-FORCE",skill:"Newton's second law",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Newton's second law connects force, mass, and acceleration.",
  workedExample:"F = ma. If mass increases, more force is needed for the same acceleration.",
  guidedPractice:"Use the formula and identify force, mass, and acceleration.",
  q:"Newton's second law is...",
  c:["F = ma","y = mx + b","C = πd"],a:"F = ma",
  explain:"F = ma means force equals mass times acceleration."},

 {unit:"G8-SCI-FORCE",skill:"energy",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Kinetic energy is energy of motion. Potential energy is stored energy.",
  workedExample:"A moving cart has kinetic energy. A raised rock has potential energy because of its position.",
  guidedPractice:"Ask whether the object is moving or stored in a position.",
  q:"Energy of motion is...",
  c:["kinetic energy","potential energy","density"],a:"kinetic energy",
  explain:"Kinetic energy is energy an object has because it is moving."}
]);

LR_addLessons("Michael","History",[
 {unit:"G8-SS-CIVICS",skill:"separation of powers",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Separation of powers divides government authority among branches.",
  workedExample:"The legislative branch makes laws, the executive branch carries them out, and the judicial branch interprets them.",
  guidedPractice:"Look for which branch has which job.",
  q:"Separation of powers divides authority among...",
  c:["branches","markets","cells"],a:"branches",
  explain:"The branches divide power so one part does not hold all authority."},

 {unit:"G8-SS-CIVICS",skill:"checks and balances",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Checks and balances let branches limit one another.",
  workedExample:"A court can review whether a law follows the Constitution. This helps prevent one branch from becoming too powerful.",
  guidedPractice:"Ask which branch is limiting another branch.",
  q:"Checks and balances help limit government...",
  c:["power","weather","density"],a:"power",
  explain:"The system is meant to keep power balanced."},

 {unit:"G8-SS-ECON",skill:"scarcity",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Scarcity means resources are limited compared with wants.",
  workedExample:"If a town has only enough wood for one bridge, leaders must choose how to use it.",
  guidedPractice:"Ask what is limited and what choice must be made.",
  q:"Scarcity means resources are...",
  c:["limited","unlimited","unneeded"],a:"limited",
  explain:"Scarcity exists because people have more wants than available resources."}
]);

LR_addLessons("Michael","English",[
 {unit:"G8-ELA-ARG",skill:"argument paragraph",difficulty:"teaching",mode:"guided writing",
  miniLesson:"An argument paragraph needs a clear claim, evidence, and reasoning.",
  workedExample:"Claim: The town should repair the bridge. Evidence: Travelers use it every day. Reasoning: Repairing it would make travel safer and easier.",
  guidedPractice:"Make sure the evidence actually supports the claim.",
  q:"What explains how evidence supports the claim?",
  c:["reasoning","font size","setting"],a:"reasoning",
  explain:"Reasoning is the explanation that connects proof to the claim."},

 {unit:"G8-ELA-RESEARCH",skill:"source reliability",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A reliable source can be checked for author, evidence, date, and purpose.",
  workedExample:"A signed article with sources and a clear date is usually stronger than an anonymous page with no evidence.",
  guidedPractice:"Ask who made it, when, why, and what evidence it gives.",
  q:"Which helps judge source reliability?",
  c:["author, evidence, date, and purpose","font color only","page length only"],a:"author, evidence, date, and purpose",
  explain:"Those details help show whether the source is trustworthy."},

 {unit:"G8-ELA-ARG",skill:"counterclaim and rebuttal",difficulty:"teaching",mode:"guided writing",
  miniLesson:"A counterclaim gives the other side. A rebuttal answers it.",
  workedExample:"Counterclaim: The gate should stay closed. Rebuttal: The gate can open safely if guards inspect travelers.",
  guidedPractice:"State the other side fairly, then answer it.",
  q:"A rebuttal answers the...",
  c:["counterclaim","citation","title"],a:"counterclaim",
  explain:"The rebuttal responds to the opposing view."}
]);
