// Grade Ladder Pack K1: Kindergarten Foundation
// All children start here. These lessons are intentionally basic so older kids can quickly prove mastery.
// Curriculum only.

function LR_addKFoundation(child){
  LR_addLessons(child,"Reading",[
    {gradeBand:"K",unit:"K-READ-LETTERS",skill:"letter sounds",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Letters stand for sounds. The sound at the beginning of a word helps us read it.",
     workedExample:"Ball begins with the /b/ sound. The letter B makes /b/.",
     guidedPractice:"Say the first sound slowly.",
     q:"Which letter starts the word ball?",c:["B","S","M"],a:"B",
     explain:"Ball begins with the /b/ sound, and B makes that sound."},
    {gradeBand:"K",unit:"K-READ-RHYME",skill:"rhyming",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Rhyming words end with the same sound.",
     workedExample:"Cat and hat rhyme because they both end with the /at/ sound.",
     guidedPractice:"Listen to the ending sound.",
     q:"Which word rhymes with cat?",c:["hat","dog","sun"],a:"hat",
     explain:"Cat and hat both end with the same sound."},
    {gradeBand:"K",unit:"K-READ-STORY",skill:"story basics",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"A character is who a story is about.",
     workedExample:"If the story says the rabbit hopped home, the rabbit is the character.",
     guidedPractice:"Ask who is doing something.",
     q:"The fox ran. Who is the character?",c:["fox","ran","the"],a:"fox",
     explain:"The fox is who the sentence is about."}
  ]);

  LR_addLessons(child,"Math",[
    {gradeBand:"K",unit:"K-MATH-COUNT",skill:"counting",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Counting tells how many things there are.",
     workedExample:"If you see one, two, three apples, there are 3 apples.",
     guidedPractice:"Count each item once.",
     q:"How many: apple, apple, apple?",c:["3","2","4"],a:"3",
     explain:"There are three apples."},
    {gradeBand:"K",unit:"K-MATH-COMPARE",skill:"more and less",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"More means a bigger amount. Less means a smaller amount.",
     workedExample:"5 stones is more than 2 stones.",
     guidedPractice:"Compare the two numbers.",
     q:"Which number is more?",c:["5","2","same"],a:"5",
     explain:"5 is greater than 2."},
    {gradeBand:"K",unit:"K-MATH-SHAPES",skill:"shapes",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Shapes have names. A circle is round. A square has four equal sides.",
     workedExample:"A ball drawing may look like a circle.",
     guidedPractice:"Look for the round shape.",
     q:"Which shape is round?",c:["circle","square","triangle"],a:"circle",
     explain:"A circle is round."}
  ]);

  LR_addLessons(child,"English",[
    {gradeBand:"K",unit:"K-ELA-SENTENCE",skill:"capital letters",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Names and sentences begin with capital letters.",
     workedExample:"The sentence 'The cat ran.' starts with capital T.",
     guidedPractice:"Look at the first letter.",
     q:"Which starts correctly?",c:["The cat ran.","the cat ran.","cat ran"],a:"The cat ran.",
     explain:"A sentence should begin with a capital letter."},
    {gradeBand:"K",unit:"K-ELA-WORDS",skill:"word order",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Words must be in an order that makes sense.",
     workedExample:"The dog runs makes sense. Runs dog the does not.",
     guidedPractice:"Choose the sentence that sounds complete.",
     q:"Which makes sense?",c:["The dog runs.","Runs dog the.","Dog the runs."],a:"The dog runs.",
     explain:"The dog runs is in a clear order."}
  ]);

  LR_addLessons(child,"Science",[
    {gradeBand:"K",unit:"K-SCI-LIVING",skill:"living things",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Living things grow and need things like water, food, or light.",
     workedExample:"A plant is living because it grows and needs water and light.",
     guidedPractice:"Ask whether it grows or needs care.",
     q:"Which is a living thing?",c:["plant","rock","chair"],a:"plant",
     explain:"A plant is living because it grows."},
    {gradeBand:"K",unit:"K-SCI-WEATHER",skill:"weather",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Weather tells what it is like outside.",
     workedExample:"Sunny, rainy, windy, and snowy are weather words.",
     guidedPractice:"Choose the word that tells about the sky or air.",
     q:"Which is weather?",c:["rainy","pencil","table"],a:"rainy",
     explain:"Rainy tells what the weather is like."}
  ]);

  LR_addLessons(child,"History",[
    {gradeBand:"K",unit:"K-SS-RULES",skill:"rules",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Rules help people stay safe and know what to do.",
     workedExample:"Take turns is a rule that helps people be fair.",
     guidedPractice:"Think about what helps people stay safe or fair.",
     q:"Rules help people stay...",c:["safe","lost","invisible"],a:"safe",
     explain:"Good rules help people stay safe."},
    {gradeBand:"K",unit:"K-SS-MAPS",skill:"maps",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"A map shows where places are.",
     workedExample:"A map can show a road, a river, or a town.",
     guidedPractice:"Choose the tool that shows places.",
     q:"What helps show where places are?",c:["map","spoon","song"],a:"map",
     explain:"A map helps people find places."}
  ]);

  LR_addLessons(child,"Art",[
    {gradeBand:"K",unit:"K-ART-COLOR",skill:"colors",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Colors help artists make pictures.",
     workedExample:"Red, blue, yellow, green, orange, and purple are colors.",
     guidedPractice:"Choose the color word.",
     q:"Which is a color?",c:["blue","table","jump"],a:"blue",
     explain:"Blue is a color."},
    {gradeBand:"K",unit:"K-ART-LINES",skill:"lines",difficulty:"kindergarten",mode:"foundation",
     miniLesson:"Artists use lines to draw.",
     workedExample:"A straight line can draw a road. A curved line can draw a hill.",
     guidedPractice:"Choose the thing artists draw with.",
     q:"Artists can use a line to...",c:["draw","sleep","eat"],a:"draw",
     explain:"Lines are used to draw shapes and pictures."}
  ]);
}

LR_addKFoundation("Luna");
LR_addKFoundation("Ava");
LR_addKFoundation("Michael");
