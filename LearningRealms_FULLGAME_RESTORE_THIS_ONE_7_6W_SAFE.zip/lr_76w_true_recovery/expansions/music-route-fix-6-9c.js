/* LearningRealms Music Route Fix 6.9C
   Fixes Music links that could land on writing/story routes or continue from the wrong Creative Studio section.
   No new lessons or rewards. Route/stability only.
*/
(function(){
  'use strict';
  if(window.__LR69C_MUSIC_ROUTE_FIX__) return;
  window.__LR69C_MUSIC_ROUTE_FIX__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function getRooms(){
    try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){}
    try{ if(typeof ROOMS !== 'undefined') return ROOMS; }catch(e){}
    return {};
  }
  function getState(){
    try{ if(window.state) return window.state; }catch(e){}
    try{ if(typeof state !== 'undefined') return state; }catch(e){}
    return null;
  }
  function save(){ try{ if(typeof window.save === 'function') window.save(); else if(typeof save === 'function') save(); }catch(e){} }
  function stats(){ try{ if(typeof window.renderStats === 'function') window.renderStats(); else if(typeof renderStats === 'function') renderStats(); }catch(e){} }
  function render(note){
    try{ if(typeof window.lr68Render === 'function') return window.lr68Render('room', note || 'You step into Bardwood Hall.'); }catch(e){}
    try{ if(typeof window.lr67RenderDynamicScreen === 'function') return window.lr67RenderDynamicScreen('room', note || 'You step into Bardwood Hall.'); }catch(e){}
    try{ if(typeof window.renderRoom === 'function') return window.renderRoom(); }catch(e){}
    return false;
  }

  var STUDIO_FIRST_TOPIC = {
    'Drawing Desk': 0,
    'Painting Studio': 10,
    'Craft Cottage': 20,
    'Pattern Workshop': 30,
    'Theater Stage': 41,
    'Music Corner': 52,
    'Story Maker Room': 63,
    'Mini Gallery': 74
  };
  var STUDIO_NAMES = ['Drawing Desk','Painting Studio','Craft Cottage','Pattern Workshop','Theater Stage','Music Corner','Story Maker Room','Mini Gallery'];
  var lastStudioFilter = null;

  function patchMusicRooms(){
    var rooms = getRooms();
    ['bardwoodRoad1','bardwoodRoad2','bardwoodGate','rhythmCircle','instrumentGallery','tempoTrail','melodyBridge','listeningLoft','choirNook'].forEach(function(id){
      if(rooms[id]) rooms[id].subject = 'Music';
    });
    if(rooms.bardwoodRoad1 && !rooms.bardwoodRoad1.npc){
      rooms.bardwoodRoad1.npc = {name:'Bardwood Road Guide', desc:'A friendly guide who points toward the music hall.', text:'Follow the humming leaves to Bardwood Gate. Beat, rhythm, melody, and listening all begin here.'};
    }
    if(rooms.bardwoodRoad2 && !rooms.bardwoodRoad2.npc){
      rooms.bardwoodRoad2.npc = {name:'Echo Bend Guide', desc:'A quiet listener who teaches that music begins with noticing sound.', text:'Listen first. Then name what changed: beat, rhythm, tempo, pitch, or volume.'};
    }
  }

  function goMusicHall(){
    patchMusicRooms();
    var target = 'bardwoodGate';
    var rooms = getRooms();
    if(!rooms[target]) target = rooms.bardwoodRoad1 ? 'bardwoodRoad1' : null;
    if(!target){ render('Music Hall is not loaded in this build.'); return false; }

    try{
      if(window.LR68A && typeof window.LR68A.goTo === 'function') return window.LR68A.goTo(target);
    }catch(e){}
    try{
      if(typeof window.lr68aGoTo === 'function' && window.lr68aGoTo.__lr69cMusicWrapped) return window.lr68aGoTo(target);
    }catch(e){}

    var s = getState();
    if(s){ s.loc = target; s.room = Math.max(1, Number(s.room || 1)) + 1; }
    save(); stats();
    return render('You follow the sound of humming leaves and step into Bardwood Hall. Music lessons should stay Music here.');
  }

  function patchTrailFunctions(){
    if(typeof window.lr68bRunTrail === 'function' && !window.lr68bRunTrail.__lr69cMusicWrapped){
      var oldRunTrail = window.lr68bRunTrail;
      var wrappedRunTrail = function(id){
        if(id === 'music' || id === 'music-hall' || id === 'bardwood') return goMusicHall();
        return oldRunTrail.apply(this, arguments);
      };
      wrappedRunTrail.__lr69cMusicWrapped = true;
      wrappedRunTrail.__lr69cOld = oldRunTrail;
      window.lr68bRunTrail = wrappedRunTrail;
      try{ lr68bRunTrail = wrappedRunTrail; }catch(e){}
    }

    if(typeof window.lr68aGoTo === 'function' && !window.lr68aGoTo.__lr69cMusicWrapped){
      var oldGoTo = window.lr68aGoTo;
      var wrappedGoTo = function(target){
        if(target === 'bardwoodRoad1' || target === 'bardwoodRoad2' || target === 'Music Hall') return goMusicHall();
        return oldGoTo.apply(this, arguments);
      };
      wrappedGoTo.__lr69cMusicWrapped = true;
      wrappedGoTo.__lr69cOld = oldGoTo;
      window.lr68aGoTo = wrappedGoTo;
      try{ lr68aGoTo = wrappedGoTo; }catch(e){}
      try{ if(window.LR68A) window.LR68A.goTo = wrappedGoTo; }catch(e){}
    }
  }

  function patchCreativeContinueButton(filter){
    if(!filter || !STUDIO_FIRST_TOPIC.hasOwnProperty(filter)) return;
    var idx = STUDIO_FIRST_TOPIC[filter];
    var body = byId('lrPopupBody') || document.body;
    if(!body) return;
    var buttons = Array.prototype.slice.call(body.querySelectorAll('.cs65HeroBtns button, button'));
    buttons.forEach(function(btn){
      var text = (btn.textContent || '').trim().toLowerCase();
      var onclick = btn.getAttribute('onclick') || '';
      if(text === 'continue' || (text.indexOf('continue') >= 0 && onclick.indexOf('creativeOpenTopic') >= 0)){
        btn.textContent = 'Continue ' + filter;
        btn.onclick = function(){ return window.creativeOpenTopic(idx,0); };
        btn.setAttribute('data-lr69c-studio-continue-fixed', filter);
      }
    });
  }

  function patchCreativeStudioCourse(){
    if(typeof window.openCreativeStudioByStudio === 'function' && !window.openCreativeStudioByStudio.__lr69cMusicWrapped){
      var oldByStudio = window.openCreativeStudioByStudio;
      var wrappedByStudio = function(i){
        var filter = STUDIO_NAMES[Number(i)] || null;
        lastStudioFilter = filter;
        var out = oldByStudio.apply(this, arguments);
        setTimeout(function(){ patchCreativeContinueButton(filter); }, 20);
        setTimeout(function(){ patchCreativeContinueButton(filter); }, 120);
        return out;
      };
      wrappedByStudio.__lr69cMusicWrapped = true;
      window.openCreativeStudioByStudio = wrappedByStudio;
      try{ openCreativeStudioByStudio = wrappedByStudio; }catch(e){}
    }

    if(typeof window.openCreativeStudioCourse === 'function' && !window.openCreativeStudioCourse.__lr69cMusicWrapped){
      var oldCourse = window.openCreativeStudioCourse;
      var wrappedCourse = function(filter){
        lastStudioFilter = filter || null;
        var out = oldCourse.apply(this, arguments);
        setTimeout(function(){ patchCreativeContinueButton(filter || lastStudioFilter); }, 20);
        setTimeout(function(){ patchCreativeContinueButton(filter || lastStudioFilter); }, 120);
        return out;
      };
      wrappedCourse.__lr69cMusicWrapped = true;
      window.openCreativeStudioCourse = wrappedCourse;
      try{ openCreativeStudioCourse = wrappedCourse; }catch(e){}
    }
  }

  function patchRealCurriculumMusicTab(){
    // Adds a precise Music-only route for the real curriculum bank without replacing the old picker.
    window.openMusicRealCurriculum = async function(){
      try{
        if(typeof window.lrLoadRealCurriculumBank !== 'function' && typeof lrLoadRealCurriculumBank !== 'function') return false;
        var loader = window.lrLoadRealCurriculumBank || lrLoadRealCurriculumBank;
        var bank = await loader();
        var filtered = (bank || []).filter(function(l){
          var text = String((l.region || '') + ' ' + (l.pack_region || '') + ' ' + (l.source_pack || '') + ' ' + (l.mastery_tag || '')).toLowerCase();
          return /music|rhythm|tempo|melody|instrument|listening|dynamics|beat/.test(text) && !/writing guild|sentence|paragraph/.test(text);
        });
        var sample = filtered.slice(0,40);
        var title = byId('actionTitle'), action = byId('actionText');
        if(title) title.textContent = '🎵 Music Lessons';
        if(action){
          action.innerHTML = '<div class="lrRealCurriculumPicker"><div class="lrRealCurriculumHeader"><h3>Music Lesson Bank</h3><p>Showing Music Hall lessons only, not writing/story lessons.</p></div><div class="lrRealLessonList">' + sample.map(function(l){
            var index = (bank || []).indexOf(l);
            return '<button onclick="lrOpenRealLessonByIndex(' + index + ')"><b>' + esc(l.region || l.pack_region || 'Music Lesson') + '</b><br><small>' + esc(l.question || '') + '</small></button>';
          }).join('') + '</div></div>';
        }
        if(typeof window.lrOpenActionPopup === 'function') window.lrOpenActionPopup('🎵 Music Lessons');
        return false;
      }catch(e){ console.warn('LR69C music real curriculum failed', e); return false; }
    };
  }

  function install(){
    patchMusicRooms();
    patchTrailFunctions();
    patchCreativeStudioCourse();
    patchRealCurriculumMusicTab();
  }

  window.lr69cGoMusicHall = goMusicHall;
  window.lr69cPatchCreativeContinueButton = patchCreativeContinueButton;
  window.lr69cMusicRouteHealth = function(){
    var rooms = getRooms();
    return {
      loaded:true,
      bardwoodGateSubject: rooms.bardwoodGate && rooms.bardwoodGate.subject,
      bardwoodRoad1Subject: rooms.bardwoodRoad1 && rooms.bardwoodRoad1.subject,
      trailWrapped: !!(window.lr68bRunTrail && window.lr68bRunTrail.__lr69cMusicWrapped),
      goToWrapped: !!(window.lr68aGoTo && window.lr68aGoTo.__lr69cMusicWrapped),
      creativeWrapped: !!(window.openCreativeStudioCourse && window.openCreativeStudioCourse.__lr69cMusicWrapped),
      musicFirstTopic: STUDIO_FIRST_TOPIC['Music Corner']
    };
  };

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(install,80); setTimeout(install,500); });
  else { setTimeout(install,80); setTimeout(install,500); }
  window.addEventListener('load', function(){ setTimeout(install,300); setTimeout(install,1200); });
})();
