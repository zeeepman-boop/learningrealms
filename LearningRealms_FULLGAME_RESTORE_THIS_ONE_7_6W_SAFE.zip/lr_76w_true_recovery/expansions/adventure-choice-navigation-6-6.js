/* LearningRealms Adventure Choice Navigation 6.6
   Replaces compass-style movement with choose-your-own-adventure travel choices.
   Safe overlay: rooms, lessons, rewards, Go Learn, and Shipwreck Cove stay intact.
*/
(function(){
  'use strict';
  if(window.__LR66_ADVENTURE_CHOICE_NAV__) return;
  window.__LR66_ADVENTURE_CHOICE_NAV__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }
  function plain(v){ return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim(); }
  function titleCaseDir(key){
    var names = {
      north:'north', south:'south', east:'east', west:'west',
      northeast:'northeast', northwest:'northwest', southeast:'southeast', southwest:'southwest',
      up:'up', down:'down', out:'out', center:'back to the center', home:'home',
      civics:'toward civics', geography:'toward geography', economics:'toward economics', logic:'toward logic',
      nature:'toward nature', health:'toward health', music:'toward music', copywork:'toward copywork', lifeskills:'toward life skills'
    };
    return names[key] || String(key || '').replace(/_/g,' ');
  }
  function getRoom(){
    try{ if(typeof window.room === 'function') return window.room() || {}; }catch(e){}
    try{ if(typeof room === 'function') return room() || {}; }catch(e){}
    return {};
  }
  function roomTable(){ return window.LR_ROOMS || {}; }
  function targetRoom(id){ return roomTable()[id] || {}; }
  function currentLoc(){
    try{ if(window.state && window.state.loc) return window.state.loc; }catch(e){}
    try{ if(typeof state !== 'undefined' && state && state.loc) return state.loc; }catch(e){}
    return '';
  }
  function allExits(){
    var r = getRoom();
    return (r && r.exits) ? r.exits : {};
  }
  function targetTitle(id){
    var t = targetRoom(id);
    return t.title || id || 'the next place';
  }
  function targetZone(id){
    var t = targetRoom(id);
    return t.zone || '';
  }
  function targetSubject(id){
    var t = targetRoom(id);
    return t.subject || '';
  }
  function pathWord(dir, destTitle, destZone){
    var d = String(dir || '').toLowerCase();
    var t = String(destTitle || '').toLowerCase();
    var z = String(destZone || '').toLowerCase();
    if(d === 'up') return 'climb up toward';
    if(d === 'down') return 'climb down toward';
    if(d === 'out') return 'step out toward';
    if(d === 'home') return 'return home to';
    if(d === 'center') return 'circle back toward';
    if(t.indexOf('bridge') >= 0) return 'cross the path toward';
    if(t.indexOf('gate') >= 0) return 'walk up to';
    if(t.indexOf('shop') >= 0 || z.indexOf('shop') >= 0 || z.indexOf('market') >= 0) return 'wander into';
    if(t.indexOf('hall') >= 0 || t.indexOf('room') >= 0 || t.indexOf('vault') >= 0 || t.indexOf('archive') >= 0) return 'step inside';
    if(t.indexOf('trail') >= 0 || t.indexOf('road') >= 0 || t.indexOf('lane') >= 0 || t.indexOf('path') >= 0) return 'follow the road toward';
    if(t.indexOf('square') >= 0 || t.indexOf('plaza') >= 0) return 'head back into';
    return 'travel toward';
  }
  function subjectHint(subject){
    if(!subject) return '';
    var s = String(subject).toLowerCase();
    if(s.indexOf('reading') >= 0) return 'where story clues and reading challenges wait';
    if(s.indexOf('math') >= 0) return 'where numbers, patterns, and problem solving wait';
    if(s.indexOf('science') >= 0) return 'where observation and evidence guide the next discovery';
    if(s.indexOf('writing') >= 0) return 'where words, sentences, and records shape the journey';
    if(s.indexOf('history') >= 0) return 'where old evidence helps explain what happened before';
    if(s.indexOf('english') >= 0) return 'where language choices and careful reading matter';
    if(s.indexOf('civics') >= 0) return 'where rules, service, and responsibility are studied';
    if(s.indexOf('geography') >= 0) return 'where maps, places, and landforms guide the way';
    if(s.indexOf('economics') >= 0) return 'where choices, trade, saving, and value are explored';
    if(s.indexOf('logic') >= 0) return 'where careful thinking opens the next door';
    if(s.indexOf('nature') >= 0) return 'where outdoor clues and living things can be studied';
    if(s.indexOf('health') >= 0) return 'where safe habits and body basics are practiced';
    if(s.indexOf('music') >= 0) return 'where rhythm, listening, and sound become part of the path';
    if(s.indexOf('copywork') >= 0) return 'where careful copying and neat language practice wait';
    if(s.indexOf('life') >= 0) return 'where practical skills turn into little quests';
    return 'where the next lesson path waits';
  }
  function storyChoiceText(dir, targetId){
    var r = getRoom();
    var t = targetRoom(targetId);
    var dest = plain(t.title || targetId || 'the next place');
    var zone = t.zone || '';
    var subject = t.subject || '';
    var from = plain(r.title || 'here');
    var key = String(dir || '').toLowerCase();

    if(key === 'home' || targetId === 'home') return 'Return to Home Hearth and check the cozy rooms, storage, pets, and family keepsakes.';
    if(key === 'out') return 'Step out of ' + from + ' and return to ' + dest + '.';
    if(key === 'up') return 'Climb upward toward ' + dest + ' and see what is waiting above.';
    if(key === 'down') return 'Climb down carefully toward ' + dest + ' and inspect the hidden passage below.';

    var action = pathWord(key, dest, zone);
    var hint = subjectHint(subject);
    if(hint) return cap(action) + ' ' + dest + ', ' + hint + '.';

    var zl = String(zone).toLowerCase();
    if(zl.indexOf('home') >= 0) return cap(action) + ' ' + dest + ' and check the next cozy home space.';
    if(zl.indexOf('town') >= 0) return cap(action) + ' ' + dest + ' and see what the town opens next.';
    if(zl.indexOf('shop') >= 0 || zl.indexOf('market') >= 0) return cap(action) + ' ' + dest + ' and browse the strange little shelves.';
    if(zl.indexOf('castle') >= 0) return cap(action) + ' ' + dest + ' and study the sealed castle path.';
    if(zl.indexOf('secret') >= 0 || zl.indexOf('mystery') >= 0 || zl.indexOf('under') >= 0) return cap(action) + ' ' + dest + ' and look for the clue that explains this hidden place.';

    return cap(action) + ' ' + dest + ' and continue the adventure from there.';
  }
  function cap(s){ s = String(s || ''); return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

  function showMessage(title, body){
    try{
      var actionTitle = byId('actionTitle');
      var actionText = byId('actionText');
      if(actionTitle) actionTitle.textContent = title;
      if(actionText) actionText.innerHTML = body;
    }catch(e){}
  }

  window.lrAdventureChoiceGo = function(exitKey){
    try{
      var exits = allExits();
      var target = exits[exitKey];
      if(!target){
        showMessage('No path there', '<div class="lrAdventureLook"><h3>🧭 No open story path</h3><p>That choice is not available from this room. Pick one of the story travel buttons shown under the room description.</p></div>');
        var fb = byId('feedback'); if(fb) fb.textContent = 'No open story path that way.';
        return;
      }
      var label = storyChoiceText(exitKey, target);
      if(typeof window.go === 'function'){
        showMessage('Traveling', '<div class="lrAdventureLook"><h3>🧭 Traveling</h3><p>' + esc(label) + '</p></div>');
        window.go(exitKey);
        setTimeout(window.lrRenderExplorationNav, 30);
        return;
      }
      if(typeof go === 'function'){
        showMessage('Traveling', '<div class="lrAdventureLook"><h3>🧭 Traveling</h3><p>' + esc(label) + '</p></div>');
        go(exitKey);
        setTimeout(window.lrRenderExplorationNav, 30);
        return;
      }
      showMessage('Travel unavailable', '<div class="lrAdventureLook"><h3>Travel hook missing</h3><p>The room path exists, but the travel function did not load.</p></div>');
    }catch(e){
      console.error(e);
      showMessage('Travel error', '<div class="lrAdventureLook"><h3>Travel Error</h3><p>' + esc(e.message || e) + '</p></div>');
    }
  };
  window.lrNavRestoreGo = window.lrAdventureChoiceGo;

  window.lrAdventureChoiceLook = function(){
    var r = getRoom();
    var exits = allExits();
    var paths = Object.keys(exits).map(function(k){
      return '<li>' + esc(storyChoiceText(k, exits[k])) + '</li>';
    }).join('') || '<li>No story paths are marked from this room yet.</li>';
    var npcLine = '';
    try{
      var hasNpc = (typeof window.roomHasNpc === 'function') ? window.roomHasNpc() : (typeof roomHasNpc === 'function' && roomHasNpc());
      var n = hasNpc ? ((typeof window.npc === 'function') ? window.npc() : (typeof npc === 'function' ? npc() : null)) : null;
      if(n) npcLine = '<p><b>Nearby guide:</b> ' + esc(n.name || 'A realm helper') + '</p>';
    }catch(e){}
    showMessage('Look Around', '<div class="lrAdventureLook"><h3>🔎 ' + esc(r.title || 'This place') + '</h3><p>' + esc(r.text || 'You pause and look around carefully.') + '</p>' + npcLine + '<h4>Story paths from here</h4><ul>' + paths + '</ul></div>');
  };
  window.lrNavRestoreLook = window.lrAdventureChoiceLook;

  window.lrAdventureChoiceInteract = function(){
    try{
      var hasNpc = (typeof window.roomHasNpc === 'function') ? window.roomHasNpc() : (typeof roomHasNpc === 'function' && roomHasNpc());
      if(hasNpc){
        if(typeof window.talk === 'function') return window.talk();
        if(typeof talk === 'function') return talk();
      }
    }catch(e){}
    window.lrAdventureChoiceLook();
  };
  window.lrNavRestoreInteract = window.lrAdventureChoiceInteract;

  window.lrAdventureOpenLearn = function(){
    try{
      var choices = ['lr62eOpenLearn','lr19OpenLearningChooser','openRealCurriculumPicker','openLessonLauncher','openSubjectAtlasUI'];
      for(var i=0;i<choices.length;i++){
        if(typeof window[choices[i]] === 'function'){ window[choices[i]](); return; }
      }
      showMessage('Go Learn', '<div class="lrAdventureLook"><h3>📘 Go Learn</h3><p>The learning menu is still loading in this build.</p></div>');
    }catch(e){ console.error(e); }
  };

  window.lrAdventureGoHome = function(){
    try{
      if(typeof window.travelHome === 'function') return window.travelHome();
      if(typeof travelHome === 'function') return travelHome();
    }catch(e){}
    try{
      if(window.state){ window.state.loc = 'home'; if(typeof window.renderRoom === 'function') window.renderRoom(); }
    }catch(e){}
  };

  function choiceButton(exitKey, targetId, index){
    var t = targetRoom(targetId);
    var dest = t.title || targetId;
    var subject = t.subject || '';
    var zone = t.zone || '';
    var tag = subject ? subject : (zone || titleCaseDir(exitKey));
    return '<button type="button" class="lrAdventureChoiceBtn" onclick="lrAdventureChoiceGo(\'' + esc(exitKey) + '\')">' +
      '<span class="lrChoiceNumber">' + esc(index + 1) + '</span>' +
      '<span class="lrChoiceBody"><b>' + esc(storyChoiceText(exitKey, targetId)) + '</b>' +
      '<small>' + esc(dest) + (tag ? ' · ' + esc(tag) : '') + '</small></span>' +
      '</button>';
  }

  function adventurePanelHtml(){
    var r = getRoom();
    var exits = allExits();
    var keys = Object.keys(exits);
    var title = r.title || 'This room';
    var subtitle = keys.length ? 'Choose the next page of the adventure.' : 'No story paths are marked from here yet.';
    var body = '';
    if(keys.length){
      body = keys.map(function(k,i){ return choiceButton(k, exits[k], i); }).join('');
    }else{
      body = '<div class="lrAdventureNoChoices">This room is quiet right now. Use Go Learn, Home, or Look Around while this path is expanded later.</div>';
    }
    return '<div class="lrAdventurePanel" id="lrAdventurePanel">' +
      '<div class="lrAdventureHeader"><div><span class="lrAdventureKicker">📖 Adventure choices</span><h3>' + esc(title) + '</h3></div><small>' + esc(subtitle) + '</small></div>' +
      '<div class="lrAdventureChoiceList">' + body + '</div>' +
      '<div class="lrAdventureActionRow">' +
        '<button type="button" onclick="lrAdventureChoiceLook()">🔎 Look around</button>' +
        '<button type="button" onclick="lrAdventureChoiceInteract()">✨ Talk / interact</button>' +
        '<button type="button" onclick="lrAdventureOpenLearn()">📘 Go Learn</button>' +
        '<button type="button" onclick="lrAdventureGoHome()">🏡 Home</button>' +
      '</div>' +
    '</div>';
  }

  function removeOldDocks(){
    ['lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock'].forEach(function(id){
      var el = byId(id); if(el && el.parentNode) el.parentNode.removeChild(el);
    });
  }

  window.lrRenderExplorationNav = function(){
    try{
      removeOldDocks();
      var mount = byId('mainCompassNav');
      if(!mount){
        var rt = byId('roomText');
        if(rt && rt.parentNode){
          mount = document.createElement('div');
          mount.id = 'mainCompassNav';
          mount.className = 'mainCompassNav';
          rt.parentNode.insertBefore(mount, rt.nextSibling);
        }
      }
      if(mount){
        mount.innerHTML = adventurePanelHtml();
        mount.style.display = 'block';
        mount.style.height = 'auto';
        mount.style.overflow = 'visible';
      }
    }catch(e){ console.warn('Adventure choice navigation skipped', e); }
  };

  function swcTargetLabel(raw){
    var s = plain(raw).replace(/^[A-Z]+\s*→\s*/,'').replace(/\s*🔒\s*$/,'').trim();
    return s || plain(raw) || 'the next stop';
  }
  function swcChoiceText(raw){
    var s = swcTargetLabel(raw).toLowerCase();
    var dest = swcTargetLabel(raw);
    if(s.indexOf('chart') >= 0) return 'Step into the Chart Room and read the old maps before choosing the next sea road.';
    if(s.indexOf('warning') >= 0 || s.indexOf('iceberg') >= 0) return 'Follow the guide into the warning gallery and study the messages that came before disaster.';
    if(s.indexOf('dry dock') >= 0 || s.indexOf('ship') >= 0) return 'Walk into the old dry dock and inspect how ship design, weight, and balance mattered.';
    if(s.indexOf('pirate') >= 0) return 'Cross to Pirate Evidence Pier and separate legend from records, artifacts, and maps.';
    if(s.indexOf('treasure') >= 0) return 'Enter the treasure archive and ask why preservation matters more than grabbing shiny things.';
    if(s.indexOf('rescue') >= 0) return 'Head to the rescue dock and study how warnings, lifeboats, and communication protect people.';
    if(s.indexOf('museum') >= 0) return 'Walk into the maritime museum hall and connect the wreck story to evidence and memory.';
    if(s.indexOf('ghost') >= 0) return 'Take the lantern walk and treat the ghost stories as clues about memory, folklore, and respect.';
    if(s.indexOf('salvage') >= 0 || s.indexOf('sonar') >= 0) return 'Go to the salvage and sonar lab to learn how wreck sites are mapped without wrecking the evidence.';
    if(s.indexOf('modern') >= 0 || s.indexOf('safety') >= 0) return 'Continue to the modern safety deck and see what changed because people studied the evidence.';
    if(s.indexOf('lookout') >= 0 || s.indexOf('master') >= 0) return 'Climb toward the final lookout and pull the whole Shipwreck Cove investigation together.';
    if(s.indexOf('pier') >= 0) return 'Return to the foggy pier and review the harbor clues before moving on.';
    return 'Travel to ' + dest + ' and continue the guided wreck investigation.';
  }

  function polishShipwreckChoices(){
    try{
      document.querySelectorAll('.swczCExits').forEach(function(box){
        if(box.dataset.lr66ChoicePolished === '1') return;
        box.dataset.lr66ChoicePolished = '1';
        var buttons = Array.prototype.slice.call(box.querySelectorAll('button'));
        if(!buttons.length) return;
        box.classList.add('lrSwcAdventureChoices');
        var heading = document.createElement('div');
        heading.className = 'lrSwcAdventureHeading';
        heading.textContent = 'Choose the next stop in the tour';
        box.insertBefore(heading, box.firstChild);
        buttons.forEach(function(btn, i){
          var old = btn.textContent || '';
          var locked = btn.classList.contains('swczCLocked') || old.indexOf('🔒') >= 0;
          btn.classList.add('lrSwcChoiceBtn');
          btn.innerHTML = '<span class="lrChoiceNumber">' + (i + 1) + '</span><span class="lrChoiceBody"><b>' + esc(swcChoiceText(old)) + (locked ? ' 🔒' : '') + '</b><small>' + esc(swcTargetLabel(old)) + '</small></span>';
        });
      });
    }catch(e){}
  }

  function injectStyles(){
    if(byId('lrAdventureChoiceNav66Style')) return;
    var css = `
      #mainCompassNav, #mainCompassNav *{box-sizing:border-box;}
      #lrControlDock,#lrFixedGameplayDock,#lrCenterActionDock,#lrCenterGameplayDock{display:none!important;}
      .lrExplorePanel{display:none!important;}
      .lrAdventurePanel{
        margin:14px 0 10px;
        padding:14px;
        border-radius:18px;
        background:linear-gradient(135deg, rgba(20,38,33,.96), rgba(44,64,52,.96));
        border:2px solid rgba(232,219,168,.42);
        color:#f7efd8;
        box-shadow:0 10px 24px rgba(0,0,0,.26);
        position:relative;
        z-index:3;
      }
      .lrAdventureHeader{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:12px;border-bottom:1px solid rgba(247,239,216,.16);padding-bottom:10px;}
      .lrAdventureHeader h3{margin:2px 0 0;color:#fff7d9;font-size:1.12rem;}
      .lrAdventureHeader small{max-width:240px;text-align:right;color:#d9e5cc;font-weight:700;font-size:.78rem;line-height:1.25;}
      .lrAdventureKicker{font-weight:900;font-size:.82rem;text-transform:uppercase;letter-spacing:.05em;color:#ffdf87;}
      .lrAdventureChoiceList{display:grid;grid-template-columns:1fr;gap:8px;}
      .lrAdventureChoiceBtn,.lrSwcChoiceBtn{
        width:100%!important;
        min-height:58px!important;
        padding:10px 12px!important;
        border-radius:14px!important;
        border:1px solid rgba(255,230,151,.42)!important;
        background:rgba(255,250,229,.94)!important;
        color:#1b332b!important;
        display:flex!important;
        align-items:flex-start!important;
        gap:10px!important;
        text-align:left!important;
        line-height:1.25!important;
        box-shadow:0 4px 10px rgba(0,0,0,.15)!important;
      }
      .lrAdventureChoiceBtn:hover,.lrSwcChoiceBtn:hover{filter:brightness(1.03);transform:translateY(-1px);}
      .lrChoiceNumber{
        flex:0 0 28px;
        height:28px;
        border-radius:999px;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        background:#244c41;
        color:#fff7d9;
        font-weight:900;
        box-shadow:inset 0 0 0 1px rgba(255,255,255,.16);
      }
      .lrChoiceBody{display:flex;flex-direction:column;gap:3px;min-width:0;}
      .lrChoiceBody b{font-size:.95rem;font-weight:900;color:#18352d;}
      .lrChoiceBody small{font-size:.75rem;color:#486056;font-weight:700;}
      .lrAdventureActionRow{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(247,239,216,.16);}
      .lrAdventureActionRow button{min-height:40px!important;border-radius:12px!important;font-weight:900!important;}
      .lrAdventureNoChoices{padding:12px;border-radius:14px;background:rgba(255,255,255,.08);color:#fff7d9;}
      .lrAdventureLook{padding:12px;border-radius:16px;background:rgba(30,47,42,.92);border:1px solid rgba(232,219,168,.32);color:#f7efd8;line-height:1.48;}
      .lrAdventureLook h3,.lrAdventureLook h4{margin-top:0;color:#fff7d9;}
      .lrAdventureLook li{margin:.35rem 0;}
      .lrSwcAdventureChoices{display:grid!important;grid-template-columns:1fr!important;gap:8px!important;}
      .lrSwcAdventureHeading{font-weight:900;color:#123345;background:#e7f4f8;border:1px solid rgba(31,71,91,.22);border-radius:12px;padding:8px 10px;}
      .lrSwcChoiceBtn.swczCLocked,.swczCLocked.lrSwcChoiceBtn{opacity:.78!important;background:#ece6db!important;}
      @media(max-width:900px){
        .lrAdventureHeader{display:block;}
        .lrAdventureHeader small{display:block;text-align:left;max-width:none;margin-top:4px;}
        .lrAdventureChoiceBtn,.lrSwcChoiceBtn{min-height:52px!important;padding:9px!important;}
      }
    `;
    var st = document.createElement('style');
    st.id = 'lrAdventureChoiceNav66Style';
    st.textContent = css;
    document.head.appendChild(st);
  }

  function wrapShipwreck(fn){
    if(typeof window[fn] !== 'function' || window[fn].__lr66Wrapped) return;
    var old = window[fn];
    var repl = function(){
      var out = old.apply(this, arguments);
      setTimeout(polishShipwreckChoices, 20);
      setTimeout(polishShipwreckChoices, 100);
      return out;
    };
    repl.__lr66Wrapped = true;
    window[fn] = repl;
  }

  function boot(){
    injectStyles();
    removeOldDocks();
    if(typeof window.lrApplyFixedDockLayout === 'function') window.lrApplyFixedDockLayout = removeOldDocks;
    if(typeof window.lrKeepCenterControlsVisible === 'function') window.lrKeepCenterControlsVisible = removeOldDocks;
    ['shipwreckGuidedZoneOpen','shipwreckGuidedZoneContinue','shipwreckGuidedZoneTalk','shipwreckGuidedZoneMap','shipwreckGuidedZoneMove'].forEach(wrapShipwreck);
    setTimeout(window.lrRenderExplorationNav, 25);
    setTimeout(polishShipwreckChoices, 50);
  }

  try{
    if(typeof renderRoom === 'function' && !window.__LR66_RENDER_WRAPPED__){
      window.__LR66_RENDER_WRAPPED__ = true;
      var oldRender = renderRoom;
      renderRoom = function(){
        var result = oldRender.apply(this, arguments);
        setTimeout(function(){ injectStyles(); removeOldDocks(); window.lrRenderExplorationNav(); }, 25);
        return result;
      };
      window.renderRoom = renderRoom;
    }
  }catch(e){ console.warn('6.6 render wrap skipped', e); }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  }else{
    setTimeout(boot, 10);
  }
  window.addEventListener('load', function(){ setTimeout(boot, 80); setTimeout(boot, 500); });
})();
