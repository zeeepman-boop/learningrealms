// Curriculum Pack 6D: Logic / Critical Thinking Foundation
// Content-only expansion. No mechanics, Home, UI, or engine changes.
(function(){
  if (typeof LR_addLessons !== "function") return;
  LR_addLessons("Luna", "Logic", [
    { teach:"Sorting means putting things into groups that belong together.", practice:"Apples with apples. Socks with socks. That is sorting.", q:"What does sorting mean?", c:["putting things in groups","throwing things away","making things loud"], a:"putting things in groups" },
    { teach:"A pattern is something that repeats in order.", practice:"Red, blue, red, blue is a pattern because it repeats.", q:"Which one is a pattern?", c:["red blue red blue","red blue green yellow","chair apple shoe"], a:"red blue red blue" },
    { teach:"Same means alike. Different means not alike.", practice:"Two stars are the same shape. A star and a square are different shapes.", q:"Same means...", c:["alike","broken","hungry"], a:"alike" },
    { teach:"A clue helps you figure something out.", practice:"Wet paw prints are a clue an animal walked there.", q:"What helps you figure something out?", c:["a clue","a nap","a cloud"], a:"a clue" },
    { teach:"First, next, and last tell the order things happen.", practice:"First wash hands, next eat, last clean up.", q:"Which word tells what happens at the end?", c:["last","first","round"], a:"last" }
  ]);
  LR_addLessons("Ava", "Logic", [
    { teach:"Observation means noticing details carefully.", practice:"A careful thinker notices color, shape, size, order, and changes.", q:"Observation means...", c:["noticing details","guessing without looking","copying an answer"], a:"noticing details" },
    { teach:"A cause is why something happens. An effect is what happens after.", practice:"The wind blew, so the leaves moved.", q:"In cause and effect, the effect is...", c:["what happens after","the reason it happened","a random opinion"], a:"what happens after" },
    { teach:"Evidence is information that supports a claim.", practice:"Footprints by the door can be evidence that someone walked there.", q:"What supports a claim?", c:["evidence","a guess","a decoration"], a:"evidence" },
    { teach:"An inference is a thoughtful conclusion based on clues.", practice:"A wet umbrella by the door may help you infer it rained.", q:"An inference is based on...", c:["clues","nothing","volume"], a:"clues" },
    { teach:"A fact can be checked. An opinion tells what someone thinks or feels.", practice:"The cup is blue can be checked. Blue is best is an opinion.", q:"Which one can be checked?", c:["fact","opinion","preference"], a:"fact" }
  ]);
  LR_addLessons("Michael", "Logic", [
    { teach:"A valid conclusion follows from the evidence and reasoning given.", practice:"If all squares have four sides and this shape is a square, it has four sides.", q:"A valid conclusion should follow from...", c:["evidence and reasoning","mood only","a random answer"], a:"evidence and reasoning" },
    { teach:"A claim is a statement someone says is true.", practice:"The bridge is unsafe is a claim. It needs evidence before accepting it.", q:"A claim is...", c:["a statement said to be true","proof by itself","a question only"], a:"a statement said to be true" },
    { teach:"Bias is a tendency that can unfairly affect judgment.", practice:"Liking one team can make someone judge a close call unfairly.", q:"Bias can affect...", c:["judgment","gravity","temperature only"], a:"judgment" },
    { teach:"Correlation means two things happen together. It does not always prove cause.", practice:"Ice cream sales and hot days rise together, but ice cream does not cause heat.", q:"Correlation alone does not prove...", c:["causation","comparison","counting"], a:"causation" },
    { teach:"A logical fallacy is a flaw in reasoning.", practice:"Attacking a person instead of the idea is poor reasoning.", q:"A logical fallacy is...", c:["a flaw in reasoning","a strong proof","a math tool only"], a:"a flaw in reasoning" }
  ]);
})();
