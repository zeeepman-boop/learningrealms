/* LearningRealms 7.6B - Shipwreck Cove Polish + Route Audit
   Additive stabilization patch built on 7.6A. No shell rebuild, no render loop, no loading curtain.
   Purpose: keep all visible Shipwreck Cove routes pointed to the new deep rebuild, add a small audit panel, and close escape paths into older cove layers. */
(function(){
'use strict';
if(window.__LR76B_SHIPWRECK_COVE_ROUTE_AUDIT__) return;
window.__LR76B_SHIPWRECK_COVE_ROUTE_AUDIT__ = true;

var PATCH='7.6B Shipwreck Cove Polish + Route Audit';
var ROOM_ALIASES={
  pier:'pier', fog:'pier', bell:'pier', entrance:'pier', dock:'pier',
  lighthouse:'lighthouse', chart:'lighthouse', loft:'lighthouse', map:'lighthouse', navigation:'lighthouse',
  storm:'storm', weather:'storm', fogbank:'storm', current:'storm', wave:'storm',
  drydock:'drydock', dry:'drydock', dockyard:'drydock', shipwright:'drydock', hull:'drydock', engineering:'drydock',
  rescue:'rescue', lifeboat:'rescue', signal:'rescue', safety:'rescue',
  lab:'lab', evidence:'lab', archaeology:'lab', artifact:'lab', conservation:'lab',
  pirate:'pirate', trade:'pirate', law:'pirate',
  gallery:'gallery', famous:'gallery', wreck:'gallery', memory:'gallery'
};
function byId(id){return document.getElementById(id);}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(ch){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];});}
function has(fn){return typeof window[fn]==='function';}
function mainBox(){return byId('actionText') || byId('lrPopupBody') || null;}
function titleBox(){return byId('actionTitle') || byId('lrPopupTitle');}
function closeOldShipwreckPopups(){
  try{
    var old=byId('shipwreckCove74IPopup');
    if(old && !old.classList.contains('lr76bAllowedOldPopup')) old.remove();
  }catch(e){}
  try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){}
}
function normalizeRoomId(v){
  var raw=String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  if(!raw) return 'pier';
  if(ROOM_ALIASES[raw]) return ROOM_ALIASES[raw];
  var parts=raw.split(/\s+/);
  for(var i=0;i<parts.length;i++) if(ROOM_ALIASES[parts[i]]) return ROOM_ALIASES[parts[i]];
  if(raw.indexOf('light')>=0 || raw.indexOf('chart')>=0) return 'lighthouse';
  if(raw.indexOf('storm')>=0 || raw.indexOf('weather')>=0 || raw.indexOf('fog')>=0) return 'storm';
  if(raw.indexOf('dry')>=0 || raw.indexOf('ship')>=0 || raw.indexOf('hull')>=0) return 'drydock';
  if(raw.indexOf('rescue')>=0 || raw.indexOf('life')>=0 || raw.indexOf('signal')>=0) return 'rescue';
  if(raw.indexOf('arch')>=0 || raw.indexOf('evidence')>=0 || raw.indexOf('lab')>=0) return 'lab';
  if(raw.indexOf('pirate')>=0 || raw.indexOf('trade')>=0) return 'pirate';
  if(raw.indexOf('famous')>=0 || raw.indexOf('gallery')>=0 || raw.indexOf('memory')>=0) return 'gallery';
  return 'pier';
}
function openMap(){ closeOldShipwreckPopups(); if(has('openShipwreckCoveDeepRebuild76A')) return window.openShipwreckCoveDeepRebuild76A(); if(has('openShipwreckCoveDeepCourse')) return window.openShipwreckCoveDeepCourse(); }
function openRoom(id){ closeOldShipwreckPopups(); id=normalizeRoomId(id); if(has('shipwreckCoveTravel')) return window.shipwreckCoveTravel(id); return openMap(); }
function openTalk(){ closeOldShipwreckPopups(); if(has('openShipwreckCoveKeeper76A')) return window.openShipwreckCoveKeeper76A(); if(has('openShipwreckCoveDeepCourse')) return window.openShipwreckCoveDeepCourse(); }
function openInspect(id){ closeOldShipwreckPopups(); if(has('shipwreckCoveInspect')) return window.shipwreckCoveInspect(normalizeRoomId(id)); return openRoom(id); }
function patchGlobalRoutes(){
  window.shipwreckGuidedZoneMap=openMap;
  window.shipwreckGuidedZoneMove=function(id){return openRoom(id);};
  window.shipwreckGuidedZoneTalk=openTalk;
  window.shipwreckFallbackPopup=openMap;
  window.openShipwreckCoveQualityLockCheck=routeAudit;
  if(!has('openShipwreckCoveRouteAudit76B')) window.openShipwreckCoveRouteAudit76B=routeAudit;
}
function buttonText(el){return (el && (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')) || '').replace(/\s+/g,' ').trim();}
function isOldShipwreckControl(el){
  if(!el || (el.closest && (el.closest('.lr76aShell') || el.closest('.lr76bShell')))) return false;
  var text=buttonText(el);
  var attr=[el.getAttribute('onclick')||'', el.getAttribute('data-route')||'', el.getAttribute('data-action')||'', el.getAttribute('href')||''].join(' ');
  var hay=(text+' '+attr).toLowerCase();
  if(!/(shipwreck|ship wreck|cove|fogbound|wreck steward|lifeboat|chart loft|pirate map|famous wreck)/i.test(hay)) return false;
  if(/history and world|world directory|realm library|connection ledger|core halls|science and engineering|bible road|creative quarter|homestead/i.test(text)) return false;
  return true;
}
function routeForText(text){
  var t=String(text||'').toLowerCase();
  if(/artifact|reward|catalog|shelf/.test(t)) return 'rewards';
  if(/review|missed/.test(t)) return 'review';
  if(/keeper|marnie|talk|shop/.test(t)) return 'merchant';
  if(/lighthouse|chart|navigation|soundings/.test(t)) return 'room:lighthouse';
  if(/storm|weather|fog|current|wave/.test(t)) return 'room:storm';
  if(/dry dock|drydock|shipwright|hull|ballast|buoyancy|engineering/.test(t)) return 'room:drydock';
  if(/rescue|lifeboat|signal|safety/.test(t)) return 'room:rescue';
  if(/evidence|archaeology|lab|conservation/.test(t)) return 'room:lab';
  if(/pirate|trade|law/.test(t)) return 'room:pirate';
  if(/famous|gallery|titanic|great lakes|memory/.test(t)) return 'room:gallery';
  if(/pier|bell|entrance|dock/.test(t)) return 'room:pier';
  return 'map';
}
function rerouteOldControls(){
  var count=0;
  try{
    Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')).forEach(function(el){
      if(!isOldShipwreckControl(el)) return;
      var text=buttonText(el), route=routeForText(text);
      el.setAttribute('data-lr76a-act', route);
      el.setAttribute('data-lr76b-rerouted','true');
      try{/* 7.6W: preserve onclick fallback */}catch(e){}
      if(el.tagName && el.tagName.toLowerCase()==='a') el.setAttribute('href','#');
      count++;
    });
  }catch(e){}
  return count;
}
function scanVisibleRoutes(){
  var found=[];
  try{
    Array.prototype.slice.call(document.querySelectorAll('button,a,[role="button"]')).forEach(function(el){
      var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : {width:1,height:1};
      if(rect.width===0 || rect.height===0) return;
      var text=buttonText(el); if(!text) return;
      if(/shipwreck|cove|lifeboat|chart loft|pirate map|famous wreck|fog bell/i.test(text)){
        found.push({text:text.slice(0,90), route:el.getAttribute('data-lr76a-act') || el.getAttribute('onclick') || el.getAttribute('href') || 'no explicit route', patched:!!el.getAttribute('data-lr76b-rerouted') || !!(el.closest && el.closest('.lr76aShell'))});
      }
    });
  }catch(e){}
  return found.slice(0,40);
}
function routeAudit(){
  closeOldShipwreckPopups();
  var patched=rerouteOldControls();
  var routes=scanVisibleRoutes();
  var rows=routes.length ? routes.map(function(r){
    return '<tr><td>'+esc(r.text)+'</td><td>'+esc(r.route)+'</td><td>'+(r.patched?'Safe / new route':'Check if visible')+'</td></tr>';
  }).join('') : '<tr><td colspan="3">No loose Shipwreck Cove controls are visible right now. Open History and World Wing, then run this again if needed.</td></tr>';
  var t=titleBox(), b=mainBox();
  if(t) t.textContent='⚓ Shipwreck Cove Route Audit';
  if(!b){ openMap(); return; }
  if(b){
    b.innerHTML='<div class="lr76bShell"><section class="lr76bHero"><h2>Shipwreck Cove route audit</h2><p>This small stabilizer checks visible cove buttons and keeps them aimed at the new 7.6A deep rebuild instead of older popup layers.</p></section><section class="lr76bPanel"><h3>Audit result</h3><p><b>'+patched+'</b> old loose cove control(s) were rerouted during this scan.</p><table class="lr76bTable"><thead><tr><th>Visible label</th><th>Route</th><th>Status</th></tr></thead><tbody>'+rows+'</tbody></table></section><section class="lr76bPanel"><h3>Safe exits</h3><div class="lr76bNav"><button data-lr76b-act="map">Open Shipwreck Cove</button><button data-lr76b-act="history">History and World Wing</button><button data-lr76b-act="scan">Scan again</button></div></section></div>';
  }
}
function injectAuditStrip(){
  var root=byId('actionText'); if(!root || byId('lr76bAuditStrip')) return;
  if(!root.querySelector || !root.querySelector('.lr76aShell')) return;
  var txt=(root.textContent||'');
  if(!/Shipwreck Cove|Fog Bell|Lighthouse Chart|Storm Table|Famous Wreck/i.test(txt)) return;
  var div=document.createElement('div'); div.id='lr76bAuditStrip'; div.className='lr76bStrip';
  div.innerHTML='<b>7.6B route polish:</b> Cove routes are locked to the new deep rebuild. <button data-lr76b-act="scan">Run visible route audit</button>';
  try{root.querySelector('.lr76aShell').appendChild(div);}catch(e){try{root.appendChild(div);}catch(err){}}
}
function bind(){
  if(window.__LR76B_BIND__) return; window.__LR76B_BIND__=true;
  window.addEventListener('click', function(ev){
    var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr76b-act]') : null;
    if(!el) return;
    ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
    var act=String(el.getAttribute('data-lr76b-act')||'scan');
    if(act==='scan') return routeAudit();
    if(act==='map') return openMap();
    if(act==='history'){ if(has('openLearningCenterAnnex75O')) return window.openLearningCenterAnnex75O('history'); if(has('openRealmLibrary75A')) return window.openRealmLibrary75A('history'); return openMap(); }
  }, true);
}
function styles(){
  if(byId('lr76bStyles')) return;
  var st=document.createElement('style'); st.id='lr76bStyles'; st.textContent='\
.lr76bShell{font-family:inherit;color:#17303a}.lr76bHero,.lr76bPanel{background:linear-gradient(180deg,#fffdf6,#f7efdf);border:1px solid rgba(62,87,98,.22);border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 5px 14px rgba(10,32,42,.08)}.lr76bHero{background:linear-gradient(135deg,#143240,#236d7c);color:#fff}.lr76bHero h2{color:#fff;margin:.1rem 0 .45rem}.lr76bHero p{color:#fff9e8}.lr76bTable{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}.lr76bTable th,.lr76bTable td{border:1px solid rgba(36,70,83,.18);padding:8px;text-align:left;vertical-align:top}.lr76bTable th{background:#eaf6f8}.lr76bNav{display:flex;gap:8px;flex-wrap:wrap}.lr76bNav button,.lr76bStrip button{border:1px solid rgba(33,65,82,.28);border-radius:12px;background:#fffaf0;padding:8px 11px;font-weight:800;cursor:pointer;box-shadow:0 2px 0 rgba(0,0,0,.08);color:#1d3340}.lr76bStrip{margin:12px 0 0;padding:10px 12px;border-radius:14px;background:#eef9fb;border:1px solid #8ac4d1;color:#17303a;display:flex;gap:10px;align-items:center;flex-wrap:wrap}\
'; document.head.appendChild(st);
}
function boot(){
  styles(); bind(); patchGlobalRoutes(); rerouteOldControls(); injectAuditStrip();
  try{ var mo=new MutationObserver(function(){ patchGlobalRoutes(); rerouteOldControls(); injectAuditStrip(); closeOldShipwreckPopups(); }); mo.observe(document.body,{childList:true,subtree:true}); }catch(e){}
  setTimeout(function(){patchGlobalRoutes();rerouteOldControls();injectAuditStrip();},250);
  setTimeout(function(){patchGlobalRoutes();rerouteOldControls();injectAuditStrip();},900);
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();
window.openShipwreckCoveRouteAudit76B=routeAudit;
})();
