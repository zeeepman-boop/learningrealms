// Curriculum Pack 6K Reading Forge
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Reading",[
{teach:"Stories have characters.",q:"Who is in a story?",c:["characters","rocks","weather"],a:"characters"},
{teach:"Stories happen in settings.",q:"Where a story happens is the...",c:["setting","title","cover"],a:"setting"},
{teach:"Beginning comes first.",q:"What comes first?",c:["beginning","ending","middle"],a:"beginning"},
{teach:"Main idea is what a text is mostly about.",q:"Main idea means...",c:["mostly about","favorite word","picture"],a:"mostly about"}
]);

LR_addLessons("Ava","Reading",[
{teach:"Inference uses clues and thinking.",q:"Inference uses...",c:["clues","guessing only","luck"],a:"clues"},
{teach:"Context clues help vocabulary.",q:"Context clues help...",c:["word meaning","spelling only","maps"],a:"word meaning"},
{teach:"Cause leads to effect.",q:"Cause leads to...",c:["effect","title","chapter"],a:"effect"},
{teach:"Nonfiction gives information.",q:"Nonfiction mainly gives...",c:["information","songs","games"],a:"information"}
]);

LR_addLessons("Michael","Reading",[
{teach:"Theme is a deeper message.",q:"Theme is...",c:["message","character","cover"],a:"message"},
{teach:"Evidence supports answers.",q:"Answers should use...",c:["evidence","guesses","luck"],a:"evidence"},
{teach:"Point of view affects narration.",q:"Point of view changes...",c:["narration","paper","font"],a:"narration"},
{teach:"Authors develop ideas across texts.",q:"Authors develop...",c:["ideas","maps","equations"],a:"ideas"}
]);
})();