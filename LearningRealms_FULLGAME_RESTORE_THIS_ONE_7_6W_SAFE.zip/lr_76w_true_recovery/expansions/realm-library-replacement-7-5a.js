/* LearningRealms Realm Library Replacement 7.5A
   Conservative navigation/display patch built on 7.4Z.
   Goal: replace the mile-long Scroll Shelf / REAL Curriculum link wall with a game-like
   Hall of Doors: umbrellas first, deep roads first, legacy one-question practice kept in
   nested drawers only. No shell rewrite, no lesson rewrite, no save reset.
*/
(function(){
  'use strict';
  if(window.__LR75A_REALM_LIBRARY__) return;
  window.__LR75A_REALM_LIBRARY__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ try{ return (root||document).querySelector(sel); }catch(e){ return null; } }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function norm(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,''); }
  function has(fn){ return typeof window[fn] === 'function'; }
  function call(fn){
    var args = Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); return true; }
    catch(e){ console.warn('LR75A route failed:', fn, e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var x=list[i];
      if(Array.isArray(x)){ if(call.apply(null,x)) return true; }
      else if(call(x)) return true;
    }
    return false;
  }
  function mount(title, html){
    installStyles();
    var t=byId('actionTitle'), b=byId('actionText');
    if(t) t.textContent = title || 'Realm Library';
    if(b) b.innerHTML = html;
    if(has('lrOpenActionPopup')){ try{ window.lrOpenActionPopup(title || 'Realm Library'); }catch(e){} }
    else if(has('lrOpenPopup')){ try{ window.lrOpenPopup(title || 'Realm Library', html); }catch(e){} }
  }
  function popup(title, html){
    installStyles();
    if(has('lrOpenPopup')) return window.lrOpenPopup(title, html);
    return mount(title, html);
  }

  var WINGS = {
    core:{
      title:'Core Halls', icon:'🏰', tag:'Reading · Writing · Math · Logic',
      mood:'A lantern-lit academy of libraries, number vaults, writing desks, and puzzle towers. This is where basic skill paths become real rooms instead of a plain list.',
      doors:[
        {title:'Core Halls Adventure', icon:'🏰', meta:'Reading, Writing, Math, and Logic together', body:'A castle-academy road with chamber movement, proof challenges, and artifacts for the main foundations.', call:['openCoreHallsNoFillerAdventure74N']},
        {title:'Writing Composition Master Course', icon:'🪶', meta:'Author Guild · Story Forge · Essay craft', body:'The deeper writing road with sentences, paragraphs, stories, evidence, revision, proofreading, and portfolios.', call:['openWritingCompositionMasterCourse','openWritingCompositionMaster74W','openAuthorGuild']},
        {title:'Reading Practice Drawer', icon:'📚', meta:'Foundational reading shelves', body:'Older quick practice scrolls, kept in a drawer instead of spread across the whole screen.', archive:'reading'},
        {title:'Math Practice Drawer', icon:'🔢', meta:'Foundational number shelves', body:'Counting, fractions, geometry, equations, and applied math practice in small batches.', archive:'math'},
        {title:'Logic Practice Drawer', icon:'🧩', meta:'Puzzle shelves', body:'Patterns, sequences, clues, and reasoning practice in a compact drawer.', archive:'logic'}
      ]
    },
    science:{
      title:'Science and Engineering Quarter', icon:'🔬', tag:'Nature · Weather · Animals · Inventions · Flight',
      mood:'A busy quarter of laboratories, field stations, sky docks, storm towers, and blueprint benches. Each door opens a real expedition road.',
      doors:[
        {title:'Science and Engineering Expedition', icon:'⚙️', meta:'Foundations of science and design', body:'Matter, forces, machines, energy, circuits, plants, habitats, safe body systems, and engineering design.', call:['openScienceEngineeringAdventure74M','openScienceEngineeringQuarter74M']},
        {title:'Inventions & Engineering Disasters', icon:'🛠️', meta:'Blueprints · failures · redesign', body:'Invention history and kid-safe engineering investigations focused on evidence, design limits, testing, and safer rebuilds.', call:['openInventionsEngineeringMaster74R','openInventionsEngineeringDisasters74R','openInventionsDeepCourse']},
        {title:'Aerospace Engineering Mission Wing', icon:'🚀', meta:'Flight hall · rocket yard · mission control', body:'Lift, drag, thrust, gliders, rockets, orbits, satellites, simulations, Apollo, rovers, spacesuits, and future flight.', call:['openAerospaceEngineering74S','openAerospaceEngineering','openAerospaceMissionWing74S']},
        {title:'Nature & Health Deep Adventure', icon:'🌿', meta:'Living Woods · Health Lodge', body:'Ecosystems, gardens, weather sense, safe body systems, hygiene, sleep, movement, and field readiness.', call:['openNatureHealthDeepAdventure','openNatureHealth74T','openNatureAndHealth']},
        {title:'Weather & Storm Lab', icon:'🌦️', meta:'Stormwatch Tower', body:'Clouds, pressure, wind, storms, instruments, radar, satellites, forecasting, and safety planning.', call:['openWeatherStormLab74U','openWeatherStormLab','openStormwatchTower']},
        {title:'Animal Kingdom & Creature Field Guide', icon:'🐾', meta:'Creature Field Station', body:'Animal groups, habitats, tracks, migration, field journals, ducks, chickens, companion care, and no-touch wildlife wisdom.', call:['openCreatureFieldGuide','openAnimalKingdom74V','openAnimalKingdom']},
        {title:'Science Practice Drawer', icon:'🧪', meta:'Older quick shelves', body:'Short practice rooms for older science packs, tucked into batches instead of one long wall.', archive:'science'}
      ]
    },
    history:{
      title:'History and World Wing', icon:'🗺️', tag:'Egypt · England · West · Ships · Civics · Markets',
      mood:'A museum wing of map tables, royal halls, desert chambers, harbor charts, frontier roads, civic desks, and market stalls.',
      doors:[
        {title:'Ancient Egypt Expedition', icon:'𓂀', meta:'Nile halls · royal gallery · world expansion', body:'The strongest model course so far: Egypt foundations, rulers, monuments, daily life, temples, beliefs, archaeology, and artifacts.', call:['openAncientEgyptCourse','openAncientEgyptTrail','openLearningRealmsEgyptRoad']},
        {title:'Egypt Royal Gallery', icon:'👑', meta:'Notable pharaohs and rulers', body:'A dynasty-by-dynasty royal gallery with ruler chambers and historical artifacts.', call:['openAncientEgyptRoyalGallery','openAncientEgyptRoyalCourse']},
        {title:'Egypt World Expansion', icon:'🏺', meta:'Monuments, daily life, temples, archaeology', body:'Nile boats, farming, homes, art, quarries, Giza, temples, tombs, Rosetta Stone, museums, and preservation.', call:['openAncientEgyptWorldExpansion','openAncientEgyptWorldCourse']},
        {title:'England: Kings and Queens Road', icon:'👑', meta:'Castles · charters · Parliament · modern crown', body:'The royal-history road you liked: Anglo-Saxon England through William, Magna Carta, Tudors, Stuarts, Victoria, Elizabeth II, and the modern crown.', call:['openEnglandKingsQueens74Q','openEnglandKingsQueensRoad74Q']},
        {title:'Great Depression History Street', icon:'🏚️', meta:'Economy, families, Dust Bowl, recovery', body:'A no-filler historical/economic road on bank runs, family budgets, relief, public works, culture, and legacy.', call:['openGreatDepressionTrail','openGreatDepressionCourse']},
        {title:'Wild West Frontier Trail', icon:'🤠', meta:'Kid-safe frontier history', body:'Trails, railroads, cattle drives, tools, towns, geography, newspapers, homesteads, and myth vs. evidence.', call:['openWildWestTrail','openWildWestCourse']},
        {title:'Shipwreck Cove', icon:'⚓', meta:'Harbor, wrecks, weather, rescue, evidence', body:'A maritime adventure zone with charts, lighthouses, navigation, storms, famous wrecks, archaeology, and folklore handled carefully.', call:['shipwreckGuidedZoneOpen','openShipwreckCoveMap','openShipwreckCoveDeepCourse']},
        {title:'Mapmaker’s Loft', icon:'🧭', meta:'Geography support road', body:'Maps, landforms, regions, climate, resources, trade routes, migration, and how geography shapes history.', call:['openMapmakersLoft74P','openHistoryWorldSupportAdventure74P']},
        {title:'Civic Hall', icon:'🏛️', meta:'Laws, government, public life', body:'Rules, courts, local government, public services, symbols, founding documents, and responsibilities.', call:['openCivicHall74P','openHistoryWorldSupportAdventure74P']},
        {title:'Market Square', icon:'🏪', meta:'Economics support road', body:'Needs, wants, goods, services, money, banks, supply and demand, jobs, taxes, trade, and budgets.', call:['openMarketSquare74P','openHistoryWorldSupportAdventure74P']},
        {title:'History Practice Drawer', icon:'📜', meta:'Older heritage shelves', body:'Older quick history and geography practice, kept as a compact drawer for extra review.', archive:'heritage'}
      ]
    },
    bible:{
      title:'Bible Road', icon:'✝️', tag:'Catholic-friendly sacred history',
      mood:'A separate respectful road with chapel shelves, Gospel rooms, sacred-art symbols, saints, angels, sacraments, and careful artifact displays.',
      doors:[
        {title:'Bible History Road', icon:'📖', meta:'Catholic-friendly no-filler course', body:'Creation through the New Testament, Mary, Jesus, apostles, Pentecost, saints, angels, sacraments, and the Church year.', call:['openBibleHistoryTrail','openBibleHistoryCourse']},
        {title:'Saints, Angels, and Early Church Road', icon:'🕯️', meta:'Saints Gallery · Angel Tower · Early Church', body:'A reverent Catholic-friendly expansion with saints, archangels, guardian angels, Pentecost, Acts, early sacraments, councils, creeds, and sacred time.', call:['openBibleRoadSaintsAngelsEarlyChurch75M','openSaintsAngelsEarlyChurchRoad75M']},
        {title:'Bible Artifact Hall', icon:'🕯️', meta:'Tasteful study symbols', body:'Respectful memory pieces and chapel-style displays, not magic items or silly loot.', call:['openBibleHistoryArtifacts','openBibleHistoryRewards','openBibleHistoryArtifacts73B']},
        {title:'Bible Review Shelf', icon:'🔁', meta:'Return to missed clues', body:'Review missed Bible History questions and return to the road.', call:['openBibleHistoryReview']}
      ]
    },
    creative:{
      title:'Creative Quarter', icon:'🎨', tag:'Art · music · theater · story making',
      mood:'A maker village with paint tables, craft cottages, music corners, stage curtains, puppet shelves, and gallery walls.',
      doors:[
        {title:'Creative Quarter Adventure', icon:'🎨', meta:'Art, music, theater, craft, story', body:'Drawing, color, watercolor, sculpture, patterns, design, melody, instruments, theater, props, puppets, galleries, and observation sketching.', call:['openCreativeQuarterAdventure74O','openCreativeHomesteadAdventure74O']},
        {title:'Creative Practice Drawer', icon:'🖌️', meta:'Older art and music shelves', body:'Short legacy practice rooms for art, music, theater, craft, and story packs.', archive:'arts'}
      ]
    },
    homestead:{
      title:'Homestead Workshop', icon:'🏡', tag:'Life skills · companions · collections · living world',
      mood:'A cozy working yard with storage rooms, companion dens, repair benches, kitchen safety shelves, garden paths, and the town notice board.',
      doors:[
        {title:'Homestead Workshop Adventure', icon:'🧰', meta:'Life skills and home craft', body:'Kitchen safety, measuring, gardening, animal care, repair, mending, cleaning, budgeting, first aid signals, weather readiness, and display rooms.', call:['openHomesteadWorkshopAdventure74O','openCreativeHomesteadAdventure74O']},
        {title:'Town Notice Board', icon:'📌', meta:'Seasons, events, shops, rare rotations', body:'Preserves the living-world systems: seasons, festivals, merchant row, rare finds, pets, collections, quests, birthdays, and home rewards.', call:['openLivingWorldLedger74L']},
        {title:'Companion Den', icon:'🐾', meta:'Pets and helpers', body:'Open the companion area and pet systems when available.', call:['openCompanionDen','openPetJournal','openCompanionPopup']},
        {title:'Collection Log', icon:'💎', meta:'Artifacts and treasures', body:'Open earned collections and item records.', call:['openCollectionLog','openBackpack','openInventoryPopup','openAchievementJournal']},
        {title:'Quest Board', icon:'📜', meta:'Daily and story tasks', body:'Open the quest board, story quests, or daily tasks when available.', call:['openQuestBoard','openDailyQuestBoard','openQuestJournal','openStoryQuestJournal']},
        {title:'Life Practice Drawer', icon:'🍳', meta:'Older home-life shelves', body:'Short legacy practice rooms for life skills, cooking, repair, animal care, and budgeting.', archive:'life'}
      ]
    }
  };

  var SUBJECT_TO_WING = {
    all:null, math:'core', reading:'core', writing:'core', logic:'core',
    science:'science', aerospace:'science', engineering:'science', nature:'science', weather:'science', animals:'science', animal:'science',
    geography:'history', history:'history', heritage:'history', civics:'history', economics:'history',
    bible:'bible', arts:'creative', music:'creative', life:'homestead', homestead:'homestead'
  };

  function wingCard(key){
    var w = WINGS[key];
    return '<button type="button" class="lr75aWingCard" data-lr75a-act="wing:'+esc(key)+'">' +
      '<span class="lr75aBigIcon">'+esc(w.icon)+'</span>' +
      '<span><b>'+esc(w.title)+'</b><small>'+esc(w.tag)+'</small><p>'+esc(w.mood)+'</p></span>' +
      '<i>Enter ›</i>' +
    '</button>';
  }
  function doorCard(d, idx){
    var act = d.archive ? 'archive:'+d.archive+':0' : (d.call ? 'call:'+d.call.join('|') : 'wing:core');
    return '<button type="button" class="lr75aDoorCard" data-lr75a-act="'+esc(act)+'">' +
      '<span class="lr75aDoorIcon">'+esc(d.icon||'🚪')+'</span>' +
      '<span><b>'+esc(d.title)+'</b><small>'+esc(d.meta||'')+'</small><p>'+esc(d.body||'')+'</p></span>' +
      '<i>'+ (d.archive ? 'Open drawer' : 'Enter road') +' ›</i>' +
    '</button>';
  }

  function renderLibrary(){
    var html = '<div class="lr75aLibrary">' +
      '<div class="lr75aHero"><div class="lr75aHeroIcon">🏛️</div><div><h2>Realm Library</h2><p>Choose a wing first, then enter a road. Deep adventures like England, Egypt, Shipwreck Cove, Weather, Animals, and Writing are presented as doors and rooms. Older quick practice stays tucked inside drawers instead of becoming a mile of links.</p></div></div>' +
      '<div class="lr75aWingGrid">' + Object.keys(WINGS).map(wingCard).join('') + '</div>' +
      '<div class="lr75aFooter"><button data-lr75a-act="route:atlas">Realm Atlas</button><button data-lr75a-act="route:livingworld">Town Notice Board</button><button data-lr75a-act="route:home">Homestead</button></div>' +
    '</div>';
    mount('🏛️ Realm Library', html);
  }

  function renderWing(key){
    key = WINGS[key] ? key : 'core';
    var w = WINGS[key];
    var html = '<div class="lr75aLibrary lr75aWingRoom">' +
      '<div class="lr75aHero"><div class="lr75aHeroIcon">'+esc(w.icon)+'</div><div><h2>'+esc(w.title)+'</h2><p>'+esc(w.mood)+'</p><small>'+esc(w.tag)+'</small></div></div>' +
      '<div class="lr75aDoorGrid">' + w.doors.map(doorCard).join('') + '</div>' +
      '<div class="lr75aFooter"><button data-lr75a-act="library">All wings</button><button data-lr75a-act="route:atlas">Realm Atlas</button></div>' +
    '</div>';
    mount(w.icon+' '+w.title, html);
  }

  function localMatch(lesson, subject){
    var text = ((lesson.region||'')+' '+(lesson.pack_region||'')+' '+(lesson.mastery_tag||'')+' '+(lesson.question||'')).toLowerCase();
    if(subject === 'math') return /count|math|number|merchant|fraction|geometry|equation|budget|decimal|ratio|algebra/.test(text);
    if(subject === 'reading') return /story|reading|library|character|plot|infer|genre|main idea|text/.test(text);
    if(subject === 'science') return /insect|chem|weather|earth|physics|electric|botany|astronomy|nature|garden|energy|machine|robot|aero|space|rocket/.test(text);
    if(subject === 'writing') return /writing|sentence|paragraph|essay|author|grammar|punctuation/.test(text);
    if(subject === 'geography') return /map|geography|region|landform|river|climate/.test(text);
    if(subject === 'logic') return /logic|pattern|sequence|reason|clue/.test(text);
    if(subject === 'heritage') return /celtic|heritage|ancient|history|king|queen|civilization/.test(text);
    if(subject === 'life') return /life|cook|farm|repair|animal|budget|home|garden/.test(text);
    if(subject === 'arts') return /art|music|paint|theater|craft|builder|story|drawing/.test(text);
    return true;
  }
  async function loadBank(){
    try{
      if(has('lrLoadRealCurriculumBank')) return await window.lrLoadRealCurriculumBank();
      if(typeof lrLoadRealCurriculumBank === 'function') return await lrLoadRealCurriculumBank();
    }catch(e){}
    return window.__lrRealCurriculumBank || [];
  }
  function matchLesson(l, subject){
    try{
      if(has('lrLessonMatchesSubject')) return window.lrLessonMatchesSubject(l, subject);
      if(typeof lrLessonMatchesSubject === 'function') return lrLessonMatchesSubject(l, subject);
    }catch(e){}
    return localMatch(l, subject);
  }
  async function renderArchive(subject, page){
    subject = subject || 'all'; page = Math.max(0, Number(page)||0);
    var bank = await loadBank();
    var list = subject === 'all' ? bank : bank.filter(function(l){ return matchLesson(l, subject); });
    var per = 12, totalPages = Math.max(1, Math.ceil(list.length/per));
    if(page >= totalPages) page = totalPages-1;
    var sample = list.slice(page*per, page*per+per);
    var wing = SUBJECT_TO_WING[subject] || 'core';
    var html = '<div class="lr75aLibrary lr75aArchive">' +
      '<div class="lr75aHero"><div class="lr75aHeroIcon">📚</div><div><h2>'+esc(titleForSubject(subject))+' Practice Drawer</h2><p>These are older quick challenge rooms. They are useful for extra practice, but they stay in a drawer so the main game is led by the richer adventure roads.</p><small>'+list.length+' quick rooms found · Drawer page '+(page+1)+' / '+totalPages+'</small></div></div>' +
      '<div class="lr75aArchiveGrid">' + sample.map(function(l){
        var idx = (window.__lrRealCurriculumBank||bank).indexOf(l);
        if(idx < 0) idx = bank.indexOf(l);
        return '<button type="button" class="lr75aMiniScroll" data-lr75a-act="lesson:'+idx+'"><b>'+esc(l.region || l.pack_region || 'Practice room')+'</b><small>'+esc(l.mastery_tag || 'quick challenge')+'</small><p>'+esc(l.question || 'Open the challenge room.')+'</p></button>';
      }).join('') + '</div>' +
      '<div class="lr75aFooter">' +
        (page>0 ? '<button data-lr75a-act="archive:'+esc(subject)+':'+(page-1)+'">‹ Previous drawer page</button>' : '') +
        (page<totalPages-1 ? '<button data-lr75a-act="archive:'+esc(subject)+':'+(page+1)+'">Next drawer page ›</button>' : '') +
        '<button data-lr75a-act="wing:'+esc(wing)+'">Back to '+esc(WINGS[wing].title)+'</button><button data-lr75a-act="library">All wings</button>' +
      '</div></div>';
    mount('📚 '+titleForSubject(subject)+' Practice Drawer', html);
  }
  function titleForSubject(s){
    var m = {all:'All', math:'Math', reading:'Reading', science:'Science', writing:'Writing', geography:'Geography', logic:'Logic', aerospace:'Aerospace', heritage:'History', life:'Life Skills', arts:'Creative'};
    return m[s] || String(s||'Practice').replace(/^./,function(c){return c.toUpperCase();});
  }

  function route(act){
    act = String(act||'library');
    if(act === 'library') return renderLibrary();
    if(act.indexOf('wing:') === 0) return renderWing(act.slice(5));
    if(act.indexOf('archive:') === 0){ var p=act.split(':'); return renderArchive(p[1]||'all', Number(p[2]||0)); }
    if(act.indexOf('lesson:') === 0){ var idx = Number(act.split(':')[1]||0); return openPracticeRoom(idx); }
    if(act.indexOf('route:') === 0){ var r=act.slice(6); return first([['lr74xRoute',r],['lr74kRoute',r],['lr73pDo',r],['lr73mDo',r]]) || renderLibrary(); }
    if(act.indexOf('call:') === 0){ var fns=act.slice(5).split('|'); if(first(fns)) return true; return popup('Door still settling','<div class="lr75aLibrary"><h2>Door still settling</h2><p>This door did not answer yet. Return through the Realm Library or try the Realm Atlas.</p><div class="lr75aFooter"><button data-lr75a-act="library">Realm Library</button><button data-lr75a-act="route:atlas">Realm Atlas</button></div></div>'); }
    return renderLibrary();
  }

  function openPracticeRoom(idx){
    // Keep the old one-question material accessible, but frame it as a compact practice room.
    if(has('lrOpenRealLessonByIndex')){
      try{ window.lrOpenRealLessonByIndex(idx); setTimeout(scrubPracticeLabels,0); setTimeout(scrubPracticeLabels,80); return true; }catch(e){}
    }
    if(typeof lrOpenRealLessonByIndex === 'function'){
      try{ lrOpenRealLessonByIndex(idx); setTimeout(scrubPracticeLabels,0); setTimeout(scrubPracticeLabels,80); return true; }catch(e){}
    }
    return renderArchive('all',0);
  }

  function scrubPracticeLabels(){
    var at=byId('actionTitle');
    if(at){
      at.textContent = String(at.textContent||'').replace(/REAL Curriculum|Lesson Bank|Lesson|Test/g,function(x){
        if(/Test/.test(x)) return 'Challenge';
        if(/Lesson/.test(x)) return 'Practice Room';
        return 'Realm Library';
      });
    }
    var root=byId('actionText'); if(!root) return;
    root.querySelectorAll('button').forEach(function(btn){
      btn.textContent = String(btn.textContent||'')
        .replace(/Start Test/g,'Enter challenge')
        .replace(/Back to REAL Curriculum/g,'Back to Realm Library')
        .replace(/Choose Another/g,'Choose another room')
        .replace(/Back to Lesson/g,'Back to practice room');
    });
    root.querySelectorAll('h3').forEach(function(h){
      h.textContent = String(h.textContent||'').replace(/^Lesson$/,'Practice Room').replace(/^Test$/,'Challenge');
    });
  }

  function overrideOldPicker(){
    var oldPicker = window.openRealCurriculumPicker || (typeof openRealCurriculumPicker === 'function' ? openRealCurriculumPicker : null);
    window.__LR75A_OLD_SCROLL_PICKER__ = window.__LR75A_OLD_SCROLL_PICKER__ || oldPicker;
    window.openRealmLibrary75A = function(subject){
      var key = norm(subject || '');
      if(!key || key === 'all') return renderLibrary();
      var wing = SUBJECT_TO_WING[key];
      if(wing) return renderWing(wing);
      return renderLibrary();
    };
    window.openRealCurriculumPicker = function(subject){ return window.openRealmLibrary75A(subject); };
    try{ openRealCurriculumPicker = window.openRealCurriculumPicker; }catch(e){}
    window.openLessonLauncher = window.openLessonLauncher || function(){ return renderLibrary(); };
    try{ lrStartCleanLesson = function(){ return renderLibrary(); }; }catch(e){}
  }

  function wrapRouters(){
    if(window.__LR75A_ROUTERS_WRAPPED__) return;
    window.__LR75A_ROUTERS_WRAPPED__ = true;
    var oldX = window.lr74xRoute;
    if(typeof oldX === 'function'){
      window.lr74xRoute = function(act){
        var n = norm(act);
        if(n === 'learn' || n === 'golearn' || n === 'curriculum' || n === 'scrollshelf' || n === 'realcurriculum') return renderLibrary();
        return oldX.apply(this, arguments);
      };
      try{ lr74xRoute = window.lr74xRoute; }catch(e){}
    }
  }

  function bind(){
    if(window.__LR75A_BOUND__) return;
    window.__LR75A_BOUND__ = true;
    window.addEventListener('click', function(ev){
      var el = ev.target && ev.target.closest ? ev.target.closest('[data-lr75a-act]') : null;
      if(!el) return;
      ev.preventDefault();
      /* 7.6W: do not swallow normal clicks */
      route(el.getAttribute('data-lr75a-act'));
    }, true);
  }

  function installStyles(){
    if(byId('lr75aRealmLibraryStyles')) return;
    var st=document.createElement('style'); st.id='lr75aRealmLibraryStyles';
    st.textContent = `
      .lr75aLibrary{font-family:inherit;color:#f7ecd0;display:grid;gap:14px;max-width:1120px;margin:0 auto;}
      .lr75aHero{display:grid;grid-template-columns:auto 1fr;gap:14px;align-items:center;padding:16px;border:1px solid rgba(244,209,134,.35);border-radius:18px;background:linear-gradient(135deg,rgba(70,38,12,.92),rgba(20,47,43,.88));box-shadow:0 18px 40px rgba(0,0,0,.32), inset 0 1px 0 rgba(255,255,255,.08);}
      .lr75aHeroIcon{width:58px;height:58px;border-radius:17px;display:grid;place-items:center;font-size:2rem;background:rgba(255,240,190,.13);border:1px solid rgba(255,231,165,.36);box-shadow:inset 0 0 18px rgba(255,221,135,.08);}
      .lr75aHero h2{margin:0 0 5px;color:#fff5cf;letter-spacing:.03em;text-shadow:0 2px 0 rgba(0,0,0,.35);}
      .lr75aHero p{margin:0;line-height:1.5;color:#e9dcc0;}
      .lr75aHero small{display:block;margin-top:8px;color:#aee8d0;font-weight:800;letter-spacing:.04em;text-transform:uppercase;}
      .lr75aWingGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:12px;}
      .lr75aDoorGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px;}
      .lr75aWingCard,.lr75aDoorCard,.lr75aMiniScroll{cursor:pointer;text-align:left;color:#f7ecd0;border:1px solid rgba(244,209,134,.30);border-radius:16px;background:linear-gradient(145deg,rgba(14,31,31,.94),rgba(47,31,18,.92));box-shadow:0 10px 24px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.07);transition:transform .12s ease,border-color .12s ease,background .12s ease;}
      .lr75aWingCard:hover,.lr75aDoorCard:hover,.lr75aMiniScroll:hover{transform:translateY(-1px);border-color:rgba(255,230,153,.62);background:linear-gradient(145deg,rgba(21,47,44,.96),rgba(70,43,18,.96));}
      .lr75aWingCard{display:grid;grid-template-columns:auto 1fr auto;gap:12px;padding:14px;align-items:center;}
      .lr75aDoorCard{display:grid;grid-template-columns:auto 1fr auto;gap:12px;padding:14px;align-items:start;min-height:132px;}
      .lr75aBigIcon,.lr75aDoorIcon{width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:rgba(255,236,176,.12);border:1px solid rgba(255,232,166,.28);font-size:1.6rem;}
      .lr75aWingCard b,.lr75aDoorCard b,.lr75aMiniScroll b{display:block;color:#fff2bd;font-size:1.02rem;margin-bottom:3px;}
      .lr75aWingCard small,.lr75aDoorCard small,.lr75aMiniScroll small{display:block;color:#aee8d0;font-size:.74rem;text-transform:uppercase;letter-spacing:.05em;font-weight:900;margin-bottom:6px;}
      .lr75aWingCard p,.lr75aDoorCard p,.lr75aMiniScroll p{margin:0;color:#dcccae;line-height:1.42;font-size:.92rem;}
      .lr75aWingCard i,.lr75aDoorCard i{font-style:normal;color:#ffe49c;font-weight:900;align-self:center;white-space:nowrap;}
      .lr75aFooter{display:flex;flex-wrap:wrap;gap:10px;padding:12px;border:1px solid rgba(244,209,134,.24);border-radius:14px;background:rgba(0,0,0,.22);}
      .lr75aFooter button{border:1px solid rgba(255,232,166,.34);border-radius:999px;background:rgba(255,231,165,.12);color:#fff3cf;font-weight:900;padding:9px 13px;cursor:pointer;}
      .lr75aArchiveGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;}
      .lr75aMiniScroll{padding:12px;min-height:124px;}
      .lr75aArchive .lr75aHero{background:linear-gradient(135deg,rgba(56,36,18,.94),rgba(36,45,39,.9));}
      .lr75aLibrary .lrCleanLessonWindow,.lr75aLibrary .lrCleanTestWindow{border:1px solid rgba(255,232,166,.28);border-radius:16px;background:rgba(0,0,0,.18);padding:14px;}
      @media(max-width:900px){.lr75aHero{grid-template-columns:1fr}.lr75aWingCard,.lr75aDoorCard{grid-template-columns:1fr}.lr75aBigIcon,.lr75aDoorIcon{width:42px;height:42px}.lr75aWingCard i,.lr75aDoorCard i{justify-self:start}}
    `;
    document.head.appendChild(st);
  }

  function boot(){ installStyles(); overrideOldPicker(); wrapRouters(); bind(); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,120); setTimeout(boot,700); });
})();
