// Curriculum Pack 6B: Geography Foundation Expansion
// Content-only pack. No engine changes.
// Adds geography lessons for Luna, Ava, and Michael.

(function(){
  LR_addLessons("Luna","Geography",[
 {
  "teach": "A map is a picture that shows places.",
  "practice": "A map can show a room, a town, a state, or the world.",
  "q": "What does a map show?",
  "c": [
   "places",
   "songs",
   "tastes"
  ],
  "a": "places"
 },
 {
  "teach": "A globe is a round model of Earth.",
  "practice": "A globe looks like a ball with land and water on it.",
  "q": "What shape is a globe?",
  "c": [
   "flat like paper",
   "round",
   "triangle"
  ],
  "a": "round"
 },
 {
  "teach": "Land is the dry part of Earth.",
  "practice": "Hills, fields, and yards are land.",
  "q": "Which is land?",
  "c": [
   "lake",
   "river",
   "field"
  ],
  "a": "field"
 },
 {
  "teach": "Water covers much of Earth.",
  "practice": "Lakes, rivers, and oceans are water.",
  "q": "Which is water?",
  "c": [
   "river",
   "hill",
   "road"
  ],
  "a": "river"
 },
 {
  "teach": "North is one direction.",
  "practice": "A compass can point north.",
  "q": "Which word is a direction?",
  "c": [
   "table",
   "north",
   "pencil"
  ],
  "a": "north"
 },
 {
  "teach": "South is the opposite of north.",
  "practice": "A map can show north and south.",
  "q": "What is opposite of north?",
  "c": [
   "blue",
   "grass",
   "south"
  ],
  "a": "south"
 },
 {
  "teach": "East and west are directions.",
  "practice": "The sun rises in the east.",
  "q": "Which pair are directions?",
  "c": [
   "east and west",
   "apple and cup",
   "dog and bed"
  ],
  "a": "east and west"
 },
 {
  "teach": "A compass rose shows directions on a map.",
  "practice": "It can show north, south, east, and west.",
  "q": "What shows directions on a map?",
  "c": [
   "sandwich",
   "compass rose",
   "shoelace"
  ],
  "a": "compass rose"
 },
 {
  "teach": "A symbol is a picture that stands for something.",
  "practice": "A star might show a capital city.",
  "q": "What can a map symbol do?",
  "c": [
   "make rain",
   "eat paper",
   "stand for something"
  ],
  "a": "stand for something"
 },
 {
  "teach": "A map key explains symbols.",
  "practice": "If a tree symbol means park, the key tells you.",
  "q": "What explains map symbols?",
  "c": [
   "map key",
   "spoon",
   "cloud"
  ],
  "a": "map key"
 },
 {
  "teach": "A road map can show roads.",
  "practice": "People use road maps to find paths.",
  "q": "What can a road map show?",
  "c": [
   "dreams",
   "roads",
   "noises"
  ],
  "a": "roads"
 },
 {
  "teach": "A town is a place where people live and work.",
  "practice": "A town can have homes, roads, stores, and helpers.",
  "q": "What can a town have?",
  "c": [
   "only oceans",
   "no people",
   "homes and roads"
  ],
  "a": "homes and roads"
 },
 {
  "teach": "A city is usually larger than a town.",
  "practice": "Cities have many buildings and people.",
  "q": "A city is usually...",
  "c": [
   "larger than a town",
   "smaller than a pebble",
   "only water"
  ],
  "a": "larger than a town"
 },
 {
  "teach": "A state is part of a country.",
  "practice": "Kentucky is a state in the United States.",
  "q": "Kentucky is a...",
  "c": [
   "planet",
   "state",
   "river"
  ],
  "a": "state"
 },
 {
  "teach": "A country is a large place with its own government.",
  "practice": "The United States is a country.",
  "q": "The United States is a...",
  "c": [
   "pencil",
   "park bench",
   "country"
  ],
  "a": "country"
 },
 {
  "teach": "A capital city is an important government city.",
  "practice": "Frankfort is the capital of Kentucky.",
  "q": "What is Kentucky's capital?",
  "c": [
   "Frankfort",
   "Ocean Town",
   "Cloud City"
  ],
  "a": "Frankfort"
 },
 {
  "teach": "A border is a line that separates places.",
  "practice": "A state border shows where one state ends and another begins.",
  "q": "What does a border separate?",
  "c": [
   "cookies",
   "places",
   "clouds"
  ],
  "a": "places"
 },
 {
  "teach": "A continent is a very large land area.",
  "practice": "North America is a continent.",
  "q": "What is a continent?",
  "c": [
   "small toy",
   "kind of shoe",
   "large land area"
  ],
  "a": "large land area"
 },
 {
  "teach": "An ocean is a very large body of salt water.",
  "practice": "The Atlantic Ocean is an ocean.",
  "q": "What is an ocean?",
  "c": [
   "large body of salt water",
   "tiny cup",
   "dry hill"
  ],
  "a": "large body of salt water"
 },
 {
  "teach": "A river is moving water.",
  "practice": "A river flows across land.",
  "q": "What does a river do?",
  "c": [
   "sleeps",
   "flows",
   "sits still like a rock"
  ],
  "a": "flows"
 },
 {
  "teach": "A lake is water with land around it.",
  "practice": "A lake is usually not moving like a river.",
  "q": "What is a lake?",
  "c": [
   "a tall mountain",
   "a road sign",
   "water with land around it"
  ],
  "a": "water with land around it"
 },
 {
  "teach": "A mountain is very high land.",
  "practice": "Mountains rise above the land around them.",
  "q": "What is a mountain?",
  "c": [
   "high land",
   "flat paper",
   "deep water"
  ],
  "a": "high land"
 },
 {
  "teach": "A hill is raised land.",
  "practice": "A hill is usually smaller than a mountain.",
  "q": "A hill is usually smaller than a...",
  "c": [
   "cup",
   "mountain",
   "map key"
  ],
  "a": "mountain"
 },
 {
  "teach": "A valley is low land between hills or mountains.",
  "practice": "A river may run through a valley.",
  "q": "What is a valley?",
  "c": [
   "high cloud",
   "round model",
   "low land"
  ],
  "a": "low land"
 },
 {
  "teach": "A forest has many trees.",
  "practice": "Forests are habitats for many animals.",
  "q": "What has many trees?",
  "c": [
   "forest",
   "desert",
   "ocean"
  ],
  "a": "forest"
 },
 {
  "teach": "A desert is very dry land.",
  "practice": "Some deserts are hot, and some are cold.",
  "q": "What is a desert usually like?",
  "c": [
   "full of lakes",
   "dry",
   "always underwater"
  ],
  "a": "dry"
 },
 {
  "teach": "A plain is a large flat area of land.",
  "practice": "Plains may have grass and farms.",
  "q": "What is a plain?",
  "c": [
   "deep ocean",
   "tall tower",
   "flat land"
  ],
  "a": "flat land"
 },
 {
  "teach": "An island is land with water all around it.",
  "practice": "An island is surrounded by water.",
  "q": "What surrounds an island?",
  "c": [
   "water",
   "fences only",
   "mountains only"
  ],
  "a": "water"
 },
 {
  "teach": "A peninsula is land with water on most sides.",
  "practice": "Florida is shaped like a peninsula.",
  "q": "A peninsula has water on...",
  "c": [
   "no sides",
   "most sides",
   "only one corner"
  ],
  "a": "most sides"
 },
 {
  "teach": "Weather is what the air is like today.",
  "practice": "Rainy, sunny, windy, and snowy are weather.",
  "q": "Weather tells what the air is like...",
  "c": [
   "a hundred years ago only",
   "inside a book",
   "today"
  ],
  "a": "today"
 },
 {
  "teach": "Climate is the usual weather of a place over a long time.",
  "practice": "A desert usually has a dry climate.",
  "q": "Climate means usual weather over a...",
  "c": [
   "long time",
   "single minute",
   "snack"
  ],
  "a": "long time"
 },
 {
  "teach": "A habitat is a place where a plant or animal lives.",
  "practice": "A pond can be a habitat.",
  "q": "What is a habitat?",
  "c": [
   "a kind of clock",
   "place where something lives",
   "a map title"
  ],
  "a": "place where something lives"
 },
 {
  "teach": "A resource is something people use.",
  "practice": "Water, trees, and soil can be resources.",
  "q": "Which is a resource?",
  "c": [
   "shadow monster",
   "empty noise",
   "water"
  ],
  "a": "water"
 },
 {
  "teach": "A farm is land where people grow food or raise animals.",
  "practice": "Farms can grow corn or keep cows.",
  "q": "What can farms grow?",
  "c": [
   "food",
   "stars",
   "sidewalks"
  ],
  "a": "food"
 },
 {
  "teach": "A route is a way to go from one place to another.",
  "practice": "A route can show how to get home.",
  "q": "What is a route?",
  "c": [
   "kind of animal",
   "way to go",
   "dry lake"
  ],
  "a": "way to go"
 },
 {
  "teach": "Near means close by.",
  "practice": "The chair is near the table.",
  "q": "What does near mean?",
  "c": [
   "far away",
   "underwater",
   "close by"
  ],
  "a": "close by"
 },
 {
  "teach": "Far means not close.",
  "practice": "A city across the country is far away.",
  "q": "What does far mean?",
  "c": [
   "not close",
   "right beside",
   "inside"
  ],
  "a": "not close"
 },
 {
  "teach": "Above means higher than something.",
  "practice": "A bird can fly above a tree.",
  "q": "What means higher?",
  "c": [
   "below",
   "above",
   "beside"
  ],
  "a": "above"
 },
 {
  "teach": "Below means lower than something.",
  "practice": "A rug is below a table.",
  "q": "What means lower?",
  "c": [
   "above",
   "over",
   "below"
  ],
  "a": "below"
 },
 {
  "teach": "Geography helps us learn where places are.",
  "practice": "It also teaches what places are like.",
  "q": "Geography helps us learn about...",
  "c": [
   "places",
   "only spelling",
   "only music"
  ],
  "a": "places"
 }
]);
  LR_addLessons("Ava","Geography",[
 {
  "teach": "Geography studies places and how people interact with them.",
  "practice": "It includes maps, landforms, climate, resources, and movement.",
  "q": "Geography studies places and...",
  "c": [
   "how people interact with them",
   "only multiplication facts",
   "only spelling rules"
  ],
  "a": "how people interact with them"
 },
 {
  "teach": "Absolute location gives an exact spot.",
  "practice": "Latitude and longitude can give absolute location.",
  "q": "Absolute location gives an...",
  "c": [
   "opinion",
   "exact spot",
   "weather pattern"
  ],
  "a": "exact spot"
 },
 {
  "teach": "Relative location explains where something is compared to another place.",
  "practice": "Kentucky is south of Ohio.",
  "q": "Relative location compares one place to...",
  "c": [
   "a clock",
   "a recipe",
   "another place"
  ],
  "a": "another place"
 },
 {
  "teach": "Latitude lines run east-west and measure north or south.",
  "practice": "The equator is 0 degrees latitude.",
  "q": "Latitude measures north or...",
  "c": [
   "south",
   "east",
   "west only"
  ],
  "a": "south"
 },
 {
  "teach": "Longitude lines run north-south and measure east or west.",
  "practice": "The prime meridian is 0 degrees longitude.",
  "q": "Longitude measures east or...",
  "c": [
   "north only",
   "west",
   "height"
  ],
  "a": "west"
 },
 {
  "teach": "The equator divides Earth into Northern and Southern Hemispheres.",
  "practice": "It is 0 degrees latitude.",
  "q": "The equator is 0 degrees...",
  "c": [
   "longitude",
   "elevation",
   "latitude"
  ],
  "a": "latitude"
 },
 {
  "teach": "The prime meridian divides Earth into Eastern and Western Hemispheres.",
  "practice": "It is 0 degrees longitude.",
  "q": "The prime meridian is 0 degrees...",
  "c": [
   "longitude",
   "latitude",
   "temperature"
  ],
  "a": "longitude"
 },
 {
  "teach": "A map scale shows distance on a map compared to real distance.",
  "practice": "One inch might represent 100 miles.",
  "q": "A map scale helps measure...",
  "c": [
   "temperature",
   "distance",
   "population age"
  ],
  "a": "distance"
 },
 {
  "teach": "A map key explains symbols used on a map.",
  "practice": "A blue line may represent a river.",
  "q": "A map key explains...",
  "c": [
   "weather today",
   "how to vote",
   "symbols"
  ],
  "a": "symbols"
 },
 {
  "teach": "A compass rose shows directions.",
  "practice": "Cardinal directions are north, south, east, and west.",
  "q": "Which is a cardinal direction?",
  "c": [
   "north",
   "inside",
   "near"
  ],
  "a": "north"
 },
 {
  "teach": "Intermediate directions are northeast, northwest, southeast, and southwest.",
  "practice": "They are between the cardinal directions.",
  "q": "Which is an intermediate direction?",
  "c": [
   "upstairs",
   "northeast",
   "middle"
  ],
  "a": "northeast"
 },
 {
  "teach": "A physical map shows natural features.",
  "practice": "Mountains, rivers, plains, and deserts are physical features.",
  "q": "A physical map shows...",
  "c": [
   "only laws",
   "only election results",
   "natural features"
  ],
  "a": "natural features"
 },
 {
  "teach": "A political map shows borders and governments.",
  "practice": "Countries, states, capitals, and cities appear on political maps.",
  "q": "A political map often shows...",
  "c": [
   "borders",
   "soil layers",
   "animal tracks only"
  ],
  "a": "borders"
 },
 {
  "teach": "A thematic map focuses on one topic.",
  "practice": "A population map or climate map is thematic.",
  "q": "A thematic map focuses on...",
  "c": [
   "only roads",
   "one topic",
   "only oceans"
  ],
  "a": "one topic"
 },
 {
  "teach": "A region is an area with common features.",
  "practice": "A region may share climate, landforms, culture, or economy.",
  "q": "A region has common...",
  "c": [
   "shoe sizes",
   "secret names",
   "features"
  ],
  "a": "features"
 },
 {
  "teach": "Physical regions are based on natural features.",
  "practice": "The Appalachian region is connected to mountains.",
  "q": "Physical regions are based on...",
  "c": [
   "natural features",
   "election speeches",
   "store names"
  ],
  "a": "natural features"
 },
 {
  "teach": "Human regions are based on people and culture.",
  "practice": "Language, religion, or economy can help define a human region.",
  "q": "Human regions are based on...",
  "c": [
   "only rivers",
   "people and culture",
   "only clouds"
  ],
  "a": "people and culture"
 },
 {
  "teach": "A landform is a natural shape on Earth's surface.",
  "practice": "Mountains, valleys, plains, and plateaus are landforms.",
  "q": "Which is a landform?",
  "c": [
   "traffic law",
   "library card",
   "mountain"
  ],
  "a": "mountain"
 },
 {
  "teach": "A plateau is high, mostly flat land.",
  "practice": "It is flatter on top than a mountain.",
  "q": "A plateau is high and mostly...",
  "c": [
   "flat",
   "underwater",
   "round like a globe"
  ],
  "a": "flat"
 },
 {
  "teach": "A delta forms where a river drops sediment near its mouth.",
  "practice": "Deltas can have rich soil.",
  "q": "A delta forms near a river's...",
  "c": [
   "source only",
   "mouth",
   "mountaintop"
  ],
  "a": "mouth"
 },
 {
  "teach": "A river source is where a river begins.",
  "practice": "A river mouth is where it empties into another body of water.",
  "q": "Where does a river begin?",
  "c": [
   "mouth",
   "delta",
   "source"
  ],
  "a": "source"
 },
 {
  "teach": "A watershed is an area of land that drains into the same water system.",
  "practice": "Rainwater in a watershed flows toward connected streams and rivers.",
  "q": "A watershed drains into the same...",
  "c": [
   "water system",
   "capital city",
   "desert"
  ],
  "a": "water system"
 },
 {
  "teach": "Elevation means height above sea level.",
  "practice": "Mountains have higher elevation than beaches.",
  "q": "Elevation means height above...",
  "c": [
   "a desk",
   "sea level",
   "a map key"
  ],
  "a": "sea level"
 },
 {
  "teach": "Climate is the usual weather pattern over a long time.",
  "practice": "Temperature and precipitation help describe climate.",
  "q": "Climate is usual weather over a...",
  "c": [
   "single afternoon",
   "minute",
   "long time"
  ],
  "a": "long time"
 },
 {
  "teach": "Weather is short-term conditions in the atmosphere.",
  "practice": "Today's rain is weather, not climate.",
  "q": "Weather is more...",
  "c": [
   "short-term",
   "unchanging forever",
   "only about maps"
  ],
  "a": "short-term"
 },
 {
  "teach": "Natural resources are materials from nature that people use.",
  "practice": "Water, timber, coal, oil, soil, and minerals can be resources.",
  "q": "Which is a natural resource?",
  "c": [
   "plastic toy name",
   "timber",
   "street address"
  ],
  "a": "timber"
 },
 {
  "teach": "Renewable resources can be replaced naturally over time.",
  "practice": "Trees can be renewable if managed well.",
  "q": "A renewable resource can be...",
  "c": [
   "used only once forever",
   "made only by laws",
   "replaced naturally"
  ],
  "a": "replaced naturally"
 },
 {
  "teach": "Nonrenewable resources are limited and form very slowly.",
  "practice": "Coal and oil are nonrenewable.",
  "q": "Which is nonrenewable?",
  "c": [
   "coal",
   "sunlight",
   "wind"
  ],
  "a": "coal"
 },
 {
  "teach": "Population density means how many people live in an area.",
  "practice": "A city usually has higher density than farmland.",
  "q": "Population density tells how many people live in...",
  "c": [
   "one family only",
   "an area",
   "a river"
  ],
  "a": "an area"
 },
 {
  "teach": "Urban means city-like.",
  "practice": "Urban areas usually have many buildings and people.",
  "q": "Urban areas are connected to...",
  "c": [
   "empty deserts only",
   "deep oceans",
   "cities"
  ],
  "a": "cities"
 },
 {
  "teach": "Rural means countryside-like.",
  "practice": "Rural areas often have farms, forests, or small communities.",
  "q": "Rural areas are connected to...",
  "c": [
   "countryside",
   "large city centers",
   "airports only"
  ],
  "a": "countryside"
 },
 {
  "teach": "Suburban areas are between urban and rural in many ways.",
  "practice": "They often have homes near a city.",
  "q": "Suburban areas are often near...",
  "c": [
   "the moon",
   "a city",
   "only oceans"
  ],
  "a": "a city"
 },
 {
  "teach": "Migration means people moving from one place to another.",
  "practice": "People may migrate for jobs, safety, family, or land.",
  "q": "Migration means people...",
  "c": [
   "stand still forever",
   "draw maps only",
   "move from one place to another"
  ],
  "a": "move from one place to another"
 },
 {
  "teach": "Push factors make people leave a place.",
  "practice": "War, job loss, or drought can be push factors.",
  "q": "A push factor makes people...",
  "c": [
   "leave",
   "stay forever",
   "sleep"
  ],
  "a": "leave"
 },
 {
  "teach": "Pull factors attract people to a place.",
  "practice": "Jobs, safety, or family can be pull factors.",
  "q": "A pull factor attracts people...",
  "c": [
   "away from all maps",
   "to a place",
   "into the ocean"
  ],
  "a": "to a place"
 },
 {
  "teach": "Trade is the exchange of goods and services.",
  "practice": "Places trade because resources are not spread evenly.",
  "q": "Trade means exchanging goods and...",
  "c": [
   "mountains",
   "latitudes",
   "services"
  ],
  "a": "services"
 },
 {
  "teach": "Transportation routes connect places.",
  "practice": "Roads, rivers, railroads, ports, and airports help movement.",
  "q": "Which is a transportation route?",
  "c": [
   "railroad",
   "hilltop only",
   "map legend"
  ],
  "a": "railroad"
 },
 {
  "teach": "A port is a place where ships load and unload.",
  "practice": "Ports help trade across water.",
  "q": "What happens at a port?",
  "c": [
   "courts make laws",
   "ships load and unload",
   "clouds form maps"
  ],
  "a": "ships load and unload"
 },
 {
  "teach": "A time zone is a region that uses the same standard time.",
  "practice": "Earth's rotation helps explain time zones.",
  "q": "A time zone shares the same...",
  "c": [
   "climate",
   "elevation",
   "standard time"
  ],
  "a": "standard time"
 },
 {
  "teach": "A hemisphere is half of Earth.",
  "practice": "The Northern Hemisphere is north of the equator.",
  "q": "A hemisphere is...",
  "c": [
   "half of Earth",
   "a city",
   "a landform"
  ],
  "a": "half of Earth"
 },
 {
  "teach": "The United States is in North America.",
  "practice": "North America is a continent.",
  "q": "The United States is on which continent?",
  "c": [
   "Australia",
   "North America",
   "Antarctica"
  ],
  "a": "North America"
 },
 {
  "teach": "Kentucky is in the southeastern/central part of the United States.",
  "practice": "It borders several states and contains varied landforms.",
  "q": "Kentucky is part of the...",
  "c": [
   "Pacific Ocean",
   "Sahara Desert",
   "United States"
  ],
  "a": "United States"
 },
 {
  "teach": "Frankfort is Kentucky's capital city.",
  "practice": "A capital is an important government city.",
  "q": "Kentucky's capital is...",
  "c": [
   "Frankfort",
   "Nashville",
   "Cincinnati"
  ],
  "a": "Frankfort"
 },
 {
  "teach": "The Ohio River forms part of Kentucky's northern border.",
  "practice": "Rivers can be natural borders.",
  "q": "Which river borders northern Kentucky?",
  "c": [
   "Nile River",
   "Ohio River",
   "Amazon River"
  ],
  "a": "Ohio River"
 },
 {
  "teach": "The Appalachian Mountains extend into eastern Kentucky.",
  "practice": "This region has mountains and valleys.",
  "q": "Eastern Kentucky is connected to the...",
  "c": [
   "Rocky Mountains only",
   "Sahara Desert",
   "Appalachian Mountains"
  ],
  "a": "Appalachian Mountains"
 },
 {
  "teach": "A barrier can make movement harder.",
  "practice": "Mountains, deserts, and oceans can be barriers.",
  "q": "Which can be a physical barrier?",
  "c": [
   "mountain range",
   "postcard",
   "calendar"
  ],
  "a": "mountain range"
 },
 {
  "teach": "A corridor makes movement easier.",
  "practice": "A river valley or road can act as a corridor.",
  "q": "A corridor makes movement...",
  "c": [
   "impossible",
   "easier",
   "unrelated"
  ],
  "a": "easier"
 },
 {
  "teach": "Human-environment interaction means people affect and are affected by places.",
  "practice": "Building roads changes land, and climate affects farming.",
  "q": "Human-environment interaction studies people and...",
  "c": [
   "only planets",
   "only spelling",
   "places"
  ],
  "a": "places"
 },
 {
  "teach": "Adaptation means changing behavior to fit the environment.",
  "practice": "People may build different homes in hot, cold, wet, or dry places.",
  "q": "Adaptation means changing to fit the...",
  "c": [
   "environment",
   "alphabet",
   "clock"
  ],
  "a": "environment"
 },
 {
  "teach": "Modification means people change the environment.",
  "practice": "Building dams, roads, and farms modifies land.",
  "q": "Modification means people change the...",
  "c": [
   "direction names",
   "environment",
   "prime meridian"
  ],
  "a": "environment"
 }
]);
  LR_addLessons("Michael","Geography",[
 {
  "teach": "Geography studies spatial patterns, places, environments, and human activity.",
  "practice": "Geographers ask where things are, why they are there, and how places connect.",
  "q": "Geography studies spatial patterns and...",
  "c": [
   "human activity",
   "only grammar",
   "only multiplication"
  ],
  "a": "human activity"
 },
 {
  "teach": "Absolute location gives a precise position, often using latitude and longitude.",
  "practice": "Coordinates can identify a place on Earth.",
  "q": "Absolute location is usually...",
  "c": [
   "vague",
   "precise",
   "only emotional"
  ],
  "a": "precise"
 },
 {
  "teach": "Relative location explains location by comparison.",
  "practice": "Kentucky is east of Missouri and south of Ohio.",
  "q": "Relative location describes a place compared with...",
  "c": [
   "a recipe",
   "a ruler only",
   "another place"
  ],
  "a": "another place"
 },
 {
  "teach": "Latitude measures distance north or south of the equator.",
  "practice": "Latitude lines are parallels.",
  "q": "Latitude measures north or south of the...",
  "c": [
   "equator",
   "prime meridian",
   "International Date Line"
  ],
  "a": "equator"
 },
 {
  "teach": "Longitude measures distance east or west of the prime meridian.",
  "practice": "Longitude lines are meridians.",
  "q": "Longitude measures east or west of the...",
  "c": [
   "equator",
   "prime meridian",
   "Arctic Circle"
  ],
  "a": "prime meridian"
 },
 {
  "teach": "The equator divides Earth into Northern and Southern Hemispheres.",
  "practice": "It is the zero-degree latitude line.",
  "q": "The equator is a line of...",
  "c": [
   "longitude",
   "elevation",
   "latitude"
  ],
  "a": "latitude"
 },
 {
  "teach": "The prime meridian divides Earth into Eastern and Western Hemispheres.",
  "practice": "It is the zero-degree longitude line.",
  "q": "The prime meridian is a line of...",
  "c": [
   "longitude",
   "latitude",
   "rainfall"
  ],
  "a": "longitude"
 },
 {
  "teach": "A projection is a way to show the round Earth on a flat map.",
  "practice": "All flat map projections distort something.",
  "q": "A map projection turns Earth into a...",
  "c": [
   "court case",
   "flat map",
   "weather system"
  ],
  "a": "flat map"
 },
 {
  "teach": "Map distortion can affect shape, area, distance, or direction.",
  "practice": "No flat world map is perfect.",
  "q": "Flat maps can distort...",
  "c": [
   "only spelling",
   "civic duties",
   "area and shape"
  ],
  "a": "area and shape"
 },
 {
  "teach": "GIS means Geographic Information Systems.",
  "practice": "GIS uses digital layers to analyze spatial data.",
  "q": "GIS helps analyze...",
  "c": [
   "spatial data",
   "poems only",
   "court testimony only"
  ],
  "a": "spatial data"
 },
 {
  "teach": "A physical map emphasizes natural features.",
  "practice": "Landforms, rivers, elevation, and water bodies are physical features.",
  "q": "A physical map emphasizes...",
  "c": [
   "political parties",
   "natural features",
   "only capital cities"
  ],
  "a": "natural features"
 },
 {
  "teach": "A political map emphasizes human boundaries and government units.",
  "practice": "Countries, states, capitals, and borders are political features.",
  "q": "A political map emphasizes...",
  "c": [
   "soil color only",
   "weather today",
   "boundaries"
  ],
  "a": "boundaries"
 },
 {
  "teach": "A thematic map shows one topic or pattern.",
  "practice": "Population density, climate, and resources can be shown thematically.",
  "q": "A thematic map focuses on...",
  "c": [
   "one topic",
   "all details equally",
   "only roads"
  ],
  "a": "one topic"
 },
 {
  "teach": "Scale affects how much detail a map shows.",
  "practice": "A local map can show streets; a world map shows broader patterns.",
  "q": "Map scale affects...",
  "c": [
   "citizenship status",
   "detail",
   "temperature only"
  ],
  "a": "detail"
 },
 {
  "teach": "A region is an area unified by common characteristics.",
  "practice": "Regions may be physical, cultural, economic, or political.",
  "q": "Regions are defined by common...",
  "c": [
   "shoe sizes",
   "random guesses",
   "characteristics"
  ],
  "a": "characteristics"
 },
 {
  "teach": "A formal region has a shared measurable trait.",
  "practice": "A state, country, or climate zone can be a formal region.",
  "q": "A formal region has a shared...",
  "c": [
   "measurable trait",
   "rumor",
   "single road sign"
  ],
  "a": "measurable trait"
 },
 {
  "teach": "A functional region is organized around a central point or activity.",
  "practice": "A metro area around a city can be a functional region.",
  "q": "A functional region is organized around a...",
  "c": [
   "mountain shape only",
   "central point",
   "random border"
  ],
  "a": "central point"
 },
 {
  "teach": "A perceptual region is based on people's ideas or feelings about a place.",
  "practice": "The 'Midwest' or 'the South' can be perceptual depending on context.",
  "q": "A perceptual region is based on...",
  "c": [
   "exact coordinates only",
   "one law",
   "people's ideas"
  ],
  "a": "people's ideas"
 },
 {
  "teach": "Physical geography examines natural systems.",
  "practice": "Climate, landforms, water, soils, and ecosystems are physical geography topics.",
  "q": "Physical geography focuses on...",
  "c": [
   "natural systems",
   "election law only",
   "grammar rules"
  ],
  "a": "natural systems"
 },
 {
  "teach": "Human geography examines people, culture, economies, settlement, and movement.",
  "practice": "It asks how humans use and shape places.",
  "q": "Human geography focuses on...",
  "c": [
   "only rivers",
   "people and culture",
   "only planets"
  ],
  "a": "people and culture"
 },
 {
  "teach": "A watershed is land that drains into a common water system.",
  "practice": "Watersheds help explain river networks and water quality.",
  "q": "A watershed drains into a common...",
  "c": [
   "city hall",
   "desert dune",
   "water system"
  ],
  "a": "water system"
 },
 {
  "teach": "River systems shape settlement and trade.",
  "practice": "Rivers can provide water, transportation, and fertile land.",
  "q": "Rivers often support settlement because they provide...",
  "c": [
   "water and transportation",
   "only mountains",
   "no resources"
  ],
  "a": "water and transportation"
 },
 {
  "teach": "A delta forms where sediment is deposited near a river's mouth.",
  "practice": "Deltas can support farming but may flood.",
  "q": "A delta forms near a river's...",
  "c": [
   "source",
   "mouth",
   "highest peak"
  ],
  "a": "mouth"
 },
 {
  "teach": "Erosion moves soil and rock from one place to another.",
  "practice": "Water, wind, and ice can cause erosion.",
  "q": "Erosion moves...",
  "c": [
   "laws",
   "votes",
   "soil and rock"
  ],
  "a": "soil and rock"
 },
 {
  "teach": "Deposition drops sediment in a new location.",
  "practice": "River deltas are formed by deposition.",
  "q": "Deposition drops...",
  "c": [
   "sediment",
   "temperature",
   "population"
  ],
  "a": "sediment"
 },
 {
  "teach": "Tectonic activity helps form mountains, earthquakes, and volcanoes.",
  "practice": "Plate boundaries are often active areas.",
  "q": "Tectonic activity is linked to...",
  "c": [
   "ballots",
   "mountains and earthquakes",
   "time zones"
  ],
  "a": "mountains and earthquakes"
 },
 {
  "teach": "Climate is long-term weather patterns in a place.",
  "practice": "Temperature and precipitation are major climate factors.",
  "q": "Climate is long-term...",
  "c": [
   "court decisions",
   "map symbols",
   "weather patterns"
  ],
  "a": "weather patterns"
 },
 {
  "teach": "Weather is short-term atmospheric condition.",
  "practice": "A thunderstorm today is weather.",
  "q": "Weather is...",
  "c": [
   "short-term",
   "unchanging",
   "a political border"
  ],
  "a": "short-term"
 },
 {
  "teach": "Orographic effect happens when mountains influence rainfall.",
  "practice": "Air rises over mountains, cools, and may drop precipitation.",
  "q": "Mountains can influence...",
  "c": [
   "voting age",
   "rainfall",
   "longitude only"
  ],
  "a": "rainfall"
 },
 {
  "teach": "Rain shadow areas are drier areas on the leeward side of mountains.",
  "practice": "Mountains can block moist air.",
  "q": "A rain shadow is usually...",
  "c": [
   "underwater",
   "a city law",
   "drier"
  ],
  "a": "drier"
 },
 {
  "teach": "Natural resources influence settlement and economies.",
  "practice": "Coal, timber, soil, and water can affect where people live and work.",
  "q": "Resources can influence settlement and...",
  "c": [
   "economies",
   "alphabet order",
   "jury size"
  ],
  "a": "economies"
 },
 {
  "teach": "Renewable resources can be replenished naturally if managed well.",
  "practice": "Forests, sunlight, wind, and water cycles can be renewable.",
  "q": "A renewable resource can be...",
  "c": [
   "formed only once ever",
   "replenished naturally",
   "a border"
  ],
  "a": "replenished naturally"
 },
 {
  "teach": "Nonrenewable resources form slowly and are limited.",
  "practice": "Coal, oil, and natural gas are nonrenewable.",
  "q": "Which is nonrenewable?",
  "c": [
   "sunlight",
   "wind",
   "natural gas"
  ],
  "a": "natural gas"
 },
 {
  "teach": "Population density measures people per unit of area.",
  "practice": "High density usually means many people in a small area.",
  "q": "Population density measures people per...",
  "c": [
   "unit of area",
   "court case",
   "river only"
  ],
  "a": "unit of area"
 },
 {
  "teach": "Carrying capacity is the number of people or organisms an environment can support.",
  "practice": "Resources and technology affect carrying capacity.",
  "q": "Carrying capacity refers to what an environment can...",
  "c": [
   "spell",
   "support",
   "vote"
  ],
  "a": "support"
 },
 {
  "teach": "Urbanization is the growth of cities.",
  "practice": "Industrial jobs and services can attract people to cities.",
  "q": "Urbanization is growth of...",
  "c": [
   "oceans",
   "mountain height",
   "cities"
  ],
  "a": "cities"
 },
 {
  "teach": "Suburbanization is growth around cities.",
  "practice": "Suburbs often develop along roads and commuting routes.",
  "q": "Suburbanization occurs around...",
  "c": [
   "cities",
   "volcanoes only",
   "deserts only"
  ],
  "a": "cities"
 },
 {
  "teach": "Rural areas usually have lower population density.",
  "practice": "They may include farms, forests, small towns, and open land.",
  "q": "Rural areas usually have lower...",
  "c": [
   "elevation always",
   "population density",
   "latitude"
  ],
  "a": "population density"
 },
 {
  "teach": "Migration is movement from one place to another.",
  "practice": "Migration can be voluntary or forced.",
  "q": "Migration is movement between...",
  "c": [
   "paragraphs only",
   "clock hands",
   "places"
  ],
  "a": "places"
 },
 {
  "teach": "Push factors drive people away from a place.",
  "practice": "Conflict, famine, lack of jobs, or disasters can be push factors.",
  "q": "Push factors encourage people to...",
  "c": [
   "leave",
   "stay",
   "draw maps"
  ],
  "a": "leave"
 },
 {
  "teach": "Pull factors attract people to a place.",
  "practice": "Jobs, safety, family, or opportunity can be pull factors.",
  "q": "Pull factors attract people...",
  "c": [
   "away only",
   "to a place",
   "into rivers"
  ],
  "a": "to a place"
 },
 {
  "teach": "Diffusion is the spread of ideas, goods, or culture.",
  "practice": "Technology and trade can speed diffusion.",
  "q": "Diffusion means...",
  "c": [
   "erosion only",
   "border drawing",
   "spread"
  ],
  "a": "spread"
 },
 {
  "teach": "Trade routes connect places and move goods, people, and ideas.",
  "practice": "Rivers, roads, railroads, ports, and sea lanes can be trade routes.",
  "q": "Trade routes move goods and...",
  "c": [
   "ideas",
   "mountains",
   "latitudes"
  ],
  "a": "ideas"
 },
 {
  "teach": "A chokepoint is a narrow passage important for movement or trade.",
  "practice": "Canals, straits, and mountain passes can be chokepoints.",
  "q": "A chokepoint is a narrow...",
  "c": [
   "climate zone",
   "passage",
   "city law"
  ],
  "a": "passage"
 },
 {
  "teach": "Interdependence means places rely on each other.",
  "practice": "One region may produce food while another manufactures tools.",
  "q": "Interdependence means places...",
  "c": [
   "never trade",
   "are all identical",
   "rely on each other"
  ],
  "a": "rely on each other"
 },
 {
  "teach": "Globalization increases connections across regions.",
  "practice": "Trade, communication, migration, and technology can increase globalization.",
  "q": "Globalization increases...",
  "c": [
   "connections",
   "isolation only",
   "elevation"
  ],
  "a": "connections"
 },
 {
  "teach": "Infrastructure includes systems that support movement and services.",
  "practice": "Roads, bridges, ports, power lines, and water systems are infrastructure.",
  "q": "Which is infrastructure?",
  "c": [
   "rain cloud",
   "bridge",
   "latitude"
  ],
  "a": "bridge"
 },
 {
  "teach": "Site means the physical characteristics of a place.",
  "practice": "A city site may include rivers, hills, or soil.",
  "q": "Site describes physical...",
  "c": [
   "opinions",
   "election dates",
   "characteristics"
  ],
  "a": "characteristics"
 },
 {
  "teach": "Situation means a place's location relative to other places.",
  "practice": "A port city may have a useful situation for trade.",
  "q": "Situation describes location relative to...",
  "c": [
   "other places",
   "only elevation",
   "one building"
  ],
  "a": "other places"
 },
 {
  "teach": "Settlement patterns show where people live.",
  "practice": "People often settle near water, resources, transportation, or jobs.",
  "q": "Settlement patterns show where people...",
  "c": [
   "vote only",
   "live",
   "draw maps"
  ],
  "a": "live"
 },
 {
  "teach": "Cultural landscape means visible human changes to the land.",
  "practice": "Farms, roads, towns, and monuments are cultural landscape features.",
  "q": "Cultural landscape shows human...",
  "c": [
   "rainfall only",
   "longitude",
   "changes to land"
  ],
  "a": "changes to land"
 },
 {
  "teach": "A political boundary separates government areas.",
  "practice": "Country and state borders are political boundaries.",
  "q": "Political boundaries separate...",
  "c": [
   "government areas",
   "weather systems",
   "river sources"
  ],
  "a": "government areas"
 },
 {
  "teach": "A natural boundary uses a physical feature.",
  "practice": "A river or mountain range can be a natural boundary.",
  "q": "A natural boundary may use a...",
  "c": [
   "ballot",
   "river",
   "capital building"
  ],
  "a": "river"
 },
 {
  "teach": "A geometric boundary is often a straight line drawn by latitude, longitude, or survey.",
  "practice": "Some borders follow straight lines.",
  "q": "A geometric boundary often looks...",
  "c": [
   "like a river always",
   "invisible to maps",
   "straight"
  ],
  "a": "straight"
 },
 {
  "teach": "A capital city often serves as a center of government.",
  "practice": "Frankfort is Kentucky's capital.",
  "q": "A capital city is important for...",
  "c": [
   "government",
   "erosion",
   "rainfall"
  ],
  "a": "government"
 },
 {
  "teach": "Kentucky's location affects its history and economy.",
  "practice": "Rivers, mountains, farmland, and routes shape settlement and work.",
  "q": "Kentucky's rivers and landforms affect settlement and...",
  "c": [
   "grammar",
   "economy",
   "moon phases"
  ],
  "a": "economy"
 },
 {
  "teach": "The Ohio River has been important for Kentucky movement and trade.",
  "practice": "Rivers helped connect inland places to larger markets.",
  "q": "The Ohio River helped Kentucky with movement and...",
  "c": [
   "volcanoes",
   "latitude lines",
   "trade"
  ],
  "a": "trade"
 },
 {
  "teach": "Eastern Kentucky is part of the Appalachian region.",
  "practice": "Mountains influenced settlement, transportation, and resource use.",
  "q": "Eastern Kentucky is connected with the...",
  "c": [
   "Appalachian region",
   "Sahara region",
   "Andes only"
  ],
  "a": "Appalachian region"
 },
 {
  "teach": "The Bluegrass region is known for rolling land and pasture.",
  "practice": "Regions can be named by physical and cultural features.",
  "q": "The Bluegrass region is associated with...",
  "c": [
   "desert dunes",
   "rolling land and pasture",
   "tropical rainforest"
  ],
  "a": "rolling land and pasture"
 },
 {
  "teach": "Human-environment interaction includes dependence, adaptation, and modification.",
  "practice": "People depend on resources, adapt to climate, and modify land.",
  "q": "Human-environment interaction includes dependence, adaptation, and...",
  "c": [
   "spelling",
   "legislation only",
   "modification"
  ],
  "a": "modification"
 },
 {
  "teach": "A geographic question often asks where, why there, and why it matters.",
  "practice": "Good geography connects location to cause and effect.",
  "q": "A strong geographic question asks where and...",
  "c": [
   "why it matters",
   "who won a spelling bee",
   "what color only"
  ],
  "a": "why it matters"
 }
]);
})();
