/* LearningRealms 7.5I - Sidebar Button Route Repair
   Built on 7.5H. Conservative polish only.
   Goals:
   - Keep left sidebar buttons inside the sidebar at common desktop widths.
   - Stop known legacy sidebar/menu buttons from opening the wrong old surfaces.
   - Route major visible subject/living-world buttons through one stable doorway map.
   - Do not rewrite the shell, lessons, saves, living-world systems, or content.
*/
(function(){
  'use strict';
  if(window.__LR75I_SIDEBAR_BUTTON_ROUTE_REPAIR__) return;
  window.__LR75I_SIDEBAR_BUTTON_ROUTE_REPAIR__ = true;

  function byId(id){ return document.getElementById(id); }
  function q(sel, root){ try{ return (root||document).querySelector(sel); }catch(e){ return null; } }
  function qa(sel, root){ try{ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }catch(e){ return []; } }
  function has(fn){ return typeof window[fn] === 'function'; }
  function norm(v){ return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,''); }
  function esc(v){ return String(v == null ? '' : v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;'); }
  function closePopups(){ try{ if(has('lrClosePopup')) window.lrClosePopup(); }catch(e){} try{ var r=byId('lrPopupRoot'); if(r) r.classList.add('hidden'); }catch(e){} }
  function call(fn){
    var args=Array.prototype.slice.call(arguments,1);
    if(!has(fn)) return false;
    try{ window[fn].apply(window,args); return true; }
    catch(e){ console.warn('LR75I route failed:',fn,e); return false; }
  }
  function first(list){
    for(var i=0;i<list.length;i++){
      var x=list[i];
      if(Array.isArray(x)){ if(call.apply(null,x)) return true; }
      else if(call(x)) return true;
    }
    return false;
  }
  function note(title, body){
    installStyles();
    var html='<div class="lr75iNote"><h3>'+esc(title||'Doorway')+'</h3><p>'+esc(body||'This path is being held safely instead of doing nothing.')+'</p><div><button data-lr75i-route="library">🏛️ Realm Library</button><button data-lr75i-route="scene">↩ Scene</button></div></div>';
    if(has('lrOpenPopup')){ try{ window.lrOpenPopup(title||'Doorway', html); return true; }catch(e){} }
    var at=byId('actionTitle'), ax=byId('actionText');
    if(at) at.textContent=title||'Doorway';
    if(ax) ax.innerHTML=html;
    return true;
  }

  function openLibrary(wing){
    closePopups();
    wing = wing || 'all';
    if(has('openRealmLibrary75B')) return window.openRealmLibrary75B(wing);
    if(has('openRealmLibrary75A')) return window.openRealmLibrary75A(wing);
    if(has('openRealCurriculumPicker')) return window.openRealCurriculumPicker(wing);
    return note('Realm Library','The library doorway is present, but the route hook did not answer. Try the Scene button or reload this build.');
  }

  var ROUTE_MAP = {
    library:function(){ return openLibrary('all'); },
    atlas:function(){ return openLibrary('all'); },
    worldatlas:function(){ return openLibrary('all'); },
    golearn:function(){ return openLibrary('all'); },
    core:function(){ return openLibrary('core'); },
    corehalls:function(){ return openLibrary('core'); },
    science:function(){ return openLibrary('science'); },
    sciencequarter:function(){ return openLibrary('science'); },
    history:function(){ return openLibrary('history'); },
    historywing:function(){ return openLibrary('history'); },
    bible:function(){ return openLibrary('bible'); },
    bibleroad:function(){ return openLibrary('bible'); },
    creative:function(){ return openLibrary('creative'); },
    creativequarter:function(){ return openLibrary('creative'); },
    homestead:function(){ return openLibrary('homestead'); },
    homesteadworkshop:function(){ return openLibrary('homestead'); },
    scene:function(){ closePopups(); return first([['renderRoom']]) || note('Scene','The scene window did not answer.'); },

    egypt:function(){ closePopups(); return first([['openAncientEgyptCourse'],['openAncientEgyptTrail'],['openLearningRealmsEgyptRoad'],['openLearningRealmsEgypt']]) || openLibrary('history'); },
    egyptroyal:function(){ closePopups(); return first([['openAncientEgyptRoyalGallery'],['openAncientEgyptRoyalCourse']]) || ROUTE_MAP.egypt(); },
    egyptworld:function(){ closePopups(); return first([['openAncientEgyptWorldExpansion'],['openAncientEgyptWorldCourse']]) || ROUTE_MAP.egypt(); },
    england:function(){ closePopups(); return first([['openEnglandKingsQueens74Q'],['openEnglandKingsQueensRoad74Q']]) || openLibrary('history'); },
    kingsqueens:function(){ return ROUTE_MAP.england(); },
    depression:function(){ closePopups(); return first([['openGreatDepressionTrail'],['openGreatDepressionCourse']]) || openLibrary('history'); },
    greatdepression:function(){ return ROUTE_MAP.depression(); },
    wildwest:function(){ closePopups(); return first([['openWildWestTrail'],['openWildWestCourse']]) || openLibrary('history'); },
    shipwreck:function(){ closePopups(); return first([['shipwreckGuidedZoneOpen'],['openShipwreckCoveMap'],['openShipwreckCoveDeepCourse']]) || openLibrary('history'); },
    shipwreckcove:function(){ return ROUTE_MAP.shipwreck(); },
    geography:function(){ closePopups(); return first([['openMapmakersLoft74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history'); },
    civics:function(){ closePopups(); return first([['openCivicHall74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history'); },
    economics:function(){ closePopups(); return first([['openMarketSquare74P'],['openHistoryWorldSupportAdventure74P']]) || openLibrary('history'); },

    scienceexpedition:function(){ closePopups(); return first([['openScienceEngineeringAdventure74M'],['openScienceEngineeringQuarter74M']]) || openLibrary('science'); },
    inventions:function(){ closePopups(); return first([['openInventionsEngineeringMaster74R'],['openInventionsEngineeringDisasters74R'],['openInventionsDeepCourse']]) || openLibrary('science'); },
    engineering:function(){ return ROUTE_MAP.inventions(); },
    aerospace:function(){ closePopups(); return first([['openAerospaceEngineering74S'],['openAerospaceMissionWing74S'],['openAerospaceEngineering']]) || openLibrary('science'); },
    nature:function(){ closePopups(); return first([['openNatureHealthDeepAdventure'],['openNatureHealth74T'],['openNatureAndHealth']]) || openLibrary('science'); },
    naturehealth:function(){ return ROUTE_MAP.nature(); },
    weather:function(){ closePopups(); return first([['openWeatherStormLab74U'],['openWeatherStormLab'],['openWeatherStation']]) || openLibrary('science'); },
    animals:function(){ closePopups(); return first([['openAnimalKingdom74V'],['openAnimalKingdom'],['openCreatureFieldGuide']]) || openLibrary('science'); },
    animal:function(){ return ROUTE_MAP.animals(); },
    creatures:function(){ return ROUTE_MAP.animals(); },

    reading:function(){ closePopups(); return first([['openReadingComprehensionMasterCourse75C'],['openReadingComprehensionMasterCourse']]) || openLibrary('core'); },
    writing:function(){ closePopups(); return first([['openWritingCompositionMasterCourse'],['openWritingCompositionMaster74W']]) || openLibrary('core'); },
    math:function(){ closePopups(); return first([['openMathAdventureMasterCourse75D'],['openMathAdventureMasterCourse']]) || openLibrary('core'); },
    logic:function(){ closePopups(); return first([['openLogicTowerCriticalThinking75E'],['openLogicTowerMasterCourse']]) || openLibrary('core'); },
    grammar:function(){ closePopups(); return first([['openGrammarVocabularyLanguageForge75F'],['openGrammarMasterCourse']]) || openLibrary('core'); },
    vocabulary:function(){ return ROUTE_MAP.grammar(); },
    languageforge:function(){ return ROUTE_MAP.grammar(); },

    living:function(){ closePopups(); return first([['openLivingWorldLedger74L'],['lr75hRoute','living']]) || note('Town Notice Board','The living-world ledger route is protected, but the older hook did not answer.'); },
    townnotice:function(){ return ROUTE_MAP.living(); },
    navqa:function(){ closePopups(); return first([['openNavigationLedger75H'],['lr75hRoute','navqa']]) || note('Navigation Ledger','The route checker is not available in this branch.'); },
    merchants:function(){ closePopups(); return first([['lr74lRoute','merchants'],['lr75hRoute','system:merchants'],['openShopHub'],['lr69OpenMerchantSquare']]) || ROUTE_MAP.living(); },
    shops:function(){ return ROUTE_MAP.merchants(); },
    rare:function(){ closePopups(); return first([['lr74lRoute','rare'],['lr75hRoute','system:rare'],['openShopHub']]) || ROUTE_MAP.merchants(); },
    companions:function(){ closePopups(); return first([['openCompanionDen'],['openCompanionPopup'],['openPetJournal'],['lr75hRoute','system:companions']]) || ROUTE_MAP.living(); },
    pets:function(){ return ROUTE_MAP.companions(); },
    collections:function(){ closePopups(); return first([['openCollectionLog'],['openInventoryPopup'],['openAchievementJournal'],['lr75hRoute','system:collections']]) || ROUTE_MAP.living(); },
    items:function(){ return ROUTE_MAP.collections(); },
    quests:function(){ closePopups(); return first([['openQuestBoard'],['openDailyQuestBoard'],['openQuestJournal'],['openStoryQuestJournal'],['lr75hRoute','system:quests']]) || ROUTE_MAP.living(); },
    home:function(){ closePopups(); return first([['openHomeRenderer'],['openHomeViewPopup'],['openHomeView'],['openVisibleHome'],['openHomeRooms'],['lr75hRoute','home']]) || openLibrary('homestead'); },
    seasons:function(){ closePopups(); return first([['openSeasonHall'],['openSeasonalCalendar'],['openSeasonQuests'],['lr75hRoute','system:seasons']]) || ROUTE_MAP.living(); },
    events:function(){ closePopups(); return first([['openEventLog'],['openStoryCampaigns'],['lr75hRoute','system:events']]) || ROUTE_MAP.living(); },
    birthday:function(){ closePopups(); return first([['openParentRewardVault'],['openRewardCodeRedeemer'],['lr75hRoute','system:birthday']]) || ROUTE_MAP.living(); }
  };

  function route(key){
    key = norm(key);
    if(ROUTE_MAP[key]) return ROUTE_MAP[key]();
    if(has('lr74xRoute')){ try{ return window.lr74xRoute(key); }catch(e){} }
    return openLibrary('all');
  }

  window.lr75iRoute = route;

  // Keep a few old global buttons from opening stale pre-library surfaces.
  var oldFns = {};
  ['openWorldAtlas','openAtlasPopup','openLearningRealmsRealmAtlas74K','openLearningRealmsRealmAtlas','openRealmAtlas'].forEach(function(name){ if(has(name)) oldFns[name]=window[name]; });
  window.__LR75I_OLD_NAV_FUNCS__ = window.__LR75I_OLD_NAV_FUNCS__ || oldFns;
  window.openWorldAtlas = function(){ return route('library'); };
  window.openAtlasPopup = function(){ return route('library'); };
  window.openRealmAtlas = function(){ return route('library'); };
  try{ openWorldAtlas=window.openWorldAtlas; openAtlasPopup=window.openAtlasPopup; openRealmAtlas=window.openRealmAtlas; }catch(e){}

  var LABELS = [
    [/^open world atlas$/i,'library'],[/^world atlas$/i,'library'],[/^world directory$/i,'library'],[/^realm atlas$/i,'library'],[/^realm library$/i,'library'],[/^go learn$/i,'library'],
    [/^navigation ledger$/i,'navqa'],[/^button audit$/i,'navqa'],[/^town notice board$/i,'living'],[/^living world ledger$/i,'living'],
    [/^merchant row$/i,'merchants'],[/^shop hub$/i,'merchants'],[/^shops$/i,'merchants'],[/^rare finds( shelf)?$/i,'rare'],[/^companion den$/i,'companions'],[/^companions?$/i,'companions'],[/^pets$/i,'companions'],[/^treasure registry$/i,'collections'],[/^collection log$/i,'collections'],[/^collections$/i,'collections'],[/^items$/i,'collections'],[/^quest board$/i,'quests'],[/^quests$/i,'quests'],[/^travel home$/i,'home'],[/^home hearth$/i,'home'],[/^home$/i,'home'],[/^seasons$/i,'seasons'],[/^festival board$/i,'seasons'],[/^town chronicle$/i,'events'],[/^event log$/i,'events'],[/^birthday chest$/i,'birthday'],
    [/^core halls$/i,'core'],[/^science and engineering quarter$/i,'science'],[/^science quarter$/i,'science'],[/^history and world wing$/i,'history'],[/^history wing$/i,'history'],[/^bible road$/i,'bible'],[/^creative quarter$/i,'creative'],[/^homestead workshop$/i,'homestead'],
    [/^ancient egypt( expedition)?$/i,'egypt'],[/^egypt road$/i,'egypt'],[/^egypt royal gallery$/i,'egyptroyal'],[/^egypt world expansion$/i,'egyptworld'],[/^england: kings and queens( road)?$/i,'england'],[/^england kings and queens$/i,'england'],[/^kings and queens$/i,'england'],[/^great depression( history street)?$/i,'depression'],[/^wild west( frontier trail)?$/i,'wildwest'],[/^shipwreck cove$/i,'shipwreck'],[/^mapmaker.?s loft$/i,'geography'],[/^civic hall$/i,'civics'],[/^market square$/i,'economics'],
    [/^science and engineering expedition$/i,'scienceexpedition'],[/^inventions.*engineering/i,'inventions'],[/^aerospace( engineering)?( mission wing)?$/i,'aerospace'],[/^nature.*health/i,'nature'],[/^weather.*storm/i,'weather'],[/^animal kingdom/i,'animals'],[/^creature field guide$/i,'animals'],
    [/^reading comprehension/i,'reading'],[/^writing composition/i,'writing'],[/^math adventure/i,'math'],[/^logic tower/i,'logic'],[/^grammar.*vocabulary/i,'grammar'],[/^language forge$/i,'grammar'],[/^scene$/i,'scene'],[/^return to scene$/i,'scene']
  ];
  function routeForText(txt){
    txt = String(txt||'').replace(/\s+/g,' ').trim().replace(/[›»]+$/,'').trim();
    txt = txt.replace(/^[^A-Za-z0-9𓂀✝️]+/,'').trim();
    for(var i=0;i<LABELS.length;i++){ if(LABELS[i][0].test(txt)) return LABELS[i][1]; }
    return '';
  }
  function hasDataRoute(btn){
    if(!btn) return false;
    var attrs=btn.attributes||[];
    for(var i=0;i<attrs.length;i++) if(/^data-lr/i.test(attrs[i].name)) return true;
    return false;
  }
  function shouldOverrideKnownLegacy(btn, routeKey){
    if(!routeKey) return false;
    var text=(btn.textContent||'').replace(/\s+/g,' ').trim();
    if(/^(Open World Atlas|World Atlas|World Directory|Realm Atlas|Shop Hub|Travel Home)$/i.test(text)) return true;
    if(/^(Core Halls|History and World Wing|Science and Engineering Quarter|Bible Road|Creative Quarter|Homestead Workshop)$/i.test(text)) return true;
    if(/^(Ancient Egypt|Egypt Road|England: Kings and Queens|Great Depression|Wild West|Shipwreck Cove)$/i.test(text)) return true;
    return false;
  }
  function scanButtons(root){
    root = root || document;
    qa('button', root).forEach(function(btn){
      if(!btn || btn.disabled) return;
      var key=routeForText(btn.textContent||'');
      if(!key) return;
      if(hasDataRoute(btn) && !btn.getAttribute('data-lr75i-route')) return; // respect course-specific buttons
      if(btn.getAttribute('data-lr75i-route')===key) return;
      if(!btn.getAttribute('onclick') || shouldOverrideKnownLegacy(btn,key)){
        try{ btn.onclick=null; }catch(e){}
        btn.setAttribute('data-lr75i-route',key);
        btn.classList.add('lr75iRoutedButton');
      }
    });
  }
  function scanSidebarOnly(){ var b=byId('leftActionButtons'); if(b) scanButtons(b); }

  function installStyles(){
    if(byId('lr75iStyles')) return;
    var st=document.createElement('style'); st.id='lr75iStyles';
    st.textContent = `
      main{grid-template-columns:minmax(260px,360px) minmax(0,1fr) minmax(250px,320px)!important;gap:14px!important;max-width:100%!important;}
      .actionSidebar{width:auto!important;min-width:0!important;max-width:360px!important;overflow:hidden!important;}
      .rightSidebar{width:auto!important;min-width:0!important;max-width:320px!important;overflow:hidden!important;}
      .main{min-width:0!important;max-width:100%!important;overflow:visible!important;}
      #leftActionButtons,.actionButtons,.lrActionGroup,.lrTravelPanel,.lrMiniMap{min-width:0!important;max-width:100%!important;overflow:hidden!important;}
      #leftActionButtons button,.actionSidebar button,.lrActionGroup button,.lrTravelPanel button,.lr75iRoutedButton{display:block!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;line-height:1.18!important;text-align:left!important;padding:8px 10px!important;}
      .lrTravelLabel,.lrTravelLabel select,.actionSidebar select{max-width:100%!important;width:100%!important;min-width:0!important;box-sizing:border-box!important;white-space:normal!important;}
      .lrMiniMapExits,.lrMiniMapHere,.lrMapCaption,.lrActionGroupTitle{overflow-wrap:anywhere!important;}
      .lr75iRoutedButton{outline:1px solid rgba(174,232,208,.20)!important;}
      .lr75iNote{padding:14px;border:1px solid rgba(244,209,134,.28);border-radius:16px;background:rgba(18,32,29,.92);color:#f7ecd0;}.lr75iNote h3{margin-top:0;color:#ffe6a7}.lr75iNote div{display:flex;gap:8px;flex-wrap:wrap}.lr75iNote button{width:auto!important;text-align:center!important;}
      @media(max-width:1260px){main{grid-template-columns:minmax(230px,310px) minmax(0,1fr) minmax(220px,285px)!important}.actionSidebar{max-width:310px!important}.rightSidebar{max-width:285px!important}body{font-size:18px!important}}
      @media(max-width:980px){main{display:block!important}.actionSidebar,.rightSidebar,.playerSidebar{max-width:none!important;width:auto!important;min-width:0!important;position:relative!important}.shell{width:min(1000px,96vw)!important}}
    `;
    document.head.appendChild(st);
  }

  function wrapRenderers(){
    if(window.__LR75I_RENDERERS_WRAPPED__) return;
    window.__LR75I_RENDERERS_WRAPPED__=true;
    if(typeof window.renderLeftActions==='function'){
      var oldLeft=window.renderLeftActions;
      window.renderLeftActions=function(){ var out=oldLeft.apply(this,arguments); setTimeout(function(){ installStyles(); scanSidebarOnly(); },0); setTimeout(scanSidebarOnly,80); return out; };
      try{ renderLeftActions=window.renderLeftActions; }catch(e){}
    }
    if(typeof window.renderRoom==='function'){
      var oldRoom=window.renderRoom;
      window.renderRoom=function(){ var out=oldRoom.apply(this,arguments); setTimeout(function(){ installStyles(); scanButtons(document); },80); return out; };
      try{ renderRoom=window.renderRoom; }catch(e){}
    }
    ['openRealmLibrary75A','openRealmLibrary75B','lrOpenPopup','lrOpenActionPopup','openLivingWorldLedger74L'].forEach(function(name){
      if(!has(name) || window[name].__lr75iWrapped) return;
      var old=window[name];
      var wrapped=function(){ var out=old.apply(this,arguments); setTimeout(function(){ installStyles(); scanButtons(document); },60); setTimeout(function(){ scanButtons(document); },220); return out; };
      wrapped.__lr75iWrapped=true; window[name]=wrapped; try{ eval(name+' = window["'+name+'"]'); }catch(e){}
    });
  }

  function bind(){
    if(window.__LR75I_BOUND__) return;
    window.__LR75I_BOUND__=true;
    window.addEventListener('click', function(ev){
      var el=ev.target && ev.target.closest ? ev.target.closest('[data-lr75i-route]') : null;
      if(!el) return;
      ev.preventDefault(); /* 7.6W: do not swallow normal clicks */
      route(el.getAttribute('data-lr75i-route'));
      setTimeout(function(){ scanButtons(document); },100);
    }, true);
  }

  function boot(){
    installStyles(); bind(); wrapRenderers(); scanButtons(document);
    setTimeout(function(){ installStyles(); scanButtons(document); },180);
    setTimeout(function(){ scanButtons(document); },800);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  window.addEventListener('load', function(){ setTimeout(boot,120); });
})();
