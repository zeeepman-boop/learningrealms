// Question Mountain Phase 10 - Geography Civics Economics Deepening II
(function(){
if(typeof LR_addLessons!=="function") return;

LR_addLessons("Luna","Geography",[
{teach:"North is a direction.",q:"North is a...",c:["direction","animal","season"],a:"direction"},
{teach:"Oceans hold water.",q:"Oceans contain...",c:["water","books","coins"],a:"water"},
{teach:"Maps use symbols.",q:"Maps use...",c:["symbols","songs","stories"],a:"symbols"},
{teach:"Communities have helpers.",q:"Helpers serve the...",c:["community","forest","mountain"],a:"community"},
{teach:"Needs are important things.",q:"Food is a...",c:["need","want","toy"],a:"need"}
]);

LR_addLessons("Ava","Geography",[
{teach:"Regions can share climate.",q:"Regions may share...",c:["climate","titles","equations"],a:"climate"},
{teach:"Trade moves goods.",q:"Trade moves...",c:["goods","clouds","fonts"],a:"goods"},
{teach:"Citizens follow laws.",q:"Citizens follow...",c:["laws","weather","maps"],a:"laws"},
{teach:"Supply affects markets.",q:"Supply affects...",c:["markets","chapters","songs"],a:"markets"},
{teach:"Resources vary by place.",q:"Resources vary by...",c:["location","color","time"],a:"location"}
]);

LR_addLessons("Michael","Economics",[
{teach:"Demand influences markets.",q:"Demand affects...",c:["markets","weather","titles"],a:"markets"},
{teach:"Citizens participate in communities.",q:"Citizens can...",c:["participate","hibernate","float"],a:"participate"},
{teach:"Imports move goods in.",q:"Imports bring goods...",c:["in","out","away"],a:"in"},
{teach:"Exports move goods out.",q:"Exports send goods...",c:["out","in","up"],a:"out"},
{teach:"Budgets help planning.",q:"Budgets help...",c:["planning","weathering","mapping"],a:"planning"}
]);
})();