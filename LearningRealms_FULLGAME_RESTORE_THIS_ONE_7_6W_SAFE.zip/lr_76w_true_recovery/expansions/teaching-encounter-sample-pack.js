// Teaching Encounter Sample Pack v1
// Small rich-format sample lessons using miniLesson, workedExample, and guidedPractice.
// Old lessons still work. These just prove the richer teaching flow.

LR_addLessons("Luna","Math",[
 {unit:"G1-MATH-FACTS",skill:"make ten",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Making ten helps you add faster.",
  workedExample:"8 + 7 can be changed into 10 + 5. Take 2 from the 7 and give it to 8. Now 8 becomes 10, and 7 becomes 5.",
  guidedPractice:"Ask: What does 8 need to become 10?",
  q:"8 needs how many more to make 10?",
  c:["2","3","7"],a:"2",
  explain:"8 + 2 = 10, so taking 2 from the 7 helps make ten first."}
]);

LR_addLessons("Ava","Math",[
 {unit:"G7-MATH-EQ",skill:"two-step equations",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"A two-step equation is solved by undoing operations in reverse order.",
  workedExample:"For 3x + 5 = 20, subtract 5 first to get 3x = 15. Then divide by 3 to get x = 5.",
  guidedPractice:"Find what is added or subtracted first, then undo it.",
  q:"3x + 5 = 20. What should you do first?",
  c:["subtract 5","divide by 5","add 20"],a:"subtract 5",
  explain:"Subtracting 5 from both sides leaves 3x = 15, then division solves x."}
]);

LR_addLessons("Michael","Math",[
 {unit:"G8-MATH-FUNC",skill:"slope",difficulty:"teaching",mode:"guided lesson",
  miniLesson:"Slope tells how fast a line rises or falls.",
  workedExample:"From (1,2) to (3,8), y changes from 2 to 8, so y changes by 6. x changes from 1 to 3, so x changes by 2. Slope is 6 ÷ 2 = 3.",
  guidedPractice:"Find change in y first, then change in x.",
  q:"What is the slope from (1,2) to (3,8)?",
  c:["3","6","2"],a:"3",
  explain:"The change in y is 6 and the change in x is 2, so 6 divided by 2 equals 3."}
]);
