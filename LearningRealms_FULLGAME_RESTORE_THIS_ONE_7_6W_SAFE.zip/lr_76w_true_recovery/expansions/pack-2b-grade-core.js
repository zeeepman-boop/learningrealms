// Curriculum Pack 2B: Grade Core Expansion
// Curriculum-only expansion. No engine changes.

LR_addLessons("Luna","Reading",[
 {teach:"A CVC word has consonant, vowel, consonant.",practice:"cat, dog, sun",q:"Which is a CVC word?",c:["cat","tree","cake"],a:"cat"},
 {teach:"A final e can make the vowel say its name.",practice:"cap becomes cape.",q:"Which word has final e?",c:["cape","cap","cat"],a:"cape"},
 {teach:"A blend keeps both sounds.",practice:"bl in black says /b/ and /l/.",q:"Which word starts with BL?",c:["black","chair","ship"],a:"black"},
 {teach:"FL is a blend in flag.",practice:"flag, flat, flip",q:"Which word starts with FL?",c:["flag","then","ship"],a:"flag"},
 {teach:"GR is a blend in green.",practice:"green, grass, grow",q:"Which starts with GR?",c:["grass","fish","owl"],a:"grass"},
 {teach:"The main character is the most important character.",practice:"The rabbit solved the problem.",q:"Who is usually most important?",c:["main character","page number","period"],a:"main character"},
 {teach:"A problem is what goes wrong in a story.",practice:"The bridge broke.",q:"In a story, the problem is what...",c:["goes wrong","ends the page","names the author"],a:"goes wrong"},
 {teach:"A solution fixes the problem.",practice:"They repaired the bridge.",q:"A solution...",c:["fixes the problem","starts the title","counts coins"],a:"fixes the problem"}
]);

LR_addLessons("Luna","English",[
 {teach:"An adjective describes a noun.",practice:"silver owl, tall tree",q:"Which word describes?",c:["silver","owl","ran"],a:"silver"},
 {teach:"A plural noun means more than one.",practice:"cat becomes cats.",q:"Which means more than one?",c:["cats","cat","run"],a:"cats"},
 {teach:"Use I when talking about yourself.",practice:"I can read.",q:"Which sentence is correct?",c:["I can read.","i can read.","Me can read."],a:"I can read."},
 {teach:"A period ends a telling sentence.",practice:"The fox ran.",q:"What ends this sentence?",c:[".","?","!"],a:"."}
]);

LR_addLessons("Luna","Math",[
 {teach:"Doubles are facts like 4 + 4.",practice:"4 + 4 = 8.",q:"4 + 4 = ?",c:["8","7","9"],a:"8"},
 {teach:"Near doubles help with adding.",practice:"5 + 6 is one more than 5 + 5.",q:"5 + 6 = ?",c:["11","10","12"],a:"11"},
 {teach:"Ten frames help show numbers.",practice:"A full ten frame shows 10.",q:"A full ten frame shows...",c:["10","5","20"],a:"10"},
 {teach:"A quarter hour is 15 minutes.",practice:"15 minutes after 2:00 is 2:15.",q:"A quarter hour is...",c:["15 minutes","10 minutes","25 minutes"],a:"15 minutes"},
 {teach:"A cube is a solid shape.",practice:"A dice can look like a cube.",q:"Which is a solid shape?",c:["cube","circle","line"],a:"cube"},
 {teach:"Compare numbers using greater than and less than.",practice:"9 is greater than 6.",q:"Which is greater?",c:["9","6","same"],a:"9"},
 {teach:"Skip counting by 5 helps count nickels.",practice:"5, 10, 15, 20.",q:"What comes after 15 when counting by 5?",c:["20","16","25"],a:"20"},
 {teach:"Fact families use related addition and subtraction facts.",practice:"3 + 4 = 7 and 7 - 4 = 3.",q:"Which fact belongs with 3 + 4 = 7?",c:["7 - 4 = 3","8 + 1 = 9","5 - 2 = 3"],a:"7 - 4 = 3"}
]);

LR_addLessons("Ava","Math",[
 {teach:"Dividing by a fraction can be done by multiplying by its reciprocal.",practice:"6 ÷ 1/2 = 6 × 2.",q:"6 ÷ 1/2 = ?",c:["12","3","6"],a:"12"},
 {teach:"Combining like terms means adding terms with the same variable part.",practice:"3x + 5x = 8x.",q:"3x + 5x = ?",c:["8x","15x","8"],a:"8x"},
 {teach:"Two-step equations need inverse operations in reverse order.",practice:"2x + 3 = 11. Subtract 3, then divide by 2.",q:"2x + 3 = 11. x = ?",c:["4","7","14"],a:"4"},
 {teach:"A proportional graph goes through the origin.",practice:"y = 3x passes through 0,0.",q:"A proportional graph passes through...",c:["origin","only x=5","no points"],a:"origin"},
 {teach:"Percent change compares the amount of change to the original amount.",practice:"Increase from 50 to 60 is 10 out of 50.",q:"Change from 50 to 60 is an increase of...",c:["20%","10%","5%"],a:"20%"},
 {teach:"The circumference of a circle is the distance around it.",practice:"It is like the perimeter of a circle.",q:"Circumference means...",c:["distance around circle","middle point","inside area"],a:"distance around circle"},
 {teach:"A scale factor tells how much a figure is enlarged or reduced.",practice:"Scale factor 2 doubles lengths.",q:"Scale factor 2 makes lengths...",c:["double","half","unchanged"],a:"double"},
 {teach:"The mode is the value that appears most often.",practice:"2, 3, 3, 4 has mode 3.",q:"Mode of 2, 3, 3, 4?",c:["3","2","4"],a:"3"}
]);

LR_addLessons("Ava","English",[
 {teach:"A strong answer explains evidence instead of only quoting it.",practice:"Quote plus explanation.",q:"After giving evidence, a writer should...",c:["explain it","ignore it","erase it"],a:"explain it"},
 {teach:"A narrator's perspective can shape how events are described.",practice:"One character may see things differently.",q:"Perspective affects...",c:["how events are described","only page numbers","division"],a:"how events are described"},
 {teach:"Tone is the author's attitude toward a subject.",practice:"Words can sound serious, funny, or worried.",q:"Tone means author's...",c:["attitude","address","font"],a:"attitude"},
 {teach:"A root word carries the main meaning.",practice:"helpful has root help.",q:"Root of helpful?",c:["help","ful","he"],a:"help"},
 {teach:"A prefix comes before a root word.",practice:"replay has prefix re.",q:"In replay, the prefix is...",c:["re","play","lay"],a:"re"},
 {teach:"A suffix comes after a root word.",practice:"careless has suffix less.",q:"In careless, the suffix is...",c:["less","care","car"],a:"less"}
]);

LR_addLessons("Ava","Science",[
 {teach:"A consumer gets energy by eating other organisms.",practice:"A fox eating a rabbit is a consumer.",q:"A consumer gets energy by...",c:["eating","photosynthesis","freezing"],a:"eating"},
 {teach:"A decomposer breaks down dead material.",practice:"Fungi can decompose logs.",q:"A decomposer breaks down...",c:["dead material","paragraphs","fractions"],a:"dead material"},
 {teach:"The water cycle includes evaporation, condensation, and precipitation.",practice:"Water moves through air and land.",q:"Which is part of the water cycle?",c:["evaporation","punctuation","election"],a:"evaporation"},
 {teach:"A force is a push or pull.",practice:"Pushing a cart applies force.",q:"A force is a...",c:["push or pull","claim","theme"],a:"push or pull"},
 {teach:"Balanced forces do not change motion.",practice:"Equal pushes cancel out.",q:"Balanced forces cause...",c:["no change in motion","constant speeding","melting"],a:"no change in motion"},
 {teach:"Unbalanced forces can change motion.",practice:"A stronger push moves an object.",q:"Unbalanced forces can change...",c:["motion","spelling","government"],a:"motion"}
]);

LR_addLessons("Michael","Math",[
 {teach:"Distribute before combining like terms.",practice:"3(x + 2) = 3x + 6.",q:"3(x + 2) = ?",c:["3x + 6","x + 6","3x + 2"],a:"3x + 6"},
 {teach:"Solve equations by keeping both sides balanced.",practice:"Subtract the same amount from both sides.",q:"Equation solving keeps sides...",c:["balanced","random","unequal"],a:"balanced"},
 {teach:"A function rule can generate ordered pairs.",practice:"y = 2x gives (1,2), (2,4).",q:"y = 2x when x=3 gives y...",c:["6","5","2"],a:"6"},
 {teach:"The y-intercept is the value of y when x is 0.",practice:"In y = 5x + 2, y-intercept is 2.",q:"In y = 5x + 2, y-intercept is...",c:["2","5","7"],a:"2"},
 {teach:"Parallel lines have the same slope.",practice:"Two lines with slope 3 are parallel if different intercepts.",q:"Parallel lines have same...",c:["slope","length","x-value only"],a:"slope"},
 {teach:"The volume of a cylinder uses pi times radius squared times height.",practice:"V = πr²h.",q:"Cylinder volume uses radius...",c:["squared","doubled only","ignored"],a:"squared"},
 {teach:"Scatter plots show relationships between two variables.",practice:"Height and arm span can be plotted.",q:"Scatter plots compare...",c:["two variables","one spelling word","only claims"],a:"two variables"},
 {teach:"A trend line shows the general pattern of data.",practice:"It runs through the middle of a scatter cloud.",q:"Trend line shows...",c:["general pattern","only one point","the title"],a:"general pattern"}
]);

LR_addLessons("Michael","English",[
 {teach:"Relevant evidence directly supports the claim.",practice:"Use proof that matches the point.",q:"Relevant evidence must...",c:["support the claim","change the topic","be random"],a:"support the claim"},
 {teach:"Reasoning explains how evidence proves the claim.",practice:"Because this quote shows courage, the claim is stronger.",q:"Reasoning connects evidence to...",c:["claim","weather","volume"],a:"claim"},
 {teach:"Formal writing avoids casual slang.",practice:"Use clear academic language.",q:"Formal writing avoids...",c:["slang","evidence","paragraphs"],a:"slang"},
 {teach:"A thesis states the main argument.",practice:"The essay will prove this point.",q:"A thesis states the...",c:["main argument","page count","font"],a:"main argument"},
 {teach:"Transitions guide readers between ideas.",practice:"however, therefore, meanwhile",q:"Which is a transition?",c:["therefore","table","oxygen"],a:"therefore"},
 {teach:"Research notes should track source information.",practice:"Record author and title.",q:"Research notes should track...",c:["sources","shoe size","weather only"],a:"sources"}
]);

LR_addLessons("Michael","Science",[
 {teach:"An element is made of one kind of atom.",practice:"Gold is an element.",q:"An element has one kind of...",c:["atom","paragraph","government"],a:"atom"},
 {teach:"A molecule forms when atoms bond together.",practice:"Oxygen gas has bonded oxygen atoms.",q:"Molecules are made of bonded...",c:["atoms","sentences","maps"],a:"atoms"},
 {teach:"Newton's second law connects force, mass, and acceleration.",practice:"F = ma.",q:"Newton's second law is...",c:["F = ma","V = lwh","y = mx+b"],a:"F = ma"},
 {teach:"Thermal energy relates to particle motion.",practice:"Warmer particles move more.",q:"Thermal energy relates to particle...",c:["motion","citizenship","grammar"],a:"motion"},
 {teach:"Conduction transfers heat through direct contact.",practice:"A spoon heats in soup.",q:"Heat through direct contact is...",c:["conduction","radiation only","erosion"],a:"conduction"},
 {teach:"Radiation transfers energy through waves.",practice:"Sunlight warms Earth.",q:"Sunlight warming Earth is...",c:["radiation","friction","condensation"],a:"radiation"}
]);

LR_addLessons("Michael","History",[
 {teach:"A federal system shares power between levels of government.",practice:"National and state governments both have roles.",q:"Federalism shares power between...",c:["levels of government","food chains","atoms"],a:"levels of government"},
 {teach:"The Bill of Rights lists important individual freedoms.",practice:"Speech and religion are protected.",q:"The Bill of Rights protects...",c:["freedoms","weather","slope"],a:"freedoms"},
 {teach:"Opportunity cost is what you give up when choosing one option.",practice:"Choosing time to study means giving up other time.",q:"Opportunity cost means what you...",c:["give up","multiply","evaporate"],a:"give up"},
 {teach:"A historical claim needs evidence from reliable sources.",practice:"Use documents, records, and artifacts.",q:"Historical claims need...",c:["evidence","guessing","decoration"],a:"evidence"},
 {teach:"Chronology is the order events happened.",practice:"First, second, third.",q:"Chronology means...",c:["time order","mass","theme"],a:"time order"},
 {teach:"Cause and effect help explain why events happened and what changed after.",practice:"A tax led to protest.",q:"Cause and effect explain why and...",c:["what changed","how to spell","circle area"],a:"what changed"}
]);
