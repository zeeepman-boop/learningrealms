/* LearningRealms Egypt Button Stability 7.4Y
   Tiny repair on top of 7.4X.
   The old 7.4B/7.4C Egypt visibility scripts styled/injected the same Egypt button
   that 7.3P rewrites, causing a rapid visual blink. This script only stabilizes
   existing Egypt controls and removes duplicate Egypt buttons if any remain.
*/
(function(){
  'use strict';
  if(window.__LR74Y_EGYPT_BUTTON_STABILITY__) return;
  window.__LR74Y_EGYPT_BUTTON_STABILITY__ = true;

  function byId(id){ return document.getElementById(id); }
  function qa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }

  function installStyles(){
    if(byId('lr74yEgyptButtonStabilityStyles')) return;
    var st=document.createElement('style');
    st.id='lr74yEgyptButtonStabilityStyles';
    st.textContent = `
      [data-lr73p-act="egypt"],
      [data-lr73p-act="ancientegypt"],
      [data-lr74b-act="egypt"],
      [data-lr74c-act="egypt"]{
        animation:none!important;
        transition:filter .12s ease, transform .08s ease!important;
      }
      #leftActionButtons [data-lr73p-act="egypt"]{
        border-color:rgba(255,231,150,.46)!important;
      }
    `;
    document.head.appendChild(st);
  }

  function isEgyptButton(el){
    if(!el || !el.matches) return false;
    var act=(el.getAttribute('data-lr73p-act')||el.getAttribute('data-lr74b-act')||el.getAttribute('data-lr74c-act')||'').toLowerCase();
    var txt=(el.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
    return act==='egypt' || act==='ancientegypt' || /egypt road|ancient egypt expedition/.test(txt);
  }

  function normalizeContainer(root){
    if(!root) return;
    var buttons=qa('button', root).filter(isEgyptButton);
    if(buttons.length <= 1) return;
    var keep=buttons[0];
    if(!keep.getAttribute('data-lr73p-act')) keep.setAttribute('data-lr73p-act','egypt');
    buttons.slice(1).forEach(function(b){ try{ b.remove(); }catch(e){} });
  }

  function normalize(){
    installStyles();
    normalizeContainer(byId('leftActionButtons'));
    normalizeContainer(document.querySelector('.lr73mTopNav'));
    normalizeContainer(document.querySelector('.lr73mIconRack'));
    normalizeContainer(document.querySelector('.lr73pIconRack'));
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', normalize); else normalize();
  window.addEventListener('load', function(){ setTimeout(normalize,120); setTimeout(normalize,700); });
})();
