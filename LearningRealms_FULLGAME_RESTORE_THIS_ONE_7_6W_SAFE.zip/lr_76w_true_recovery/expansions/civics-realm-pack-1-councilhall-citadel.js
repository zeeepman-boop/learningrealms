// Civics Realm Pack 1: Councilhall Citadel
// Adds a dedicated Civics realm with law/council/courtroom flavor.
// Adds starter Civics grade-ladder lessons, rewards, portfolio prompts, grade targets, and boss seeds.
// Uses existing lesson/portfolio/boss systems. Minimal engine risk.

(function(){
  const ROOMS = window.LR_ROOMS = window.LR_ROOMS || {};

  const civicsRooms = {
    councilRoad1:{
      title:"Banner Road",
      zone:"Councilhall Road",
      text:"A clean stone road leads away from the town square beneath tall banners marked with scales, keys, lanterns, and open books. Every banner seems to represent a rule, a right, or a responsibility.",
      exits:{west:"townSquare",east:"councilRoad2"}
    },
    councilRoad2:{
      title:"Citizen Steps",
      zone:"Councilhall Road",
      text:"Wide shallow steps climb toward a walled citadel. Bronze plaques along the railings describe fairness, service, honesty, order, and courage.",
      exits:{west:"councilRoad1",east:"councilGate"}
    },
    councilGate:{
      title:"Councilhall Gate",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"A tall gate stands open beneath a carved stone motto: Good rules protect good people. A friendly guard waves learners inside and points toward the chambers of law, service, debate, and judgment.",
      npc:{name:"Gatewarden Brindle",desc:"A kind old gatewarden with a polished badge and a patient voice.",text:"Brindle taps his badge. 'Civics begins with one question: how do people live well together?'"},
      exits:{west:"councilRoad2",east:"citizenSquare",south:"lawLibrary"}
    },
    citizenSquare:{
      title:"Citizen Square",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"A bright square opens inside the citadel. Citizens gather around notice boards, service booths, public maps, and a fountain shaped like joined hands.",
      npc:{name:"Mira the Town Clerk",desc:"Mira keeps careful records of rules, services, and civic duties.",text:"Mira smiles. 'A citizen has rights, but also responsibilities. Both matter.'"},
      exits:{west:"councilGate",east:"debateHall",south:"serviceMarket"}
    },
    lawLibrary:{
      title:"Law Library",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"Tall shelves hold law scrolls, charters, town records, and old case books. Golden dust floats in the quiet air. A carved owl watches from a reading desk.",
      npc:{name:"Archivist Quill",desc:"A careful scribe who teaches rules, laws, sources, and founding documents.",text:"Archivist Quill whispers, 'A law is not just words. It shapes what people may do, must do, and must not do.'"},
      exits:{north:"councilGate",east:"serviceMarket",south:"courtOfFairness"}
    },
    serviceMarket:{
      title:"Public Service Market",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"This busy courtyard is filled with models of roads, wells, lamps, bridges, gardens, and safety towers. Signs explain how public services help a community.",
      npc:{name:"Foreman Pike",desc:"A practical worker who teaches taxes, roads, safety, and public goods.",text:"Pike lifts a tiny bridge model. 'A community works better when people help maintain the things everyone uses.'"},
      exits:{north:"citizenSquare",west:"lawLibrary",east:"votingGarden",south:"courtOfFairness"}
    },
    debateHall:{
      title:"Debate Hall",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"Rows of benches face two speaking stands. The walls are painted with scenes of respectful disagreement, evidence, listening, and fair decisions.",
      npc:{name:"Counselor Venn",desc:"A calm debate teacher who insists on reasons, evidence, and respectful listening.",text:"Venn raises one finger. 'A loud claim is not a strong claim. Bring reasons. Bring evidence. Listen before answering.'"},
      exits:{west:"citizenSquare",south:"votingGarden"}
    },
    votingGarden:{
      title:"Voting Garden",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"A peaceful garden holds stone ballot boxes, colored ribbons, and walking paths that split and join again. It feels like a place for choices and consequences.",
      npc:{name:"Tally Finch",desc:"A cheerful vote counter who teaches choices, majority, representation, and civic voice.",text:"Tally Finch grins. 'Voting is a way people help choose leaders or decisions, but good choices require good information.'"},
      exits:{north:"debateHall",west:"serviceMarket",south:"branchTower"}
    },
    courtOfFairness:{
      title:"Court of Fairness",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"A solemn courtroom glows with soft lantern light. The judge's bench is carved with scales. The room feels serious, but not frightening, like a place meant for truth and fairness.",
      npc:{name:"Judge Stonebrow",desc:"A stern but fair judge who teaches courts, evidence, rights, and due process.",text:"Judge Stonebrow nods. 'A fair decision must hear evidence, follow rules, and protect the rights of the people involved.'"},
      exits:{north:"lawLibrary",east:"branchTower"}
    },
    branchTower:{
      title:"Three-Branch Tower",
      zone:"Councilhall Citadel",
      subject:"Civics",
      text:"A round tower rises above the citadel with three stairways winding upward: one marked Make Laws, one marked Carry Out Laws, and one marked Interpret Laws.",
      npc:{name:"Triarch Bell",desc:"A silver-belled guide who teaches branches of government, separation of powers, and checks and balances.",text:"Triarch Bell rings softly. 'Power is safer when it is divided and checked.'"},
      exits:{north:"votingGarden",west:"courtOfFairness"}
    }
  };

  Object.assign(ROOMS, civicsRooms);

  // Connect from town if possible, without overwriting important existing exits unless needed.
  if(ROOMS.townSquare){
    ROOMS.townSquare.exits = ROOMS.townSquare.exits || {};
    if(!ROOMS.townSquare.exits.east) ROOMS.townSquare.exits.east = "councilRoad1";
    else if(!ROOMS.townSquare.exits.south) ROOMS.townSquare.exits.south = "councilRoad1";
  }
  if(ROOMS.mainStreetEast){
    ROOMS.mainStreetEast.exits = ROOMS.mainStreetEast.exits || {};
    if(!ROOMS.mainStreetEast.exits.south) ROOMS.mainStreetEast.exits.south = "councilRoad1";
  }
})();

(function(){
  // Rewards
  window.LR_REWARDS = window.LR_REWARDS || {};
  window.LR_REWARDS.Civics = window.LR_REWARDS.Civics || [];
  window.LR_REWARDS.Civics.push(
    {name:"Citizen Badge",slot:"wall"},
    {name:"Tiny Law Scroll",slot:"shelf"},
    {name:"Council Lantern",slot:"shelf"},
    {name:"Voting Garden Ribbon",slot:"wall"},
    {name:"Fairness Scales Model",slot:"shelf"},
    {name:"Public Service Plaque",slot:"wall"},
    {name:"Three-Branch Tower Miniature",slot:"desk"},
    {name:"Debate Hall Quill",slot:"desk"}
  );
})();

(function(){
  // Grade target tracking
  const cfg = window.LR_GRADE_CONFIG = window.LR_GRADE_CONFIG || {};
  cfg.defaults = cfg.defaults || {targetCorrect:250,bossTarget:1};

  cfg.Luna = cfg.Luna || {gradeLabel:"Grade 1 Core",subjects:{}};
  cfg.Luna.subjects = cfg.Luna.subjects || {};
  cfg.Luna.subjects.Civics = {display:"Civics / Rules / Community",targetCorrect:160,bossTarget:1};

  cfg.Ava = cfg.Ava || {gradeLabel:"Grade 7 Core",subjects:{}};
  cfg.Ava.subjects = cfg.Ava.subjects || {};
  cfg.Ava.subjects.Civics = {display:"Civics / Government / Citizenship",targetCorrect:220,bossTarget:1};

  cfg.Michael = cfg.Michael || {gradeLabel:"Grade 8 Core",subjects:{}};
  cfg.Michael.subjects = cfg.Michael.subjects || {};
  cfg.Michael.subjects.Civics = {display:"Civics / Government / Source Judgment",targetCorrect:240,bossTarget:1};
})();

(function(){
  // Daily classroom rotation
  const cfg = window.LR_CLASSROOM_CONFIG = window.LR_CLASSROOM_CONFIG || {};
  cfg.assignmentSubjects = cfg.assignmentSubjects || {};
  cfg.dailyQuestionTargets = cfg.dailyQuestionTargets || {};

  ["Luna","Ava","Michael"].forEach(child=>{
    cfg.assignmentSubjects[child] = cfg.assignmentSubjects[child] || [];
    if(!cfg.assignmentSubjects[child].includes("Civics")) cfg.assignmentSubjects[child].push("Civics");
  });

  cfg.dailyQuestionTargets.Luna = Object.assign({Civics:3}, cfg.dailyQuestionTargets.Luna || {});
  cfg.dailyQuestionTargets.Ava = Object.assign({Civics:4}, cfg.dailyQuestionTargets.Ava || {});
  cfg.dailyQuestionTargets.Michael = Object.assign({Civics:4}, cfg.dailyQuestionTargets.Michael || {});
})();

(function(){
  // Curriculum map additions
  const map = window.LR_CURRICULUM_MAP = window.LR_CURRICULUM_MAP || {};

  map.Luna = map.Luna || {gradeLabel:"Grade 1",subjects:{}};
  map.Luna.subjects = map.Luna.subjects || {};
  map.Luna.subjects.Civics = {
    zone:"Councilhall Citadel",
    units:[
      {id:"G1-CIV-RULES",title:"Rules and Fairness",goal:"Understand rules, fairness, rights, and responsibilities at a young level.",targetLessons:120,skills:["rules","fairness","taking turns","rights","responsibilities"]},
      {id:"G1-CIV-COMMUNITY",title:"Community Helpers and Services",goal:"Learn how helpers and public services support a community.",targetLessons:120,skills:["helpers","services","safety","roads","community"]},
      {id:"G1-CIV-CHOICES",title:"Choices and Voice",goal:"Understand choices, voting-like decisions, and respectful listening.",targetLessons:80,skills:["choices","voice","listening","majority","kind disagreement"]}
    ]
  };

  map.Ava = map.Ava || {gradeLabel:"Grade 7",subjects:{}};
  map.Ava.subjects = map.Ava.subjects || {};
  map.Ava.subjects.Civics = {
    zone:"Councilhall Citadel",
    units:[
      {id:"G6-CIV-CITIZENSHIP",title:"Citizenship and Responsibility",goal:"Understand rights, responsibilities, public services, and civic participation.",targetLessons:160,skills:["rights","responsibilities","citizenship","public services","civic participation"]},
      {id:"G6-CIV-GOVERNMENT",title:"Government Structure",goal:"Understand local, state, national government and branches of government.",targetLessons:160,skills:["local government","state government","federal government","branches","laws"]},
      {id:"G6-CIV-EVIDENCE",title:"Civic Evidence and Sources",goal:"Use evidence and source reliability when discussing civic questions.",targetLessons:120,skills:["evidence","reliability","bias","purpose","fact vs opinion"]}
    ]
  };

  map.Michael = map.Michael || {gradeLabel:"Grade 8",subjects:{}};
  map.Michael.subjects = map.Michael.subjects || {};
  map.Michael.subjects.Civics = {
    zone:"Councilhall Citadel",
    units:[
      {id:"G7-CIV-CONSTITUTION",title:"Constitutional Principles",goal:"Understand limited government, rule of law, separation of powers, checks and balances, and rights.",targetLessons:180,skills:["limited government","rule of law","separation of powers","checks and balances","rights"]},
      {id:"G7-CIV-COURTS",title:"Courts and Due Process",goal:"Understand courts, evidence, fairness, juries, rights, and due process.",targetLessons:140,skills:["courts","evidence","due process","jury","fair trial"]},
      {id:"G7-CIV-SOURCES",title:"Civic Source Analysis",goal:"Analyze source reliability, bias, claims, evidence, and propaganda-like persuasion.",targetLessons:140,skills:["source reliability","bias","claim","evidence","persuasion"]}
    ]
  };
})();

(function(){
  // Portfolio prompts
  window.LR_PORTFOLIO_PROMPTS = window.LR_PORTFOLIO_PROMPTS || {};
  ["Luna","Ava","Michael"].forEach(child=>{
    window.LR_PORTFOLIO_PROMPTS[child] = window.LR_PORTFOLIO_PROMPTS[child] || [];
  });

  window.LR_PORTFOLIO_PROMPTS.Luna.push(
    {id:"LUNA-CIV-RULE-1",subject:"Civics",unit:"G1-CIV-RULES",title:"Make a Fair Rule",prompt:"Think of one rule that helps people be safe or fair. Write or tell the rule and why it helps.",helper:"Use: My rule is ___. It helps because ___.",estimatedMinutes:15},
    {id:"LUNA-CIV-HELPER-1",subject:"Civics",unit:"G1-CIV-COMMUNITY",title:"Community Helper Drawing",prompt:"Draw or describe one helper in a community. Tell what that helper does.",helper:"Think about safety, roads, food, health, mail, or helping people.",estimatedMinutes:20}
  );

  window.LR_PORTFOLIO_PROMPTS.Ava.push(
    {id:"AVA-CIV-SERVICES-1",subject:"Civics",unit:"G6-CIV-CITIZENSHIP",title:"Public Service Explanation",prompt:"Choose one public service and explain why a community needs it.",helper:"Use claim, evidence or example, and reasoning.",estimatedMinutes:25},
    {id:"AVA-CIV-SOURCE-1",subject:"Civics",unit:"G6-CIV-EVIDENCE",title:"Is This Source Reliable?",prompt:"Describe how you would decide whether a civic source is reliable.",helper:"Mention author, date, purpose, evidence, and bias.",estimatedMinutes:25}
  );

  window.LR_PORTFOLIO_PROMPTS.Michael.push(
    {id:"MICHAEL-CIV-CHECKS-1",subject:"Civics",unit:"G7-CIV-CONSTITUTION",title:"Checks and Balances Response",prompt:"Explain why checks and balances matter. Give one example of one branch limiting another.",helper:"Use the words branch, power, limit, and evidence.",estimatedMinutes:30},
    {id:"MICHAEL-CIV-DUEPROCESS-1",subject:"Civics",unit:"G7-CIV-COURTS",title:"Fair Trial Explanation",prompt:"Explain why evidence, rules, and rights matter in a fair court process.",helper:"Think like Judge Stonebrow: fairness needs more than guessing.",estimatedMinutes:30}
  );
})();

(function(){
  // Grade-ladder Civics lessons for all three children.
  function LR_addCivicsLadder(child){
    LR_addLessons(child,"Civics",[
      {gradeBand:"K",unit:"K-CIV-RULES",skill:"rules",difficulty:"kindergarten",mode:"foundation",
       miniLesson:"Rules help people stay safe and know what to do.",
       workedExample:"Take turns is a rule that helps people be fair.",
       guidedPractice:"Choose the idea that helps people stay safe or fair.",
       q:"Rules help people stay...",c:["safe","lost","invisible"],a:"safe",
       explain:"Good rules help people stay safe and fair."},

      {gradeBand:"G1",unit:"G1-CIV-RULES",skill:"rights and responsibilities",difficulty:"grade 1",mode:"foundation",
       miniLesson:"A responsibility is something you should do. A right is something people should be allowed or protected to have.",
       workedExample:"Listening when someone else speaks can be a responsibility. Being treated fairly is connected to rights.",
       guidedPractice:"Pick the action someone should do.",
       q:"Which is a responsibility?",c:["follow fair rules","hide the map","break the chair"],a:"follow fair rules",
       explain:"Following fair rules is a responsibility."},

      {gradeBand:"G2",unit:"G2-CIV-COMMUNITY",skill:"public services",difficulty:"grade 2",mode:"foundation",
       miniLesson:"Public services help a community.",
       workedExample:"Road repair, emergency help, and public libraries can be public services.",
       guidedPractice:"Choose the service that helps many people.",
       q:"Which is a public service?",c:["road repair","private toy box","personal snack"],a:"road repair",
       explain:"Road repair helps the public use roads safely."},

      {gradeBand:"G3",unit:"G3-CIV-CITIZENSHIP",skill:"citizenship",difficulty:"grade 3",mode:"foundation",
       miniLesson:"Citizenship includes rights and responsibilities.",
       workedExample:"A citizen may have the right to speak and the responsibility to obey laws.",
       guidedPractice:"Think about what people may do and what they should do.",
       q:"Citizenship includes rights and...",c:["responsibilities","evaporation","fractions"],a:"responsibilities",
       explain:"Citizenship includes both rights and responsibilities."},

      {gradeBand:"G4",unit:"G4-CIV-GOVERNMENT",skill:"local government",difficulty:"grade 4",mode:"foundation",
       miniLesson:"Local government helps manage community needs.",
       workedExample:"A local government may help with roads, safety, parks, and public buildings.",
       guidedPractice:"Choose the community-level service.",
       q:"Which can be a local government service?",c:["road repair","multiplication fact","vowel team"],a:"road repair",
       explain:"Road repair is a local service in many communities."},

      {gradeBand:"G5",unit:"G5-CIV-BRANCHES",skill:"branches of government",difficulty:"grade 5",mode:"foundation",
       miniLesson:"Government power can be divided among branches.",
       workedExample:"The legislative branch makes laws, the executive branch carries them out, and the judicial branch interprets them.",
       guidedPractice:"Match each branch to its job.",
       q:"Which branch makes laws?",c:["legislative","judicial","weather"],a:"legislative",
       explain:"The legislative branch makes laws."},

      {gradeBand:"G6",unit:"G6-CIV-EVIDENCE",skill:"source reliability",difficulty:"grade 6",mode:"foundation",
       miniLesson:"A reliable source should be checked for author, date, purpose, and evidence.",
       workedExample:"A signed article with clear evidence is stronger than an anonymous page with no support.",
       guidedPractice:"Ask who made it, when, why, and what proof it gives.",
       q:"Which helps judge source reliability?",c:["author, date, purpose, and evidence","font color only","page length only"],a:"author, date, purpose, and evidence",
       explain:"Those details help show whether a source is trustworthy."},

      {gradeBand:"G7",unit:"G7-CIV-CONSTITUTION",skill:"limited government",difficulty:"grade 7",mode:"foundation",
       miniLesson:"Limited government means government power is restricted by law.",
       workedExample:"A constitution can limit what leaders are allowed to do.",
       guidedPractice:"Look for rules that keep power from becoming unlimited.",
       q:"Limited government restricts...",c:["power","weather","division"],a:"power",
       explain:"Limited government prevents unlimited power."},

      {gradeBand:"G8",unit:"G8-CIV-CHECKS",skill:"checks and balances",difficulty:"grade 8",mode:"foundation",
       miniLesson:"Checks and balances allow branches of government to limit one another.",
       workedExample:"A court may review whether a law follows the Constitution, checking the power of lawmakers.",
       guidedPractice:"Ask which branch is limiting another.",
       q:"Checks and balances help limit government...",c:["power","weather","multiplication"],a:"power",
       explain:"Checks and balances help prevent one branch from holding too much power."}
    ]);
  }

  LR_addCivicsLadder("Luna");
  LR_addCivicsLadder("Ava");
  LR_addCivicsLadder("Michael");
})();

(function(){
  // Boss content
  window.LR_BOSS_CONTENT = window.LR_BOSS_CONTENT || {};
  window.LR_BOSS_CONTENT.Luna = window.LR_BOSS_CONTENT.Luna || {};
  window.LR_BOSS_CONTENT.Ava = window.LR_BOSS_CONTENT.Ava || {};
  window.LR_BOSS_CONTENT.Michael = window.LR_BOSS_CONTENT.Michael || {};

  window.LR_BOSS_CONTENT.Luna.Civics = [
    {title:"Gatewarden's Fair Rule Trial",intro:"Gatewarden Brindle asks Luna to choose what rules are for.",q:"Rules should help people stay...",c:["safe and fair","confused","hidden"],a:"safe and fair",reward:"Fair Rule Badge"},
    {title:"Mira's Helper Trial",intro:"Mira points to the busy square full of helpers.",q:"A community helper is someone who...",c:["helps people in the community","hides all maps","breaks roads"],a:"helps people in the community",reward:"Community Helper Ribbon"}
  ];

  window.LR_BOSS_CONTENT.Ava.Civics = [
    {title:"Public Service Trial",intro:"Foreman Pike lays out a model road, bridge, and lamp post.",q:"Which is a public service?",c:["road repair","private snack","personal toy shelf"],a:"road repair",reward:"Public Service Crest"},
    {title:"Reliable Source Trial",intro:"Archivist Quill places two scrolls on a desk.",q:"A reliable civic source should be checked for author, date, purpose, and...",c:["evidence","paper color","how fancy it looks"],a:"evidence",reward:"Source Checker Seal"}
  ];

  window.LR_BOSS_CONTENT.Michael.Civics = [
    {title:"Checks and Balances Trial",intro:"Triarch Bell rings three notes for the three branches.",q:"Checks and balances are meant to limit government...",c:["power","weather","density"],a:"power",reward:"Three-Branch Tower Medal"},
    {title:"Court of Evidence Trial",intro:"Judge Stonebrow asks for proof, not guesses.",q:"A fair court decision should rely on...",c:["evidence and rules","rumors only","who talks loudest"],a:"evidence and rules",reward:"Fair Trial Scales"}
  ];
})();
