/* LearningRealms Dynamic Learning Trails Router 6.8B
   Turns Go Learn into a main-screen learning-trails scene. No new lessons/rewards.
   Keeps the dynamic adventure shell and makes subjects easier to reach through descriptive choices.
*/
(function(){
  'use strict';
  if(window.__LR68B_LEARNING_TRAILS_ROUTER__) return;
  window.__LR68B_LEARNING_TRAILS_ROUTER__ = true;

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v === undefined || v === null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
  }
  function clean(v){
    return String(v || '').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,'').replace(/\s+/g,' ').trim();
  }
  function getState(){ try{ if(window.state) return window.state; }catch(e){} try{ if(typeof state !== 'undefined') return state; }catch(e){} return null; }
  function getRooms(){ try{ if(window.LR_ROOMS) return window.LR_ROOMS; }catch(e){} try{ if(typeof ROOMS !== 'undefined') return ROOMS; }catch(e){} return {}; }
  function loc(){ var s=getState(); return (s && s.loc) ? s.loc : 'crossroads'; }
  function room(id){ var rooms=getRooms(); return rooms[id || loc()] || rooms.crossroads || {}; }
  function statLine(){
    var s=getState() || {}, parts=[];
    try{ if(typeof activeChild !== 'undefined') parts.push(activeChild); }catch(e){}
    if(typeof s.room !== 'undefined') parts.push('Room ' + s.room);
    if(typeof s.sparks !== 'undefined') parts.push((s.sparks || 0) + ' Sparks');
    if(typeof s.streak !== 'undefined') parts.push('Streak ' + (s.streak || 0));
    return parts.join(' · ');
  }
  function call(name){
    var args=Array.prototype.slice.call(arguments,1);
    try{ if(typeof window[name] === 'function') return window[name].apply(window,args); }catch(e){ console.warn('LR68B call failed', name, e); }
    return undefined;
  }
  function save(){ try{ call('save'); }catch(e){} }
  function stats(){ try{ call('renderStats'); }catch(e){} try{ call('renderHomeSlots'); }catch(e){} }

  if(!window.__LR68B_OLD_OPEN_LEARN__ && typeof window.lr68OpenLearn === 'function'){
    window.__LR68B_OLD_OPEN_LEARN__ = window.lr68OpenLearn;
  }

  function ensureMount(){
    try{
      document.body.classList.add('lrDynamicAdventureMode','lr68DynamicShell','lr68aHardening','lr68bLearningTrails');
      document.body.classList.remove('homeMode');
    }catch(e){}
    var main = document.querySelector('.main') || document.querySelector('main') || document.body;
    var first = document.querySelector('.main > .card:first-child') || main;
    try{
      if(main){ main.style.display='block'; main.style.visibility='visible'; main.style.opacity='1'; main.style.width='100%'; }
      if(first){ first.style.display='block'; first.style.visibility='visible'; first.style.opacity='1'; first.style.width='100%'; first.style.maxWidth='none'; }
    }catch(e){}
    var mount = byId('lrDynamicAdventureScreen');
    if(!mount){
      mount = document.createElement('div');
      mount.id = 'lrDynamicAdventureScreen';
      mount.className = 'lrDynamicAdventureScreen lr68DynamicScreen lr68bTrailScreen';
      if(first && first.firstChild) first.insertBefore(mount, first.firstChild);
      else (first || document.body).appendChild(mount);
    }
    mount.style.display='block'; mount.style.visibility='visible'; mount.style.opacity='1'; mount.style.width='100%'; mount.style.maxWidth='none';
    return mount;
  }

  function oldSurfacesOff(){
    ['mainCompassNav','mainGameplayActions','lrControlDock','lrFixedGameplayDock','lrCenterActionDock','lrCenterGameplayDock','movementControls','leftActionButtons'].forEach(function(id){
      var el=byId(id); if(el){ el.style.display='none'; el.style.visibility='hidden'; el.style.height='0'; el.style.maxHeight='0'; el.style.overflow='hidden'; }
    });
  }

  var TRAILS = {
    featured: [
      {id:'shipwreck-tour', type:'fn', fn:'shipwreckGuidedZoneOpen', title:'Take the misty path to Shipwreck Cove.', meta:'Guided maritime zone', body:'Start with the lighthouse guide, foggy pier, chart room, pirates, legends, wreck evidence, rescue lessons, and safety clues.'},
      {id:'inventions-course', type:'fn', fn:'openInventionsDeepCourse', title:'Enter the Engineering Hall of Inventions.', meta:'Deep master course', body:'Open prototypes, simple machines, bridges, flight, computers, space safety, redesign, and engineering disaster lessons.'},
      {id:'creative-course', type:'fn', fn:'openCreativeStudioCourse', title:'Step into the Creative Studio.', meta:'Creative specialist course', body:'Open drawing, painting, crafts, patterns, theater, music, story making, and gallery practice.'},
      {id:'reading-woods', type:'room', room:'whisperwood', title:'Follow the story road into Reading Woods.', meta:'Reading realm', body:'Move into text clues, careful reading, story details, vocabulary, and proof from what was read.'},
      {id:'math-hills', type:'room', room:'ironGate', title:'Take the stone path toward the Math Iron Hills.', meta:'Math realm', body:'Travel into gears, measurement, number thinking, problem solving, and math challenges.'},
      {id:'merchant-row', type:'room', room:'merchantRoad1', title:'Walk the coinstone lane toward Merchant Row.', meta:'Economics and money', body:'Travel toward choices, trade, needs, wants, value, saving, and shopkeeper-style learning.'}
    ],
    core: [
      {id:'reading', type:'room', room:'whisperwood', title:'Follow the birch road to story clues.', meta:'Reading', body:'Careful reading, main ideas, details, vocabulary, sequence, and proof from the text.'},
      {id:'math', type:'room', room:'ironGate', title:'Climb toward the old math gate.', meta:'Math', body:'Numbers, patterns, operations, measurement, models, and step-by-step problem solving.'},
      {id:'science', type:'room', room:'crystalMarsh', title:'Walk the creek road to Science Marsh.', meta:'Science', body:'Observation, weather, habitats, matter, evidence, and safe experiments.'},
      {id:'writing', type:'room', room:'archiveRoad', title:'Climb the lantern road to Writing and Archives.', meta:'Writing / history records', body:'Sentences, records, explanations, source clues, maps, timelines, and careful notes.'},
      {id:'copywork', type:'room', room:'scribeRoad1', title:'Enter the quiet road to Copywork Abbey.', meta:'Copywork', body:'Handwriting, careful copying, language patterns, attention to detail, and neat practice.'},
      {id:'life-skills', type:'room', room:'homesteadRoad1', title:'Head toward Homestead Workshop.', meta:'Life skills', body:'Planning, daily habits, practical work, useful routines, and common-sense problem solving.'}
    ],
    world: [
      {id:'shipwreck-deep', type:'fn', fn:'openShipwreckCoveDeepCourse', title:'Open the full Shipwreck Cove course map.', meta:'Maritime history', body:'Study wrecks, ships, navigation, weather, archaeology, safety improvements, and respectful historical memory.'},
      {id:'civics', type:'room', room:'councilRoad1', title:'Follow the banner road to Councilhall Citadel.', meta:'Civics', body:'Rules, rights, responsibility, service, fair decisions, public goods, and evidence-based disagreement.'},
      {id:'geography', type:'room', room:'mapmakerRoad1', title:'Step onto the mapmaker road.', meta:'Geography', body:'Maps, routes, landforms, regions, directions, location clues, and how places connect.'},
      {id:'history-archive', type:'room', room:'historicalSociety', title:'Visit the Historical Society.', meta:'History', body:'Old records, source clues, timelines, artifacts, cause and effect, and careful historical thinking.'},
      {id:'timeline', type:'room', room:'timelineHall', title:'Enter Timeline Hall.', meta:'History timeline', body:'Put events in order and connect dates, people, places, causes, and consequences.'},
      {id:'maproom', type:'room', room:'mapRoom', title:'Study the map room.', meta:'History and geography', body:'Use maps as evidence and connect locations to what happened there.'}
    ],
    stem: [
      {id:'inventions', type:'fn', fn:'openInventionsDeepCourse', title:'Open Inventions and Engineering Disasters.', meta:'Engineering', body:'Inventors, prototypes, redesign, testing, bridges, flight, computers, rockets, safety, and failure analysis.'},
      {id:'science-marsh', type:'room', room:'crystalMarsh', title:'Step into Crystal Marsh.', meta:'Science', body:'Use observation and evidence to study living things, weather clues, water, and nature patterns.'},
      {id:'nature', type:'room', room:'wildrootRoad1', title:'Follow the Wildroot Preserve trail.', meta:'Nature', body:'Plants, animals, habitats, safe outdoor observation, ecology basics, and stewardship.'},
      {id:'health', type:'room', room:'hearthwellRoad1', title:'Visit the Hearthwell Clinic path.', meta:'Health', body:'Food, rest, movement, hygiene, safe body systems, and basic wellness habits.'},
      {id:'logic', type:'room', room:'puzzleRoad1', title:'Head to the Puzzle Spire road.', meta:'Logic', body:'Reasoning, patterns, evidence, careful claims, and avoiding weak thinking.'},
      {id:'forge', type:'room', room:'forgeHall', title:'Enter Forge Hall for tool thinking.', meta:'Math and mechanics', body:'Gears, measurements, shapes, tools, and practical problem solving.'}
    ],
    creative: [
      {id:'creative-studio', type:'fn', fn:'openCreativeStudioCourse', title:'Open Creative Studio Specialists.', meta:'Creative course', body:'Drawing, painting, crafts, pattern design, theater, music, story making, and gallery habits.'},
      {id:'music', type:'room', room:'bardwoodGate', title:'Step through Bardwood Gate into Music Hall.', meta:'Music', body:'Rhythm, sound, listening, instruments, patterns, and music vocabulary.'},
      {id:'art-road', type:'room', room:'dragonbrushVale1', title:'Enter Dragonbrush Vale.', meta:'Art realm', body:'Lines, shapes, color, composition, observation, and art practice in a fantasy art valley.'},
      {id:'storymaker', type:'room', room:'archiveRoad', title:'Climb toward the Story Maker archives.', meta:'Story and writing', body:'Build ideas, sentences, scenes, descriptions, and explanations from clear details.'},
      {id:'gallery', type:'room', room:'memoryMuseum', title:'Walk into the Memory Museum.', meta:'Collections', body:'Review earned memories, discoveries, records, and what has been collected so far.'}
    ],
    tools: [
      {id:'home', type:'room', room:'home', title:'Return to Home Hearth.', meta:'Home base', body:'Check rooms, storage, pets, collections, and family progress without leaving the dynamic screen.'},
      {id:'atlas', type:'action', fn:'openWorldAtlas', title:'Open the World Atlas.', meta:'Travel tool', body:'Use the atlas when you want a broader view of loaded places and shortcuts.'},
      {id:'quests', type:'action', fn:'openQuestJournal', title:'Open the Quest Journal.', meta:'Quest tool', body:'Check longer goals, current tasks, story quests, and things worth finishing next.'},
      {id:'collections', type:'action', fn:'openCollectionLog', title:'Open the Collection Log.', meta:'Collections', body:'Look over discovered items, keepsakes, rewards, and unlocks.'},
      {id:'pets', type:'action', fn:'openCompanionDen', title:'Visit the Companion Den.', meta:'Pets / companions', body:'Check companions, training, discoveries, and related progress.'},
      {id:'classic-menu', type:'classic', title:'Open the old course list as a fallback.', meta:'Fallback menu', body:'Use this if a topic has not been wired into the new trail scene yet.'}
    ]
  };

  var TAB_META = [
    {id:'featured', label:'Featured trails', hint:'Best starting doors'},
    {id:'core', label:'Core realms', hint:'Reading, math, writing, science'},
    {id:'world', label:'History and world', hint:'History, civics, geography'},
    {id:'stem', label:'Science and engineering', hint:'STEM roads'},
    {id:'creative', label:'Creative paths', hint:'Art, music, story'},
    {id:'tools', label:'Home and tools', hint:'Storage, quests, atlas'}
  ];

  function available(t){
    if(!t) return false;
    if(t.type === 'room') return !!getRooms()[t.room];
    if(t.type === 'fn' || t.type === 'action') return typeof window[t.fn] === 'function';
    if(t.type === 'classic') return true;
    return false;
  }
  function allTrails(){
    var out=[]; Object.keys(TRAILS).forEach(function(k){ (TRAILS[k]||[]).forEach(function(t){ out.push(t); }); }); return out;
  }
  function trailById(id){
    var list=allTrails();
    for(var i=0;i<list.length;i++){ if(list[i].id === id) return list[i]; }
    return null;
  }

  function tabBar(active){
    return '<div class="lr68bTabs">' + TAB_META.map(function(t){
      return '<button type="button" class="' + (t.id===active?'active':'') + '" onclick="lr68bOpenLearningTrails(\'' + esc(t.id) + '\')"><b>' + esc(t.label) + '</b><small>' + esc(t.hint) + '</small></button>';
    }).join('') + '</div>';
  }
  function card(t){
    var disabled = available(t) ? '' : ' disabled';
    var note = available(t) ? '' : '<em>Not loaded in this build yet.</em>';
    return '<button type="button" class="lr68bTrailCard"' + disabled + ' onclick="lr68bRunTrail(\'' + esc(t.id) + '\')">' +
      '<span class="lr68bTrailText"><b>' + esc(t.title) + '</b><small>' + esc(t.meta || '') + '</small><p>' + esc(t.body || '') + '</p>' + note + '</span>' +
      '<span class="lr68bTrailArrow">›</span>' +
    '</button>';
  }
  function relatedRoomPreview(){
    var r=room();
    var bits=[];
    if(r.subject) bits.push('Current subject: ' + clean(r.subject));
    if(r.zone) bits.push('Current zone: ' + clean(r.zone));
    if(r.title) bits.push('Current scene: ' + clean(r.title));
    return bits.length ? bits.join(' · ') : 'Choose a trail to begin.';
  }

  function renderTrails(section){
    section = TRAILS[section] ? section : 'featured';
    var mount=ensureMount();
    oldSurfacesOff();
    var cards = (TRAILS[section] || []).map(card).join('');
    if(!cards) cards = '<div class="lr68bEmpty">No trail cards are loaded for this group yet.</div>';
    mount.innerHTML =
      '<span data-lr68a-path-panel="1" style="display:none"></span>' +
      '<section class="lr68bHero">' +
        '<div class="lr68bHeroTop"><span>Learning trails router</span><span>' + esc(statLine()) + '</span></div>' +
        '<h1>Choose the next learning trail.</h1>' +
        '<p>This replaces the giant course-button feeling with descriptive adventure choices. Pick a road, and the main screen moves you to the right subject area. Lessons and quizzes still open in the larger reading windows.</p>' +
        '<small>' + esc(relatedRoomPreview()) + '</small>' +
      '</section>' +
      tabBar(section) +
      '<section class="lr68bTrailGrid" aria-label="Learning trails">' + cards + '</section>' +
      '<div class="lr68bFooter">' +
        '<button type="button" onclick="lr68bReturnToScene()">↩ Return to current scene</button>' +
        '<button type="button" onclick="lr68bClassicLearningMenu()">Open fallback course list</button>' +
        '<button type="button" onclick="lr68OpenHome && lr68OpenHome()">Home</button>' +
      '</div>';
    stats();
    return false;
  }

  function travelTo(target, label){
    try{
      if(!getRooms()[target]){ renderTrails('featured'); return false; }
      if(window.LR68A && typeof window.LR68A.goTo === 'function') return window.LR68A.goTo(target);
      if(typeof window.lr68aGoTo === 'function') return window.lr68aGoTo(target);
      var s=getState(); if(s){ s.loc=target; s.room=Math.max(1,Number(s.room||1))+1; }
      save(); stats();
      if(typeof window.lr68Render === 'function') return window.lr68Render('room','You follow the learning trail to ' + (label || clean(room(target).title || target)) + '.');
    }catch(e){ console.warn('LR68B travel failed', e); }
    return false;
  }
  function openFunction(fn){
    try{
      document.body.classList.add('lrBigLessonPopup','lr68BigLessonPopup','lr68aBigPopup','lr68bBigPopup');
      if(typeof window[fn] === 'function') return window[fn]();
    }catch(e){ console.warn('LR68B function route failed', fn, e); }
    renderTrails('featured');
    return false;
  }
  function openAction(fn, title){
    try{
      if(typeof window[fn] === 'function'){
        var out = window[fn]();
        setTimeout(function(){
          try{ if(window.LR68 && typeof window.LR68.embed === 'function') window.LR68.embed(title || fn); }
          catch(e){ if(typeof window.lr68Render === 'function') window.lr68Render('room'); }
        }, 35);
        return out;
      }
    }catch(e){ console.warn('LR68B action route failed', fn, e); }
    renderTrails('tools');
    return false;
  }
  function runTrail(id){
    var t=trailById(id);
    if(!t || !available(t)){ renderTrails('featured'); return false; }
    if(t.type === 'room') return travelTo(t.room, t.title);
    if(t.type === 'fn') return openFunction(t.fn);
    if(t.type === 'action') return openAction(t.fn, t.title);
    if(t.type === 'classic') return classicMenu();
    return false;
  }
  function classicMenu(){
    try{
      document.body.classList.add('lrBigLessonPopup','lr68BigLessonPopup','lr68bBigPopup');
      var old = window.__LR68B_OLD_OPEN_LEARN__;
      if(typeof old === 'function' && old !== renderTrails) return old.call(window);
      var names=['lr62eOpenLearn','lr19OpenLearningChooser','openRealCurriculumPicker','openLessonLauncher','openSubjectAtlasUI'];
      for(var i=0;i<names.length;i++){ if(typeof window[names[i]] === 'function') return window[names[i]](); }
    }catch(e){ console.warn('LR68B fallback menu failed', e); }
    return renderTrails('featured');
  }
  function returnToScene(){
    try{ if(typeof window.lr68Render === 'function') return window.lr68Render('room','You return from the learning trail board.'); }catch(e){}
    try{ if(window.LR68 && typeof window.LR68.render === 'function') return window.LR68.render('room','You return from the learning trail board.'); }catch(e){}
    return false;
  }

  function injectStyles(){
    if(byId('lr68bLearningTrailsStyle')) return;
    var st=document.createElement('style'); st.id='lr68bLearningTrailsStyle';
    st.textContent = `
      body.lr68bLearningTrails #lrDynamicAdventureScreen{min-height:650px !important;width:100% !important;max-width:none !important;}
      .lr68bHero{padding:28px 32px 22px;border-radius:24px 24px 0 0;background:linear-gradient(135deg,rgba(15,44,60,.98),rgba(33,81,73,.95));color:#fff6db;border-bottom:1px solid rgba(255,232,166,.25);box-shadow:inset 0 -1px 0 rgba(255,255,255,.08);}
      .lr68bHeroTop{display:flex;justify-content:space-between;gap:12px;font-weight:900;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem;color:#ffe7a5;}
      .lr68bHero h1{margin:12px 0 10px;font-size:clamp(1.8rem,3vw,2.8rem);line-height:1.05;color:#fff8dd;}
      .lr68bHero p{max-width:960px;margin:0 0 10px;line-height:1.55;font-weight:750;color:#e7f4e5;}.lr68bHero small{display:block;color:#bde9d7;font-weight:850;}
      .lr68bTabs{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px;padding:14px 18px;background:rgba(7,28,39,.78);border-bottom:1px solid rgba(255,255,255,.08);}
      .lr68bTabs button{display:flex;flex-direction:column;gap:2px;align-items:flex-start;text-align:left;border:1px solid rgba(255,231,165,.24);background:rgba(255,255,255,.08);color:#fff5d6;border-radius:14px;padding:10px 12px;cursor:pointer;box-shadow:0 6px 14px rgba(0,0,0,.16);}
      .lr68bTabs button.active{background:#fff4d2;color:#153830;border-color:#ffe394;}.lr68bTabs button small{opacity:.82;font-weight:800;line-height:1.2;}
      .lr68bTrailGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:13px;padding:20px;background:linear-gradient(180deg,rgba(242,252,239,.96),rgba(225,241,234,.96));}
      .lr68bTrailCard{min-height:142px;width:100%;display:flex;align-items:stretch;justify-content:space-between;gap:12px;text-align:left;border:1px solid rgba(19,75,65,.20);border-radius:20px;background:#fffdf2;color:#17352d;padding:15px 15px;box-shadow:0 10px 18px rgba(0,0,0,.13);cursor:pointer;transition:transform .08s ease, box-shadow .08s ease;}
      .lr68bTrailCard:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 14px 22px rgba(0,0,0,.18);}.lr68bTrailCard:disabled{opacity:.55;cursor:not-allowed;filter:grayscale(.25);}
      .lr68bTrailText{display:flex;flex-direction:column;gap:5px;}.lr68bTrailText b{font-size:1.05rem;line-height:1.25;color:#123a31;}.lr68bTrailText small{font-weight:950;color:#6b5920;text-transform:uppercase;letter-spacing:.04em;font-size:.73rem;}.lr68bTrailText p{margin:2px 0 0;color:#435b53;font-weight:760;line-height:1.35;}.lr68bTrailText em{font-style:normal;color:#8a4a28;font-weight:900;}
      .lr68bTrailArrow{align-self:center;font-size:2.2rem;line-height:1;color:#ac7b21;font-weight:900;}.lr68bEmpty{grid-column:1/-1;padding:20px;border-radius:16px;background:#fff;color:#183a32;font-weight:800;}
      .lr68bFooter{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:16px 20px;background:rgba(8,33,42,.92);border-radius:0 0 22px 22px;}
      .lr68bFooter button{border:1px solid rgba(255,231,165,.35);background:#fff5d6;color:#183a32;border-radius:999px;padding:10px 14px;font-weight:900;cursor:pointer;}
      body.lr68bBigPopup .lrPopupWindow{width:min(1180px,96vw) !important;max-height:94vh !important;} body.lr68bBigPopup .lrPopupBody{max-height:80vh !important;font-size:1.08rem !important;line-height:1.62 !important;}
      @media(max-width:850px){.lr68bHero{padding:22px 18px 18px}.lr68bHeroTop{flex-direction:column}.lr68bTrailGrid{grid-template-columns:1fr;padding:14px}.lr68bTabs{grid-template-columns:1fr 1fr;padding:10px}.lr68bTrailCard{min-height:auto}.lr68bFooter{border-radius:0}}
    `;
    document.head.appendChild(st);
  }

  function install(){
    injectStyles();
    window.lr68bOpenLearningTrails = renderTrails;
    window.lr68bRunTrail = runTrail;
    window.lr68bClassicLearningMenu = classicMenu;
    window.lr68bReturnToScene = returnToScene;
    window.lr68OpenLearn = function(){ return renderTrails('featured'); };
    try{ lr68OpenLearn = window.lr68OpenLearn; }catch(e){}
    if(window.LR68) window.LR68.learn = window.lr68OpenLearn;
    oldSurfacesOff();
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function(){ setTimeout(install,120); setTimeout(install,420); });
  else { setTimeout(install,120); setTimeout(install,420); }
  window.addEventListener('load', function(){ setTimeout(install,250); setTimeout(install,900); });
})();
