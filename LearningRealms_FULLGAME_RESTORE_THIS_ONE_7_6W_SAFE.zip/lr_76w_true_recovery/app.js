
/* HARD UI CLEANUP PACK REMOVED BY 7.3I ATMOSPHERE RESTORE */

/* REAL Curriculum Loader Pack */
const LR_REAL_CURRICULUM_FILES = [
  "content_packs/advanced_aerospace_real_curriculum_pack1.json",
  "content_packs/aerospace_engineering_real_curriculum_pack1.json",
  "content_packs/ancient_worlds_real_curriculum_pack1.json",
  "content_packs/animal_care_real_curriculum_pack1.json",
  "content_packs/arts_kingdom_real_curriculum_pack1.json",
  "content_packs/astronomy_observatory_real_curriculum_pack1.json",
  "content_packs/botany_conservatory_real_curriculum_pack1.json",
  "content_packs/budget_borough_real_curriculum_pack1.json",
  "content_packs/builder_workshop_real_curriculum_pack1.json",
  "content_packs/celtic_heritage_real_curriculum_pack1.json",
  "content_packs/chemistry_institute_real_curriculum_pack1.json",
  "content_packs/computer_science_real_curriculum_pack1.json",
  "content_packs/cooking_guild_real_curriculum_pack1.json",
  "content_packs/counting_orchard_real_curriculum_pack1.json",
  "content_packs/craft_cottage_real_curriculum_pack1.json",
  "content_packs/earth_science_real_curriculum_pack1.json",
  "content_packs/electricity_lab_real_curriculum_pack1.json",
  "content_packs/equation_forge_real_curriculum_pack1.json",
  "content_packs/farm_valley_real_curriculum_pack1.json",
  "content_packs/fraction_castle_real_curriculum_pack1.json",
  "content_packs/garden_grounds_real_curriculum_pack1.json",
  "content_packs/geometry_caverns_real_curriculum_pack1.json",
  "content_packs/insect_kingdom_real_curriculum_pack1.json",
  "content_packs/life_skills_real_curriculum_pack1.json",
  "content_packs/logic_realm_real_curriculum_pack1.json",
  "content_packs/machines_motion_real_curriculum_pack1.json",
  "content_packs/map_hall_real_curriculum_pack1.json",
  "content_packs/mechanical_workshop_real_curriculum_pack1.json",
  "content_packs/merchant_square_real_curriculum_pack1.json",
  "content_packs/music_hall_real_curriculum_pack1.json",
  "content_packs/nature_health_real_curriculum_pack1.json",
  "content_packs/painting_studio_real_curriculum_pack1.json",
  "content_packs/physics_forge_real_curriculum_pack1.json",
  "content_packs/repair_shop_real_curriculum_pack1.json",
  "content_packs/robotics_lab_real_curriculum_pack1.json",
  "content_packs/story_forest_real_curriculum_pack1.json",
  "content_packs/theater_stage_real_curriculum_pack1.json",
  "content_packs/weather_academy_real_curriculum_pack1.json",
  "content_packs/writing_guild_real_curriculum_pack1.json"
];

window.__lrRealCurriculumBank = window.__lrRealCurriculumBank || [];
window.__lrRealCurriculumLoaded = false;

async function lrLoadRealCurriculumBank(){
  if(window.__lrRealCurriculumLoaded) return window.__lrRealCurriculumBank;
  const loaded = [];
  for(const file of LR_REAL_CURRICULUM_FILES){
    try{
      const res = await fetch(file);
      if(!res.ok) continue;
      const data = await res.json();
      if(data && Array.isArray(data.lessons)){
        data.lessons.forEach(function(lesson){
          loaded.push(Object.assign({source_pack:file, pack_region:data.region || ""}, lesson));
        });
      }
    }catch(e){}
  }
  window.__lrRealCurriculumBank = loaded;
  window.__lrRealCurriculumLoaded = true;
  return loaded;
}

function lrLessonMatchesSubject(lesson, subject){
  const text = ((lesson.region || "") + " " + (lesson.pack_region || "") + " " + (lesson.mastery_tag || "")).toLowerCase();
  if(subject === "math") return /count|merchant|fraction|geometry|equation|budget/.test(text);
  if(subject === "reading") return /story|reading|library|character|plot/.test(text);
  if(subject === "science") return /insect|chem|weather|earth|physics|electric|botany|astronomy|nature|garden/.test(text);
  if(subject === "writing") return /writing|sentence|paragraph/.test(text);
  if(subject === "geography") return /map|geography/.test(text);
  if(subject === "logic") return /logic|pattern|sequence/.test(text);
  if(subject === "aerospace") return /aero|space|rocket|engineering|mechanical|robot|computer|motion/.test(text);
  if(subject === "heritage") return /celtic|heritage|ancient/.test(text);
  if(subject === "life") return /life|cook|farm|repair|animal|budget/.test(text);
  if(subject === "arts") return /art|music|paint|theater|craft|builder/.test(text);
  return true;
}

async function openRealCurriculumPicker(subject){
  const bank = await lrLoadRealCurriculumBank();
  const active = subject || "all";
  const subjects = ["all","math","reading","science","writing","geography","logic","aerospace","heritage","life","arts"];
  const filtered = active === "all" ? bank : bank.filter(l => lrLessonMatchesSubject(l, active));
  const sample = filtered.slice(0, 40);

  actionTitle.textContent = "📚 REAL Curriculum";
  actionText.innerHTML =
    '<div class="lrRealCurriculumPicker">' +
      '<div class="lrRealCurriculumHeader"><h3>Authored Lesson Bank</h3><p>Loaded ' + bank.length + ' real authored lessons from ' + LR_REAL_CURRICULUM_FILES.length + ' packs.</p></div>' +
      '<div class="lrRealSubjectTabs">' + subjects.map(function(s){
        return '<button onclick="openRealCurriculumPicker(\'' + s + '\')">' + s + '</button>';
      }).join("") + '</div>' +
      '<div class="lrRealLessonList">' + sample.map(function(l, idx){
        return '<button onclick="lrOpenRealLessonByIndex(' + bank.indexOf(l) + ')"><b>' + lrAtlasEscape(l.region || l.pack_region || "Lesson") + '</b><br><small>' + lrAtlasEscape(l.question || "") + '</small></button>';
      }).join("") + '</div>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("REAL Curriculum");
}

function lrOpenRealLessonByIndex(index){
  const lesson = window.__lrRealCurriculumBank[index];
  if(!lesson) return;
  window.__lrActiveRealLesson = lesson;
  actionTitle.textContent = "📘 Lesson";
  actionText.innerHTML =
    '<div class="lrCleanLessonWindow">' +
      '<h3>' + lrAtlasEscape(lesson.region || lesson.pack_region || "Lesson") + '</h3>' +
      '<p><b>Skill:</b> ' + lrAtlasEscape(lesson.mastery_tag || "practice") + '</p>' +
      '<div class="lrLessonTeachingBox">' + lrAtlasEscape(lesson.explanation || "Read the question carefully, then begin the test.") + '</div>' +
      '<button onclick="lrStartRealLessonTest()">Start Test</button>' +
      '<button onclick="openRealCurriculumPicker()">Back to REAL Curriculum</button>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Lesson");
}

function lrStartRealLessonTest(){
  const lesson = window.__lrActiveRealLesson;
  if(!lesson) return;
  actionTitle.textContent = "📝 Test";
  let answers = "";
  if(Array.isArray(lesson.choices)){
    answers = '<div class="lrCleanChoiceGrid">' + lesson.choices.map(function(c){
      return '<button onclick="lrSubmitRealLessonAnswer(' + JSON.stringify(String(c)) + ')">' + lrAtlasEscape(c) + '</button>';
    }).join("") + '</div>';
  }else if(Array.isArray(lesson.items)){
    answers = '<p><b>Items:</b> ' + lesson.items.map(lrAtlasEscape).join(" → ") + '</p><button onclick="lrSubmitRealLessonAnswer(' + JSON.stringify(JSON.stringify(lesson.answer)) + ')">Submit Ordered Answer</button>';
  }else{
    answers = '<input id="lrRealFillAnswer" class="lrRewardCodeInput" placeholder="Type answer"><button onclick="lrSubmitRealLessonAnswer(document.getElementById(\'lrRealFillAnswer\').value)">Submit</button>';
  }

  actionText.innerHTML =
    '<div class="lrCleanTestWindow">' +
      '<h3>' + lrAtlasEscape(lesson.region || "Test") + '</h3>' +
      '<p>' + lrAtlasEscape(lesson.question || "") + '</p>' +
      answers +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Test");
}

function lrRealAnswerMatches(choice, answer){
  if(Array.isArray(answer)) return String(choice).trim() === JSON.stringify(answer);
  return String(choice).trim().toLowerCase() === String(answer).trim().toLowerCase();
}

function lrSubmitRealLessonAnswer(choice){
  const lesson = window.__lrActiveRealLesson;
  if(!lesson) return;
  const correct = lrRealAnswerMatches(choice, lesson.answer);
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : null;
  if(correct && econ) econ.crowns += 25;
  if(typeof save === "function") save();
  actionTitle.textContent = correct ? "✅ Correct" : "🔁 Review";
  actionText.innerHTML =
    '<div class="lrCleanTestWindow">' +
      '<h3>' + (correct ? "Correct!" : "Review this one") + '</h3>' +
      '<p><b>Answer:</b> ' + lrAtlasEscape(Array.isArray(lesson.answer) ? lesson.answer.join(" → ") : lesson.answer) + '</p>' +
      '<p>' + lrAtlasEscape(lesson.explanation || "") + '</p>' +
      (correct ? '<p>Reward: ✨ 25 Learning Crowns</p>' : '') +
      '<button onclick="lrOpenRealLessonByIndex(window.__lrRealCurriculumBank.indexOf(window.__lrActiveRealLesson))">Back to Lesson</button>' +
      '<button onclick="openRealCurriculumPicker()">Choose Another</button>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Result");
}

/* Hook Start Lesson button toward real curriculum */
const lrOldStartCleanLesson = (typeof lrStartCleanLesson === "function") ? lrStartCleanLesson : null;
lrStartCleanLesson = function(){
  openRealCurriculumPicker();
};
/* End REAL Curriculum Loader Pack */


/* Removed by 7.4X Stability: Main Room Action Bar Cleanup Pack */


/* Removed by 7.4X Stability: Room Focus + Compass Cleanup Pack */


/* Subject Atlas UI Pack */
const LR_SUBJECT_ATLAS_UI = {
  "🧮 Mathematics": {
    guide:"🦉 Professor Numeron",
    path:["🍎 Counting Orchard","🏪 Merchant Square","🏰 Fraction Castle","💎 Geometry Caverns","⚔ Equation Forge","🔭 Algebra Observatory"]
  },
  "📚 Reading & Literature": {
    guide:"🦉 Owl Librarian",
    path:["🌲 Story Forest","🐉 Dragon Library","🧚 Fairy Tale Grove","🔍 Mystery Hall","✍ Writer Loft","🏛 Great Library"]
  },
  "✍ Writing": {
    guide:"🪶 Quillmaster Nora",
    path:["📝 Sentence Workshop","📜 Paragraph Hall","🏰 Story Builder","📔 Journal Nook","📚 Report Room","🎭 Dialogue Theater","🪶 Author Tower"]
  },
  "🔬 Science": {
    guide:"🧙 Wizard Scientist",
    path:["🦋 Insect Kingdom","🌱 Garden Grounds","🌱 Botany Conservatory","🧪 Chemistry Institute","⚡ Physics Forge","🌋 Earth Science","🌌 Astronomy Observatory"]
  },
  "🚀 Aerospace Engineering": {
    guide:"🚀 Mission Quartermaster",
    path:["🛩 Junior Builder Hangar","✈ Airframe Workshop","🌪 Aerodynamics Lab","🔬 Materials Bay","🚀 Rocket Yard","🛰 Orbital Control","📐 Mission Design Studio"]
  },
  "🍀 Celtic Heritage": {
    guide:"🎵 Bard Eamon",
    entrance:"🪨 Stone Circle Gate",
    path:["🪨 Stone Circle Gate","🍀 Clover Vale","🏰 Stone Fort Keep","🎵 Harp Hall","📜 Chronicle Grove","⚒ Craft Village","🌊 Sea Voyager Harbor","🏛 Heritage Museum"]
  },
  "🌎 Geography": {
    guide:"🧭 Cartographer Mira",
    path:["🗺 Map Hall","🏔 Mountain Reach","🌊 Riverlands","🏜 Desert Winds","🌲 Forest Realm","🌊 Ocean Realm","❄ Polar Frontier"]
  },
  "🧠 Logic": {
    guide:"⚙ Gearmaster Rowan",
    path:["🔐 Puzzle Vault","⚙ Machine Works","🔍 Detective Wing","♟ Strategy Hall","🧩 Code Cavern"]
  },
  "🧰 Life Skills": {
    guide:"🧰 Handy Hazel",
    path:["🍳 Cooking Guild","🧺 Laundry Hall","🌱 Garden Grounds","💰 Budget Borough","🔧 Repair Shop","🏠 Home Haven","🩹 Preparedness Post"]
  },
  "🎨 Arts": {
    guide:"🎨 Master Pippa",
    path:["🎨 Painting Studio","🎵 Music Hall","✂ Craft Cottage","🧱 Builder Workshop","🎭 Theater Stage","🖼 Gallery Hall"]
  }
};

const LR_ROOM_NPCS_UI = {
  "🍎 Counting Orchard":["🍎 Farmer Pip","🍏 Apple Collector Mina","🐿 Acorn Helper","🦉 Professor Numeron"],
  "🌲 Story Forest":["📖 Story Sprite","🦊 Fable Fox","🦉 Owl Librarian"],
  "🦋 Insect Kingdom":["🦋 Wingkeeper Luma","🐝 Bee Scout","🐜 Ant Captain","🧙 Wizard Scientist"],
  "🧪 Chemistry Institute":["🧪 Beaker Sprite","🥽 Lab Owl","💎 Crystal Keeper"],
  "⚡ Physics Forge":["⚡ Force Goblin","🧲 Magnet Mouse","⚙ Gear Helper"],
  "🌌 Astronomy Observatory":["🔭 Telescope Keeper Mira","⭐ Star Scribe","🌙 Moon Moth"],
  "🛩 Junior Builder Hangar":["🚀 Mission Quartermaster","🛠 Workshop Goblin Brik","🦉 Navigator Owl"],
  "🍀 Clover Vale":["🎵 Bard Eamon","🍀 Clover Keeper Saoirse","🐑 Shepherd Aoife"],
  "🏰 Stone Fort Keep":["🏰 Caretaker Bran","🪨 Stone Mason Finn","📜 History Hare"],
  "🎵 Harp Hall":["🎵 Harp Keeper Nia","🪕 Tune Sprite","📯 Rhythm Fox"],
  "🏛 Heritage Museum":["🏛 Curator Maeve","📜 Scroll Keeper Ronan","🍀 Heritage Guide"],
  "🗺 Map Hall":["🧭 Cartographer Mira","🌍 Globe Goblin","📍 Pin Sprite"],
  "🔐 Puzzle Vault":["🧠 Riddle Raven","🔑 Lock Sprite","⚙ Gearmaster Rowan"],
  "🍳 Cooking Guild":["🍳 Cook Marla","🥄 Spoon Helper","🧼 Cleanup Sprite"],
  "🎨 Painting Studio":["🎨 Master Pippa","🖌 Brushling","🌈 Color Fairy"]
};

function lrAtlasEscape(v){
  if(typeof lrHomeRendererEscape === "function") return lrHomeRendererEscape(v);
  return String(v ?? "").replace(/[&<>"']/g, function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c];});
}

function lrTeleportToSubjectRoom(room){
  if(typeof state !== "undefined"){
    if(!state.currentRoom) state.currentRoom = {};
    state.currentRoom[activeChild] = room;
    if(typeof save === "function") save();
  }
  openSubjectAtlasRoom(room);
}

function lrRenderSubjectPath(subjectName, data){
  return '<div class="lrAtlasSubjectCard">' +
    '<h3>' + lrAtlasEscape(subjectName) + '</h3>' +
    '<p><b>Guide:</b> ' + lrAtlasEscape(data.guide) + '</p>' +
    (data.entrance ? '<p><b>Entrance:</b> ' + lrAtlasEscape(data.entrance) + '</p>' : '') +
    '<div class="lrAtlasPath">' + data.path.map(function(room, idx){
      return '<button onclick="lrTeleportToSubjectRoom(\'' + lrAtlasEscape(room) + '\')"><b>' + (idx+1) + '.</b> ' + lrAtlasEscape(room) + '</button>';
    }).join("") + '</div>' +
  '</div>';
}

function openSubjectAtlasUI(){
  actionTitle.textContent = "📚 Subject Atlas";
  actionText.innerHTML =
    '<div class="lrSubjectAtlasUI">' +
      '<div class="lrAtlasIntro"><h3>Choose a subject path</h3><p>Each subject now has a clear hub, guide NPC, and linear progression. Celtic Heritage is placed here clearly through the Stone Circle Gate.</p></div>' +
      '<div class="lrAtlasGrid">' + Object.keys(LR_SUBJECT_ATLAS_UI).map(function(name){
        return lrRenderSubjectPath(name, LR_SUBJECT_ATLAS_UI[name]);
      }).join("") + '</div>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Subject Atlas");
}

function openSubjectAtlasRoom(room){
  const npcs = LR_ROOM_NPCS_UI[room] || ["🙂 Friendly Traveler","📜 Local Guide","✨ Curious Helper"];
  actionTitle.textContent = room;
  actionText.innerHTML =
    '<div class="lrRoomFocusPanel">' +
      '<h3>' + lrAtlasEscape(room) + '</h3>' +
      '<p>This room is part of a guided subject path. Talk to NPCs, start a lesson, or continue to the next room in the path.</p>' +
      '<h3>NPCs here</h3>' +
      '<div class="lrNpcGrid">' + npcs.map(function(npc){
        return '<button onclick="openSubjectNpcTalk(\'' + lrAtlasEscape(npc) + '\', \'' + lrAtlasEscape(room) + '\')">' + lrAtlasEscape(npc) + '</button>';
      }).join("") + '</div>' +
      '<div class="lrRoomActions">' +
        '<button onclick="openLessonLauncher()">📘 Start Lesson</button>' +
        '<button onclick="openSubjectAtlasUI()">📚 Back to Subject Atlas</button>' +
        '<button onclick="openWorldMapEngine()">🗺 World Atlas</button>' +
      '</div>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup(room);
}

function openSubjectNpcTalk(npc, room){
  actionTitle.textContent = npc;
  actionText.innerHTML =
    '<div class="lrNpcTalkPanel">' +
      '<h3>' + lrAtlasEscape(npc) + '</h3>' +
      '<p>Welcome to ' + lrAtlasEscape(room) + '. This area has lessons, collections, and rewards. Follow the Subject Atlas path if you want a guided route.</p>' +
      '<p><b>Advice:</b> Complete a lesson, collect your spark, then move to the next room when ready.</p>' +
      '<button onclick="openSubjectAtlasRoom(\'' + lrAtlasEscape(room) + '\')">Back to room</button>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup(npc);
}
/* End Subject Atlas UI Pack */


/* Removed by 7.4X Stability: Sidebar Dropdown Cleanup Pack */


/* Home Only On Demand Patch */
function lrHideVisibleHomeOnMainScreen(){
  const selectors = [
    "#visibleHome",
    "#homeRenderer",
    "#homeView",
    ".visibleHome",
    ".homeRendererAlwaysVisible",
    ".lrVisibleHome",
    ".lrHomeRenderer.mainScreen",
    "[data-home-renderer='main']"
  ];

  selectors.forEach(function(sel){
    document.querySelectorAll(sel).forEach(function(el){
      el.classList.add("lrHomeOnlyHidden");
      el.style.display = "none";
    });
  });

  document.querySelectorAll("section, div, aside").forEach(function(el){
    const txt = (el.textContent || "").trim();
    if(txt.includes("Visible Home") || txt.includes("Home Renderer")){
      const hasSlots = txt.includes("Main Room") || txt.includes("Cozy Cottage") || txt.includes("Pet Corner") || txt.includes("Seasonal Rooms");
      const insidePopup = el.closest(".popup") || el.closest("#actionPopup") || el.closest(".modal") || el.closest(".overlay");
      if(hasSlots && !insidePopup){
        el.classList.add("lrHomeOnlyHidden");
        el.style.display = "none";
      }
    }
  });
}

document.addEventListener("DOMContentLoaded", function(){
  lrHideVisibleHomeOnMainScreen();
});

const lrHomeOnlyOriginalOpenHomeRenderer = (typeof openHomeRenderer === "function") ? openHomeRenderer : null;
if(lrHomeOnlyOriginalOpenHomeRenderer){
  openHomeRenderer = function(tab){
    lrHomeOnlyOriginalOpenHomeRenderer(tab);
  };
}
/* End Home Only On Demand Patch */


/* Lesson Launcher Engine Pack 1 */
const LR_LESSON_LAUNCHER_SUBJECTS = {
  science:["Volcano Reach","Dinosaur Basin","Insect Kingdom","Space Observatory","Weather Academy","Aerospace Engineering"],
  reading:["Story Forest","Dragon Library","Mystery Hall","Great Library"],
  math:["Counting Orchard","Merchant Square","Fraction Castle","Equation Forge","Geometry Caverns","Algebra Observatory"],
  history:["Ancient Worlds","Celtic Heritage","Artifact Hall","Chronicle Tower"],
  geography:["Map Hall","Mountain Reach","Riverlands","Ocean Realm"],
  life:["Cooking Guild","Garden Grounds","Budget Borough","Repair Shop"],
  arts:["Painting Studio","Music Hall","Craft Cottage","Theater Stage"]
};

function lrEnsureLessonLauncherState(){
  if(!state.lessonLauncher) state.lessonLauncher = {};
  if(!state.lessonLauncher[activeChild]) state.lessonLauncher[activeChild] = {completed:[], currentSubject:"science"};
  return state.lessonLauncher[activeChild];
}

function lrGenerateLessonPrompt(subject, zone){
  const samples = {
    science:[
      ["multiple_choice","Which answer best matches this science topic?","Observe carefully and choose the strongest answer."],
      ["sequence_order","Put the steps in the best order.","Think about what must happen first, next, and last."],
      ["matching","Match each idea to its meaning.","Use clues from the words."]
    ],
    reading:[
      ["multiple_choice","Which detail best supports the story idea?","Look for proof from the text."],
      ["sequence_order","Put the story events in order.","Beginning, middle, and end matter."],
      ["fill_blank","Complete the sentence with the best word.","Use context clues."]
    ],
    math:[
      ["fill_blank","Solve the problem.","Check your work before answering."],
      ["multiple_choice","Choose the correct answer.","Use number sense and careful thinking."],
      ["sorting","Sort the items into the correct group.","Compare the values or shapes."]
    ],
    history:[
      ["sequence_order","Put these events or ideas in order.","Think about past, present, and change over time."],
      ["matching","Match the artifact or idea to its use.","Use evidence like a historian."],
      ["multiple_choice","Which answer best fits this history topic?","Look for the most reasonable answer."]
    ]
  };
  const pool = samples[subject] || samples.science;
  const pick = pool[Math.floor(Math.random()*pool.length)];
  return {
    id:"live_" + subject + "_" + Date.now(),
    subject,
    zone,
    type:pick[0],
    question:pick[1],
    hint:pick[2],
    reward:"✨ 25 Learning Crowns"
  };
}

function lrStartLesson(subject, zone){
  const l = lrGenerateLessonPrompt(subject, zone);
  window.__activeLearningRealmsLesson = l;
  actionTitle.textContent = "📘 Lesson";
  actionText.innerHTML =
    '<div class="lrLessonCard">' +
      '<h3>' + lrHomeRendererEscape(zone) + '</h3>' +
      '<p><b>Subject:</b> ' + lrHomeRendererEscape(subject) + '</p>' +
      '<p><b>Type:</b> ' + lrHomeRendererEscape(l.type) + '</p>' +
      '<p class="lrLessonQuestion">' + lrHomeRendererEscape(l.question) + '</p>' +
      '<p><i>' + lrHomeRendererEscape(l.hint) + '</i></p>' +
      '<textarea class="lrLessonAnswer" id="lrLessonAnswer" placeholder="Type the answer, notes, or parent-approved response here..."></textarea>' +
      '<button onclick="lrCompleteLiveLesson()">Complete Lesson</button>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Lesson");
}

function lrCompleteLiveLesson(){
  const l = window.__activeLearningRealmsLesson;
  if(!l) return;
  const s = lrEnsureLessonLauncherState();
  s.completed.push({id:l.id,subject:l.subject,zone:l.zone,date:new Date().toISOString()});
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : null;
  if(econ) econ.crowns += 25;
  if(typeof save === "function") save();
  actionTitle.textContent = "✅ Lesson Complete";
  actionText.innerHTML = '<div class="journalPage"><h3>Great work!</h3><p>You completed a lesson in ' + lrHomeRendererEscape(l.zone) + '.</p><p>Reward: ✨ 25 Learning Crowns</p></div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Lesson Complete");
}

function openLessonLauncher(subject){
  const s = lrEnsureLessonLauncherState();
  const active = subject || s.currentSubject || "science";
  s.currentSubject = active;
  const tabs = Object.keys(LR_LESSON_LAUNCHER_SUBJECTS).map(function(key){
    const cls = key === active ? " active" : "";
    return '<button class="lrLessonTab' + cls + '" onclick="openLessonLauncher(\'' + key + '\')">' + lrHomeRendererEscape(key) + '</button>';
  }).join("");
  const zones = LR_LESSON_LAUNCHER_SUBJECTS[active] || [];
  actionTitle.textContent = "📘 Lesson Launcher";
  actionText.innerHTML =
    '<div class="lrLessonLauncher">' +
      '<div class="lrLessonTabs">' + tabs + '</div>' +
      '<div class="lrLessonHeader"><h3>' + lrHomeRendererEscape(active.toUpperCase()) + '</h3><p>Pick a zone and start a parent-guided lesson. This is the bridge from lesson slots to real authored curriculum.</p><b>Completed lessons: ' + s.completed.length + '</b></div>' +
      '<div class="lrLessonZoneGrid">' + zones.map(function(z){ return '<button onclick="lrStartLesson(\'' + active + '\', \'' + lrHomeRendererEscape(z) + '\')">' + lrHomeRendererEscape(z) + '</button>'; }).join("") + '</div>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Lesson Launcher");
}
/* End Lesson Launcher Engine Pack 1 */


/* Daily Quest Board Engine Pack 1 */
const LR_DAILY_QUEST_POOLS = [
  {id:"dq_read_1", title:"📚 Read & Record", task:"Complete one reading lesson or book journal activity.", reward:"✨ 50 Crowns", crowns:50, track:"reading"},
  {id:"dq_math_1", title:"🧮 Number Practice", task:"Complete two math practice questions.", reward:"✨ 50 Crowns", crowns:50, track:"math"},
  {id:"dq_science_1", title:"🔬 Science Spark", task:"Complete one science lesson or observation.", reward:"✨ 60 Crowns", crowns:60, track:"science"},
  {id:"dq_logic_1", title:"🧠 Puzzle Time", task:"Complete one logic puzzle or sequence challenge.", reward:"✨ 45 Crowns", crowns:45, track:"logic"},
  {id:"dq_write_1", title:"✍ Writer's Mark", task:"Write one sentence, paragraph, journal note, or project evidence entry.", reward:"✨ 55 Crowns", crowns:55, track:"writing"},
  {id:"dq_project_1", title:"🧪 Project Step", task:"Make progress on one project lab task.", reward:"✨ 75 Crowns", crowns:75, track:"project"},
  {id:"dq_house_1", title:"🏠 Display Something", task:"Place one earned item in the house or museum.", reward:"✨ 35 Crowns", crowns:35, track:"collection"}
];

function lrTodayKey(){
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
}

function lrEnsureDailyQuestState(){
  if(!state.dailyQuestBoard) state.dailyQuestBoard = {};
  if(!state.dailyQuestBoard[activeChild]) state.dailyQuestBoard[activeChild] = {};
  const s = state.dailyQuestBoard[activeChild];
  const today = lrTodayKey();
  if(s.date !== today){
    s.date = today;
    s.completed = [];
    s.claimed = [];
    s.quests = LR_DAILY_QUEST_POOLS.slice(0,5).map(q => q.id);
  }
  return s;
}

function lrQuestById(id){
  return LR_DAILY_QUEST_POOLS.find(q => q.id === id) || LR_DAILY_QUEST_POOLS[0];
}

function lrCompleteDailyQuest(id){
  const s = lrEnsureDailyQuestState();
  if(s.completed.indexOf(id) === -1) s.completed.push(id);
  if(typeof save === "function") save();
  openDailyQuestBoard();
}

function lrClaimDailyQuest(id){
  const s = lrEnsureDailyQuestState();
  if(s.completed.indexOf(id) === -1 || s.claimed.indexOf(id) !== -1){
    openDailyQuestBoard();
    return;
  }
  const q = lrQuestById(id);
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : null;
  if(econ) econ.crowns += q.crowns;
  else{
    if(!state.learningCrowns) state.learningCrowns = {};
    state.learningCrowns[activeChild] = (state.learningCrowns[activeChild] || 0) + q.crowns;
  }
  s.claimed.push(id);
  if(typeof save === "function") save();
  openDailyQuestBoard();
}

function lrRenderDailyQuest(id){
  const s = lrEnsureDailyQuestState();
  const q = lrQuestById(id);
  const done = s.completed.indexOf(id) !== -1;
  const claimed = s.claimed.indexOf(id) !== -1;
  let button = '<button onclick="lrCompleteDailyQuest(\'' + id + '\')">Mark Done</button>';
  if(done && !claimed) button = '<button onclick="lrClaimDailyQuest(\'' + id + '\')">Claim</button>';
  if(claimed) button = '<button disabled>Claimed</button>';
  return '<div class="lrDailyQuest">' +
    '<h3>' + lrHomeRendererEscape(q.title) + '</h3>' +
    '<p>' + lrHomeRendererEscape(q.task) + '</p>' +
    '<b>' + lrHomeRendererEscape(q.reward) + '</b>' +
    button +
  '</div>';
}

function openDailyQuestBoard(){
  const s = lrEnsureDailyQuestState();
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : {crowns:""};
  const finished = s.claimed.length;
  actionTitle.textContent = "📋 Daily Quest Board";
  actionText.innerHTML =
    '<div class="lrDailyBoard">' +
      '<div class="lrDailyHeader"><h3>Today: ' + lrHomeRendererEscape(s.date) + '</h3><p>Finish learning tasks, then claim crowns. Parent can decide what counts as done.</p><b>✨ Crowns: ' + (econ.crowns ?? "") + '</b><br><b>Progress: ' + finished + ' / ' + s.quests.length + '</b></div>' +
      '<div class="lrDailyGrid">' + s.quests.map(lrRenderDailyQuest).join("") + '</div>' +
      '<div class="lrDailyNote">This is intentionally parent-guided. The game tracks the reward loop; you decide when the real learning effort was good enough.</div>' +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Daily Quest Board");
}
/* End Daily Quest Board Engine Pack 1 */


/* Reward Code Redeemer Engine Pack 1 */
const LR_BUILTIN_REWARD_CODES = {
  "READ-STAR-001": {type:"crowns", amount:100, label:"✨ 100 Learning Crowns"},
  "MATH-HERO-777": {type:"item", item:"🧮 Math Chest", label:"🧮 Math Chest"},
  "BOOK-DRAGON-42": {type:"item", item:"🐉 Dragon Egg", label:"🐉 Dragon Egg"},
  "SCIENCE-MASTER": {type:"item", item:"⭐ Star Fragments x10", label:"⭐ Star Fragments x10"},
  "CASTLE-UPGRADE": {type:"item", item:"🏰 Expansion Permit", label:"🏰 Expansion Permit"},
  "FAMILY-MOVIE": {type:"item", item:"🎬 Festival Token Pack", label:"🎬 Festival Token Pack"},
  "LEGEND-STAR-DRAGON": {type:"item", item:"⭐ Star Dragon Hatch Token", label:"⭐ Star Dragon Hatch Token"},
  "LEGEND-CASTLE-WING": {type:"item", item:"🏰 Castle Wing Permit", label:"🏰 Castle Wing Permit"},
  "LEGEND-FAIRY-QUEEN": {type:"item", item:"👑 Fairy Queen Throne", label:"👑 Fairy Queen Throne"},
  "LEGEND-COSMIC-CROWN": {type:"item", item:"👑 Cosmic Crown", label:"👑 Cosmic Crown"},
  "LEGEND-GRAND-LIBRARY": {type:"item", item:"🏰 Grand Library Wing", label:"🏰 Grand Library Wing"},
  "LEGEND-MASTER-REALMS": {type:"item", item:"👑 Keeper of Learning Realms Castle", label:"👑 Keeper of Learning Realms Castle"}
};

function lrNormalizeRewardCode(code){
  return String(code || "").trim().toUpperCase();
}

function lrEnsureRedeemedCodes(){
  if(!state.redeemedCodes) state.redeemedCodes = {};
  if(!state.redeemedCodes[activeChild]) state.redeemedCodes[activeChild] = [];
  return state.redeemedCodes[activeChild];
}

function lrGrantRewardCodeReward(reward){
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : null;
  if(reward.type === "crowns"){
    if(econ) econ.crowns += reward.amount;
    else{
      if(!state.learningCrowns) state.learningCrowns = {};
      state.learningCrowns[activeChild] = (state.learningCrowns[activeChild] || 0) + reward.amount;
    }
  }else{
    if(!state.materials) state.materials = {};
    if(!state.materials[activeChild]) state.materials[activeChild] = [];
    state.materials[activeChild].push(reward.item);
  }
  if(typeof save === "function") save();
}

function lrRedeemRewardCode(){
  const input = document.getElementById("lrRewardCodeInput");
  const code = lrNormalizeRewardCode(input ? input.value : "");
  const redeemed = lrEnsureRedeemedCodes();

  if(!code){
    openRewardCodeRedeemer("Enter a code first.");
    return;
  }

  if(redeemed.indexOf(code) !== -1){
    openRewardCodeRedeemer("That code was already redeemed by this player.");
    return;
  }

  const reward = LR_BUILTIN_REWARD_CODES[code];
  if(!reward){
    openRewardCodeRedeemer("That code was not found in this build. Check spelling or add it to the master vault later.");
    return;
  }

  lrGrantRewardCodeReward(reward);
  redeemed.push(code);
  if(typeof save === "function") save();
  openRewardCodeRedeemer("Redeemed: " + reward.label);
}

function openRewardCodeRedeemer(message){
  const econ = (typeof lrEnsureEconomyState === "function") ? lrEnsureEconomyState() : {crowns:""};
  const redeemed = lrEnsureRedeemedCodes();
  actionTitle.textContent = "🎁 Reward Shrine";
  actionText.innerHTML =
    '<div class="lrRedeemer">' +
      '<div class="lrRedeemerWallet">✨ Learning Crowns: <b>' + (econ.crowns ?? "") + '</b></div>' +
      '<h3>Enter parent reward code</h3>' +
      '<input id="lrRewardCodeInput" class="lrRewardCodeInput" placeholder="TYPE-CODE-HERE" />' +
      '<button onclick="lrRedeemRewardCode()">Redeem Code</button>' +
      (message ? '<div class="lrRedeemerMessage">' + lrHomeRendererEscape(message) + '</div>' : '') +
      '<div class="lrRedeemerNote">Parent codes should be handed out for real life wins: books finished, big effort, chores, kindness, projects, or special celebrations.</div>' +
      '<h3>Redeemed by this player</h3>' +
      '<p>' + (redeemed.length ? redeemed.map(lrHomeRendererEscape).join("<br>") : "None yet") + '</p>' +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Reward Shrine");
}
/* End Reward Code Redeemer Engine Pack 1 */


/* Shop Renderer Engine Pack 1 */
const LR_SHOP_CATALOGS = {
  home:{
    title:"🏠 Home Decor Shop",
    items:[
      ["☁ Cloud Lamp",350,"decor"],
      ["🌈 Prism Lamp",600,"decor"],
      ["🐉 Dragon Nest",2500,"dragon"],
      ["🍀 Clover Banner",450,"heritage"],
      ["🔭 Telescope Display",1200,"space"],
      ["🎃 Pumpkin Throne",3000,"seasonal"],
      ["🎄 Giant Tree",2200,"seasonal"]
    ]
  },
  tailor:{
    title:"👕 Tailor Boutique",
    items:[
      ["☁ Cloud Hood",500,"head"],
      ["❄ Frost Scarf",700,"neck"],
      ["🌈 Rainbow Cape",1200,"back"],
      ["🚀 Aerospace Jacket",1600,"torso"],
      ["🐉 Scale Mantle",2500,"torso"],
      ["👑 Cosmic Crown",5000,"head"]
    ]
  },
  companions:{
    title:"🐾 Companion House",
    items:[
      ["🦉 Owl Egg Token",1500,"companion"],
      ["🧚 Fairy Egg Token",3000,"companion"],
      ["🐉 Dragon Egg Fragment",2000,"companion"],
      ["🐾 Pet Bed",350,"home"],
      ["💎 Crystal Nest",1800,"home"]
    ]
  },
  museum:{
    title:"🏛 Museum Exchange",
    items:[
      ["🦴 Fossil Case",600,"museum"],
      ["🌌 Galaxy Display",1400,"museum"],
      ["🧪 Lab Shelf",900,"museum"],
      ["🍀 Heritage Display Case",1000,"museum"],
      ["👑 Legend Case",4000,"museum"]
    ]
  },
  engineering:{
    title:"🚀 Engineering Depot",
    items:[
      ["✈ Aircraft Shelf",850,"aerospace"],
      ["🚀 Launch Pad Model",1400,"aerospace"],
      ["🛰 Satellite Mobile",1800,"aerospace"],
      ["📐 Engineering Board",900,"aerospace"],
      ["⭐ Mission Cape",3500,"wardrobe"]
    ]
  }
};

function lrEnsureEconomyState(){
  if(!state.economy) state.economy = {};
  if(!state.economy[activeChild]) state.economy[activeChild] = {crowns:500, purchases:[]};
  return state.economy[activeChild];
}

function lrShopOwnedPurchases(){
  return lrEnsureEconomyState().purchases || [];
}

function lrBuyShopItem(shopKey, itemName, cost){
  const econ = lrEnsureEconomyState();
  if(econ.purchases.indexOf(itemName) !== -1){
    actionTitle.textContent = "Already Owned";
    actionText.innerHTML = '<div class="journalPage"><h3>Already Owned</h3><p>You already own ' + lrHomeRendererEscape(itemName) + '.</p></div>';
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Already Owned");
    return;
  }
  if(econ.crowns < cost){
    actionTitle.textContent = "Not Enough Crowns";
    actionText.innerHTML = '<div class="journalPage"><h3>Keep Learning!</h3><p>You need ' + cost + ' ✨ Learning Crowns for ' + lrHomeRendererEscape(itemName) + '.</p><p>Current crowns: ' + econ.crowns + '</p></div>';
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Not Enough Crowns");
    return;
  }
  econ.crowns -= cost;
  econ.purchases.push(itemName);
  if(!state.materials) state.materials = {};
  if(!state.materials[activeChild]) state.materials[activeChild] = [];
  state.materials[activeChild].push(itemName);
  if(typeof save === "function") save();
  openShopRenderer(shopKey);
}

function lrRenderShopItem(shopKey, item){
  const owned = lrShopOwnedPurchases().indexOf(item[0]) !== -1;
  const btn = owned ? '<button disabled>Owned</button>' : '<button onclick="lrBuyShopItem(\'' + shopKey + '\', \'' + lrHomeRendererEscape(item[0]) + '\',' + item[1] + ')">Buy</button>';
  return '<div class="lrShopItem"><div class="lrShopIcon">' + lrHomeRendererEscape(String(item[0]).split(" ")[0]) + '</div><div><b>' + lrHomeRendererEscape(item[0]) + '</b><br><span>' + item[1] + ' ✨ Crowns</span><br><small>' + lrHomeRendererEscape(item[2]) + '</small></div>' + btn + '</div>';
}

function openShopRenderer(shopKey){
  const active = shopKey || "home";
  const econ = lrEnsureEconomyState();
  const shop = LR_SHOP_CATALOGS[active] || LR_SHOP_CATALOGS.home;
  const tabs = Object.keys(LR_SHOP_CATALOGS).map(function(key){
    const cls = key === active ? " active" : "";
    return '<button class="lrShopTab' + cls + '" onclick="openShopRenderer(\'' + key + '\')">' + lrHomeRendererEscape(LR_SHOP_CATALOGS[key].title) + '</button>';
  }).join("");

  actionTitle.textContent = "🏪 Shops";
  actionText.innerHTML =
    '<div class="lrShopRenderer">' +
      '<div class="lrShopWallet">✨ Learning Crowns: <b>' + econ.crowns + '</b></div>' +
      '<div class="lrShopTabs">' + tabs + '</div>' +
      '<div class="lrShopTitle">' + lrHomeRendererEscape(shop.title) + '</div>' +
      '<div class="lrShopGrid">' + shop.items.map(function(item){ return lrRenderShopItem(active,item); }).join("") + '</div>' +
      '<div class="lrShopNote">Best items should stay expensive. Parent reward codes, boss exams, projects, and long learning chains feed this economy.</div>' +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Shops");
}
/* End Shop Renderer Engine Pack 1 */


/* World Map Engine */
const LR_WORLD_ZONES=[
"🏰 Kingdom","🌋 Volcano Reach","🦖 Dinosaur Basin","🦋 Insect Kingdom","🌍 Biome World",
"⚡ Energy Station","🧪 Chemistry Works","🌌 Deep Space","🌱 Botany","🌦 Weather",
"🏛 Museum","🏠 Home","🧚 Fairy Grove","🐉 Dragon Peaks","🎄 Holiday Village"
];
function openWorldMapEngine(){
actionTitle.textContent="🗺 World Map";
actionText.innerHTML="<h3>Learning Realms Atlas</h3><p>"+LR_WORLD_ZONES.join(" ➜ ")+"</p><p><b>Future:</b> route unlocking, minimap, travel requirements, biome completion gates, seasonal events.</p><p>Legendary lands should unlock only after mastery chains.</p>";
if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("World Map");
}
/* End World Map */


/* Crafting Renderer Engine */
const LR_CRAFT_STATIONS=["⚒ Forge","🪵 Woodworking","🍳 Kitchen","⚗ Alchemy","🧵 Tailor","🪴 Garden","🔬 Science","🎄 Seasonal"];
const LR_CRAFT_RECIPES=[
"🌋 Volcano Display = 🪨 Basalt + 💎 Quartz + 🔥 Ember Glass",
"⭐ Constellation Mobile = ⭐ Star Fragment + 🌙 Moon Stone + 🌌 Nebula Crystal",
"🦖 Fossil Showcase = 🦴 Fossil Fragment + 🪨 Shale + 🪶 Ancient Feather",
"🧚 Fairy Lamp = 🌸 Blossom + ✨ Light Crystal + 🧚 Fairy Dust",
"🌌 Cosmic Winter Set = 🌈 Rainbow Cape + ❄ Frost Scarf + 👑 Crown"
];
function openCraftingRenderer(){
actionTitle.textContent="🔨 Crafting";
actionText.innerHTML="<h3>Stations</h3><p>"+LR_CRAFT_STATIONS.join("<br>")+"</p><h3>Recipes</h3><p>"+LR_CRAFT_RECIPES.join("<br><br>")+"</p><p><b>Legendary items should require weeks of learning and collecting.</b></p>";
if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Crafting");
}
/* End Crafting */


/* Companion Engine */
const LR_COMPANIONS={
fairy:["🧚 Garden Fairy","🌙 Moon Fairy","💎 Crystal Fairy","🎄 Holiday Fairy"],
dragon:["🔥 Ember Dragon","🌲 Forest Dragon","❄ Frost Dragon","⭐ Star Dragon"],
study:["🦉 Owl","🪶 Raven","🎵 Songbird","📚 Scholar Owl"]
};
function openCompanionEngine(){
actionTitle.textContent="🐾 Companions";
actionText.innerHTML=`<h3>Legendary companions are HARD earned</h3>
<p>⭐ Star Dragon: 300 space mastery + museum completion + rare relic chain</p>
<p>🦉 Scholar Owl: reading mastery + library collection</p>
<p>🧚 Crystal Fairy: botany + weather + seasonal chain</p>
<p>Rooms: Dragon Nest • Fairy Garden • Owl Perch • Pet Corner</p>
<p>Progression: Learn → Egg → Hatch → Bond → Legendary</p>`;
if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Companions");
}
/* End Companion Engine */


/* Museum Renderer Engine Pack 1 */
const LR_MUSEUM_WINGS = {
  fossils:{
    title:"🦖 Fossil Wing",
    flavor:"Bones, tracks, eggs, amber, and ancient life displays.",
    slots:[
      ["fossil_case","🦴 Fossil Case"],
      ["track_display","👣 Track Display"],
      ["egg_display","🥚 Egg Display"],
      ["amber_case","💎 Amber Case"],
      ["skeleton_wall","🦖 Skeleton Wall"],
      ["ancient_plants","🌿 Ancient Plants"]
    ]
  },
  space:{
    title:"🌌 Space Wing",
    flavor:"Moon stones, stars, planets, and deep sky relics.",
    slots:[
      ["moon_case","🌙 Moon Case"],
      ["planet_shelf","🪐 Planet Shelf"],
      ["star_chart","⭐ Star Chart"],
      ["comet_case","☄ Comet Case"],
      ["galaxy_display","🌌 Galaxy Display"],
      ["telescope_corner","🔭 Telescope Corner"]
    ]
  },
  insects:{
    title:"🦋 Insectarium",
    flavor:"Wings, beetles, pollinators, webs, and tiny world collections.",
    slots:[
      ["wing_wall","🦋 Wing Wall"],
      ["beetle_case","🪲 Beetle Case"],
      ["pollinator_garden","🐝 Pollinator Garden"],
      ["web_display","🕸 Web Display"],
      ["night_bug_case","🌙 Night Bug Case"],
      ["chrysalis_shelf","🐛 Chrysalis Shelf"]
    ]
  },
  biomes:{
    title:"🌍 Biome Hall",
    flavor:"Forest, desert, arctic, rainforest, and ocean exhibits.",
    slots:[
      ["forest_display","🌲 Forest Display"],
      ["desert_display","🏜 Desert Display"],
      ["arctic_display","❄ Arctic Display"],
      ["rainforest_display","🌴 Rainforest Display"],
      ["ocean_display","🌊 Ocean Display"],
      ["world_seed","🌍 World Relic"]
    ]
  },
  science:{
    title:"🔬 Science Gallery",
    flavor:"Chemistry, energy, weather, botany, and lab discoveries.",
    slots:[
      ["chemistry_case","🧪 Chemistry Case"],
      ["energy_case","⚡ Energy Case"],
      ["weather_case","🌦 Weather Case"],
      ["botany_case","🌱 Botany Case"],
      ["crystal_case","💎 Crystal Case"],
      ["lab_shelf","⚗ Lab Shelf"]
    ]
  },
  seasonal:{
    title:"🎉 Seasonal Gallery",
    flavor:"Holiday event treasures and seasonal memories.",
    slots:[
      ["christmas_display","🎄 Christmas Display"],
      ["halloween_display","🎃 Halloween Display"],
      ["easter_display","🐣 Easter Display"],
      ["harvest_display","🦃 Harvest Display"],
      ["winter_display","☃ Winter Display"],
      ["new_year_display","🎆 New Year Display"]
    ]
  },
  fantasy:{
    title:"🧚 Fantasy Relic Hall",
    flavor:"Fairy, dragon, unicorn, and magical discoveries.",
    slots:[
      ["fairy_case","🧚 Fairy Case"],
      ["dragon_case","🐉 Dragon Case"],
      ["crystal_nest","💎 Crystal Nest"],
      ["mythic_banner","🏰 Mythic Banner"],
      ["magic_lamp","✨ Magic Lamp"],
      ["legend_throne","👑 Legend Throne"]
    ]
  },
  achievements:{
    title:"🏆 Achievement Hall",
    flavor:"Banners, crowns, mantles, and proof of hard earned mastery.",
    slots:[
      ["reading_banner","📚 Reading Banner"],
      ["science_banner","🔬 Science Banner"],
      ["math_banner","🧮 Math Banner"],
      ["history_banner","🏛 History Banner"],
      ["kingdom_banner","🏰 Kingdom Banner"],
      ["legend_case","👑 Legend Case"]
    ]
  }
};

function lrEnsureMuseumRenderState(){
  if(!state.museumRenderer) state.museumRenderer = {};
  if(!state.museumRenderer[activeChild]) state.museumRenderer[activeChild] = {};
  return state.museumRenderer[activeChild];
}

function lrMuseumOwnedItems(){
  const items = ["(empty)"];

  function addList(list){
    (list || []).forEach(function(item){
      if(items.indexOf(item) === -1) items.push(item);
    });
  }

  addList((state.museum && state.museum[activeChild]) || []);
  addList((state.craftedItems && state.craftedItems[activeChild]) || []);
  addList((state.materials && state.materials[activeChild]) || []);

  addList([
    "🦖 Golden Tooth","💎 Amber Relic","🦴 Ancient Skeleton Key","🪶 First Feather",
    "🌠 Fallen Star","💎 Cosmic Core","🌙 First Moon Stone","🪐 Ancient Planet Tablet",
    "👑 Queen Wing","✨ Golden Chrysalis","🪲 Ancient Beetle Shell","🦋 First Butterfly",
    "🌲 World Seed","🏜 Sun Relic","❄ Ancient Ice","🌺 First Orchid","🌊 Deep Pearl",
    "⚡ Eternal Spark","☀ Sun Core","🌊 Flow Relic","🔥 Heart Ember",
    "⚗ Ancient Flask","💎 Prism Core","⚛ Golden Atom","🧪 Master Crystal",
    "🌈 First Rainbow","⚡ Eternal Lightning","☁ Sky Core",
    "🌺 First Blossom","🌳 World Sapling","🍄 Ancient Spore","💎 Emerald Seed",
    "🎄 Star Tree Topper","🧙 Witch Charm","🍂 Golden Acorn","🥚 Golden Egg",
    "👑 Fairy Queen Crown","👑 Dragon Throne","🏆 Grove Scholar Banner","👑 Crown of Learning"
  ]);

  return items;
}

function lrSetMuseumSlot(slot, value){
  const m = lrEnsureMuseumRenderState();
  m[slot] = value;
  if(typeof save === "function") save();
  openMuseumRenderer(window.__activeMuseumWing || "fossils");
}

function lrRenderMuseumSlot(slotId, label){
  const m = lrEnsureMuseumRenderState();
  const current = m[slotId] || "(empty)";
  const options = lrMuseumOwnedItems().map(function(item){
    const selected = item === current ? " selected" : "";
    return '<option value="' + lrHomeRendererEscape(item) + '"' + selected + '>' + lrHomeRendererEscape(item) + '</option>';
  }).join("");

  const icon = String(label).split(" ")[0] || "🏛";
  const labelText = String(label).split(" ").slice(1).join(" ") || label;

  return '<div class="lrMuseumSlot">' +
    '<div class="lrMuseumSlotIcon">' + icon + '</div>' +
    '<div class="lrMuseumSlotBody">' +
      '<b>' + lrHomeRendererEscape(labelText) + '</b>' +
      '<select onchange="lrSetMuseumSlot(\'' + lrHomeRendererEscape(slotId) + '\', this.value)">' + options + '</select>' +
    '</div>' +
  '</div>';
}

function lrMuseumCompletionForWing(wing){
  const m = lrEnsureMuseumRenderState();
  const slots = LR_MUSEUM_WINGS[wing].slots;
  const filled = slots.filter(function(pair){
    return m[pair[0]] && m[pair[0]] !== "(empty)";
  }).length;
  return {filled:filled,total:slots.length,percent:Math.round((filled/slots.length)*100)};
}

function openMuseumRenderer(wing){
  const activeWing = wing || "fossils";
  window.__activeMuseumWing = activeWing;
  const data = LR_MUSEUM_WINGS[activeWing] || LR_MUSEUM_WINGS.fossils;
  const c = lrMuseumCompletionForWing(activeWing);

  const tabs = Object.keys(LR_MUSEUM_WINGS).map(function(key){
    const done = lrMuseumCompletionForWing(key);
    const cls = key === activeWing ? " active" : "";
    return '<button class="lrMuseumTab' + cls + '" onclick="openMuseumRenderer(\'' + key + '\')">' +
      lrHomeRendererEscape(LR_MUSEUM_WINGS[key].title) + '<br><small>' + done.filled + "/" + done.total + '</small></button>';
  }).join("");

  actionTitle.textContent = "🏛 Museum";
  actionText.innerHTML =
    '<div class="lrMuseumRenderer">' +
      '<div class="lrMuseumTabs">' + tabs + '</div>' +
      '<div class="lrMuseumHeader"><h3>' + lrHomeRendererEscape(data.title) + '</h3><p>' + lrHomeRendererEscape(data.flavor) + '</p><div class="lrMuseumProgress"><span style="width:' + c.percent + '%"></span></div><b>' + c.percent + '% complete</b></div>' +
      '<div class="lrMuseumSlotGrid">' + data.slots.map(function(pair){ return lrRenderMuseumSlot(pair[0], pair[1]); }).join("") + '</div>' +
      '<div class="lrMuseumNote">Museum displays are meant to be hard earned. The best pieces should require mastery, rare drops, crafting, and achievements.</div>' +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Museum");
}
/* End Museum Renderer Engine Pack 1 */


/* Wardrobe / Paper Doll Engine Pack 1 */
const LR_WARDROBE_SLOTS = {
  head:"👑 Head",
  face:"😎 Face",
  neck:"📿 Neck",
  torso:"👕 Torso",
  hands:"🧤 Hands",
  back:"🦸 Back",
  legs:"👖 Legs",
  feet:"👢 Feet",
  accessory:"💍 Accessory",
  companion:"🐾 Companion Gear"
};

const LR_WARDROBE_KEYWORDS = {
  head:["crown","hood","hat","helm","circlet","cap"],
  face:["mask","goggles","glasses"],
  neck:["scarf","amulet","necklace","collar"],
  torso:["robe","cloak","mantle","apron","suit","tunic","armor","vest"],
  hands:["gloves","gauntlets"],
  back:["cape","wings","pack","satchel"],
  legs:["leggings","pants","skirt"],
  feet:["boots","shoes","sandals"],
  accessory:["ring","charm","token","badge","crest","ribbon"],
  companion:["saddle","pet","companion","owl","dragon","fairy","frog","butterfly"]
};

function lrEnsureWardrobeState(){
  if(!state.wardrobeEngine) state.wardrobeEngine = {};
  if(!state.wardrobeEngine[activeChild]){
    state.wardrobeEngine[activeChild] = {};
    Object.keys(LR_WARDROBE_SLOTS).forEach(function(slot){
      state.wardrobeEngine[activeChild][slot] = "(empty)";
    });
  }
  return state.wardrobeEngine[activeChild];
}

function lrOwnedWardrobeItems(){
  const items = ["(empty)"];

  function addList(list){
    (list || []).forEach(function(item){
      if(items.indexOf(item) === -1) items.push(item);
    });
  }

  addList((state.craftedItems && state.craftedItems[activeChild]) || []);
  addList((state.museum && state.museum[activeChild]) || []);
  addList((state.materials && state.materials[activeChild]) || []);

  const starter = [
    "🌙 Moonwalker Mantle","🪐 Planet Keeper Cloak","⭐ Stargazer Cape","☄ Sky Explorer Mantle","🚀 Explorer Suit","👑 Cosmic Crown",
    "☁ Cloud Hood","☁ Sky Cloak","⚡ Storm Gloves","⚡ Storm Mantle","💨 Wind Boots","❄ Frost Scarf","🌈 Rainbow Cape",
    "🌱 Gardener Hood","🌸 Blossom Cloak","🌳 Ranger Mantle","🍄 Forest Cape","🪴 Greenhouse Apron",
    "🦖 Explorer Cloak","⛏ Paleontologist Apron","🦋 Meadow Mantle","🐜 Colony Banner","🕸 Weaver Cloak","🌙 Night Watch Mantle",
    "🧙 Witch Robe","🎅 Winter Mantle","🐇 Bunny Hood","🍀 Lucky Cloak","🦃 Harvest Mantle","🎆 Celebration Crown",
    "🧚 Mythkeeper Wings","👑 Fairy Queen Crown","🐉 Dragon Mantle","👑 Dragon Throne"
  ];
  addList(starter);

  return items;
}

function lrGuessWardrobeSlot(item){
  const s = String(item).toLowerCase();
  for(const slot of Object.keys(LR_WARDROBE_KEYWORDS)){
    if(LR_WARDROBE_KEYWORDS[slot].some(function(k){ return s.includes(k); })) return slot;
  }
  return "accessory";
}

function lrWardrobeOptionsFor(slot){
  const all = lrOwnedWardrobeItems();
  return all.filter(function(item){
    if(item === "(empty)") return true;
    return lrGuessWardrobeSlot(item) === slot;
  });
}

function lrEquipWardrobe(slot, item){
  const w = lrEnsureWardrobeState();
  w[slot] = item;
  if(typeof save === "function") save();
  openWardrobeEngine();
}

function lrRenderWardrobeSlot(slot){
  const w = lrEnsureWardrobeState();
  const current = w[slot] || "(empty)";
  const options = lrWardrobeOptionsFor(slot).map(function(item){
    const selected = item === current ? " selected" : "";
    return '<option value="' + lrHomeRendererEscape(item) + '"' + selected + '>' + lrHomeRendererEscape(item) + '</option>';
  }).join("");

  return '<div class="lrWardSlot">' +
    '<div class="lrWardSlotLabel">' + lrHomeRendererEscape(LR_WARDROBE_SLOTS[slot]) + '</div>' +
    '<select onchange="lrEquipWardrobe(\'' + slot + '\', this.value)">' + options + '</select>' +
  '</div>';
}

function lrPaperDollPreview(){
  const w = lrEnsureWardrobeState();
  return '<div class="lrPaperDoll">' +
    '<div class="lrDollTitle">Character Preview</div>' +
    '<div class="lrDollHead">' + (w.head !== "(empty)" ? w.head : "🙂") + '</div>' +
    '<div class="lrDollBack">' + (w.back !== "(empty)" ? w.back : "") + '</div>' +
    '<div class="lrDollTorso">' + (w.torso !== "(empty)" ? w.torso : "👕 Plain Outfit") + '</div>' +
    '<div class="lrDollHands">' + (w.hands !== "(empty)" ? w.hands : "") + '</div>' +
    '<div class="lrDollFeet">' + (w.feet !== "(empty)" ? w.feet : "👢 Simple Shoes") + '</div>' +
    '<div class="lrDollAccessory">' + (w.neck !== "(empty)" ? w.neck : "") + " " + (w.accessory !== "(empty)" ? w.accessory : "") + '</div>' +
    '<div class="lrDollCompanion">' + (w.companion !== "(empty)" ? w.companion : "🐾 No companion gear") + '</div>' +
  '</div>';
}

function lrWardrobeSetHints(){
  return '<div class="lrWardSets">' +
    '<h3>Set Goals</h3>' +
    '<p>❄ Winter Set: Frost Scarf + Winter Mantle + Ice Boots</p>' +
    '<p>🌌 Cosmic Set: Cosmic Crown + Stargazer Cape + Explorer Suit</p>' +
    '<p>🧚 Fairy Set: Fairy Crown + Mythkeeper Wings + Blossom Cloak</p>' +
    '<p>🐉 Dragon Set: Dragon Mantle + Dragon Crown + Ember Boots</p>' +
    '<p class="lrWardNote">Legendary sets should require long learning chains, rare drops, crafting, and achievement unlocks.</p>' +
  '</div>';
}

function openWardrobeEngine(){
  actionTitle.textContent = "👕 Wardrobe";
  actionText.innerHTML =
    '<div class="lrWardrobeEngine">' +
      lrPaperDollPreview() +
      '<div class="lrWardSlotGrid">' +
        Object.keys(LR_WARDROBE_SLOTS).map(lrRenderWardrobeSlot).join("") +
      '</div>' +
      lrWardrobeSetHints() +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Wardrobe");
}
/* End Wardrobe / Paper Doll Engine Pack 1 */


/* Home Renderer Engine Pack 1 */
function lrHomeRendererEscape(value){
  return String(value ?? "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}

const LR_HOME_RENDERER_ROOMS = {
  cottage: {
    title: "🏡 Cozy Cottage",
    rooms: [
      {
        name: "🔥 Main Room",
        flavor: "Warm firelight fills the center of the home.",
        slots: [
          ["wall_left","🖼 Left Wall"],
          ["wall_right","🖼 Right Wall"],
          ["hearth","🔥 Hearth"],
          ["table","🪑 Table"],
          ["floor","🏺 Floor Display"],
          ["rug","🧶 Rug Center"]
        ]
      },
      {
        name: "🛏 Upstairs Loft",
        flavor: "A quiet loft beneath the rafters.",
        slots: [
          ["bed","🛏 Bed Nook"],
          ["shelf","📚 Story Shelf"],
          ["window","🕯 Window Table"],
          ["perch","🦉 Companion Perch"]
        ]
      },
      {
        name: "🐾 Pet Corner",
        flavor: "A soft place waiting for companions.",
        slots: [
          ["pet_bed","🐾 Pet Bed"],
          ["food_bowl","🥣 Food Bowl"],
          ["toy_basket","🧸 Toy Basket"],
          ["pet_perch","🪵 Perch"]
        ]
      }
    ]
  },
  estate: {
    title: "🏛 Estate Expansion",
    rooms: [
      {
        name: "🏆 Trophy Room",
        flavor: "Achievements become visible treasures here.",
        slots: [
          ["trophy_wall","🏆 Trophy Wall"],
          ["museum_shelf","🏛 Museum Shelf"],
          ["relic_case","💎 Relic Case"],
          ["banner","🚩 Banner"]
        ]
      },
      {
        name: "🧚 Fairy Conservatory",
        flavor: "Tiny lanterns glow beside flowers and mushrooms.",
        slots: [
          ["fairy_lamp","🧚 Fairy Lamp"],
          ["mushroom_table","🍄 Mushroom Table"],
          ["flower_arch","🌸 Flower Arch"],
          ["wing_display","🪽 Wing Display"]
        ]
      },
      {
        name: "🐉 Dragon Chamber",
        flavor: "Crystals sparkle around a warm stone chamber.",
        slots: [
          ["dragon_nest","💎 Crystal Nest"],
          ["dragon_banner","🐉 Dragon Banner"],
          ["ember_torch","🔥 Ember Torch"],
          ["egg_display","🥚 Egg Display"]
        ]
      }
    ]
  },
  seasonal: {
    title: "🎉 Seasonal Rooms",
    rooms: [
      {
        name: "❄ Winter Corner",
        flavor: "Snowy decorations wait for December magic.",
        slots: [
          ["winter_tree","🎄 Winter Tree"],
          ["snowman","☃ Snowman"],
          ["snow_rug","❄ Snowflake Rug"],
          ["stocking","🧦 Stocking Mantle"]
        ]
      },
      {
        name: "🎃 Autumn Corner",
        flavor: "Pumpkins, lanterns, and harvest colors fill the room.",
        slots: [
          ["pumpkin","🎃 Pumpkin Display"],
          ["lantern","🕯 Lantern"],
          ["bat_decor","🦇 Bat Decor"],
          ["harvest_table","🍞 Harvest Table"]
        ]
      },
      {
        name: "🌸 Spring Corner",
        flavor: "Flowers, eggs, and butterflies brighten the home.",
        slots: [
          ["egg_tree","🐣 Egg Tree"],
          ["tulips","🌷 Tulips"],
          ["butterfly_lamp","🦋 Butterfly Lantern"],
          ["blossom_arch","🌸 Blossom Arch"]
        ]
      }
    ]
  }
};

function lrEnsureHomeRenderState(){
  if(!state.homeRenderer) state.homeRenderer = {};
  if(!state.homeRenderer[activeChild]) state.homeRenderer[activeChild] = {};
  return state.homeRenderer[activeChild];
}

function lrHomeOwnedDecorItems(){
  const items = ["(empty)"];

  function addList(list){
    (list || []).forEach(function(item){
      if(items.indexOf(item) === -1) items.push(item);
    });
  }

  addList((state.museum && state.museum[activeChild]) || []);
  addList((state.craftedItems && state.craftedItems[activeChild]) || []);

  const mats = (state.materials && state.materials[activeChild]) || [];
  addList(mats.filter(function(x){ return /Statue|Display|Lamp|Banner|Crown|Cloak|Mantle|Table|Shelf|Rug|Lantern|Tree|Chair|Throne|Perch|Stand|Frame|Wreath|Totem|Plaque|Vane|Mobile|Cape|Hood|Gloves|Boots|Scarf/.test(String(x)); }));

  if(typeof lrAllPlaceableItems === "function"){
    addList(lrAllPlaceableItems());
  }

  return items;
}

function lrSetHomeRenderSlot(slot, value){
  const h = lrEnsureHomeRenderState();
  h[slot] = value;
  if(typeof save === "function") save();
  openHomeRenderer();
}

function lrRenderHomeSlot(slotId, label){
  const h = lrEnsureHomeRenderState();
  const current = h[slotId] || "(empty)";
  const opts = lrHomeOwnedDecorItems().map(function(item){
    const selected = item === current ? " selected" : "";
    return '<option value="' + lrHomeRendererEscape(item) + '"' + selected + '>' + lrHomeRendererEscape(item) + '</option>';
  }).join("");

  const icon = String(label).split(" ")[0] || "✨";
  const labelText = String(label).split(" ").slice(1).join(" ") || label;

  return '<div class="lrHomeSlot">' +
    '<div class="lrHomeSlotIcon">' + icon + '</div>' +
    '<div class="lrHomeSlotBody">' +
      '<b>' + lrHomeRendererEscape(labelText) + '</b>' +
      '<select onchange="lrSetHomeRenderSlot(\'' + lrHomeRendererEscape(slotId) + '\', this.value)">' + opts + '</select>' +
    '</div>' +
  '</div>';
}

function lrRenderHomeRoom(room){
  return '<section class="lrHomeRoom">' +
    '<h3>' + lrHomeRendererEscape(room.name) + '</h3>' +
    '<p>' + lrHomeRendererEscape(room.flavor) + '</p>' +
    '<div class="lrHomeSlotGrid">' + room.slots.map(function(pair){
      return lrRenderHomeSlot(pair[0], pair[1]);
    }).join("") + '</div>' +
  '</section>';
}

function openHomeRenderer(tab){
  const activeTab = tab || "cottage";
  const data = LR_HOME_RENDERER_ROOMS[activeTab] || LR_HOME_RENDERER_ROOMS.cottage;
  const tabs = Object.keys(LR_HOME_RENDERER_ROOMS).map(function(key){
    const cls = key === activeTab ? " active" : "";
    return '<button class="lrHomeTab' + cls + '" onclick="openHomeRenderer(\'' + key + '\')">' + lrHomeRendererEscape(LR_HOME_RENDERER_ROOMS[key].title) + '</button>';
  }).join("");

  actionTitle.textContent = "🏠 Home Renderer";
  actionText.innerHTML =
    '<div class="lrHomeRenderer">' +
      '<div class="lrHomeTabs">' + tabs + '</div>' +
      '<div class="lrHomeTitle">' + lrHomeRendererEscape(data.title) + '</div>' +
      data.rooms.map(lrRenderHomeRoom).join("") +
      '<div class="lrHomeNote">Items shown here are pulled from owned materials, crafted items, museum rewards, and placeable inventory hooks.</div>' +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Home Renderer");
}
/* End Home Renderer Engine Pack 1 */


/* Seasonal Drops and Vendors Pack */
const LR_SEASONAL_DROP_TABLES = {
  "Christmas":["🎄 Pine Sprig","🎁 Ribbon","❄ Snow Crystal","⭐ Tree Topper"],
  "Halloween":["🎃 Pumpkin","🕸 Web Thread","🍬 Candy","🧙 Witch Charm"],
  "Thanksgiving / Harvest":["🌽 Corn Husk","🍂 Harvest Leaf","🍞 Bread Token","🍂 Golden Acorn"],
  "Easter / Spring":["🥚 Painted Egg","🌷 Tulip Petal","🐇 Bunny Button","🥚 Golden Egg"],
  "St Patrick":["🍀 Clover","🌈 Rainbow Thread","🪙 Gold Coin","✨ Four Leaf Clover"],
  "New Year":["🎉 Confetti","🎇 Sparkler","🕰 Clock Gear","✨ New Year Spark"],
  "Winter":["❄ Snowflake","🧊 Ice Chip","🛷 Sled Wood","👑 Crystal Snow Crown"],
  "Summer":["🌻 Sunflower Seed","🍓 Berry","🪁 Kite String","☀ Sun Medal"]
};

const LR_SEASONAL_VENDOR_CATALOGS = {
  "Christmas":["🎄 Giant Tree","☃ Snowman Set","🎁 Present Tower","🧸 Toy Workshop"],
  "Halloween":["🎃 Giant Pumpkin Chair","🦇 Bat Chandelier","🕸 Spider Rug","🧹 Broom Rack"],
  "Thanksgiving / Harvest":["🎃 Pumpkin Bench","🌽 Corn Display","🍞 Harvest Table","🌾 Harvest Wagon"],
  "Easter / Spring":["🐣 Egg Tree","🐇 Bunny Decor","🌸 Blossom Arch","🦋 Butterfly Lantern"],
  "St Patrick":["🍀 Clover Patch","🌈 Rainbow Banner","🪙 Pot of Gold","🎩 Green Hat"],
  "New Year":["🎇 Firework Rack","🎉 Celebration Banner","🕰 Clock Tower Decor"],
  "Winter":["☃ Snowman Set","🧊 Ice Table","❄ Snowflake Rug","🛷 Sled Shelf"],
  "Summer":["🌻 Sunflower Patch","🍓 Berry Table","🪁 Wind Spinner","☀ Sun Pavilion"]
};

function lrSeasonalDrop(){
  const active = (typeof lrActiveSeasons === "function") ? lrActiveSeasons() : ["Everyday Kingdom"];
  let pool = [];
  active.forEach(function(season){
    if(LR_SEASONAL_DROP_TABLES[season]) pool = pool.concat(LR_SEASONAL_DROP_TABLES[season]);
  });
  if(!pool.length) pool = ["🍂 Leaf","🪨 Stone","🌼 Petal"];
  const item = pool[Math.floor(Math.random() * pool.length)];
  if(typeof lrGrantMaterial === "function"){
    lrGrantMaterial(item);
  }else if(typeof lrEnsureMaterials === "function"){
    lrEnsureMaterials().push(item);
    save();
  }
  return item;
}

function openSeasonalSearch(){
  const item = lrSeasonalDrop();
  actionTitle.textContent = "🎁 Seasonal Discovery";
  actionText.innerHTML = '<div class="journalPage"><h3>Seasonal Find</h3><p>You searched during the active event season.</p><p><b>Found:</b><br>' + item + '</p></div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Seasonal Discovery");
}

function openSeasonalVendor(){
  const active = (typeof lrActiveSeasons === "function") ? lrActiveSeasons() : ["Everyday Kingdom"];
  let items = [];
  active.forEach(function(season){
    if(LR_SEASONAL_VENDOR_CATALOGS[season]) items = items.concat(LR_SEASONAL_VENDOR_CATALOGS[season]);
  });
  if(!items.length) items = ["🏡 Everyday Decor"];
  actionTitle.textContent = "🛍 Seasonal Vendor";
  actionText.innerHTML = '<div class="journalPage"><h3>Active Catalog</h3><p>' + active.join("<br>") + '</p><h3>Items</h3><p>' + items.join("<br>") + '</p></div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Seasonal Vendor");
}
/* End Seasonal Drops and Vendors Pack */


/* Seasonal Engine Pack 1 */
function lrTodayMonthDay(){
  const d = new Date();
  return {month:d.getMonth()+1, day:d.getDate()};
}

function lrDateBetween(month, day, sm, sd, em, ed){
  const v = month * 100 + day;
  const s = sm * 100 + sd;
  const e = em * 100 + ed;
  if(s <= e) return v >= s && v <= e;
  return v >= s || v <= e;
}

function lrActiveSeasons(){
  const t = lrTodayMonthDay();
  const m = t.month, d = t.day;
  const active = [];

  if(lrDateBetween(m,d,1,1,1,7)) active.push("New Year");
  if(lrDateBetween(m,d,12,1,2,28)) active.push("Winter");
  if(lrDateBetween(m,d,3,1,3,20)) active.push("St Patrick");
  if(lrDateBetween(m,d,3,15,4,30)) active.push("Easter / Spring");
  if(lrDateBetween(m,d,6,1,8,31)) active.push("Summer");
  if(lrDateBetween(m,d,10,1,11,1)) active.push("Halloween");
  if(lrDateBetween(m,d,11,1,11,30)) active.push("Thanksgiving / Harvest");
  if(lrDateBetween(m,d,12,1,12,31)) active.push("Christmas");

  return active.length ? active : ["Everyday Kingdom"];
}

function lrSeasonalItemsFor(name){
  const data = {
    "New Year":["🎇 Firework Rack","🎉 Banner","🕰 Clock Tower Decor","🎆 Celebration Crown"],
    "Winter":["☃ Snowman Set","🧊 Ice Table","❄ Snowflake Rug","🛷 Sled Shelf"],
    "St Patrick":["🍀 Clover Patch","🌈 Rainbow Banner","🪙 Pot of Gold","🎩 Green Hat"],
    "Easter / Spring":["🐣 Painted Eggs","🐇 Bunny Decor","🌷 Tulips","🧺 Egg Basket","🌸 Blossom Arch"],
    "Summer":["🎣 Fishing Rack","🌻 Sunflower Patch","🍓 Berry Table","🪁 Wind Spinner"],
    "Halloween":["🎃 Pumpkins","🧙 Witch Hat","🦇 Bat Banner","🕸 Web Decor","🍬 Candy Bowl","🧹 Broom Display"],
    "Thanksgiving / Harvest":["🌽 Corn Bundle","🎃 Harvest Decor","🍞 Bread Basket","🪵 Rustic Table","🍂 Harvest Wreath"],
    "Christmas":["🎄 Giant Tree","🎁 Presents","☃ Snowmen","🦌 Reindeer Decor","🧦 Stockings","🛷 Sled","🧸 Toy Workshop"]
  };
  return data[name] || ["🏡 Everyday Decor"];
}

function openSeasonalCalendar(){
  const seasons = lrActiveSeasons();
  const items = seasons.flatMap(lrSeasonalItemsFor);
  actionTitle.textContent = "🎉 Seasonal Calendar";
  actionText.innerHTML =
    '<div class="journalPage"><h3>Active Event(s)</h3><p>' + seasons.join("<br>") + '</p></div>' +
    '<div class="journalPage"><h3>Seasonal Catalog</h3><p>' + items.join("<br>") + '</p></div>' +
    '<div class="journalPage"><h3>Event Journal</h3><p>Seasonal completion tracking hook is active.</p></div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Seasonal Calendar");
}

function lrEnsureSeasonalStorage(){
  if(!state.seasonalStorage) state.seasonalStorage = {};
  ["Halloween","Christmas","Easter","St Patrick","Harvest","New Year","Winter","Spring","Summer"].forEach(function(tab){
    if(!state.seasonalStorage[tab]) state.seasonalStorage[tab] = [];
  });
  return state.seasonalStorage;
}
/* End Seasonal Engine Pack 1 */




/* Village Square Pack 1 */
function openVillageSquare(){
 actionTitle.textContent="🏡 Village Square";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'><h3>📚 Elder Rowan's Book Cart</h3><p>🦉 Owl lanterns and story displays line the cart.</p><button onclick="openBookCart()">Browse Cart</button></div>
 <div class='journalPage'><h3>🔨 Builder Shed</h3><p>🪚 Workbench • ⚒ Anvil • 🪵 Wood stacks</p><button onclick="openCraftingStation()">Use Workshop</button></div>
 <div class='journalPage'><h3>🌿 Botanist Hut</h3><p>🦋 Jars • 🌼 Flowers • 🌿 Pressing table</p><button onclick="openBotanistShop()">Visit Hut</button></div>
 <div class='journalPage'><h3>👕 Tailor Tent</h3><p>🦉 Owl Hood • 🌿 Leaf Crown • 🔨 Builder Apron</p><button onclick="openTailorTent()">Browse Clothing</button></div>
 <div class='journalPage'><h3>🏞 Village Center</h3><p>🔥 Fire pit • 🪑 Benches • 📜 Notice board • 🦆 Pond hook</p></div>
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Village Square");
}

function openBookCart(){
 actionText.innerHTML='<div class="journalPage"><h3>📚 Book Cart</h3><p>🍂 Leaf Bookmark — 120 sparks<br>🦉 Owl Lantern — 900 sparks<br>📖 Story Tablet Stand — 1400 sparks</p></div>';
}
function openBotanistShop(){
 actionText.innerHTML='<div class="journalPage"><h3>🌿 Botanist Hut</h3><p>🌿 Fern Frame — 180 sparks<br>🦋 Butterfly Perch — achievement unlock<br>🐸 Pond Statue — 1500 sparks</p></div>';
}
function openTailorTent(){
 actionText.innerHTML='<div class="journalPage"><h3>👕 Tailor Tent</h3><p>🦉 Owl Hood<br>🌿 Leaf Crown<br>🔨 Builder Apron</p></div>';
}


/* Global Inventory + Journal Pack */
function openBackpack(){
 const mats=lrEnsureMaterials();
 const crafted=lrEnsureCraftedInventory();
 actionTitle.textContent="🎒 Backpack";
 actionText.innerHTML='<div class="journalPage"><h3>Materials</h3><p>'+mats.join("<br>")+'</p><h3>Crafted</h3><p>'+(crafted.join("<br>")||"None")+'</p></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Backpack");
}
function openAchievementJournal(){
 const r=(state.groveAchievements||[]).concat(state.workshopAchievements||[]).concat(state.natureAchievements||[]);
 actionTitle.textContent="📜 Achievements";
 actionText.innerHTML='<div class="journalPage"><h3>Achievement Log</h3><p>'+(r.join("<br>")||"None")+'</p></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Achievements");
}
function openWardrobe(){
 if(!state.wardrobe) state.wardrobe={hat:"Empty",outfit:"Empty",cloak:"Empty",pack:"Empty",shoes:"Empty",companion:"Empty"};
 actionTitle.textContent="👕 Wardrobe";
 actionText.innerHTML='<div class="journalPage"><h3>Equipment</h3><p>🎩 '+state.wardrobe.hat+'<br>👕 '+state.wardrobe.outfit+'<br>🧥 '+state.wardrobe.cloak+'<br>🎒 '+state.wardrobe.pack+'<br>👢 '+state.wardrobe.shoes+'<br>🦉 '+state.wardrobe.companion+'</p></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Wardrobe");
}
function openRegionJournal(){
 actionTitle.textContent="📖 Region Journal";
 actionText.innerHTML='<div class="journalPage"><h3>Reading Grove</h3><p>🌳 Character Circle ✅<br>🍂 Setting Hollow ✅<br>📖 Story Path ✅<br>🪶 Evidence Hall ✅</p><h3>Workshop</h3><p>🔨 Number Yard ✅<br>📏 Measure Bridge ✅<br>⚙ Pattern Mill ✅<br>🏗 Builder Square ✅</p><h3>Nature</h3><p>🌿 Pond of Leaves ✅<br>🐸 Reed Walk 🔒</p></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Region Journal");
}


/* World Materials Pack 1 */
const LR_MATERIAL_TABLE={
reading:[["Grove Leaf",55],["Feather",20],["Story Scrap",15],["Ancient Owl Feather",5]],
workshop:[["Wood",55],["Stone",25],["Gear",12],["Builder Seal",5]],
nature:[["Flower",50],["Reed",25],["Herb",15],["Butterfly Wing",5]]
};

function lrGrantMaterial(mat){
 const m=lrEnsureMaterials();
 m.push(mat);
 save();
}

function lrRandomFind(zone="reading"){
 const table=LR_MATERIAL_TABLE[zone]||LR_MATERIAL_TABLE.reading;
 const roll=Math.random()*100;
 let total=0;
 for(const [item,chance] of table){
   total+=chance;
   if(roll<=total){
     lrGrantMaterial(item);
     return item;
   }
 }
 return "Nothing";
}

function searchArea(zone){
 const item=lrRandomFind(zone);
 actionTitle.textContent="🔎 Discovery";
 actionText.innerHTML='<div class="journalPage"><h3>Ground Discovery</h3><p>You searched the area.</p><p><b>Found:</b> '+item+'</p></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Discovery");
}


/* Crafting Pack 1 - Two Item Combine Stations */
const LR_CRAFTING_RECIPES = [
  {station:"Woodworking Table", a:"Wood", b:"Stone", result:"Rustic Display Stand"},
  {station:"Woodworking Table", a:"Wood", b:"Grove Leaf", result:"Leaf Shelf"},
  {station:"Forge and Anvil", a:"Stone", b:"Gear", result:"Builder Hook"},
  {station:"Writing Desk", a:"Story Scrap", b:"Feather", result:"Quill Bookmark"},
  {station:"Botanist Table", a:"Flower", b:"Grove Leaf", result:"Pressed Flower Frame"},
  {station:"Oven", a:"Wheat", b:"Apple", result:"Apple Bread"}
];

function lrEnsureMaterials(){
  if(!state.materials) state.materials = {};
  if(!state.materials[activeChild]){
    state.materials[activeChild] = ["Wood","Stone","Grove Leaf","Story Scrap","Feather","Flower","Gear","Wheat","Apple"];
  }
  return state.materials[activeChild];
}

function lrEnsureCraftedInventory(){
  if(!state.craftedItems) state.craftedItems = {};
  if(!state.craftedItems[activeChild]) state.craftedItems[activeChild] = [];
  return state.craftedItems[activeChild];
}

function lrCraftItem(){
  const station = document.getElementById("craftStation").value;
  const a = document.getElementById("craftItemA").value;
  const b = document.getElementById("craftItemB").value;
  const recipe = LR_CRAFTING_RECIPES.find(function(r){
    return r.station === station && ((r.a === a && r.b === b) || (r.a === b && r.b === a));
  });

  if(!recipe){
    document.getElementById("craftResult").innerHTML = "Nothing happened. Those materials do not combine here.";
    return;
  }

  const inv = lrEnsureCraftedInventory();
  if(inv.indexOf(recipe.result) === -1) inv.push(recipe.result);

  const decor = (typeof lrEnsureHomeDecor === "function") ? lrEnsureHomeDecor() : null;
  if(decor && decor.shelf && decor.shelf.indexOf(recipe.result) === -1){
    decor.shelf.push(recipe.result);
  }

  save();
  document.getElementById("craftResult").innerHTML = "Crafted: <b>" + recipe.result + "</b>";
}

function lrCraftOptions(){
  const mats = lrEnsureMaterials();
  return mats.map(function(m){
    return '<option value="' + m + '">' + m + '</option>';
  }).join("");
}

function openCraftingStation(){
  const stations = ["Woodworking Table","Forge and Anvil","Writing Desk","Botanist Table","Oven"];
  const stationOptions = stations.map(function(s){
    return '<option value="' + s + '">' + s + '</option>';
  }).join("");

  actionTitle.textContent = "Crafting Station";
  actionText.innerHTML =
    '<div class="craftBox">' +
      '<h3>Choose a station</h3>' +
      '<select id="craftStation" class="craftDrop">' + stationOptions + '</select>' +
      '<h3>Combine materials</h3>' +
      '<select id="craftItemA" class="craftDrop">' + lrCraftOptions() + '</select>' +
      '<select id="craftItemB" class="craftDrop">' + lrCraftOptions() + '</select>' +
      '<button type="button" onclick="lrCraftItem()">Combine</button>' +
      '<div id="craftResult" class="craftResult">Pick two materials and try a recipe.</div>' +
      '<h3>Known crafted items</h3>' +
      '<p>' + (lrEnsureCraftedInventory().join("<br>") || "None yet") + '</p>' +
    '</div>';

  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Crafting Station");
}
/* End Crafting Pack 1 */


/* Nature Hollow Phase 1 - Pond of Leaves */
function openPondOfLeaves(){
 actionTitle.textContent="🌿 Pond of Leaves";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🌿 Pond of Leaves</h3>
 <p>A quiet pond reflects the sky while butterflies drift above the reeds.</p>
 <p><b>🌿 Willow:</b><br>"Nature teaches quietly."</p>
 <button onclick="openPondLesson()">Observe the Pond</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Pond of Leaves");
}

function openPondLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Living Things</h3>
 <p>🌳 Tree = living<br>
 🦋 Butterfly = living<br>
 🪨 Stone = nonliving</p>
 <button onclick="completePondOfLeaves()">Finish Observation</button>
 </div>`;
}

function completePondOfLeaves(){
 if(!state.natureAchievements) state.natureAchievements=[];
 if(!state.natureAchievements.includes("🌿 Pond Watcher"))
   state.natureAchievements.push("🌿 Pond Watcher");

 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Pond Explored</h3>
 <p>Achievement: 🌿 Pond Watcher<br>
 Reward: 🦋 Butterfly Perch<br><br>
 🐸 Reed Walk unlocked</p>
 </div>`;
 save();
}


/* Workshop Meadow Phase 4 - Builder Square */
function openBuilderSquare(){
 actionTitle.textContent="🏗 Builder Square";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🏗 Builder Square</h3>
 <p>Stone blocks, beams, and half built projects fill the square.</p>
 <p><b>🔨 Brindletoe:</b><br>"Builders add pieces together."</p>
 <button onclick="openBuilderLesson()">Help Build</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Builder Square");
}

function openBuilderLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Building Math</h3>
 <p>🪨 + 🪨 = 2 stones<br>
 🪵 + 🪵 + 🪵 = 3 beams<br><br>
 Adding materials helps projects grow.</p>
 <button onclick="completeBuilderSquare()">Finish Project</button>
 </div>`;
}

function completeBuilderSquare(){
 if(!state.workshopAchievements) state.workshopAchievements=[];
 if(!state.workshopAchievements.includes("🏗 Master Builder"))
   state.workshopAchievements.push("🏗 Master Builder");

 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Workshop Meadow Complete</h3>
 <p>Achievement: 🏗 Master Builder<br>
 Reward: 🏗 Builder Banner<br><br>
 🌿 Nature Hollow path opened</p>
 </div>`;
 save();
}


/* Workshop Meadow Phase 3 - Pattern Mill */
function openPatternMill(){
 actionTitle.textContent="⚙ Pattern Mill";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>⚙ Pattern Mill</h3>
 <p>The water wheel turns beside the mill while banners sway overhead.</p>
 <p><b>🔨 Brindletoe:</b><br>"Builders see shapes everywhere."</p>
 <button onclick="openPatternLesson()">Study the Mill</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Pattern Mill");
}

function openPatternLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Patterns and Shapes</h3>
 <p>🔵 🟦 🔵 🟦 ?<br>
 🪨 🪨 🌿 🪨 🪨 🌿 ?<br><br>
 Shapes help builders repeat designs.</p>
 <button onclick="completePatternMill()">Turn the Wheel</button>
 </div>`;
}

function completePatternMill(){
 if(!state.workshopAchievements) state.workshopAchievements=[];
 if(!state.workshopAchievements.includes("⚙ Pattern Keeper"))
   state.workshopAchievements.push("⚙ Pattern Keeper");

 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Mill Restored</h3>
 <p>Achievement: ⚙ Pattern Keeper<br>
 Reward: ⚙ Mill Gear Token<br><br>
 🏗 Builder Square unlocked</p>
 </div>`;
 save();
}


/* Workshop Meadow Phase 2 - Measure Bridge */
function openMeasureBridge(){
 actionTitle.textContent="📏 Measure Bridge";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>📏 Measure Bridge</h3>
 <p>Wooden beams stretch over the river. Marker posts line the path.</p>
 <p><b>🔨 Brindletoe:</b><br>"Builders do not guess. They measure."</p>
 <button onclick="openMeasureLesson()">Survey the Bridge</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Measure Bridge");
}

function openMeasureLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Measuring</h3>
 <p>🪵 Long plank vs short plank<br>
 🌉 Which beam reaches farther?<br>
 📏 Count the measuring posts.</p>
 <button onclick="completeMeasureBridge()">Finish Survey</button>
 </div>`;
}

function completeMeasureBridge(){
 if(!state.workshopAchievements) state.workshopAchievements=[];
 if(!state.workshopAchievements.includes("📏 Bridge Surveyor"))
   state.workshopAchievements.push("📏 Bridge Surveyor");

 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Bridge Survey Complete</h3>
 <p>Achievement: 📏 Bridge Surveyor<br>
 Reward: 📏 Builder Measure Rod<br><br>
 ⚙ Pattern Mill unlocked</p>
 </div>`;
 save();
}


/* Workshop Meadow Phase 1 - Number Yard */
function openNumberYard(){
 actionTitle.textContent="🔨 Number Yard";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🔨 Number Yard</h3>
 <p>Stone markers surround a warm forge. A little bridge crosses the stream.</p>
 <p><b>🔨 Brindletoe:</b><br>"Builders count before they build."</p>
 <button onclick="openNumberLesson()">Count the Stones</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Number Yard");
}

function openNumberLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Counting Stones</h3>
 <p>🪨🪨 = 2 stones<br>🪨🪨🪨 = 3 stones<br>Bridges need careful counting.</p>
 <button onclick="completeNumberYard()">Repair Bridge</button>
 </div>`;
}

function completeNumberYard(){
 if(!state.workshopAchievements) state.workshopAchievements=[];
 if(!state.workshopAchievements.includes("🔨 Apprentice Builder"))
   state.workshopAchievements.push("🔨 Apprentice Builder");
 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Bridge Repaired</h3>
 <p>Achievement: 🔨 Apprentice Builder<br>
 Reward: 🪨 Builder Stone<br><br>
 📏 Measure Bridge unlocked</p>
 </div>`;
 save();
}


/* Reading Grove Completion Pack */
function openReadingGroveCompletion(){
 actionTitle.textContent="🌳 Reading Grove Complete";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🌳 The Old Oak</h3>
 <p>The oak glows softly as leaves drift around the grove.</p>
 <p><b>🦉 Elric:</b><br>"Traveler... you walked the grove well."</p>
 </div>

 <div class='journalPage'>
 <h3>🏆 Grove Rewards</h3>
 <p>🏆 Grove Scholar Banner<br>
 🪶 Scholar Quill<br>
 🦉 Owl Statue<br>
 🏛 Museum Entry</p>
 </div>

 <div class='journalPage'>
 <h3>🌍 World Change</h3>
 <p>📜 Grove banner raised in the village<br>
 🦉 Owl lantern placed by the path<br>
 🔨 Workshop Meadow now welcomes travelers</p>
 </div>
 </div>`;
 if(!state.regionComplete) state.regionComplete={};
 state.regionComplete.readingGrove=true;
 save();
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Reading Grove Complete");
}


/* Reading Grove Phase 4 - Evidence Hall */
function openEvidenceHall(){
 actionTitle.textContent="🪶 Evidence Hall";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🪶 Evidence Hall</h3>
 <p>Quiet stones rest beneath the roots of the old oak. Faded story scraps glow softly.</p>
 <p><b>🦉 Elric:</b> "Readers do not guess. They prove."</p>
 <button onclick="openEvidenceLesson()">Study the Hall</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Evidence Hall");
}

function openEvidenceLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Finding Evidence</h3>
 <p>Text detail → proof<br>Clue → support<br>Evidence helps answer questions.</p>
 <button onclick="completeEvidenceHall()">Challenge Gate</button>
 </div>`;
}

function completeEvidenceHall(){
 if(!state.groveAchievements) state.groveAchievements=[];
 if(!state.groveAchievements.includes("🪶 Grove Scholar"))
   state.groveAchievements.push("🪶 Grove Scholar");

 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Reading Grove Complete</h3>
 <p>Achievement: 🪶 Grove Scholar<br>
 Reward: 🪶 Scholar Quill<br><br>
 🏛 Museum display unlocked</p>
 </div>`;
 save();
}


/* Reading Grove Phase 3 - Story Path */
function openStoryPath(){
 actionTitle.textContent="📖 Story Path";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>📖 Story Path</h3>
 <p>Stone markers line the trail beneath the old oaks.</p>
 <p><b>Elric:</b> "Every story travels."</p>
 <button onclick="openStoryLesson()">Walk the Path</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Story Path");
}
function openStoryLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Story Journey</h3>
 <p>🪵 Fallen Log = Beginning<br>🌉 Creek Bridge = Middle<br>🦉 Great Oak = Ending</p>
 <button onclick="completeStoryPath()">Continue Forward</button>
 </div>`;
}
function completeStoryPath(){
 if(!state.groveAchievements) state.groveAchievements=[];
 if(!state.groveAchievements.includes("📖 Story Walker"))
   state.groveAchievements.push("📖 Story Walker");
 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Story Path Complete</h3>
 <p>Achievement: 📖 Story Walker<br>Reward: 📖 Story Tablet<br><br>🪶 Evidence Hall unlocked</p>
 </div>`;
 save();
}


/* Reading Grove Phase 2 - Setting Hollow */
function openSettingHollow(){
 actionTitle.textContent="🍂 Setting Hollow";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🍂 Setting Hollow</h3>
 <p>Leaves drift beside a quiet creek. Story scraps rest beneath the trees.</p>
 <p><b>Elric:</b> "Settings change how stories feel."</p>
 <button onclick="openSettingHollowLesson()">Study the Hollow</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Setting Hollow");
}

function openSettingHollowLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Setting and Mood</h3>
 <p>🌞 Sunny village = cheerful mood<br>
 🌧 Rainy forest = mysterious mood<br>
 🌙 Castle at night = quiet mood</p>
 <button onclick="completeSettingHollow()">Walk Story Path</button>
 </div>`;
}

function completeSettingHollow(){
 if(!state.groveAchievements) state.groveAchievements=[];
 if(!state.groveAchievements.includes("🍂 Keeper of Setting"))
   state.groveAchievements.push("🍂 Keeper of Setting");
 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Hollow Complete</h3>
 <p>Achievement: 🍂 Keeper of Setting<br>
 Reward: 🍂 Grove Leaf Marker<br><br>
 📖 Story Path unlocked</p>
 </div>`;
 save();
}


/* Reading Grove Phase 1 */
const LR_GROVE_PROGRESS={
character:{title:"🌳 Character Circle",open:true},
setting:{title:"🍂 Setting Hollow",open:false},
story:{title:"📖 Story Path",open:false},
evidence:{title:"🪶 Evidence Hall",open:false}
};

function openCharacterCircle(){
 actionTitle.textContent="🌳 Character Circle";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>🦉 Elric</h3>
 <p>"Traveler... stories happen somewhere.<br><br>That place is called the setting."</p>
 <button onclick="openSettingLesson()">Continue</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Character Circle");
}

function openSettingLesson(){
 actionText.innerHTML=`<div class='journalPage'>
 <h3>📚 Setting Lesson</h3>
 <p>Village = setting<br>Forest = setting<br>Castle = setting</p>
 <button onclick="completeCharacterCircle()">Begin Quiz Gate</button>
 </div>`;
}

function completeCharacterCircle(){
 if(!state.groveAchievements) state.groveAchievements=[];
 if(!state.groveAchievements.includes("📜 First Steps in the Grove"))
   state.groveAchievements.push("📜 First Steps in the Grove");
 actionText.innerHTML=`<div class='journalPage'>
 <h3>🏆 Achievement Unlocked</h3>
 <p>📜 First Steps in the Grove<br><br>Reward: 🪶 Grove Leaf Marker<br><br>🍂 Setting Hollow unlocked</p>
 </div>`;
 save();
}


/* Journey Rebuild Pack 1 */
const LR_WORLD_HUB={
village:{title:"🏡 Village",desc:"A quiet crossroads village.",paths:{north:"reading",south:"workshop",east:"nature"}},
reading:{title:"🌳 Reading Grove",desc:"Old oaks surround Elric's circle.",npc:"elric",paths:{south:"village"}},
workshop:{title:"🔨 Workshop",desc:"Hammer echoes drift in the air.",npc:"brindle",paths:{north:"village"}},
nature:{title:"🌿 Nature Hollow",desc:"Butterflies drift over reeds.",npc:"willow",paths:{west:"village"}}
};

function lrEnsureJourney(){ if(!state.journeyLoc) state.journeyLoc="village"; return state.journeyLoc; }

function openJourneyWorld(){
 const k=lrEnsureJourney(); const r=LR_WORLD_HUB[k];
 let p=Object.entries(r.paths).map(([d,t])=>`<button onclick="travelJourney('${t}')">${d.toUpperCase()} → ${LR_WORLD_HUB[t].title}</button>`).join("");
 let npc=r.npc?`<button onclick="talkNPCProgress('${r.npc}')">Meet Teacher</button>`:"";
 actionTitle.textContent=r.title;
 actionText.innerHTML=`<div class='travelPlace'><h3>${r.title}</h3><p>${r.desc}</p>${p}<br>${npc}</div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup(r.title);
}
function travelJourney(t){state.journeyLoc=t; save(); openJourneyWorld();}


/* Home Pack 8 - True Slot Dropdown Home */
function lrAllPlaceableItems(){
  const items = ["(empty)"];
  const museum = (state.museum && state.museum[activeChild]) || [];
  const living = lrEnsureLivingHome ? lrEnsureLivingHome() : {};
  const decor = lrEnsureHomeDecor ? lrEnsureHomeDecor() : {};

  museum.forEach(function(i){ if(items.indexOf(i) === -1) items.push(i); });

  ["library","nature","pets","treasure"].forEach(function(k){
    (living[k] || []).forEach(function(i){
      if(items.indexOf(i) === -1) items.push(i);
    });
  });

  ["wall","table","floor","shelf"].forEach(function(k){
    (decor[k] || []).forEach(function(i){
      if(items.indexOf(i) === -1) items.push(i);
    });
  });

  return items;
}

function lrSlotDropdown(slot){
  const inv = lrEnsureSlotInventory();
  const current = inv[slot] || "(empty)";
  const options = lrAllPlaceableItems().map(function(item){
    const selected = item === current ? " selected" : "";
    return '<option value="' + lrHomeSafeEscape(item) + '"' + selected + '>' + lrHomeSafeEscape(item) + '</option>';
  }).join("");

  return '<select class="slotDropdown" onchange="setHomeSlot(decodeURIComponent(this.dataset.slot), this.value)" data-slot="' + encodeURIComponent(slot) + '">' + options + '</select>';
}

function lrPrettySlot(slot){
  const parts = slot.split(" ");
  const icon = parts[0] || "✨";
  const label = parts.slice(1).join(" ") || slot;
  return '<div class="trueSlotCard">' +
    '<div class="trueSlotIcon">' + icon + '</div>' +
    '<div class="trueSlotBody"><b>' + lrHomeSafeEscape(label) + '</b>' +
    lrSlotDropdown(slot) +
    '</div></div>';
}

function lrRoomSlotPanel(title, slots, flavor){
  return '<div class="trueRoomPanel">' +
    '<h3>' + title + '</h3>' +
    '<p class="trueRoomFlavor">' + flavor + '</p>' +
    '<div class="trueSlotGrid">' + slots.map(lrPrettySlot).join("") + '</div>' +
    '</div>';
}

function openTrueSlotHome(){
  actionTitle.textContent = "Cozy Home Slots";
  actionText.innerHTML =
    '<div class="trueSlotHome">' +
      lrRoomSlotPanel("Upstairs Loft", LR_HOME_SLOTS.loft, "A quiet loft beneath the rafters, ready for shelves, keepsakes, and little treasures.") +
      lrRoomSlotPanel("Main Room", LR_HOME_SLOTS.main, "Warm firelight fills the cottage. This is where the home starts to feel earned.") +
      lrRoomSlotPanel("Pet Corner", LR_HOME_SLOTS.pet, "A soft little place waiting for future companions.") +
      lrRoomSlotPanel("Museum Corner", LR_HOME_SLOTS.museum, "Special trophies and relics can be shown here before the castle museum is complete.") +
    '</div>';
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Cozy Home Slots");
}

/* Replace old slot home view with the true dropdown version. */
openSlotHome = openTrueSlotHome;
/* End Home Pack 8 */


/* Question Sanitizer Pack */
function lrNormalize(s){
 return String(s||"").toLowerCase().replace(/[^a-z0-9]/g,"");
}

function lrSanitizeLesson(lesson){
 if(!lesson) return lesson;
 const ans=lrNormalize(lesson.a);
 if(lesson.practice && ans && lrNormalize(lesson.practice).includes(ans)){
   lesson.practice="[Example hidden to avoid answer leakage]";
 }
 return lesson;
}

const _oldRoadCurrentLesson = typeof lrRoadCurrentLesson==="function" ? lrRoadCurrentLesson : null;
if(_oldRoadCurrentLesson){
 lrRoadCurrentLesson=function(subj){
   return lrSanitizeLesson(_oldRoadCurrentLesson(subj));
 }
}

function lrQuestionCard(q,choices){
 return `<div class='qCard'>
 <div class='qHeader'>QUESTION</div>
 <div class='qTitle'>${q}</div>
 ${choices.map((c,i)=>`<div class='qChoice'><b>${String.fromCharCode(65+i)}.</b> ${c}</div>`).join("")}
 </div>`;
}


/* Adventure Restoration Pack */
function renderTravelPlace(name,desc,fn){
 return `<div class="travelPlace"><h3>${name}</h3><p>${desc}</p><button onclick="${fn}()">Travel</button></div>`;
}
function openAdventureTravel(){
 actionTitle.textContent="🌳 Paths";
 actionText.innerHTML=
 renderTravelPlace("🌳 Reading Grove","A quiet path under old trees.","talkNPCProgress.bind(null,'elric')")+
 renderTravelPlace("🔨 Workshop","Hammer echoes nearby.","talkNPCProgress.bind(null,'brindle')")+
 renderTravelPlace("🌿 Nature Hollow","Butterflies drift over reeds.","talkNPCProgress.bind(null,'willow')")+
 renderTravelPlace("🪶 Scribe Hall","Pages rustle softly.","talkNPCProgress.bind(null,'scribe')");
}

function slotSelect(slot){
 const opts=lrOwnedItems().map(i=>`<option ${((lrEnsureSlotInventory()[slot]||"(empty)")==i)?"selected":""}>${i}</option>`).join("");
 actionText.innerHTML=`<div class='journalPage'><h3>${slot}</h3><select onchange="setHomeSlot('${slot}',this.value)" class="homeDrop">${opts}</select></div>`;
}

function lrQuestionCard(q,choices){
 return `<div class='qCard'><div class='qTitle'>${q}</div>${choices.map(c=>`<div class='qChoice'>${c}</div>`).join("")}</div>`;
}


/* Home Pack 7 - Slot Inventory */
function lrEnsureSlotInventory(){
 if(!state.slotInventory) state.slotInventory={};
 if(!state.slotInventory[activeChild]){
  state.slotInventory[activeChild]={
   "📚 Story Shelf":"🦉 Wooden Story Owl",
   "🔥 Hearth":"(empty)"
  };
 }
 return state.slotInventory[activeChild];
}

const LR_HOME_SLOTS={
 loft:["🛏 Bed Nook","📚 Story Shelf","🦉 Companion Perch","🕯 Window Table","🖼 Wall Hook","📦 Storage Chest"],
 main:["🖼 Left Wall","🖼 Right Wall","🔥 Hearth","🪑 Table","📚 Bookshelf","🧶 Rug Center","🏺 Floor Display","🪴 Plant Corner"],
 pet:["🐾 Pet Bed","🥣 Food Bowl","🧸 Toy Basket","🪵 Perch"],
 museum:["🗿 Fossil Pedestal","🏆 Trophy Shelf","📜 Scroll Rack"]
};

function lrOwnedItems(){
 return ((state.museum&&state.museum[activeChild])||[]).concat(["(empty)"]);
}
function setHomeSlot(slot,val){
 lrEnsureSlotInventory()[slot]=val; save(); openSlotHome();
}
function slotSelect(slot){
 const opts=lrOwnedItems().map(i=>`<button onclick="setHomeSlot('${slot}','${i}')">${i}</button>`).join("<br>");
 actionText.innerHTML=`<div class='journalPage'><h3>${slot}</h3>${opts}</div>`;
}
function renderSlot(slot){
 const inv=lrEnsureSlotInventory();
 return `<div class="slotCard"><span class="slotIcon">${slot.split(" ")[0]}</span><b>${slot}</b><br>${inv[slot]||"(empty)"}<br><button onclick="slotSelect('${slot}')">Choose</button></div>`;
}
function openSlotHome(){
 actionTitle.textContent="🏠 Cozy Home";
 actionText.innerHTML=`<div class='homeView'>${Object.values(LR_HOME_SLOTS).flat().map(renderSlot).join("")}</div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Cozy Home");
}


/* Home Pack 6 - Living Home */
function lrEnsureLivingHome(){
 if(!state.livingHome) state.livingHome={};
 if(!state.livingHome[activeChild]){
   state.livingHome[activeChild]={
     library:["🦉 Story Owl"],
     nature:["🪴 Fern Display","🦋 Butterfly Perch"],
     pets:[],
     treasure:[]
   };
 }
 return state.livingHome[activeChild];
}

function openLivingHome(){
 const h=lrEnsureLivingHome();
 actionTitle.textContent="🐾 Living Home";
 actionText.innerHTML=`
 <div class="homeView">
  <div class="homeRoom"><b>📚 Library Loft</b><br>${h.library.join("<br>")||"Empty"}</div>
  <div class="homeRoom"><b>🌿 Nature Room</b><br>${h.nature.join("<br>")||"Empty"}</div>
  <div class="homeRoom"><b>🐾 Pet Nook</b><br>${h.pets.join("<br>")||"Empty"}</div>
  <div class="homeRoom"><b>💎 Treasure Cellar</b><br>${h.treasure.join("<br>")||"Empty"}</div>
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Living Home");
}


/* Home Pack 5 CLEAN - Dream Home Layout */
function lrHomeSafeEscape(value){
  if(typeof lrEscape === "function") return lrEscape(String(value));
  return String(value)
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}

function lrHomeDecorText(list){
  if(!list || !list.length) return "Empty";
  return list.map(function(item){
    return lrHomeSafeEscape(item);
  }).join("<br>");
}

function openDreamHome(){
  var decor = lrEnsureHomeDecor();
  var rooms = lrEnsureHomeRooms();
  var extraRooms = (rooms.rooms || []).slice(2);
  var wingsHtml = extraRooms.map(function(roomName){
    return '<div class="dreamWing">✨ ' + lrHomeSafeEscape(roomName) + '</div>';
  }).join("");

  actionTitle.textContent = "Dream Home";
  actionText.innerHTML =
    '<div class="dreamHome">' +
      '<div class="dreamFloor">' +
        '<div class="dreamTitle">Upstairs</div>' +
        '<div class="dreamSlot">Bed Corner</div>' +
        '<div class="dreamSlot">Shelf<br>' + lrHomeDecorText(decor.shelf) + '</div>' +
        '<div class="dreamSlot">Wall<br>' + lrHomeDecorText(decor.wall) + '</div>' +
      '</div>' +
      '<div class="dreamFloor">' +
        '<div class="dreamTitle">Downstairs</div>' +
        '<div class="dreamSlot">Table<br>' + lrHomeDecorText(decor.table) + '</div>' +
        '<div class="dreamSlot">Floor<br>' + lrHomeDecorText(decor.floor) + '</div>' +
        '<div class="dreamSlot">Exit Hall</div>' +
      '</div>' +
      wingsHtml +
    '</div>';

  if(typeof lrOpenActionPopup === "function"){
    lrOpenActionPopup("Dream Home");
  }
}
/* End Home Pack 5 CLEAN */


/* Home Pack 4 - Visual Home View */
function openVisualHome(){
 const rooms=lrEnsureHomeRooms();
 const decor=lrEnsureHomeDecor();
 actionTitle.textContent="🏠 Visual Home";
 actionText.innerHTML=`
 <div class="homeView">
   <div class="homeRoom">🏡 Downstairs<br><small>${decor.floor.join("<br>")||"Empty floor"}</small></div>
   <div class="homeRoom">🛏 Upstairs<br><small>${decor.wall.join("<br>")||"Empty walls"}</small></div>
   <div class="homeRoom">📚 Shelf Area<br><small>${decor.shelf.join("<br>")||"Empty shelves"}</small></div>
   ${rooms.rooms.slice(2).map(r=>`<div class="homeRoom">✨ ${r}</div>`).join("")}
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Visual Home");
}


/* Home Pack 3 - Room Expansion View */
function lrEnsureHomeRooms(){
 if(!state.homeRooms) state.homeRooms={};
 if(!state.homeRooms[activeChild]){
   state.homeRooms[activeChild]={
    level:1,
    rooms:["Downstairs","Upstairs"]
   };
 }
 return state.homeRooms[activeChild];
}

function expandHomeRoom(){
 const h=lrEnsureHomeRooms();
 const unlocks=["Museum Room","Nature Room","Library Loft","Pet Nook","Treasure Cellar","Castle Entry"];
 if(h.level<unlocks.length+1){
   h.rooms.push(unlocks[h.level-1]);
   h.level+=1;
   save();
 }
 openHomeRooms();
}

function openHomeRooms(){
 const h=lrEnsureHomeRooms();
 actionTitle.textContent="🏠 Home Expansion";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>Home Level ${h.level}</h3>
 <p>${h.rooms.join("<br>")}</p>
 <br><button onclick="expandHomeRoom()">🛠 Expand Home</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Home Expansion");
}


/* Home Pack 2 - Museum Placement */
const LR_HOME_REWARD_SLOTS={
"🦉 Wooden Story Owl":"shelf",
"🌿 Pressed Fern Display":"wall",
"🪨 Carved Number Stone":"floor",
"🪶 Quill Plaque":"wall"
};

function moveMuseumRewardHome(item){
 const slot=LR_HOME_REWARD_SLOTS[item];
 if(!slot) return;

 const museum=(state.museum&&state.museum[activeChild])||[];
 if(!museum.includes(item)) return;

 const h=lrEnsureHomeDecor();
 if(!h[slot].includes(item)){
   h[slot].push(item);
   save();
 }
}

function lrSafeJsArg(value){
 return encodeURIComponent(String(value));
}

function openHomePlacement(){
 const museum=(state.museum&&state.museum[activeChild])||[];
 let rows=museum.map(function(item){
   const safe=lrSafeJsArg(item);
   const label=(typeof lrEscape==="function")?lrEscape(item):String(item);
   return '<button onclick="moveMuseumRewardHome(decodeURIComponent(\''+safe+'\'))">'+label+'</button>';
 }).join("<br>");

 actionTitle.textContent="Place Museum Rewards";
 actionText.innerHTML='<div class="journalBook"><div class="journalPage"><h3>Available Displays</h3><p>'+(rows||"No museum rewards yet.")+'</p></div></div>';
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Home Placement");
}


/* Home Pack 1 - Decoration Placement */
function lrEnsureHomeDecor(){
 if(!state.homeDecor) state.homeDecor={};
 if(!state.homeDecor[activeChild]){
   state.homeDecor[activeChild]={
     wall:[],
     table:[],
     floor:[],
     shelf:[]
   };
 }
 return state.homeDecor[activeChild];
}

function placeMuseumToHome(slot,item){
 const h=lrEnsureHomeDecor();
 if(!h[slot].includes(item)) h[slot].push(item);
 save();
}

function openHomeDecor(){
 const h=lrEnsureHomeDecor();
 actionTitle.textContent="🏠 Home Decor";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'><h3>🖼 Wall</h3><p>${h.wall.join("<br>")||"Empty"}</p></div>
 <div class='journalPage'><h3>🪑 Table</h3><p>${h.table.join("<br>")||"Empty"}</p></div>
 <div class='journalPage'><h3>🏺 Floor</h3><p>${h.floor.join("<br>")||"Empty"}</p></div>
 <div class='journalPage'><h3>📚 Shelf</h3><p>${h.shelf.join("<br>")||"Empty"}</p></div>
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Home Decor");
}


/* Atmosphere Pack 1 - Living World Flavor */
const LR_ATMOSPHERE={
Reading:[
"🍂 Leaves drift across Character Circle.",
"🦉 An owl watches from the oak.",
"📖 A page turns somewhere in the stacks."
],
Math:[
"🔨 Hammer echoes from the forge.",
"⚒ Sparks leap from hot iron.",
"🪨 Mason lines mark old stones."
],
Nature:[
"🦋 Butterflies cross the pond.",
"🐸 Ripples spread in the reeds.",
"🌾 Grass bends in the wind."
],
Writing:[
"🕯 Candlelight flickers.",
"📜 Pages rustle quietly.",
"🪶 Quills scratch softly."
]
};

function lrAtmosphereMessage(subject){
 const arr=LR_ATMOSPHERE[subject]||["✨ The world feels alive."];
 return arr[Math.floor(Math.random()*arr.length)];
}

function openAtmosphereView(subject="Reading"){
 actionTitle.textContent="✨ World Atmosphere";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'>
 <h3>${subject}</h3>
 <p>${lrAtmosphereMessage(subject)}</p>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("World Atmosphere");
}


/* Stability Pack 1 - Button and Popup Audit */
function lrSafeCall(fnName, label){
  try{
    if(typeof window[fnName] === "function"){
      window[fnName]();
      return true;
    }
    actionTitle.textContent = label || "Unavailable";
    actionText.innerHTML = `<div class="journalPage"><h3>${label || "Unavailable"}</h3><p>This feature hook exists, but the function was not loaded yet.</p></div>`;
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup(label || "Unavailable");
    return false;
  }catch(err){
    actionTitle.textContent = "Feature Error";
    actionText.innerHTML = `<div class="journalPage"><h3>${label || fnName}</h3><p>${String(err && err.message ? err.message : err)}</p></div>`;
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Feature Error");
    console.error("LearningRealms feature error:", fnName, err);
    return false;
  }
}

function openSystemAudit(){
  const checks = [
    ["Teacher Paths", "openTeacherSubjectMenu"],
    ["Curriculum Roads", "openCurriculumRoadMenu"],
    ["Learning Groves", "openLearningGroves"],
    ["Extended District", "openSubjectSchools"],
    ["Quest Board", "openQuestBoard"],
    ["Student Journal", "openStudentJournal"],
    ["Achievements", "openAchievementsJournal"],
    ["Museum Hall", "openMuseumHall"],
    ["Learning Castle", "openCastleHall"],
    ["Realm Friends", "openNpcRelations"]
  ];
  const rows = checks.map(([label,fn])=>{
    const ok = typeof window[fn] === "function";
    return `<div class="auditRow ${ok ? "ok" : "bad"}"><b>${ok ? "✅" : "⚠️"} ${label}</b><br><small>${fn}</small></div>`;
  }).join("");
  actionTitle.textContent = "System Audit";
  actionText.innerHTML = `<div class="journalBook"><div class="journalPage"><h3>🔧 Button / Popup Audit</h3><p>Quick check for the main feature hooks.</p></div>${rows}</div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("System Audit");
}

function lrCleanDuplicateUtilityButtons(){
  const seen = {};
  document.querySelectorAll("button").forEach(btn=>{
    const text = (btn.textContent || "").trim();
    const click = btn.getAttribute("onclick") || "";
    const key = text + "::" + click;
    if(seen[key] && text && click){
      btn.style.display = "none";
    }else{
      seen[key] = true;
    }
  });
}

function lrRunPostRenderAudit(){
  try{
    lrCleanDuplicateUtilityButtons();
  }catch(e){
    console.warn("LearningRealms duplicate button cleanup failed", e);
  }
}
/* End Stability Pack 1 */


/* Quest Pack 1 - Learning Quests */
const LR_LEARNING_QUESTS={
reading:{npc:"🦉 Archivist Elric",title:"Story Owl Restoration",goal:"Complete Character Circle",reward:"🦉 Wooden Story Owl",subject:"Reading"},
math:{npc:"🔨 Brindletoe",title:"Measure the Old Stones",goal:"Complete Counting Bench",reward:"🪨 Carved Number Stone",subject:"Math"},
nature:{npc:"🌿 Willow",title:"Restore the Garden",goal:"Complete Plant Garden",reward:"🌿 Pressed Fern Display",subject:"Nature"},
writing:{npc:"🪶 Scribe Keeper",title:"Village Chronicle",goal:"Complete Sentence Nook",reward:"🪶 Quill Plaque",subject:"Writing"}
};

function openQuestBoard(){
 let h="<div class='journalBook'>";
 Object.keys(LR_LEARNING_QUESTS).forEach(k=>{
  const q=LR_LEARNING_QUESTS[k];
  h+=`<div class='journalPage'><h3>${q.title}</h3><p>${q.npc}<br>${q.goal}<br>Reward: ${q.reward}<br><br><button onclick="acceptQuest('${k}')">Accept Quest</button></p></div>`;
 });
 h+="</div>";
 actionTitle.textContent="📜 Quest Board";
 actionText.innerHTML=h;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Quest Board");
}

function acceptQuest(k){
 const q=LR_LEARNING_QUESTS[k];
 if(!state.quests) state.quests={};
 state.quests[k]="accepted";
 save();
 actionTitle.textContent=q.title;
 actionText.innerHTML=`<div class='journalPage'><h3>${q.title}</h3><p>Quest accepted.<br>${q.goal}<br><br><button onclick="completeQuest('${k}')">Complete Quest</button></p></div>`;
}

function completeQuest(k){
 const q=LR_LEARNING_QUESTS[k];
 awardMuseumReward(q.subject);
 state.quests[k]="done";
 save();
 actionTitle.textContent="🏆 Quest Complete";
 actionText.innerHTML=`<div class='journalPage'><h3>${q.title}</h3><p>Reward earned:<br>${q.reward}</p></div>`;
}


/* Castle Pack 2 - Expansion System */
function expandCastle(){
 const c=lrEnsureCastle();
 if(!c.level) c.level=1;
 if(c.level==1){
   c.level=2;
   c.rooms.push("Library Wing");
 }else if(c.level==2){
   c.level=3;
   c.rooms.push("Museum Wing");
 }else if(c.level==3){
   c.level=4;
   c.rooms.push("Nature Conservatory");
 }else if(c.level==4){
   c.level=5;
   c.rooms.push("Grand Hall");
 }
 save();
 actionTitle.textContent="🛠 Goblin Builders";
 actionText.innerHTML=`<div class='journalBook'><div class='journalPage'><h3>Castle Expanded!</h3><p>Your castle is now level ${c.level}.<br><br>New room unlocked:<br>${c.rooms[c.rooms.length-1]}</p></div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Castle Expanded");
}


/* Castle Pack 1 - Trophy Foundations */
function lrEnsureCastle(){
 if(!state.castle) state.castle={level:1,rooms:["Great Room"],wings:[]};
 return state.castle;
}

function openCastleHall(){
 const c=lrEnsureCastle();
 const museum=(state.museum&&state.museum[activeChild])||[];
 actionTitle.textContent="🏰 Learning Castle";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'><h3>Castle Level ${c.level}</h3><p>Rooms:<br>${c.rooms.join("<br>")}</p></div>
 <div class='journalPage'><h3>🏆 Trophy Room</h3><p>${museum.length?museum.join("<br>"):"No trophies yet."}</p></div>
 <div class='journalPage'><h3>Future Wings</h3><p>📚 Library Wing<br>🖼 Museum Wing<br>🌿 Nature Conservatory</p></div>
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Learning Castle");
}


/* Reward & Museum Pack 1 */
const LR_MUSEUM_REWARDS={
Reading:["🦉 Wooden Story Owl"],
Math:["🪨 Carved Number Stone"],
Nature:["🌿 Pressed Fern Display"],
Writing:["🪶 Quill Plaque"]
};

function lrEnsureMuseum(){
 if(!state.museum) state.museum={};
 if(!state.museum[activeChild]) state.museum[activeChild]=[];
 return state.museum[activeChild];
}

function awardMuseumReward(subject){
 const rewards=LR_MUSEUM_REWARDS[subject]||[];
 if(!rewards.length) return;
 const m=lrEnsureMuseum();
 rewards.forEach(r=>{if(!m.includes(r)) m.push(r);});
 save();
}

function openMuseumHall(){
 const m=lrEnsureMuseum();
 actionTitle.textContent="🏛 Museum Hall";
 actionText.innerHTML=`<div class='journalBook'><div class='journalPage'><h3>Collected Displays</h3><p>${m.length?m.join("<br>"):"No displays yet."}</p></div>
 <div class='journalPage'><h3>Future Castle Wing</h3><p>These items will someday appear physically in the home and castle.</p></div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Museum Hall");
}


/* Learning District Pack 2 - Remaining Subject Schools */
const LR_SUBJECT_SCHOOLS={
geography:{name:"🗺 Cartographer Lodge",travel:"Hill Road → East",subject:"Geography",npc:["🗺 Cartographer Nia","🧭 Trail Scout"],rooms:["Map Hall","Globe Room","Trade Gallery"]},
civics:{name:"⚖ Council Hall",travel:"Village Center → West",subject:"Civics",npc:["⚖ Council Keeper","📜 Law Apprentice"],rooms:["Community Room","Government Hall","Citizenship Court"]},
economics:{name:"🪙 Market School",travel:"Market Square → North",subject:"Economics",npc:["🪙 Market Tutor","📦 Trade Clerk"],rooms:["Goods Hall","Budget Bench","Trade Floor"]},
logic:{name:"🧩 Puzzle Grove",travel:"Forest Edge → North",subject:"Logic",npc:["🧩 Puzzle Sage","🪨 Riddle Sprite"],rooms:["Pattern Circle","Reasoning Trail","Critical Hall"]},
science:{name:"🔬 Marsh Laboratory",travel:"Marsh Path → East",subject:"Science",npc:["🔬 Marsh Scholar","🧪 Lab Sprite"],rooms:["Experiment Table","Nature Lab","Discovery Hall"]},
arts:{name:"🎨 Art and Music Hall",travel:"Town Lane → South",subject:"Arts",npc:["🎨 Hall Artist","🎵 Song Keeper"],rooms:["Painting Room","Music Stage","Creation Studio"]}
};

function openSubjectSchools(){
 let h='<div class="lessonCard roadCard"><div class="lessonCardTitle">🏫 Extended Learning District</div><div class="teacherChoiceGrid">';
 Object.keys(LR_SUBJECT_SCHOOLS).forEach(k=>{
   h+=`<button onclick="visitSubjectSchool('${k}')">${LR_SUBJECT_SCHOOLS[k].name}</button>`;
 });
 h+='</div></div>';
 actionTitle.textContent="Extended Learning District";
 actionText.innerHTML=h;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Extended Learning District");
}

function visitSubjectSchool(k){
 const s=LR_SUBJECT_SCHOOLS[k];
 actionTitle.textContent=s.name;
 actionText.innerHTML=`<div class='lessonCard roadCard'><div class='lessonCardTitle'>${s.name}</div><div class='lessonCardText'>
 <b>Travel:</b> ${s.travel}<br><br>
 ${s.npc.join("<br>")}<br><br>
 ${s.rooms.join("<br>")}<br><br>
 <button onclick="lrStartCurriculumRoad('${s.subject}')">Begin ${s.subject} Road</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup(s.name);
}


/* Journal Pack 2 - Titles and Achievements */
function lrAchievementList(){
 const prog=(state.progress&&state.progress[activeChild])||{};
 const titles=[];
 if((prog.Reading||0)>=10) titles.push("📚 Story Seeker");
 if((prog.Math||0)>=10) titles.push("🔨 Number Builder");
 if((prog.Nature||0)>=10) titles.push("🌿 Grove Walker");
 if((prog.Writing||0)>=10) titles.push("🪶 Young Scribe");
 if(!titles.length) titles.push("🌱 New Traveler");
 return titles.join("<br>");
}

function openAchievementsJournal(){
 actionTitle.textContent="Achievements";
 actionText.innerHTML=`<div class='journalBook'>
 <div class='journalPage'><h3>🏆 Titles</h3><p>${lrAchievementList()}</p></div>
 <div class='journalPage'><h3>🏰 Future Trophy Hall</h3><p>Castle display rooms will eventually show badges, titles, museum pieces, and learning trophies.</p></div>
 </div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Achievements");
}


/* Journal Pack 1 - Student Adventure Journal */
function lrJournalProgressList(){
  const prog = (state.progress && state.progress[activeChild]) || {};
  const keys = Object.keys(prog).sort();
  if(!keys.length) return "No subjects recorded yet.";
  return keys.map(k=>`${k}: ${prog[k] || 0} lessons`).join("<br>");
}

function lrJournalNPCProgress(){
  const p = (state.npcProgress && state.npcProgress[activeChild]) || {};
  const rows = [];
  if(typeof LR_ROOM_UNLOCKS !== "undefined"){
    Object.keys(LR_ROOM_UNLOCKS).forEach(subj=>{
      const idx = p[subj] && typeof p[subj].room === "number" ? p[subj].room : 0;
      const room = LR_ROOM_UNLOCKS[subj][Math.min(idx, LR_ROOM_UNLOCKS[subj].length-1)];
      rows.push(`${subj}: ${room || "Not started"}`);
    });
  }
  return rows.length ? rows.join("<br>") : "No learning rooms unlocked yet.";
}

function lrJournalRoads(){
  const roads = (state.curriculumRoads && state.curriculumRoads[activeChild]) || {};
  const keys = Object.keys(roads).sort();
  if(!keys.length) return "No curriculum roads started yet.";
  return keys.map(k=>{
    const r = roads[k] || {};
    return `${k}: stage ${(r.stage || 0)+1}, ${r.correctInStage || 0}/5 toward next gate`;
  }).join("<br>");
}

function lrJournalMemories(){
  const mem = state.memoryBook || [];
  if(!mem.length) return "No memories yet.";
  return mem.slice(-8).map(m=>{
    if(typeof m === "string") return "• " + m;
    return "• " + (m.title || "Memory") + (m.text ? ": " + m.text : "");
  }).join("<br>");
}

function openStudentJournal(){
  actionTitle.textContent = "Student Adventure Journal";
  actionText.innerHTML = `
  <div class="journalBook">
    <div class="journalPage">
      <h3>📖 ${activeChild}'s Journal</h3>
      <p><b>Current place:</b> ${(room().title || state.loc)}<br>
      <b>Zone:</b> ${(room().zone || "Unknown")}</p>
    </div>

    <div class="journalPage">
      <h3>📚 Subject Progress</h3>
      <p>${lrJournalProgressList()}</p>
    </div>

    <div class="journalPage">
      <h3>🏫 Learning Rooms</h3>
      <p>${lrJournalNPCProgress()}</p>
    </div>

    <div class="journalPage">
      <h3>🛤 Curriculum Roads</h3>
      <p>${lrJournalRoads()}</p>
    </div>

    <div class="journalPage">
      <h3>🕯 Recent Memories</h3>
      <p>${lrJournalMemories()}</p>
    </div>
  </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Student Adventure Journal");
}
/* End Journal Pack 1 */


/* NPC Interaction Pack 2 - Progress Paths */
const LR_ROOM_UNLOCKS={
Reading:["Character Circle","Setting Hollow","Story Path","Evidence Hall"],
Math:["Counting Bench","Shape Yard","Measurement Table","Algebra Forge"],
Nature:["Plant Garden","Habitat Pond","Ecosystem Trail","Stewardship Ridge"],
Writing:["Sentence Nook","Paragraph Room","Revision Chamber","Argument Hall"]
};

function lrEnsureNPCProgress(){
 if(!state.npcProgress) state.npcProgress={};
 if(!state.npcProgress[activeChild]) state.npcProgress[activeChild]={};
 return state.npcProgress[activeChild];
}

function talkNPCProgress(id){
 const n=LR_NPCS[id];
 const p=lrEnsureNPCProgress();
 const subj=n.lesson;
 if(!p[subj]) p[subj]={room:0};
 const room=LR_ROOM_UNLOCKS[subj][Math.min(p[subj].room,LR_ROOM_UNLOCKS[subj].length-1)];

 actionTitle.textContent=n.name;
 actionText.innerHTML=`<div class='lessonCard roadCard'>
 <div class='lessonCardTitle'>${n.name}</div>
 <div class='lessonCardText'>
 Current study area:<br><b>${room}</b><br><br>
 "${n.memory}"<br><br>
 <button onclick="lrAdvanceNPCRoom('${subj}')">Complete Lesson Area</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup(n.name);
}

function lrAdvanceNPCRoom(subj){
 const p=lrEnsureNPCProgress();
 if(!p[subj]) p[subj]={room:0};
 p[subj].room=Math.min(p[subj].room+1,LR_ROOM_UNLOCKS[subj].length-1);
 save();
 actionText.innerHTML="<div class='lessonCard roadCard'><div class='lessonCardTitle'>🏆 Area Unlocked</div><div class='lessonCardText'>Next learning room opened.</div></div>";
}


/* NPC Interaction Pack 1 */
const LR_NPCS={
elric:{name:"🦉 Archivist Elric",memory:"Last time you studied setting.",lesson:"Reading"},
sprite:{name:"📖 Story Sprite",memory:"Stories hide clues everywhere.",lesson:"Reading"},
brindle:{name:"🔨 Builder Brindletoe",memory:"Measure twice, build once.",lesson:"Math"},
willow:{name:"🌿 Willow Naturalist",memory:"Plants remember sunlight.",lesson:"Nature"},
scribe:{name:"🪶 Scribe Keeper",memory:"Good writing grows slowly.",lesson:"Writing"}
};

function talkNPC(id){
 const n=LR_NPCS[id];
 actionTitle.textContent=n.name;
 actionText.innerHTML=`<div class='lessonCard roadCard'>
 <div class='lessonCardTitle'>${n.name}</div>
 <div class='lessonCardText'>
 "${n.memory}"<br><br>
 <button onclick="lrStartCurriculumRoad('${n.lesson}')">Begin ${n.lesson} Lesson</button>
 </div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup(n.name);
}


/* World Integration 2C + 2D - Nature Hollow and Scribe Hall */
const LR_NATURE_HOLLOW_WORLD = {
  name:"🌿 Willow Nature Hollow",
  travel:"River Bank → West",
  npcs:["🌿 Willow Naturalist","🦋 Garden Sprite","🐸 Pond Keeper"],
  rooms:["🌱 Plant Garden","🐟 Habitat Pond","🕸 Ecosystem Trail","🌲 Stewardship Ridge"]
};

function openNatureHollowWorld(){
  actionTitle.textContent = LR_NATURE_HOLLOW_WORLD.name;
  actionText.innerHTML = `
  <div class="lessonCard roadCard">
    <div class="lessonCardTitle">${LR_NATURE_HOLLOW_WORLD.name}</div>
    <div class="lessonCardText">
      <b>Travel:</b> ${LR_NATURE_HOLLOW_WORLD.travel}<br><br>
      <b>NPCs</b><br>${LR_NATURE_HOLLOW_WORLD.npcs.join("<br>")}<br><br>
      <b>Places</b><br>${LR_NATURE_HOLLOW_WORLD.rooms.join("<br>")}<br><br>
      <button onclick="lrStartCurriculumRoad('Nature')">Talk to Willow Naturalist</button>
    </div>
  </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Nature Hollow");
}

const LR_SCRIBE_HALL_WORLD = {
  name:"🪶 Scribe Hall",
  travel:"Library Lane → South",
  npcs:["🪶 Scribe Keeper","📜 Ink Apprentice","🕯 Lantern Copyist"],
  rooms:["✏️ Sentence Nook","📄 Paragraph Room","🛠 Revision Chamber","⚖ Argument Hall"]
};

function openScribeHallWorld(){
  actionTitle.textContent = LR_SCRIBE_HALL_WORLD.name;
  actionText.innerHTML = `
  <div class="lessonCard roadCard">
    <div class="lessonCardTitle">${LR_SCRIBE_HALL_WORLD.name}</div>
    <div class="lessonCardText">
      <b>Travel:</b> ${LR_SCRIBE_HALL_WORLD.travel}<br><br>
      <b>NPCs</b><br>${LR_SCRIBE_HALL_WORLD.npcs.join("<br>")}<br><br>
      <b>Places</b><br>${LR_SCRIBE_HALL_WORLD.rooms.join("<br>")}<br><br>
      <button onclick="lrStartCurriculumRoad('Writing')">Talk to Scribe Keeper</button>
    </div>
  </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Scribe Hall");
}
/* End World Integration 2C + 2D */


/* World Integration 2A-2B: Reading Grove + Math Workshop */
const LR_WORLD_SCHOOLS_2AB = {
  reading:{
    name:"🌳 Old Oak Reading Grove",
    travel:"Forest Path → East",
    subject:"Reading",
    teacher:"🦉 Archivist Elric",
    npcs:["🦉 Archivist Elric","📖 Story Sprite","🦉 Apprentice Owl"],
    rooms:["Character Circle","Setting Hollow","Story Path"]
  },
  math:{
    name:"🔨 Stonebuilder Workshop",
    travel:"Village Square → North",
    subject:"Math",
    teacher:"🔨 Builder Brindletoe",
    npcs:["🔨 Builder Brindletoe","🪨 Apprentice Mason","⚒ Apprentice Smith"],
    rooms:["Counting Bench","Shape Yard","Measurement Table","Algebra Forge"]
  }
};

function openWorldSchool2AB(kind){
  const g = LR_WORLD_SCHOOLS_2AB[kind || "reading"];
  actionTitle.textContent = g.name;
  actionText.innerHTML = `<div class='lessonCard roadCard'><div class='lessonCardTitle'>${g.name}</div><div class='lessonCardText'>
  <b>Travel:</b> ${g.travel}<br><br>
  <b>Teachers / Helpers</b><br>${g.npcs.join("<br>")}<br><br>
  <b>Learning Rooms</b><br>${g.rooms.join("<br>")}<br><br>
  <button onclick="lrStartCurriculumRoad('${g.subject}')">Talk to ${g.teacher}</button>
  </div></div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup(g.name);
}


/* Learning Grove Pack 1 */
const LR_GROVES={
reading:{name:"🌳 Old Oak Reading Grove",rooms:["Character Circle","Setting Hollow","Story Path","Evidence Hall"],subject:"Reading"},
math:{name:"🔨 Stonebuilder Workshop",rooms:["Counting Bench","Shape Yard","Measurement Table","Algebra Forge"],subject:"Math"},
nature:{name:"🌿 Willow Nature Hollow",rooms:["Plant Garden","Habitat Pond","Ecosystem Trail","Stewardship Ridge"],subject:"Nature"},
writing:{name:"🪶 Scribe Hall",rooms:["Sentence Nook","Paragraph Room","Revision Chamber","Argument Hall"],subject:"Writing"}
};

function openLearningGroves(){
 let html='<div class="lessonCard"><div class="lessonCardTitle">Learning Places</div><div class="teacherChoiceGrid">';
 for(const [k,g] of Object.entries(LR_GROVES)){
  html+=`<button onclick="enterGrove('${k}')">${g.name}<br>${g.rooms[0]}</button>`;
 }
 html+='</div></div>';
 actionTitle.textContent="Learning Groves";
 actionText.innerHTML=html;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Learning Groves");
}
function enterGrove(kind){
 const g=LR_GROVES[kind];
 let roomHtml=`<div class="lessonCard roadCard"><div class="lessonCardTitle">${g.name}</div><div class="lessonCardText">`;
 roomHtml+=g.rooms.map((r,i)=>`${i+1}. ${r}`).join("<br>");
 roomHtml+=`<br><br><button onclick="lrStartCurriculumRoad('${g.subject}')">Begin Lesson Path</button></div></div>`;
 actionTitle.textContent=g.name;
 actionText.innerHTML=roomHtml;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup(g.name);
}


/* Teacher NPC Pack 4 - Curriculum Roads */
const LR_CURRICULUM_ROADS = {
  Reading: {
    title:"📚 Reading Road",
    stages:[
      {name:"Foundation Grove", keys:["character","setting","beginning","middle","end","title","picture","retell","sequence","problem","solution"]},
      {name:"Understanding Trail", keys:["main idea","details","summary","context","cause","effect","compare","contrast","nonfiction","heading","caption"]},
      {name:"Deep Reader Hall", keys:["inference","theme","evidence","claim","source","tone","bias","purpose","analysis","synthesis"]}
    ]
  },
  Writing: {
    title:"✍️ Writing Road",
    stages:[
      {name:"Sentence Meadow", keys:["capital","period","question","exclamation","space","sentence","word order","name","comma"]},
      {name:"Paragraph Path", keys:["paragraph","detail","topic","opening","conclusion","transition","narrative","opinion","informative"]},
      {name:"Composition Hall", keys:["audience","evidence","organization","hook","body paragraph","argument","revision","editing","grammar"]}
    ]
  },
  Math: {
    title:"🔢 Math Road",
    stages:[
      {name:"Number Field", keys:["counting","addition","subtraction","skip","place value","ten","time","money","shape","measurement"]},
      {name:"Middle Math Bridge", keys:["ratio","percent","decimal","integer","area","perimeter","probability","data","coordinate","geometry"]},
      {name:"Algebra Ridge", keys:["expression","equation","system","function","graph","slope","inequality","statistic","exponent","variable"]}
    ]
  },
  Nature: {
    title:"🌿 Nature Road",
    stages:[
      {name:"Living Things Hollow", keys:["plant","animal","seed","water","sunlight","soil","leaf","forest","shelter","habitat"]},
      {name:"Ecosystem Trail", keys:["ecosystem","food chain","producer","consumer","pollination","weather","cloud","predator","nutrition","exercise"]},
      {name:"Stewardship Ridge", keys:["biodiversity","adaptation","erosion","weathering","watershed","resource","conservation","energy","species","climate"]}
    ]
  },
  Geography: {
    title:"🌎 Geography Road",
    stages:[
      {name:"Map Meadow", keys:["map","globe","land","water","direction","symbol","north","ocean"]},
      {name:"Region Road", keys:["region","climate","resource","physical","landform","settlement","population","migration"]},
      {name:"World Connections", keys:["trade","import","export","goods","community","citizenship","government","law"]}
    ]
  },
  Economics: {
    title:"💰 Economics Road",
    stages:[
      {name:"Market Basics", keys:["need","want","goods","saving","money","coin","market"]},
      {name:"Trade Trail", keys:["supply","demand","trade","production","exchange","budget"]},
      {name:"Choice Hall", keys:["scarcity","opportunity","cost","economics","resource","consumer","market"]}
    ]
  },
  Civics: {
    title:"⚖ Civics Road",
    stages:[
      {name:"Community Path", keys:["helper","rule","community","responsibility"]},
      {name:"Government Hall", keys:["government","law","citizen","service","level"]},
      {name:"Participation Road", keys:["participate","citizenship","responsibilities","community"]}
    ]
  },
  Logic: {
    title:"🧩 Logic Road",
    stages:[
      {name:"Puzzle Grove", keys:["sort","pattern","same","different","clue","first","next","last","reason"]},
      {name:"Reasoning Path", keys:["evidence","inference","sequence","category","analogy","relevant","conclusion"]},
      {name:"Critical Hall", keys:["claim","bias","assumption","fallacy","deductive","inductive","argument","source"]}
    ]
  }
};

function lrLessonSearchText(L){
  return ((L.teach || "") + " " + (L.practice || "") + " " + (L.q || "") + " " + ((L.c || []).join(" "))).toLowerCase();
}

function lrRoadForSubject(subj){
  return LR_CURRICULUM_ROADS[subj] || {
    title:"✨ " + subj + " Road",
    stages:[{name:"Foundation",keys:[]},{name:"Practice",keys:[]},{name:"Mastery",keys:[]}]
  };
}

function lrEnsureRoadState(){
  if(!state.curriculumRoads) state.curriculumRoads = {};
  if(!state.curriculumRoads[activeChild]) state.curriculumRoads[activeChild] = {};
  return state.curriculumRoads[activeChild];
}

function lrRoadState(subj){
  const roads = lrEnsureRoadState();
  if(!roads[subj]) roads[subj] = {stage:0,step:0,completed:[]};
  return roads[subj];
}

function lrRoadStageForSubject(subj){
  const road = lrRoadForSubject(subj);
  const rs = lrRoadState(subj);
  const stage = road.stages[Math.min(rs.stage || 0, road.stages.length - 1)] || road.stages[0];
  return {road, rs, stage};
}

function lrRoadLessonPool(subj){
  const all = (((LESSONS || {})[activeChild] || {})[subj] || []);
  const info = lrRoadStageForSubject(subj);
  const keys = (info.stage.keys || []).map(x=>String(x).toLowerCase());

  if(!keys.length) return all;

  const filtered = all.filter(L=>{
    const txt = lrLessonSearchText(L);
    return keys.some(k=>txt.includes(k));
  });

  return filtered.length ? filtered : all;
}

function lrRoadCurrentLesson(subj){
  const pool = lrRoadLessonPool(subj);
  if(!pool.length) return null;
  const rs = lrRoadState(subj);
  return pool[(rs.step || 0) % pool.length];
}

function lrStartCurriculumRoad(subj){
  subj = subj || lrTeacherSubjectForRoom();
  const pool = lrRoadLessonPool(subj);
  if(!pool.length){
    $("feedback").textContent = "No road lessons loaded for " + activeChild + " / " + subj + ".";
    return;
  }
  const rs = lrRoadState(subj);
  rs.active = true;
  rs.correctInStage = rs.correctInStage || 0;
  rs.step = rs.step || 0;
  save();
  lrShowRoadLesson(subj);
}

function lrShowRoadLesson(subj){
  const info = lrRoadStageForSubject(subj);
  const L = lrRoadCurrentLesson(subj);
  if(!L) return;
  $("actionTitle").textContent = info.road.title;
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard roadCard">
      <div class="lessonCardTitle">${lrTeacherNameForSubject(subj)} — ${info.stage.name}</div>
      <div class="lessonCardText">
        <b>Road Step:</b> ${(info.rs.step || 0) + 1}<br>
        <b>Stage Progress:</b> ${info.rs.correctInStage || 0} / 5<br><br>
        <b>Teach:</b><br>${lrEscape(L.teach || "Read carefully and think through this skill.")}
        ${L.practice ? `<br><br><b>Example:</b><br>${lrEscape(L.practice)}` : ""}
        <br><br><button type="button" onclick="lrShowRoadPractice('${subj}')">Practice</button>
      </div>
    </div>`;
  $("lessonBox").classList.add("hidden");
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup(info.road.title);
}

function lrShowRoadPractice(subj){
  const L = lrRoadCurrentLesson(subj);
  if(!L) return;
  $("actionTitle").textContent = "Road Practice";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard roadCard">
      <div class="lessonCardTitle">Practice Gate</div>
      <div class="lessonCardText">
        ${lrEscape(L.q || "Choose the best answer.")}
        <div class="teacherChoiceGrid">
          ${(L.c || []).map((ch,i)=>`<button type="button" onclick="lrRoadAnswer('${subj}', ${i})">${lrEscape(ch)}</button>`).join("")}
        </div>
      </div>
    </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Road Practice");
}

function lrRoadAnswer(subj, choiceIndex){
  const L = lrRoadCurrentLesson(subj);
  if(!L) return;
  const choice = (L.c || [])[choiceIndex];
  const info = lrRoadStageForSubject(subj);
  const correct = choice === L.a;

  if(correct){
    info.rs.correctInStage = (info.rs.correctInStage || 0) + 1;
    info.rs.step = (info.rs.step || 0) + 1;

    if(!state.progress[activeChild]) state.progress[activeChild] = {};
    state.progress[activeChild][subj] = (state.progress[activeChild][subj] || 0) + 1;
    state.sparks = (state.sparks || 0) + 1;

    addMemory("Curriculum Road", activeChild + " advanced on the " + subj + " road: " + info.stage.name + ".");
    save();

    if(info.rs.correctInStage >= 5){
      lrRoadCompleteStage(subj);
    }else{
      lrShowRoadLesson(subj);
    }
  }else{
    $("actionTitle").textContent = "Road Review";
    $("actionText").innerHTML = `
      <div class="lessonCard teacherCard roadCard">
        <div class="lessonCardTitle">Not yet</div>
        <div class="lessonCardText">
          The road does not open from guessing. Read the teaching again and try once more.<br><br>
          <b>Teach:</b><br>${lrEscape(L.teach || "")}
          <br><br><button type="button" onclick="lrShowRoadPractice('${subj}')">Try Again</button>
        </div>
      </div>`;
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Road Review");
  }
}

function lrRoadCompleteStage(subj){
  const info = lrRoadStageForSubject(subj);
  const completedName = info.stage.name;
  info.rs.completed = info.rs.completed || [];
  if(!info.rs.completed.includes(completedName)) info.rs.completed.push(completedName);
  info.rs.stage = Math.min((info.rs.stage || 0) + 1, info.road.stages.length - 1);
  info.rs.correctInStage = 0;
  info.rs.step = 0;

  const fullyComplete = info.rs.completed.length >= info.road.stages.length;
  if(fullyComplete){
    ensureHome().storage.push({name:subj + " Road Badge", slot:"shelf"});
  }
  save();

  $("actionTitle").textContent = "Road Gate Opened";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard roadCard">
      <div class="lessonCardTitle">🏆 ${completedName} Complete</div>
      <div class="lessonCardText">
        The teacher nods and the next part of the road opens.<br><br>
        ${fullyComplete ? `<b>Road Complete:</b> ${subj} Road Badge earned.` : `<b>Next Stage:</b> ${lrRoadStageForSubject(subj).stage.name}`}
        <br><br><button type="button" onclick="lrStartCurriculumRoad('${subj}')">Continue Road</button>
      </div>
    </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Road Gate Opened");
}

function openCurriculumRoadMenu(){
  const subjects = Object.keys((LESSONS && LESSONS[activeChild]) || {}).sort();
  $("actionTitle").textContent = "Curriculum Roads";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard roadCard">
      <div class="lessonCardTitle">Choose a Road</div>
      <div class="lessonCardText">
        Each road teaches in order: foundation, practice, then mastery. Complete 5 correct practice gates to open the next stage.
        <div class="teacherChoiceGrid">
          ${subjects.map(s=>{
            const info = lrRoadStageForSubject(s);
            return `<button type="button" onclick="lrStartCurriculumRoad('${s}')">${lrRoadForSubject(s).title}<br><small>${info.stage.name} — ${info.rs.correctInStage || 0}/5</small></button>`;
          }).join("")}
        </div>
      </div>
    </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Curriculum Roads");
}
/* End Teacher NPC Pack 4 */


/* Teacher NPC Pack 3 - Teach From Question Mountain Pools */
function lrTeacherSubjectForRoom(){
  const r = room ? room() : {};
  if(r && r.subject) return r.subject;
  return "Reading";
}

function lrTeacherNameForSubject(subj){
  const names = {
    Reading:"🦉 Archivist Elric",
    Writing:"🪶 Scribe Keeper",
    Math:"🔨 Builder Brindletoe",
    Nature:"🌿 Willow Naturalist",
    Science:"🔬 Marsh Scholar",
    Geography:"🗺 Cartographer Nia",
    Civics:"⚖ Council Keeper",
    Economics:"🪙 Market Tutor",
    Arts:"🎨 Hall Artist",
    Logic:"🧩 Puzzle Sage"
  };
  return names[subj] || "✨ Realm Teacher";
}

function lrEnsureTeacherState(){
  if(!state.teacherPaths) state.teacherPaths = {};
  if(!state.teacherPaths[activeChild]) state.teacherPaths[activeChild] = {};
  return state.teacherPaths[activeChild];
}

function lrTeacherLessonList(subj){
  const list = ((LESSONS && LESSONS[activeChild]) || {})[subj] || [];
  return list;
}

function lrTeacherPathStart(subj){
  subj = subj || lrTeacherSubjectForRoom();
  const list = lrTeacherLessonList(subj);
  if(!list.length){
    $("feedback").textContent = "No lesson pool loaded for " + activeChild + " / " + subj + ".";
    return;
  }
  const ts = lrEnsureTeacherState();
  ts.activeSubject = subj;
  ts.step = 0;
  ts.correct = 0;
  ts.pathStart = ((state.progress[activeChild] || {})[subj] || 0) % list.length;
  save();
  lrTeacherShowLesson();
}

function lrTeacherCurrentLesson(){
  const ts = lrEnsureTeacherState();
  const subj = ts.activeSubject || lrTeacherSubjectForRoom();
  const list = lrTeacherLessonList(subj);
  if(!list.length) return null;
  const start = typeof ts.pathStart === "number" ? ts.pathStart : 0;
  const step = typeof ts.step === "number" ? ts.step : 0;
  return {subj, list, lesson:list[(start + step) % list.length], index:(start + step) % list.length};
}

function lrTeacherShowLesson(){
  const cur = lrTeacherCurrentLesson();
  if(!cur || !cur.lesson){
    $("feedback").textContent = "No teacher lesson available.";
    return;
  }
  const L = cur.lesson;
  const teacher = lrTeacherNameForSubject(cur.subj);
  $("actionTitle").textContent = "Teacher Lesson";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard">
      <div class="lessonCardTitle">${teacher}</div>
      <div class="lessonCardText">
        <b>Subject:</b> ${cur.subj}<br>
        <b>Mini Lesson:</b><br>${lrEscape(L.teach || "Read carefully and think about the idea.")}
        ${L.practice ? `<br><br><b>Example:</b><br>${lrEscape(L.practice)}` : ""}
        <br><br>
        <button type="button" onclick="lrTeacherShowPractice()">Practice This</button>
      </div>
    </div>`;
  $("lessonBox").classList.add("hidden");
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Teacher Lesson");
}

function lrTeacherShowPractice(){
  const cur = lrTeacherCurrentLesson();
  if(!cur || !cur.lesson) return;
  const L = cur.lesson;
  $("actionTitle").textContent = "Teacher Practice";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard">
      <div class="lessonCardTitle">Practice Before the Gate</div>
      <div class="lessonCardText">
        ${lrEscape(L.q)}
        <div class="teacherChoiceGrid">
          ${(L.c || []).map(ch=>`<button type="button" onclick="lrTeacherAnswer('${String(ch).replace(/'/g,"&#039;")}')">${lrEscape(ch)}</button>`).join("")}
        </div>
      </div>
    </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Teacher Practice");
}

function lrTeacherAnswer(choice){
  const cur = lrTeacherCurrentLesson();
  if(!cur || !cur.lesson) return;
  const L = cur.lesson;
  const ts = lrEnsureTeacherState();
  const correct = choice === L.a;
  if(correct){
    ts.correct = (ts.correct || 0) + 1;
    ts.step = (ts.step || 0) + 1;

    if(!state.progress[activeChild]) state.progress[activeChild] = {};
    state.progress[activeChild][cur.subj] = (state.progress[activeChild][cur.subj] || 0) + 1;

    state.sparks = (state.sparks || 0) + 1;
    addMemory("Teacher Lesson", activeChild + " learned " + cur.subj + " with " + lrTeacherNameForSubject(cur.subj) + ".");
    save();

    if(ts.step >= 3){
      $("actionTitle").textContent = "Lesson Gate Open";
      $("actionText").innerHTML = `
        <div class="lessonCard teacherCard">
          <div class="lessonCardTitle">🏆 Gate Opened</div>
          <div class="lessonCardText">
            You completed a guided ${cur.subj} path.<br><br>
            Correct lessons: ${ts.correct}<br>
            Reward: +1 Spark per lesson and progress recorded.<br><br>
            <button type="button" onclick="lrClosePopup()">Return to Room</button>
          </div>
        </div>`;
      if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Lesson Gate Open");
    }else{
      lrTeacherShowLesson();
    }
  }else{
    $("actionTitle").textContent = "Try Again";
    $("actionText").innerHTML = `
      <div class="lessonCard teacherCard">
        <div class="lessonCardTitle">Not yet</div>
        <div class="lessonCardText">
          Read the lesson again, then try the practice question once more.<br><br>
          <b>Lesson:</b><br>${lrEscape(L.teach || "")}<br><br>
          <button type="button" onclick="lrTeacherShowPractice()">Try Again</button>
        </div>
      </div>`;
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Try Again");
  }
}

function openTeacherSubjectMenu(){
  const subjects = Object.keys((LESSONS && LESSONS[activeChild]) || {}).sort();
  $("actionTitle").textContent = "Teacher Paths";
  $("actionText").innerHTML = `
    <div class="lessonCard teacherCard">
      <div class="lessonCardTitle">Choose a Guided Lesson Path</div>
      <div class="lessonCardText">
        These teachers pull directly from the Question Mountain pools that are already loaded for ${activeChild}.
        <div class="teacherChoiceGrid">
          ${subjects.map(s=>`<button type="button" onclick="lrTeacherPathStart('${s}')">${lrTeacherNameForSubject(s)}<br>${s}</button>`).join("")}
        </div>
      </div>
    </div>`;
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Teacher Paths");
}
/* End Teacher NPC Pack 3 */


/* Teacher NPC Pack 2 - Lesson Paths */
const LR_LEARNING_PATHS={
reading:[
{teach:"Characters are WHO is in the story.",practice:"Who is in a story?",correct:"character"},
{teach:"Setting is WHERE the story happens.",practice:"Where does the story happen?",correct:"setting"},
{teach:"Problem means what went wrong.",practice:"What went wrong?",correct:"problem"}
],
math:[
{teach:"Addition combines groups.",practice:"2 + 3 = ?",correct:"5"},
{teach:"Subtraction takes away.",practice:"5 - 2 = ?",correct:"3"},
{teach:"Shapes have sides.",practice:"Square sides?",correct:"4"}
]
};
let lrLessonStep=0;
function startLearningPath(kind="reading"){
 lrLessonStep=0;
 openLearningStep(kind);
}
function openLearningStep(kind){
 const s=LR_LEARNING_PATHS[kind][lrLessonStep];
 actionTitle.textContent="Lesson Path";
 actionText.innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>Lesson ${lrLessonStep+1}</div><div class='lessonCardText'>${s.teach}<br><br><button onclick="openPracticeStep('${kind}')">Practice</button></div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Lesson Path");
}
function openPracticeStep(kind){
 const s=LR_LEARNING_PATHS[kind][lrLessonStep];
 actionText.innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>Practice</div><div class='lessonCardText'>${s.practice}<br><br><button onclick="finishLessonStep('${kind}')">Answer: ${s.correct}</button></div></div>`;
}
function finishLessonStep(kind){
 lrLessonStep++;
 if(lrLessonStep>=LR_LEARNING_PATHS[kind].length){
  actionText.innerHTML="<div class='lessonCard'><div class='lessonCardTitle'>🏆 Grove Complete</div><div class='lessonCardText'>Path opens and journal updated.</div></div>";
 } else openLearningStep(kind);
}


/* Teacher NPC Pack 1 */
const LR_TEACHERS={
reading:{npc:"🦉 Archivist Elric",lesson:"Setting means WHERE a story happens.",practice:"Where does a story happen?",answers:["setting","character","problem"],correct:"setting"},
nature:{npc:"🌿 Willow Naturalist",lesson:"Plants need sunlight, water, and soil.",practice:"What helps plants grow?",answers:["sunlight","rocks","coins"],correct:"sunlight"},
math:{npc:"🔨 Builder Brindletoe",lesson:"Perimeter means distance around a shape.",practice:"Perimeter measures...",answers:["around","inside","weather"],correct:"around"}
};

function openTeacherGate(kind="reading"){
 const t=LR_TEACHERS[kind];
 let html=`<div class='lessonCard'><div class='lessonCardTitle'>${t.npc}</div><div class='lessonCardText'><b>Lesson</b><br>${t.lesson}<br><br><button onclick="openTeacherPractice('${kind}')">Practice</button></div></div>`;
 actionTitle.textContent="Learning Grove";
 actionText.innerHTML=html;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Learning Grove");
}
function openTeacherPractice(kind){
 const t=LR_TEACHERS[kind];
 actionText.innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>Practice</div><div class='lessonCardText'>${t.practice}<br>${t.answers.join(" • ")}<br><br><button onclick="openTeacherQuiz('${kind}')">Take Quiz</button></div></div>`;
}
function openTeacherQuiz(kind){
 const t=LR_TEACHERS[kind];
 actionText.innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>Quiz Gate</div><div class='lessonCardText'>Answer: ${t.correct}<br>✅ Path Opens</div></div>`;
}


/* Landmark Pack 1: Named Wonder Sites */
const LR_LANDMARKS = {
  "0,0": [
    {name:"🏮 Lantern Hill", tile:"lantern", desc:"Old lantern posts stand along a low hill where travelers once found their way home after dusk.", reward:"Weathered Lantern Note"},
    {name:"🏡 Brindletoe Hamlet", tile:"home", desc:"A tucked-away builder settlement where clever goblins measure doors, roofs, shelves, and impossible castle corners.", reward:"Builder's Measuring String"},
    {name:"🌊 Silver Reed Pond", tile:"water", desc:"A quiet pond where reeds whisper in the breeze and bright ripples move like little pieces of sky.", reward:"Silver Reed"}
  ],
  "1,0": [
    {name:"🌳 Old Oak Crossing", tile:"oak", desc:"A huge oak tree rises over the road. Travelers have tied ribbons to its lower branches for many seasons.", reward:"Oak Token"},
    {name:"🪨 Stonewatch Ridge", tile:"stone", desc:"Weathered stones line the ridge like sleepy guardians watching the road below.", reward:"Ridge Stone"},
    {name:"⛰️ Hammerhill Path", tile:"hill", desc:"The road climbs through rocky ground where distant hammer sounds seem to echo from old workshops.", reward:"Hillmark Chip"}
  ]
};

function lrCurrentLandmarks(){
  if(typeof lrPage === "function"){
    return LR_LANDMARKS[lrPage()] || [];
  }
  return LR_LANDMARKS["0,0"] || [];
}

function openLandmarkJournal(){
  const list = lrCurrentLandmarks();
  $("actionTitle").textContent = "Map Landmarks";
  $("actionText").innerHTML = list.length ? list.map(l=>`
    <div class="lessonCard landmarkCard">
      <div class="lessonCardTitle">${l.name}</div>
      <div class="lessonCardText">${l.desc}<br><br><b>Discovery:</b> ${l.reward}</div>
    </div>`).join("") : `<div class="lessonCard"><div class="lessonCardTitle">No named landmarks here yet</div><div class="lessonCardText">Explore to another map page.</div></div>`;
  $("lessonBox").classList.add("hidden");
  if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Map Landmarks");
}

function lrNearbyLandmarkLine(){
  const list = lrCurrentLandmarks();
  if(!list.length) return "";
  return "🗺️ Nearby landmarks: " + list.map(x=>x.name).join(", ");
}

/* Add landmark line to compact room text if that system exists. */
if(typeof lrCompactRoomText === "function" && !window.__lrLandmarkCompactPatched){
  window.__lrLandmarkCompactPatched = true;
  const _oldLandmarkCompact = lrCompactRoomText;
  lrCompactRoomText = function(raw){
    let text = _oldLandmarkCompact(raw);
    const line = lrNearbyLandmarkLine();
    if(line && text.indexOf("Nearby landmarks") === -1) text += "\n" + line;
    return text;
  };
}
/* End Landmark Pack 1 */


/* Map Rebuild Pack 1 */
const LR_WORLD_PAGES={
"0,0":[
["tree","tree","field","road","field","tree","tree"],
["tree","field","field","road","field","field","tree"],
["field","field","field","road","lantern","field","field"],
["water","water","road","road","road","reed","reed"],
["water","water","field","home","field","field","field"],
["tree","field","field","road","field","stone","tree"],
["tree","tree","field","road","field","tree","tree"]],
"1,0":[
["hill","hill","field","road","field","tree","tree"],
["hill","stone","field","road","field","field","tree"],
["field","field","field","road","oak","field","field"],
["field","field","road","road","road","field","field"],
["field","field","field","road","field","field","field"],
["tree","field","field","road","field","stone","tree"],
["tree","tree","field","road","field","tree","tree"]]
};
function lrPage(){const m=lrEnsurePagedMap(); return `${m.pageX},${m.pageY}`;}
function lrTileIcon(t){return {tree:"🌳",field:"",road:"🟫",water:"🌊",reed:"🌾",home:"🏡",stone:"🪨",hill:"⛰️",lantern:"🏮",oak:"🌳"}[t]||"";}
function lrPagedMapHtml(){const m=lrEnsurePagedMap(); const page=LR_WORLD_PAGES[lrPage()]||LR_WORLD_PAGES["0,0"]; let h='<div class="pagedMapGrid">'; for(let y=0;y<7;y++){for(let x=0;x<7;x++){let ic=(x==m.x&&y==m.y)?"🧍":lrTileIcon(page[y][x]); h+=`<div class="pagedMapTile ${page[y][x]}">${ic}</div>`}} return h+"</div>";}
function lrPagedMapMove(dir){const m=lrEnsurePagedMap(); const mv={north:[0,-1],south:[0,1],east:[1,0],west:[-1,0]}[dir]||[0,0]; m.x+=mv[0]; m.y+=mv[1]; if(m.x<0){m.pageX++;m.x=6} if(m.x>6){m.pageX++;m.x=0} if(m.y<0){m.pageY--;m.y=6} if(m.y>6){m.pageY++;m.y=0}}

const $ = id => document.getElementById(id);

const ROOMS = window.LR_ROOMS || {};
const LESSONS = window.LR_LESSONS || {};
const REWARDS = window.LR_REWARDS || {};
const CAMPAIGNS = window.LR_CAMPAIGNS || {};
const COMPANIONS = window.LR_COMPANIONS || {};

const familyBirthdays = [
 {name:"Daddy", date:"02-14"}, {name:"Mommy", date:"08-16"},
 {name:"Michael", date:"12-03"}, {name:"Ava", date:"01-14"},
 {name:"Luna", date:"07-02"}, {name:"Calista", date:"04-24"}, {name:"Aurora", date:"05-09"}
];

const seasonalCalendar = [
 {season:"Spring",festival:"Bloomwake Festival",flavor:"Fresh flowers decorate the paths."},
 {season:"Summer",festival:"Sunbrook Fair",flavor:"Bright banners flutter near the brook."},
 {season:"Fall",festival:"Harvest Lantern Festival",flavor:"Lanterns sway in the trees."},
 {season:"Winter",festival:"Frostlight Gathering",flavor:"Soft lights glow through the cold."}
];

const fallbackNpcs = {
 "Town Square":{name:"Crossroads Keeper",desc:"A warm-eyed keeper stands beside the fountain.",text:"Welcome back traveler. The fountain remembers every journey. The castle still waits beyond the northern road."},
 "Town Gates":{name:"Guard Rowan",desc:"Guard Rowan stands at attention near the gate.",text:"The roads beyond town change with weather, festivals, and courage."},
 "Town Blocks":{name:"Town Guide",desc:"A friendly town guide watches the street.",text:"The town is busy with shops, travelers, festivals, and rumors."},
 "Town Homes":{name:"Town Child",desc:"A town child watches the roads with curious eyes.",text:"Have you seen the Silver Owl? Someone found feathers in Whisperwood."},
 "Town Mystery":{name:"Old Well",desc:"The old well waits silently behind the homes.",text:"The stones feel older than the town itself."},
 "Town History":{name:"Historian Alder",desc:"Historian Alder studies old notes and lantern-lit maps.",text:"Bring discoveries here. The town remembers."},
 "Underwell":{name:"Ancient Echo",desc:"A low echo moves through the old stones.",text:"The wall shows an Owl, Gear, Castle, Moon, and Gate."},
 "Ancient Chamber":{name:"Ancient Tablet",desc:"An ancient tablet waits on a dusty stone shelf.",text:"Five realms stood beneath the Moon Gate. An empty pedestal waits nearby."},
 "Secret Market":{name:"Shifty Salesman",desc:"A shifty salesman smiles under a patched tent.",text:"Ancient Coins? Hmm... perhaps you have something worth showing me..."},
 "Town Life":{name:"Herky Jerky",desc:"Herky Jerky dances across a tiny stage with a fiddle.",text:"Music, warm food, and bright laughter fill the room."},
 "Whisperwood":{name:"Forest Guide",desc:"A quiet forest guide watches the trail with story cards.",text:"Whisperwood teaches reading, words, sounds, and careful noticing."},
 "Secret Den":{name:"Hidden Keeper",desc:"A hidden keeper sits by a tiny lantern.",text:"Secret places reward careful readers."},
 "Iron Hills":{name:"Mine Tutor",desc:"A sturdy tutor studies a measuring rope and slate.",text:"Iron Hills teaches math through gears, maps, lifts, and measurements."},
 "Crystal Marsh":{name:"Marsh Naturalist",desc:"A naturalist kneels beside reeds with an observation journal.",text:"Crystal Marsh teaches science through careful observation."},
 "Kingdom Archives":{name:"Archive Guide",desc:"An archive guide carries records tied with blue ribbon.",text:"The archives teach history, writing, evidence, and civic thinking."},
 "Grammar Grove":{name:"Grammar Guide",desc:"A grammar guide holds a book marked with punctuation ribbons.",text:"Grammar Grove teaches sentences, spelling, punctuation, and word patterns."},
 "Home":{name:"Home Keeper",desc:"A gentle home keeper watches over family treasures.",text:"Home is where rewards, memories, companions, and decorations belong."},
 "Castle Gate":{name:"Gate Echo",desc:"The enchanted gate hums with quiet power.",text:"Mommy and Daddy remain beyond the gate. Master the realms and return when the world is healed."}
};

const realNpcRooms = {
  crossroads:"Crossroads Keeper",
  southGatePlaza:"Guard Rowan",
  seasonalShop:"Shopkeeper Elric",
  pictureShop:"Curator Mira",
  luckyKettle:"Herky Jerky",
  shiftyTent:"Shifty Salesman",
  historicalSociety:"Historian Alder",
  mapRoom:"Ancient Map",
  underwellChamber:"Ancient Mural",
  relicRoom:"Ancient Tablet",
  kidsSquare:"Town Child",
  oldWell:"Old Well"
};

const realmStages = {
 "Whisperwood":["Cracked Story Stones. Dim owl perch. Hidden den sealed.","One Story Stone restored. Owl feathers found.","Silver Owl returns. Hidden den begins opening.","Whisperwood restored. Reader Rabbit strengthened."],
 "Iron Hills":["Broken lift. Silent machinery.","Survey markers repaired.","Lift works again.","Gear Fox routes restored."],
 "Crystal Marsh":["Broken weather station. Disturbed habitats.","Nature logs recovered.","Weather station repaired.","Crystal Marsh restored."],
 "Kingdom Archives":["Lost records and fallen banners.","Records recovered.","Timeline repaired.","Archives restored."],
 "Grammar Grove":["Letter stones scattered.","Letter stones restored.","Punctuation arch repaired.","Grammar Grove restored."]
};

const realmObjects = {
 "Whisperwood":["Story Stone cracked and dark.","Small glow returns to Story Stone.","Runes awaken. Owl feather nearby.","Story Stone fully restored."],
 "Iron Hills":["Broken chains hang silent.","Supports repaired.","Lift moves again.","Iron lift restored."],
 "Crystal Marsh":["Weather station broken.","Repairs underway.","Station active.","Marsh observations resume."],
 "Kingdom Archives":["Timeline torn.","Timeline patched.","Timeline repaired.","Archive complete."],
 "Grammar Grove":["Punctuation arch cracked.","Repairs underway.","Arch restored.","Grammar gate shines."]
};

const shopData = {
 seasonal:{
  Spring:["Flower Rug","Garden Banner","Tulip Painting","Nest Basket"],
  Summer:["River Picture","Bluebird Painting","Sun Garland","Picnic Set"],
  Fall:["Harvest Wreath","Pumpkin Rug","Lantern Post","Autumn Picture"],
  Winter:["Snow Banner","Frost Lamp","Winter Painting","Pine Garland"]
 },
 pictures:["Owl Picture","Marsh Picture","Mountain Picture","Reader Rabbit Portrait","Gear Fox Sketch","Archivist Owl Banner","Birthday Frame","Festival Frame","Castle Sketch"],
 diner:["Berry Pie","Honey Bread","Soup Pot","Tea Tray","Fruit Basket","Harvest Pie","Winter Cookies","Lantern Cake","Birthday Cake"],
 relics:["Silver Owl Statue","Clockwork Fox Figure","Crystal Frog Lantern","Ancient Tome Display","Mini Castle Model"]
};

const dailyQuests = [
 {name:"Read 5 lessons",reward:"10 Sparks"},
 {name:"Complete 5 math lessons",reward:"Gear Crate Decoration"},
 {name:"Visit Frog Pool",reward:"Nature Journal"},
 {name:"Visit Owl Clearing",reward:"Festival Token"},
 {name:"Visit Survey Camp",reward:"Festival Token"},
 {name:"Visit Scribe Camp",reward:"Festival Token"}
];

const moonClues = {
  underwellChamber:{id:"underwellMural",name:"Underwell Mural",clue:"The mural shows an Owl, Gear, Castle, Moon, and Gate.",hint:"The symbols connect the realms to the sealed castle."},
  relicRoom:{id:"moonStairSymbol",name:"Moon + Stair Symbol",clue:"A moon and stair symbol is scratched into the Relic Room wall.",hint:"The Moon Stair may be a hidden path, not just a legend."},
  storyStone:{id:"halfMoonMark",name:"Half Moon Mark",clue:"A half moon carving is hidden near the Story Stone.",hint:"Whisperwood knows something about the Moon Stair."},
  surveyCamp:{id:"upperPathCollapsed",name:"Upper Path Collapsed Note",clue:"A survey note says: upper path collapsed.",hint:"Iron Hills may once have had an upper route."},
  recordVault:{id:"sixthRoadSealed",name:"Sixth Road Was Sealed",clue:"An archive page says: the sixth road was sealed.",hint:"The old stories about five realms may be incomplete."},
  mapRoom:{id:"moonriseHeights",name:"Moonrise Heights Map",clue:"A faded map points toward Moonrise Heights.",hint:"Moonrise Heights may be connected to the Moon Stair."}
};

function DEFAULT_PROFILE_STATE(){
 return {loc:"crossroads",room:1,sparks:0,coins:0,ancientCoins:0,streak:0,progress:{},log:[],inventory:[],memoryBook:[],reviewQueue:[],usedLessons:[],homes:{},dayCycle:{day:1},mystery:{moonStair:{}},mastery:{},bossWins:{},attendance:{},unitProgress:{}};
}


/* Stability Pack 1: Safe Startup */
const LR_PROFILE_STORAGE_KEY = "LR_profiles_recovery_2a";
const LR_ACTIVE_CHILD_STORAGE_KEY = "LR_active_child_recovery_2a";
let LR_lastSystemError = "";

function LR_stabilityConfig(){
 return window.LR_STABILITY_CONFIG || {repairDefaults:{students:["Luna","Ava","Michael"],safeRoom:"crossroads"},storageKeys:{profiles:LR_PROFILE_STORAGE_KEY,activeChild:LR_ACTIVE_CHILD_STORAGE_KEY}};
}

function LR_studentList(){
 return ((LR_stabilityConfig().repairDefaults || {}).students || ["Luna","Ava","Michael"]);
}

function LR_defaultProfiles(){
 const out = {};
 LR_studentList().forEach(name=>out[name]=DEFAULT_PROFILE_STATE());
 return out;
}

function LR_safeParseJSON(raw, label){
 if(!raw) return null;
 try{
   return JSON.parse(raw);
 }catch(err){
   LR_lastSystemError = "Could not read saved profiles. A corrupt backup was preserved.";
   try{
     const prefix = ((LR_stabilityConfig().storageKeys || {}).corruptBackupPrefix || "LR_corrupt_profiles_backup_");
     localStorage.setItem(prefix + Date.now(), raw);
   }catch(e){}
   console.error("LearningRealms save parse failed", label, err);
   return null;
 }
}

function LR_loadProfilesSafe(){
 const cfg = LR_stabilityConfig();
 const key = ((cfg.storageKeys || {}).profiles) || LR_PROFILE_STORAGE_KEY;
 const raw = localStorage.getItem(key);
 const parsed = LR_safeParseJSON(raw, key);
 if(!parsed || typeof parsed !== "object") return LR_defaultProfiles();
 return parsed;
}

function LR_ensureObject(value, fallback){
 return value && typeof value === "object" && !Array.isArray(value) ? value : (fallback || {});
}

function LR_ensureArray(value){
 return Array.isArray(value) ? value : [];
}

function LR_repairProfile(profile, child){
 const def = DEFAULT_PROFILE_STATE();
 let p = LR_ensureObject(profile, DEFAULT_PROFILE_STATE());

 Object.keys(def).forEach(k=>{
   if(p[k] === undefined || p[k] === null){
     if(Array.isArray(def[k])) p[k] = [];
     else if(def[k] && typeof def[k] === "object") p[k] = JSON.parse(JSON.stringify(def[k]));
     else p[k] = def[k];
   }
 });

 p.loc = (typeof p.loc === "string" && ROOMS[p.loc]) ? p.loc : (((LR_stabilityConfig().repairDefaults || {}).safeRoom) || "crossroads");
 p.room = Number.isFinite(Number(p.room)) && Number(p.room) > 0 ? Number(p.room) : 1;
 p.sparks = Number.isFinite(Number(p.sparks)) ? Number(p.sparks) : 0;
 p.coins = Number.isFinite(Number(p.coins)) ? Number(p.coins) : 0;
 p.ancientCoins = Number.isFinite(Number(p.ancientCoins)) ? Number(p.ancientCoins) : 0;
 p.streak = Number.isFinite(Number(p.streak)) ? Number(p.streak) : 0;

 p.progress = LR_ensureObject(p.progress,{});
 if(!p.progress[child] || typeof p.progress[child] !== "object") p.progress[child] = {};
 Object.keys(LESSONS[child] || {}).forEach(subj=>{
   if(!Number.isFinite(Number(p.progress[child][subj]))) p.progress[child][subj] = 0;
 });

 p.log = LR_ensureArray(p.log);
 p.inventory = LR_ensureArray(p.inventory);
 p.memoryBook = LR_ensureArray(p.memoryBook);
 p.reviewQueue = LR_ensureArray(p.reviewQueue);
 p.usedLessons = LR_ensureArray(p.usedLessons);

 p.homes = LR_ensureObject(p.homes,{});
 if(!p.homes[child] || typeof p.homes[child] !== "object"){
   p.homes[child] = {storage:[],equip:{wall:null,shelf:null,desk:null,table:null,rug:null,pet1:null,pet2:null,food:null,hat:null,cloak:null,accessory:null,held:null}};
 }
 p.homes[child].storage = LR_ensureArray(p.homes[child].storage);
 p.homes[child].equip = LR_ensureObject(p.homes[child].equip,{});
 ["wall","shelf","desk","table","rug","pet1","pet2","food","hat","cloak","accessory","held"].forEach(slot=>{
   if(!(slot in p.homes[child].equip)) p.homes[child].equip[slot] = null;
 });

 p.dayCycle = LR_ensureObject(p.dayCycle,{day:1});
 if(!Number.isFinite(Number(p.dayCycle.day))) p.dayCycle.day = 1;

 p.mystery = LR_ensureObject(p.mystery,{moonStair:{}});
 p.mystery.moonStair = LR_ensureObject(p.mystery.moonStair,{});
 p.mastery = LR_ensureObject(p.mastery,{});
 p.bossWins = LR_ensureObject(p.bossWins,{});
 if(!p.bossWins[child] || typeof p.bossWins[child] !== "object") p.bossWins[child] = {};
 p.attendance = LR_ensureObject(p.attendance,{});
 p.unitProgress = LR_ensureObject(p.unitProgress,{});

 p._lastStabilityRepair = new Date().toLocaleString();
 return p;
}

function LR_repairAllProfiles(profiles){
 const repaired = LR_ensureObject(profiles, LR_defaultProfiles());
 LR_studentList().forEach(name=>{
   repaired[name] = LR_repairProfile(repaired[name] || DEFAULT_PROFILE_STATE(), name);
 });
 return repaired;
}
/* End Stability Pack 1: Safe Startup */

let allProfiles = LR_repairAllProfiles(LR_loadProfilesSafe());
let activeChild = localStorage.getItem(LR_ACTIVE_CHILD_STORAGE_KEY) || "Luna";
if(!LR_studentList().includes(activeChild)) activeChild = "Luna";
let state = LR_repairProfile(allProfiles[activeChild] || DEFAULT_PROFILE_STATE(), activeChild);
allProfiles[activeChild] = state;

function student(){return activeChild;}
function room(){if(!ROOMS[state.loc]) state.loc="crossroads"; return ROOMS[state.loc];}
function save(){
 try{
   state = LR_repairProfile(state, activeChild);
   allProfiles[activeChild]=state;
   localStorage.setItem(LR_PROFILE_STORAGE_KEY,JSON.stringify(allProfiles));
   localStorage.setItem(LR_ACTIVE_CHILD_STORAGE_KEY,activeChild);
 }catch(err){
   LR_lastSystemError = "Save failed: " + (err && err.message ? err.message : err);
   console.error("LearningRealms save failed", err);
   try{$("feedback").textContent = LR_lastSystemError;}catch(e){}
 }
}
function ensureProgress(){if(!state.progress[activeChild]) state.progress[activeChild]={}; Object.keys(LESSONS[activeChild]||{}).forEach(s=>{if(state.progress[activeChild][s]===undefined) state.progress[activeChild][s]=0;});}
function ensureHome(){if(!state.homes[activeChild]) state.homes[activeChild]={storage:[],equip:{wall:null,shelf:null,desk:null,table:null,rug:null,pet1:null,pet2:null,food:null,hat:null,cloak:null,accessory:null,held:null}}; return state.homes[activeChild];}
function ensureMystery(){if(!state.mystery)state.mystery={moonStair:{}}; if(!state.mystery.moonStair)state.mystery.moonStair={};}
function totalProgress(child=activeChild){const p=state.progress[child]||{}; return Object.values(p).reduce((a,b)=>a+(b||0),0);}
function stage(child=activeChild){const t=totalProgress(child); if(t>=30)return 3; if(t>=20)return 2; if(t>=10)return 1; return 0;}
function currentFestival(){const m=new Date().getMonth()+1; if(m>=3&&m<=5)return seasonalCalendar[0]; if(m>=6&&m<=8)return seasonalCalendar[1]; if(m>=9&&m<=11)return seasonalCalendar[2]; return seasonalCalendar[3];}
function getWeatherType(){const d=new Date().getDate(); if(currentFestival().season==="Winter"&&d%4===0)return "snow"; if(d%5===0)return "rain"; if(d%7===0)return "fog"; if(d%3===0)return "wind"; return "clear";}
function getTimeOfDay(){const h=new Date().getHours(); if(h>=5&&h<11)return "Morning"; if(h>=11&&h<17)return "Daytime"; if(h>=17&&h<21)return "Evening"; return "Nighttime";}
function todayCelebration(){const d=new Date(); const md=String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0"); const hit=familyBirthdays.find(x=>x.date===md); return hit?`\n\nCelebration Day: ${hit.name}'s birthday!`:"";}
function exitsText(r){return "Exits: "+Object.keys(r.exits||{}).map(x=>x[0].toUpperCase()+x.slice(1)).join(", ")+".";}
function npc(){const r=room(); const base = r.npc || fallbackNpcs[r.zone] || fallbackNpcs["Town Blocks"]; if(realNpcRooms[state.loc]) return {...base,name:realNpcRooms[state.loc]}; return base;}
function roomHasNpc(){return !!room().npc || !!realNpcRooms[state.loc];}
function addMemory(title,text){if(!state.memoryBook)state.memoryBook=[]; state.memoryBook.push({title,text,date:new Date().toLocaleDateString()});}


/* Travel/Layout Polish Rebuild: minimap, quick travel, shop hub, compass */
function lrCompassDirectionLabel(dir){ const names={north:"North",south:"South",east:"East",west:"West",northeast:"North-East",northwest:"North-West",southeast:"South-East",southwest:"South-West",up:"Up",down:"Down"}; return names[dir] || (dir?dir.charAt(0).toUpperCase()+dir.slice(1):""); }
function lrCompassButtonHtml(dir,target){ const label=lrCompassDirectionLabel(dir); const short={north:"N",south:"S",east:"E",west:"W",northeast:"NE",northwest:"NW",southeast:"SE",southwest:"SW",up:"Up",down:"Dn"}[dir] || label; const title=ROOMS[target]?ROOMS[target].title:target; return `<button class="compassBtn compass-${lrEscape(dir)}" onclick="go('${lrEscape(dir)}')" title="${lrEscape(label)} to ${lrEscape(title)}"><b>${lrEscape(short)}</b><span>${lrEscape(title)}</span></button>`; }
function lrRenderMainCompass(){ const mount=$("mainCompassNav"); if(!mount) return; const r=room(); const exits=r.exits||{}; const order=["northwest","north","northeast","west","center","east","southwest","south","southeast","up","down"]; if(!Object.keys(exits).length){mount.innerHTML=""; return;} let html='<div class="compassBox"><div class="compassTitle">Move by Compass</div><div class="compassGrid">'; order.forEach(dir=>{ if(dir==="center") html += `<div class="compassCenter">You<br>Are<br>Here</div>`; else if(exits[dir]) html += lrCompassButtonHtml(dir,exits[dir]); else html += `<div class="compassBlank"></div>`; }); html+='</div></div>'; mount.innerHTML=html; }
var LR_STATIC_MINIMAP_ROWS=["wwwwccwwfffff","wwwpcpppffrff","mmppptpppprff","mmrpptpppprff","mmrppthppprff","mrrpptppppfff","fffpppppppfff","fffpptpppmfff","ffffptpppmfff","fffffppppmmmm","ffffwppwwmmmm"];
var LR_STATIC_MINIMAP_POINTS={ enchantedGate:[5,0,"castle","C"], royalCauseway:[5,1,"path",""], crossroads:[5,4,"town","★"], townSquare:[4,4,"town","T"], mainStreet:[5,5,"town",""], questBoardPlaza:[5,6,"town","Q"], marketRow:[6,4,"shop","$"], seasonalShop:[7,4,"shop","$"], pictureRow:[4,4,"shop","$"], pictureShop:[3,4,"shop","$"], cloverLane:[6,5,"shop","$"], luckyKettle:[7,5,"shop","$"], crookedAlley:[4,6,"shop","$"], shiftyTent:[4,7,"shop","$"], home:[2,5,"home","H"], residentialRow:[3,5,"home",""] , whisperwood:[10,3,"realm","R"], storyStone:[11,3,"realm",""] , brookBridge:[10,5,"realm",""] , ironGate:[1,3,"realm","M"], forgeHall:[1,4,"realm",""] , gearWorkshop:[1,5,"realm",""] , crystalMarsh:[6,9,"realm","S"], reedPool:[6,10,"realm",""] , frogPool:[7,10,"realm",""] , archiveRoad:[5,2,"realm","W"], recordVault:[5,1,"realm",""] , grammarRoad:[8,2,"realm","E"], councilRoad1:[3,2,"realm","C"], mapmakerRoad1:[4,2,"realm","G"], merchantRoad1:[6,3,"realm","$"], puzzleRoad1:[7,2,"realm","?"], wildrootRoad1:[9,4,"realm","N"], hearthwellRoad1:[8,5,"realm","+"], bardwoodRoad1:[9,3,"realm","♪"], scribeRoad1:[4,1,"realm","S"], homesteadRoad1:[3,6,"realm","L"] };
function lrMinimapFallbackPoint(r){ const subject=(r&&r.subject)||""; const zone=(r&&r.zone)||""; if(zone==="Home") return [2,5,"home","H"]; if(zone.indexOf("Town")>=0) return [5,4,"town","★"]; if(zone.indexOf("Shop")>=0||zone.indexOf("Market")>=0) return [6,4,"shop","$"]; if(subject==="Reading") return [10,3,"realm","R"]; if(subject==="Math") return [1,4,"realm","M"]; if(subject==="Science") return zone.indexOf("Marsh")>=0?[6,9,"realm","S"]:[10,5,"realm","S"]; if(subject==="Writing") return [5,2,"realm","W"]; if(subject==="History") return [5,1,"realm","H"]; if(subject==="English") return [8,2,"realm","E"]; if(subject==="Civics") return [3,2,"realm","C"]; if(subject==="Geography") return [4,2,"realm","G"]; if(subject==="Economics") return [6,3,"realm","$"]; if(subject==="Logic") return [7,2,"realm","?"]; if(subject==="Nature") return [9,4,"realm","N"]; if(subject==="Health") return [8,5,"realm","+"]; if(subject==="Music") return [9,3,"realm","♪"]; if(subject==="Copywork") return [4,1,"realm","S"]; if(subject==="Life Skills") return [3,6,"realm","L"]; return [5,4,"town","★"]; }
function lrStaticMapType(ch){ return ch==="w"?"water":ch==="p"?"path":ch==="t"?"town":ch==="m"?"mountain":ch==="c"?"castle":"forest"; }
function lrStaticMinimapGridHtml(){ const r=room(); const herePoint=LR_STATIC_MINIMAP_POINTS[state.loc]||lrMinimapFallbackPoint(r); const markerIds=["crossroads","home","seasonalShop","pictureShop","luckyKettle","shiftyTent","enchantedGate","whisperwood","ironGate","crystalMarsh","archiveRoad","grammarRoad","puzzleRoad1","wildrootRoad1","hearthwellRoad1","homesteadRoad1"]; let html='<div class="lrStaticMap" aria-label="Static realm minimap">'; for(let y=0;y<LR_STATIC_MINIMAP_ROWS.length;y++){ for(let x=0;x<LR_STATIC_MINIMAP_ROWS[y].length;x++){ const type=lrStaticMapType(LR_STATIC_MINIMAP_ROWS[y][x]); let point=null; for(let i=0;i<markerIds.length;i++){ const p=LR_STATIC_MINIMAP_POINTS[markerIds[i]]; if(p&&p[0]===x&&p[1]===y){point=p;break;} } const marker=point?`<span class="lrMapMarker ${point[2]}Mark">${lrEscape(point[3]||"•")}</span>`:""; const player=(herePoint[0]===x&&herePoint[1]===y)?'<span class="lrPlayerDot" title="You are here"></span>':''; html += `<span class="lrMapTile ${type}">${marker}${player}</span>`; }} html+='</div>'; return html; }
function lrMiniMapHtml(){ const r=room(); const exits=Object.keys(r.exits||{}); const exitText=exits.length?exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]]&&ROOMS[r.exits[d]].title)||r.exits[d])}</span>`).join(""):"<span>No visible exits</span>"; return `<div class="lrMiniMap"><div class="lrMiniMapTitle">🧭 Realm Mini Map</div>${lrStaticMinimapGridHtml()}<div class="lrMiniMapHere">You are here:<br><b>${lrEscape(r.title||state.loc)}</b><small>${lrEscape(r.zone||"Unknown")}</small></div><div class="lrMiniMapLegend"><span><i class="lrLegendSwatch town"></i>Town</span><span><i class="lrLegendSwatch path"></i>Road</span><span><i class="lrLegendSwatch water"></i>Water</span><span><i class="lrLegendSwatch mountain"></i>Hills</span></div><div class="lrMiniMapExits compact">${exitText}</div></div>`; }
function lrTravelSubjectHubs(){ const hubs=(typeof atlasHubs==="function"?atlasHubs():[]); return hubs.filter(h=>h.category==="subject"&&h.subject&&ROOMS[h.id]); }
function lrShopHubs(){ const ids=["seasonalShop","pictureShop","luckyKettle","shiftyTent"]; return ids.filter(id=>ROOMS[id]).map(id=>({id,title:ROOMS[id].title||id,zone:ROOMS[id].zone||"Shop"})); }
function lrJumpToSubject(select){ const dest=select.value; select.value=""; if(!dest)return; if(typeof fastTravelAtlas==="function") fastTravelAtlas(dest); else { state.loc=dest; state.room++; save(); renderRoom(); } }
function lrJumpToShop(select){ const dest=select.value; select.value=""; if(!dest)return; state.loc=dest; state.room++; save(); renderRoom(); if(typeof openShop==="function") lrSafeBrowseShopPopup(); }
function lrQuickTravelHtml(){ const subjectOpts=lrTravelSubjectHubs().map(h=>`<option value="${lrEscape(h.id)}">${lrEscape(h.icon||"✨")} ${lrEscape(h.subject)} - ${lrEscape(h.title)}</option>`).join(""); const shopOpts=lrShopHubs().map(h=>`<option value="${lrEscape(h.id)}">${lrEscape(h.title)}</option>`).join(""); return `<div class="lrTravelPanel"><label class="lrTravelLabel">🪄 Flying Carpet<select onchange="lrJumpToSubject(this)"><option value="">Choose a subject realm...</option>${subjectOpts}</select></label><label class="lrTravelLabel">🏪 Shop Lantern<select onchange="lrJumpToShop(this)"><option value="">Choose a shop...</option>${shopOpts}</select></label></div>`; }
function openShopHub(){ $("lessonBox").classList.add("hidden");
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Castle Prestige");
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Pet Corner");
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Long Journey");
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Quest Journal");
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("World Directory"); $("storageBox").classList.remove("hidden"); $("actionTitle").textContent="Town Shop Hub"; $("actionText").innerHTML=`<div class="lessonCard"><div class="lessonCardTitle">🏪 Shop Lantern Hub</div><div class="lessonCardText">Pick a shop and the lantern path will take you there immediately.</div></div>`; $("storageItems").innerHTML=lrShopHubs().map(h=>`<div class="atlasHub"><div class="atlasHubHeader"><span>🏪</span><b>${lrEscape(h.title)}</b><span>${lrEscape(h.zone)}</span></div><div class="reportButtonRow"><button onclick="state.loc='${lrEscape(h.id)}'; state.room++; save(); renderRoom(); lrSafeBrowseShopPopup();">Visit Shop</button></div></div>`).join(""); }
function lrAddActionGroup(title,items){ if(!items||!items.length)return; const box=$("leftActionButtons"); const wrap=document.createElement("div"); wrap.className="lrActionGroup"; const h=document.createElement("div"); h.className="lrActionGroupTitle"; h.textContent=title; wrap.appendChild(h); items.forEach(item=>{ const b=document.createElement("button"); b.type="button"; b.textContent=item.label; b.onclick=item.fn; wrap.appendChild(b); }); box.appendChild(wrap); }
/* End Travel/Layout Polish Rebuild */


/* Immersion Pack 1: narrative room expansion */
const LR_ROOM_IMMERSION = {
"Town Square":"The heart of town opens around an old fountain whose stones have been worn smooth by countless travelers. Flower boxes hang beneath windows while banners sway overhead.\n\nThe smell of bread drifts between shops and distant laughter carries through the streets. It feels like the sort of place where adventures quietly begin.",
"Whisperwood":"The path bends beneath towering silver bark trees whose leaves shimmer whenever the wind passes through the canopy. Ferns spill across the forest floor while shafts of sunlight fall like golden ladders between the trunks.\n\nA stream slips over smooth stones somewhere deeper in the woods. Moss covered rocks line the trail and acorns rest beneath old roots as though woodland creatures have been preparing for winter.",
"Iron Hills":"Stone ridges rise around the road and ancient hammer marks still scar the weathered cliffs. The air carries hints of coal, rain, and warm metal from distant workshops.\n\nFar away, faint ringing echoes through the hills as though hidden forges still burn beneath the mountains.",
"Kingdom Archives":"Great shelves stretch into shadow while scroll cases, maps, and weathered books wait beneath hanging lamps. Dust dances through shafts of light and every corridor promises another forgotten tale.\n\nThe silence here feels alive, as though the halls remember every traveler who came seeking knowledge.",
"Home":"Warm light settles across familiar walls while treasures from past journeys rest where they were last placed. Blank spaces still wait for future discoveries.\n\nThe house quietly remembers every adventure brought back through its door.",

"Whisperwood":"Tall silver bark trees rise overhead and their leaves flicker softly whenever the wind moves through the forest. Ferns gather beside the trail while tiny birds dart through the branches above.\n\nSomewhere deeper in the woods a stream can be heard slipping over smooth stones. It feels like a place where stories might still be hiding beneath roots and moss.",
"Iron Hills":"Stone ridges rise around the road and old hammer marks can still be seen on weathered rock faces. The air smells faintly of metal, coal, and rain.\n\nFar away, steady ringing echoes through the hills as though hidden forges are still awake beneath the mountains.",
"Kingdom Archives":"Rows of shelves, scroll cases, and old maps seem to stretch farther than expected. Dust dances through beams of light while the quiet almost feels alive.\n\nEvery hallway seems to promise another forgotten tale waiting to be rediscovered.",
"Home":"Warm light settles across the room and familiar belongings rest where past adventures left them. It feels safe here.\n\nThe walls quietly remember every treasure brought back from distant journeys."
};

function lrImmersionText(r){
 let t = LR_ROOM_IMMERSION[r.zone] || "";
 if(r.subject){
   t += "\n\nA feeling of learning and discovery hangs over this place, inviting travelers to slow down and notice details.";
 }
 return t;
}


/* Layout Polish 3B: right-side student records dropdown */
function lrSetRightInfoPanel(){
 const sel = $("rightInfoSelect");
 if(!sel) return;
 const ids = ["progress","inventory","memoryBook","log"];
 ids.forEach(id=>{
   const panel = $(id+"Panel");
   if(panel) panel.classList.toggle("hidden", sel.value !== id);
 });
}


/* Layout/GamePlay Polish 4A: move common gameplay actions into main room window */
function lrMainGameplayActionButton(label, fnName){
  return `<button type="button" onclick="${fnName}">${label}</button>`;
}

function lrRenderMainGameplayActions(){
  const mount = $("mainGameplayActions");
  if(!mount) return;
  const buttons = [];
  const r = room();

  if(roomHasNpc()) buttons.push(lrMainGameplayActionButton("Talk to " + lrEscape(npc().name || "NPC"), "talk()"));

  if(["seasonalShop","pictureShop","luckyKettle","shiftyTent"].includes(state.loc)){
    buttons.push(lrMainGameplayActionButton("Browse Shop", "openShop()"));
  }

  if(state.loc === "questBoardPlaza"){
    buttons.push(lrMainGameplayActionButton("Read Quest Board", "openQuestBoard()"));
    buttons.push(lrMainGameplayActionButton("Classroom Plan", "openDailyClassroomBoard()"));
  }

  if(state.loc === "historicalSociety"){
    buttons.push(lrMainGameplayActionButton("Investigation Board", "openInvestigationBoard()"));
  }

  if(moonClues[state.loc]){
    buttons.push(lrMainGameplayActionButton("Record Moon Clue", "recordMoonClue()"));
  }

  if(r.subject){
    buttons.push(lrMainGameplayActionButton("Mastery Status", "showMasteryStatus()"));
    buttons.push(lrMainGameplayActionButton("Realm Boss", "startBossChallenge()"));
    buttons.push(lrMainGameplayActionButton("Adaptive Review", "openAdaptiveReview()"));
  }

  if(buttons.length){
    mount.innerHTML = `<div class="mainGameplayBox"><div class="mainGameplayTitle">Room Actions</div><div class="mainGameplayGrid">${buttons.join("")}</div></div>`;
  } else {
    mount.innerHTML = `<div class="mainGameplayBox muted"><div class="mainGameplayTitle">Room Actions</div><p>No special room actions here yet. Explore another path or use quick travel.</p></div>`;
  }
}
/* End Layout/GamePlay Polish 4A main gameplay actions */


/* Interface Pack 5A SAFE: Sierra-style popup framework */
function lrOpenPopup(title, html){
 const root = $("lrPopupRoot");
 const titleEl = $("lrPopupTitle");
 const bodyEl = $("lrPopupBody");
 if(!root || !titleEl || !bodyEl) return;
 titleEl.textContent = title;
 bodyEl.innerHTML = html || "<p>Nothing here yet.</p>";
 root.classList.remove("hidden");
}
function lrClosePopup(){
 const root = $("lrPopupRoot");
 if(root) root.classList.add("hidden");
}
function lrGetPanelHtml(id){
 const el = $(id);
 if(!el) return "<p>Nothing here yet.</p>";
 const html = el.innerHTML && el.innerHTML.trim() ? el.innerHTML : el.textContent;
 return html && String(html).trim() ? html : "<p>Nothing here yet.</p>";
}
function openInventoryPopup(){ lrOpenPopup("Inventory", lrGetPanelHtml("inventory")); }
function openProgressPopup(){ lrOpenPopup("Progress", lrGetPanelHtml("progress")); }
function openMemoryPopup(){ lrOpenPopup("Memory Book", lrGetPanelHtml("memoryBook")); }
function openLogPopup(){ lrOpenPopup("Learning Log", lrGetPanelHtml("log")); }

function lrEnsureSierraBarMount(){
 let mount = $("sierraBarMount");
 if(mount) return mount;
 const compass = $("mainCompassNav");
 if(!compass || !compass.parentNode) return null;
 mount = document.createElement("div");
 mount.id = "sierraBarMount";
 mount.className = "sierraBarMount";
 compass.parentNode.insertBefore(mount, compass.nextSibling);
 return mount;
}
function lrRenderSierraBar(){
 const mount = lrEnsureSierraBarMount();
 if(!mount) return;
 mount.innerHTML = `
 <div class="sierraBar">
   <button type="button" onclick="openInventoryPopup()">🎒 Inventory</button>
   <button type="button" onclick="openMemoryPopup()">📖 Memory</button>
   <button type="button" onclick="openProgressPopup()">⭐ Progress</button>
   <button type="button" onclick="openLogPopup()">📝 Learning</button>
 </div>`;
}
/* End Interface Pack 5A SAFE */

/* Interface Pack 5B popup expansion */
function openQuestPopup(){
 let html="<p>No quest board found here.</p>";
 if(state.loc==="questBoardPlaza"){
   html="<p>Quest Board available here.</p>";
 }
 lrOpenPopup("Quest Board",html);
}
function openCompanionPopup(){
 lrOpenPopup("Companions",lrGetPanelHtml("companionDen") || "<p>No companions yet.</p>");
}
function openAtlasPopup(){
 const r=room();
 let html=`<p><b>Current Room:</b> ${lrEscape(r.title||state.loc)}</p>`;
 html+=`<p><b>Zone:</b> ${lrEscape(r.zone||"Unknown")}</p>`;
 html+=`<p><b>Subject:</b> ${lrEscape(r.subject||"None")}</p>`;
 lrOpenPopup("Atlas",html);
}

const _oldRenderSierraBar=lrRenderSierraBar;
lrRenderSierraBar=function(){
 _oldRenderSierraBar();
 const m=$("sierraBarMount");
 if(!m)return;
 m.innerHTML+=`
 <div class="sierraBar sierraBar2">
   <button onclick="openQuestPopup()">📜 Quests</button>
   <button onclick="openCompanionPopup()">🐾 Companion</button>
   <button onclick="openAtlasPopup()">🗺 Atlas</button>
 </div>`;
}



/* Immersion Pack 3: Living World Expansion */
const LR_AMBIENT_DISCOVERIES = [
 "A red squirrel darts across the path carrying an acorn almost as large as its head.",
 "Someone has stacked smooth river stones beside the trail into a tiny tower.",
 "A feather catches on a branch and turns slowly in the breeze.",
 "Old initials have been carved into a weathered fence post.",
 "A tiny bird nest rests safely among the roots of a tree.",
 "You notice faint footprints pressed into the soft earth.",
 "A loose page flutters from a shelf and settles at your feet.",
 "An old lantern hangs from a hook, long cold but carefully polished.",
 "A beetle pushes through moss carrying a crumb many times its size.",
 "The wind carries the distant smell of bread and warm spice."
];

const LR_ZONE_LORE = {
 "Town Square":`The town fountain splashes softly while colorful banners sway overhead. Flower boxes hang beneath windows and the smell of bread drifts through the market road.

Merchants call to one another while distant laughter echoes between stone buildings. It feels like the sort of place where adventures begin quietly.`,

 "Whisperwood":`Towering silver bark trees arch overhead while sunlight falls through the canopy in golden shafts. Ferns spread across the forest floor and moss climbs over old stones.

Somewhere deeper in the woods a stream slips over smooth rocks while unseen birds trade songs among the branches.`,

 "Iron Hills":`Stone ridges rise around the road and old hammer marks still scar the cliffs. The air smells faintly of rain, coal, and warm iron.

Far away, rhythmic ringing echoes through the hills as though hidden forges still burn beneath the mountains.`,

 "Kingdom Archives":`Great shelves stretch into shadow while maps, scrolls, and weathered books wait beneath hanging lamps.

Dust drifts through beams of light and every corridor feels as though it remembers the travelers who came seeking knowledge.`,

 "Market":`Canvas awnings sway overhead while merchants straighten wares and polish signs.

The smell of spice, cloth dye, and baked goods drifts between the stalls. Every table seems to hide a story.`,

 "Home":`Warm light settles across familiar walls while treasures from past journeys wait quietly in their places.

Blank spaces still remain, patiently waiting for future discoveries.`
};

function lrAmbientText(){
 return LR_AMBIENT_DISCOVERIES[(state.room || 0) % LR_AMBIENT_DISCOVERIES.length];
}


/* Immersion Pack 3A: Organized Home */
const LR_HOME_AMBIENT = [
 "A kettle steams quietly near the hearth.",
 "Warm bread cools on a wooden board.",
 "A lantern glows beside familiar keepsakes.",
 "A rocking chair sits near the fire.",
 "Treasure shelves wait for future discoveries.",
 "Soft lamplight falls across the room."
];

function lrHomeAmbient(){
 return LR_HOME_AMBIENT[(state.room||0)%LR_HOME_AMBIENT.length];
}

function lrHomeLore(){
 return `═══ Hearth Home ═══

Warm lamplight settles across familiar walls while treasures from past journeys rest safely nearby.

Displayed Treasures:
• Journey Keepsakes
• Nature Finds
• Future Display Spaces

Home Notes:
Blank places still wait for future discoveries and decorations.

Recent Memories:
Adventures, lessons, and discoveries will gather here over time.

Ambient:
${lrHomeAmbient()}${lrHomeExpansionText()}`;
}


/* Home Expansion Pack 1A: Brindletoe Builder Goblin + expandable home */
const LR_HOME_EXPANSIONS = [
  {
    level:1,
    name:"Starter Cottage",
    cost:0,
    storage:12,
    rooms:["Downstairs Hearth Room","Upstairs Sleeping Loft"],
    unlocks:"A small but warm home with a downstairs room and simple upstairs loft."
  },
  {
    level:2,
    name:"Roomy Cottage",
    cost:60,
    storage:20,
    rooms:["Downstairs Hearth Room","Upstairs Sleeping Loft","Pet Corner"],
    unlocks:"More floor space, extra storage, and a cozy pet corner."
  },
  {
    level:3,
    name:"Hall House",
    cost:140,
    storage:32,
    rooms:["Downstairs Hearth Room","Upstairs Sleeping Loft","Pet Corner","Treasure Hall"],
    unlocks:"A dedicated hall for treasures, lesson trophies, and strange finds."
  },
  {
    level:4,
    name:"Manor Home",
    cost:280,
    storage:48,
    rooms:["Downstairs Hearth Room","Upstairs Sleeping Loft","Pet Corner","Treasure Hall","West Wing","East Wing"],
    unlocks:"Side wings open for collections, seasonal decor, and special displays."
  },
  {
    level:5,
    name:"Small Keep",
    cost:500,
    storage:72,
    rooms:["Great Hall","Sleeping Loft","Treasure Hall","Pet Corner","Tower Room","Animal Room"],
    unlocks:"A fantasy keep with a tower room and a special space for animals."
  },
  {
    level:6,
    name:"Learning Castle",
    cost:850,
    storage:110,
    rooms:["Great Hall","Library","Treasure Museum","Workshop","Pet Stable","Tower Room","Dungeon"],
    unlocks:"A castle-scale home with room for books, trophies, pets, crafts, and a starter dungeon."
  },
  {
    level:7,
    name:"Grand Realm Castle",
    cost:1300,
    storage:160,
    rooms:["Great Hall","Royal Library","Treasure Museum","Workshop","Pet Stable","Tower Room","Dungeon","Vault","Seasonal Wing"],
    unlocks:"A huge expandable castle for future decorations, animals, pets, treasures, and special rooms."
  }
];

function lrEnsureHomeExpansion(){
  if(!state.homeExpansion) state.homeExpansion = {level:1};
  if(!state.homeExpansion.level) state.homeExpansion.level = 1;
  if(state.homeExpansion.level < 1) state.homeExpansion.level = 1;
  if(state.homeExpansion.level > LR_HOME_EXPANSIONS.length) state.homeExpansion.level = LR_HOME_EXPANSIONS.length;
  if(typeof state.coins !== "number") state.coins = state.coins || 0;
}

function lrHomeExpansionCurrent(){
  lrEnsureHomeExpansion();
  return LR_HOME_EXPANSIONS[state.homeExpansion.level - 1] || LR_HOME_EXPANSIONS[0];
}

function lrHomeExpansionNext(){
  lrEnsureHomeExpansion();
  return LR_HOME_EXPANSIONS[state.homeExpansion.level] || null;
}

function lrHomeRoomListHtml(expansion){
  return `<ul class="homeRoomList">${expansion.rooms.map(r=>`<li>${lrEscape(r)}</li>`).join("")}</ul>`;
}

function lrHomeExpansionHtml(){
  lrEnsureHomeExpansion();
  const cur = lrHomeExpansionCurrent();
  const next = lrHomeExpansionNext();
  let html = `<div class="homeExpansionCard">
    <h3>🏠 ${lrEscape(cur.name)}</h3>
    <p><b>Home Level:</b> ${cur.level} / ${LR_HOME_EXPANSIONS.length}</p>
    <p><b>Storage Capacity:</b> ${cur.storage} keepsake slots</p>
    <p>${lrEscape(cur.unlocks)}</p>
    <h4>Open Rooms</h4>
    ${lrHomeRoomListHtml(cur)}
  </div>`;

  if(next){
    const affordable = (state.coins || 0) >= next.cost;
    html += `<div class="homeExpansionCard builderCard">
      <h3>🛠️ Brindletoe the Builder Goblin</h3>
      <p>“Ah! Bigger house? More treasure? More pets? Brindletoe can help. Not cheap, no no, but very sturdy!”</p>
      <p><b>Next Upgrade:</b> ${lrEscape(next.name)}</p>
      <p><b>Cost:</b> ${next.cost} coins</p>
      <p><b>Unlocks:</b> ${lrEscape(next.unlocks)}</p>
      <h4>Rooms After Upgrade</h4>
      ${lrHomeRoomListHtml(next)}
      <button type="button" class="homeUpgradeBtn" onclick="lrBuyHomeExpansion()" ${affordable ? "" : "disabled"}>${affordable ? "Pay Brindletoe and Expand Home" : "Need More Coins"}</button>
    </div>`;
  }else{
    html += `<div class="homeExpansionCard builderCard">
      <h3>🛠️ Brindletoe the Builder Goblin</h3>
      <p>“No more walls to knock out! This place is a castle fit for every treasure you drag home.”</p>
    </div>`;
  }

  html += `<div class="homeExpansionCard futureCard">
    <h3>Future Display System</h3>
    <p>These rooms are prepared for later decoration slots: rugs, wall items, tables, pets, animals, dungeon oddities, seasonal decor, trophies, and lesson treasures.</p>
  </div>`;
  return html;
}

function lrBuyHomeExpansion(){
  lrEnsureHomeExpansion();
  const next = lrHomeExpansionNext();
  if(!next){
    $("feedback").textContent = "Your home is already fully expanded.";
    return;
  }
  if((state.coins || 0) < next.cost){
    $("feedback").textContent = "Brindletoe pats his tool belt. You need " + next.cost + " coins for that expansion.";
    return;
  }
  state.coins -= next.cost;
  state.homeExpansion.level = next.level;
  addMemory("Home Expanded", "Brindletoe expanded the home into " + next.name + ".");
  save();
  renderRoom();
  lrOpenPopup("Home Expanded", `<p>Brindletoe hammers, mutters, measures twice, and somehow makes the home bigger by sunset.</p><p><b>New Home:</b> ${lrEscape(next.name)}</p><p><b>Storage:</b> ${next.storage} keepsake slots</p>`);
}

function openHomeExpansionPopup(){
  lrOpenPopup("Home Expansion", lrHomeExpansionHtml());
}

function lrHomeExpansionText(){
  const cur = lrHomeExpansionCurrent();
  const next = lrHomeExpansionNext();
  let text = `\n\nHome Expansion:\nCurrent Home: ${cur.name}\nHome Level: ${cur.level} / ${LR_HOME_EXPANSIONS.length}\nStorage Capacity: ${cur.storage} keepsake slots`;
  if(next) text += `\nNext Upgrade: ${next.name} (${next.cost} coins)\nBuilder: Brindletoe the Builder Goblin is ready when you have enough coins.`;
  else text += `\nBrindletoe says this home is already a grand castle.`;
  return text;
}
/* End Home Expansion Pack 1A */


/* Home Expansion Pack 1B: visual home view + rabbit leak cleanup */
const LR_HOME_BLOCKED_PHRASES = [
  "A shy rabbit watches from the grass.",
  "A red squirrel darts across the path carrying an acorn almost as large as its head.",
  "Someone has stacked smooth river stones beside the trail into a tiny tower.",
  "A feather catches on a branch and turns slowly in the breeze.",
  "Old initials have been carved into a weathered fence post.",
  "A tiny bird nest rests safely among the roots of a tree.",
  "You notice faint footprints pressed into the soft earth.",
  "A loose page flutters from a shelf and settles at your feet.",
  "An old lantern hangs from a hook, long cold but carefully polished.",
  "A beetle pushes through moss carrying a crumb many times its size."
];

function lrIsHomeRoom(){
  const r = room();
  return state.loc === "home" ||
    ((r.zone || "").toLowerCase().includes("home")) ||
    ((r.title || "").toLowerCase().includes("home")) ||
    ((r.title || "").toLowerCase().includes("hearth"));
}

function lrCleanHomeWildlifeText(text){
  if(!lrIsHomeRoom()) return text;
  LR_HOME_BLOCKED_PHRASES.forEach(p=>{
    text = text.split("\n\n" + p).join("");
    text = text.split(p + "\n\n").join("");
    text = text.split(p).join("");
  });
  return text.replace(/\n{4,}/g, "\n\n").trim();
}

function lrHomeVisualRooms(){
  if(typeof lrEnsureHomeExpansion === "function") lrEnsureHomeExpansion();
  const lvl = state.homeExpansion && state.homeExpansion.level ? state.homeExpansion.level : 1;
  const all = [
    {name:"Downstairs Hearth Room", unlock:1, icon:"🔥"},
    {name:"Upstairs Sleeping Loft", unlock:1, icon:"🛏️"},
    {name:"Pet Corner", unlock:2, icon:"🐾"},
    {name:"Treasure Hall", unlock:3, icon:"🏆"},
    {name:"West Wing", unlock:4, icon:"🖼️"},
    {name:"East Wing", unlock:4, icon:"📚"},
    {name:"Tower Room", unlock:5, icon:"🗼"},
    {name:"Animal Room", unlock:5, icon:"🐇"},
    {name:"Library", unlock:6, icon:"📖"},
    {name:"Workshop", unlock:6, icon:"🛠️"},
    {name:"Dungeon", unlock:6, icon:"🕯️"},
    {name:"Vault", unlock:7, icon:"💎"},
    {name:"Seasonal Wing", unlock:7, icon:"🍂"}
  ];
  return all.map(r=>({...r, open:lvl >= r.unlock}));
}

function lrHomeVisualHtml(){
  const current = typeof lrHomeExpansionCurrent === "function" ? lrHomeExpansionCurrent() : {name:"Starter Cottage", level:1, storage:12};
  const rooms = lrHomeVisualRooms();
  const openRooms = rooms.filter(r=>r.open);
  const lockedRooms = rooms.filter(r=>!r.open);

  return `<div class="lrHomeVisual">
    <div class="lrHomeVisualHeader">
      <div>
        <h3>🏠 ${lrEscape(current.name)}</h3>
        <p>Home Level ${current.level} • Storage ${current.storage} keepsake slots</p>
      </div>
      <button type="button" onclick="openHomeExpansionPopup()">🛠️ Visit Brindletoe</button>
    </div>

    <div class="lrHomeScene">
      <div class="lrHomeRoom downstairs">
        <b>🔥 Downstairs Hearth Room</b>
        <span>Rug • Table • Shelf • Keepsakes</span>
      </div>
      <div class="lrHomeRoom loft">
        <b>🛏️ Upstairs Sleeping Loft</b>
        <span>Bed • Chest • Quiet Reading Corner</span>
      </div>
      ${openRooms.filter(r=>r.unlock > 1).map(r=>`<div class="lrHomeRoom unlocked"><b>${r.icon} ${lrEscape(r.name)}</b><span>Unlocked room</span></div>`).join("")}
      ${lockedRooms.slice(0,8).map(r=>`<div class="lrHomeRoom locked"><b>🔒 ${lrEscape(r.name)}</b><span>Unlocks at Home Level ${r.unlock}</span></div>`).join("")}
    </div>

    <div class="lrHomeSlots">
      <div><b>Displayed Treasures</b><span>Journey Keepsakes • Nature Finds • Lesson Trophies</span></div>
      <div><b>Future Slots</b><span>Walls • Rug • Tabletop • Pets • Animals • Dungeon Oddities</span></div>
    </div>
  </div>`;
}

function openHomeViewPopup(){
  lrOpenPopup("Home View", lrHomeVisualHtml());
}
/* End Home Expansion Pack 1B */


/* Gameplay Pack 1A: Restore interaction loop + hard-earned rewards */
function lrTodayKey(){
  if(typeof localDateKey === "function") return localDateKey();
  return new Date().toISOString().slice(0,10);
}

function lrEnsureGameplayLimits(){
  if(!state.gameplayLimits) state.gameplayLimits = {};
  const day = lrTodayKey();
  if(!state.gameplayLimits[day]) state.gameplayLimits[day] = {};
  if(!state.gameplayLimits[day][activeChild]) state.gameplayLimits[day][activeChild] = {rooms:{},subjects:{},earnedCorrect:0,uniqueRooms:{}};
  return state.gameplayLimits[day][activeChild];
}

function lrRoomLearningKey(){
  const r = room();
  return state.loc + "::" + ((r && r.subject) || "general");
}

function lrRoomLessonLimit(){
  return 2; // prevents farming one NPC/room
}

function lrCanStartLearning(){
  const r = room();
  const subj = r.subject;
  if(!subj){
    return {ok:false,msg:"There is no lesson encounter in this room. Travel to a subject realm or talk to someone nearby."};
  }
  const lim = lrEnsureGameplayLimits();
  const key = lrRoomLearningKey();
  const used = lim.rooms[key] || 0;
  if(used >= lrRoomLessonLimit()){
    return {ok:false,msg:"This room has given all the useful lessons it has for today. Explore another room or subject to keep earning."};
  }
  return {ok:true,msg:""};
}

function lrReserveLearningAttempt(){
  const lim = lrEnsureGameplayLimits();
  const key = lrRoomLearningKey();
  lim.rooms[key] = (lim.rooms[key] || 0) + 1;
  lim.uniqueRooms[state.loc] = true;
}

function lrSubjectDailyCount(subj){
  const lim = lrEnsureGameplayLimits();
  return lim.subjects[subj] || 0;
}

function lrRecordHardEarnedReward(subj){
  const lim = lrEnsureGameplayLimits();
  lim.subjects[subj] = (lim.subjects[subj] || 0) + 1;
  lim.earnedCorrect = (lim.earnedCorrect || 0) + 1;

  let line = "";
  // Coins are intentionally slow. Correct answers are not an instant coin faucet.
  if(lim.earnedCorrect % 5 === 0){
    state.coins = (state.coins || 0) + 1;
    line += " +1 coin earned for steady work.";
  }

  // Variety bonus: small but meaningful, prevents grinding one room.
  const uniqueCount = Object.keys(lim.uniqueRooms || {}).length;
  if(uniqueCount && uniqueCount % 6 === 0 && !lim["varietyBonus_"+uniqueCount]){
    lim["varietyBonus_"+uniqueCount] = true;
    state.coins = (state.coins || 0) + 2;
    line += " +2 coins for learning across different rooms.";
  }

  return line;
}

function lrStartInteraction(){
  const r = room();
  const subj = r.subject;

  if(roomHasNpc()){
    talk();
  }

  if(subj){
    const gate = lrCanStartLearning();
    if(!gate.ok){
      $("feedback").textContent = gate.msg;
      $("actionTitle").textContent = "Explore More";
      $("actionText").innerHTML = `<div class="lessonCard"><div class="lessonCardTitle">Today's Work Here Is Done</div><div class="lessonCardText">${lrEscape(gate.msg)}</div></div>`;
      $("lessonBox").classList.add("hidden");
      return;
    }
    lrReserveLearningAttempt();
    window.__lrStartingFromInteract = true;
    startLesson();
    window.__lrStartingFromInteract = false;
    $("feedback").textContent = "Interaction started. Work carefully. Rewards are earned slowly and matter.";
    save();
    return;
  }

  if(!roomHasNpc()){
    $("actionTitle").textContent = "Look Around";
    $("actionText").innerHTML = `<div class="lessonCard"><div class="lessonCardTitle">Nothing to interact with yet</div><div class="lessonCardText">This room is quiet. Use the compass to explore until you find a subject realm, NPC, shop, quest board, or special room.</div></div>`;
    $("lessonBox").classList.add("hidden");
    $("feedback").textContent = "No interaction here yet.";
  }
}

/* Replace the direct lesson button loop with an Interact-first gameplay loop. */
if(typeof lrRenderMainGameplayActions === "function" && !window.__lrGameplayPack1AInteractPatched){
  window.__lrGameplayPack1AInteractPatched = true;
  const _lrGP1A_oldMainGameplay = lrRenderMainGameplayActions;
  lrRenderMainGameplayActions = function(){
    _lrGP1A_oldMainGameplay();
    const mount = $("mainGameplayActions");
    if(!mount) return;
    const r = room();
    const subj = r.subject;
    const gate = subj ? lrCanStartLearning() : {ok:false,msg:""};
    const label = subj ? (gate.ok ? "⭐ Interact / Learn" : "✅ Done Here Today") : (roomHasNpc() ? "💬 Talk / Interact" : "🔎 Look Around");
    const disabled = subj && !gate.ok ? "disabled" : "";
    mount.innerHTML = `<div class="mainGameplayBox interactBox"><button type="button" onclick="lrSafeOpenWorldDirectory()">🗺 World Directory</button><button type="button" onclick="openLandmarkJournal()">📍 Landmarks</button><button type="button" onclick="lrSafeOpenQuestJournal()">📜 Quest Journal</button><button type="button" onclick="lrSafeOpenLongQuestJournal()">🏰 Long Journey</button><button type="button" onclick="lrSafeOpenPetJournal()">🐾 Pet Corner</button><button type="button" onclick="lrSafeOpenCastlePrestige()">🏰 Prestige</button><button type="button" onclick="openStoryQuestJournal()">📖 Story Quests</button><button type="button" onclick="openVisibleHome()">🏡 Home View</button><button type="button" onclick="openSeasonHall()">🌿 Seasons</button><button type="button" onclick="openHomeExpansion2()">🏗 Expand Home</button><button type="button" onclick="openSeasonQuests()">🎉 Festivals</button><button type="button" onclick="openNpcRelations()">🤝 Realm Friends</button>` + `
      <div class="mainGameplayTitle">Main Interaction</div>
      <p>${subj ? "Use this to learn from the room encounter. Each room has limited useful work per day, so exploring matters." : "Use this to talk, inspect, or discover whether anything here can teach you."}</p>
      <div class="mainGameplayGrid"><button type="button" onclick="lrStartInteraction()" ${disabled}>${label}</button></div>
      ${subj && !gate.ok ? `<p class="dailyLimitNote">${lrEscape(gate.msg)}</p>` : ""}
    </div>` + mount.innerHTML;
  };
}
/* End Gameplay Pack 1A */


/* Gameplay Pack 1C: World Activation */
const LR_WORLD_EVENTS=[
"🪶 A feather rests beside the trail.",
"🕯 A small lantern hangs from a branch.",
"📜 A folded note peeks from under a stone.",
"🦉 Tiny owl carvings decorate a root.",
"🧩 Someone left a puzzle token here.",
"🎒 An abandoned satchel lies nearby."
];

const LR_SCHOLARS={
Logic:"🦉 Owl Scholar",
Geography:"🗺 Map Keeper",
Nature:"🌿 Marsh Naturalist",
Economics:"🪙 Market Tutor",
Writing:"🪶 Scribe Keeper",
Arts:"🎨 Hall Artist"
};

function lrWorldFlavor(){
 const r=room();
 const scholar=LR_SCHOLARS[r.subject]||"✨ Realm Guide";
 const e=LR_WORLD_EVENTS[(state.room||0)%LR_WORLD_EVENTS.length];
 return `<div class="lessonCard"><div class="lessonCardTitle">${scholar}</div><div class="lessonCardText">${e}</div></div>`;
}


/* World Expansion Pass */
const LR_WORLD_DETAILS=[
"Wind moves softly through the trees and the path seems older than it first appeared.",
"Someone once traveled here often. Faint footprints still remain beside the trail.",
"A weathered stone marker leans slightly, covered in moss and tiny carvings.",
"The air feels quiet and thoughtful, as if this place remembers many travelers.",
"A few leaves drift across the ground while distant birds call from the woods."
];
function lrExpandedRoomFlavor(){
 return LR_WORLD_DETAILS[(state.room||0)%LR_WORLD_DETAILS.length];
}


/* World Expansion Pass 2 */
const LR_MORE_SCHOLARS=["🦉 Archivist Elric","🗺 Cartographer Nia","🌿 Willow Naturalist","⚙ Clockwork Tutor","🪙 Market Keeper"];
const LR_MICRO_EVENTS=[
"📜 You find a folded trail note.",
"🧩 A carved puzzle stone sits in the moss.",
"🎁 A tiny wrapped parcel was left on a stump.",
"🪶 A bright feather catches the light.",
"🏮 A lantern sways gently overhead."
];

function lrRandomDiscovery(){
 return LR_MICRO_EVENTS[(state.room+state.streak)%LR_MICRO_EVENTS.length];
}

function openWorldDirectory(){
 $("actionTitle").textContent="World Directory";
 $("actionText").innerHTML="<div class='lessonCard'><div class='lessonCardTitle'>Known Scholars</div><div class='lessonCardText'>"+LR_MORE_SCHOLARS.join("<br>")+"</div></div><div class='lessonCard'><div class='lessonCardTitle'>Discoveries</div><div class='lessonCardText'>"+lrRandomDiscovery()+"</div></div>";
 $("lessonBox").classList.add("hidden");
}


/* Quest Pack 1 */
const LR_QUESTS=[
{name:"Meet the Owl Scholar",goal:"Complete 2 Logic lessons",reward:"🪶 Owl Feather"},
{name:"Map Walker",goal:"Visit 6 rooms",reward:"🗺 Explorer Banner"},
{name:"Nature Watch",goal:"Complete 2 Nature lessons",reward:"🌿 Nature Journal"},
{name:"Young Builder",goal:"Earn 3 coins",reward:"🪵 Builder Token"}
];

function openQuestJournal(){
 $("actionTitle").textContent="Quest Journal";
 $("actionText").innerHTML=LR_QUESTS.map(q=>`<div class='lessonCard'><div class='lessonCardTitle'>${q.name}</div><div class='lessonCardText'>Goal: ${q.goal}<br>Reward: ${q.reward}</div></div>`).join("");
 $("lessonBox").classList.add("hidden");
}


/* Quest Pack 2: Long Journey Quests */
const LR_LONG_QUESTS=[
{name:"Brindletoe's First Expansion",goal:"Earn 10 coins and complete 8 lessons",reward:"🪑 Wooden Chair Display"},
{name:"Owl Scholar's Trial",goal:"Complete 5 Logic lessons and explore Puzzle Grove",reward:"🪶 Scholar Cloak"},
{name:"Cartographer Journey",goal:"Discover 12 rooms",reward:"🗺 Wall Map"},
{name:"Naturalist Walk",goal:"Complete Nature studies and exploration",reward:"🌿 Herb Shelf"},
{name:"Castle Foundation I",goal:"Reach 100 total lessons",reward:"🧱 Foundation Stone"},
{name:"Castle Foundation II",goal:"Reach 250 total lessons",reward:"🏛 Builder Banner"},
{name:"Castle Foundation III",goal:"Reach 500 total lessons",reward:"🏰 Castle Charter"}
];

function openLongQuestJournal(){
 $("actionTitle").textContent="Long Journey Quests";
 $("actionText").innerHTML=LR_LONG_QUESTS.map(q=>`<div class='lessonCard'><div class='lessonCardTitle'>${q.name}</div><div class='lessonCardText'>Goal: ${q.goal}<br>Reward: ${q.reward}</div></div>`).join("");
 $("lessonBox").classList.add("hidden");
}


/* Companion / Pet Pack 1: Vanity Heart Pack */
const LR_VANITY_PETS=[
{name:"🐇 Meadow Rabbit",bonus:"Home companion only"},
{name:"🦆 Pond Duck",bonus:"Occasional memory flavor"},
{name:"🦉 Owl Friend",bonus:"Tiny clue flavor"},
{name:"🐿 Acorn Squirrel",bonus:"Decor companion"},
{name:"🐸 Frog Companion",bonus:"Home shelf friend"}
];

function lrEnsurePets(){
 if(!state.vanityPets) state.vanityPets={owned:[],active:null};
 return state.vanityPets;
}

function adoptVanityPet(i){
 const p=LR_VANITY_PETS[i];
 const pets=lrEnsurePets();
 if(!pets.owned.find(x=>x.name==p.name)){
   pets.owned.push(p);
   ensureHome().storage.push({name:p.name,slot:"pet1"});
 }
 pets.active=p.name;
 save();
 openPetJournal();
}

function openPetJournal(){
 const pets=lrEnsurePets();
 $("actionTitle").textContent="Pet Corner";
 $("actionText").innerHTML=LR_VANITY_PETS.map((p,i)=>`<div class='lessonCard'><div class='lessonCardTitle'>${p.name}</div><div class='lessonCardText'>${p.bonus}<br><button onclick='adoptVanityPet(${i})'>Invite Home</button></div></div>`).join("")+`<div class='lessonCard'><div class='lessonCardTitle'>Active Companion</div><div class='lessonCardText'>${pets.active||"None"}<br>Companions are cosmetic and give almost no gameplay power.</div></div>`;
 $("lessonBox").classList.add("hidden");
}

/* Castle Systems Pack 1 */
function lrEnsurePrestige(){if(!state.homePrestige) state.homePrestige={museum:0,decor:0,library:0,pets:0,treasures:0}; return state.homePrestige;}
function lrRecalcPrestige(){const p=lrEnsurePrestige(); const h=ensureHome(); const items=(h.storage||[]); p.treasures=items.length; p.pets=((state.vanityPets&&state.vanityPets.owned)||[]).length*5; p.library=items.filter(x=>/book|scroll|journal|tome/i.test(x.name||"")).length*3; p.decor=items.filter(x=>/banner|map|chair|rug|painting/i.test(x.name||"")).length*2; p.museum=items.filter(x=>/token|relic|trophy|feather|lantern|stone/i.test(x.name||"")).length*4; return p;}
function prestigeTitle(score){if(score>=200)return "🏰 Castle Steward"; if(score>=120)return "📚 Archivist"; if(score>=70)return "🏛 Curator"; if(score>=30)return "🏠 Cozy Keeper"; return "Traveler";}
function openCastlePrestige(){const p=lrRecalcPrestige(); const total=p.museum+p.decor+p.library+p.pets+p.treasures; $("actionTitle").textContent="Castle Prestige"; $("actionText").innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>Prestige ${total}</div><div class='lessonCardText'>Title: ${prestigeTitle(total)}<br>Museum: ${p.museum}<br>Decor: ${p.decor}<br>Library: ${p.library}<br>Pets: ${p.pets}<br>Treasures: ${p.treasures}</div></div>`; $("lessonBox").classList.add("hidden");}


/* UI Pack 6A: Compact Room Flow + Popup Learning */
function lrCompactRoomText(raw){
  let text = String(raw || "").replace(/\r/g,"");
  // Remove repeated literal escape leaks and trim wild paragraph buildup.
  text = text.replace(/\\n\\n/g, "\n\n").replace(/\n{3,}/g, "\n\n").trim();

  const lines = text.split("\n").map(x=>x.trim()).filter(Boolean);
  const titleBits = [];
  const bodyBits = [];

  for(const line of lines){
    if(/^Exits:/i.test(line)) continue;
    if(/^Home Expansion:/i.test(line)) break;
    if(/^Campaign:/i.test(line)) { titleBits.push(line); continue; }
    if(/^Realm State:/i.test(line)) break;
    if(/^Restoration Object:/i.test(line)) break;
    if(/^Celebration Day:/i.test(line)) { titleBits.push(line); continue; }
    if(line.length < 48 && /Weather:|Festival:/.test(line)) { titleBits.push(line); continue; }
    bodyBits.push(line);
  }

  let p1 = bodyBits[0] || "This room waits quietly for the next step of the journey.";
  let p2 = bodyBits.find(x=>x !== p1 && x.length > 35) || "";
  let compact = p1;
  if(p2 && (p1 + " " + p2).length < 520) compact += "\n\n" + p2;

  const r = room();
  const exits = Object.keys((r && r.exits) || {});
  compact += "\n\n" + "🧭 Paths: " + (exits.length ? exits.map(x=>x[0].toUpperCase()+x.slice(1)).join(", ") : "None visible");
  if(r.subject) compact += "\n📚 Learning Realm: " + r.subject;
  if(typeof roomHasNpc === "function" && roomHasNpc()) compact += "\n💬 Someone is here: " + (npc().name || "Realm Guide");

  return compact;
}

function lrPopupAvailable(){
  return typeof lrOpenPopup === "function" && $("lrPopupRoot") && $("lrPopupBody");
}

function lrMoveLessonIntoPopup(){
  if(!lrPopupAvailable()) return;
  const lesson = $("lessonBox");
  const q = $("questionText");
  const c = $("choices");
  const action = $("actionText");
  if(!lesson || lesson.classList.contains("hidden")) return;

  const title = $("actionTitle") ? $("actionTitle").textContent : "Learning Encounter";
  const body = `
    <div class="popupLessonContent">
      <div class="popupLessonIntro">${action ? action.innerHTML : ""}</div>
      <div class="popupLessonQuestion">${q ? q.innerHTML : ""}</div>
      <div id="popupChoices" class="choices popupChoices">${c ? c.innerHTML : ""}</div>
    </div>
  `;
  lrOpenPopup(title, body);

  const originalButtons = Array.from(c ? c.querySelectorAll("button") : []);
  const popupButtons = Array.from(document.querySelectorAll("#popupChoices button"));
  popupButtons.forEach((btn,i)=>{
    if(originalButtons[i] && originalButtons[i].onclick){
      btn.onclick = function(){
        originalButtons[i].click();
        setTimeout(lrRefreshLearningPopupAfterAnswer, 60);
      };
    }
  });

  // Keep the page short once the popup owns the lesson.
  if(action) action.innerHTML = `<div class="compactNotice">Learning encounter opened in a popup window.</div>`;
  if(lesson) lesson.classList.add("hidden");
}

function lrRefreshLearningPopupAfterAnswer(){
  if(!lrPopupAvailable()) return;
  const feedback = $("feedback") ? $("feedback").textContent : "";
  const action = $("actionText") ? $("actionText").innerHTML : "";
  $("lrPopupBody").innerHTML = `
    <div class="popupLessonResult">
      <h3>Result</h3>
      <p>${lrEscape(feedback || "Answer recorded.")}</p>
      <div class="popupResultDetails">${action || ""}</div>
      <button type="button" onclick="lrClosePopup()">Return to Room</button>
    </div>
  `;
}

function lrOpenActionPopup(title){
  if(!lrPopupAvailable()) return;
  const action = $("actionText") ? $("actionText").innerHTML : "<p>Nothing here yet.</p>";
  lrOpenPopup(title || ($("actionTitle") ? $("actionTitle").textContent : "Window"), action);
}
/* End UI Pack 6A */


/* UI Pack 6B: button reliability fixes */
function lrShowInPopupFromAction(title){
  if(typeof lrOpenPopup !== "function") return false;
  const body = $("actionText") ? $("actionText").innerHTML : "<p>Nothing here yet.</p>";
  lrOpenPopup(title || (($("actionTitle") && $("actionTitle").textContent) || "Window"), body);
  return true;
}

// Safe wrappers for common buttons that used to look dead after 6A.
function lrSafeOpenWorldDirectory(){
  if(typeof openWorldDirectory === "function") openWorldDirectory();
  lrShowInPopupFromAction("World Directory");
}
function lrSafeOpenQuestJournal(){
  if(typeof openQuestJournal === "function") openQuestJournal();
  lrShowInPopupFromAction("Quest Journal");
}
function lrSafeOpenLongQuestJournal(){
  if(typeof openLongQuestJournal === "function") openLongQuestJournal();
  lrShowInPopupFromAction("Long Journey");
}
function lrSafeOpenPetJournal(){
  if(typeof openPetJournal === "function") openPetJournal();
  lrShowInPopupFromAction("Pet Corner");
}
function lrSafeOpenCastlePrestige(){
  if(typeof openCastlePrestige === "function") openCastlePrestige();
  lrShowInPopupFromAction("Castle Prestige");
}
/* End UI Pack 6B button reliability fixes */


/* Quest Pack 3: Story Quest Chains */
const LR_STORY_QUESTS=[
{arc:"🌿 Lost Lantern of Willowbrook",step:"Talk to Archivist Elric",goal:"Complete 2 Reading lessons and visit forest rooms",reward:"🕯 Weathered Lantern"},
{arc:"🌿 Lost Lantern of Willowbrook",step:"Gather clues",goal:"Complete Nature lessons and explore",reward:"📜 Willow Note"},
{arc:"🌿 Lost Lantern of Willowbrook",step:"Restore the lantern",goal:"Complete Logic + Science lessons",reward:"🏮 Willow Lantern Display"},
{arc:"🦉 Owl Scholar Journey",step:"Earn trust",goal:"Complete 5 Logic lessons",reward:"🪶 Owl Scholar Token"},
{arc:"🗺 Cartographer Expedition",step:"Map the roads",goal:"Discover 15 rooms",reward:"🗺 Explorer Chart"},
{arc:"🏰 Castle Foundation Campaign",step:"Prepare the grounds",goal:"Reach 100 lessons",reward:"🧱 Foundation Stone"}
];

function openStoryQuestJournal(){
 $("actionTitle").textContent="Story Quest Chains";
 $("actionText").innerHTML=LR_STORY_QUESTS.map(q=>`<div class='lessonCard'><div class='lessonCardTitle'>${q.arc}</div><div class='lessonCardText'><b>${q.step}</b><br>Goal: ${q.goal}<br>Reward: ${q.reward}</div></div>`).join("");
 $("lessonBox").classList.add("hidden");
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Story Quest Chains");
}


/* Decoration Placement Pack 2: Visible Home Rooms */
function lrVisibleHomeHtml(){
 const h=ensureHome();
 const d=h.decor||{};
 function slot(k,empty){return (d[k]&&d[k].name)||empty;}
 return `<div class="visibleHome">
 <div class="homeLoft"><h3>UPSTAIRS LOFT</h3><div class="homeSlot">🛏 ${slot("bed","Loft Empty")}</div><div class="homeSlot">📚 ${slot("shelf","Shelf Empty")}</div></div>
 <div class="homeMain"><h3>MAIN ROOM</h3><div class="homeGrid">
 <div class="homeSlot">🖼 ${slot("wallLeft","Wall Empty")}</div>
 <div class="homeSlot">🖼 ${slot("wallRight","Wall Empty")}</div>
 <div class="homeSlot">🪵 ${slot("table","Table Empty")}</div>
 <div class="homeSlot">🔥 ${slot("hearth","Hearth Empty")}</div>
 <div class="homeSlot wide">🧶 ${slot("rug","Rug Empty")}</div>
 </div></div>
 <div class="homePets"><h3>PET CORNER</h3><div class="homeSlot">🐾 ${slot("petSpot","Pet Empty")}</div></div>
 </div>`;
}
function openVisibleHome(){
 $("actionTitle").textContent="Visible Home";
 $("actionText").innerHTML=lrVisibleHomeHtml();
 $("lessonBox").classList.add("hidden");
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Visible Home");
}


/* Season System Pack 1 */
const LR_SEASONS={
spring:{icon:"🌸",items:["Egg Garland","Flower Basket","Planting Banner"],quest:"Spring Planting Festival"},
summer:{icon:"☀️",items:["Firefly Jar","Picnic Cloth","Lantern String"],quest:"Lantern Night"},
harvest:{icon:"🍂",items:["Pumpkin Display","Leaf Rug","Acorn Shelf"],quest:"Harvest Lantern Hunt"},
winter:{icon:"❄️",items:["Winter Wreath","Candle Set","Snow Banner"],quest:"Winter Hall Decoration"}
};

function lrCurrentSeason(){
 const m=new Date().getMonth()+1;
 if(m>=3 && m<=5) return "spring";
 if(m>=6 && m<=8) return "summer";
 if(m>=9 && m<=11) return "harvest";
 return "winter";
}

function openSeasonHall(){
 const s=LR_SEASONS[lrCurrentSeason()];
 $("actionTitle").textContent="Season Hall";
 $("actionText").innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>${s.icon} ${lrCurrentSeason().toUpperCase()}</div><div class='lessonCardText'>Festival: ${s.quest}<br><br>Seasonal Items:<br>${s.items.join("<br>")}</div></div>`;
 $("lessonBox").classList.add("hidden");
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Season Hall");
}


/* Home Expansion Pack 2 */
function lrEnsureHomeGrowth(){
 const h=ensureHome();
 if(!h.wings) h.wings={library:false,workshop:false,museum:false};
 return h.wings;
}

function openHomeExpansion2(){
 const w=lrEnsureHomeGrowth();
 $("actionTitle").textContent="Brindletoe Expansions";
 $("actionText").innerHTML=`<div class='lessonCard'><div class='lessonCardTitle'>📚 Library Wing</div><div class='lessonCardText'>Cost: 20 coins<br><button onclick="lrUnlockWing('library')">Build</button></div></div>
 <div class='lessonCard'><div class='lessonCardTitle'>🔨 Workshop Wing</div><div class='lessonCardText'>Cost: 20 coins<br><button onclick="lrUnlockWing('workshop')">Build</button></div></div>
 <div class='lessonCard'><div class='lessonCardTitle'>🏛 Museum Hall</div><div class='lessonCardText'>Cost: 30 coins<br><button onclick="lrUnlockWing('museum')">Build</button></div></div>`;
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Brindletoe Expansions");
}

function lrUnlockWing(k){
 const h=ensureHome(); const w=lrEnsureHomeGrowth();
 const cost=(k==="museum")?30:20;
 if((state.coins||0)<cost){$("feedback").textContent="Not enough coins."; return;}
 state.coins-=cost; w[k]=true; save();
 openVisibleHome();
}

const _oldHome=lrVisibleHomeHtml;
lrVisibleHomeHtml=function(){
 const base=_oldHome();
 const w=lrEnsureHomeGrowth();
 return base+`<div class='homeExpansionGrid'>
 ${w.library?'<div class="homeWing">📚 LIBRARY WING<br>Scroll displays and scholar relics</div>':''}
 ${w.workshop?'<div class="homeWing">🔨 WORKSHOP<br>Builder items and tools</div>':''}
 ${w.museum?'<div class="homeWing wideWing">🏛 MUSEUM HALL<br>Trophies • Relics • Seasonal displays</div>':''}
 </div>`;
}


/* Season Quest Pack 2 */
const LR_SEASON_QUESTS={
spring:[{name:"Spring Planting Festival",reward:"🌷 Tulip Basket"},{name:"Egg Trail",reward:"🥚 Egg Garland"},{name:"Garden Blessing",reward:"🌱 Garden Stone"}],
summer:[{name:"Lantern Night",reward:"🏮 Firefly Lantern"},{name:"Firefly Walk",reward:"🫙 Firefly Jar"},{name:"Evening Breeze",reward:"🎐 Wind Chime"}],
harvest:[{name:"Harvest Lantern Hunt",reward:"🎃 Pumpkin Display"},{name:"Leaf Gathering",reward:"🍁 Leaf Rug"},{name:"Acorn Trail",reward:"🌰 Acorn Shelf"}],
winter:[{name:"Winter Hall Decoration",reward:"🕯 Candle Set"},{name:"Wreath Making",reward:"🎄 Winter Wreath"},{name:"Snow Hall",reward:"❄ Snow Banner"}]
};

function openSeasonQuests(){
 const s=lrCurrentSeason();
 const q=LR_SEASON_QUESTS[s];
 $("actionTitle").textContent="Season Festivals";
 $("actionText").innerHTML=q.map(x=>`<div class='lessonCard'><div class='lessonCardTitle'>${x.name}</div><div class='lessonCardText'>Seasonal quest reward:<br>${x.reward}</div></div>`).join("");
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Season Festivals");
}


/* NPC Relationship Pack 1 */
const LR_NPC_REL={
elric:{name:"🦉 Archivist Elric",ranks:["Stranger","Acquaintance","Friend","Scholar Ally"],rewards:["📜 Journal Page","📚 Library Relic","🕯 Lantern Lore"]},
nia:{name:"🗺 Cartographer Nia",ranks:["Traveler","Scout","Pathfinder","Realm Explorer"],rewards:["🗺 Explorer Chart","🧭 Banner","🪶 Travel Note"]},
willow:{name:"🌿 Willow Naturalist",ranks:["Observer","Helper","Grove Friend","Keeper"],rewards:["🌱 Seed Pouch","🍄 Nature Journal","🌿 Display Herb"]},
};

function lrEnsureRelations(){
 if(!state.npcRelations) state.npcRelations={elric:0,nia:0,willow:0};
 return state.npcRelations;
}

function lrNpcRank(id){
 const v=lrEnsureRelations()[id]||0;
 return LR_NPC_REL[id].ranks[Math.min(v,LR_NPC_REL[id].ranks.length-1)];
}

function lrBefriendNpc(id){
 const r=lrEnsureRelations();
 r[id]=Math.min((r[id]||0)+1,3);
 save();
 openNpcRelations();
}

function openNpcRelations(){
 const rel=lrEnsureRelations();
 $("actionTitle").textContent="Realm Friends";
 $("actionText").innerHTML=Object.entries(LR_NPC_REL).map(([id,n])=>`
 <div class='lessonCard'>
 <div class='lessonCardTitle'>${n.name}</div>
 <div class='lessonCardText'>
 Rank: ${lrNpcRank(id)}<br>
 Next Memories: ${n.rewards.join(", ")}<br><br>
 <button onclick="lrBefriendNpc('${id}')">Spend Time</button>
 </div></div>`).join("");
 if(typeof lrOpenActionPopup==="function") lrOpenActionPopup("Realm Friends");
}

function renderRoom(){
 const r=room();
 $("roomTitle").textContent=r.title || "Room";
 $("zoneName").textContent=r.zone || "";
 let text=r.text || "";
 text += `\n\n${getTimeOfDay()} | Weather: ${getWeatherType()} | Festival: ${currentFestival().festival}\n${currentFestival().flavor}`;
 text += todayCelebration();

 const camp=CAMPAIGNS[activeChild];
 if(camp && (r.zone==="Whisperwood"||r.zone==="Iron Hills"||r.zone==="Kingdom Archives")){
   const s=stage(); text += `\n\nCampaign: ${camp.title}\nChapter: ${camp.chapters[Math.min(s,camp.chapters.length-1)]}\n${camp.world[Math.min(s,camp.world.length-1)]}`;
 }

 const comp=COMPANIONS[activeChild];
 if(comp && (r.zone==="Home" || (activeChild==="Luna"&&r.zone==="Whisperwood") || (activeChild==="Ava"&&r.zone==="Iron Hills") || (activeChild==="Michael"&&r.zone==="Kingdom Archives"))){
   text += "\n\n"+comp.stages[Math.min(stage(),comp.stages.length-1)];
 }

 if(realmStages[r.zone]){
   const s=stage();
   text += "\n\nRealm State:\n"+realmStages[r.zone][s];
   text += "\n\nRestoration Object:\n"+realmObjects[r.zone][s];
 }

 if(r.zone==="Castle Gate"){
   const restored=Object.keys(realmStages).filter(z=>stage()>=3).length;
   text += "\n\nCastle Seal:\n";
   if(restored===0) text+="The castle remains fully sealed.";
   else if(restored===1) text+="The castle barrier flickers.";
   else if(restored>=3) text+="The seal weakens.";
   if(restored>=5) text+="\nThe gates tremble...";
 }

 if(roomHasNpc()) text += "\n\n"+(npc().desc || npc().text || "");
 text += "\n\n"+lrImmersionText(r);
 text += "\n\n"+exitsText(r);
 const lrHomeCheck = (
 state.loc==="home" ||
 ((room().zone||"").toLowerCase().includes("home")) ||
 ((room().title||"").toLowerCase().includes("home"))
);
 if(lrHomeCheck){
   text += "\n\n" + lrHomeLore();
 }else{
   let lore = LR_ZONE_LORE[room().title] || LR_ZONE_LORE[room().zone] || "";
   if(lore) text += "\n\n" + lore;
   if(!lrHomeCheck) text += "\n\n" + lrAmbientText();
 }
 text = lrCompactRoomText(text);
 $("roomText").textContent=text;
 lrRenderMainCompass();
 lrRenderMainGameplayActions();
 renderLeftActions();
 renderStats();
 if(typeof lrConvertShopButtonsToPopup === 'function') setTimeout(lrConvertShopButtonsToPopup, 50);
 lrSetRightInfoPanel();
}


/* Stability Pack 1.8: global-safe action button append */
function lrAppendLeftButton(button){
 const mount = (typeof lrEnsureLeftActionMount === "function" ? lrEnsureLeftActionMount() : $("leftActionButtons"));
 if(!mount){
   LR_lastSystemError = "Action button mount missing";
   try{$("feedback").textContent = LR_lastSystemError;}catch(e){}
   return;
 }
 mount.appendChild(button);
}
/* End Stability Pack 1.8 */

function addLeft(label,fn){const b=document.createElement("button"); b.type="button"; b.textContent=label; b.onclick=fn; lrAppendLeftButton(b);}

function ensureMastery(){
 if(!state.mastery) state.mastery = {};
 if(!state.mastery[activeChild]) state.mastery[activeChild] = {};
 if(!state.bossWins) state.bossWins = {};
 if(!state.bossWins[activeChild]) state.bossWins[activeChild] = {};
 ensureProgress();
}

function subjectProgress(subj){
 ensureMastery();
 return (state.progress[activeChild] && state.progress[activeChild][subj]) ? state.progress[activeChild][subj] : 0;
}

function masterySparkCount(subj){
 return Math.floor(subjectProgress(subj) / 10);
}

function bossReady(subj){
 return subjectProgress(subj) >= 25;
}

function bossWinKey(subj){
 return activeChild + "_" + subj;
}

function masteryRank(subj){
 const n = subjectProgress(subj);
 if(n >= 100) return "Master";
 if(n >= 50) return "Expert";
 if(n >= 25) return "Boss Ready";
 if(n >= 10) return "Apprentice";
 return "Novice";
}

function showMasteryStatus(){
 const subj = room().subject;
 if(!subj){
   $("actionTitle").textContent = "Mastery";
   $("actionText").textContent = "There is no subject mastery in this room.";
   return;
 }
 ensureMastery();
 const n = subjectProgress(subj);
 const sparks = masterySparkCount(subj);
 const ready = bossReady(subj);
 const won = !!state.bossWins[activeChild][subj];

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent = subj + " Mastery";
 $("actionText").textContent =
   "Subject: " + subj + "\n" +
   "Correct answers: " + n + "\n" +
   "Mastery Sparks: " + sparks + "\n" +
   "Rank: " + masteryRank(subj) + "\n" +
   "Boss Ready: " + (ready ? "Yes" : "Not yet") + "\n" +
   "Boss Cleared: " + (won ? "Yes" : "No") + "\n\n" +
   "Boss challenges unlock at 25 correct answers in a subject.";
 $("feedback").textContent = "Mastery checked.";
}

function bossQuestionFor(subj){
 const child = activeChild;
 const content = window.LR_BOSS_CONTENT && window.LR_BOSS_CONTENT[child] && window.LR_BOSS_CONTENT[child][subj];

 if(content && content.length){
   const wins = state.bossWins && state.bossWins[child] ? Object.keys(state.bossWins[child]).length : 0;
   return content[wins % content.length];
 }

 if(child === "Luna"){
   if(subj === "Reading") return {title:"Silver Owl Reading Boss",intro:"The Silver Owl watches the Story Stone.",q:"Boss: Which answer shows character, setting, and problem?",c:["Rabbit in a pond with a broken bridge","The word ship starts with SH","A dime is 10 cents"],a:"Rabbit in a pond with a broken bridge",reward:"Moon Feather Banner"};
   if(subj === "English") return {title:"Grammar Grove Boss",intro:"The Grammar Gate glows.",q:"Boss: Which sentence is written correctly?",c:["The owl flew over the gate.","the owl flew over the gate","Owl flew gate"],a:"The owl flew over the gate.",reward:"Grammar Star Scroll"};
   if(subj === "Math") return {title:"Number Bridge Boss",intro:"Stone numbers rise from the bridge.",q:"Boss: 8 + 7 = ?",c:["15","14","16"],a:"15",reward:"Number Lantern"};
   if(subj === "Science") return {title:"Marsh Observation Boss",intro:"A frog watches the sunlight.",q:"Boss: A shadow forms when something blocks...",c:["light","sound","water"],a:"light",reward:"Shadow Frog Charm"};
   if(subj === "History") return {title:"Map Stone Boss",intro:"A small map glows on the stone.",q:"Boss: Which tool helps show where places are?",c:["map","verb","magnet"],a:"map",reward:"Little Map Frame"};
   if(subj === "Civics") return {title:"Kind Rule Boss",intro:"The town bell rings softly.",q:"Boss: Good rules help people stay...",c:["safe","lost","hidden"],a:"safe",reward:"Kind Rule Ribbon"};
 }

 if(child === "Ava"){
   if(subj === "Math") return {title:"Iron Hills Gear Boss",intro:"The Broken Lift begins to turn.",q:"Boss: Solve 3x + 4 = 22.",c:["6","8","18"],a:"6",reward:"Restored Gear Trophy"};
   if(subj === "English") return {title:"Evidence Hall Boss",intro:"A glowing scroll asks for proof.",q:"Boss: In CER, what explains how evidence supports the claim?",c:["reasoning","setting","prefix"],a:"reasoning",reward:"Evidence Scroll"};
   if(subj === "Science") return {title:"Crystal Marsh Boss",intro:"The weather station clicks.",q:"Boss: In a controlled experiment, how many main variables should change?",c:["one","all","none"],a:"one",reward:"Weather Station Model"};
   if(subj === "History") return {title:"Archive Source Boss",intro:"Historian Alder opens old papers.",q:"Boss: A diary written during an event is usually a...",c:["primary source","secondary source","fictional source"],a:"primary source",reward:"Primary Source Badge"};
   if(subj === "Civics") return {title:"Council Boss",intro:"The round table glows.",q:"Boss: Citizenship includes rights and...",c:["responsibilities","evaporation","fractions"],a:"responsibilities",reward:"Council Seal"};
   if(subj === "Reading") return {title:"Theme Boss",intro:"A lantern shines on an old story.",q:"Boss: Theme is the story's...",c:["message or lesson","font size","page number"],a:"message or lesson",reward:"Theme Lantern"};
 }

 if(child === "Michael"){
   if(subj === "Math") return {title:"Algebra Gate Boss",intro:"The gate locks rearrange into equations.",q:"Boss: Solve 5x + 2 = 3x + 14.",c:["6","8","12"],a:"6",reward:"Algebra Gate Key"};
   if(subj === "English") return {title:"Argument Boss",intro:"The debate chamber falls silent.",q:"Boss: A rebuttal answers the...",c:["counterclaim","citation","setting"],a:"counterclaim",reward:"Rebuttal Banner"};
   if(subj === "Science") return {title:"Physical Science Boss",intro:"A metal orb hums.",q:"Boss: Newton's second law is...",c:["F = ma","y = mx + b","C = πd"],a:"F = ma",reward:"Force Orb"};
   if(subj === "History") return {title:"Constitution Boss",intro:"The Archive Guide unrolls an old framework.",q:"Boss: Checks and balances help limit government...",c:["power","weather","density"],a:"power",reward:"Constitution Frame"};
   if(subj === "Civics") return {title:"Republic Boss",intro:"A council seal glows.",q:"Boss: Rule of law means laws apply to...",c:["everyone","only rulers","only children"],a:"everyone",reward:"Rule of Law Seal"};
   if(subj === "Reading") return {title:"Inference Boss",intro:"A shadow leaves only clues.",q:"Boss: A strong inference uses evidence and...",c:["reasoning","punctuation","volume"],a:"reasoning",reward:"Inference Lens"};
 }

 return {title:subj+" Boss",intro:"A realm challenge begins.",q:"Boss: What should you do when a problem is hard?",c:["Break it into steps","Guess without thinking","Quit right away"],a:"Break it into steps",reward:"Realm Trophy"};
}

function startBossChallenge(){
 const subj = room().subject;
 if(!subj){
   $("actionTitle").textContent = "Realm Boss";
   $("actionText").textContent = "There is no realm boss here.";
   return;
 }
 ensureMastery();
 if(!bossReady(subj)){
   $("actionTitle").textContent = "Realm Boss Locked";
   $("actionText").textContent = "Complete 25 correct answers in " + subj + " to unlock this boss.\n\nCurrent: " + subjectProgress(subj) + " / 25";
   $("feedback").textContent = "Keep training.";
   return;
 }

 const B = bossQuestionFor(subj);
 $("lessonBox").classList.remove("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent = B.title;
 $("actionText").textContent = (B.intro || "A realm boss challenge begins.") + "\n\nWin to earn bonus Sparks and a rare reward chance.";
 $("questionText").textContent = B.q;
 $("choices").innerHTML = "";
 B.c.forEach(choice=>{
   const b=document.createElement("button");
   b.className="choice";
   b.textContent=choice;
   b.onclick=()=>answerBoss(choice,B,subj,b);
   $("choices").appendChild(b);
 });
}

function answerBoss(choice,B,subj,btn){
 document.querySelectorAll(".choice").forEach(b=>b.disabled=true);
 ensureMastery();

 if(choice === B.a){
   attendanceRecordAnswer(subj, true, "boss", B.q);
   recordGameFunEvent("answers",1,{subject:subj});
   recordGameFunEvent("bossAttempts",1,{subject:subj});
   recordGameFunEvent("bossWins",1,{subject:subj});
   recordGameFunEvent("subjectCorrect",1,{subject:subj});
   btn.classList.add("correct");
   const firstWin = !state.bossWins[activeChild][subj];
   state.bossWins[activeChild][subj] = true;
   state.sparks += 15;
   const bossXp = addXP(xpAward("bossWin"), "boss victory");

   let rewardText = "Boss cleared. +15 Sparks. " + bossXp.message + ".";
   if(firstWin){
     state.ancientCoins = (state.ancientCoins || 0) + 1;
     const firstClearXp = addXP(xpAward("firstBossClearBonus"), "first boss clear");
     rewardText += " First clear bonus: +1 Ancient Coin. " + firstClearXp.message + ".";
     addMemory(subj + " Boss Cleared", activeChild + " cleared the " + B.title + ".");
     if(B.reward){ ensureHome().storage.push({name:B.reward, slot:"shelf"}); rewardText += " Reward found: " + B.reward + "."; }
   }else{
     rewardText += " Boss already cleared before.";
   }

   const bossTreasureLine = rollTreasureDrop(subj,"boss");
   const bossCompLine = addCompanionXP((companionTrainingConfig().xp||{}).bossWin || 15, "boss win", subj);
   const bossDiscoveryLine = checkCompanionDiscoveryRewards();
   const bossMasteryLine = addSubjectMasteryXP(subj, (masteryPathConfig().xp||{}).bossWin || 40, "bossWin");
   rewardText += bossTreasureLine + bossCompLine + bossDiscoveryLine + bossMasteryLine;

   $("feedback").textContent = rewardText;
   $("actionText").innerHTML = `<div class="lessonResult lessonResultWin"><div class="lessonResultTitle">🏆 Boss Victory!</div><div>${lrEscape(rewardText)}</div>${levelUpHtml((bossXp.levelUps||[]))}</div>`;
 }else{
   attendanceRecordAnswer(subj, false, "boss", B.q);
   recordGameFunEvent("answers",1,{subject:subj});
   recordGameFunEvent("wrongAnswers",1,{subject:subj});
   recordGameFunEvent("bossAttempts",1,{subject:subj});
   addXP(xpAward("bossAttempt"), "boss attempt");
   btn.classList.add("wrong");
   state.streak = 0;
   $("feedback").textContent = "Boss attempt failed. Review more lessons and try again.";
   $("actionText").textContent = "Not yet.\n\nThe boss waits for stronger mastery.";
 }

 save();
 renderStats();
 lrRenderSierraBar();
}

function awardMasteryProgress(subj){
 ensureMastery();
 const n = subjectProgress(subj);
 const sparks = masterySparkCount(subj);
 const rank = masteryRank(subj);

 let msg = " Mastery: " + rank + " (" + n + " correct).";
 if(n > 0 && n % 10 === 0){
   msg += " Mastery Spark earned.";
 }
 if(n === 25){
   msg += " Boss Ready!";
 }
 return msg;
}


let LR_attendanceLastTick = Date.now();

function localDateKey(){
 const d = new Date();
 return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}

function formatMinutes(totalSeconds){
 const mins = Math.floor((totalSeconds || 0) / 60);
 const h = Math.floor(mins / 60);
 const m = mins % 60;
 if(h <= 0) return m + " min";
 return h + " hr " + m + " min";
}

function ensureAttendanceFor(profile, child, dateKey){
 if(!profile.attendance) profile.attendance = {};
 const key = dateKey || localDateKey();
 if(!profile.attendance[key]){
   profile.attendance[key] = {
     date:key,
     present:false,
     loginCount:0,
     firstLogin:null,
     lastSeen:null,
     activeSeconds:0,
     sessions:[],
     answers:{},
     lessonLog:[]
   };
 }
 return profile.attendance[key];
}

function todayAttendance(profile, child){
 return ensureAttendanceFor(profile || state, child || activeChild, localDateKey());
}

function markAttendanceLogin(){
 const rec = todayAttendance(state, activeChild);
 const now = new Date().toLocaleTimeString();
 if(!rec.present){
   rec.present = true;
   rec.firstLogin = now;
 }
 rec.loginCount++;
 rec.lastSeen = now;
 rec.sessions.push({start:now});
 save();
}

function attendanceTick(force){
 if(!state) return;
 const nowMs = Date.now();
 let delta = Math.floor((nowMs - LR_attendanceLastTick) / 1000);
 if(delta < 1 && !force) return;
 if(delta > 120) delta = 120;

 if(!document.hidden || force){
   const rec = todayAttendance(state, activeChild);
   rec.present = true;
   rec.activeSeconds = (rec.activeSeconds || 0) + delta;
   rec.lastSeen = new Date().toLocaleTimeString();
   save();
 }
 LR_attendanceLastTick = nowMs;
}

function attendanceRecordAnswer(subj, correct, kind, questionText){
 const rec = todayAttendance(state, activeChild);
 if(!rec.answers[subj]) rec.answers[subj] = {attempted:0, correct:0, wrong:0, bossAttempts:0, bossWins:0};
 rec.answers[subj].attempted++;
 if(correct) rec.answers[subj].correct++;
 else rec.answers[subj].wrong++;

 if(kind === "boss"){
   rec.answers[subj].bossAttempts++;
   if(correct) rec.answers[subj].bossWins++;
 }

 rec.lessonLog.push({
   time:new Date().toLocaleTimeString(),
   subject:subj,
   kind:kind || "lesson",
   correct:!!correct,
   question:questionText || ""
 });
 if(rec.lessonLog.length > 250) rec.lessonLog = rec.lessonLog.slice(-250);
}

function attendanceSummary(profile, child, dateKey){
 const rec = ensureAttendanceFor(profile, child, dateKey || localDateKey());
 const subjects = Object.keys(rec.answers || {});
 const attempted = subjects.reduce((sum,s)=>sum+(rec.answers[s].attempted||0),0);
 const correct = subjects.reduce((sum,s)=>sum+(rec.answers[s].correct||0),0);
 const wrong = subjects.reduce((sum,s)=>sum+(rec.answers[s].wrong||0),0);
 return {rec, subjects, attempted, correct, wrong};
}

function gradeConfig(child){
 const cfg = (window.LR_GRADE_CONFIG && window.LR_GRADE_CONFIG[child]) ? window.LR_GRADE_CONFIG[child] : {};
 const defaults = (window.LR_GRADE_CONFIG && window.LR_GRADE_CONFIG.defaults) ? window.LR_GRADE_CONFIG.defaults : {targetCorrect:250,bossTarget:1};
 return {cfg, defaults};
}

function allDashboardSubjects(profile, child){
 const fromLessons = Object.keys((LESSONS && LESSONS[child]) || {});
 const fromProgress = Object.keys((profile.progress && profile.progress[child]) || {});
 const fromTargets = Object.keys(((window.LR_GRADE_CONFIG && window.LR_GRADE_CONFIG[child] && window.LR_GRADE_CONFIG[child].subjects) || {}));
 return Array.from(new Set([...fromTargets, ...fromLessons, ...fromProgress])).sort();
}

function subjectTargetInfo(child, subj){
 const {cfg, defaults} = gradeConfig(child);
 const specific = (cfg.subjects && cfg.subjects[subj]) ? cfg.subjects[subj] : {};
 return {
   display: specific.display || subj,
   targetCorrect: specific.targetCorrect || defaults.targetCorrect || 250,
   bossTarget: specific.bossTarget || defaults.bossTarget || 1,
   isConfigured: !!(cfg.subjects && cfg.subjects[subj])
 };
}

function percentText(done, target){
 if(!target || target <= 0) return "0%";
 return Math.min(100, Math.round((done / target) * 100)) + "%";
}

function subjectCompletionStatus(done, target, bossStatus){
 const ratio = target > 0 ? done / target : 0;
 if(done >= target) return "Grade Target Met";
 if(bossStatus === "Cleared") return "Boss Cleared";
 if(bossStatus === "Ready") return "Ready for Boss";
 if(ratio >= 0.65) return "On Track";
 if(ratio >= 0.30) return "Building";
 return "Needs More Work";
}

function gradeOverall(profile, child){
 const subjects = allDashboardSubjects(profile, child);
 let earned = 0;
 let possible = 0;
 subjects.forEach(subj=>{
   const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
   const correct = progress[subj] || 0;
   const info = subjectTargetInfo(child, subj);
   earned += Math.min(correct, info.targetCorrect);
   possible += info.targetCorrect;
 });
 return {earned, possible, percent: possible ? Math.min(100, Math.round((earned / possible) * 100)) : 0};
}

function dashboardRankByCount(n){
 if(n >= 100) return "Master";
 if(n >= 50) return "Expert";
 if(n >= 25) return "Boss Ready";
 if(n >= 10) return "Apprentice";
 return "Novice";
}

function bossStatusFor(profile, child, subj){
 const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 const bossWins = (profile.bossWins && profile.bossWins[child]) ? profile.bossWins[child] : {};
 if(bossWins[subj]) return "Cleared";
 if((progress[subj] || 0) >= 25) return "Ready";
 return "Locked";
}

function parentSubjectRows(profile, child){
 const subjects = allDashboardSubjects(profile, child);
 if(!subjects.length) return "<tr><td colspan='7'>No subjects loaded yet.</td></tr>";
 const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 return subjects.map(subj=>{
   const info = subjectTargetInfo(child, subj);
   const correct = progress[subj] || 0;
   const loaded = (((LESSONS[child] || {})[subj]) || []).length;
   const boss = bossStatusFor(profile, child, subj);
   const rank = dashboardRankByCount(correct);
   const status = subjectCompletionStatus(correct, info.targetCorrect, boss);
   const configuredNote = info.isConfigured ? "" : " *";
   return `<tr>
     <td>${info.display}${configuredNote}</td>
     <td>${correct} / ${info.targetCorrect}</td>
     <td>${percentText(correct, info.targetCorrect)}</td>
     <td>${loaded}</td>
     <td>${rank}</td>
     <td>${boss}</td>
     <td>${status}</td>
   </tr>`;
 }).join("");
}

function parentWeakSubjects(profile, child){
 const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 const subjects = allDashboardSubjects(profile, child);
 const sorted = subjects.map(s=>{
   const info = subjectTargetInfo(child, s);
   const correct = progress[s] || 0;
   const ratio = info.targetCorrect ? correct / info.targetCorrect : 0;
   return {subject:info.display, ratio, correct, target:info.targetCorrect};
 }).sort((a,b)=>a.ratio-b.ratio);
 return sorted.slice(0,3).map(x=>`${x.subject} (${Math.round(x.ratio*100)}%)`).join(", ") || "None yet";
}

function parentRecommendedSubject(profile, child){
 const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 const subjects = allDashboardSubjects(profile, child);
 if(!subjects.length) return "No recommendation yet";
 const sorted = subjects.map(s=>{
   const info = subjectTargetInfo(child, s);
   const correct = progress[s] || 0;
   const ratio = info.targetCorrect ? correct / info.targetCorrect : 0;
   return {subject:info.display, ratio, correct, target:info.targetCorrect};
 }).filter(x=>x.correct < x.target).sort((a,b)=>a.ratio-b.ratio);
 return sorted.length ? sorted[0].subject : "All listed targets met";
}

function parentBossSummary(profile, child){
 const subjects = allDashboardSubjects(profile, child);
 const ready = subjects.filter(s=>bossStatusFor(profile, child, s) === "Ready").length;
 const cleared = subjects.filter(s=>bossStatusFor(profile, child, s) === "Cleared").length;
 return {ready, cleared, total:subjects.length};
}

function assignmentSubjectsFor(child){
 const cfg = window.LR_CLASSROOM_CONFIG || {};
 const listed = cfg.assignmentSubjects && cfg.assignmentSubjects[child] ? cfg.assignmentSubjects[child] : [];
 const loaded = Object.keys((LESSONS && LESSONS[child]) || {});
 return Array.from(new Set([...listed, ...loaded])).filter(Boolean);
}

function dailyPlanFor(child){
 const profile = allProfiles[child] || DEFAULT_PROFILE_STATE();
 const subjects = assignmentSubjectsFor(child);
 const progress = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 const cfg = window.LR_CLASSROOM_CONFIG || {};
 const qTargets = (cfg.dailyQuestionTargets && cfg.dailyQuestionTargets[child]) ? cfg.dailyQuestionTargets[child] : {};
 const preferred = (cfg.assignmentSubjects && cfg.assignmentSubjects[child]) ? cfg.assignmentSubjects[child] : subjects;

 const ranked = subjects.map(s=>{
   const info = subjectTargetInfo(child, s);
   const correct = progress[s] || 0;
   const ratio = info.targetCorrect ? correct / info.targetCorrect : 0;
   const baseQuestions = qTargets[s] || 5;
   const priorityBoost = preferred.includes(s) ? 0 : 1;
   return {subject:s, display:info.display || s, ratio, correct, target:info.targetCorrect, questions:baseQuestions, priorityBoost};
 }).sort((a,b)=>(a.ratio+a.priorityBoost)-(b.ratio+b.priorityBoost));

 const chosen = ranked.slice(0,5);
 const timeBlocks = (cfg.timeBlocks && cfg.timeBlocks[child]) ? cfg.timeBlocks[child] : [];
 return {chosen, timeBlocks, dailyMinutes:cfg.dailyInstructionMinutes || 360};
}

function dailyPlanHtml(child){
 const plan = dailyPlanFor(child);
 let html = `<h3>Daily Classroom Plan — ${child}</h3>`;
 html += `<div><b>Simulated classroom target:</b> ${plan.dailyMinutes} minutes (${Math.round(plan.dailyMinutes/60*10)/10} hours)</div>`;
 html += "<h4>Suggested question goals</h4>";
 html += plan.chosen.map(x=>`<div>${x.display}: ${x.questions} questions today <small>(${x.correct} / ${x.target})</small></div>`).join("");
 html += "<h4>Time blocks</h4>";
 html += plan.timeBlocks.map(x=>`<div>${x[0]} — ${x[1]} min</div>`).join("");
 html += "<div style='margin-top:8px;'>Use the weakest subjects first, then let game exploration and boss prep fill the rest of the learning block.</div>";
 return html;
}

function attendanceReportHtml(profile, child){
 const sum = attendanceSummary(profile, child, localDateKey());
 const rec = sum.rec;
 const cfg = window.LR_CLASSROOM_CONFIG || {};
 const targetSeconds = (cfg.dailyInstructionMinutes || 360) * 60;
 const pct = Math.min(100, Math.round(((rec.activeSeconds || 0) / targetSeconds) * 100));
 let html = `<div><b>Attendance today:</b> ${rec.present ? "Present" : "Not logged yet"}</div>`;
 html += `<div><b>Active game time:</b> ${formatMinutes(rec.activeSeconds)} / ${formatMinutes(targetSeconds)} (${pct}%)</div>`;
 html += `<div><b>Logins:</b> ${rec.loginCount || 0} | <b>First login:</b> ${rec.firstLogin || "—"} | <b>Last seen:</b> ${rec.lastSeen || "—"}</div>`;
 html += `<div><b>Problems attempted:</b> ${sum.attempted} | <b>Correct:</b> ${sum.correct} | <b>Wrong:</b> ${sum.wrong}</div>`;
 if(sum.subjects.length){
   html += "<table style='width:100%;border-collapse:collapse;margin-top:6px;'><thead><tr><th style='text-align:left;'>Subject</th><th style='text-align:left;'>Attempted</th><th style='text-align:left;'>Correct</th><th style='text-align:left;'>Wrong</th></tr></thead><tbody>";
   html += sum.subjects.map(s=>`<tr><td>${s}</td><td>${rec.answers[s].attempted||0}</td><td>${rec.answers[s].correct||0}</td><td>${rec.answers[s].wrong||0}</td></tr>`).join("");
   html += "</tbody></table>";
 }
 return html;
}

function attendanceLogHtml(profile, child){
 const sum = attendanceSummary(profile, child, localDateKey());
 const logs = (sum.rec.lessonLog || []).slice(-12).reverse();
 if(!logs.length) return "<div>No solved problems recorded today yet.</div>";
 return logs.map(x=>`<div>${x.time} — ${x.subject} — ${x.kind} — ${x.correct ? "correct" : "wrong"} — ${x.question}</div>`).join("");
}



/* Game Fun Pack 1: Quest Board Upgrade */
function gameFunConfig(){
 return window.LR_GAME_FUN_CONFIG || {dailyQuests:[],weeklyQuests:[],achievements:[]};
}

function weekKey(){
 const d = new Date();
 const onejan = new Date(d.getFullYear(),0,1);
 const dayOfYear = Math.floor((d - onejan) / 86400000) + 1;
 const week = Math.ceil((dayOfYear + onejan.getDay()) / 7);
 return d.getFullYear() + "-W" + String(week).padStart(2,"0");
}

function ensureGameFunFor(profile, child){
 if(!profile.gameFun) profile.gameFun = {};
 if(!profile.gameFun[child]){
   profile.gameFun[child] = {
     daily:{},
     weekly:{},
     achievementsClaimed:{},
     totals:{answers:0,correctLessons:0,wrongAnswers:0,bossAttempts:0,bossWins:0,roomVisits:0,bestStreak:0,subjectsEverCorrect:{}}
   };
 }
 const gf = profile.gameFun[child];
 if(!gf.daily) gf.daily = {};
 if(!gf.weekly) gf.weekly = {};
 if(!gf.achievementsClaimed) gf.achievementsClaimed = {};
 if(!gf.totals) gf.totals = {answers:0,correctLessons:0,wrongAnswers:0,bossAttempts:0,bossWins:0,roomVisits:0,bestStreak:0,subjectsEverCorrect:{}};
 if(!gf.totals.subjectsEverCorrect) gf.totals.subjectsEverCorrect = {};
 if(!gf.totals.roomsEver) gf.totals.roomsEver = {};
 return gf;
}

function ensureQuestBucket(parent, key){
 if(!parent[key]){
   parent[key] = {
     key,
     answers:0,
     correctLessons:0,
     wrongAnswers:0,
     bossAttempts:0,
     bossWins:0,
     roomVisits:0,
     bestStreak:0,
     subjectsCorrect:{},
     visitedRooms:{},
     claimed:{}
   };
 }
 if(!parent[key].subjectsCorrect) parent[key].subjectsCorrect = {};
 if(!parent[key].visitedRooms) parent[key].visitedRooms = {};
 if(!parent[key].claimed) parent[key].claimed = {};
 return parent[key];
}

function currentDailyQuestBucket(profile, child){
 const gf = ensureGameFunFor(profile || state, child || activeChild);
 return ensureQuestBucket(gf.daily, localDateKey());
}

function currentWeeklyQuestBucket(profile, child){
 const gf = ensureGameFunFor(profile || state, child || activeChild);
 return ensureQuestBucket(gf.weekly, weekKey());
}

function recordGameFunEvent(type, amount, extra){
 const gf = ensureGameFunFor(state, activeChild);
 const d = currentDailyQuestBucket(state, activeChild);
 const w = currentWeeklyQuestBucket(state, activeChild);
 const n = Math.max(1, amount || 1);

 function bump(bucket){
   if(type === "answers") bucket.answers = (bucket.answers || 0) + n;
   if(type === "correctLessons") bucket.correctLessons = (bucket.correctLessons || 0) + n;
   if(type === "wrongAnswers") bucket.wrongAnswers = (bucket.wrongAnswers || 0) + n;
   if(type === "bossAttempts") bucket.bossAttempts = (bucket.bossAttempts || 0) + n;
   if(type === "bossWins") bucket.bossWins = (bucket.bossWins || 0) + n;
   if(type === "roomVisits") {
     bucket.roomVisits = (bucket.roomVisits || 0) + n;
     if(extra && extra.room) bucket.visitedRooms[extra.room] = true;
   }
   if(type === "subjectCorrect" && extra && extra.subject){
     bucket.subjectsCorrect[extra.subject] = true;
   }
   if(type === "bestStreak" && extra && extra.streak){
     bucket.bestStreak = Math.max(bucket.bestStreak || 0, extra.streak);
   }
 }

 bump(d);
 bump(w);

 if(type === "answers") gf.totals.answers = (gf.totals.answers || 0) + n;
 if(type === "correctLessons") gf.totals.correctLessons = (gf.totals.correctLessons || 0) + n;
 if(type === "wrongAnswers") gf.totals.wrongAnswers = (gf.totals.wrongAnswers || 0) + n;
 if(type === "bossAttempts") gf.totals.bossAttempts = (gf.totals.bossAttempts || 0) + n;
 if(type === "bossWins") gf.totals.bossWins = (gf.totals.bossWins || 0) + n;
 if(type === "roomVisits") { gf.totals.roomVisits = (gf.totals.roomVisits || 0) + n; if(extra && extra.room){ if(!gf.totals.roomsEver) gf.totals.roomsEver = {}; gf.totals.roomsEver[extra.room] = true; } }
 if(type === "bestStreak" && extra && extra.streak) gf.totals.bestStreak = Math.max(gf.totals.bestStreak || 0, extra.streak);
 if(type === "subjectCorrect" && extra && extra.subject) gf.totals.subjectsEverCorrect[extra.subject] = true;
}

function questMetricProgress(q, bucket){
 const metric = q.metric;
 if(metric === "subjectsCorrect") return Object.keys(bucket.subjectsCorrect || {}).length;
 if(metric === "visitedRooms") return Object.keys(bucket.visitedRooms || {}).length;
 return bucket[metric] || 0;
}

function achievementProgress(a, profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const gf = ensureGameFunFor(p, c);
 const totals = gf.totals || {};
 if(a.metric === "totalAnswers") return totals.answers || 0;
 if(a.metric === "totalRooms") return p.room || totals.roomVisits || 0;
 if(a.metric === "subjectsEverCorrect") return Object.keys(totals.subjectsEverCorrect || {}).length;
 if(a.metric === "bossesCleared") return Object.values((p.bossWins && p.bossWins[c]) || {}).filter(Boolean).length;
 if(a.metric === "level") return ensureLevelingFor(p, c).level || 1;
 return totals[a.metric] || 0;
}

function rewardTextFor(reward){
 if(!reward) return "No reward configured";
 const parts = [];
 if(reward.sparks) parts.push("+" + reward.sparks + " Sparks");
 if(reward.xp) parts.push("+" + reward.xp + " XP");
 if(reward.ancientCoins) parts.push("+" + reward.ancientCoins + " Ancient Coins");
 if(reward.coins) parts.push("+" + reward.coins + " Coins");
 if(reward.item) parts.push(reward.item.name);
 return parts.join(", ");
}

function grantGameFunReward(reward, reason){
 if(!reward) return "Reward claimed.";
 const messages = [];
 if(reward.sparks){ state.sparks = (state.sparks || 0) + reward.sparks; messages.push("+" + reward.sparks + " Sparks"); }
 if(reward.coins){ state.coins = (state.coins || 0) + reward.coins; messages.push("+" + reward.coins + " Coins"); }
 if(reward.ancientCoins){ state.ancientCoins = (state.ancientCoins || 0) + reward.ancientCoins; messages.push("+" + reward.ancientCoins + " Ancient Coins"); }
 if(reward.xp){
   const xp = addXP(reward.xp, reason || "quest reward");
   messages.push(xp.message);
 }
 if(reward.item){
   const h = ensureHome();
   if(!h.storage.find(x=>x.name === reward.item.name) && !Object.values(h.equip || {}).find(x=>x && x.name === reward.item.name)){
     h.storage.push({...reward.item});
     messages.push("Item: " + reward.item.name);
   }else{
     messages.push("Item already owned: " + reward.item.name);
   }
 }
 return messages.join(" | ") || "Reward claimed.";
}

function claimDailyQuest(id){
 const cfg = gameFunConfig();
 const q = (cfg.dailyQuests || []).find(x=>x.id === id);
 const bucket = currentDailyQuestBucket(state, activeChild);
 if(!q) return;
 const progress = questMetricProgress(q,bucket);
 if(progress < q.target){ $("feedback").textContent = "Quest not finished yet."; return; }
 if(bucket.claimed[id]){ $("feedback").textContent = "Already claimed today."; return; }
 bucket.claimed[id] = true;
 const msg = grantGameFunReward(q.reward, "daily quest");
 addMemory("Daily Quest: " + q.title, msg);
 $("feedback").textContent = "Daily quest claimed: " + msg;
 save();
 openQuestBoard();
 renderStats();
}

function claimWeeklyQuest(id){
 const cfg = gameFunConfig();
 const q = (cfg.weeklyQuests || []).find(x=>x.id === id);
 const bucket = currentWeeklyQuestBucket(state, activeChild);
 if(!q) return;
 const progress = questMetricProgress(q,bucket);
 if(progress < q.target){ $("feedback").textContent = "Weekly quest not finished yet."; return; }
 if(bucket.claimed[id]){ $("feedback").textContent = "Already claimed this week."; return; }
 bucket.claimed[id] = true;
 const msg = grantGameFunReward(q.reward, "weekly quest");
 addMemory("Weekly Quest: " + q.title, msg);
 $("feedback").textContent = "Weekly quest claimed: " + msg;
 save();
 openQuestBoard();
 renderStats();
}

function claimAchievement(id){
 const cfg = gameFunConfig();
 const a = (cfg.achievements || []).find(x=>x.id === id);
 const gf = ensureGameFunFor(state, activeChild);
 if(!a) return;
 const progress = achievementProgress(a, state, activeChild);
 if(progress < a.target){ $("feedback").textContent = "Achievement not unlocked yet."; return; }
 if(gf.achievementsClaimed[id]){ $("feedback").textContent = "Achievement already claimed."; return; }
 gf.achievementsClaimed[id] = true;
 const msg = grantGameFunReward(a.reward, "achievement");
 addMemory("Achievement: " + a.title, msg);
 $("feedback").textContent = "Achievement claimed: " + msg;
 save();
 openQuestBoard();
 renderStats();
}

function questCardHtml(q, bucket, kind){
 const progress = questMetricProgress(q,bucket);
 const pct = Math.min(100, Math.round((progress / q.target) * 100));
 const ready = progress >= q.target;
 const claimed = !!bucket.claimed[q.id];
 const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="${kind}('${q.id}')">Claim Reward</button>` : "<button disabled>In Progress</button>";
 return `<div class="questCard ${ready ? "questReady" : ""}">
   <div class="questTitle">${ready && !claimed ? "⭐ " : ""}${lrEscape(q.title)}</div>
   <div class="questGoal">${lrEscape(q.goal)}</div>
   <div class="questTrack"><div class="questFill" style="width:${pct}%"></div></div>
   <div class="questMeta">${progress} / ${q.target} — Reward: ${lrEscape(rewardTextFor(q.reward))}</div>
   ${btn}
 </div>`;
}

function achievementCardHtml(a, gf){
 const progress = achievementProgress(a, state, activeChild);
 const pct = Math.min(100, Math.round((progress / a.target) * 100));
 const ready = progress >= a.target;
 const claimed = !!gf.achievementsClaimed[a.id];
 const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimAchievement('${a.id}')">Claim Achievement</button>` : "<button disabled>Locked</button>";
 return `<div class="questCard ${ready ? "questReady" : ""}">
   <div class="questTitle">${ready && !claimed ? "🏅 " : ""}${lrEscape(a.title)}</div>
   <div class="questGoal">${lrEscape(a.goal)}</div>
   <div class="questTrack"><div class="questFill" style="width:${pct}%"></div></div>
   <div class="questMeta">${progress} / ${a.target} — Reward: ${lrEscape(rewardTextFor(a.reward))}</div>
   ${btn}
 </div>`;
}

function questSummaryLine(){
 const d = currentDailyQuestBucket(state, activeChild);
 const w = currentWeeklyQuestBucket(state, activeChild);
 return `Today: ${d.answers || 0} answered, ${d.correctLessons || 0} correct, ${d.roomVisits || 0} rooms, ${Object.keys(d.subjectsCorrect || {}).length} subjects. This week: ${w.answers || 0} answered, ${w.correctLessons || 0} correct, ${w.roomVisits || 0} rooms.`;
}
/* End Game Fun Pack 1 */

function openLevelGuide(){
 const lev = ensureLeveling();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Level Guide";
 $("actionText").innerHTML = levelPanelHtml(state, activeChild) + `
   <div class="lessonCard">
     <div class="lessonCardTitle">⚔️ How to Level Up</div>
     <div class="lessonCardText">
Correct lesson: +${xpAward("correctLesson")} XP
Portfolio work: +${xpAward("portfolioComplete")} XP
Boss attempt: +${xpAward("bossAttempt")} XP
Boss win: +${xpAward("bossWin")} XP
First boss clear bonus: +${xpAward("firstBossClearBonus")} XP

Leveling unlocks home items, titles, Sparks, Ancient Coins, and future gates.
     </div>
   </div>`;

 const cfg = levelConfig();
 const milestones = cfg.milestones || {};
 const rows = Object.keys(milestones).map(k=>{
   const m = milestones[k];
   return `<div><b>Level ${k}: ${lrEscape(m.title || "Milestone")}</b><br>${lrEscape(m.message || "")}</div>`;
 }).join("");

 $("storageItems").innerHTML = `<h3>Known Level Rewards</h3>${rows || "<div>No milestones configured.</div>"}
 <h3>Recent Level Ups</h3>
 ${(lev.levelUps || []).slice(-8).reverse().map(x=>`<div>Level ${x.level} — ${x.date} ${x.time}</div>`).join("") || "<div>No level ups yet.</div>"}`;
}

function openDailyClassroomBoard(){
 openClassroomSchedule();
}


/* Game Fun Pack 5: Random Events & Treasure Maps */
function randomEventConfig(){
 return window.LR_RANDOM_EVENT_CONFIG || {chancePerRoom:0.18,dailyEventCap:10,cooldownRooms:2,events:[],subjectEventText:{},mapMilestones:[]};
}

function ensureRandomEventsFor(profile, child){
 if(!profile.randomEvents) profile.randomEvents = {};
 if(!profile.randomEvents[child]){
   profile.randomEvents[child] = {
     totalEvents:0,
     lastEventRoomCount:-99,
     daily:{},
     log:[],
     mapScraps:0,
     claimedMapMilestones:{}
   };
 }
 const r = profile.randomEvents[child];
 if(!r.daily) r.daily = {};
 if(!r.log) r.log = [];
 if(!r.claimedMapMilestones) r.claimedMapMilestones = {};
 return r;
}

function ensureRandomEvents(){
 return ensureRandomEventsFor(state, activeChild);
}

function randomEventDailyBucket(){
 const r = ensureRandomEvents();
 const key = localDateKey();
 if(!r.daily[key]) r.daily[key] = {count:0,seen:{}};
 return r.daily[key];
}

function weightedRandomEvent(events){
 const list = (events || []).filter(Boolean);
 const total = list.reduce((sum,e)=>sum+(e.weight || 1),0);
 let roll = Math.random() * total;
 for(const e of list){
   roll -= (e.weight || 1);
   if(roll <= 0) return e;
 }
 return list[0];
}

function addRandomEventLog(event, text){
 const r = ensureRandomEvents();
 r.log.unshift({
   time:new Date().toLocaleString(),
   room:room().title || state.loc,
   zone:room().zone || "",
   subject:room().subject || "",
   title:event.title,
   text:text
 });
 r.log = r.log.slice(0,50);
}

function randomEventReward(event){
 let msg = "";
 if(event.reward){
   msg += grantGameFunReward(event.reward, "random event");
 }
 if(event.companionXp){
   msg += " " + addCompanionXP(event.companionXp, "random event companion find", room().subject || "Adventure");
 }
 if(event.type === "map"){
   const r = ensureRandomEvents();
   r.mapScraps = (r.mapScraps || 0) + 1;
   msg += " Map scraps: " + r.mapScraps + ".";
   msg += checkMapMilestones();
 }
 return msg;
}

function checkMapMilestones(){
 const cfg = randomEventConfig();
 const r = ensureRandomEvents();
 let out = "";
 (cfg.mapMilestones || []).forEach((m,idx)=>{
   const id = "map_" + m.scraps + "_" + idx;
   if((r.mapScraps || 0) >= m.scraps && !r.claimedMapMilestones[id]){
     r.claimedMapMilestones[id] = true;
     const msg = grantGameFunReward(m.reward, "treasure map milestone");
     const col = ensureCollection();
     if(m.title && col.manualTitles && !col.manualTitles.includes(m.title)) col.manualTitles.push(m.title);
     out += " Treasure map milestone unlocked: " + m.title + ". " + msg;
     addMemory("Treasure Map Milestone", activeChild + " unlocked " + m.title + ". " + msg);
   }
 });
 return out;
}

function maybeTriggerRandomEvent(roomId){
 const cfg = randomEventConfig();
 const r = ensureRandomEvents();
 const daily = randomEventDailyBucket();
 if((daily.count || 0) >= (cfg.dailyEventCap || 10)) return;
 if((state.room || 0) - (r.lastEventRoomCount || -99) < (cfg.cooldownRooms || 2)) return;
 if(Math.random() > (cfg.chancePerRoom || 0.18)) return;

 const event = weightedRandomEvent(cfg.events || []);
 if(!event) return;

 r.lastEventRoomCount = state.room || 0;
 r.totalEvents = (r.totalEvents || 0) + 1;
 daily.count = (daily.count || 0) + 1;
 daily.seen[event.id] = (daily.seen[event.id] || 0) + 1;

 let text = event.text || "Something interesting happens.";
 const subj = room().subject;
 if(event.type === "subject" && subj && cfg.subjectEventText && cfg.subjectEventText[subj]){
   text += " " + cfg.subjectEventText[subj];
 }

 const rewardMsg = randomEventReward(event);
 const fullText = text + (rewardMsg ? "\n\nReward: " + rewardMsg : "");
 addRandomEventLog(event, fullText);
 addMemory("Random Event: " + event.title, fullText);

 $("actionTitle").textContent = "✨ " + event.title;
 $("actionText").textContent = fullText;
 $("feedback").textContent = "Random event discovered: " + event.title + ".";
 save();
 renderStats();
}

function eventLogSummaryLine(profile, child){
 const r = ensureRandomEventsFor(profile || state, child || activeChild);
 return `${r.totalEvents || 0} total events, ${r.mapScraps || 0} map scraps, ${randomEventDailyBucket().count || 0} events today`;
}

function eventLogHtml(){
 const r = ensureRandomEvents();
 if(!r.log.length) return "<p>No random events found yet. Explore rooms to discover them.</p>";
 return r.log.map(e=>`<div class="eventCard">
   <div class="eventTitle">✨ ${lrEscape(e.title)}</div>
   <div class="eventMeta">${lrEscape(e.time)} — ${lrEscape(e.zone || e.room)}${e.subject ? " — " + lrEscape(e.subject) : ""}</div>
   <div class="eventText">${lrEscape(e.text).replace(/\n/g,"<br>")}</div>
 </div>`).join("");
}

function mapMilestonesHtml(){
 const cfg = randomEventConfig();
 const r = ensureRandomEvents();
 return (cfg.mapMilestones || []).map((m,idx)=>{
   const id = "map_" + m.scraps + "_" + idx;
   const ready = (r.mapScraps || 0) >= m.scraps;
   const claimed = !!r.claimedMapMilestones[id];
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🗺️</span><b>${lrEscape(m.title)}</b><span>${r.mapScraps || 0} / ${m.scraps}</span></div>
     <div class="collectionDesc">${claimed ? "Unlocked" : ready ? "Ready" : "Find more map scraps"} — Reward: ${lrEscape(rewardTextFor(m.reward))}</div>
   </div>`;
 }).join("");
}

function openEventLog(){
 attendanceTick(true);
 const r = ensureRandomEvents();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Event Log";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">✨ Random Events & Treasure Maps</div>
   <div class="lessonCardText">${lrEscape(eventLogSummaryLine(state, activeChild))}<br><br>Explore rooms to find surprise events, hidden caches, lore tablets, companion finds, and map scraps.</div>
 </div>`;
 $("storageItems").innerHTML =
   `<h3>Treasure Map Milestones</h3>${mapMilestonesHtml()}<h3>Recent Events</h3>${eventLogHtml()}`;
}
/* End Game Fun Pack 5 */


/* Game Fun Pack 6: Subject Mastery Paths */
function masteryPathConfig(){
 return window.LR_MASTERY_PATH_CONFIG || {xp:{},ranks:[],subjectFlavor:{},multiSubjectMilestones:[]};
}

function ensureMasteryFor(profile, child){
 if(!profile.masteryPaths) profile.masteryPaths = {};
 if(!profile.masteryPaths[child]){
   profile.masteryPaths[child] = {
     subjects:{},
     claimedMulti:{}
   };
 }
 const m = profile.masteryPaths[child];
 if(!m.subjects) m.subjects = {};
 if(!m.claimedMulti) m.claimedMulti = {};
 return m;
}

function ensureMastery(){
 return ensureMasteryFor(state, activeChild);
}

function ensureSubjectMastery(profile, child, subj){
 const m = ensureMasteryFor(profile, child);
 if(!m.subjects[subj]){
   m.subjects[subj] = {
     xp:0,
     rank:1,
     claimedRanks:{},
     correct:0,
     bossWins:0
   };
 }
 if(!m.subjects[subj].claimedRanks) m.subjects[subj].claimedRanks = {};
 if(!m.subjects[subj].rank) m.subjects[subj].rank = 1;
 if(!m.subjects[subj].xp) m.subjects[subj].xp = 0;
 return m.subjects[subj];
}

function masteryFlavor(subj){
 const cfg = masteryPathConfig();
 return (cfg.subjectFlavor || {})[subj] || {title:subj + " Scholar",icon:"⭐",item:subj + " Mastery Token"};
}

function masteryRankForXp(xp){
 const cfg = masteryPathConfig();
 const ranks = (cfg.ranks || []).slice().sort((a,b)=>a.xp-b.xp);
 let current = ranks[0] || {rank:1,name:"Novice",xp:0};
 for(const r of ranks){
   if(xp >= r.xp) current = r;
 }
 return current;
}

function nextMasteryRank(rank){
 const cfg = masteryPathConfig();
 const ranks = (cfg.ranks || []).slice().sort((a,b)=>a.rank-b.rank);
 return ranks.find(r=>r.rank > rank) || null;
}

function grantSubjectRankReward(subj, rankDef){
 if(!rankDef || !rankDef.reward) return "";
 const flavor = masteryFlavor(subj);
 const reward = JSON.parse(JSON.stringify(rankDef.reward));
 if(reward.item && reward.item.name){
   reward.item.name = flavor.item + " — " + rankDef.name;
 }
 const msg = grantGameFunReward(reward, subj + " mastery rank");
 const col = ensureCollection();
 const title = flavor.title + " " + rankDef.name;
 if(col.manualTitles && !col.manualTitles.includes(title)) col.manualTitles.push(title);
 addMemory("Subject Mastery Rank", activeChild + " reached " + rankDef.name + " in " + subj + ". " + msg);
 return " " + subj + " mastery rank up: " + rankDef.name + "! " + msg;
}

function addSubjectMasteryXP(subj, amount, source){
 if(!subj) return "";
 const sm = ensureSubjectMastery(state, activeChild, subj);
 const gain = Math.max(0, Math.floor(amount || 0));
 if(!gain) return "";
 sm.xp += gain;
 if(source === "correctLesson") sm.correct = (sm.correct || 0) + 1;
 if(source === "bossWin") sm.bossWins = (sm.bossWins || 0) + 1;

 let text = " +" + gain + " " + subj + " Mastery XP.";
 let newRank = masteryRankForXp(sm.xp);
 while(newRank && newRank.rank > sm.rank){
   sm.rank++;
   const rankDef = (masteryPathConfig().ranks || []).find(r=>r.rank === sm.rank) || newRank;
   if(!sm.claimedRanks[sm.rank]){
     sm.claimedRanks[sm.rank] = true;
     text += grantSubjectRankReward(subj, rankDef);
   }
 }
 text += checkMultiSubjectMasteryMilestones();
 return text;
}

function subjectMasteryList(child){
 const subjects = Object.keys(LESSONS[child] || {}).sort();
 const m = ensureMasteryFor(state, child);
 Object.keys(m.subjects || {}).forEach(s=>{ if(!subjects.includes(s)) subjects.push(s); });
 return subjects.sort();
}

function masteryProgressHtml(subj){
 const sm = ensureSubjectMastery(state, activeChild, subj);
 const rankDef = masteryRankForXp(sm.xp);
 const next = nextMasteryRank(rankDef.rank);
 let pct = 100;
 let line = "Max rank reached";
 if(next){
   const prevXp = rankDef.xp || 0;
   const span = Math.max(1, next.xp - prevXp);
   pct = Math.min(100, Math.round(((sm.xp - prevXp) / span) * 100));
   line = sm.xp + " / " + next.xp + " XP toward " + next.name;
 }
 return `<div class="masteryTrack"><div class="masteryFill" style="width:${pct}%"></div></div><div class="questMeta">${lrEscape(line)}</div>`;
}

function masteryCardHtml(subj){
 const sm = ensureSubjectMastery(state, activeChild, subj);
 const flavor = masteryFlavor(subj);
 const rankDef = masteryRankForXp(sm.xp);
 return `<div class="masteryCard">
   <div class="masteryHeader"><span>${flavor.icon || "⭐"}</span><b>${lrEscape(subj)}</b><span>Rank ${rankDef.rank}: ${lrEscape(rankDef.name)}</span></div>
   <div class="collectionDesc">Title path: ${lrEscape(flavor.title)} | Correct: ${sm.correct || 0} | Boss wins: ${sm.bossWins || 0}</div>
   ${masteryProgressHtml(subj)}
 </div>`;
}

function masteryRankCountAt(rank){
 const m = ensureMastery();
 return Object.values(m.subjects || {}).filter(s=> (s.rank || 1) >= rank).length;
}

function checkMultiSubjectMasteryMilestones(){
 const cfg = masteryPathConfig();
 const m = ensureMastery();
 let out = "";
 (cfg.multiSubjectMilestones || []).forEach(ms=>{
   const count = masteryRankCountAt(ms.rank);
   if(count >= ms.count && !m.claimedMulti[ms.id]){
     m.claimedMulti[ms.id] = true;
     const msg = grantGameFunReward(ms.reward, "multi-subject mastery");
     const col = ensureCollection();
     if(ms.title && col.manualTitles && !col.manualTitles.includes(ms.title)) col.manualTitles.push(ms.title);
     out += " Multi-subject mastery unlocked: " + ms.title + ". " + msg;
     addMemory("Multi-Subject Mastery", activeChild + " unlocked " + ms.title + ". " + msg);
   }
 });
 return out;
}

function masteryMilestonesHtml(){
 const cfg = masteryPathConfig();
 const m = ensureMastery();
 return (cfg.multiSubjectMilestones || []).map(ms=>{
   const count = masteryRankCountAt(ms.rank);
   const ready = count >= ms.count;
   const claimed = !!m.claimedMulti[ms.id];
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🌟</span><b>${lrEscape(ms.title)}</b><span>${count} / ${ms.count}</span></div>
     <div class="collectionDesc">${claimed ? "Unlocked" : ready ? "Ready" : "Reach Rank " + ms.rank + " in more subjects"} — Reward: ${lrEscape(rewardTextFor(ms.reward))}</div>
   </div>`;
 }).join("");
}

function masterySummaryLine(profile, child){
 const m = ensureMasteryFor(profile || state, child || activeChild);
 const subjects = Object.values(m.subjects || {});
 if(!subjects.length) return "No subject mastery XP yet.";
 const best = subjects.reduce((a,b)=> ((b.rank || 1) > (a.rank || 1) ? b : a), subjects[0]);
 const totalXp = subjects.reduce((sum,s)=>sum+(s.xp || 0),0);
 const highestRank = Math.max(...subjects.map(s=>s.rank || 1));
 return `${subjects.length} subjects started, ${totalXp} mastery XP, highest rank ${highestRank}`;
}

function openMasteryPaths(){
 attendanceTick(true);
 const subjects = subjectMasteryList(activeChild);
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Subject Mastery Paths";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🌟 ${lrEscape(activeChild)}'s Mastery Paths</div>
   <div class="lessonCardText">${lrEscape(masterySummaryLine(state, activeChild))}<br><br>Correct answers and boss wins now build subject-specific mastery ranks.</div>
 </div>`;
 $("storageItems").innerHTML =
   `<h3>Multi-Subject Mastery Rewards</h3>${masteryMilestonesHtml()}
    <h3>Subject Paths</h3>${subjects.map(masteryCardHtml).join("")}`;
}
/* End Game Fun Pack 6 */


/* Game Fun Pack 7: Homeschool Report Center */
function reportCenterConfig(){
 return window.LR_REPORT_CENTER_CONFIG || {dailyInstructionMinutes:360,partialDayMinutes:180,attendanceRewards:[],exportColumns:[]};
}

function reportTargetSeconds(){
 const rc = reportCenterConfig();
 const cc = window.LR_CLASSROOM_CONFIG || {};
 return ((rc.dailyInstructionMinutes || cc.dailyInstructionMinutes || 360) * 60);
}

function reportTargetMinutes(){
 return Math.round(reportTargetSeconds() / 60);
}

function ensureReportCenterFor(profile, child){
 if(!profile.reportCenter) profile.reportCenter = {};
 if(!profile.reportCenter[child]){
   profile.reportCenter[child] = {
     notes:{},
     claimedAttendanceRewards:{}
   };
 }
 const r = profile.reportCenter[child];
 if(!r.notes) r.notes = {};
 if(!r.claimedAttendanceRewards) r.claimedAttendanceRewards = {};
 return r;
}

function ensureReportCenter(){
 return ensureReportCenterFor(state, activeChild);
}

function attendanceDates(profile){
 return Object.keys((profile && profile.attendance) || {}).sort();
}

function reportStatusFor(rec){
 const target = reportTargetSeconds();
 const partial = (reportCenterConfig().partialDayMinutes || 180) * 60;
 const active = rec ? (rec.activeSeconds || 0) : 0;
 if(active >= target) return "Full Day";
 if(active >= partial) return "Partial Day";
 if(active >= 60) return "Logged Learning";
 return rec && rec.present ? "Present" : "No Login";
}

function reportDateSummary(profile, child, dateKey){
 const sum = attendanceSummary(profile, child, dateKey);
 const rec = sum.rec;
 const rc = ensureReportCenterFor(profile, child);
 return {
   date:dateKey,
   status:reportStatusFor(rec),
   activeSeconds:rec.activeSeconds || 0,
   activeMinutes:Math.round((rec.activeSeconds || 0) / 60),
   targetMinutes:reportTargetMinutes(),
   loginCount:rec.loginCount || 0,
   firstLogin:rec.firstLogin || "",
   lastSeen:rec.lastSeen || "",
   attempted:sum.attempted,
   correct:sum.correct,
   wrong:sum.wrong,
   subjects:sum.subjects,
   note:rc.notes[dateKey] || ""
 };
}

function reportAllDateSummaries(profile, child){
 const dates = attendanceDates(profile);
 return dates.map(d=>reportDateSummary(profile, child, d));
}

function reportTotalSummary(profile, child){
 const rows = reportAllDateSummaries(profile, child);
 const totals = rows.reduce((acc,r)=>{
   acc.days += r.status !== "No Login" ? 1 : 0;
   acc.fullDays += r.status === "Full Day" ? 1 : 0;
   acc.partialDays += r.status === "Partial Day" ? 1 : 0;
   acc.activeSeconds += r.activeSeconds || 0;
   acc.attempted += r.attempted || 0;
   acc.correct += r.correct || 0;
   acc.wrong += r.wrong || 0;
   r.subjects.forEach(s=>acc.subjects[s]=true);
   return acc;
 },{days:0,fullDays:0,partialDays:0,activeSeconds:0,attempted:0,correct:0,wrong:0,subjects:{}});
 totals.subjectCount = Object.keys(totals.subjects).length;
 return totals;
}

function subjectTotalsForReport(profile, child){
 const out = {};
 attendanceDates(profile).forEach(date=>{
   const rec = ensureAttendanceFor(profile, child, date);
   Object.keys(rec.answers || {}).forEach(subj=>{
     if(!out[subj]) out[subj] = {attempted:0,correct:0,wrong:0,bossAttempts:0,bossWins:0};
     const a = rec.answers[subj];
     out[subj].attempted += a.attempted || 0;
     out[subj].correct += a.correct || 0;
     out[subj].wrong += a.wrong || 0;
     out[subj].bossAttempts += a.bossAttempts || 0;
     out[subj].bossWins += a.bossWins || 0;
   });
 });
 return out;
}

function reportProgressBar(pct){
 const safe = Math.max(0, Math.min(100, Math.round(pct || 0)));
 return `<div class="reportTrack"><div class="reportFill" style="width:${safe}%"></div></div>`;
}

function todaySchoolDayCard(){
 const row = reportDateSummary(state, activeChild, localDateKey());
 const pct = Math.min(100, Math.round((row.activeSeconds / reportTargetSeconds()) * 100));
 return `<div class="reportCard reportToday">
   <div class="reportHeader"><b>Today's School Record</b><span>${lrEscape(row.status)}</span></div>
   ${reportProgressBar(pct)}
   <div class="reportGrid">
     <div><b>Active time</b><br>${formatMinutes(row.activeSeconds)} / ${formatMinutes(reportTargetSeconds())}</div>
     <div><b>Problems</b><br>${row.attempted} attempted | ${row.correct} correct | ${row.wrong} wrong</div>
     <div><b>Logins</b><br>${row.loginCount} | First: ${row.firstLogin || "—"} | Last: ${row.lastSeen || "—"}</div>
     <div><b>Subjects</b><br>${row.subjects.length ? row.subjects.join(", ") : "None yet"}</div>
   </div>
 </div>`;
}

function reportHistoryTable(profile, child){
 const rows = reportAllDateSummaries(profile, child).slice(-30).reverse();
 if(!rows.length) return "<p>No attendance records yet.</p>";
 return `<table class="reportTable">
   <thead><tr><th>Date</th><th>Status</th><th>Active Time</th><th>Problems</th><th>Correct</th><th>Wrong</th><th>Subjects</th></tr></thead>
   <tbody>
     ${rows.map(r=>`<tr>
       <td>${lrEscape(r.date)}</td>
       <td>${lrEscape(r.status)}</td>
       <td>${formatMinutes(r.activeSeconds)}</td>
       <td>${r.attempted}</td>
       <td>${r.correct}</td>
       <td>${r.wrong}</td>
       <td>${r.subjects.length}</td>
     </tr>`).join("")}
   </tbody>
 </table>`;
}

function reportSubjectTotalsTable(profile, child){
 const totals = subjectTotalsForReport(profile, child);
 const subjects = Object.keys(totals).sort();
 if(!subjects.length) return "<p>No subject totals yet.</p>";
 return `<table class="reportTable">
   <thead><tr><th>Subject</th><th>Attempted</th><th>Correct</th><th>Wrong</th><th>Boss Attempts</th><th>Boss Wins</th></tr></thead>
   <tbody>
     ${subjects.map(s=>`<tr>
       <td>${lrEscape(s)}</td>
       <td>${totals[s].attempted}</td>
       <td>${totals[s].correct}</td>
       <td>${totals[s].wrong}</td>
       <td>${totals[s].bossAttempts}</td>
       <td>${totals[s].bossWins}</td>
     </tr>`).join("")}
   </tbody>
 </table>`;
}

function recentProblemLogTable(profile, child){
 const rec = ensureAttendanceFor(profile, child, localDateKey());
 const logs = (rec.lessonLog || []).slice(-40).reverse();
 if(!logs.length) return "<p>No problems solved today yet.</p>";
 return `<table class="reportTable">
   <thead><tr><th>Time</th><th>Subject</th><th>Kind</th><th>Result</th><th>Question</th></tr></thead>
   <tbody>
     ${logs.map(x=>`<tr>
       <td>${lrEscape(x.time || "")}</td>
       <td>${lrEscape(x.subject || "")}</td>
       <td>${lrEscape(x.kind || "lesson")}</td>
       <td>${x.correct ? "Correct" : "Wrong"}</td>
       <td>${lrEscape((x.question || "").slice(0,120))}</td>
     </tr>`).join("")}
   </tbody>
 </table>`;
}

function csvCell(v){
 const s = String(v == null ? "" : v);
 return '"' + s.replace(/"/g,'""') + '"';
}

function downloadTextFile(filename, text, mime){
 const blob = new Blob([text], {type:mime || "text/plain"});
 const url = URL.createObjectURL(blob);
 const a = document.createElement("a");
 a.href = url;
 a.download = filename;
 document.body.appendChild(a);
 a.click();
 setTimeout(()=>{URL.revokeObjectURL(url); a.remove();}, 0);
}

function exportAttendanceCSV(){
 const cfg = reportCenterConfig();
 const headers = cfg.exportColumns || [];
 const rows = reportAllDateSummaries(state, activeChild).map(r=>[
   activeChild,
   r.date,
   r.status,
   r.activeMinutes,
   r.targetMinutes,
   r.loginCount,
   r.firstLogin,
   r.lastSeen,
   r.attempted,
   r.correct,
   r.wrong,
   r.subjects.join("; "),
   r.note
 ]);
 const csv = [headers, ...rows].map(row=>row.map(csvCell).join(",")).join("\n");
 downloadTextFile("LearningRealms_Attendance_"+activeChild+"_"+localDateKey()+".csv", csv, "text/csv");
 $("feedback").textContent = "Attendance CSV exported.";
}

function exportProblemLogCSV(){
 const rows = [["Student","Date","Time","Subject","Kind","Correct","Question"]];
 attendanceDates(state).forEach(date=>{
   const rec = ensureAttendanceFor(state, activeChild, date);
   (rec.lessonLog || []).forEach(x=>{
     rows.push([activeChild,date,x.time || "",x.subject || "",x.kind || "lesson",x.correct ? "Correct" : "Wrong",x.question || ""]);
   });
 });
 const csv = rows.map(row=>row.map(csvCell).join(",")).join("\n");
 downloadTextFile("LearningRealms_ProblemLog_"+activeChild+"_"+localDateKey()+".csv", csv, "text/csv");
 $("feedback").textContent = "Problem log CSV exported.";
}

function exportReportJSON(){
 const payload = {
   student:activeChild,
   exported: new Date().toLocaleString(),
   dailyTargetMinutes:reportTargetMinutes(),
   attendance:reportAllDateSummaries(state, activeChild),
   subjectTotals:subjectTotalsForReport(state, activeChild),
   collection:collectionSummaryLine(state, activeChild),
   companion:companionSummaryLine(state, activeChild),
   mastery:masterySummaryLine(state, activeChild),
   events:eventLogSummaryLine(state, activeChild)
 };
 downloadTextFile("LearningRealms_Report_"+activeChild+"_"+localDateKey()+".json", JSON.stringify(payload,null,2), "application/json");
 $("feedback").textContent = "Report JSON exported.";
}

function saveDailyReportNote(){
 const box = document.getElementById("reportNoteBox");
 if(!box) return;
 const rc = ensureReportCenter();
 rc.notes[localDateKey()] = box.value || "";
 save();
 $("feedback").textContent = "Daily report note saved.";
 openReportCenter();
}

function checkReportAttendanceRewards(){
 const cfg = reportCenterConfig();
 const rc = ensureReportCenter();
 const rec = todayAttendance(state, activeChild);
 const date = localDateKey();
 if(!rc.claimedAttendanceRewards[date]) rc.claimedAttendanceRewards[date] = {};
 let out = "";
 (cfg.attendanceRewards || []).forEach(r=>{
   if(r.scope !== "daily") return;
   const secondsNeeded = (r.minutes || 0) * 60;
   if((rec.activeSeconds || 0) >= secondsNeeded && !rc.claimedAttendanceRewards[date][r.id]){
     rc.claimedAttendanceRewards[date][r.id] = true;
     const msg = grantGameFunReward(r.reward, "attendance reward");
     out += " Attendance reward unlocked: " + r.title + ". " + msg;
     addMemory("Attendance Reward", activeChild + " unlocked " + r.title + ". " + msg);
   }
 });
 if(out) save();
 return out;
}

function reportRewardStatusHtml(){
 const cfg = reportCenterConfig();
 const rc = ensureReportCenter();
 const rec = todayAttendance(state, activeChild);
 const date = localDateKey();
 const claimed = rc.claimedAttendanceRewards[date] || {};
 return (cfg.attendanceRewards || []).map(r=>{
   const activeMin = Math.round((rec.activeSeconds || 0)/60);
   const ready = activeMin >= (r.minutes || 0);
   const done = !!claimed[r.id];
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>📘</span><b>${lrEscape(r.title)}</b><span>${activeMin} / ${r.minutes} min</span></div>
     <div class="collectionDesc">${done ? "Claimed automatically" : ready ? "Ready" : "Keep learning"} — Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
   </div>`;
 }).join("");
}

function schoolReportSummaryLine(profile, child){
 const today = reportDateSummary(profile || state, child || activeChild, localDateKey());
 const totals = reportTotalSummary(profile || state, child || activeChild);
 return `Today ${formatMinutes(today.activeSeconds)} / ${formatMinutes(reportTargetSeconds())}, ${today.correct} correct. Records: ${totals.days} days, ${formatMinutes(totals.activeSeconds)} total.`;
}

function openReportCenter(){
 attendanceTick(true);
 const rewardMsg = checkReportAttendanceRewards();
 const totals = reportTotalSummary(state, activeChild);
 const note = (ensureReportCenter().notes || {})[localDateKey()] || "";

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Homeschool Report Center";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">📘 ${lrEscape(activeChild)}'s Homeschool Record</div>
   <div class="lessonCardText">
     ${lrEscape(schoolReportSummaryLine(state, activeChild))}<br>
     <b>Total record days:</b> ${totals.days} | <b>Full days:</b> ${totals.fullDays} | <b>Total problems:</b> ${totals.attempted} | <b>Total correct:</b> ${totals.correct}
     ${rewardMsg ? "<br><br>"+lrEscape(rewardMsg) : ""}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<div class="reportButtonRow">
      <button onclick="exportAttendanceCSV()">Export Attendance CSV</button>
      <button onclick="exportProblemLogCSV()">Export Problem Log CSV</button>
      <button onclick="exportReportJSON()">Export Full JSON</button>
      <button onclick="window.print()">Print / Save as PDF</button>
    </div>
    ${todaySchoolDayCard()}
    <h3>Daily Parent Note</h3>
    <textarea id="reportNoteBox" class="reportNoteBox" placeholder="Add a note for today's record...">${lrEscape(note)}</textarea>
    <button onclick="saveDailyReportNote()">Save Note</button>
    <h3>Attendance Rewards</h3>
    ${reportRewardStatusHtml()}
    <h3>Attendance History</h3>
    ${reportHistoryTable(state, activeChild)}
    <h3>Subject Totals</h3>
    ${reportSubjectTotalsTable(state, activeChild)}
    <h3>Recent Problems Today</h3>
    ${recentProblemLogTable(state, activeChild)}`;
}
/* End Game Fun Pack 7 */


/* Game Fun Pack 8: Classroom Schedule & Focus Blocks */
function classroomScheduleConfig(){
 return window.LR_CLASSROOM_SCHEDULE_CONFIG || {dailyMinutes:360,blocks:[],dailyCompletionReward:{title:"Full Schedule Clear",reward:{}}};
}

function ensureClassroomScheduleFor(profile, child){
 if(!profile.classroomSchedule) profile.classroomSchedule = {};
 if(!profile.classroomSchedule[child]){
   profile.classroomSchedule[child] = {
     daily:{}
   };
 }
 const c = profile.classroomSchedule[child];
 if(!c.daily) c.daily = {};
 return c;
}

function ensureClassroomSchedule(){
 return ensureClassroomScheduleFor(state, activeChild);
}

function classroomScheduleDay(profile, child, dateKey){
 const c = ensureClassroomScheduleFor(profile || state, child || activeChild);
 const key = dateKey || localDateKey();
 if(!c.daily[key]){
   c.daily[key] = {
     activeBlockId:"",
     claimedBlocks:{},
     fullRewardClaimed:false,
     focusHits:{}
   };
 }
 if(!c.daily[key].claimedBlocks) c.daily[key].claimedBlocks = {};
 if(!c.daily[key].focusHits) c.daily[key].focusHits = {};
 return c.daily[key];
}

function classroomBlocksFor(child){
 const cfg = classroomScheduleConfig();
 return (cfg.blocks || []).map(b=>Object.assign({}, b));
}

function blockTargetCorrect(block, child){
 if(typeof block.targetCorrect === "number") return block.targetCorrect;
 if(block.targetCorrect && block.targetCorrect[child] !== undefined) return block.targetCorrect[child];
 return 5;
}

function blockSubjectList(block){
 if(block.subjects === "any") return assignmentSubjectsFor(activeChild);
 return Array.isArray(block.subjects) ? block.subjects : [];
}

function blockMatchesSubject(block, subj){
 if(!block || !subj) return false;
 if(block.subjects === "any") return true;
 return (block.subjects || []).includes(subj);
}

function blockSubjectDisplay(block){
 if(block.subjects === "any") return "Any loaded subject";
 return (block.subjects || []).join(", ");
}

function blockProgress(block, profile, child, dateKey){
 const p = profile || state;
 const c = child || activeChild;
 const rec = ensureAttendanceFor(p, c, dateKey || localDateKey());
 const subjects = block.subjects === "any" ? Object.keys(rec.answers || {}) : (block.subjects || []);
 let attempted = 0;
 let correct = 0;
 let wrong = 0;
 let bossAttempts = 0;
 subjects.forEach(s=>{
   const a = rec.answers && rec.answers[s] ? rec.answers[s] : null;
   if(!a) return;
   attempted += a.attempted || 0;
   correct += a.correct || 0;
   wrong += a.wrong || 0;
   bossAttempts += a.bossAttempts || 0;
 });
 const targetCorrect = blockTargetCorrect(block, c);
 const bossReady = block.targetBossAttempts ? bossAttempts >= block.targetBossAttempts : false;
 const correctReady = correct >= targetCorrect;
 const complete = block.targetBossAttempts ? (correctReady || bossReady) : correctReady;
 return {attempted,correct,wrong,bossAttempts,targetCorrect,complete};
}

function classroomActiveBlock(){
 const day = classroomScheduleDay(state, activeChild);
 return classroomBlocksFor(activeChild).find(b=>b.id === day.activeBlockId) || null;
}

function startClassroomBlock(id){
 const day = classroomScheduleDay(state, activeChild);
 const block = classroomBlocksFor(activeChild).find(b=>b.id === id);
 if(!block){ $("feedback").textContent = "Classroom block not found."; return; }
 day.activeBlockId = id;
 save();
 $("feedback").textContent = "Focus block started: " + block.title + ".";
 openClassroomSchedule();
}

function clearClassroomBlock(){
 const day = classroomScheduleDay(state, activeChild);
 day.activeBlockId = "";
 save();
 $("feedback").textContent = "Focus block cleared.";
 openClassroomSchedule();
}

function recordClassroomFocusAnswer(subj){
 const cfg = classroomScheduleConfig();
 const day = classroomScheduleDay(state, activeChild);
 const block = classroomActiveBlock();
 if(!block || !blockMatchesSubject(block, subj)) return "";
 const key = localDateKey() + "_" + block.id + "_" + subj + "_" + ((ensureAttendanceFor(state, activeChild, localDateKey()).answers[subj] || {}).correct || 0);
 if(day.focusHits[key]) return "";
 day.focusHits[key] = true;
 const fb = cfg.focusBonus || {};
 let text = " Focus block progress.";
 if(fb.sparks){
   state.sparks = (state.sparks || 0) + fb.sparks;
   text += " +" + fb.sparks + " Spark.";
 }
 if(fb.companionXp && typeof addCompanionXP === "function"){
   text += addCompanionXP(fb.companionXp, "classroom focus", subj);
 }
 if(fb.masteryXp && typeof addSubjectMasteryXP === "function"){
   text += addSubjectMasteryXP(subj, fb.masteryXp, "classroomFocus");
 }
 return text;
}

function claimClassroomBlock(id){
 const blocks = classroomBlocksFor(activeChild);
 const block = blocks.find(b=>b.id === id);
 const day = classroomScheduleDay(state, activeChild);
 if(!block){ $("feedback").textContent = "Classroom block not found."; return; }
 const prog = blockProgress(block, state, activeChild, localDateKey());
 if(!prog.complete){ $("feedback").textContent = "Block is not complete yet."; return; }
 if(day.claimedBlocks[id]){ $("feedback").textContent = "Block reward already claimed today."; return; }
 day.claimedBlocks[id] = true;
 const msg = grantGameFunReward(block.reward, "classroom block");
 addMemory("Classroom Block Complete", activeChild + " completed " + block.title + ". " + msg);
 $("feedback").textContent = "Classroom block claimed: " + block.title + ". " + msg;
 save();
 openClassroomSchedule();
 renderStats();
}

function allClassroomBlocksClaimed(){
 const blocks = classroomBlocksFor(activeChild);
 const day = classroomScheduleDay(state, activeChild);
 return blocks.length > 0 && blocks.every(b=>!!day.claimedBlocks[b.id]);
}

function claimClassroomFullSchedule(){
 const cfg = classroomScheduleConfig();
 const day = classroomScheduleDay(state, activeChild);
 if(!allClassroomBlocksClaimed()){
   $("feedback").textContent = "Claim each classroom block first.";
   return;
 }
 if(day.fullRewardClaimed){
   $("feedback").textContent = "Full schedule reward already claimed today.";
   return;
 }
 day.fullRewardClaimed = true;
 const def = cfg.dailyCompletionReward || {title:"Full Schedule Clear",reward:{}};
 const msg = grantGameFunReward(def.reward, "full classroom schedule");
 const col = ensureCollection();
 if(def.title && col.manualTitles && !col.manualTitles.includes(def.title)) col.manualTitles.push(def.title);
 addMemory("Full Classroom Schedule", activeChild + " completed the full classroom schedule. " + msg);
 $("feedback").textContent = "Full schedule reward claimed: " + msg;
 save();
 openClassroomSchedule();
 renderStats();
}

function classroomBlockCard(block){
 const day = classroomScheduleDay(state, activeChild);
 const prog = blockProgress(block, state, activeChild, localDateKey());
 const pct = Math.min(100, Math.round((prog.correct / Math.max(1, prog.targetCorrect)) * 100));
 const active = day.activeBlockId === block.id;
 const claimed = !!day.claimedBlocks[block.id];
 const ready = prog.complete;
 const hints = classroomScheduleConfig().subjectTravelHints || {};
 const subjectHints = block.subjects === "any" ? "Use any realm that has lessons." : (block.subjects || []).map(s=>hints[s] || s).join(" ");
 const claimButton = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimClassroomBlock('${block.id}')">Claim Block Reward</button>` : "<button disabled>In Progress</button>";
 const focusButton = active ? `<button onclick="clearClassroomBlock()">Clear Focus</button>` : `<button onclick="startClassroomBlock('${block.id}')">Start Focus Block</button>`;
 return `<div class="classBlock ${active ? "classBlockActive" : ""} ${ready ? "collectionReady" : ""}">
   <div class="classBlockHeader"><span>${active ? "🎯" : "📚"}</span><b>${lrEscape(block.title)}</b><span>${block.minutes || 0} min</span></div>
   <div class="collectionDesc">${lrEscape(block.theme || "")}</div>
   <div><b>Subjects:</b> ${lrEscape(blockSubjectDisplay(block))}</div>
   <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
   <div class="questMeta">Correct: ${prog.correct} / ${prog.targetCorrect} | Attempted: ${prog.attempted} | Boss attempts: ${prog.bossAttempts}${block.targetBossAttempts ? " / " + block.targetBossAttempts : ""}</div>
   <div class="questMeta"><b>Travel hint:</b> ${lrEscape(subjectHints)}</div>
   <div class="classBlockButtons">${focusButton}${claimButton}</div>
 </div>`;
}

function classroomScheduleSummaryLine(profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const blocks = classroomBlocksFor(c);
 const day = classroomScheduleDay(p, c, localDateKey());
 const done = blocks.filter(b=>!!day.claimedBlocks[b.id]).length;
 const today = reportDateSummary(p, c, localDateKey());
 return `${done} / ${blocks.length} class blocks claimed today, ${formatMinutes(today.activeSeconds)} active learning`;
}

function classroomSchedulePrintSummary(){
 const blocks = classroomBlocksFor(activeChild);
 return `<table class="reportTable">
   <thead><tr><th>Block</th><th>Minutes</th><th>Subjects</th><th>Target</th><th>Status</th></tr></thead>
   <tbody>
     ${blocks.map(b=>{
       const p = blockProgress(b, state, activeChild, localDateKey());
       const claimed = classroomScheduleDay(state, activeChild).claimedBlocks[b.id];
       return `<tr><td>${lrEscape(b.title)}</td><td>${b.minutes || 0}</td><td>${lrEscape(blockSubjectDisplay(b))}</td><td>${p.correct} / ${p.targetCorrect}</td><td>${claimed ? "Claimed" : p.complete ? "Ready" : "In Progress"}</td></tr>`;
     }).join("")}
   </tbody>
 </table>`;
}

function openClassroomSchedule(){
 attendanceTick(true);
 const cfg = classroomScheduleConfig();
 const blocks = classroomBlocksFor(activeChild);
 const day = classroomScheduleDay(state, activeChild);
 const active = classroomActiveBlock();
 const totalMinutes = blocks.reduce((sum,b)=>sum+(b.minutes || 0),0);
 const today = reportDateSummary(state, activeChild, localDateKey());
 const timePct = Math.min(100, Math.round((today.activeSeconds / Math.max(1, (cfg.dailyMinutes || 360) * 60)) * 100));

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Classroom Schedule";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🏫 ${lrEscape(activeChild)}'s Classroom Schedule</div>
   <div class="lessonCardText">
     ${lrEscape(classroomScheduleSummaryLine(state, activeChild))}<br>
     <b>Daily target:</b> ${cfg.dailyMinutes || 360} minutes | <b>Scheduled blocks:</b> ${totalMinutes} minutes<br>
     <b>Current focus:</b> ${active ? lrEscape(active.title) : "None selected"}
     <div class="reportTrack"><div class="reportFill" style="width:${timePct}%"></div></div>
     <small>${formatMinutes(today.activeSeconds)} / ${formatMinutes((cfg.dailyMinutes || 360) * 60)} active learning time</small>
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<div class="reportButtonRow">
      <button onclick="claimClassroomFullSchedule()" ${allClassroomBlocksClaimed() && !day.fullRewardClaimed ? "" : "disabled"}>Claim Full Schedule Reward</button>
      <button onclick="window.print()">Print Schedule / Save PDF</button>
      <button onclick="openReportCenter()">Open Report Center</button>
    </div>
    <h3>Today's Focus Blocks</h3>
    ${blocks.map(classroomBlockCard).join("")}
    <h3>Printable Schedule Summary</h3>
    ${classroomSchedulePrintSummary()}
    <h3>Regular Daily Plan</h3>
    ${dailyPlanHtml(activeChild)}
    <h3>Today's Problem Log</h3>
    ${recentProblemLogTable(state, activeChild)}`;
}
/* End Game Fun Pack 8 */


/* Game Fun Pack 9: Story Campaign Quest Chains */
function storyCampaignConfig(){
 return window.LR_STORY_CAMPAIGN_CONFIG || {chains:[]};
}

function ensureStoryCampaignsFor(profile, child){
 if(!profile.storyCampaigns) profile.storyCampaigns = {};
 if(!profile.storyCampaigns[child]){
   profile.storyCampaigns[child] = {
     activeChainId:"",
     claimedStages:{},
     claimedChains:{}
   };
 }
 const s = profile.storyCampaigns[child];
 if(!s.claimedStages) s.claimedStages = {};
 if(!s.claimedChains) s.claimedChains = {};
 return s;
}

function ensureStoryCampaigns(){
 return ensureStoryCampaignsFor(state, activeChild);
}

function storyChainById(id){
 return (storyCampaignConfig().chains || []).find(c=>c.id === id) || null;
}

function storyStageKey(chainId, stageId){
 return chainId + "::" + stageId;
}

function storySubjectCorrectTotal(profile, child, subjects){
 const p = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 const list = subjects && subjects.length ? subjects : Object.keys(p);
 return list.reduce((sum,s)=>sum+(p[s] || 0),0);
}

function storyClassBlocksClaimedToday(profile, child){
 const day = classroomScheduleDay(profile || state, child || activeChild, localDateKey());
 return Object.keys(day.claimedBlocks || {}).filter(k=>day.claimedBlocks[k]).length;
}

function storyMasteryRankSubjectsAt(profile, child, rank){
 const m = ensureMasteryFor(profile || state, child || activeChild);
 return Object.values(m.subjects || {}).filter(s=>(s.rank || 1) >= (rank || 1)).length;
}

function storyStageProgress(stage, profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const gf = ensureGameFunFor(p, c);
 const totals = gf.totals || {};
 const rec = ensureAttendanceFor(p, c, localDateKey());
 const random = ensureRandomEventsFor(p, c);
 const companion = ensureCompanionTrainingFor(p, c);

 switch(stage.metric){
   case "totalAnswers":
     return totals.answers || 0;
   case "totalCorrectInSubjects":
     return storySubjectCorrectTotal(p, c, stage.subjects || []);
   case "dailyCorrectInSubjects": {
     const subjects = stage.subjects || Object.keys(rec.answers || {});
     return subjects.reduce((sum,s)=>sum+(((rec.answers || {})[s] || {}).correct || 0),0);
   }
   case "roomsVisitedTotal":
     return totals.roomVisits || p.room || 0;
   case "subjectsStarted":
     return subjectsWithCorrect(p, c).length;
   case "bossAttemptsTotal":
     return totals.bossAttempts || 0;
   case "bossCleared":
     return ((p.bossWins && p.bossWins[c] && p.bossWins[c][stage.subject]) ? 1 : 0);
   case "activeMinutesToday":
     return Math.round((rec.activeSeconds || 0) / 60);
   case "classBlocksClaimedToday":
     return storyClassBlocksClaimedToday(p, c);
   case "mapScraps":
     return random.mapScraps || 0;
   case "eventTotal":
     return random.totalEvents || 0;
   case "companionLevel":
     return companion.level || 1;
   case "companionBond":
     return companion.bond || 0;
   case "companionSubjectDiscoveries":
     return Object.keys(companion.subjectDiscoveries || {}).length;
   case "masteryRankSubjectsAt":
     return storyMasteryRankSubjectsAt(p, c, stage.rank || 1);
   case "collectionItems":
     return allHomeItemNames(p, c).length;
   default:
     return 0;
 }
}

function storyStageComplete(stage, profile, child){
 return storyStageProgress(stage, profile || state, child || activeChild) >= (stage.target || 1);
}

function storyChainStagesComplete(chain, profile, child){
 return (chain.stages || []).every(st=>storyStageComplete(st, profile || state, child || activeChild));
}

function storyChainProgress(chain, profile, child){
 const stages = chain.stages || [];
 const done = stages.filter(st=>storyStageComplete(st, profile || state, child || activeChild)).length;
 return {done,total:stages.length};
}

function storyActiveChain(){
 const s = ensureStoryCampaigns();
 return storyChainById(s.activeChainId) || (storyCampaignConfig().chains || [])[0] || null;
}

function setActiveStoryCampaign(id){
 const s = ensureStoryCampaigns();
 const chain = storyChainById(id);
 if(!chain){ $("feedback").textContent = "Story campaign not found."; return; }
 s.activeChainId = id;
 save();
 $("feedback").textContent = "Active story campaign: " + chain.title + ".";
 openStoryCampaigns();
 renderStats();
}

function claimStoryStage(chainId, stageId){
 const chain = storyChainById(chainId);
 const stage = chain ? (chain.stages || []).find(st=>st.id === stageId) : null;
 const s = ensureStoryCampaigns();
 if(!chain || !stage){ $("feedback").textContent = "Campaign stage not found."; return; }
 const key = storyStageKey(chainId, stageId);
 if(!storyStageComplete(stage, state, activeChild)){ $("feedback").textContent = "That story stage is not complete yet."; return; }
 if(s.claimedStages[key]){ $("feedback").textContent = "Stage reward already claimed."; return; }
 s.claimedStages[key] = true;
 const msg = grantGameFunReward(stage.reward, "story campaign stage");
 addMemory("Story Campaign Stage", activeChild + " completed " + chain.title + " — " + stage.title + ". " + msg);
 $("feedback").textContent = "Stage reward claimed: " + stage.title + ". " + msg;
 save();
 openStoryCampaigns();
 renderStats();
}

function claimStoryChain(chainId){
 const chain = storyChainById(chainId);
 const s = ensureStoryCampaigns();
 if(!chain){ $("feedback").textContent = "Campaign not found."; return; }
 if(!storyChainStagesComplete(chain, state, activeChild)){ $("feedback").textContent = "Finish every stage first."; return; }
 if(s.claimedChains[chainId]){ $("feedback").textContent = "Campaign completion reward already claimed."; return; }
 s.claimedChains[chainId] = true;
 const msg = grantGameFunReward(chain.completionReward, "story campaign completion");
 const col = ensureCollection();
 if(chain.finalTitle && col.manualTitles && !col.manualTitles.includes(chain.finalTitle)) col.manualTitles.push(chain.finalTitle);
 addMemory("Story Campaign Complete", activeChild + " completed " + chain.title + ". " + msg);
 $("feedback").textContent = "Campaign complete: " + chain.title + ". " + msg;
 save();
 openStoryCampaigns();
 renderStats();
}

function storyStageCardHtml(chain, stage){
 const s = ensureStoryCampaigns();
 const progress = storyStageProgress(stage, state, activeChild);
 const target = stage.target || 1;
 const pct = Math.min(100, Math.round((progress / target) * 100));
 const complete = progress >= target;
 const key = storyStageKey(chain.id, stage.id);
 const claimed = !!s.claimedStages[key];
 const button = claimed ? "<button disabled>Claimed</button>" : complete ? `<button onclick="claimStoryStage('${chain.id}','${stage.id}')">Claim Stage Reward</button>` : "<button disabled>In Progress</button>";

 return `<div class="storyStage ${complete ? "collectionReady" : ""}">
   <div class="storyStageHeader"><b>${complete && !claimed ? "⭐ " : ""}${lrEscape(stage.title)}</b><span>${progress} / ${target}</span></div>
   <div class="collectionDesc">${lrEscape(stage.text || "")}</div>
   <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
   <div class="questMeta">Reward: ${lrEscape(rewardTextFor(stage.reward))}</div>
   ${button}
 </div>`;
}

function storyCampaignCardHtml(chain){
 const s = ensureStoryCampaigns();
 const prog = storyChainProgress(chain, state, activeChild);
 const pct = Math.min(100, Math.round((prog.done / Math.max(1, prog.total)) * 100));
 const active = s.activeChainId === chain.id || (!s.activeChainId && chain === (storyCampaignConfig().chains || [])[0]);
 const complete = storyChainStagesComplete(chain, state, activeChild);
 const claimed = !!s.claimedChains[chain.id];
 const claimButton = claimed ? "<button disabled>Campaign Claimed</button>" : complete ? `<button onclick="claimStoryChain('${chain.id}')">Claim Campaign Reward</button>` : "<button disabled>Campaign In Progress</button>";

 return `<div class="storyCampaign ${active ? "storyCampaignActive" : ""}">
   <div class="storyCampaignHeader"><span>${chain.icon || "📜"}</span><b>${lrEscape(chain.title)}</b><span>${prog.done} / ${prog.total}</span></div>
   <div class="collectionDesc">${lrEscape(chain.intro || "")}</div>
   <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
   <div class="reportButtonRow">
     <button onclick="setActiveStoryCampaign('${chain.id}')" ${active ? "disabled" : ""}>${active ? "Active Campaign" : "Set Active"}</button>
     ${claimButton}
   </div>
   <div class="questMeta"><b>Completion reward:</b> ${lrEscape(rewardTextFor(chain.completionReward))}${chain.finalTitle ? " | Title: " + lrEscape(chain.finalTitle) : ""}</div>
   <div class="storyStageList">${(chain.stages || []).map(st=>storyStageCardHtml(chain,st)).join("")}</div>
 </div>`;
}

function storyCampaignSummaryLine(profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const sc = ensureStoryCampaignsFor(p, c);
 const chains = storyCampaignConfig().chains || [];
 const active = storyChainById(sc.activeChainId) || chains[0];
 const completedChains = chains.filter(ch=>!!sc.claimedChains[ch.id]).length;
 if(!active) return "No story campaigns loaded.";
 const prog = storyChainProgress(active, p, c);
 return `Active: ${active.title} (${prog.done}/${prog.total} stages). Completed campaigns: ${completedChains}/${chains.length}`;
}

function openStoryCampaigns(){
 attendanceTick(true);
 const cfg = storyCampaignConfig();
 const chains = cfg.chains || [];
 const s = ensureStoryCampaigns();
 if(!s.activeChainId && chains[0]) s.activeChainId = chains[0].id;
 const active = storyActiveChain();

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Story Campaigns";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">📜 Story Campaign Quest Chains</div>
   <div class="lessonCardText">
     ${lrEscape(storyCampaignSummaryLine(state, activeChild))}<br>
     ${active ? "<b>Current guidance:</b> " + lrEscape(active.intro || "") : ""}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<h3>Campaign Quest Chains</h3>
    ${chains.map(storyCampaignCardHtml).join("")}`;
}
/* End Game Fun Pack 9 */


/* Game Fun Pack 10: Adaptive Review & Weak Skill Rescue */
function adaptiveReviewConfig(){
 return window.LR_ADAPTIVE_REVIEW_CONFIG || {missions:[],reviewQueueMissions:[],streakRewards:[],completionTitles:[],messages:{}};
}

function ensureAdaptiveReviewFor(profile, child){
 if(!profile.adaptiveReview) profile.adaptiveReview = {};
 if(!profile.adaptiveReview[child]){
   profile.adaptiveReview[child] = {
     activeSubject:"",
     rescue:{},
     reviewQueueCorrect:0,
     rescueStreak:0,
     bestRescueStreak:0,
     totalRescueCorrect:0,
     totalRescueWrong:0,
     claimedMissions:{},
     claimedQueueMissions:{},
     claimedStreakRewards:{},
     claimedTitles:{},
     currentMode:"",
     currentReviewQueueIndex:-1
   };
 }
 const a = profile.adaptiveReview[child];
 if(!a.rescue) a.rescue = {};
 if(!a.claimedMissions) a.claimedMissions = {};
 if(!a.claimedQueueMissions) a.claimedQueueMissions = {};
 if(!a.claimedStreakRewards) a.claimedStreakRewards = {};
 if(!a.claimedTitles) a.claimedTitles = {};
 return a;
}

function ensureAdaptiveReview(){
 return ensureAdaptiveReviewFor(state, activeChild);
}

function adaptiveSubjectStats(profile, child, subj){
 const totals = subjectTotalsForReport(profile || state, child || activeChild);
 const t = totals[subj] || {attempted:0,correct:0,wrong:0,bossAttempts:0,bossWins:0};
 const attempted = t.attempted || 0;
 const correct = t.correct || 0;
 const wrong = t.wrong || 0;
 const accuracy = attempted ? Math.round((correct / attempted) * 100) : 0;
 const last = lastSubjectPracticeDate(profile || state, child || activeChild, subj);
 const stale = subjectIsStale(profile || state, child || activeChild, subj);
 return {attempted,correct,wrong,accuracy,lastPractice:last,stale,bossAttempts:t.bossAttempts||0,bossWins:t.bossWins||0};
}

function allAdaptiveSubjects(child){
 const subjects = Object.keys(LESSONS[child || activeChild] || {}).sort();
 return subjects;
}

function lastSubjectPracticeDate(profile, child, subj){
 const dates = attendanceDates(profile || state).sort();
 let last = "";
 dates.forEach(date=>{
   const rec = ensureAttendanceFor(profile || state, child || activeChild, date);
   const a = rec.answers && rec.answers[subj];
   if(a && (a.attempted || 0) > 0) last = date;
 });
 return last;
}

function daysSinceDateKey(dateKey){
 if(!dateKey) return 9999;
 const today = new Date(localDateKey() + "T00:00:00");
 const then = new Date(dateKey + "T00:00:00");
 const diff = Math.round((today - then) / 86400000);
 return isNaN(diff) ? 9999 : diff;
}

function subjectIsStale(profile, child, subj){
 const cfg = adaptiveReviewConfig();
 const last = lastSubjectPracticeDate(profile || state, child || activeChild, subj);
 return daysSinceDateKey(last) >= (cfg.staleDays || 3);
}

function adaptiveSubjectStatus(subj){
 const cfg = adaptiveReviewConfig();
 const s = adaptiveSubjectStats(state, activeChild, subj);
 if(s.attempted < (cfg.weakMinimumAttempts || 5)){
   return {kind:"new",label:"Needs Data",message:(cfg.messages||{}).noData || "Not enough records yet."};
 }
 if(s.accuracy < (cfg.weakAccuracyThreshold || 70)){
   return {kind:"weak",label:"Weak Spot",message:(cfg.messages||{}).weak || "This subject may need attention."};
 }
 if(s.stale){
   return {kind:"stale",label:"Stale",message:(cfg.messages||{}).stale || "This subject has not been practiced recently."};
 }
 return {kind:"strong",label:"Stable",message:(cfg.messages||{}).strong || "This subject looks stable."};
}

function adaptiveRecommendedSubjects(){
 const subjects = allAdaptiveSubjects(activeChild);
 return subjects.map(s=>{
   const stats = adaptiveSubjectStats(state, activeChild, s);
   const status = adaptiveSubjectStatus(s);
   let score = 0;
   if(status.kind === "weak") score += 100;
   if(status.kind === "stale") score += 50;
   score += Math.max(0, 100 - stats.accuracy);
   score += stats.wrong * 2;
   if(stats.attempted < 5) score += 20;
   return {subject:s,score,stats,status};
 }).sort((a,b)=>b.score-a.score);
}

function adaptiveActiveSubject(){
 const a = ensureAdaptiveReview();
 if(a.activeSubject) return a.activeSubject;
 const rec = adaptiveRecommendedSubjects()[0];
 return rec ? rec.subject : "";
}

function setAdaptiveSubject(subj){
 const a = ensureAdaptiveReview();
 if(!allAdaptiveSubjects(activeChild).includes(subj)){
   $("feedback").textContent = "Subject not available for this student.";
   return;
 }
 a.activeSubject = subj;
 a.currentMode = "subject";
 a.currentReviewQueueIndex = -1;
 if(!a.rescue[subj]) a.rescue[subj] = {correct:0,wrong:0};
 save();
 $("feedback").textContent = "Adaptive rescue subject set to " + subj + ".";
 openAdaptiveReview();
}

function clearAdaptiveSubject(){
 const a = ensureAdaptiveReview();
 a.activeSubject = "";
 a.currentMode = "";
 a.currentReviewQueueIndex = -1;
 save();
 $("feedback").textContent = "Adaptive rescue cleared.";
 openAdaptiveReview();
}

function adaptiveSubjectProgress(subj){
 const a = ensureAdaptiveReview();
 if(!a.rescue[subj]) a.rescue[subj] = {correct:0,wrong:0};
 return a.rescue[subj];
}

function adaptiveProgressBar(progress, target){
 const pct = Math.min(100, Math.round((progress / Math.max(1,target)) * 100));
 return `<div class="adaptiveTrack"><div class="adaptiveFill" style="width:${pct}%"></div></div>`;
}

function claimAdaptiveMission(subj, missionId){
 const cfg = adaptiveReviewConfig();
 const mission = (cfg.missions || []).find(m=>m.id === missionId);
 const a = ensureAdaptiveReview();
 if(!mission || !subj) return;
 const p = adaptiveSubjectProgress(subj);
 const key = subj + "::" + mission.id;
 if((p.correct || 0) < mission.targetCorrect){
   $("feedback").textContent = "Rescue mission is not complete yet.";
   return;
 }
 if(a.claimedMissions[key]){
   $("feedback").textContent = "Rescue mission already claimed.";
   return;
 }
 a.claimedMissions[key] = true;
 const msg = grantGameFunReward(mission.reward, "adaptive review rescue");
 addMemory("Adaptive Review Rescue", activeChild + " completed " + mission.title + " for " + subj + ". " + msg);
 $("feedback").textContent = "Rescue reward claimed: " + mission.title + ". " + msg;
 save();
 openAdaptiveReview();
 renderStats();
}

function claimAdaptiveQueueMission(missionId){
 const cfg = adaptiveReviewConfig();
 const mission = (cfg.reviewQueueMissions || []).find(m=>m.id === missionId);
 const a = ensureAdaptiveReview();
 if(!mission) return;
 if((a.reviewQueueCorrect || 0) < mission.targetCorrect){
   $("feedback").textContent = "Missed-question mission is not complete yet.";
   return;
 }
 if(a.claimedQueueMissions[mission.id]){
   $("feedback").textContent = "Missed-question mission already claimed.";
   return;
 }
 a.claimedQueueMissions[mission.id] = true;
 const msg = grantGameFunReward(mission.reward, "missed-question review");
 addMemory("Missed Question Review", activeChild + " completed " + mission.title + ". " + msg);
 $("feedback").textContent = "Missed-question reward claimed: " + mission.title + ". " + msg;
 save();
 openAdaptiveReview();
 renderStats();
}

function claimAdaptiveStreakReward(id){
 const cfg = adaptiveReviewConfig();
 const reward = (cfg.streakRewards || []).find(r=>r.id === id);
 const a = ensureAdaptiveReview();
 if(!reward) return;
 if((a.bestRescueStreak || 0) < reward.target){
   $("feedback").textContent = "Review streak reward is not ready yet.";
   return;
 }
 if(a.claimedStreakRewards[reward.id]){
   $("feedback").textContent = "Review streak reward already claimed.";
   return;
 }
 a.claimedStreakRewards[reward.id] = true;
 const msg = grantGameFunReward(reward.reward, "adaptive review streak");
 addMemory("Adaptive Review Streak", activeChild + " earned " + reward.title + ". " + msg);
 $("feedback").textContent = "Review streak reward claimed: " + reward.title + ". " + msg;
 save();
 openAdaptiveReview();
 renderStats();
}

function checkAdaptiveTitles(){
 const cfg = adaptiveReviewConfig();
 const a = ensureAdaptiveReview();
 const col = ensureCollection();
 let out = "";
 (cfg.completionTitles || []).forEach(t=>{
   const id = "correct_" + t.correct;
   if((a.totalRescueCorrect || 0) >= t.correct && !a.claimedTitles[id]){
     a.claimedTitles[id] = true;
     if(col.manualTitles && !col.manualTitles.includes(t.title)) col.manualTitles.push(t.title);
     out += " Title unlocked: " + t.title + ".";
     addMemory("Adaptive Review Title", activeChild + " unlocked " + t.title + ".");
   }
 });
 return out;
}

function recordAdaptiveReviewAnswer(subj, correct){
 const a = ensureAdaptiveReview();
 const active = adaptiveActiveSubject();
 let text = "";
 if(correct){
   a.totalRescueCorrect = (a.totalRescueCorrect || 0) + 1;
   a.rescueStreak = (a.rescueStreak || 0) + 1;
   a.bestRescueStreak = Math.max(a.bestRescueStreak || 0, a.rescueStreak || 0);
   if(subj === active){
     const p = adaptiveSubjectProgress(subj);
     p.correct = (p.correct || 0) + 1;
     text += " Adaptive rescue +1 for " + subj + ".";
   }
   if(a.currentMode === "queue"){
     a.reviewQueueCorrect = (a.reviewQueueCorrect || 0) + 1;
     if(typeof a.currentReviewQueueIndex === "number" && a.currentReviewQueueIndex >= 0 && state.reviewQueue && state.reviewQueue[a.currentReviewQueueIndex]){
       state.reviewQueue.splice(a.currentReviewQueueIndex,1);
       a.currentReviewQueueIndex = -1;
       text += " Missed question repaired.";
     }
   }
   text += checkAdaptiveTitles();
 }else{
   a.totalRescueWrong = (a.totalRescueWrong || 0) + 1;
   a.rescueStreak = 0;
   if(subj === active){
     const p = adaptiveSubjectProgress(subj);
     p.wrong = (p.wrong || 0) + 1;
   }
 }
 return text;
}

function adaptiveMissionHtml(subj){
 const cfg = adaptiveReviewConfig();
 const a = ensureAdaptiveReview();
 const p = adaptiveSubjectProgress(subj);
 return (cfg.missions || []).map(m=>{
   const progress = p.correct || 0;
   const ready = progress >= m.targetCorrect;
   const key = subj + "::" + m.id;
   const claimed = !!a.claimedMissions[key];
   const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimAdaptiveMission('${subj}','${m.id}')">Claim Rescue Reward</button>` : "<button disabled>In Progress</button>";
   return `<div class="adaptiveCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🛟</span><b>${lrEscape(m.title)}</b><span>${progress} / ${m.targetCorrect}</span></div>
     ${adaptiveProgressBar(progress,m.targetCorrect)}
     <div class="collectionDesc">Reward: ${lrEscape(rewardTextFor(m.reward))}</div>
     ${btn}
   </div>`;
 }).join("");
}

function adaptiveQueueMissionHtml(){
 const cfg = adaptiveReviewConfig();
 const a = ensureAdaptiveReview();
 return (cfg.reviewQueueMissions || []).map(m=>{
   const progress = a.reviewQueueCorrect || 0;
   const ready = progress >= m.targetCorrect;
   const claimed = !!a.claimedQueueMissions[m.id];
   const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimAdaptiveQueueMission('${m.id}')">Claim Missed-Question Reward</button>` : "<button disabled>In Progress</button>";
   return `<div class="adaptiveCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🧰</span><b>${lrEscape(m.title)}</b><span>${progress} / ${m.targetCorrect}</span></div>
     ${adaptiveProgressBar(progress,m.targetCorrect)}
     <div class="collectionDesc">Reward: ${lrEscape(rewardTextFor(m.reward))}</div>
     ${btn}
   </div>`;
 }).join("");
}

function adaptiveStreakHtml(){
 const cfg = adaptiveReviewConfig();
 const a = ensureAdaptiveReview();
 return (cfg.streakRewards || []).map(r=>{
   const progress = a.bestRescueStreak || 0;
   const ready = progress >= r.target;
   const claimed = !!a.claimedStreakRewards[r.id];
   const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimAdaptiveStreakReward('${r.id}')">Claim Streak Reward</button>` : "<button disabled>Locked</button>";
   return `<div class="adaptiveCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🔥</span><b>${lrEscape(r.title)}</b><span>${progress} / ${r.target}</span></div>
     ${adaptiveProgressBar(progress,r.target)}
     <div class="collectionDesc">Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
     ${btn}
   </div>`;
 }).join("");
}

function adaptiveSubjectCard(item){
 const s = item.subject;
 const stats = item.stats;
 const status = item.status;
 const active = adaptiveActiveSubject() === s;
 const cls = status.kind === "weak" ? "adaptiveWeak" : status.kind === "stale" ? "adaptiveStale" : "adaptiveStable";
 return `<div class="adaptiveSubject ${cls} ${active ? "adaptiveActive" : ""}">
   <div class="collectionHeader"><span>${active ? "🎯" : "📌"}</span><b>${lrEscape(s)}</b><span>${lrEscape(status.label)}</span></div>
   <div class="collectionDesc">${lrEscape(status.message)}</div>
   <div class="reportGrid">
     <div><b>Accuracy</b><br>${stats.attempted ? stats.accuracy + "%" : "No data"}</div>
     <div><b>Record</b><br>${stats.correct} correct / ${stats.wrong} wrong</div>
     <div><b>Last practiced</b><br>${stats.lastPractice || "Never"}</div>
     <div><b>Rescue</b><br>${(adaptiveSubjectProgress(s).correct || 0)} correct / ${(adaptiveSubjectProgress(s).wrong || 0)} wrong</div>
   </div>
   <button onclick="setAdaptiveSubject('${s}')">${active ? "Active Rescue Subject" : "Set as Rescue Subject"}</button>
 </div>`;
}

function startAdaptiveReviewLesson(){
 const a = ensureAdaptiveReview();
 const subj = adaptiveActiveSubject();
 if(!subj){
   $("feedback").textContent = "No subject available for adaptive review.";
   return;
 }

 let L = null;
 let idx = 0;
 a.currentMode = "subject";
 a.currentReviewQueueIndex = -1;

 if(state.reviewQueue && state.reviewQueue.length){
   const found = state.reviewQueue.findIndex(x=>x && (!x.subject || x.subject === subj || true));
   if(found >= 0){
     L = state.reviewQueue[found];
     a.currentMode = "queue";
     a.currentReviewQueueIndex = found;
   }
 }

 const list = ((LESSONS[activeChild] || {})[subj]) || [];
 if(!L && list.length){
   const prog = adaptiveSubjectProgress(subj);
   idx = ((prog.correct || 0) + (prog.wrong || 0)) % list.length;
   L = list[idx];
 }
 if(!L){
   $("feedback").textContent = "No lessons available for " + subj + ".";
   return;
 }
 if(!L.subject) L.subject = subj;

 $("lessonBox").classList.remove("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent = "Adaptive Review: " + subj;
 $("actionText").innerHTML = lessonIntroHtml(L, subj, idx, list.length || 1);

 $("questionText").innerHTML = `<div class="questionPrompt">${lrEscape(L.q)}</div>`;
 $("choices").innerHTML = L.c.map(ch=>`<button class="choice">${lrEscape(ch)}</button>`).join("");
 document.querySelectorAll(".choice").forEach(btn=>btn.onclick=()=>answer(btn.textContent,L,subj,idx,btn));
 $("feedback").textContent = a.currentMode === "queue" ? "Repairing a missed question." : "Targeted rescue practice started.";
 save();
}

function adaptiveSummaryLine(profile, child){
 const a = ensureAdaptiveReviewFor(profile || state, child || activeChild);
 const active = a.activeSubject || (adaptiveRecommendedSubjects()[0] ? adaptiveRecommendedSubjects()[0].subject : "");
 return `Active rescue: ${active || "none"}, ${a.totalRescueCorrect || 0} rescue correct, ${((profile || state).reviewQueue || []).length} missed questions queued`;
}

function openAdaptiveReview(){
 attendanceTick(true);
 const a = ensureAdaptiveReview();
 const recs = adaptiveRecommendedSubjects();
 const active = adaptiveActiveSubject();
 if(active && !a.activeSubject) a.activeSubject = active;
 const activeStats = active ? adaptiveSubjectStats(state, activeChild, active) : null;

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Adaptive Review Center";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🛟 Adaptive Review & Weak Skill Rescue</div>
   <div class="lessonCardText">
     ${lrEscape(adaptiveSummaryLine(state, activeChild))}<br>
     ${active ? "<b>Recommended focus:</b> " + lrEscape(active) + " (" + (activeStats && activeStats.attempted ? activeStats.accuracy + "% accuracy" : "needs data") + ")" : "No active subject yet."}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<div class="reportButtonRow">
      <button onclick="startAdaptiveReviewLesson()">Start Adaptive Review Lesson</button>
      <button onclick="clearAdaptiveSubject()">Clear Rescue Subject</button>
      <button onclick="openReportCenter()">Open Report Center</button>
    </div>
    <h3>Active Rescue Missions: ${lrEscape(active || "None")}</h3>
    ${active ? adaptiveMissionHtml(active) : "<p>No active rescue subject.</p>"}
    <h3>Missed-Question Repair</h3>
    <div class="collectionCard">Missed questions in queue: ${(state.reviewQueue || []).length}<br>Repaired in adaptive mode: ${a.reviewQueueCorrect || 0}</div>
    ${adaptiveQueueMissionHtml()}
    <h3>Review Streak Rewards</h3>
    ${adaptiveStreakHtml()}
    <h3>Recommended Subjects</h3>
    ${recs.map(adaptiveSubjectCard).join("")}`;
}
/* End Game Fun Pack 10 */


/* Game Fun Pack 11: Boss Gauntlets & Capstone Trials */
function bossGauntletConfig(){
 return window.LR_BOSS_GAUNTLET_CONFIG || {gauntlets:[]};
}

function ensureBossGauntletsFor(profile, child){
 if(!profile.bossGauntlets) profile.bossGauntlets = {};
 if(!profile.bossGauntlets[child]){
   profile.bossGauntlets[child] = {
     activeGauntletId:"",
     claimedStages:{},
     claimedGauntlets:{}
   };
 }
 const g = profile.bossGauntlets[child];
 if(!g.claimedStages) g.claimedStages = {};
 if(!g.claimedGauntlets) g.claimedGauntlets = {};
 return g;
}

function ensureBossGauntlets(){
 return ensureBossGauntletsFor(state, activeChild);
}

function bossGauntletById(id){
 return (bossGauntletConfig().gauntlets || []).find(g=>g.id === id) || null;
}

function bossGauntletStageKey(gauntletId, stageId){
 return gauntletId + "::" + stageId;
}

function bossClearsTotal(profile, child){
 const wins = (profile.bossWins && profile.bossWins[child]) ? profile.bossWins[child] : {};
 return Object.keys(wins).filter(s=>!!wins[s]).length;
}

function bossClearsInSubjects(profile, child, subjects){
 const wins = (profile.bossWins && profile.bossWins[child]) ? profile.bossWins[child] : {};
 return (subjects || []).filter(s=>!!wins[s]).length;
}

function subjectsStartedInSet(profile, child, subjects){
 const started = subjectsWithCorrect(profile || state, child || activeChild);
 return (subjects || []).filter(s=>started.includes(s)).length;
}

function allSubjectsAtCorrect(profile, child, subjects, target){
 const p = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 return (subjects || []).filter(s=>(p[s] || 0) >= (target || 1)).length;
}

function subjectsCorrectTodayCount(profile, child){
 const rec = ensureAttendanceFor(profile || state, child || activeChild, localDateKey());
 return Object.keys(rec.answers || {}).filter(s=>((rec.answers[s] || {}).correct || 0) > 0).length;
}

function storyCampaignsCompleted(profile, child){
 const sc = ensureStoryCampaignsFor(profile || state, child || activeChild);
 return Object.keys(sc.claimedChains || {}).filter(id=>!!sc.claimedChains[id]).length;
}

function bossGauntletStageProgress(stage, profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const gf = ensureGameFunFor(p, c);
 const totals = gf.totals || {};
 const rec = ensureAttendanceFor(p, c, localDateKey());
 const random = ensureRandomEventsFor(p, c);
 const companion = ensureCompanionTrainingFor(p, c);
 const adaptive = ensureAdaptiveReviewFor(p, c);

 switch(stage.metric){
   case "totalAnswers":
     return totals.answers || 0;
   case "roomsVisitedTotal":
     return totals.roomVisits || p.room || 0;
   case "subjectsStarted":
     return subjectsWithCorrect(p, c).length;
   case "subjectsStartedInSet":
     return subjectsStartedInSet(p, c, stage.subjects || []);
   case "subjectCorrect": {
     const prog = (p.progress && p.progress[c]) ? p.progress[c] : {};
     return prog[stage.subject] || 0;
   }
   case "allSubjectsAtCorrect":
     return allSubjectsAtCorrect(p, c, stage.subjects || [], stage.target || 1);
   case "bossClearsTotal":
     return bossClearsTotal(p, c);
   case "bossClearsInSubjects":
     return bossClearsInSubjects(p, c, stage.subjects || []);
   case "masteryRankSubjectsAt":
     return storyMasteryRankSubjectsAt(p, c, stage.rank || 1);
   case "activeMinutesToday":
     return Math.round((rec.activeSeconds || 0) / 60);
   case "classBlocksClaimedToday":
     return storyClassBlocksClaimedToday(p, c);
   case "subjectsCorrectToday":
     return subjectsCorrectTodayCount(p, c);
   case "adaptiveRescueCorrect":
     return adaptive.totalRescueCorrect || 0;
   case "adaptiveQueueCorrect":
     return adaptive.reviewQueueCorrect || 0;
   case "adaptiveBestStreak":
     return adaptive.bestRescueStreak || 0;
   case "companionLevel":
     return companion.level || 1;
   case "mapScraps":
     return random.mapScraps || 0;
   case "storyCampaignsCompleted":
     return storyCampaignsCompleted(p, c);
   default:
     return 0;
 }
}

function bossGauntletStageComplete(stage, profile, child){
 if(stage.metric === "allSubjectsAtCorrect"){
   return bossGauntletStageProgress(stage, profile || state, child || activeChild) >= (stage.subjects || []).length;
 }
 return bossGauntletStageProgress(stage, profile || state, child || activeChild) >= (stage.target || 1);
}

function bossGauntletProgress(gauntlet, profile, child){
 const stages = gauntlet.stages || [];
 const done = stages.filter(st=>bossGauntletStageComplete(st, profile || state, child || activeChild)).length;
 return {done,total:stages.length};
}

function bossGauntletComplete(gauntlet, profile, child){
 return (gauntlet.stages || []).every(st=>bossGauntletStageComplete(st, profile || state, child || activeChild));
}

function setActiveBossGauntlet(id){
 const g = ensureBossGauntlets();
 const gauntlet = bossGauntletById(id);
 if(!gauntlet){ $("feedback").textContent = "Boss gauntlet not found."; return; }
 g.activeGauntletId = id;
 save();
 $("feedback").textContent = "Active boss gauntlet: " + gauntlet.title + ".";
 openBossGauntlets();
 renderStats();
}

function activeBossGauntlet(){
 const g = ensureBossGauntlets();
 return bossGauntletById(g.activeGauntletId) || (bossGauntletConfig().gauntlets || [])[0] || null;
}

function claimBossGauntletStage(gauntletId, stageId){
 const gauntlet = bossGauntletById(gauntletId);
 const stage = gauntlet ? (gauntlet.stages || []).find(st=>st.id === stageId) : null;
 const g = ensureBossGauntlets();
 if(!gauntlet || !stage){ $("feedback").textContent = "Gauntlet stage not found."; return; }
 const key = bossGauntletStageKey(gauntletId, stageId);
 if(!bossGauntletStageComplete(stage, state, activeChild)){ $("feedback").textContent = "That gauntlet stage is not complete yet."; return; }
 if(g.claimedStages[key]){ $("feedback").textContent = "Gauntlet stage already claimed."; return; }
 g.claimedStages[key] = true;
 const msg = grantGameFunReward(stage.reward, "boss gauntlet stage");
 addMemory("Boss Gauntlet Stage", activeChild + " completed " + gauntlet.title + " — " + stage.title + ". " + msg);
 $("feedback").textContent = "Gauntlet stage claimed: " + stage.title + ". " + msg;
 save();
 openBossGauntlets();
 renderStats();
}

function claimBossGauntlet(gauntletId){
 const gauntlet = bossGauntletById(gauntletId);
 const g = ensureBossGauntlets();
 if(!gauntlet){ $("feedback").textContent = "Gauntlet not found."; return; }
 if(!bossGauntletComplete(gauntlet, state, activeChild)){ $("feedback").textContent = "Finish every gauntlet stage first."; return; }
 if(g.claimedGauntlets[gauntletId]){ $("feedback").textContent = "Gauntlet completion reward already claimed."; return; }
 g.claimedGauntlets[gauntletId] = true;
 const msg = grantGameFunReward(gauntlet.completionReward, "boss gauntlet completion");
 const col = ensureCollection();
 if(gauntlet.finalTitle && col.manualTitles && !col.manualTitles.includes(gauntlet.finalTitle)) col.manualTitles.push(gauntlet.finalTitle);
 addMemory("Boss Gauntlet Complete", activeChild + " completed " + gauntlet.title + ". " + msg);
 $("feedback").textContent = "Boss gauntlet complete: " + gauntlet.title + ". " + msg;
 save();
 openBossGauntlets();
 renderStats();
}

function bossGauntletTargetText(stage){
 if(stage.metric === "allSubjectsAtCorrect"){
   return (stage.subjects || []).length + " subjects at " + (stage.target || 1);
 }
 return stage.target || 1;
}

function bossGauntletStageCardHtml(gauntlet, stage){
 const g = ensureBossGauntlets();
 const progress = bossGauntletStageProgress(stage, state, activeChild);
 const target = stage.metric === "allSubjectsAtCorrect" ? (stage.subjects || []).length : (stage.target || 1);
 const pct = Math.min(100, Math.round((progress / Math.max(1,target)) * 100));
 const complete = bossGauntletStageComplete(stage, state, activeChild);
 const key = bossGauntletStageKey(gauntlet.id, stage.id);
 const claimed = !!g.claimedStages[key];
 const button = claimed ? "<button disabled>Claimed</button>" : complete ? `<button onclick="claimBossGauntletStage('${gauntlet.id}','${stage.id}')">Claim Stage Reward</button>` : "<button disabled>In Progress</button>";

 return `<div class="gauntletStage ${complete ? "collectionReady" : ""}">
   <div class="gauntletStageHeader"><b>${complete && !claimed ? "⚔️ " : ""}${lrEscape(stage.title)}</b><span>${progress} / ${target}</span></div>
   <div class="collectionDesc">${lrEscape(stage.text || "")}</div>
   <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
   <div class="questMeta">Reward: ${lrEscape(rewardTextFor(stage.reward))}</div>
   ${button}
 </div>`;
}

function bossGauntletCardHtml(gauntlet){
 const g = ensureBossGauntlets();
 const prog = bossGauntletProgress(gauntlet, state, activeChild);
 const pct = Math.min(100, Math.round((prog.done / Math.max(1,prog.total)) * 100));
 const active = g.activeGauntletId === gauntlet.id || (!g.activeGauntletId && gauntlet === (bossGauntletConfig().gauntlets || [])[0]);
 const complete = bossGauntletComplete(gauntlet, state, activeChild);
 const claimed = !!g.claimedGauntlets[gauntlet.id];
 const claimButton = claimed ? "<button disabled>Gauntlet Claimed</button>" : complete ? `<button onclick="claimBossGauntlet('${gauntlet.id}')">Claim Gauntlet Reward</button>` : "<button disabled>Gauntlet In Progress</button>";

 return `<div class="gauntletCard ${active ? "gauntletActive" : ""}">
   <div class="gauntletHeader"><span>${gauntlet.icon || "⚔️"}</span><b>${lrEscape(gauntlet.title)}</b><span>${prog.done} / ${prog.total}</span></div>
   <div class="collectionDesc">${lrEscape(gauntlet.intro || "")}</div>
   <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
   <div class="reportButtonRow">
     <button onclick="setActiveBossGauntlet('${gauntlet.id}')" ${active ? "disabled" : ""}>${active ? "Active Gauntlet" : "Set Active"}</button>
     ${claimButton}
   </div>
   <div class="questMeta"><b>Completion reward:</b> ${lrEscape(rewardTextFor(gauntlet.completionReward))}${gauntlet.finalTitle ? " | Title: " + lrEscape(gauntlet.finalTitle) : ""}</div>
   <div class="gauntletStageList">${(gauntlet.stages || []).map(st=>bossGauntletStageCardHtml(gauntlet,st)).join("")}</div>
 </div>`;
}

function bossGauntletSummaryLine(profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const gs = ensureBossGauntletsFor(p, c);
 const gauntlets = bossGauntletConfig().gauntlets || [];
 const active = bossGauntletById(gs.activeGauntletId) || gauntlets[0];
 const completed = gauntlets.filter(g=>!!gs.claimedGauntlets[g.id]).length;
 if(!active) return "No boss gauntlets loaded.";
 const prog = bossGauntletProgress(active, p, c);
 return `Active: ${active.title} (${prog.done}/${prog.total} stages). Completed gauntlets: ${completed}/${gauntlets.length}`;
}

function openBossGauntlets(){
 attendanceTick(true);
 const cfg = bossGauntletConfig();
 const gauntlets = cfg.gauntlets || [];
 const g = ensureBossGauntlets();
 if(!g.activeGauntletId && gauntlets[0]) g.activeGauntletId = gauntlets[0].id;
 const active = activeBossGauntlet();

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Boss Gauntlets";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">⚔️ Boss Gauntlets & Capstone Trials</div>
   <div class="lessonCardText">
     ${lrEscape(bossGauntletSummaryLine(state, activeChild))}<br>
     ${active ? "<b>Current challenge:</b> " + lrEscape(active.intro || "") : ""}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<h3>Gauntlets & Capstone Trials</h3>
    ${gauntlets.map(bossGauntletCardHtml).join("")}`;
}
/* End Game Fun Pack 11 */


/* Game Fun Pack 12: World Atlas & Fast Travel */
function worldAtlasConfig(){
 return window.LR_WORLD_ATLAS_CONFIG || {categories:[],hubs:[],travelRewards:[],discoveryRewards:[]};
}

function ensureWorldAtlasFor(profile, child){
 if(!profile.worldAtlas) profile.worldAtlas = {};
 if(!profile.worldAtlas[child]){
   profile.worldAtlas[child] = {
     visitedHubs:{},
     fastTravelCount:0,
     lastTravel:"",
     claimedTravelRewards:{},
     claimedDiscoveryRewards:{}
   };
 }
 const a = profile.worldAtlas[child];
 if(!a.visitedHubs) a.visitedHubs = {};
 if(!a.claimedTravelRewards) a.claimedTravelRewards = {};
 if(!a.claimedDiscoveryRewards) a.claimedDiscoveryRewards = {};
 return a;
}

function ensureWorldAtlas(){
 return ensureWorldAtlasFor(state, activeChild);
}

function atlasHubs(){
 const cfg = worldAtlasConfig();
 return (cfg.hubs || []).filter(h=>h.systemAction || ROOMS[h.id]);
}

function atlasCategories(){
 return worldAtlasConfig().categories || [];
}

function atlasCategoryById(id){
 return atlasCategories().find(c=>c.id === id) || {id,title:id || "Other",icon:"•"};
}

function markAtlasVisit(roomId){
 const a = ensureWorldAtlas();
 if(roomId && ROOMS[roomId]){
   a.visitedHubs[roomId] = true;
 }
 const hub = atlasHubs().find(h=>h.id === roomId || (ROOMS[roomId] && h.zone === ROOMS[roomId].zone));
 if(hub && !hub.systemAction){
   a.visitedHubs[hub.id] = true;
 }
}

function atlasVisitedCount(){
 const a = ensureWorldAtlas();
 const realHubs = atlasHubs().filter(h=>!h.systemAction);
 return realHubs.filter(h=>!!a.visitedHubs[h.id] || state.loc === h.id || (ROOMS[state.loc] && ROOMS[state.loc].zone === h.zone)).length;
}

function atlasFastTravelCount(){
 return ensureWorldAtlas().fastTravelCount || 0;
}

function atlasHubDiscovered(hub){
 if(!hub || hub.systemAction) return true;
 const a = ensureWorldAtlas();
 if(hub.id === "crossroads" || hub.id === "home" || hub.id === "questBoardPlaza") return true;
 if(state.loc === hub.id) return true;
 if(ROOMS[state.loc] && hub.zone && ROOMS[state.loc].zone === hub.zone) return true;
 return !!a.visitedHubs[hub.id];
}

function atlasTotalRealHubs(){
 return atlasHubs().filter(h=>!h.systemAction).length || 1;
}

function atlasSystemAction(action){
 if(action === "report") openReportCenter();
 else if(action === "schedule") openClassroomSchedule();
 else if(action === "campaigns") openStoryCampaigns();
 else if(action === "gauntlets") openBossGauntlets();
 else if(action === "adaptive") openAdaptiveReview();
 else if(action === "collection") openCollectionLog();
 else openQuestBoard();
}

function findAtlasRoute(start, target){
 if(!ROOMS[start] || !ROOMS[target]) return [];
 if(start === target) return [start];
 const queue = [[start]];
 const seen = new Set([start]);
 while(queue.length){
   const path = queue.shift();
   const cur = path[path.length-1];
   const exits = (ROOMS[cur] && ROOMS[cur].exits) || {};
   for(const dir of Object.keys(exits)){
     const next = exits[dir];
     if(!ROOMS[next] || seen.has(next)) continue;
     const np = path.concat(next);
     if(next === target) return np;
     seen.add(next);
     queue.push(np);
   }
 }
 return [];
}

function atlasRouteText(target){
 const path = findAtlasRoute(state.loc, target);
 if(!path.length) return "No walking route found. Use fast travel.";
 if(path.length <= 1) return "You are already here.";
 const names = path.slice(1,8).map(id=>(ROOMS[id] && ROOMS[id].title) || id);
 const more = path.length > 8 ? " ..." : "";
 return names.join(" → ") + more;
}

function openAtlasRoute(target){
 const hub = atlasHubs().find(h=>h.id === target);
 if(!hub || !ROOMS[target]){
   $("feedback").textContent = "Route not available.";
   return;
 }
 $("actionTitle").textContent = "Route to " + hub.title;
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🧭 Walking Route</div>
   <div class="lessonCardText"><b>From:</b> ${lrEscape(room().title)}<br><b>To:</b> ${lrEscape(hub.title)}<br><br>${lrEscape(atlasRouteText(target))}</div>
 </div>`;
 $("feedback").textContent = "Route plotted.";
}

function checkAtlasTravelRewards(){
 const cfg = worldAtlasConfig();
 const a = ensureWorldAtlas();
 let out = "";
 (cfg.travelRewards || []).forEach((r,idx)=>{
   const id = "travel_" + r.count + "_" + idx;
   if((a.fastTravelCount || 0) >= r.count && !a.claimedTravelRewards[id]){
     a.claimedTravelRewards[id] = true;
     const msg = grantGameFunReward(r.reward, "atlas fast travel");
     const col = ensureCollection();
     if(r.title && col.manualTitles && !col.manualTitles.includes(r.title)) col.manualTitles.push(r.title);
     out += " Atlas travel milestone: " + r.title + ". " + msg;
     addMemory("Atlas Travel Milestone", activeChild + " unlocked " + r.title + ". " + msg);
   }
 });
 return out;
}

function checkAtlasDiscoveryRewards(){
 const cfg = worldAtlasConfig();
 const a = ensureWorldAtlas();
 const count = atlasVisitedCount();
 let out = "";
 (cfg.discoveryRewards || []).forEach((r,idx)=>{
   const id = "discover_" + r.count + "_" + idx;
   if(count >= r.count && !a.claimedDiscoveryRewards[id]){
     a.claimedDiscoveryRewards[id] = true;
     const msg = grantGameFunReward(r.reward, "atlas discovery");
     const col = ensureCollection();
     if(r.title && col.manualTitles && !col.manualTitles.includes(r.title)) col.manualTitles.push(r.title);
     out += " Atlas discovery milestone: " + r.title + ". " + msg;
     addMemory("Atlas Discovery Milestone", activeChild + " unlocked " + r.title + ". " + msg);
   }
 });
 return out;
}

function fastTravelAtlas(target){
 const hub = atlasHubs().find(h=>h.id === target);
 if(!hub){
   $("feedback").textContent = "Atlas hub not found.";
   return;
 }
 if(hub.systemAction){
   atlasSystemAction(hub.systemAction);
   return;
 }
 if(!ROOMS[target]){
   $("feedback").textContent = "That destination is not loaded yet.";
   return;
 }
 const a = ensureWorldAtlas();
 state.loc = target;
 state.room++;
 a.fastTravelCount = (a.fastTravelCount || 0) + 1;
 a.lastTravel = new Date().toLocaleString();
 markAtlasVisit(target);
 if(typeof recordGameFunEvent === "function") recordGameFunEvent("roomVisits",1,{room:target});
 const milestoneText = checkAtlasTravelRewards() + checkAtlasDiscoveryRewards();
 addMemory("Atlas Fast Travel", activeChild + " fast traveled to " + hub.title + ".");
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.add("hidden");
 $("feedback").textContent = "Fast traveled to " + hub.title + "." + milestoneText;
 save();
 renderRoom();
 if(target === "home" && typeof enterHomePortal === "function"){ enterHomePortal(); }
 renderStats();
}

function atlasRewardStatusHtml(){
 const cfg = worldAtlasConfig();
 const a = ensureWorldAtlas();
 const visited = atlasVisitedCount();
 const travel = atlasFastTravelCount();
 const discovery = (cfg.discoveryRewards || []).map((r,idx)=>{
   const id = "discover_" + r.count + "_" + idx;
   const ready = visited >= r.count;
   const claimed = !!a.claimedDiscoveryRewards[id];
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🗺️</span><b>${lrEscape(r.title)}</b><span>${visited} / ${r.count}</span></div>
     <div class="collectionDesc">${claimed ? "Claimed" : ready ? "Ready" : "Discover more hubs"} — Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
   </div>`;
 }).join("");
 const travels = (cfg.travelRewards || []).map((r,idx)=>{
   const id = "travel_" + r.count + "_" + idx;
   const ready = travel >= r.count;
   const claimed = !!a.claimedTravelRewards[id];
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>✨</span><b>${lrEscape(r.title)}</b><span>${travel} / ${r.count}</span></div>
     <div class="collectionDesc">${claimed ? "Claimed" : ready ? "Ready" : "Use fast travel more"} — Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
   </div>`;
 }).join("");
 return `<h3>Atlas Discovery Rewards</h3>${discovery}<h3>Fast Travel Rewards</h3>${travels}`;
}

function atlasHubCard(hub){
 const discovered = atlasHubDiscovered(hub);
 const here = !hub.systemAction && state.loc === hub.id;
 const loaded = hub.systemAction || !!ROOMS[hub.id];
 const subj = hub.subject ? `<span class="collectionChip">${lrEscape(hub.subject)}</span>` : "";
 const status = hub.systemAction ? "System Shortcut" : here ? "You are here" : discovered ? "Discovered" : "Undiscovered";
 const travelButton = hub.systemAction
   ? `<button onclick="fastTravelAtlas('${hub.id}')">Open</button>`
   : loaded ? `<button onclick="fastTravelAtlas('${hub.id}')" ${here ? "disabled" : ""}>${here ? "Here" : "Fast Travel"}</button>` : "<button disabled>Not Loaded</button>";
 const routeButton = (!hub.systemAction && loaded) ? `<button onclick="openAtlasRoute('${hub.id}')">Plot Walking Route</button>` : "";
 const route = (!hub.systemAction && loaded) ? `<div class="questMeta"><b>Route hint:</b> ${lrEscape(atlasRouteText(hub.id))}</div>` : "";
 return `<div class="atlasHub ${discovered ? "atlasDiscovered" : "atlasUndiscovered"} ${here ? "atlasHere" : ""}">
   <div class="atlasHubHeader"><span>${hub.icon || "📍"}</span><b>${lrEscape(hub.title)}</b><span>${lrEscape(status)}</span></div>
   <div class="collectionDesc">${lrEscape(hub.desc || "")}</div>
   <div class="questMeta"><b>Zone:</b> ${lrEscape(hub.zone || "System")} ${subj}</div>
   ${route}
   <div class="reportButtonRow">${travelButton}${routeButton}</div>
 </div>`;
}

function atlasCategorySection(cat){
 const hubs = atlasHubs().filter(h=>(h.category || "other") === cat.id);
 if(!hubs.length) return "";
 return `<h3>${cat.icon || "•"} ${lrEscape(cat.title)}</h3>${hubs.map(atlasHubCard).join("")}`;
}

function worldAtlasSummaryLine(profile, child){
 const p = profile || state;
 const c = child || activeChild;
 const a = ensureWorldAtlasFor(p,c);
 const visited = Object.keys(a.visitedHubs || {}).length;
 const total = atlasTotalRealHubs();
 return `${visited}/${total} atlas hubs discovered, ${a.fastTravelCount || 0} fast travels`;
}

function openWorldAtlas(){
 attendanceTick(true);
 markAtlasVisit(state.loc);
 const rewards = checkAtlasDiscoveryRewards();
 const cfg = worldAtlasConfig();
 const visited = atlasVisitedCount();
 const total = atlasTotalRealHubs();
 const pct = Math.min(100, Math.round((visited / Math.max(1,total)) * 100));

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "World Atlas";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🗺️ World Atlas & Fast Travel</div>
   <div class="lessonCardText">
     ${lrEscape(worldAtlasSummaryLine(state, activeChild))}<br>
     <b>Current location:</b> ${lrEscape(room().title)} — ${lrEscape(room().zone || "")}
     <div class="reportTrack"><div class="reportFill" style="width:${pct}%"></div></div>
     ${rewards ? "<br>"+lrEscape(rewards) : ""}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<div class="reportButtonRow">
      <button onclick="fastTravelAtlas('home')">Travel Home</button>
      <button onclick="fastTravelAtlas('questBoardPlaza')">Quest Board</button>
      <button onclick="fastTravelAtlas('crossroads')">Crossroads</button>
      <button onclick="openReportCenter()">Report Center</button>
    </div>
    ${atlasRewardStatusHtml()}
    ${atlasCategories().map(atlasCategorySection).join("")}`;
 save();
 renderStats();
}
/* End Game Fun Pack 12 */


/* Stability Pack 1: System Health & Save Repair */
function stabilityProblem(level,title,detail,fix){
 return {level,title,detail:detail || "",fix:fix || ""};
}

function stabilityRoomExitProblems(){
 const issues = [];
 Object.entries(ROOMS || {}).forEach(([id,r])=>{
   Object.entries((r && r.exits) || {}).forEach(([dir,target])=>{
     if(!ROOMS[target]){
       issues.push(stabilityProblem("error","Broken room exit",id + " → " + dir + " points to missing room: " + target,"Patch the room exit or create the missing room."));
     }
   });
 });
 return issues;
}

function stabilityRequiredRoomProblems(){
 const cfg = LR_stabilityConfig();
 const issues = [];
 ((cfg.requiredRooms || [])).forEach(id=>{
   if(!ROOMS[id]) issues.push(stabilityProblem("error","Missing required room",id,"Restore the required room data."));
 });
 ((cfg.importantRooms || [])).forEach(id=>{
   if(!ROOMS[id]) issues.push(stabilityProblem("warning","Important room not loaded",id,"This is only a problem if that realm should be active."));
 });
 return issues;
}

function stabilityDomProblems(){
 const cfg = LR_stabilityConfig();
 const issues = [];
 ((cfg.requiredDomIds || [])).forEach(id=>{
   if(!document.getElementById(id)){
     issues.push(stabilityProblem("error","Missing page element","#" + id,"Restore index.html element."));
   }
 });
 return issues;
}

function stabilityProfileProblems(){
 const issues = [];
 LR_studentList().forEach(name=>{
   const p = allProfiles[name];
   if(!p) issues.push(stabilityProblem("error","Missing student profile",name,"Run save repair."));
   else{
     if(!ROOMS[p.loc]) issues.push(stabilityProblem("error","Student stuck in missing room",name + " location: " + p.loc,"Use Reset Location or Save Repair."));
     if(!p.progress || !p.progress[name]) issues.push(stabilityProblem("warning","Missing progress bucket",name,"Run save repair."));
     if(!p.homes || !p.homes[name]) issues.push(stabilityProblem("warning","Missing home bucket",name,"Run save repair."));
     if(!p.attendance) issues.push(stabilityProblem("warning","Missing attendance bucket",name,"Run save repair."));
   }
 });
 return issues;
}

function stabilityLessonProblems(){
 const issues = [];
 LR_studentList().forEach(name=>{
   const subjects = Object.keys(LESSONS[name] || {});
   if(!subjects.length) issues.push(stabilityProblem("error","No lessons loaded",name,"Check data/core-lessons.js and expansion scripts."));
   subjects.forEach(subj=>{
     const list = LESSONS[name][subj];
     if(!Array.isArray(list)) issues.push(stabilityProblem("error","Lesson subject is not an array",name + " / " + subj,"Repair lesson pack format."));
     else if(list.length === 0) issues.push(stabilityProblem("warning","Empty subject lesson list",name + " / " + subj,"Add lessons later or remove from rotation."));
     else{
       list.slice(0,3).forEach((L,idx)=>{
         if(!L || !L.q || !Array.isArray(L.c) || L.a === undefined){
           issues.push(stabilityProblem("error","Malformed lesson sample",name + " / " + subj + " item " + idx,"Repair lesson object q/c/a fields."));
         }
       });
     }
   });
 });
 return issues;
}

function stabilityAtlasProblems(){
 const issues = [];
 try{
   const hubs = typeof atlasHubs === "function" ? atlasHubs() : [];
   hubs.forEach(h=>{
     if(!h.systemAction && !ROOMS[h.id]){
       issues.push(stabilityProblem("warning","Atlas hub target missing",h.title + " → " + h.id,"Remove from atlas or add the room."));
     }
   });
 }catch(err){
   issues.push(stabilityProblem("warning","Atlas diagnostic failed",err.message || String(err),"World Atlas may still work, but diagnostics could not inspect it."));
 }
 return issues;
}

function stabilityStorageProblem(){
 const issues = [];
 try{
   const key = "LR_storage_test_" + Date.now();
   localStorage.setItem(key,"ok");
   localStorage.removeItem(key);
 }catch(err){
   issues.push(stabilityProblem("error","Browser storage blocked or full",err.message || String(err),"Exports may still work, but saves may fail. Free storage or allow localStorage."));
 }
 return issues;
}

function runSystemHealthChecks(){
 const issues = [];
 issues.push(...stabilityDomProblems());
 issues.push(...stabilityRequiredRoomProblems());
 issues.push(...stabilityRoomExitProblems());
 issues.push(...stabilityProfileProblems());
 issues.push(...stabilityLessonProblems());
 issues.push(...stabilityAtlasProblems());
 issues.push(...stabilityStorageProblem());
 if(LR_lastSystemError) issues.push(stabilityProblem("warning","Last system message",LR_lastSystemError,"Check backup/export if needed."));
 if(!issues.length) issues.push(stabilityProblem("ok","System looks healthy","No serious problems found by the current checks.",""));
 return issues;
}

function systemHealthSummaryLine(){
 const issues = runSystemHealthChecks();
 const errors = issues.filter(x=>x.level === "error").length;
 const warnings = issues.filter(x=>x.level === "warning").length;
 if(errors) return errors + " error(s), " + warnings + " warning(s)";
 if(warnings) return warnings + " warning(s), no errors";
 return "Healthy";
}

function repairSaveNow(){
 allProfiles = LR_repairAllProfiles(allProfiles);
 if(!allProfiles[activeChild]) activeChild = "Luna";
 state = LR_repairProfile(allProfiles[activeChild], activeChild);
 if(!ROOMS[state.loc]) state.loc = "crossroads";
 save();
 $("feedback").textContent = "Save repaired and migrated.";
 openSystemHealth();
 renderRoom();
}

function emergencyResetLocation(){
 state.loc = "crossroads";
 state.room = Math.max(1, Number(state.room || 1));
 save();
 $("feedback").textContent = "Location reset to Crossroads.";
 renderRoom();
}

function emergencyClearPanels(){
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent = "Panels Cleared";
 $("actionText").textContent = "Lesson and storage panels were cleared. You can continue from the current room.";
 $("feedback").textContent = "Panels cleared.";
}

function emergencyResetCurrentChild(){
 if(!confirm("Reset only " + activeChild + "'s profile? Export a backup first if you need one.")) return;
 allProfiles[activeChild] = LR_repairProfile(DEFAULT_PROFILE_STATE(), activeChild);
 state = allProfiles[activeChild];
 save();
 $("feedback").textContent = activeChild + " was reset.";
 renderRoom();
}

function stabilityDownloadText(filename,text,mime){
 const blob = new Blob([text], {type:mime || "text/plain"});
 const url = URL.createObjectURL(blob);
 const a = document.createElement("a");
 a.href = url;
 a.download = filename;
 document.body.appendChild(a);
 a.click();
 setTimeout(()=>{URL.revokeObjectURL(url); a.remove();},0);
}

function exportSaveBackup(){
 try{
   save();
   const payload = {
     exported:new Date().toLocaleString(),
     activeChild,
     profiles:allProfiles,
     version:"Stability Pack 1"
   };
   stabilityDownloadText("LearningRealms_SaveBackup_"+new Date().toISOString().slice(0,10)+".json", JSON.stringify(payload,null,2), "application/json");
   $("feedback").textContent = "Save backup exported.";
 }catch(err){
   $("feedback").textContent = "Backup export failed: " + (err.message || err);
 }
}

function importSaveBackup(){
 const input = document.createElement("input");
 input.type = "file";
 input.accept = ".json,application/json";
 input.onchange = () => {
   const file = input.files && input.files[0];
   if(!file) return;
   const reader = new FileReader();
   reader.onload = () => {
     try{
       const parsed = JSON.parse(String(reader.result || "{}"));
       const incoming = parsed.profiles || parsed;
       if(!incoming || typeof incoming !== "object") throw new Error("No profiles found in backup.");
       allProfiles = LR_repairAllProfiles(incoming);
       activeChild = parsed.activeChild && allProfiles[parsed.activeChild] ? parsed.activeChild : activeChild;
       state = LR_repairProfile(allProfiles[activeChild], activeChild);
       save();
       $("studentSelect").value = activeChild;
       $("feedback").textContent = "Save backup imported and repaired.";
       renderRoom();
     }catch(err){
       $("feedback").textContent = "Import failed: " + (err.message || err);
     }
   };
   reader.readAsText(file);
 };
 input.click();
}

function exportSystemReport(){
 const report = {
   exported:new Date().toLocaleString(),
   activeChild,
   location:state.loc,
   summary:systemHealthSummaryLine(),
   issues:runSystemHealthChecks(),
   students:LR_studentList().map(name=>({
     name,
     loc:(allProfiles[name] || {}).loc,
     report: typeof schoolReportSummaryLine === "function" ? schoolReportSummaryLine(allProfiles[name] || {}, name) : "",
     atlas: typeof worldAtlasSummaryLine === "function" ? worldAtlasSummaryLine(allProfiles[name] || {}, name) : "",
     adaptive: typeof adaptiveSummaryLine === "function" ? adaptiveSummaryLine(allProfiles[name] || {}, name) : ""
   }))
 };
 stabilityDownloadText("LearningRealms_SystemHealth_"+new Date().toISOString().slice(0,10)+".json", JSON.stringify(report,null,2), "application/json");
 $("feedback").textContent = "System health report exported.";
}

function downloadPlaytestChecklist(){
 const text = `LearningRealms Stability Pack 1 Playtest Checklist

1. Open index.html.
2. Confirm the game loads without a blank screen.
3. Open System Health from the menu.
4. Click Run Save Repair.
5. Click Export Save Backup.
6. Use Reset Location to Crossroads if the player is stuck.
7. Test World Atlas fast travel to:
   - Home
   - Quest Board Plaza
   - Math realm
   - Reading realm
   - Civics realm
   - Geography realm
   - Life Skills realm
8. Open these screens from the menu:
   - Report Center
   - Classroom Schedule
   - Story Campaigns
   - Boss Gauntlets
   - Adaptive Review
   - Collection Log
   - Companion Den
   - Event Log
   - World Atlas
9. Answer one lesson question correctly.
10. Answer one lesson question incorrectly.
11. Confirm missed-question review still opens.
12. Open Quest Board and confirm progress bars appear.
13. Open Report Center and confirm today's problem log updates.
14. Export Attendance CSV.
15. Export Problem Log CSV.
16. Switch students and repeat a short test.
17. Close and reopen the game.
18. Confirm progress persists.

If something breaks:
- Export Save Backup first if possible.
- Use System Health → Run Save Repair.
- Use Reset Location to Crossroads.
- Use Clear Stuck Panels.
`;
 stabilityDownloadText("LearningRealms_Stability_Playtest_Checklist.txt", text, "text/plain");
 $("feedback").textContent = "Playtest checklist downloaded.";
}

function healthIssueHtml(issue){
 const cls = issue.level === "error" ? "healthError" : issue.level === "warning" ? "healthWarning" : "healthOk";
 const icon = issue.level === "error" ? "🚨" : issue.level === "warning" ? "⚠️" : "✅";
 return `<div class="healthItem ${cls}">
   <div class="healthTitle">${icon} ${lrEscape(issue.title)}</div>
   <div class="healthDetail">${lrEscape(issue.detail)}</div>
   ${issue.fix ? `<div class="healthFix"><b>Fix:</b> ${lrEscape(issue.fix)}</div>` : ""}
 </div>`;
}

function openSystemHealth(){
 attendanceTick(true);
 const issues = runSystemHealthChecks();
 const errors = issues.filter(x=>x.level === "error").length;
 const warnings = issues.filter(x=>x.level === "warning").length;

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "System Health";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🧰 System Health & Save Repair</div>
   <div class="lessonCardText">
     <b>Status:</b> ${lrEscape(systemHealthSummaryLine())}<br>
     <b>Errors:</b> ${errors} | <b>Warnings:</b> ${warnings}<br>
     <b>Current student:</b> ${lrEscape(activeChild)}<br>
     <b>Current location:</b> ${lrEscape(state.loc)} — ${lrEscape(room().title || "")}${LR_lastSystemError ? "<br><b>Last warning:</b> " + lrEscape(LR_lastSystemError) : ""}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<div class="reportButtonRow">
      <button onclick="repairSaveNow()">Run Save Repair</button>
      <button onclick="exportSaveBackup()">Export Save Backup</button>
      <button onclick="importSaveBackup()">Import Save Backup</button>
      <button onclick="exportSystemReport()">Export System Report</button>
      <button onclick="downloadPlaytestChecklist()">Download Playtest Checklist</button>
    </div>
    <h3>Emergency Tools</h3>
    <div class="reportButtonRow">
      <button onclick="emergencyResetLocation()">Reset Location to Crossroads</button>
      <button onclick="emergencyClearPanels()">Clear Stuck Panels</button>
      <button onclick="emergencyResetCurrentChild()">Reset Current Student</button>
    </div>
    <h3>Diagnostics</h3>
    ${issues.map(healthIssueHtml).join("")}`;
}
/* End Stability Pack 1: System Health & Save Repair */


/* Stability Pack 1.2: definite Sleep / Rest action repair */

function safeActionRef(fn, label){
 return function(){
   try{
     if(typeof fn === "function") return fn();
     $("feedback").textContent = "Action unavailable: " + label + ". Open System Health and run Save Repair.";
   }catch(err){
     LR_lastSystemError = "Action failed: " + label + " — " + (err && err.message ? err.message : err);
     try{$("feedback").textContent = LR_lastSystemError;}catch(e){}
     console.error(LR_lastSystemError, err);
   }
 };
}

function lrSafeRestAction(){
 try{
   attendanceTick(true);
 }catch(e){}
 state.dayCycle = state.dayCycle || {day:1};
 state.dayCycle.day = Math.max(1, Number(state.dayCycle.day || 1)) + 1;
 state.streak = 0;
 try{$("lessonBox").classList.add("hidden");}catch(e){}
 try{$("storageBox").classList.add("hidden");}catch(e){}
 try{$("actionTitle").textContent = "Rest";}catch(e){}
 try{$("actionText").textContent = "You rest until the next learning day. The realm feels fresh again.";}catch(e){}
 try{$("feedback").textContent = "A new learning day begins.";}catch(e){}
 try{addMemory("Rest", activeChild + " rested and began learning day " + state.dayCycle.day + ".");}catch(e){}
 save();
 renderRoom();
}
function sleep(){
 return lrSafeRestAction();
}
/* End Stability Pack 1.2 */


/* Stability Pack 1.3: definite Storage Chest repair */
function lrSafeStorageChest(){
 try{
   attendanceTick(true);
 }catch(e){}
 const h = ensureHome();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Storage Chest";
 $("actionText").textContent = "Choose an item from storage to equip it in your home.";
 if(!h.storage || !h.storage.length){
   $("storageItems").innerHTML = "<p>Your storage chest is empty right now.</p>";
   $("feedback").textContent = "Storage chest opened.";
   save();
   return;
 }
 $("storageItems").innerHTML = h.storage.map((it,i)=>{
   const slot = it && it.slot ? it.slot : "shelf";
   const name = it && it.name ? it.name : "Unnamed Item";
   return `<button data-equip="${i}">${lrEscape(name)} <small>(${lrEscape(slot)})</small></button>`;
 }).join("");
 document.querySelectorAll("[data-equip]").forEach(btn=>{
   btn.onclick = () => {
     const idx = Number(btn.dataset.equip);
     const item = h.storage[idx];
     if(!item){
       $("feedback").textContent = "That storage item was not found.";
       return;
     }
     equipItem(idx);
   };
 });
 $("feedback").textContent = "Storage chest opened.";
 save();
}
function chest(){
 return lrSafeStorageChest();
}
/* End Stability Pack 1.3 */


/* Stability Pack 1.6: prettier Home screen and hidden Home Slots sidebar */
function lrHomeSlotLabel(slot){
 const labels = {
   wall:"Wall",
   shelf:"Shelf",
   desk:"Desk",
   table:"Table",
   rug:"Rug",
   pet1:"Pet Spot 1",
   pet2:"Pet Spot 2",
   food:"Food / Treat",
   hat:"Hat",
   cloak:"Cloak",
   accessory:"Accessory",
   held:"Held Item"
 };
 return labels[slot] || slot;
}

function lrHomeSlotIcon(slot){
 const icons = {
   wall:"🖼️",
   shelf:"🏺",
   desk:"✏️",
   table:"🪑",
   rug:"▤",
   pet1:"🐾",
   pet2:"🐾",
   food:"🍲",
   hat:"🎩",
   cloak:"🧥",
   accessory:"🎖️",
   held:"🎒"
 };
 return icons[slot] || "▫️";
}

function lrHomeSlotGroup(slot){
 if(["wall","shelf","desk","table","rug"].includes(slot)) return "Room Decor";
 if(["pet1","pet2","food"].includes(slot)) return "Companion & Pets";
 return "Outfit & Gear";
}

function lrHomeItemName(item){
 if(!item) return "Empty";
 if(typeof item === "string") return item;
 return item.name || "Unnamed Item";
}

function lrHomeSlotCard(slot, item){
 const empty = !item;
 return `<div class="homeSlotCard ${empty ? "homeSlotEmpty" : "homeSlotFilled"}">
   <div class="homeSlotIcon">${lrHomeSlotIcon(slot)}</div>
   <div class="homeSlotText">
     <b>${lrEscape(lrHomeSlotLabel(slot))}</b>
     <span>${lrEscape(lrHomeItemName(item))}</span>
   </div>
 </div>`;
}

function lrHomeSlotsByGroupHtml(){
 const h = ensureHome();
 const eq = h.equip || {};
 const slots = ["wall","shelf","desk","table","rug","pet1","pet2","food","hat","cloak","accessory","held"];
 const groups = {};
 slots.forEach(slot=>{
   const group = lrHomeSlotGroup(slot);
   if(!groups[group]) groups[group] = [];
   groups[group].push(slot);
 });
 return Object.keys(groups).map(group=>{
   return `<div class="homeGroup">
     <h3>${lrEscape(group)}</h3>
     <div class="homeSlotGrid">
       ${groups[group].map(slot=>lrHomeSlotCard(slot, eq[slot])).join("")}
     </div>
   </div>`;
 }).join("");
}

function lrHomeStoragePreviewHtml(){
 const h = ensureHome();
 const storage = h.storage || [];
 if(!storage.length){
   return `<div class="homeStorageEmpty">Storage is empty right now. Rewards and shop purchases will appear here.</div>`;
 }
 return `<div class="homeStoragePreview">
   ${storage.slice(0,12).map((it,i)=>`<button data-home-equip="${i}">${lrEscape(lrHomeItemName(it))}<small>${lrEscape((it && it.slot) || "shelf")}</small></button>`).join("")}
 </div>
 ${storage.length > 12 ? `<div class="questMeta">Showing 12 of ${storage.length} stored items. Open Storage Chest for everything.</div>` : ""}`;
}


/* Stability Pack 1.9: Cozy Home Room View */
function lrHomeTheme(){
 const themes = {
   Luna:{name:"Storybook Cottage",wall:"soft story walls",floor:"warm reading rug",accent:"rabbit nook"},
   Ava:{name:"Foxwork Workshop",wall:"clever workshop walls",floor:"cozy plank floor",accent:"gear fox corner"},
   Michael:{name:"Owl Archive Room",wall:"quiet archive walls",floor:"study hall floor",accent:"owl perch"}
 };
 return themes[activeChild] || {name:"Cozy Trophy Room",wall:"warm walls",floor:"soft floor",accent:"study corner"};
}

function lrHomeSceneItem(slot, item){
 const name = lrHomeItemName(item);
 const empty = !item;
 const label = empty ? lrHomeSlotLabel(slot) : name;
 return `<div class="homeSceneObject scene-${slot} ${empty ? "scene-empty" : "scene-filled"}" title="${lrEscape(label)}">
   <span class="sceneIcon">${lrHomeSlotIcon(slot)}</span>
   <span class="sceneLabel">${lrEscape(label)}</span>
 </div>`;
}

function lrHomeRoomSceneHtml(){
 const h = ensureHome();
 const eq = h.equip || {};
 const theme = lrHomeTheme();
 return `<div class="homeRoomWrap">
   <div class="homeRoomHeader">
     <div>
       <div class="homeRoomTitle">🏡 ${lrEscape(theme.name)}</div>
       <div class="homeRoomSubtitle">${lrEscape(theme.wall)} • ${lrEscape(theme.floor)} • ${lrEscape(theme.accent)}</div>
     </div>
     <div class="homeRoomBadge">${(h.storage || []).length}<span>stored</span></div>
   </div>

   <div class="homeRoomScene">
     <div class="homeBackWall">
       ${lrHomeSceneItem("wall", eq.wall)}
       ${lrHomeSceneItem("shelf", eq.shelf)}
     </div>
     <div class="homeFloor">
       <div class="floorPattern"></div>
       ${lrHomeSceneItem("rug", eq.rug)}
       ${lrHomeSceneItem("desk", eq.desk)}
       ${lrHomeSceneItem("table", eq.table)}
       ${lrHomeSceneItem("pet1", eq.pet1)}
       ${lrHomeSceneItem("pet2", eq.pet2)}
       ${lrHomeSceneItem("food", eq.food)}
       ${lrHomeSceneItem("hat", eq.hat)}
       ${lrHomeSceneItem("cloak", eq.cloak)}
       ${lrHomeSceneItem("accessory", eq.accessory)}
       ${lrHomeSceneItem("held", eq.held)}
     </div>
   </div>

   <div class="homeRoomTip">
     Click rewards in Storage Preview to place them. Filled spots start turning the room into a real trophy home.
   </div>
 </div>`;
}

function lrHomeSlotShelfHtml(){
 const h = ensureHome();
 const eq = h.equip || {};
 const slots = ["wall","shelf","desk","table","rug","pet1","pet2","food","hat","cloak","accessory","held"];
 return `<div class="homeShelf">
   ${slots.map(slot=>{
     const item = eq[slot];
     return `<div class="homeShelfSlot ${item ? "filled" : ""}">
       <div>${lrHomeSlotIcon(slot)}</div>
       <b>${lrEscape(lrHomeSlotLabel(slot))}</b>
       <span>${lrEscape(lrHomeItemName(item))}</span>
     </div>`;
   }).join("")}
 </div>`;
}

function lrHomeDecorScore(){
 const h = ensureHome();
 const eq = h.equip || {};
 const slots = ["wall","shelf","desk","table","rug","pet1","pet2","food","hat","cloak","accessory","held"];
 const filled = slots.filter(s=>!!eq[s]).length;
 return {filled,total:slots.length,pct:Math.round((filled/slots.length)*100)};
}

function lrHomeDecorMeterHtml(){
 const score = lrHomeDecorScore();
 return `<div class="homeDecorMeter">
   <div class="homeDecorMeterTop"><b>Home Decor Progress</b><span>${score.filled} / ${score.total} spots filled</span></div>
   <div class="homeDecorTrack"><div class="homeDecorFill" style="width:${score.pct}%"></div></div>
 </div>`;
}
/* End Stability Pack 1.9 */

function openHomeView(){
 attendanceTick(true);
 const h = ensureHome();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = activeChild + "'s Home";
 $("actionText").innerHTML = lrHomeRoomSceneHtml() + lrHomeDecorMeterHtml();

 $("storageItems").innerHTML =
   `<div class="homeActionRow">
      <button onclick="lrSafeStorageChest()">Open Storage Chest</button>
      <button onclick="openCollectionLog()">Collection Log</button>
      <button onclick="openCompanionDen()">Companion Den</button>
      <button onclick="openWorldAtlas()">World Atlas</button>
    </div>
    <h3>Room Spots</h3>
    ${lrHomeSlotShelfHtml()}
    <h3>Storage Preview</h3>
    ${lrHomeStoragePreviewHtml()}`;

 document.querySelectorAll("[data-home-equip]").forEach(btn=>{
   btn.onclick = () => {
     const idx = Number(btn.dataset.homeEquip);
     equipItem(idx);
     openHomeView();
   };
 });
}

function renderHomeSlots(){
 // Home Slots are no longer rendered in the permanent sidebar.
 // They are intentionally shown only through openHomeView().
 const box = $("homeSlots");
 if(box) box.innerHTML = "";
}
/* End Stability Pack 1.6 */


/* Stability Pack 1.7: action sidebar mount guard */
function lrEnsureLeftActionMount(){
 let mount = $("leftActionButtons");
 if(mount) return mount;
 const aside = document.querySelector(".actionSidebar") || document.querySelector("aside");
 if(aside){
   const div = document.createElement("div");
   div.id = "leftActionButtons";
   div.className = "actionButtons";
   aside.appendChild(div);
   return div;
 }
 return null;
}
/* End Stability Pack 1.7 mount guard */


/* Stability Pack 2.0: Home Portal Mode */
function lrHomePortalConfig(){
 return window.LR_HOME_PORTAL_CONFIG || {arrivalLines:{},defaultArrival:"You enter Home."};
}

function lrHomeArrivalLine(){
 const cfg = lrHomePortalConfig();
 const list = (cfg.arrivalLines && cfg.arrivalLines[activeChild]) || [];
 if(list.length){
   const index = ((state.room || 1) + activeChild.length) % list.length;
   return list[index];
 }
 return cfg.defaultArrival || "You enter Home.";
}

function lrSetHomeMode(on){
 try{
   document.body.classList.toggle("homeMode", !!on);
 }catch(e){}
}

function lrHomePortalBannerHtml(){
 const theme = lrHomeTheme ? lrHomeTheme() : {name:"Cozy Home"};
 return `<div class="homePortalBanner">
   <div class="homePortalGlow"></div>
   <div class="homePortalDoor">🚪</div>
   <div class="homePortalWords">
     <div class="homePortalKicker">Entering Home</div>
     <div class="homePortalTitle">${lrEscape(theme.name)}</div>
     <div class="homePortalLine">${lrEscape(lrHomeArrivalLine())}</div>
   </div>
 </div>`;
}

function enterHomePortal(){
 lrSetHomeMode(true);
 openHomeView();
 $("actionTitle").textContent = "Home";
 $("actionText").innerHTML = lrHomePortalBannerHtml() + $("actionText").innerHTML;
 $("feedback").textContent = "Entered Home Mode.";
 save();
}

function leaveHomePortal(target){
 lrSetHomeMode(false);
 const destination = target || "crossroads";
 if(ROOMS[destination]){
   state.loc = destination;
 }else{
   state.loc = "crossroads";
 }
 state.room = Math.max(1, Number(state.room || 1)) + 1;
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.add("hidden");
 $("feedback").textContent = "Left Home and returned to adventure.";
 save();
 renderRoom();
}

function lrHomeSpecificActions(){
 addLeft("Home View",openHomeView);
 addLeft("Open Storage Chest",lrSafeStorageChest);
 addLeft("Collection Log",openCollectionLog);
 addLeft("Companion Den",openCompanionDen);
 addLeft("World Atlas",openWorldAtlas);
 addLeft("Leave Home",()=>leaveHomePortal("crossroads"));
}
/* End Stability Pack 2.0 */


/* Stability Pack 2.1: Shop Item Display Repair */
function lrShopCatalog(){
 const season = (typeof currentFestival === "function" && typeof shopData !== "undefined" && shopData.seasonal)
   ? ((shopData.seasonal[currentFestival().season] || shopData.seasonal.Bloomwake || []))
   : [];
 const pictures = (typeof shopData !== "undefined" && Array.isArray(shopData.pictures)) ? shopData.pictures : [];
 const diner = (typeof shopData !== "undefined" && Array.isArray(shopData.diner)) ? shopData.diner : [];
 const relics = (typeof shopData !== "undefined" && Array.isArray(shopData.relics)) ? shopData.relics : [];

 const seasonalFallback = ["Bloomwake Flower Pot","Spring Window Garland","Festival Table Lantern","Garden Path Rug","Painted Egg Shelf"];
 const pictureFallback = ["Forest Picture","Math Mountain Picture","Crystal Marsh Picture","Dragonbrush Picture","Council Hall Picture"];
 const dinerFallback = ["Warm Study Cocoa","Berry Hand Pie","Lucky Soup Bowl","Festival Cookie"];
 const relicFallback = ["Old Realm Key","Ancient Brass Compass","Moonlit Relic Shard","Secret Gate Gear"];

 return {
   seasonalShop:(season.length ? season : seasonalFallback).map(name=>({
     name,
     cost:25,
     currency:"sparks",
     slot:name.toLowerCase().includes("rug") ? "rug" : (name.toLowerCase().includes("picture") || name.toLowerCase().includes("banner") || name.toLowerCase().includes("garland") ? "wall" : "shelf"),
     unique:true,
     source:"seasonal"
   })),
   pictureShop:(pictures.length ? pictures : pictureFallback).map(name=>({
     name,
     cost:20,
     currency:"sparks",
     slot:"wall",
     unique:true,
     source:"picture"
   })),
   luckyKettle:(diner.length ? diner : dinerFallback).map(name=>({
     name,
     cost:15,
     currency:"sparks",
     slot:"food",
     unique:false,
     source:"diner"
   })),
   shiftyTent:(relics.length ? relics : relicFallback).map((name,i)=>({
     name,
     cost:[3,4,4,5,10][i] || 3,
     currency:"ancientCoins",
     slot:"shelf",
     unique:true,
     source:"relic"
   }))
 };
}

function lrNormalizeShopItem(item){
 if(typeof item === "string"){
   return {name:item,cost:25,currency:"sparks",slot:"shelf",unique:true};
 }
 return {
   name:item.name || "Unnamed Shop Item",
   cost:Number.isFinite(Number(item.cost)) ? Number(item.cost) : 25,
   currency:item.currency || "sparks",
   slot:item.slot || "shelf",
   minLevel:item.minLevel || 0,
   unique:item.unique === false ? false : true,
   source:item.source || "shop"
 };
}

function shopItems(){
 const catalog = lrShopCatalog();
 const base = (catalog[state.loc] || []).map(lrNormalizeShopItem);
 let extra = [];
 try{
   if(typeof extraShopStockFor === "function"){
     extra = (extraShopStockFor(state.loc) || []).map(lrNormalizeShopItem);
   }
 }catch(err){
   LR_lastSystemError = "Extra shop stock failed: " + (err && err.message ? err.message : err);
 }
 return base.concat(extra);
}

function lrShopCanAfford(item){
 const currency = item.currency === "ancientCoins" ? "ancientCoins" : "sparks";
 return (state[currency] || 0) >= item.cost;
}

function lrShopCurrencyLabel(item){
 return item.currency === "ancientCoins" ? "Ancient Coins" : "Sparks";
}

function lrShopUnlocked(item){
 try{
   if(typeof shopItemUnlocked === "function") return shopItemUnlocked(item);
 }catch(e){}
 const lvl = typeof activeLevel === "function" ? activeLevel() : 1;
 return !item.minLevel || lvl >= item.minLevel;
}

function lrShopOwned(item){
 if(item.unique === false) return false;
 try{
   if(typeof ownsHomeItem === "function") return ownsHomeItem(item.name);
 }catch(e){}
 const h = ensureHome();
 return !!((h.storage || []).find(x=>x && x.name === item.name) || Object.values(h.equip || {}).find(x=>x && x.name === item.name));
}

function lrShopItemCard(item, index){
 const unlocked = lrShopUnlocked(item);
 const owned = lrShopOwned(item);
 const afford = lrShopCanAfford(item);
 const lockedText = !unlocked ? `Requires Level ${item.minLevel}` : owned ? "Owned" : !afford ? "Need more " + lrShopCurrencyLabel(item) : "Available";
 const disabled = (!unlocked || owned || !afford) ? "disabled" : "";
 return `<div class="shopItemCard ${unlocked && !owned ? "shopAvailable" : "shopLocked"}">
   <div class="shopItemTop">
     <b>${lrEscape(item.name)}</b>
     <span>${item.cost} ${lrEscape(lrShopCurrencyLabel(item))}</span>
   </div>
   <div class="shopItemMeta">Slot: ${lrEscape(item.slot)} | ${lrEscape(lockedText)}</div>
   <button data-shop-buy="${index}" ${disabled}>${owned ? "Already Owned" : "Buy"}</button>
 </div>`;
}

function openShop(){
 attendanceTick(true);
 const items = shopItems();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = room().title || "Shop";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🛍️ ${lrEscape(room().title || "Shop")}</div>
   <div class="lessonCardText">
     Choose an item. Purchases go to Home Storage.<br>
     <b>Sparks:</b> ${state.sparks || 0} | <b>Ancient Coins:</b> ${state.ancientCoins || 0}
   </div>
 </div>`;

 const box = $("storageItems");
 if(!box){
   $("feedback").textContent = "Shop item area is missing.";
   return;
 }
 if(!items.length){
   box.innerHTML = `<div class="shopEmpty">This shop has no stock loaded yet.</div>`;
   $("feedback").textContent = "Shop opened, but no stock was found.";
   return;
 }
 box.innerHTML = `<div class="shopGrid">${items.map(lrShopItemCard).join("")}</div>`;
 document.querySelectorAll("[data-shop-buy]").forEach(btn=>{
   btn.onclick = () => buyItem(items[Number(btn.dataset.shopBuy)]);
 });
 $("feedback").textContent = "Shop opened.";
}

function buyItem(item){
 item = lrNormalizeShopItem(item);
 if(!lrShopUnlocked(item)){
   $("feedback").textContent = "Locked until Level " + item.minLevel + ".";
   return;
 }
 if(lrShopOwned(item)){
   $("feedback").textContent = "Already owned: " + item.name + ".";
   return;
 }
 const currency = item.currency === "ancientCoins" ? "ancientCoins" : "sparks";
 if((state[currency] || 0) < item.cost){
   $("feedback").textContent = "Not enough " + lrShopCurrencyLabel(item) + ".";
   return;
 }
 state[currency] = (state[currency] || 0) - item.cost;
 const h = ensureHome();
 h.storage.push({name:item.name,slot:item.slot || "shelf"});
 addMemory("Shop Purchase", activeChild + " purchased " + item.name + " from " + (room().title || "a shop") + ".");
 $("feedback").textContent = "Purchased " + item.name + ". Added to Home Storage.";
 save();
 renderStats();
 lrSafeBrowseShopPopup();
}
/* End Stability Pack 2.1 */


/* Stability Pack 2.2: NPC Interaction Repair */
function lrNpcDataForRoom(roomId){
 const id = roomId || state.loc;
 const r = ROOMS[id] || {};
 const text = r.text || "";
 const npcs = {
   marketRow:{
     name:"Elric",
     role:"Seasonal Shopkeeper",
     greeting:"Elric adjusts a row of festival goods and gives a warm nod. “Seasonal rewards make a home feel alive. Check the shop when you want something cozy for your room.”",
     shop:"seasonalShop"
   },
   seasonalShop:{
     name:"Elric",
     role:"Seasonal Shopkeeper",
     greeting:"Elric smiles from behind the counter. “Every festival brings a few special things. Pick what makes your home feel like yours.”",
     shop:"seasonalShop"
   },
   pictureShop:{
     name:"Mira",
     role:"Curator",
     greeting:"Curator Mira straightens a frame. “Pictures make a room remember where you have been.”",
     shop:"pictureShop"
   },
   luckyKettle:{
     name:"Herky Jerky",
     role:"Fiddler Cook",
     greeting:"Herky Jerky taps a boot and grins. “A warm snack and a tune can make a long school day feel lighter.”",
     shop:"luckyKettle"
   },
   shiftyTent:{
     name:"Shifty Salesman",
     role:"Relic Trader",
     greeting:"The Shifty Salesman lowers his voice. “Rare things come to patient adventurers. Ancient Coins open unusual doors.”",
     shop:"shiftyTent"
   }
 };
 if(npcs[id]) return npcs[id];

 // Fallback detection for future rooms without hand-written NPC data.
 const shopkeeper = text.match(/Shopkeeper\s+([A-Z][A-Za-z]+)/);
 if(shopkeeper){
   return {
     name:shopkeeper[1],
     role:"Shopkeeper",
     greeting:shopkeeper[1] + " greets you and points out the goods nearby.",
     shop:id.includes("Shop") ? id : ""
   };
 }
 const curator = text.match(/Curator\s+([A-Z][A-Za-z]+)/);
 if(curator){
   return {name:curator[1],role:"Curator",greeting:curator[1] + " greets you warmly.",shop:""};
 }
 return null;
}

function roomHasNpc(){
 return !!lrNpcDataForRoom(state.loc);
}

function npc(){
 return lrNpcDataForRoom(state.loc) || {name:"Someone",role:"NPC",greeting:"Someone greets you.",shop:""};
}

function talk(){
 const n = npc();
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Talk with " + n.name;
 $("actionText").innerHTML = `<div class="npcTalkCard">
   <div class="npcPortrait">👤</div>
   <div>
     <div class="npcName">${lrEscape(n.name)}</div>
     <div class="npcRole">${lrEscape(n.role || "Realm Helper")}</div>
     <p>${lrEscape(n.greeting || (n.name + " greets you."))}</p>
   </div>
 </div>`;
 const shopButton = n.shop ? `<button onclick="state.loc='${n.shop}'; save(); renderRoom(); lrSafeBrowseShopPopup();">Browse ${lrEscape((ROOMS[n.shop] && ROOMS[n.shop].title) || "Shop")}</button>` : "";
 $("storageItems").innerHTML = `<div class="npcActionRow">
   ${shopButton}
   <button onclick="openWorldAtlas()">Open World Atlas</button>
   <button onclick="openQuestBoard()">Quest Board</button>
 </div>`;
 $("feedback").textContent = "Talking with " + n.name + ".";
 if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Talk");
 addMemory("NPC Talk", activeChild + " talked with " + n.name + " at " + (room().title || state.loc) + ".");
 save();
}
/* End Stability Pack 2.2 */

function renderLeftActions(){
 const box=$("leftActionButtons"); box.innerHTML="";
 const r=room();
 box.innerHTML = lrMiniMapHtml() + lrQuickTravelHtml();
 lrAddActionGroup("Quick Travel", [
   {label:"Open World Atlas",fn:openWorldAtlas},
   {label:"Shop Hub",fn:openShopHub},
   {label:"Quest Board",fn:openQuestBoard},
   {label:"Travel Home",fn:()=>{state.loc="home";renderRoom();save();}}
 ]);
 const hereItems=[];
 if(roomHasNpc()) hereItems.push({label:"Talk: "+npc().name,fn:talk});
 if(["seasonalShop","pictureShop","luckyKettle","shiftyTent"].includes(state.loc)) hereItems.push({label:"Browse Shop",fn:openShop});
 if(state.loc==="questBoardPlaza") hereItems.push({label:"Read Quest Board",fn:openQuestBoard});
 if(state.loc==="questBoardPlaza") hereItems.push({label:"Today's Classroom Plan",fn:openDailyClassroomBoard});
 if(state.loc==="historicalSociety") hereItems.push({label:"Investigation Board",fn:openInvestigationBoard});
 if(moonClues[state.loc]) hereItems.push({label:"Record Moon Stair Clue",fn:recordMoonClue});
 lrAddActionGroup("This Room", hereItems);
 const lessonItems=[];
 if(room().subject) lessonItems.push({label:"Mastery Status",fn:showMasteryStatus});
 if(room().subject) lessonItems.push({label:"Realm Boss Challenge",fn:startBossChallenge});
 if(room().subject) lessonItems.push({label:"Adaptive Review",fn:openAdaptiveReview});
 if(room().subject) lessonItems.push({label:"Boss Gauntlets",fn:openBossGauntlets});
 lrAddActionGroup("Learning", lessonItems);
 lrAddActionGroup("Companion", [
   {label:"Check Companion",fn:checkCompanion},{label:"Train",fn:trainCompanion},{label:"Feed",fn:feedCompanion},{label:"Pet / Bond",fn:petCompanion},{label:"Ask Advice",fn:askCompanion}
 ]);
 lrAddActionGroup("Home & Save", [
   {label:"Sleep",fn:lrSafeRestAction},{label:"Open Storage Chest",fn:chest},{label:"System Health",fn:openSystemHealth},{label:"Reset Save",fn:resetChild}
 ]);
}

function go(dir){
 const target=room().exits[dir];
 if(!target)return;
 state.loc=target;
 state.room++;
 if(typeof lrPagedMapMove === "function") lrPagedMapMove(dir);
 if(typeof lrMiniMapMoveDirection === "function") lrMiniMapMoveDirection(dir);
 if(typeof recordGameFunEvent === "function") recordGameFunEvent("roomVisits",1,{room:target});
 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent="Exploring";
 $("actionText").textContent="You continue through the realm.";
 save();
 renderRoom();
 if(target === "home" && typeof enterHomePortal === "function"){
   enterHomePortal();
 }else if(typeof maybeTriggerRandomEvent === "function"){
   maybeTriggerRandomEvent(target);
 }
}


function lrEscape(value){
 return String(value === undefined || value === null ? "" : value)
   .replace(/&/g,"&amp;")
   .replace(/</g,"&lt;")
   .replace(/>/g,"&gt;")
   .replace(/"/g,"&quot;")
   .replace(/'/g,"&#039;");
}

function lessonSectionHtml(label, text, icon){
 if(!text) return "";
 return `<div class="lessonCard lesson-${label.toLowerCase().replace(/[^a-z0-9]+/g,"-")}">
   <div class="lessonCardTitle"><span>${icon || "✦"}</span>${lrEscape(label)}</div>
   <div class="lessonCardText">${lrEscape(text)}</div>
 </div>`;
}

function lessonSubjectIcon(subj){
 const icons = {
   Reading:"📖",
   English:"✍️",
   Math:"⚙️",
   Science:"🔬",
   History:"🏛️",
   Civics:"⚖️",
   Geography:"🧭",
   Economics:"🪙",
   Logic:"🧩",
   Nature:"🌿",
   Health:"🫀",
   Music:"🎵",
   Copywork:"✒️",
   LifeSkills:"🧰",
   Writing:"🪶",
   Art:"🎨",
   Geography:"🧭",
   Economics:"🪙",
   Logic:"🧩",
   Nature:"🌿",
   Health:"🫀",
   Music:"🎵",
   Copywork:"✒️",
   LifeSkills:"🧰"
 };
 return icons[subj] || "✨";
}

function lessonTutorName(subj){
 const tutors = {
   Reading:"Story Guide",
   English:"Grammar Guide",
   Math:"Gear Tutor",
   Science:"Marsh Naturalist",
   History:"Archive Guide",
   Civics:"Council Keeper",
   Geography:"Mapmaker Guide",
   Economics:"Market Tutor",
   Logic:"Puzzle Tutor",
   Nature:"Nature Guide",
   Health:"Health Guide",
   Music:"Music Guide",
   Copywork:"Scribe Mentor",
   LifeSkills:"Homestead Guide",
   Writing:"Scribe Mentor",
   Art:"Dragon Art Master",
   Geography:"Mapmaker Guide",
   Economics:"Market Tutor",
   Logic:"Puzzle Tutor",
   Nature:"Nature Guide",
   Health:"Health Guide",
   Music:"Music Guide",
   Copywork:"Scribe Mentor",
   LifeSkills:"Homestead Guide"
 };
 return tutors[subj] || "Realm Tutor";
}

function lessonModeLabel(L){
 if(L.mode) return L.mode;
 if(L.unit || L.skill) return "unit lesson";
 return "lesson";
}

function lessonIntroHtml(L, subj, idx, total){
 const mini = L.miniLesson || L.teach || "Study the lesson and choose the best answer.";
 const worked = L.workedExample || "";
 const guided = L.guidedPractice || L.practice || "Think it through carefully.";
 const tip = L.teacherTip || "";
 const tryThis = L.tryThis || "";
 const unit = L.unit || "General";
 const skill = L.skill || subj;
 const diff = L.difficulty || "core";
 const progressPct = total ? Math.min(100, Math.round(((idx + 1) / total) * 100)) : 0;

 return `<div class="lessonQuest">
   ${levelPanelHtml(state, activeChild)}
   <div class="lessonHero">
     <div class="lessonOrb">${lessonSubjectIcon(subj)}</div>
     <div>
       <div class="lessonKicker">${lrEscape(lessonTutorName(subj))} encounter</div>
       <h3>${lrEscape(subj)} Quest Lesson</h3>
       <div class="lessonBadges">
         <span>${lrEscape(lessonModeLabel(L))}</span>
         <span>${lrEscape(diff)}</span>
         <span>${lrEscape(skill)}</span>
       </div>
     </div>
   </div>

   <div class="lessonProgressWrap">
     <div class="lessonProgressLabel">
       <span>Lesson ${idx + 1} of ${total || "?"}</span>
       <span>${progressPct}% through this subject bank loop</span>
     </div>
     <div class="lessonProgressTrack"><div class="lessonProgressFill" style="width:${progressPct}%"></div></div>
   </div>

   <div class="lessonMetaGrid">
     <div><b>Unit</b><br>${lrEscape(unit)}</div>
     <div><b>Skill</b><br>${lrEscape(skill)}</div>
     <div><b>Streak</b><br>${state.streak || 0}</div>
     <div><b>Sparks</b><br>${state.sparks || 0}</div>
   </div>

   ${lessonSectionHtml("Mini Lesson", mini, "🏫")}
   ${lessonSectionHtml("Worked Example", worked, "🧩")}
   ${lessonSectionHtml("Guided Practice", guided, "🪜")}
   ${lessonSectionHtml("Teacher Tip", tip, "💡")}
   ${lessonSectionHtml("Try This First", tryThis, "🎯")}
 </div>`;
}

function lessonReviewText(L, correct){
 if(correct){
   return L.explain || L.explanation || L.why || L.correctExplain || "";
 }
 return L.review || L.hint || L.wrongExplain || L.explanation || "";
}

function showLessonResult(L, correct, message){
 const review = lessonReviewText(L, correct);
 const icon = correct ? "🏆" : "🛡️";
 const title = correct ? "Victory!" : "Try Again Training";
 const cls = correct ? "lessonResultWin" : "lessonResultReview";

 let html = `<div class="lessonResult ${cls}">
   <div class="lessonResultTitle">${icon} ${title}</div>
   <div>${lrEscape(message || "")}</div>`;

 if(review){
   html += `<div class="lessonExplain"><b>Explain Why:</b><br>${lrEscape(review)}</div>`;
 }else if(correct){
   html += `<div class="lessonExplain"><b>Explain Why:</b><br>You chose the answer that matches the lesson.</div>`;
 }else{
   html += `<div class="lessonExplain"><b>Review Hint:</b><br>Read the Mini Lesson and Worked Example again, then try another lesson.</div>`;
 }

 html += `<button class="nextLessonBtn" onclick="startLesson()">Next Lesson</button>
 </div>`;

 $("actionText").innerHTML += html;
}

function ensureUnitProgress(){
 if(!state.unitProgress) state.unitProgress = {};
 if(!state.unitProgress[activeChild]) state.unitProgress[activeChild] = {};
}

function recordLessonUnitProgress(lesson){
 if(!lesson || !lesson.unit) return;
 ensureUnitProgress();
 state.unitProgress[activeChild][lesson.unit] = (state.unitProgress[activeChild][lesson.unit] || 0) + 1;
}

function lessonChoiceLetter(i){
 return ["A","B","C","D","E"][i] || String(i+1);
}



function levelConfig(){
 return window.LR_LEVEL_CONFIG || {
   xpCurve:{base:100,growth:35,everyFiveBonus:75},
   xpAwards:{correctLesson:10,portfolioComplete:25,bossAttempt:15,bossWin:100,firstBossClearBonus:75},
   milestones:{},
   repeatingRewards:{everyLevel:{sparks:5},every5:{ancientCoins:1}}
 };
}

function ensureLevelingFor(profile, child){
 if(!profile.leveling) profile.leveling = {};
 if(!profile.leveling[child]){
   profile.leveling[child] = {
     level:1,
     xp:0,
     totalXp:0,
     title:"New Student",
     unlocked:[],
     levelUps:[],
     lastGain:null
   };
 }
 return profile.leveling[child];
}

function ensureLeveling(){
 return ensureLevelingFor(state, activeChild);
}

function xpNeededForLevel(level){
 const cfg = levelConfig();
 const curve = cfg.xpCurve || {};
 const base = curve.base || 100;
 const growth = curve.growth || 35;
 const everyFiveBonus = curve.everyFiveBonus || 75;
 return base + ((level - 1) * growth) + (Math.floor((level - 1) / 5) * everyFiveBonus);
}

function levelProgressPercent(profile, child){
 const lev = ensureLevelingFor(profile || state, child || activeChild);
 return Math.min(100, Math.round((lev.xp / xpNeededForLevel(lev.level)) * 100));
}

function grantLevelReward(newLevel){
 const cfg = levelConfig();
 const lev = ensureLeveling();
 const milestone = (cfg.milestones && cfg.milestones[newLevel]) ? cfg.milestones[newLevel] : null;
 const repeating = cfg.repeatingRewards || {};
 let messages = [];

 if(repeating.everyLevel && repeating.everyLevel.sparks){
   state.sparks = (state.sparks || 0) + repeating.everyLevel.sparks;
   messages.push("+" + repeating.everyLevel.sparks + " Sparks");
 }

 if(newLevel % 5 === 0 && repeating.every5 && repeating.every5.ancientCoins){
   state.ancientCoins = (state.ancientCoins || 0) + repeating.every5.ancientCoins;
   messages.push("+" + repeating.every5.ancientCoins + " Ancient Coin");
 }

 if(newLevel % 10 === 0 && repeating.every10 && repeating.every10.rewardPrefix){
   const reward = {name:repeating.every10.rewardPrefix + newLevel, slot:"shelf"};
   ensureHome().storage.push(reward);
   lev.unlocked.push(reward.name);
   messages.push("Unlocked " + reward.name);
 }

 if(milestone){
   if(milestone.title){
     lev.title = milestone.title;
     messages.push("Title: " + milestone.title);
   }
   if(milestone.ancientCoins){
     state.ancientCoins = (state.ancientCoins || 0) + milestone.ancientCoins;
     messages.push("+" + milestone.ancientCoins + " Ancient Coins");
   }
   if(milestone.reward){
     ensureHome().storage.push({...milestone.reward});
     lev.unlocked.push(milestone.reward.name);
     messages.push("Unlocked " + milestone.reward.name);
   }
   if(milestone.message){
     messages.push(milestone.message);
   }
 }

 lev.levelUps.push({level:newLevel,date:localDateKey(),time:new Date().toLocaleTimeString(),messages});
 addMemory(activeChild + " reached Level " + newLevel, messages.join(" | "));
 return messages;
}

function addXP(amount, reason){
 const lev = ensureLeveling();
 const gain = Math.max(0, Math.floor(amount || 0));
 if(!gain) return {gained:0, levelUps:[], message:""};

 lev.xp += gain;
 lev.totalXp += gain;
 lev.lastGain = {amount:gain, reason:reason || "Learning", time:new Date().toLocaleTimeString()};

 const levelUps = [];
 while(lev.xp >= xpNeededForLevel(lev.level)){
   lev.xp -= xpNeededForLevel(lev.level);
   lev.level++;
   const rewards = grantLevelReward(lev.level);
   levelUps.push({level:lev.level,rewards});
 }

 const message = "+" + gain + " XP" + (reason ? " for " + reason : "");
 return {gained:gain, levelUps, message};
}

function xpAward(name){
 const cfg = levelConfig();
 return (cfg.xpAwards && cfg.xpAwards[name]) ? cfg.xpAwards[name] : 0;
}

function levelPanelHtml(profile, child){
 const lev = ensureLevelingFor(profile || state, child || activeChild);
 const need = xpNeededForLevel(lev.level);
 const pct = levelProgressPercent(profile || state, child || activeChild);
 return `<div class="levelPanel">
   <div class="levelBadge">Lv ${lev.level}</div>
   <div class="levelInfo">
     <div><b>${lrEscape(child || activeChild)}</b> — ${lrEscape(lev.title || "Student Adventurer")}</div>
     <div class="levelBarTrack"><div class="levelBarFill" style="width:${pct}%"></div></div>
     <div class="levelTiny">${lev.xp} / ${need} XP to next level | Total XP: ${lev.totalXp || 0}</div>
   </div>
 </div>`;
}

function levelUpHtml(levelUps){
 if(!levelUps || !levelUps.length) return "";
 return levelUps.map(up=>{
   const rewards = (up.rewards || []).map(r=>`<div>✦ ${lrEscape(r)}</div>`).join("");
   return `<div class="levelUpBurst">
     <div class="levelUpTitle">LEVEL UP! Level ${up.level}</div>
     <div>${rewards || "New power unlocked."}</div>
   </div>`;
 }).join("");
}

function levelUnlockSummary(profile, child){
 const lev = ensureLevelingFor(profile, child);
 if(!lev.unlocked || !lev.unlocked.length) return "No level rewards unlocked yet.";
 return lev.unlocked.slice(-8).join(", ");
}

function levelGateMet(requiredLevel){
 const lev = ensureLeveling();
 return lev.level >= requiredLevel;
}

function startLesson(){
 const r=room(), subj=r.subject; if(!subj)return;
 if(typeof lrCanStartLearning === "function" && !window.__lrStartingFromInteract){
   const gate = lrCanStartLearning();
   if(!gate.ok){
     $("feedback").textContent = gate.msg;
     return;
   }
   lrReserveLearningAttempt();
 }
 ensureProgress();
 const list=((LESSONS[activeChild]||{})[subj])||[];
 if(!list.length){
   $("feedback").textContent="No lesson pack loaded for "+activeChild+" / "+subj+" yet.";
   return;
 }

 const idx=state.progress[activeChild][subj]%list.length;
 const L=list[idx];

 $("lessonBox").classList.remove("hidden");
 $("storageBox").classList.add("hidden");
 $("actionTitle").textContent=subj+" Lesson";
 $("actionText").innerHTML=lrWorldFlavor()+lessonIntroHtml(L, subj, idx, list.length);

 $("questionText").innerHTML=`<div class="questionBanner">
   <div class="questionTitle">Challenge Question</div>
   <div class="questionBody">${lrEscape(L.q)}</div>
 </div>`;

 $("choices").innerHTML="";
 (L.c || []).forEach((choice,i)=>{
   const b=document.createElement("button");
   b.className="choice";
   b.innerHTML=`<span class="choiceLetter">${lessonChoiceLetter(i)}</span><span>${lrEscape(choice)}</span>`;
   b.onclick=()=>answer(choice,L,subj,idx,b);
   $("choices").appendChild(b);
 });

 $("feedback").textContent="Choose wisely. Correct answers build mastery, Sparks, attendance records, and boss readiness.";
 lrMoveLessonIntoPopup();
}

function addReward(subj,idx){const list=REWARDS[subj]||[]; if(!list.length)return null; const reward=list[idx%list.length]; const h=ensureHome(); if(!h.storage.find(x=>x.name===reward.name))h.storage.push({...reward}); return reward;}
function answer(choice,L,subj,idx,btn){
 document.querySelectorAll(".choice").forEach(b=>b.disabled=true);

 if(choice===L.a){
   attendanceRecordAnswer(subj, true, "lesson", L.q);
   recordGameFunEvent("answers",1,{subject:subj});
   recordGameFunEvent("correctLessons",1,{subject:subj});
   recordGameFunEvent("subjectCorrect",1,{subject:subj});
   btn.classList.add("correct");
   ensureProgress();
   state.progress[activeChild][subj]++;
   recordLessonUnitProgress(L);
   state.sparks+=1;
   state.streak++;
   recordGameFunEvent("bestStreak",1,{streak:state.streak});

   const r=addReward(subj,idx);
   const masteryMsg = awardMasteryProgress(subj);
   const xp = addXP(xpAward("correctLesson"), "correct lesson");
   const treasureLine = rollTreasureDrop(subj,"lesson");
   const compLine = addCompanionXP((companionTrainingConfig().xp||{}).correctLesson || 3, "correct lesson", subj);
   const discoveryLine = checkCompanionDiscoveryRewards();
   const masteryLine = addSubjectMasteryXP(subj, (masteryPathConfig().xp||{}).correctLesson || 5, "correctLesson");
   const adaptiveLine = recordAdaptiveReviewAnswer(subj,true);
   const hardEarnedLine = (typeof lrRecordHardEarnedReward === 'function') ? lrRecordHardEarnedReward(subj) : '';
   const rewardLine = (r ? `Correct. +1 Spark. Found ${r.name}. ${xp.message}.` : `Correct. +1 Spark. ${xp.message}.`) + hardEarnedLine + treasureLine + compLine + discoveryLine + masteryLine + adaptiveLine;
   $("feedback").textContent = rewardLine + masteryMsg;
   showLessonResult(L, true, rewardLine + masteryMsg + levelUpHtml(xp.levelUps));

   state.log.push(`${activeChild} completed ${subj}: ${L.q}`);
   const t=lrUpdateTitle(subj); const ach=lrAchievementLine(); addMemory(`${activeChild} learned ${subj}`,L.q + (t?(" Title: "+t):"") + ach);
 }else{
   attendanceRecordAnswer(subj, false, "lesson", L.q);
   recordGameFunEvent("answers",1,{subject:subj});
   recordGameFunEvent("wrongAnswers",1,{subject:subj});
   btn.classList.add("wrong");
   state.streak=0;
   state.reviewQueue.push(L);
   const adaptiveWrongLine = recordAdaptiveReviewAnswer(subj,false);
   $("feedback").textContent="Not quite. Review saved." + adaptiveWrongLine;
   showLessonResult(L, false, "Not quite. This was saved for review." + adaptiveWrongLine);
 }

 save();
 renderStats();
}


/* Game Fun Pack 3: Treasure Drops & Level-Gated Shops */
function treasureShopConfig(){
 return window.LR_TREASURE_SHOP_CONFIG || {lessonDrops:[],bossDrops:[],pools:{general:[],boss:[],subjects:{}},shopStock:{}};
}

function activeLevel(){
 return ensureLevelingFor(state, activeChild).level || 1;
}

function shopCurrencyLabel(item){
 return item.currency === "ancientCoins" ? "Ancient Coins" : "Sparks";
}

function shopItemUnlocked(item){
 return !item.minLevel || activeLevel() >= item.minLevel;
}

function ownsHomeItem(name){
 const h = ensureHome();
 return !!((h.storage || []).find(x=>x && x.name === name) || Object.values(h.equip || {}).find(x=>x && x.name === name));
}

function extraShopStockFor(loc){
 const cfg = treasureShopConfig();
 return ((cfg.shopStock || {})[loc] || []).map(x=>Object.assign({source:"levelStock"}, x));
}

function baseShopItems(){
 if(state.loc==="seasonalShop") return (shopData.seasonal[currentFestival().season]||[]).map(name=>({name,cost:25,slot:name.toLowerCase().includes("rug")?"rug":name.toLowerCase().includes("picture")||name.toLowerCase().includes("banner")?"wall":"shelf",currency:"sparks",source:"base"}));
 if(state.loc==="pictureShop") return shopData.pictures.map(name=>({name,cost:20,slot:"wall",currency:"sparks",source:"base"}));
 if(state.loc==="luckyKettle") return shopData.diner.map(name=>({name,cost:15,slot:"food",currency:"sparks",source:"base",unique:false}));
 if(state.loc==="shiftyTent") return shopData.relics.map((name,i)=>({name,cost:[3,4,4,5,10][i]||3,slot:"shelf",currency:"ancientCoins",source:"base"}));
 return [];
}

function pickTreasureFromPool(poolName, subj){
 const cfg = treasureShopConfig();
 if(poolName === "subject"){
   const pool = ((cfg.pools || {}).subjects || {})[subj] || (cfg.pools || {}).general || [];
   return pool[Math.floor(Math.random()*pool.length)];
 }
 const pool = ((cfg.pools || {})[poolName] || (cfg.pools || {}).general || []);
 return pool[Math.floor(Math.random()*pool.length)];
}

function safeAddTreasureItem(item){
 if(!item || !item.name) return "";
 const h = ensureHome();
 if(ownsHomeItem(item.name)) return "Duplicate treasure shimmered away: " + item.name + ".";
 h.storage.push({name:item.name,slot:item.slot || "shelf"});
 return "Treasure found: " + item.name + ".";
}

function rollOneDrop(drop, subj){
 if(!drop || Math.random() >= drop.chance) return "";
 if(drop.type === "sparks"){
   state.sparks = (state.sparks || 0) + (drop.amount || 1);
   return " Bonus drop: " + drop.text + " +" + (drop.amount || 1) + " Sparks.";
 }
 if(drop.type === "ancientCoins"){
   state.ancientCoins = (state.ancientCoins || 0) + (drop.amount || 1);
   return " Rare drop: " + drop.text + " +" + (drop.amount || 1) + " Ancient Coin.";
 }
 if(drop.type === "item"){
   const msg = safeAddTreasureItem(pickTreasureFromPool(drop.pool || "general", subj));
   return msg ? " " + msg : "";
 }
 if(drop.type === "subjectItem"){
   const msg = safeAddTreasureItem(pickTreasureFromPool("subject", subj));
   return msg ? " " + msg : "";
 }
 return "";
}

function rollTreasureDrop(subj, source){
 const cfg = treasureShopConfig();
 const table = source === "boss" ? (cfg.bossDrops || []) : (cfg.lessonDrops || []);
 let text = "";
 table.forEach(drop=>{ text += rollOneDrop(drop, subj); });
 if(text.trim()){
   addMemory("Treasure Drop", activeChild + " found a bonus reward in " + subj + ": " + text.trim());
 }
 return text;
}

function treasureDropSummaryLine(){
 const cfg = treasureShopConfig();
 const lesson = (cfg.lessonDrops || []).map(d=>d.text).join(", ");
 const boss = (cfg.bossDrops || []).map(d=>d.text).join(", ");
 return "Lesson drops: " + lesson + ". Boss drops: " + boss + ".";
}
/* End Game Fun Pack 3 */



/* Game Fun Pack 2: Collection Log & Title Book */
function collectionConfig(){
 return window.LR_COLLECTION_CONFIG || {categories:[],starterTitles:[],completionRewards:[]};
}

function ensureCollectionFor(profile, child){
 if(!profile.collection) profile.collection = {};
 if(!profile.collection[child]){
   profile.collection[child] = {
     equippedTitle:"New Adventurer",
     claimedCompletionRewards:{},
     manualTitles:["New Adventurer"]
   };
 }
 const c = profile.collection[child];
 if(!c.claimedCompletionRewards) c.claimedCompletionRewards = {};
 if(!c.manualTitles) c.manualTitles = ["New Adventurer"];
 if(!c.equippedTitle) c.equippedTitle = "New Adventurer";
 return c;
}

function ensureCollection(){
 return ensureCollectionFor(state, activeChild);
}

function allHomeItemNames(profile, child){
 const h = (profile.homes && profile.homes[child]) ? profile.homes[child] : {storage:[],equip:{}};
 const names = new Set();
 (h.storage || []).forEach(x=>{ if(x && x.name) names.add(x.name); });
 Object.values(h.equip || {}).forEach(x=>{ if(x && x.name) names.add(x.name); });
 return Array.from(names).sort();
}

function discoveredRoomIds(profile, child){
 const gf = ensureGameFunFor(profile, child);
 const rooms = gf.totals.roomsEver || {};
 if(!rooms[profile.loc]) rooms[profile.loc] = true;
 return Object.keys(rooms);
}

function discoveredZones(profile, child){
 const zones = new Set();
 discoveredRoomIds(profile, child).forEach(id=>{
   if(ROOMS[id] && ROOMS[id].zone) zones.add(ROOMS[id].zone);
 });
 return Array.from(zones).sort();
}

function subjectNamesFor(child){
 return Object.keys(LESSONS[child] || {}).sort();
}

function subjectsWithCorrect(profile, child){
 const p = (profile.progress && profile.progress[child]) ? profile.progress[child] : {};
 return Object.keys(p).filter(s=>(p[s] || 0) > 0).sort();
}

function bossSubjectsCleared(profile, child){
 const wins = (profile.bossWins && profile.bossWins[child]) ? profile.bossWins[child] : {};
 return Object.keys(wins).filter(s=>!!wins[s]).sort();
}

function claimedAchievementTitles(profile, child){
 const cfg = gameFunConfig();
 const gf = ensureGameFunFor(profile, child);
 const claimed = gf.achievementsClaimed || {};
 return (cfg.achievements || []).filter(a=>claimed[a.id]).map(a=>a.title).sort();
}

function ladderRewardRecord(profile, child){
 if(!profile.gradeLadderRewards || !profile.gradeLadderRewards[child]){
   return {titles:[],badges:[],unlocks:[]};
 }
 const r = profile.gradeLadderRewards[child];
 return {
   titles:(r.titles || []).slice(),
   badges:(r.badges || []).slice(),
   unlocks:(r.unlocks || []).slice()
 };
}

function earnedCollectionTitles(profile, child){
 const cfg = collectionConfig();
 const col = ensureCollectionFor(profile, child);
 const gf = ensureGameFunFor(profile, child);
 const totals = gf.totals || {};
 const titles = new Set(col.manualTitles || ["New Adventurer"]);
 titles.add("New Adventurer");

 if((totals.answers || 0) >= 10) titles.add("Realm Learner");
 if((totals.correctLessons || 0) >= 25) titles.add("Steady Student");
 if((profile.room || totals.roomVisits || 0) >= 50) titles.add("Room Roamer");
 if(Object.keys(totals.subjectsEverCorrect || {}).length >= 5) titles.add("Subject Scout");
 if((totals.bossAttempts || 0) >= 1) titles.add("Boss Challenger");

 ladderRewardRecord(profile, child).titles.forEach(t=>titles.add(t));
 claimedAchievementTitles(profile, child).forEach(t=>titles.add(t));

 return Array.from(titles).sort();
}

function collectionSnapshot(profile, child){
 const totalSubjects = subjectNamesFor(child).length || 1;
 const subjects = subjectsWithCorrect(profile, child);
 const bossCleared = bossSubjectsCleared(profile, child);
 const totalBossSubjects = subjectNamesFor(child).filter(s=>((LESSONS[child] || {})[s] || []).length).length || 1;
 const items = allHomeItemNames(profile, child);
 const zones = discoveredZones(profile, child);
 const allZones = Array.from(new Set(Object.values(ROOMS).map(r=>r.zone).filter(Boolean))).sort();
 const achievements = claimedAchievementTitles(profile, child);
 const totalAchievements = (gameFunConfig().achievements || []).length || 1;
 const ladder = ladderRewardRecord(profile, child);
 const titles = earnedCollectionTitles(profile, child);
 const badges = ladder.badges || [];

 return {
   realms:{count:zones.length,total:allZones.length,items:zones},
   subjects:{count:subjects.length,total:totalSubjects,items:subjects},
   bosses:{count:bossCleared.length,total:totalBossSubjects,items:bossCleared},
   items:{count:items.length,total:Math.max(items.length, 1),items},
   achievements:{count:achievements.length,total:totalAchievements,items:achievements},
   titles:{count:titles.length,total:Math.max(titles.length,1),items:titles},
   badges:{count:badges.length,total:Math.max(badges.length,1),items:badges}
 };
}

function collectionPercent(entry){
 if(!entry || !entry.total) return 0;
 return Math.min(100, Math.round((entry.count / entry.total) * 100));
}

function collectionCardHtml(cat, snap){
 const entry = snap[cat.id] || {count:0,total:1,items:[]};
 const pct = collectionPercent(entry);
 const listed = entry.items && entry.items.length ? entry.items.map(x=>`<span class="collectionChip">${lrEscape(x)}</span>`).join("") : "<span class='collectionMuted'>Nothing collected here yet.</span>";
 return `<div class="collectionCard">
   <div class="collectionHeader"><span class="collectionIcon">${cat.icon}</span><b>${lrEscape(cat.title)}</b><span>${entry.count} / ${entry.total}</span></div>
   <div class="collectionDesc">${lrEscape(cat.desc || "")}</div>
   <div class="collectionTrack"><div class="collectionFill" style="width:${pct}%"></div></div>
   <div class="collectionList">${listed}</div>
 </div>`;
}

function equipCollectionTitle(title){
 const col = ensureCollection();
 const titles = earnedCollectionTitles(state, activeChild);
 if(!titles.includes(title)){
   $("feedback").textContent = "That title is not unlocked yet.";
   return;
 }
 col.equippedTitle = title;
 $("feedback").textContent = "Equipped title: " + title;
 save();
 openCollectionLog();
 renderStats();
}

function titleButtonsHtml(){
 const col = ensureCollection();
 const titles = earnedCollectionTitles(state, activeChild);
 return titles.map(t=>{
   const on = col.equippedTitle === t;
   return `<button class="${on ? "titleEquipped" : ""}" onclick="equipCollectionTitle('${lrEscape(t).replace(/'/g,"&#39;")}')">${on ? "✓ " : ""}${lrEscape(t)}</button>`;
 }).join("");
}

function collectionCompletionProgress(category){
 const snap = collectionSnapshot(state, activeChild);
 const e = snap[category];
 return e ? e.count : 0;
}

function claimCollectionCompletionReward(id){
 const cfg = collectionConfig();
 const rewardDef = (cfg.completionRewards || []).find(x=>x.id === id);
 const col = ensureCollection();
 if(!rewardDef) return;
 const progress = collectionCompletionProgress(rewardDef.category);
 if(progress < rewardDef.target){
   $("feedback").textContent = "Collection reward not ready yet.";
   return;
 }
 if(col.claimedCompletionRewards[id]){
   $("feedback").textContent = "Collection reward already claimed.";
   return;
 }
 col.claimedCompletionRewards[id] = true;
 if(rewardDef.title){
   col.manualTitles.push(rewardDef.title);
 }
 const msg = grantGameFunReward(rewardDef.reward, "collection reward");
 addMemory("Collection Reward: " + rewardDef.title, msg);
 $("feedback").textContent = "Collection reward claimed: " + rewardDef.title + ". " + msg;
 save();
 openCollectionLog();
 renderStats();
}

function collectionRewardsHtml(){
 const cfg = collectionConfig();
 const col = ensureCollection();
 const snap = collectionSnapshot(state, activeChild);
 return (cfg.completionRewards || []).map(r=>{
   const progress = snap[r.category] ? snap[r.category].count : 0;
   const pct = Math.min(100, Math.round((progress / r.target) * 100));
   const ready = progress >= r.target;
   const claimed = !!col.claimedCompletionRewards[r.id];
   const btn = claimed ? "<button disabled>Claimed</button>" : ready ? `<button onclick="claimCollectionCompletionReward('${r.id}')">Claim Collection Reward</button>` : "<button disabled>Locked</button>";
   return `<div class="collectionCard ${ready ? "collectionReady" : ""}">
     <div class="collectionHeader"><span>🎁</span><b>${lrEscape(r.title)}</b><span>${progress} / ${r.target}</span></div>
     <div class="collectionDesc">Collect ${r.target} ${lrEscape(r.category)} entries. Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
     <div class="collectionTrack"><div class="collectionFill" style="width:${pct}%"></div></div>
     ${btn}
   </div>`;
 }).join("");
}

function collectionSummaryLine(profile, child){
 const snap = collectionSnapshot(profile || state, child || activeChild);
 return `${snap.realms.count} realms discovered, ${snap.subjects.count} subjects started, ${snap.bosses.count} bosses cleared, ${snap.items.count} treasures, ${snap.titles.count} titles.`;
}

function openCollectionLog(){
 attendanceTick(true);
 const cfg = collectionConfig();
 const snap = collectionSnapshot(state, activeChild);
 const col = ensureCollection();

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Collection Log";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">📖 ${lrEscape(activeChild)}'s Collection Book</div>
   <div class="lessonCardText">${lrEscape(collectionSummaryLine(state, activeChild))}<br><br><b>Equipped title:</b> ${lrEscape(col.equippedTitle)}</div>
 </div>`;

 $("storageItems").innerHTML =
   `<h3>Equip a Title</h3><div class="titleButtonRow">${titleButtonsHtml()}</div>` +
   `<h3>Collection Rewards</h3>${collectionRewardsHtml()}` +
   `<h3>Collection Categories</h3>` +
   (cfg.categories || []).map(cat=>collectionCardHtml(cat,snap)).join("");
}
/* End Game Fun Pack 2 */

function openQuestBoard(){
 attendanceTick(true);
 const cfg = gameFunConfig();
 const daily = currentDailyQuestBucket(state, activeChild);
 const weekly = currentWeeklyQuestBucket(state, activeChild);
 const gf = ensureGameFunFor(state, activeChild);

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent="Quest Board";
 $("actionText").innerHTML=`<div class="lessonCard">
   <div class="lessonCardTitle">📜 Claimable Daily Quests</div>
   <div class="lessonCardText">${lrEscape(questSummaryLine())}</div>
 </div>`;

 $("storageItems").innerHTML =
   "<h3>Daily Quests</h3>" +
   (cfg.dailyQuests || []).map(q=>questCardHtml(q,daily,"claimDailyQuest")).join("") +
   "<h3>Weekly Quests</h3>" +
   (cfg.weeklyQuests || []).map(q=>questCardHtml(q,weekly,"claimWeeklyQuest")).join("") +
   "<h3>Achievements</h3>" +
   (cfg.achievements || []).map(a=>achievementCardHtml(a,gf)).join("") +
   "<h3>Classroom Plan</h3>" +
   dailyPlanHtml(activeChild) +
   "<h3>Family Quests</h3><div>Visit Family Hall</div><div>Decorate Home</div><div>Check Companion</div><div>Attend Festival</div>";
}

function recordMoonClue(){
 ensureMystery();
 const c=moonClues[state.loc]; if(!c)return;
 const already=!!state.mystery.moonStair[c.id]; state.mystery.moonStair[c.id]=true;
 $("actionTitle").textContent="Moon Stair Clue Found";
 $("actionText").textContent=c.name+"\n\n"+c.clue+"\n\nAlder's note:\n"+c.hint+"\n\nReturn to the Historical Society to review the Investigation Board.";
 $("feedback").textContent=already?"This clue was already recorded.":"New clue recorded.";
 if(!already) addMemory("Moon Stair Clue: "+c.name,c.clue);
 save(); renderStats();
}
function openInvestigationBoard(){
 ensureMystery();
 const all=Object.values(moonClues); const found=all.filter(c=>state.mystery.moonStair[c.id]).length;
 $("lessonBox").classList.add("hidden"); $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent="Investigation Board";
 let theory="Alder says: The castle is sealed, and the old stories speak of five realms. But I think something is missing.";
 if(found>=3) theory="Alder says: The Moon Stair may be a sixth path that was hidden before the castle was sealed.";
 if(found===all.length) theory="Alder says: The clues agree. The Moon Stair was real. Moonrise Heights remains the next big mystery.";
 $("actionText").textContent=`Mystery Quest: The Moon Stair\n\nGoal:\nFind clues about the hidden sixth path.\n\nClues Found: ${found} / ${all.length}\n\n${theory}`;
 $("storageItems").innerHTML="<h3>Moon Stair Clues</h3>"+all.map(c=>`<div>${state.mystery.moonStair[c.id]?"✓":"□"} ${c.name}</div>`).join("")+"<h3>What To Do Next</h3><div>Explore clue rooms and use Record Moon Stair Clue when you find something strange.</div>";
}


/* Game Fun Pack 4: Companion Training & Bonding */
function companionTrainingConfig(){
 return window.LR_COMPANION_TRAINING_CONFIG || {xp:{},levelRewards:[],tricks:[],moods:["Happy"],childFlavor:{},subjectDiscoveryRewards:[]};
}

function companionBase(child){
 return COMPANIONS[child] || {name:"Study Companion",stages:["A friendly companion waits nearby."],abilities:["Encouragement"],home:"Companion Corner"};
}

function ensureCompanionTrainingFor(profile, child){
 if(!profile.companionTraining) profile.companionTraining = {};
 if(!profile.companionTraining[child]){
   profile.companionTraining[child] = {
     level:1,
     xp:0,
     totalXp:0,
     bond:0,
     lastCareDate:"",
     careToday:{},
     subjectDiscoveries:{},
     claimedDiscoveryRewards:{},
     equippedTrick:"Encourage"
   };
 }
 const c = profile.companionTraining[child];
 if(!c.careToday) c.careToday = {};
 if(!c.subjectDiscoveries) c.subjectDiscoveries = {};
 if(!c.claimedDiscoveryRewards) c.claimedDiscoveryRewards = {};
 if(!c.equippedTrick) c.equippedTrick = "Encourage";
 return c;
}

function ensureCompanionTraining(){
 return ensureCompanionTrainingFor(state, activeChild);
}

function companionXpNeeded(level){
 return 20 + (level * 15);
}

function resetCompanionCareIfNeeded(c){
 const today = localDateKey();
 if(c.lastCareDate !== today){
   c.lastCareDate = today;
   c.careToday = {};
 }
}

function companionMood(){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 const moods = cfg.moods || ["Happy"];
 return moods[(c.bond + c.level + (state.sparks || 0)) % moods.length] || "Happy";
}

function companionUnlockedTricks(profile, child){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTrainingFor(profile || state, child || activeChild);
 return (cfg.tricks || []).filter(t=>c.level >= t.level);
}

function companionRewardForLevel(level){
 const cfg = companionTrainingConfig();
 return (cfg.levelRewards || []).find(r=>r.level === level);
}

function grantCompanionLevelReward(level){
 const def = companionRewardForLevel(level);
 if(!def) return "";
 const msg = grantGameFunReward(def.reward, "companion level " + level);
 const col = ensureCollection();
 if(def.title && col.manualTitles && !col.manualTitles.includes(def.title)) col.manualTitles.push(def.title);
 addMemory("Companion Level " + level, companionBase(activeChild).name + " unlocked " + (def.title || "a new bond reward") + ". " + msg);
 return " Companion Level " + level + " reward: " + (def.title || "Reward") + ". " + msg;
}

function addCompanionXP(amount, reason, subj){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 const gain = Math.max(0, Math.floor(amount || 0));
 if(!gain) return "";
 c.xp += gain;
 c.totalXp += gain;
 if(subj){
   c.subjectDiscoveries[subj] = (c.subjectDiscoveries[subj] || 0) + 1;
 }
 let text = " +" + gain + " Companion XP";
 const ups = [];
 while(c.xp >= companionXpNeeded(c.level)){
   c.xp -= companionXpNeeded(c.level);
   c.level++;
   ups.push(c.level);
 }
 if(ups.length){
   text += " | " + companionBase(activeChild).name + " reached Level " + c.level + "!";
   ups.forEach(level=>{ text += grantCompanionLevelReward(level); });
 }
 return text;
}

function companionProgressBar(){
 const c = ensureCompanionTraining();
 const need = companionXpNeeded(c.level);
 const pct = Math.min(100, Math.round((c.xp / need) * 100));
 return `<div class="companionTrack"><div class="companionFill" style="width:${pct}%"></div></div><div class="questMeta">${c.xp} / ${need} Companion XP</div>`;
}

function companionDiscoveryCount(){
 const c = ensureCompanionTraining();
 return Object.keys(c.subjectDiscoveries || {}).length;
}

function companionSubjectDiscoveryHtml(){
 const c = ensureCompanionTraining();
 const subs = Object.keys(c.subjectDiscoveries || {}).sort();
 if(!subs.length) return "<div class='collectionMuted'>No subject discoveries yet. Correct answers will teach your companion about each subject.</div>";
 return subs.map(s=>`<span class="collectionChip">${lrEscape(s)} × ${c.subjectDiscoveries[s]}</span>`).join("");
}

function checkCompanionDiscoveryRewards(){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 const count = companionDiscoveryCount();
 let unlocked = "";
 (cfg.subjectDiscoveryRewards || []).forEach((r,idx)=>{
   const id = "discover_" + r.count + "_" + idx;
   if(count >= r.count && !c.claimedDiscoveryRewards[id]){
     c.claimedDiscoveryRewards[id] = true;
     unlocked += " " + grantGameFunReward(r.reward, "companion subject discovery");
     addMemory("Companion Discovery Reward", companionBase(activeChild).name + " learned from " + count + " subjects. " + unlocked);
   }
 });
 return unlocked;
}

function companionTrickButtonsHtml(){
 const c = ensureCompanionTraining();
 const tricks = companionUnlockedTricks(state, activeChild);
 return tricks.map(t=>{
   const on = c.equippedTrick === t.name;
   return `<button class="${on ? "titleEquipped" : ""}" onclick="equipCompanionTrick('${lrEscape(t.name).replace(/'/g,"&#39;")}')">${on ? "✓ " : ""}${lrEscape(t.name)}</button>`;
 }).join("");
}

function equipCompanionTrick(name){
 const c = ensureCompanionTraining();
 const tricks = companionUnlockedTricks(state, activeChild).map(t=>t.name);
 if(!tricks.includes(name)){
   $("feedback").textContent = "That trick is not unlocked yet.";
   return;
 }
 c.equippedTrick = name;
 $("feedback").textContent = companionBase(activeChild).name + " equipped trick: " + name + ".";
 save();
 openCompanionDen();
}

function companionAction(kind){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 resetCompanionCareIfNeeded(c);
 if(c.careToday[kind]){
   $("feedback").textContent = "Already used that companion action today.";
   return;
 }
 c.careToday[kind] = true;
 let text = "";
 if(kind === "train"){
   c.bond += 2;
   text = "You train together. " + addCompanionXP((cfg.xp || {}).train || 8, "companion training");
 }
 if(kind === "play"){
   c.bond += 3;
   text = "You play together for a little while. " + addCompanionXP((cfg.xp || {}).play || 4, "companion play");
 }
 if(kind === "feed"){
   c.bond += 2;
   const flavor = ((cfg.childFlavor || {})[activeChild] || {}).favorite || "favorite snack";
   text = companionBase(activeChild).name + " enjoys " + flavor + ". " + addCompanionXP((cfg.xp || {}).feed || 3, "companion care");
 }
 $("feedback").textContent = text;
 addMemory("Companion Care", text);
 save();
 openCompanionDen();
 renderStats();
}

function trainCompanion(){ companionAction("train"); }
function playCompanion(){ companionAction("play"); }
function feedCompanion(){ companionAction("feed"); }

function askCompanion(){
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 resetCompanionCareIfNeeded(c);
 const flavor = ((cfg.childFlavor || {})[activeChild] || {});
 const list = flavor.advice || ["Keep going. Think carefully."];
 const subj = room().subject || "Adventure";
 const text = list[(c.level + subj.length + (state.streak || 0)) % list.length];
 if(!c.careToday.askAdvice){
   c.careToday.askAdvice = true;
   addCompanionXP((cfg.xp || {}).askAdvice || 1, "asking companion advice");
 }
 $("actionTitle").textContent = companionBase(activeChild).name + "'s Advice";
 $("actionText").textContent = text + "\n\nCurrent trick: " + c.equippedTrick + "\nMood: " + companionMood();
 $("feedback").textContent = "Companion advice received.";
 save();
 renderStats();
}

function petCompanion(){
 const c = ensureCompanionTraining();
 resetCompanionCareIfNeeded(c);
 if(c.careToday.pet){
   $("feedback").textContent = "Already bonded this way today.";
 }else{
   c.careToday.pet = true;
   c.bond += 1;
   $("feedback").textContent = companionBase(activeChild).name + " is happier. Bond +1.";
   addMemory("Companion Bond", companionBase(activeChild).name + " spent time with " + activeChild + ".");
   save();
 }
 $("actionTitle").textContent = "Companion";
 $("actionText").textContent = `${companionBase(activeChild).name} looks ${companionMood().toLowerCase()}.\n\nBond: ${c.bond}\nLevel: ${c.level}\nEquipped trick: ${c.equippedTrick}`;
 renderStats();
}

function checkCompanion(){
 openCompanionDen();
}

function companionSummaryLine(profile, child){
 const c = ensureCompanionTrainingFor(profile || state, child || activeChild);
 const base = companionBase(child || activeChild);
 return `${base.name}: Level ${c.level}, Bond ${c.bond}, Trick ${c.equippedTrick}, ${Object.keys(c.subjectDiscoveries || {}).length} subject discoveries`;
}

function openCompanionDen(){
 attendanceTick(true);
 const cfg = companionTrainingConfig();
 const c = ensureCompanionTraining();
 resetCompanionCareIfNeeded(c);
 const base = companionBase(activeChild);
 const flavor = ((cfg.childFlavor || {})[activeChild] || {});
 const den = flavor.den || base.home || "Companion Den";
 const trickList = companionUnlockedTricks(state, activeChild).map(t=>`<div><b>${lrEscape(t.name)}</b> — ${lrEscape(t.desc)}</div>`).join("");

 $("lessonBox").classList.add("hidden");
 $("storageBox").classList.remove("hidden");
 $("actionTitle").textContent = "Companion Den";
 $("actionText").innerHTML = `<div class="lessonCard">
   <div class="lessonCardTitle">🐾 ${lrEscape(den)}</div>
   <div class="lessonCardText">
     <b>${lrEscape(base.name)}</b><br>
     Level ${c.level} companion | Bond ${c.bond} | Mood: ${lrEscape(companionMood())}<br>
     Equipped trick: <b>${lrEscape(c.equippedTrick)}</b><br>
     ${companionProgressBar()}
   </div>
 </div>`;

 $("storageItems").innerHTML =
   `<h3>Daily Companion Care</h3>
    <div class="companionButtons">
      <button onclick="trainCompanion()" ${c.careToday.train ? "disabled" : ""}>Train</button>
      <button onclick="playCompanion()" ${c.careToday.play ? "disabled" : ""}>Play</button>
      <button onclick="feedCompanion()" ${c.careToday.feed ? "disabled" : ""}>Feed</button>
      <button onclick="petCompanion()" ${c.careToday.pet ? "disabled" : ""}>Pet / Bond</button>
      <button onclick="askCompanion()">Ask Advice</button>
    </div>
    <h3>Equip Companion Trick</h3>
    <div class="titleButtonRow">${companionTrickButtonsHtml()}</div>
    <h3>Unlocked Tricks</h3>
    <div class="collectionCard">${trickList || "No tricks unlocked yet."}</div>
    <h3>Subject Discoveries</h3>
    <div class="collectionCard">${companionSubjectDiscoveryHtml()}</div>
    <h3>Level Rewards</h3>
    ${(cfg.levelRewards || []).map(r=>`<div class="collectionCard ${c.level >= r.level ? "collectionReady" : ""}">
      <div class="collectionHeader"><span>🐾</span><b>Level ${r.level}: ${lrEscape(r.title)}</b><span>${c.level >= r.level ? "Unlocked" : "Locked"}</span></div>
      <div class="collectionDesc">Reward: ${lrEscape(rewardTextFor(r.reward))}</div>
    </div>`).join("")}`;
}
/* End Game Fun Pack 4 */



/* Stability Pack 1.4: right-side panel render helper repair */
function lrMiniItemName(item){
 if(!item) return "Empty";
 if(typeof item === "string") return item;
 return item.name || "Unnamed Item";
}

function renderHomeSlots(){
 try{
   const box = $("homeSlots");
   if(!box) return;
   const h = ensureHome();
   const eq = h.equip || {};
   const slots = ["wall","shelf","desk","table","rug","pet1","pet2","food","hat","cloak","accessory","held"];
   box.innerHTML = slots.map(slot=>{
     const item = eq[slot];
     return `<div class="minirow"><b>${lrEscape(slot)}</b><br>${lrEscape(lrMiniItemName(item))}</div>`;
   }).join("");
 }catch(err){
   LR_lastSystemError = "renderHomeSlots failed: " + (err && err.message ? err.message : err);
   try{$("homeSlots").innerHTML = "<small>Home slots could not render. Open System Health.</small>";}catch(e){}
 }
}

function renderInventory(){
 try{
   const box = $("inventory");
   if(!box) return;
   const inv = Array.isArray(state.inventory) ? state.inventory : [];
   if(!inv.length){
     box.innerHTML = "<small>No carried inventory yet.</small>";
     return;
   }
   box.innerHTML = inv.slice(-12).map(x=>`<div class="minirow">${lrEscape(lrMiniItemName(x))}</div>`).join("");
 }catch(err){
   LR_lastSystemError = "renderInventory failed: " + (err && err.message ? err.message : err);
   try{$("inventory").innerHTML = "<small>Inventory could not render.</small>";}catch(e){}
 }
}

function renderMemoryBook(){
 try{
   const box = $("memoryBook");
   if(!box) return;
   const mem = Array.isArray(state.memoryBook) ? state.memoryBook : [];
   if(!mem.length){
     box.innerHTML = "<small>No memories recorded yet.</small>";
     return;
   }
   box.innerHTML = mem.slice(-8).reverse().map(m=>{
     if(typeof m === "string") return `<div class="minirow">${lrEscape(m)}</div>`;
     const title = m.title || m.kind || "Memory";
     const text = m.text || m.note || m.message || "";
     return `<div class="minirow"><b>${lrEscape(title)}</b><br>${lrEscape(String(text).slice(0,120))}</div>`;
   }).join("");
 }catch(err){
   LR_lastSystemError = "renderMemoryBook failed: " + (err && err.message ? err.message : err);
   try{$("memoryBook").innerHTML = "<small>Memory Book could not render.</small>";}catch(e){}
 }
}

function renderLearningLog(){
 try{
   const box = $("learningLog") || $("log");
   if(!box) return;
   const log = Array.isArray(state.log) ? state.log : [];
   if(!log.length){
     box.innerHTML = "<small>No learning log entries yet.</small>";
     return;
   }
   box.innerHTML = log.slice(-8).reverse().map(entry=>{
     if(typeof entry === "string") return `<div class="minirow">${lrEscape(entry)}</div>`;
     const title = entry.title || entry.subject || entry.kind || "Log";
     const text = entry.text || entry.note || entry.message || entry.q || "";
     return `<div class="minirow"><b>${lrEscape(title)}</b><br>${lrEscape(String(text).slice(0,120))}</div>`;
   }).join("");
 }catch(err){
   LR_lastSystemError = "renderLearningLog failed: " + (err && err.message ? err.message : err);
   try{(($("learningLog") || $("log")).innerHTML = "<small>Learning Log could not render.</small>");}catch(e){}
 }
}
/* End Stability Pack 1.4 */


function lrSafeRenderPanels(){
 const fns = [
   ["Home Slots", typeof renderHomeSlots === "function" ? renderHomeSlots : null],
   ["Inventory", typeof renderInventory === "function" ? renderInventory : null],
   ["Memory Book", typeof renderMemoryBook === "function" ? renderMemoryBook : null],
   ["Learning Log", typeof renderLearningLog === "function" ? renderLearningLog : null]
 ];
 fns.forEach(pair=>{
   try{
     if(pair[1]) pair[1]();
   }catch(err){
     LR_lastSystemError = pair[0] + " render failed: " + (err && err.message ? err.message : err);
   }
 });
}

/* Stability Pack 1.4: render placeholders */

function entries(){
 LR_lastSystemError = "Render helper unavailable: entries";
}

function join(){
 LR_lastSystemError = "Render helper unavailable: join";
}

function map(){
 LR_lastSystemError = "Render helper unavailable: map";
}

function min(){
 LR_lastSystemError = "Render helper unavailable: min";
}

function reverse(){
 LR_lastSystemError = "Render helper unavailable: reverse";
}

function slice(){
 LR_lastSystemError = "Render helper unavailable: slice";
}


/* Gameplay Pack 1B: Mastery Titles + Long Journey */
const LR_TITLE_PATHS={
Logic:[["Logic Apprentice",25],["Puzzle Solver",75],["Riddle Keeper",150]],
Nature:[["Nature Walker",25],["Naturalist",75],["Keeper of the Wilds",150]],
Writing:[["Scribe",25],["Story Keeper",75],["Master Chronicler",150]],
Economics:[["Market Helper",25],["Merchant Scholar",75],["Coin Sage",150]]
};

function lrEnsureJourney(){
 if(!state.longJourney) state.longJourney={titles:{},achievements:{}};
 return state.longJourney;
}

function lrUpdateTitle(subj){
 const p=(state.progress[activeChild]||{})[subj]||0;
 const path=LR_TITLE_PATHS[subj]||[];
 let t="";
 path.forEach(x=>{if(p>=x[1]) t=x[0];});
 if(t){lrEnsureJourney().titles[activeChild]=t;}
 return t;
}

function lrAchievementLine(){
 const total=totalProgress(activeChild);
 let out="";
 if(total>=100 && !lrEnsureJourney().achievements.satchel){lrEnsureJourney().achievements.satchel=true;out+=" Scholar Satchel unlocked.";}
 if(total>=500 && !lrEnsureJourney().achievements.banner){lrEnsureJourney().achievements.banner=true;ensureHome().storage.push({name:"Hall Banner"});out+=" Hall Banner earned.";}
 if(total>=1000 && !lrEnsureJourney().achievements.castle){lrEnsureJourney().achievements.castle=true;ensureHome().storage.push({name:"Castle Foundation Token"});out+=" Castle Foundation Token earned.";}
 return out;
}


/* Stability Pass 1 */
function lrSystemCheck(){
 let issues=[];
 if(typeof lrStartInteraction!=="function") issues.push("Interact loop missing");
 if(!state.progress[activeChild]) issues.push("Progress missing");
 if(!state.homes[activeChild]) ensureHome();
 return issues.length?issues.join(", "):"Stable";
}

function renderStats(){
 ensureProgress();
 $("roomNumber").textContent=state.room+" / 500"; $("sparks").textContent=state.sparks; $("streak").textContent=state.streak; $("zoneName").textContent=room().zone;
 if($("coins")) $("coins").textContent=state.coins||0;
 if($("seasonToken")) $("seasonToken").textContent=currentFestival().season;
 renderHomeSlots();
 if($("title")) $("title").textContent=(lrEnsureJourney().titles[activeChild]||"Student Adventurer");
 $("inventory").innerHTML=state.inventory.length?state.inventory.map(i=>`<div class="inventoryitem">${i.name}</div>`).join(""):"<div class='inventoryitem'>No items collected yet.</div>";
 $("progress").innerHTML=`<div class="progitem"><b>System Health</b><br>${lrEscape(systemHealthSummaryLine())}<br>Stability: ${lrEscape(lrSystemCheck())}</div>`+`<div class="progitem"><b>Companion</b><br>${lrEscape(companionSummaryLine(state, activeChild))}</div>`+levelPanelHtml(state, activeChild)+Object.entries(state.progress[activeChild]||{}).map(([s,n])=>`<div class="progitem"><b>${s}</b>: ${n}<br>Rank: ${masteryRank(s)}<br>Boss: ${(state.bossWins&&state.bossWins[activeChild]&&state.bossWins[activeChild][s])?"Cleared":(n>=25?"Ready":"Locked")}</div>`).join("")+`<div class="progitem"><b>Campaign</b><br>${CAMPAIGNS[activeChild]?.title||""}<br>${CAMPAIGNS[activeChild]?.chapters?.[Math.min(stage(),CAMPAIGNS[activeChild].chapters.length-1)]||""}</div>`;
 $("memoryBook").innerHTML=state.memoryBook.length?state.memoryBook.slice(-5).reverse().map(m=>`<div class="memoryitem"><b>${m.title}</b><br>${m.date}</div>`).join(""):"<div class='memoryitem'>No memories yet.</div>";
 $("log").innerHTML=state.log.length?state.log.slice(-8).reverse().map(x=>`<div class="logitem">${x}</div>`).join(""):"<div class='logitem'>No lessons completed yet.</div>";
 save();
}

function switchChild(){attendanceTick(true); save(); activeChild=$("studentSelect").value; if(!allProfiles[activeChild])allProfiles[activeChild]=DEFAULT_PROFILE_STATE(); state=LR_repairProfile(allProfiles[activeChild], activeChild); allProfiles[activeChild]=state; localStorage.setItem(LR_ACTIVE_CHILD_STORAGE_KEY,activeChild); $("feedback").textContent=activeChild+"'s profile loaded."; LR_attendanceLastTick=Date.now(); markAttendanceLogin(); renderRoom();}
function resetChild(){if(confirm("Reset "+activeChild+"?")){allProfiles[activeChild]=DEFAULT_PROFILE_STATE(); state=allProfiles[activeChild]; save(); renderRoom();}}
function renderParentDashboard(){
 attendanceTick(true);
 let html = "";

 ["Luna","Ava","Michael"].forEach(name=>{
   const p = allProfiles[name] || DEFAULT_PROFILE_STATE();
   const cfgWrap = gradeConfig(name);
   const cfg = cfgWrap.cfg || {};
   const overall = gradeOverall(p, name);
   const boss = parentBossSummary(p, name);
   const progress = (p.progress && p.progress[name]) ? p.progress[name] : {};
   const totalCorrect = Object.values(progress).reduce((a,b)=>a+(b||0),0);
   const totalLoaded = Object.values((LESSONS[name] || {})).reduce((a,b)=>a+(b||[]).length,0);
   const weak = parentWeakSubjects(p,name);
   const rec = parentRecommendedSubject(p,name);

   html += `<div class="dashitem">
     <h3>${name} — ${cfg.gradeLabel || "Grade Core"}</h3>
     <p>
       <b>Overall grade progress:</b> ${overall.percent}% (${overall.earned} / ${overall.possible})<br>
       <b>Level / XP:</b> ${ensureLevelingFor(p,name).level} — ${ensureLevelingFor(p,name).title || "Student Adventurer"} — ${ensureLevelingFor(p,name).totalXp || 0} total XP<br>
       <b>Level unlocks:</b> ${levelUnlockSummary(p,name)}<br>
       <b>Collection summary:</b> ${collectionSummaryLine(p,name)}<br>
       <b>Companion:</b> ${companionSummaryLine(p,name)}<br>
       <b>Random events:</b> ${eventLogSummaryLine(p,name)}<br>
       <b>Mastery:</b> ${masterySummaryLine(p,name)}<br>
       <b>Report center:</b> ${schoolReportSummaryLine(p,name)}<br>
       <b>Class schedule:</b> ${classroomScheduleSummaryLine(p,name)}<br>
       <b>Story campaign:</b> ${storyCampaignSummaryLine(p,name)}<br>
       <b>Adaptive review:</b> ${adaptiveSummaryLine(p,name)}<br>
       <b>Boss gauntlet:</b> ${bossGauntletSummaryLine(p,name)}<br>
       <b>World atlas:</b> ${worldAtlasSummaryLine(p,name)}<br>
       <b>System health:</b> ${systemHealthSummaryLine()}<br>
       <b>Equipped title:</b> ${ensureCollectionFor(p,name).equippedTitle}<br>
       <b>Total correct answers:</b> ${totalCorrect}<br>
       <b>Loaded question bank:</b> ${totalLoaded} lessons/questions and expandable<br>
       <b>Sparks:</b> ${p.sparks || 0}<br>
       <b>Ancient Coins:</b> ${p.ancientCoins || 0}<br>
       <b>Bosses ready:</b> ${boss.ready}<br>
       <b>Bosses cleared:</b> ${boss.cleared} / ${boss.total}<br>
       <b>Weakest subjects:</b> ${weak}<br>
       <b>Recommended next subject:</b> ${rec}<br>
       <b>Long goal:</b> ${cfg.longGoal || "Keep building the grade core."}
     </p>

     <h3>Attendance / Time Today</h3>
     ${attendanceReportHtml(p,name)}

     <table style="width:100%;border-collapse:collapse;margin-top:10px;">
       <thead>
         <tr>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Subject</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Correct / Target</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Grade %</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Loaded</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Rank</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Boss</th>
           <th style="text-align:left;border-bottom:1px solid rgba(255,255,255,.2);">Status</th>
         </tr>
       </thead>
       <tbody>
         ${parentSubjectRows(p,name)}
       </tbody>
     </table>

     <div style="margin-top:10px;">
       ${dailyPlanHtml(name)}
       <h3>Recent Problems Solved Today</h3>
       ${attendanceLogHtml(p,name)}
     </div>
   </div>`;
 });

 html += `<div class="dashitem">
   <h3>Classroom + Attendance Notes</h3>
   <p>
     The game now tracks attendance, visible active game time, login count, first login, last seen, per-subject attempts, correct answers, wrong answers, boss attempts, recent solved problems, parent notes, and exportable CSV reports.<br><br>
     Daily time goal is stored in <b>data/classroom-config.js</b>. It is currently set to a 360-minute simulated classroom day and can be changed later without rewriting the engine.
   </p>
   <p>
     Grade progress is target-based and expandable. New subjects from future curriculum packs display automatically. Targets live in <b>data/grade-targets.js</b>.
   </p>
 </div>`;

 $("parentDashboard").innerHTML = html;
}
function openParentDashboard(){const pass=prompt("Enter parent password:"); if(pass!=="0307"){ $("feedback").textContent="Parent dashboard locked."; return;} renderParentDashboard(); $("parentDashboardPanel").classList.remove("hidden");}
function applyLock(){const locked=localStorage.getItem("LR_locked_child_recovery_2a"); if(locked){activeChild=locked; $("studentSelect").value=locked; $("studentSelect").disabled=true; $("lockProfileBtn").style.display="none"; $("unlockProfileBtn").style.display="inline-block";}else{$("studentSelect").disabled=false; $("lockProfileBtn").style.display="inline-block"; $("unlockProfileBtn").style.display="none";}}


function LR_captureRuntimeError(event){
 LR_lastSystemError = (event && event.message) ? event.message : "Unknown runtime error";
 try{console.error("LearningRealms runtime error", event);}catch(e){}
}
function LR_capturePromiseError(event){
 LR_lastSystemError = event && event.reason ? String(event.reason.message || event.reason) : "Unknown promise error";
 try{console.error("LearningRealms promise error", event);}catch(e){}
}
window.addEventListener("error", LR_captureRuntimeError);
window.addEventListener("unhandledrejection", LR_capturePromiseError);


/* MiniMap Polish 3A: more room positions so the player dot visibly moves */
Object.assign(LR_STATIC_MINIMAP_POINTS, {
  townSquare:[4,4,"town","T"],
  crossroads:[5,4,"town","★"],
  mainStreet:[5,5,"town",""],
  questBoardPlaza:[5,6,"town","Q"],
  royalCauseway:[5,1,"path",""],
  enchantedGate:[5,0,"castle","C"],

  residentialRow:[3,5,"home",""],
  home:[2,5,"home","H"],

  marketRow:[6,4,"shop","$"],
  seasonalShop:[7,4,"shop","$"],
  pictureRow:[4,4,"shop","$"],
  pictureShop:[3,4,"shop","$"],
  cloverLane:[6,5,"shop","$"],
  luckyKettle:[7,5,"shop","$"],
  crookedAlley:[4,6,"shop","$"],
  shiftyTent:[4,7,"shop","$"],

  whisperwood:[10,3,"realm","R"],
  storyStone:[11,3,"realm",""],
  brookBridge:[10,5,"realm",""],
  forestGate:[9,3,"realm",""],

  ironGate:[1,3,"realm","M"],
  forgeHall:[1,4,"realm",""],
  gearWorkshop:[1,5,"realm",""],
  mountainPass:[2,4,"realm",""],

  archiveRoad:[5,2,"realm","W"],
  recordVault:[5,1,"realm",""],
  councilHall:[4,2,"realm",""],
  historicalSociety:[4,1,"realm",""],

  grammarRoad:[8,2,"realm","E"],
  spellingGarden:[8,1,"realm",""],
  punctuationHall:[9,2,"realm",""],

  crystalMarsh:[6,9,"realm","S"],
  reedPool:[6,10,"realm",""],
  frogPool:[7,10,"realm",""],

  councilRoad1:[3,2,"realm","C"],
  councilRoad2:[3,3,"realm",""],
  councilRoad3:[3,4,"realm",""],

  mapmakerRoad1:[4,2,"realm","G"],
  mapmakerRoad2:[4,3,"realm",""],
  mapmakerRoad3:[4,4,"realm",""],

  merchantRoad1:[6,3,"realm","$"],
  merchantRoad2:[6,4,"realm",""],
  merchantRoad3:[6,5,"realm",""],

  puzzleRoad1:[7,2,"realm","?"],
  puzzleRoad2:[7,3,"realm",""],
  puzzleRoad3:[7,4,"realm",""],

  wildrootRoad1:[9,4,"realm","N"],
  wildrootRoad2:[10,4,"realm",""],
  wildrootRoad3:[11,4,"realm",""],

  hearthwellRoad1:[8,5,"realm","+"],
  hearthwellRoad2:[8,6,"realm",""],
  hearthwellRoad3:[8,7,"realm",""],

  bardwoodRoad1:[9,3,"realm","♪"],
  bardwoodRoad2:[10,3,"realm",""],
  bardwoodRoad3:[11,3,"realm",""],

  scribeRoad1:[4,1,"realm","S"],
  scribeRoad2:[4,2,"realm",""],
  scribeRoad3:[4,3,"realm",""],

  homesteadRoad1:[3,6,"realm","L"],
  homesteadRoad2:[3,7,"realm",""],
  homesteadRoad3:[3,8,"realm",""]
});

function lrHashRoomOffset(id){
  let n = 0;
  id = String(id || "");
  for(let i=0;i<id.length;i++) n = (n + id.charCodeAt(i) * (i+1)) % 997;
  return n;
}

function lrMinimapFallbackPoint(r){
 const subject = (r && r.subject) || "";
 const zone = (r && r.zone) || "";
 let base;
 if(zone === "Home") base = [2,5,"home","H"];
 else if(zone.indexOf("Town") >= 0) base = [5,4,"town","★"];
 else if(zone.indexOf("Shop") >= 0 || zone.indexOf("Market") >= 0) base = [6,4,"shop","$"];
 else if(subject === "Reading") base = [10,3,"realm","R"];
 else if(subject === "Math") base = [1,4,"realm","M"];
 else if(subject === "Science") base = zone.indexOf("Marsh") >= 0 ? [6,9,"realm","S"] : [10,5,"realm","S"];
 else if(subject === "Writing") base = [5,2,"realm","W"];
 else if(subject === "History") base = [5,1,"realm","H"];
 else if(subject === "English") base = [8,2,"realm","E"];
 else if(subject === "Civics") base = [3,2,"realm","C"];
 else if(subject === "Geography") base = [4,2,"realm","G"];
 else if(subject === "Economics") base = [6,3,"realm","$"];
 else if(subject === "Logic") base = [7,2,"realm","?"];
 else if(subject === "Nature") base = [9,4,"realm","N"];
 else if(subject === "Health") base = [8,5,"realm","+"];
 else if(subject === "Music") base = [9,3,"realm","♪"];
 else if(subject === "Copywork") base = [4,1,"realm","S"];
 else if(subject === "Life Skills") base = [3,6,"realm","L"];
 else base = [5,4,"town","★"];

 const offsets = [[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];
 const off = offsets[lrHashRoomOffset(state.loc) % offsets.length];
 return [Math.max(0, Math.min(12, base[0] + off[0])), Math.max(0, Math.min(10, base[1] + off[1])), base[2], base[3]];
}
/* End MiniMap Polish 3A */


/* MiniMap Fix 4A: accurate travel coordinates and visible movement */
Object.assign(LR_STATIC_MINIMAP_POINTS, {
  enchantedGate:[6,0,"castle","C"],
  royalCauseway:[6,1,"path",""],
  crossroads:[6,4,"town","★"],
  townSquare:[5,4,"town","T"],
  mainStreet:[6,5,"town",""],
  questBoardPlaza:[6,6,"town","Q"],

  residentialRow:[4,5,"home",""],
  home:[3,5,"home","H"],

  marketRow:[7,4,"shop","$"],
  seasonalShop:[8,4,"shop","$"],
  pictureRow:[5,5,"shop","$"],
  pictureShop:[4,6,"shop","$"],
  cloverLane:[7,5,"shop","$"],
  luckyKettle:[8,5,"shop","$"],
  crookedAlley:[5,6,"shop","$"],
  shiftyTent:[5,7,"shop","$"],

  whisperwood:[10,3,"realm","R"],
  storyStone:[11,3,"realm",""],
  brookBridge:[10,5,"realm",""],
  forestGate:[9,3,"realm",""],

  ironGate:[2,3,"realm","M"],
  forgeHall:[2,4,"realm",""],
  gearWorkshop:[2,5,"realm",""],
  mountainPass:[3,4,"realm",""],

  archiveRoad:[6,2,"realm","W"],
  recordVault:[6,1,"realm",""],
  councilHall:[5,2,"realm",""],
  historicalSociety:[5,1,"realm",""],

  grammarRoad:[9,2,"realm","E"],
  spellingGarden:[9,1,"realm",""],
  punctuationHall:[10,2,"realm",""],

  crystalMarsh:[7,8,"realm","S"],
  reedPool:[7,9,"realm",""],
  frogPool:[8,9,"realm",""],

  councilRoad1:[3,2,"realm","C"], councilRoad2:[3,3,"realm",""], councilRoad3:[3,4,"realm",""],
  mapmakerRoad1:[4,2,"realm","G"], mapmakerRoad2:[4,3,"realm",""], mapmakerRoad3:[4,4,"realm",""],
  merchantRoad1:[7,3,"realm","$"], merchantRoad2:[7,4,"realm",""], merchantRoad3:[7,5,"realm",""],
  puzzleRoad1:[8,2,"realm","?"], puzzleRoad2:[8,3,"realm",""], puzzleRoad3:[8,4,"realm",""],
  wildrootRoad1:[10,4,"realm","N"], wildrootRoad2:[11,4,"realm",""], wildrootRoad3:[12,4,"realm",""],
  hearthwellRoad1:[9,5,"realm","+"], hearthwellRoad2:[9,6,"realm",""], hearthwellRoad3:[9,7,"realm",""],
  bardwoodRoad1:[10,2,"realm","♪"], bardwoodRoad2:[11,2,"realm",""], bardwoodRoad3:[12,2,"realm",""],
  scribeRoad1:[5,1,"realm","S"], scribeRoad2:[5,2,"realm",""], scribeRoad3:[5,3,"realm",""],
  homesteadRoad1:[4,6,"realm","L"], homesteadRoad2:[4,7,"realm",""], homesteadRoad3:[4,8,"realm",""]
});

function lrMiniMapRoutePoint(){
 const r = room();
 const id = String(state.loc || "");
 if (LR_STATIC_MINIMAP_POINTS[id]) return LR_STATIC_MINIMAP_POINTS[id];

 // Handles generated/expanded room IDs like subjectRoad12, civicsTrail7, etc.
 const digits = id.match(/(\d+)$/);
 const step = digits ? Math.max(0, parseInt(digits[1],10)-1) : 0;
 const subject = (r && r.subject) || "";
 const zone = (r && r.zone) || "";
 const routes = {
   "Reading":[[9,3],[10,3],[11,3],[12,3],[10,4],[11,4],[10,5]],
   "Math":[[1,3],[2,3],[3,3],[2,4],[1,4],[2,5],[3,5]],
   "Science":[[7,8],[7,9],[8,9],[6,9],[7,10],[8,10]],
   "Writing":[[5,1],[6,1],[6,2],[5,2],[5,3],[6,3]],
   "History":[[5,1],[6,1],[6,2],[5,2],[4,2]],
   "English":[[9,1],[9,2],[10,2],[8,2],[9,3],[10,3]],
   "Civics":[[3,2],[3,3],[3,4],[4,4],[5,4]],
   "Geography":[[4,2],[4,3],[4,4],[5,4],[6,4]],
   "Economics":[[7,3],[7,4],[7,5],[6,5],[6,6]],
   "Logic":[[8,2],[8,3],[8,4],[7,4],[6,4]],
   "Nature":[[10,4],[11,4],[12,4],[11,5],[10,5]],
   "Health":[[9,5],[9,6],[9,7],[8,7],[7,7]],
   "Music":[[10,2],[11,2],[12,2],[11,3],[10,3]],
   "Copywork":[[5,1],[5,2],[5,3],[4,3],[4,2]],
   "Life Skills":[[4,6],[4,7],[4,8],[5,8],[6,8]],
   "Nature / Health":[[9,5],[10,5],[10,6],[9,6],[8,6],[7,7]]
 };
 let coords = routes[subject];
 if(!coords){
   if(zone === "Home") coords = [[3,5],[4,5]];
   else if(zone.indexOf("Town") >= 0) coords = [[5,4],[6,4],[6,5],[6,6],[5,6],[5,5]];
   else if(zone.indexOf("Shop") >= 0 || zone.indexOf("Market") >= 0) coords = [[7,4],[8,4],[7,5],[8,5],[5,6]];
   else coords = [[6,4]];
 }
 const xy = coords[step % coords.length];
 return [xy[0], xy[1], subject ? "realm" : "town", subject ? "•" : "★"];
}

// Override the older grid renderer so the glowing dot uses the fixed route point.
function lrStaticMinimapGridHtml(){
 const herePoint = lrMiniMapRoutePoint();
 const markerIds = ["crossroads","home","seasonalShop","pictureShop","luckyKettle","shiftyTent","enchantedGate","whisperwood","ironGate","crystalMarsh","archiveRoad","grammarRoad","puzzleRoad1","wildrootRoad1","hearthwellRoad1","homesteadRoad1"];
 let html = '<div class="lrStaticMap" aria-label="Static realm minimap">';
 for(let y=0;y<LR_STATIC_MINIMAP_ROWS.length;y++){
   for(let x=0;x<LR_STATIC_MINIMAP_ROWS[y].length;x++){
     const type = lrStaticMapType(LR_STATIC_MINIMAP_ROWS[y][x]);
     let point = null;
     for(let i=0;i<markerIds.length;i++){
       const p = LR_STATIC_MINIMAP_POINTS[markerIds[i]];
       if(p && p[0]===x && p[1]===y){ point = p; break; }
     }
     const marker = point ? `<span class="lrMapMarker ${point[2]}Mark">${lrEscape(point[3] || "•")}</span>` : "";
     const player = (herePoint[0]===x && herePoint[1]===y) ? '<span class="lrPlayerDot" title="You are here"></span>' : '';
     html += `<span class="lrMapTile ${type}">${marker}${player}</span>`;
   }
 }
 html += '</div>';
 return html;
}
/* End MiniMap Fix 4A */


/* MiniMap Fix 4B: movement counter path, independent of room-name guessing */
function lrEnsureMiniMapState(){
  if(!state.miniMapStep && state.miniMapStep !== 0) state.miniMapStep = 0;
}
function lrMiniMapStep(){
  lrEnsureMiniMapState();
  state.miniMapStep = (state.miniMapStep + 1) % 48;
}
function lrMiniMapRoutePoint(){
  lrEnsureMiniMapState();

  // If we know the exact room, use that. Otherwise use the movement counter below.
  if (LR_STATIC_MINIMAP_POINTS && LR_STATIC_MINIMAP_POINTS[state.loc]) {
    return LR_STATIC_MINIMAP_POINTS[state.loc];
  }

  // A visible looping trail across the static map. Every successful travel click advances the dot.
  const path = [
    [6,4],[6,5],[6,6],[5,6],[4,6],[4,7],[4,8],
    [5,8],[6,8],[7,8],[8,8],[9,7],[9,6],[9,5],
    [10,5],[11,5],[12,4],[11,4],[10,4],[9,4],
    [8,4],[8,3],[8,2],[9,2],[10,2],[11,2],[12,2],
    [11,3],[10,3],[9,3],[8,3],[7,3],[7,4],[7,5],
    [6,5],[5,5],[4,5],[3,5],[2,5],[2,4],[2,3],
    [3,3],[4,3],[5,3],[6,3],[6,2],[6,1],[6,0]
  ];
  const xy = path[state.miniMapStep % path.length];
  return [xy[0], xy[1], "realm", "•"];
}

function lrStaticMinimapGridHtml(){
 const herePoint = lrMiniMapRoutePoint();
 const markerIds = ["crossroads","home","seasonalShop","pictureShop","luckyKettle","shiftyTent","enchantedGate","whisperwood","ironGate","crystalMarsh","archiveRoad","grammarRoad","puzzleRoad1","wildrootRoad1","hearthwellRoad1","homesteadRoad1"];
 let html = '<div class="lrStaticMap" aria-label="Static realm minimap">';
 for(let y=0;y<LR_STATIC_MINIMAP_ROWS.length;y++){
   for(let x=0;x<LR_STATIC_MINIMAP_ROWS[y].length;x++){
     const type = lrStaticMapType(LR_STATIC_MINIMAP_ROWS[y][x]);
     let point = null;
     for(let i=0;i<markerIds.length;i++){
       const p = LR_STATIC_MINIMAP_POINTS[markerIds[i]];
       if(p && p[0]===x && p[1]===y){ point = p; break; }
     }
     const marker = point ? `<span class="lrMapMarker ${point[2]}Mark">${lrEscape(point[3] || "•")}</span>` : "";
     const player = (herePoint[0]===x && herePoint[1]===y) ? '<span class="lrPlayerDot" title="You are here"></span>' : '';
     html += `<span class="lrMapTile ${type}">${marker}${player}</span>`;
   }
 }
 html += '</div>';
 return html;
}
/* End MiniMap Fix 4B */


/* MiniMap Fix 4C: direction-aware player dot */
function lrEnsureMiniMapPosition(){
  if(!state.miniMapPos || typeof state.miniMapPos.x !== "number" || typeof state.miniMapPos.y !== "number"){
    const p = (LR_STATIC_MINIMAP_POINTS && LR_STATIC_MINIMAP_POINTS[state.loc]) ? LR_STATIC_MINIMAP_POINTS[state.loc] : [6,4,"town","★"];
    state.miniMapPos = {x:p[0], y:p[1]};
  }
}

function lrMiniMapMoveDirection(dir){
  lrEnsureMiniMapPosition();
  const moves = {
    north:[0,-1],
    south:[0,1],
    east:[1,0],
    west:[-1,0],
    northeast:[1,-1],
    northwest:[-1,-1],
    southeast:[1,1],
    southwest:[-1,1],
    up:[0,-1],
    down:[0,1]
  };
  const d = moves[dir] || [0,0];
  state.miniMapPos.x = Math.max(0, Math.min(12, state.miniMapPos.x + d[0]));
  state.miniMapPos.y = Math.max(0, Math.min(10, state.miniMapPos.y + d[1]));

  // If the game lands on a landmark room with known coordinates, lightly snap to it
  // so Home, shops, and realm hubs still line up with the static map.
  if(LR_STATIC_MINIMAP_POINTS && LR_STATIC_MINIMAP_POINTS[state.loc]){
    const p = LR_STATIC_MINIMAP_POINTS[state.loc];
    state.miniMapPos.x = p[0];
    state.miniMapPos.y = p[1];
  }
}

function lrMiniMapRoutePoint(){
  lrEnsureMiniMapPosition();
  return [state.miniMapPos.x, state.miniMapPos.y, "realm", "•"];
}

function lrStaticMinimapGridHtml(){
 const herePoint = lrMiniMapRoutePoint();
 const markerIds = ["crossroads","home","seasonalShop","pictureShop","luckyKettle","shiftyTent","enchantedGate","whisperwood","ironGate","crystalMarsh","archiveRoad","grammarRoad","puzzleRoad1","wildrootRoad1","hearthwellRoad1","homesteadRoad1"];
 let html = '<div class="lrStaticMap" aria-label="Static realm minimap">';
 for(let y=0;y<LR_STATIC_MINIMAP_ROWS.length;y++){
   for(let x=0;x<LR_STATIC_MINIMAP_ROWS[y].length;x++){
     const type = lrStaticMapType(LR_STATIC_MINIMAP_ROWS[y][x]);
     let point = null;
     for(let i=0;i<markerIds.length;i++){
       const p = LR_STATIC_MINIMAP_POINTS[markerIds[i]];
       if(p && p[0]===x && p[1]===y){ point = p; break; }
     }
     const marker = point ? `<span class="lrMapMarker ${point[2]}Mark">${lrEscape(point[3] || "•")}</span>` : "";
     const player = (herePoint[0]===x && herePoint[1]===y) ? '<span class="lrPlayerDot" title="You are here"></span>' : '';
     html += `<span class="lrMapTile ${type}">${marker}${player}</span>`;
   }
 }
 html += '</div>';
 return html;
}
/* End MiniMap Fix 4C */


/* Layout/GamePlay Polish 4A: local room radar, always matches current exits */
function lrLocalRadarCell(label, cls){
  return `<div class="localRadarCell ${cls || ''}">${label || ''}</div>`;
}

function lrLocalRadarHtml(){
  const r = room();
  const exits = r.exits || {};
  const cell = (dir, label) => exits[dir]
    ? `<button class="localRadarCell localRadarExit" onclick="go('${dir}')" title="${lrEscape(dir)} to ${lrEscape((ROOMS[exits[dir]] && ROOMS[exits[dir]].title) || exits[dir])}">${label}</button>`
    : lrLocalRadarCell('', 'localRadarBlank');

  return `<div class="localRadarMap" aria-label="Local room radar">
    ${cell('northwest','NW')}
    ${cell('north','N')}
    ${cell('northeast','NE')}
    ${cell('west','W')}
    <div class="localRadarCell localRadarHere">YOU</div>
    ${cell('east','E')}
    ${cell('southwest','SW')}
    ${cell('south','S')}
    ${cell('southeast','SE')}
    <div class="localRadarUpDown">${exits.up ? `<button onclick="go('up')">Up</button>` : ''}${exits.down ? `<button onclick="go('down')">Down</button>` : ''}</div>
  </div>`;
}

function lrMiniMapHtml(){
 const r = room();
 const exits = Object.keys(r.exits || {});
 const exitText = exits.length ? exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]] && ROOMS[r.exits[d]].title) || r.exits[d])}</span>`).join("") : "<span>No visible exits</span>";
 const here = lrEscape(r.title || state.loc);
 const zone = lrEscape(r.zone || "Unknown");
 return `<div class="lrMiniMap localRadarBox">
   <div class="lrMiniMapTitle">🧭 Local Room Radar</div>
   ${lrLocalRadarHtml()}
   <div class="lrMiniMapHere">You are here:<br><b>${here}</b><small>${zone}</small></div>
   <div class="lrMapCaption">This shows exits from the current room only, so it always matches the movement buttons.</div>
   <div class="lrMiniMapExits compact">${exitText}</div>
 </div>`;
}
/* End Layout/GamePlay Polish 4A local radar */


/* Gameplay Layout 4B: colorful local grid map */
function lrGridTerrainFor(x,y,r){
  const zone = ((r && r.zone) || "").toLowerCase();
  const subject = ((r && r.subject) || "").toLowerCase();

  if(x===3 && y===3) return "here";
  if(zone.includes("iron") || subject.includes("math")) return (y < 2 || x < 2) ? "mountain" : "path";
  if(zone.includes("marsh") || subject.includes("science")) return (x > 4 || y > 4) ? "water" : "marsh";
  if(zone.includes("archive") || subject.includes("writing") || subject.includes("history")) return (x===1 || x===5 || y===1 || y===5) ? "stone" : "path";
  if(zone.includes("town") || zone.includes("shop") || zone.includes("market")) return (x===3 || y===3) ? "road" : "town";
  if(zone.includes("home")) return (x===3 || y===3) ? "homepath" : "grass";
  return (x===3 || y===3) ? "path" : ((x+y)%4===0 ? "water" : "forest");
}

function lrGridExitFor(x,y,exits){
  const exitCells = {
    northwest:[1,1], north:[3,1], northeast:[5,1],
    west:[1,3], east:[5,3],
    southwest:[1,5], south:[3,5], southeast:[5,5],
    up:[2,0], down:[4,6]
  };
  for(const dir in exitCells){
    const p = exitCells[dir];
    if(exits[dir] && p[0]===x && p[1]===y) return dir;
  }
  return "";
}

function lrGridShort(dir){
  return {northwest:"NW",north:"N",northeast:"NE",west:"W",east:"E",southwest:"SW",south:"S",southeast:"SE",up:"UP",down:"DN"}[dir] || "";
}

function lrLocalRadarHtml(){
  const r = room();
  const exits = r.exits || {};
  let html = '<div class="kidGridMap" aria-label="Local adventure grid map">';
  for(let y=0;y<7;y++){
    for(let x=0;x<7;x++){
      const dir = lrGridExitFor(x,y,exits);
      const terrain = lrGridTerrainFor(x,y,r);
      if(x===3 && y===3){
        html += '<div class="kidGridTile here"><span class="kidPlayer">YOU</span></div>';
      }else if(dir){
        const target = exits[dir];
        const title = (ROOMS[target] && ROOMS[target].title) || target;
        html += `<div class="kidGridTile exit viewOnly ${terrain}" title="${lrEscape(dir)} to ${lrEscape(title)}"><b>${lrGridShort(dir)}</b></div>`;
      }else{
        html += `<div class="kidGridTile ${terrain}"></div>`;
      }
    }
  }
  html += '</div>';
  return html;
}

function lrMiniMapHtml(){
 const r = room();
 const exits = Object.keys(r.exits || {});
 const exitText = exits.length ? exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]] && ROOMS[r.exits[d]].title) || r.exits[d])}</span>`).join("") : "<span>No visible exits</span>";
 const here = lrEscape(r.title || state.loc);
 const zone = lrEscape(r.zone || "Unknown");
 return `<div class="lrMiniMap kidGridBox">
   <div class="lrMiniMapTitle">🗺️ Adventure Grid</div>
   ${lrLocalRadarHtml()}
   <div class="lrMiniMapHere">You are here:<br><b>${here}</b><small>${zone}</small></div>
   <div class="kidGridLegend"><span class="sw forest"></span> Woods <span class="sw water"></span> Water <span class="sw road"></span> Road <span class="sw mountain"></span> Hills</div>
   <div class="lrMapCaption">Gold tiles are real exits. Click them or use the compass buttons.</div>
   <div class="lrMiniMapExits compact">${exitText}</div>
 </div>`;
}
/* End Gameplay Layout 4B */


/* Gameplay Layout 4C SAFE: smaller adventure grid with black blocked tiles */
function lrLocalRadarHtml(){
  const r = room();
  const exits = r.exits || {};
  let html = '<div class="kidGridMap safeBlockedGrid" aria-label="Local adventure grid map">';
  for(let y=0;y<7;y++){
    for(let x=0;x<7;x++){
      const dir = lrGridExitFor(x,y,exits);
      const terrain = lrGridTerrainFor(x,y,r);
      if(x===3 && y===3){
        html += '<div class="kidGridTile here"><span class="kidPlayer">YOU</span></div>';
      }else if(dir){
        const target = exits[dir];
        const title = (ROOMS[target] && ROOMS[target].title) || target;
        html += `<div class="kidGridTile exit viewOnly ${terrain}" title="${lrEscape(dir)} to ${lrEscape(title)}"><b>${lrGridShort(dir)}</b></div>`;
      }else{
        html += '<div class="kidGridTile blocked"></div>';
      }
    }
  }
  html += '</div>';
  return html;
}
/* End Gameplay Layout 4C SAFE */


/* Treasure Map Patch 1: cute non-clickable living map */
function lrCuteMapTerrain(x,y,r){
  const zone = ((r && r.zone) || "").toLowerCase();
  const subject = ((r && r.subject) || "").toLowerCase();

  if(x===3 && y===3) return "here";
  if(zone.includes("iron") || subject.includes("math")) return (x<2 || y<2) ? "hill" : "trail";
  if(zone.includes("marsh") || subject.includes("science") || subject.includes("nature")) return (x>4 || y>4 || (x===1 && y===5)) ? "water" : "field";
  if(zone.includes("town") || zone.includes("market") || zone.includes("shop")) return (x===3 || y===3) ? "trail" : "town";
  if(zone.includes("home")) return (x===3 || y===3) ? "trail" : "field";
  if(zone.includes("archive") || subject.includes("writing") || subject.includes("reading")) return (x===3 || y===3 || x===1 || x===5) ? "trail" : "field";
  return (x===3 || y===3) ? "trail" : (((x+y)%5===0) ? "water" : "field");
}

function lrCuteMapIcon(x,y,r,dir){
  if(x===3 && y===3) return "🧍";
  if(dir) return "🪧";
  const picks = ["🌳","","🌼","","🪨","","🍄","",""];
  return picks[(x*7+y+(state.room||0)) % picks.length];
}

function lrCuteMapExitFor(x,y,exits){
  const exitCells = {
    northwest:[1,1], north:[3,1], northeast:[5,1],
    west:[1,3], east:[5,3],
    southwest:[1,5], south:[3,5], southeast:[5,5],
    up:[2,0], down:[4,6]
  };
  for(const dir in exitCells){
    const p = exitCells[dir];
    if(exits[dir] && p[0]===x && p[1]===y) return dir;
  }
  return "";
}

function lrLocalRadarHtml(){
  const r = room();
  const exits = r.exits || {};
  let html = '<div class="treasureMapGrid" aria-label="View-only living treasure map">';
  for(let y=0;y<7;y++){
    for(let x=0;x<7;x++){
      const dir = lrCuteMapExitFor(x,y,exits);
      const terrain = lrCuteMapTerrain(x,y,r);
      const icon = lrCuteMapIcon(x,y,r,dir);
      const cls = dir ? "exitPath" : "";
      html += `<div class="treasureMapTile ${terrain} ${cls}">${icon ? `<span>${icon}</span>` : ""}</div>`;
    }
  }
  html += '</div>';
  return html;
}

function lrMiniMapHtml(){
 const r = room();
 const exits = Object.keys(r.exits || {});
 const exitText = exits.length ? exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]] && ROOMS[r.exits[d]].title) || r.exits[d])}</span>`).join("") : "<span>No visible exits</span>";
 const here = lrEscape(r.title || state.loc);
 const zone = lrEscape(r.zone || "Unknown");
 return `<div class="lrMiniMap treasureMapBox">
   <div class="lrMiniMapTitle">🗺️ Living Treasure Map</div>
   ${lrLocalRadarHtml()}
   <div class="lrMiniMapHere">You are here:<br><b>${here}</b><small>${zone}</small></div>
   <div class="treasureMapLegend"><span class="leg field"></span>Fields <span class="leg trail"></span>Trails <span class="leg water"></span>Water <span class="leg hill"></span>Hills <span class="leg exit"></span>Exit</div>
   <div class="lrMapCaption">Map is view-only. Use the compass movement buttons to travel.</div>
   <div class="lrMiniMapExits compact">${exitText}</div>
 </div>`;
}
/* End Treasure Map Patch 1 */


/* UI Pack 6B: stable treasure map, no random redraw per step */
function lrStableMapTerrain(x,y,r){
  const zone = ((r && r.zone) || "").toLowerCase();
  const subject = ((r && r.subject) || "").toLowerCase();

  if(x===3 && y===3) return "here";

  // Build a local map that is stable and readable:
  // trail cross through the center, exits highlighted, surrounding terrain based on realm.
  if(x===3 || y===3) return "trail";

  if(zone.includes("iron") || subject.includes("math")) return "hill";
  if(zone.includes("marsh") || subject.includes("science") || subject.includes("nature")) return ((x+y)%3===0) ? "water" : "field";
  if(zone.includes("town") || zone.includes("market") || zone.includes("shop")) return "town";
  if(zone.includes("home")) return "field";
  if(zone.includes("archive") || subject.includes("writing") || subject.includes("reading")) return ((x===1 || x===5 || y===1 || y===5) ? "trail" : "field");
  return ((x+y)%6===0) ? "water" : "field";
}

function lrStableMapIcon(x,y,r,dir){
  if(x===3 && y===3) return "🧍";
  if(dir) return "🪧";

  const zone = ((r && r.zone) || "").toLowerCase();
  const subject = ((r && r.subject) || "").toLowerCase();

  // Fixed landmarks by coordinates, not by movement count.
  const key = x + "," + y;
  const forest = {"1,1":"🌳","5,1":"🌲","1,5":"🍄","5,5":"🌼"};
  const water = {"1,1":"🌿","5,1":"💧","1,5":"🪨","5,5":"🌾"};
  const town = {"1,1":"🏠","5,1":"🏪","1,5":"🌷","5,5":"🪧"};
  const hill = {"1,1":"⛰️","5,1":"🪨","1,5":"⚒️","5,5":"🔥"};
  const archive = {"1,1":"📜","5,1":"🕯️","1,5":"📚","5,5":"🪶"};

  if(zone.includes("town") || zone.includes("market") || zone.includes("shop")) return town[key] || "";
  if(zone.includes("iron") || subject.includes("math")) return hill[key] || "";
  if(zone.includes("marsh") || subject.includes("science") || subject.includes("nature")) return water[key] || "";
  if(zone.includes("archive") || subject.includes("writing") || subject.includes("reading")) return archive[key] || "";
  return forest[key] || "";
}

function lrCuteMapTerrain(x,y,r){ return lrStableMapTerrain(x,y,r); }
function lrCuteMapIcon(x,y,r,dir){ return lrStableMapIcon(x,y,r,dir); }
/* End UI Pack 6B stable treasure map */


/* UI Pack 6C: Shop Popup + Restored Magical Room Flavor */
const LR_MAGIC_ROOM_FLAVOR = {
  Home:[
    "Warm lamplight rests across the hearth while the house seems to hold its breath between adventures. Shelves wait for treasures, and the rooms feel ready to grow into something grand.",
    "The home feels safe and bright, with little spaces waiting for future pets, maps, books, and trophies. Somewhere in the walls, Brindletoe would probably claim he can hear unused expansion space."
  ],
  Town:[
    "The town hums with small friendly noises: a cart wheel creaks, a shop bell rings, and banners shift in the breeze. Every road seems to lead toward another errand, rumor, or little discovery.",
    "Stone paths cross beneath hanging signs and flower boxes. The air smells faintly of bread, dust, and old adventure, as though many travelers have passed this way before."
  ],
  Forest:[
    "Silver-green leaves stir overhead while moss softens the edges of old stones. The path feels quiet but watchful, like the woods are waiting to see whether the traveler notices the small things.",
    "Sunlight falls through the branches in bright broken patches. A few tiny flowers lean toward the trail, and somewhere far off a bird calls once, then goes silent."
  ],
  Hills:[
    "The hills rise in rough folds of stone and grass, with old hammer marks still visible where travelers or builders once worked. The air carries the mineral smell of rain on rock.",
    "A narrow trail winds between worn stones and hardy little plants. Somewhere in the distance, a sound like metal on metal rings once and fades."
  ],
  Archive:[
    "Shelves, scrolls, and old markings give this place a hushed feeling. Even the dust seems careful here, drifting slowly through the light as if it does not want to disturb the books.",
    "The room feels older than it looks. A map edge curls on a table, and the quiet has the cozy weight of stories waiting to be opened."
  ],
  Water:[
    "Water glimmers nearby, turning the light into little moving pieces. Reeds lean together at the edge, and the whole place smells clean, muddy, and alive.",
    "Soft ripples move across the water while grasses bend in the damp air. It feels like a place where careful eyes might spot tracks, frogs, or a hidden path."
  ],
  Default:[
    "The room has the feeling of a place tucked between ordinary roads and hidden stories. A traveler who slows down here may notice more than one who hurries through.",
    "Small details gather around the path: worn stones, quiet corners, and hints that someone else passed through long ago. The realm feels ready for the next step."
  ]
};

function lrRoomFlavorCategory(){
  const r = room();
  const z = ((r && r.zone) || "").toLowerCase();
  const s = ((r && r.subject) || "").toLowerCase();
  const t = ((r && r.title) || "").toLowerCase();
  if(state.loc === "home" || z.includes("home") || t.includes("home") || t.includes("hearth")) return "Home";
  if(z.includes("town") || z.includes("market") || z.includes("shop")) return "Town";
  if(z.includes("iron") || z.includes("hill") || s.includes("math")) return "Hills";
  if(z.includes("archive") || s.includes("reading") || s.includes("writing") || s.includes("history")) return "Archive";
  if(z.includes("marsh") || z.includes("pond") || s.includes("nature") || s.includes("science")) return "Water";
  if(z.includes("wood") || z.includes("forest")) return "Forest";
  return "Default";
}

function lrMagicalRoomParagraph(){
  const cat = lrRoomFlavorCategory();
  const arr = LR_MAGIC_ROOM_FLAVOR[cat] || LR_MAGIC_ROOM_FLAVOR.Default;
  return arr[(state.room || 0) % arr.length];
}

function lrCompactRoomText(raw){
  let text = String(raw || "").replace(/\r/g,"").replace(/\\n\\n/g,"\n\n").replace(/\n{3,}/g,"\n\n").trim();
  const r = room();

  // Keep only the strongest first original paragraph, then add one fresh magical paragraph.
  const parts = text.split(/\n+/).map(x=>x.trim()).filter(Boolean).filter(line=>{
    if(/^Exits:/i.test(line)) return false;
    if(/^Home Expansion:/i.test(line)) return false;
    if(/^Realm State:/i.test(line)) return false;
    if(/^Restoration Object:/i.test(line)) return false;
    return true;
  });

  const base = parts[0] || (r.title || "This room");
  let compact = base;
  const magic = lrMagicalRoomParagraph();
  if(magic && compact.indexOf(magic) === -1) compact += "\n\n" + magic;

  const exits = Object.keys((r && r.exits) || {});
  compact += "\n\n🧭 Paths: " + (exits.length ? exits.map(x=>x[0].toUpperCase()+x.slice(1)).join(", ") : "None visible");
  if(r.subject) compact += "\n📚 Learning Realm: " + r.subject;
  if(typeof roomHasNpc === "function" && roomHasNpc()) compact += "\n💬 Nearby: " + (npc().name || "Realm Guide");
  return compact;
}

function lrSafeBrowseShopPopup(){
  if(typeof openShop === "function") lrSafeBrowseShopPopup();
  if(typeof lrOpenPopup === "function"){
    const title = $("actionTitle") ? $("actionTitle").textContent : "Shop";
    const body = `
      <div class="shopPopupIntro">
        <p>The shopkeeper lays out the day’s goods. Choose carefully. Coins and sparks are meant to matter.</p>
      </div>
      ${$("actionText") ? $("actionText").innerHTML : ""}
      ${$("storageItems") ? $("storageItems").innerHTML : ""}
    `;
    lrOpenPopup(title || "Shop", body);
  }
}

function lrConvertShopButtonsToPopup(){
  document.querySelectorAll("button").forEach(btn=>{
    const txt = (btn.textContent || "").toLowerCase();
    const attr = btn.getAttribute("onclick") || "";
    if(txt.includes("browse shop") || txt.includes("browse seasonal") || txt.includes("browse picture") || txt.includes("lucky kettle") || attr.includes("openShop()")){
      if(!btn.dataset.shopPopupFixed){
        btn.dataset.shopPopupFixed = "1";
        btn.onclick = function(){ lrSafeBrowseShopPopup(); };
      }
    }
  });
}
/* End UI Pack 6C */


/* UI Pack 6E: move travel into map footer and shrink/remove big compass window */
function lrTinyTravelButton(dir,label){
  const r = room();
  const exits = r.exits || {};
  if(!exits[dir]) return `<span class="tinyTravelBlank"></span>`;
  return `<button type="button" class="tinyTravelBtn" onclick="go('${dir}')" title="${lrEscape(dir)}">${label}</button>`;
}

function lrTinyTravelHtml(){
  const r = room();
  const exits = r.exits || {};
  const vertical = (exits.up || exits.down) ? `<div class="tinyTravelVertical">${exits.up ? `<button onclick="go('up')">Up</button>` : ""}${exits.down ? `<button onclick="go('down')">Down</button>` : ""}</div>` : "";
  return `<div class="tinyTravelFooter">
    <div class="tinyTravelTitle">🧭 Travel</div>
    <div class="tinyTravelGrid">
      ${lrTinyTravelButton("northwest","NW")}
      ${lrTinyTravelButton("north","N")}
      ${lrTinyTravelButton("northeast","NE")}
      ${lrTinyTravelButton("west","W")}
      <span class="tinyTravelHere">•</span>
      ${lrTinyTravelButton("east","E")}
      ${lrTinyTravelButton("southwest","SW")}
      ${lrTinyTravelButton("south","S")}
      ${lrTinyTravelButton("southeast","SE")}
    </div>
    ${vertical}
  </div>`;
}

function lrMiniMapHtml(){
 const r = room();
 const exits = Object.keys(r.exits || {});
 const exitText = exits.length ? exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]] && ROOMS[r.exits[d]].title) || r.exits[d])}</span>`).join("") : "<span>No visible exits</span>";
 const here = lrEscape(r.title || state.loc);
 const zone = lrEscape(r.zone || "Unknown");
 return `<div class="lrMiniMap treasureMapBox">
   <div class="lrMiniMapTitle">🗺️ Living Treasure Map</div>
   ${lrLocalRadarHtml()}
   ${lrTinyTravelHtml()}
   <div class="lrMiniMapHere">You are here:<br><b>${here}</b><small>${zone}</small></div>
   <div class="treasureMapLegend"><span class="leg field"></span>Fields <span class="leg trail"></span>Trails <span class="leg water"></span>Water <span class="leg hill"></span>Hills <span class="leg exit"></span>Exit</div>
   <div class="lrMapCaption">Map is view-only. Use the tiny compass here to travel.</div>
   <div class="lrMiniMapExits compact">${exitText}</div>
 </div>`;
}

/* Replace large main-window compass with a tiny note so it stops eating space. */
function lrRenderMainCompass(){
 const mount = $("mainCompassNav");
 if(!mount) return;
 mount.innerHTML = "";
}
/* End UI Pack 6E */


/* UI Pack 6F: paged living grid map with moving player marker */
function lrEnsurePagedMap(){
  if(!state.pagedMap) state.pagedMap = {};
  if(!state.pagedMap[activeChild]) state.pagedMap[activeChild] = {pageX:0,pageY:0,x:5,y:5};
  const m = state.pagedMap[activeChild];
  if(typeof m.x !== "number") m.x = 5;
  if(typeof m.y !== "number") m.y = 5;
  if(typeof m.pageX !== "number") m.pageX = 0;
  if(typeof m.pageY !== "number") m.pageY = 0;
  return m;
}

function lrPagedMapMove(dir){
  const m = lrEnsurePagedMap();
  const move = {
    north:[0,-1], south:[0,1], east:[1,0], west:[-1,0],
    northeast:[1,-1], northwest:[-1,-1], southeast:[1,1], southwest:[-1,1],
    up:[0,-1], down:[0,1]
  }[dir] || [0,0];

  m.x += move[0];
  m.y += move[1];

  if(m.x < 0){ m.x = 10; m.pageX--; }
  if(m.x > 10){ m.x = 0; m.pageX++; }
  if(m.y < 0){ m.y = 10; m.pageY--; }
  if(m.y > 10){ m.y = 0; m.pageY++; }
}

function lrMapRegionKey(){
  const r = room();
  const z = ((r && r.zone) || "").toLowerCase();
  const s = ((r && r.subject) || "").toLowerCase();
  if(state.loc === "home" || z.includes("home")) return "home";
  if(z.includes("town") || z.includes("market") || z.includes("shop")) return "town";
  if(z.includes("iron") || z.includes("hill") || s.includes("math")) return "hills";
  if(z.includes("marsh") || z.includes("pond") || s.includes("science") || s.includes("nature")) return "water";
  if(z.includes("archive") || s.includes("reading") || s.includes("writing") || s.includes("history")) return "archive";
  if(z.includes("wood") || z.includes("forest")) return "forest";
  return "wild";
}

function lrPagedTileType(x,y){
  const region = lrMapRegionKey();
  const m = lrEnsurePagedMap();
  const n = Math.abs((x*17 + y*31 + m.pageX*7 + m.pageY*13) % 19);

  if(region === "town"){
    if(x===5 || y===5) return "road";
    if(n===1 || n===8) return "house";
    if(n===4) return "garden";
    return "field";
  }
  if(region === "home"){
    if(x===5 || y===5) return "path";
    if(n===2) return "garden";
    if(n===6) return "tree";
    return "field";
  }
  if(region === "hills"){
    if(x===5 || y===5) return "trail";
    if(n<7) return "hill";
    if(n===9) return "stone";
    return "field";
  }
  if(region === "water"){
    if(x===5 || y===5) return "trail";
    if(n<7) return "water";
    if(n<11) return "reed";
    return "field";
  }
  if(region === "archive"){
    if(x===5 || y===5) return "road";
    if(n===1 || n===9) return "ruin";
    if(n===3) return "lamp";
    return "field";
  }
  if(region === "forest" || region === "wild"){
    if(x===5 || y===5) return "trail";
    if(n<6) return "tree";
    if(n===7) return "water";
    if(n===10) return "stone";
    return "field";
  }
  return "field";
}

function lrPagedTileIcon(type,x,y){
  const m = lrEnsurePagedMap();
  const code = Math.abs((x*11 + y*23 + m.pageX*5 + m.pageY*3) % 29);
  const icons = {
    road:"", path:"", trail:"",
    field: code===1 ? "🌼" : "",
    tree: code%2 ? "🌳" : "🌲",
    water: code%2 ? "💧" : "〰️",
    hill: code%2 ? "⛰️" : "🪨",
    stone:"🪨",
    reed:"🌾",
    house:"🏠",
    garden:"🌷",
    ruin:"📜",
    lamp:"🏮"
  };
  return icons[type] || "";
}

function lrPagedExitHint(x,y){
  const exits = (room() && room().exits) || {};
  const edgeHints = [
    ["north",5,0],["south",5,10],["west",0,5],["east",10,5],
    ["northwest",0,0],["northeast",10,0],["southwest",0,10],["southeast",10,10]
  ];
  for(const e of edgeHints){
    if(exits[e[0]] && e[1]===x && e[2]===y) return e[0];
  }
  return "";
}

function lrPagedMapHtml(){
  const m = lrEnsurePagedMap();
  let html = `<div class="pagedMapMeta">Area ${m.pageX}, ${m.pageY}</div><div class="pagedMapGrid" aria-label="Paged living map">`;
  for(let y=0;y<11;y++){
    for(let x=0;x<11;x++){
      const exitDir = lrPagedExitHint(x,y);
      const here = (x===m.x && y===m.y);
      const type = lrPagedTileType(x,y);
      const icon = here ? "🧍" : (exitDir ? "🪧" : lrPagedTileIcon(type,x,y));
      html += `<div class="pagedMapTile ${type} ${exitDir ? "exitHint" : ""} ${here ? "playerHere" : ""}">${icon}</div>`;
    }
  }
  html += "</div>";
  return html;
}

function lrMiniMapHtml(){
 const r = room();
 const exits = Object.keys(r.exits || {});
 const exitText = exits.length ? exits.map(d=>`<span>${lrEscape(d)} → ${lrEscape((ROOMS[r.exits[d]] && ROOMS[r.exits[d]].title) || r.exits[d])}</span>`).join("") : "<span>No visible exits</span>";
 const here = lrEscape(r.title || state.loc);
 const zone = lrEscape(r.zone || "Unknown");
 return `<div class="lrMiniMap pagedMapBox">
   <div class="lrMiniMapTitle">🗺️ Living Map</div>
   ${lrPagedMapHtml()}
   ${lrTinyTravelHtml()}
   <div class="lrMiniMapHere">You are here:<br><b>${here}</b><small>${zone}</small></div>
   <div class="pagedMapLegend"><span class="leg field"></span>Field <span class="leg trail"></span>Trail <span class="leg water"></span>Water <span class="leg hill"></span>Hill <span class="leg exit"></span>Exit</div>
   <div class="lrMapCaption">The marker moves room by room. If you leave the edge, the map shifts to the next area.</div>
   <div class="lrMiniMapExits compact">${exitText}</div>
 </div>`;
}
/* End UI Pack 6F */

$("switchChildBtn").onclick=switchChild;
if($("rightInfoSelect")) $("rightInfoSelect").onchange=lrSetRightInfoPanel;
$("lockProfileBtn").onclick=()=>{localStorage.setItem("LR_locked_child_recovery_2a",$("studentSelect").value); applyLock(); switchChild();};
$("unlockProfileBtn").onclick=()=>{localStorage.removeItem("LR_locked_child_recovery_2a"); applyLock();};
$("gameMenuSelect").onchange=e=>{if(e.target.value==="parentDashboard")openParentDashboard(); if(e.target.value==="collectionLog")openCollectionLog(); if(e.target.value==="companionDen")openCompanionDen(); if(e.target.value==="eventLog")openEventLog(); if(e.target.value==="masteryPaths")openMasteryPaths(); if(e.target.value==="reportCenter")openReportCenter(); if(e.target.value==="classroomSchedule")openClassroomSchedule(); if(e.target.value==="storyCampaigns")openStoryCampaigns(); if(e.target.value==="adaptiveReview")openAdaptiveReview(); if(e.target.value==="bossGauntlets")openBossGauntlets(); if(e.target.value==="worldAtlas")openWorldAtlas(); if(e.target.value==="systemHealth")openSystemHealth(); e.target.value="";};
$("closeParentDashboardBtn").onclick=()=>$("parentDashboardPanel").classList.add("hidden");

$("studentSelect").value=activeChild;
applyLock();
markAttendanceLogin();
setInterval(()=>attendanceTick(false),15000);
window.addEventListener("beforeunload",()=>attendanceTick(true));

/* Map Removal Hotfix 1B - disable old map before first render */
function lrTravelCardHtml(){
  try{
    const r = room();
    const exits = (r && r.exits) || {};
    const dirs = Object.keys(exits);
    if(!dirs.length){
      return `<div class="travelCard">
        <div class="travelCardTitle">🧭 Travel</div>
        <p>No visible paths from here.</p>
      </div>`;
    }
    return `<div class="travelCard">
      <div class="travelCardTitle">🧭 Paths from here</div>
      <div class="travelPathList">
        ${dirs.map(d=>{
          const target = exits[d];
          const label = (ROOMS[target] && ROOMS[target].title) || target;
          return `<button type="button" onclick="go('${d}')">${d[0].toUpperCase()+d.slice(1)} → ${lrEscape(label)}</button>`;
        }).join("")}
      </div>
      <div class="futureMapHook">Map retired for now. Future parchment map hook preserved.</div>
    </div>`;
  }catch(e){
    return `<div class="travelCard"><div class="travelCardTitle">🧭 Travel</div><p>Travel card loaded safely.</p></div>`;
  }
}

lrMiniMapHtml = function(){
  return lrTravelCardHtml();
};

lrLocalRadarHtml = function(){ return ""; };
lrPagedMapHtml = function(){ return ""; };
lrStaticMinimapGridHtml = function(){ return ""; };
/* End Map Removal Hotfix 1B */

renderRoom();

function travelHome(){
 state.loc="home";
 state.room=Math.max(1,Number(state.room||1))+1;
 if(typeof recordGameFunEvent === "function") recordGameFunEvent("roomVisits",1,{room:"home"});
 save();
 
/* Stability Pack 1 render wrapper */
if(typeof renderRoom === "function" && !window.__lrStabilityRenderWrapped){
  window.__lrStabilityRenderWrapped = true;
  const __lrOldRenderRoom = renderRoom;
  renderRoom = function(){
    __lrOldRenderRoom();
    if(typeof lrRunPostRenderAudit === "function") setTimeout(lrRunPostRenderAudit, 30);
  };
}


/* Lesson Immersion Pack 1 */
function lrLessonPlaceBannerHtml(){
  var r = (typeof room === "function") ? room() : {};
  var title = (r && r.title) ? r.title : "Reading Grove";
  var zone = (r && r.zone) ? r.zone : "Character Circle";
  return '<div class="lessonPlaceBanner">' +
    '<div class="lessonPlaceTitle">🌳 ' + (typeof lrEscape === "function" ? lrEscape(title) : title) + '</div>' +
    '<div class="lessonPlaceSub">🦉 Elric is teaching in the grove</div>' +
  '</div>';
}

function lrEnhanceLessonPopup(){
  try{
    var body = document.getElementById("lrPopupBody");
    if(!body) return;
    var title = document.getElementById("lrPopupTitle");
    var titleText = title ? title.textContent || "" : "";
    var looksLikeLesson = /lesson|practice|question|gate/i.test(titleText) || body.querySelector("#questionText,.questionText,.qTitle,.choices,#choices");
    if(!looksLikeLesson) return;
    if(!body.querySelector(".lessonPlaceBanner")){
      body.insertAdjacentHTML("afterbegin", lrLessonPlaceBannerHtml());
    }
  }catch(e){
    console.warn("Lesson immersion enhancement skipped", e);
  }
}

if(typeof lrOpenActionPopup === "function" && !window.__lrLessonImmersionWrapped){
  window.__lrLessonImmersionWrapped = true;
  var __oldLessonPopupOpen = lrOpenActionPopup;
  lrOpenActionPopup = function(title){
    var result = __oldLessonPopupOpen(title);
    setTimeout(lrEnhanceLessonPopup, 30);
    return result;
  };
}

if(typeof lrOpenPopup === "function" && !window.__lrLessonImmersionPopupWrapped){
  window.__lrLessonImmersionPopupWrapped = true;
  var __oldBasePopupOpen = lrOpenPopup;
  lrOpenPopup = function(title, body){
    var result = __oldBasePopupOpen(title, body);
    setTimeout(lrEnhanceLessonPopup, 30);
    return result;
  };
}
/* End Lesson Immersion Pack 1 */


/* Layout Pack REAL FIX - create actual control dock */
function lrFindButtonsByText(words){
  const found = [];
  document.querySelectorAll("button").forEach(function(btn){
    const t = (btn.textContent || "").toLowerCase();
    if(words.some(function(w){ return t.includes(w.toLowerCase()); })){
      found.push(btn);
    }
  });
  return found;
}

function lrEnsureControlDock(){
  let dock = document.getElementById("lrControlDock");
  if(dock) return dock;

  dock = document.createElement("div");
  dock.id = "lrControlDock";
  dock.innerHTML =
    '<div class="lrDockTitle">🎮 Actions</div>' +
    '<div id="lrMovementDock" class="lrMovementDock"></div>' +
    '<div id="lrInteractionDock" class="lrInteractionDock"></div>' +
    '<div id="lrUtilityDock" class="lrUtilityDock"></div>';

  const roomText = document.getElementById("roomText");
  const main = roomText ? roomText.parentElement : document.querySelector("main") || document.body;
  main.appendChild(dock);
  return dock;
}

function lrMoveButtonToDock(btn, dock){
  if(!btn || !dock || btn.closest("#lrControlDock")) return;
  dock.appendChild(btn);
}

function lrOrganizeControls(){
  lrEnsureControlDock();
  const moveDock = document.getElementById("lrMovementDock");
  const interactDock = document.getElementById("lrInteractionDock");
  const utilDock = document.getElementById("lrUtilityDock");

  lrFindButtonsByText(["north","south","east","west","up","down","journey"]).forEach(function(btn){
    const txt = (btn.textContent || "").toLowerCase();
    if(/north|south|east|west|up|down|journey/.test(txt)){
      lrMoveButtonToDock(btn, moveDock);
    }
  });

  lrFindButtonsByText(["talk","interact","teacher","lesson","quest","search","craft","village square"]).forEach(function(btn){
    lrMoveButtonToDock(btn, interactDock);
  });

  lrFindButtonsByText(["backpack","journal","achievement","wardrobe","regions","castle","museum","home"]).forEach(function(btn){
    lrMoveButtonToDock(btn, utilDock);
  });
}

window.addEventListener("load", function(){
  setTimeout(lrOrganizeControls, 100);
  setTimeout(lrOrganizeControls, 500);
});

if(typeof renderRoom === "function" && !window.__lrLayoutRealFixWrapped){
  window.__lrLayoutRealFixWrapped = true;
  const __oldRenderRoomLayoutFix = renderRoom;
  renderRoom = function(){
    __oldRenderRoomLayoutFix();
    setTimeout(lrOrganizeControls, 60);
  };
}
/* End Layout Pack REAL FIX */


/* Layout Pack FIXED DOCK 2 - visible gameplay controls */
function lrDockSafeClick(fnName){
  try{
    if(typeof window[fnName] === "function"){
      window[fnName]();
    }else{
      actionTitle.textContent = "Coming Soon";
      actionText.innerHTML = '<div class="journalPage"><h3>Coming Soon</h3><p>This feature is not loaded in this build.</p></div>';
      if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Coming Soon");
    }
  }catch(e){
    console.error(e);
    actionTitle.textContent = "Action Error";
    actionText.innerHTML = '<div class="journalPage"><h3>Action Error</h3><p>' + String(e.message || e) + '</p></div>';
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Action Error");
  }
}

function lrDockGo(dir){
  try{
    if(typeof go === "function"){
      go(dir);
      return;
    }
    if(typeof travelJourney === "function"){
      const loc = (state && state.journeyLoc) || "village";
      const hub = (typeof LR_WORLD_HUB !== "undefined") ? LR_WORLD_HUB[loc] : null;
      if(hub && hub.paths && hub.paths[dir]) travelJourney(hub.paths[dir]);
    }
  }catch(e){
    console.error(e);
  }
}

function lrCreateFixedGameplayDock(){
  let dock = document.getElementById("lrFixedGameplayDock");
  if(dock) return;

  dock = document.createElement("div");
  dock.id = "lrFixedGameplayDock";
  dock.innerHTML = `
    <div class="lrDockBlock">
      <div class="lrDockHeading">🧭 Move</div>
      <div class="lrCompassDock">
        <span></span><button onclick="lrDockGo('north')">North</button><span></span>
        <button onclick="lrDockGo('west')">West</button><button onclick="lrDockSafeClick('openJourneyWorld')">Here</button><button onclick="lrDockGo('east')">East</button>
        <span></span><button onclick="lrDockGo('south')">South</button><span></span>
      </div>
    </div>
    <div class="lrDockBlock">
      <div class="lrDockHeading">✨ Interact</div>
      <div class="lrActionDock">
        <button onclick="lrDockSafeClick('openJourneyWorld')">Journey</button>
        <button onclick="lrDockSafeClick('openVillageSquare')">Village</button>
        <button onclick="lrDockSafeClick('openQuestBoard')">Quests</button>
        <button onclick="lrDockSafeClick('openBackpack')">Backpack</button>
        <button onclick="lrDockSafeClick('openCraftingStation')">Craft</button>
        <button onclick="lrDockSafeClick('openAchievementJournal')">Achievements</button>
      </div>
    </div>`;

  const roomText = document.getElementById("roomText");
  const target = roomText && roomText.parentElement ? roomText.parentElement : document.body;
  target.appendChild(dock);
}

function lrHideLooseUtilityButtons(){
  const keep = document.getElementById("lrFixedGameplayDock");
  const labels = ["journey","village square","quest board","backpack","crafting","achievements","wardrobe","regions","museum","castle","cozy","home decor","dream home","living home"];
  document.querySelectorAll("button").forEach(function(btn){
    if(keep && keep.contains(btn)) return;
    const t = (btn.textContent || "").toLowerCase();
    const isLoose = btn.parentElement === document.body || btn.parentElement.tagName === "MAIN";
    if(isLoose && labels.some(function(x){ return t.includes(x); })){
      btn.classList.add("lrLooseButtonHidden");
    }
  });
}

function lrApplyFixedDockLayout(){
  lrCreateFixedGameplayDock();
  lrHideLooseUtilityButtons();
}

window.addEventListener("load", function(){
  setTimeout(lrApplyFixedDockLayout, 100);
  setTimeout(lrApplyFixedDockLayout, 600);
});

if(typeof renderRoom === "function" && !window.__lrFixedDockWrapped){
  window.__lrFixedDockWrapped = true;
  const __oldRenderRoomFixedDock = renderRoom;
  renderRoom = function(){
    __oldRenderRoomFixedDock();
    setTimeout(lrApplyFixedDockLayout, 50);
  };
}
/* End Layout Pack FIXED DOCK 2 */


/* UI Reorganization Hotfix 2 - Always Visible Center Controls */
function lrSafeAction(fnName){
  try{
    if(typeof window[fnName] === "function"){
      window[fnName]();
      return;
    }
    actionTitle.textContent = "Action";
    actionText.innerHTML = '<div class="journalPage"><h3>Not ready yet</h3><p>This action is not loaded in this build.</p></div>';
    if(typeof lrOpenActionPopup === "function") lrOpenActionPopup("Action");
  }catch(e){
    console.error(e);
  }
}

function lrMoveFromCenter(dir){
  try{
    if(typeof go === "function"){
      go(dir);
      return;
    }
    if(typeof travelJourney === "function"){
      var loc = (state && state.journeyLoc) || "village";
      var hub = (typeof LR_WORLD_HUB !== "undefined") ? LR_WORLD_HUB[loc] : null;
      if(hub && hub.paths && hub.paths[dir]){
        travelJourney(hub.paths[dir]);
        return;
      }
    }
  }catch(e){
    console.error(e);
  }
}

function lrCreateCenterActionDock(){
  var existing = document.getElementById("lrCenterActionDock");
  if(existing) return existing;

  var dock = document.createElement("div");
  dock.id = "lrCenterActionDock";
  dock.innerHTML = `
    <div class="centerDockSection">
      <h3>🧭 Navigation</h3>
      <div class="centerCompass">
        <span></span><button type="button" onclick="lrMoveFromCenter('up'); lrMoveFromCenter('north');">UP</button><span></span>
        <button type="button" onclick="lrMoveFromCenter('west')">WEST</button>
        <button type="button" onclick="lrSafeAction('openJourneyWorld')">LOOK</button>
        <button type="button" onclick="lrMoveFromCenter('east')">EAST</button>
        <span></span><button type="button" onclick="lrMoveFromCenter('out'); lrMoveFromCenter('south');">OUT</button><span></span>
      </div>
    </div>
    <div class="centerDockSection">
      <h3>✨ Action</h3>
      <div class="centerActions">
        <button type="button" onclick="lrSafeAction('openJourneyWorld')">Journey</button>
        <button type="button" onclick="lrSafeAction('openVillageSquare')">Village</button>
        <button type="button" onclick="lrSafeAction('openQuestBoard')">Quests</button>
        <button type="button" onclick="lrSafeAction('openBackpack')">Pack</button>
        <button type="button" onclick="lrSafeAction('openCraftingStation')">Craft</button>
        <button type="button" onclick="lrSafeAction('openAchievementJournal')">Achievements</button>
      </div>
    </div>`;

  var roomText = document.getElementById("roomText");
  var target = roomText && roomText.parentElement ? roomText.parentElement : document.body;
  if(roomText && roomText.nextSibling){
    target.insertBefore(dock, roomText.nextSibling);
  }else{
    target.appendChild(dock);
  }
  return dock;
}

function lrKeepCenterControlsVisible(){
  var dock = lrCreateCenterActionDock();
  dock.style.display = "block";
  dock.querySelectorAll("button").forEach(function(b){ b.style.display = ""; });
}

window.addEventListener("load", function(){
  setTimeout(lrKeepCenterControlsVisible, 50);
  setTimeout(lrKeepCenterControlsVisible, 300);
  setTimeout(lrKeepCenterControlsVisible, 900);
});

if(typeof renderRoom === "function" && !window.__lrCenterDockHotfixWrapped){
  window.__lrCenterDockHotfixWrapped = true;
  var __oldRenderRoomCenterDock = renderRoom;
  renderRoom = function(){
    __oldRenderRoomCenterDock();
    setTimeout(lrKeepCenterControlsVisible, 40);
  };
}
/* End UI Reorganization Hotfix 2 */

renderRoom();
 enterHomePortal();
}


/* Interface Pack 5C: Sierra window conversion */
function openParentPopup(){
 let html = "<p>Parent tools coming here.</p>";
 html += "<p>Future home for reports, schedules, and curriculum oversight.</p>";
 lrOpenPopup("Parent Dashboard", html);
}

function openShopPopup(){
 let html = "<p>No shop here.</p>";
 const shops = {
   seasonalShop:"Seasonal Curios",
   pictureShop:"Picture Gallery",
   luckyKettle:"Lucky Kettle",
   shiftyTent:"Shifty Tent"
 };
 if(shops[state.loc]){
   html = `<p><b>${shops[state.loc]}</b></p><p>The shop window system will live here.</p>`;
 }
 lrOpenPopup("Shop", html);
}

const _oldMainGameplay = lrRenderMainGameplayActions;
lrRenderMainGameplayActions = function(){
 _oldMainGameplay();

 const mount = $("mainGameplayActions");
 if(!mount) return;

 const roomButtons = [];

 if(["seasonalShop","pictureShop","luckyKettle","shiftyTent"].includes(state.loc)){
   roomButtons.push('<button onclick="openShopPopup()">🛒 Open Shop Window</button>');
 }

 if(state.loc === "questBoardPlaza"){
   roomButtons.push('<button onclick="openQuestPopup()">📜 Open Quest Board</button>');
 }

 roomButtons.push('<button onclick="openParentPopup()">👨‍👩‍👧 Parent Dashboard</button>');

 mount.innerHTML += `
 <div class="sierraRoomWindows">
   <div class="mainGameplayTitle">Windows</div>
   <div class="mainGameplayGrid">
     ${roomButtons.join("")}
   </div>
 </div>`;
}


/* Home Expansion Pack 1A: Home button in main gameplay area */
const _lrHomeExpansion_oldMainGameplay = lrRenderMainGameplayActions;
lrRenderMainGameplayActions = function(){
  _lrHomeExpansion_oldMainGameplay();
  const mount = $("mainGameplayActions");
  if(!mount) return;
  const r = room();
  const isHome = state.loc === "home" || ((r.zone || "").toLowerCase().includes("home")) || ((r.title || "").toLowerCase().includes("home"));
  if(isHome){
    mount.innerHTML += `<div class="homeExpansionQuickBox"><div class="mainGameplayTitle">Home</div><div class="mainGameplayGrid"><button type="button" onclick="openHomeViewPopup()">🏠 View Home</button><button type="button" onclick="openHomeExpansionPopup()">🛠️ Expand / Manage Home</button></div></div>`;
  }
};


/* Home Expansion Pack 1B: ensure Home View button appears */
if(typeof lrRenderMainGameplayActions === "function" && !window.__lrHome1BMainPatched){
  window.__lrHome1BMainPatched = true;
  const _lrHome1B_oldMain = lrRenderMainGameplayActions;
  lrRenderMainGameplayActions = function(){
    _lrHome1B_oldMain();
    const mount = $("mainGameplayActions");
    if(!mount || !lrIsHomeRoom()) return;
    if(mount.innerHTML.indexOf("openHomeViewPopup") === -1){
      mount.innerHTML += `<div class="homeExpansionQuickBox"><div class="mainGameplayTitle">Home View</div><div class="mainGameplayGrid"><button type="button" onclick="openHomeViewPopup()">🏠 View Home Rooms</button><button type="button" onclick="openHomeExpansionPopup()">🛠️ Expand / Manage Home</button></div></div>`;
    }
  };
}


/* Decoration Placement Pack 1: Home Display Slots */
const LR_DECOR_SLOTS = [
  {id:"wallLeft", name:"Left Wall", icon:"🖼️", keywords:/picture|painting|map|banner|wall|scroll|chart/i},
  {id:"wallRight", name:"Right Wall", icon:"🖼️", keywords:/picture|painting|map|banner|wall|scroll|chart/i},
  {id:"rug", name:"Floor Rug", icon:"🧶", keywords:/rug|mat|carpet/i},
  {id:"table", name:"Tabletop", icon:"🪵", keywords:/token|stone|lantern|feather|relic|trophy|figure|model|charm|parcel/i},
  {id:"shelf", name:"Shelf", icon:"🏺", keywords:/book|journal|tome|scroll|statue|relic|feather|token|lantern|stone|trophy/i},
  {id:"petSpot", name:"Pet Spot", icon:"🐾", keywords:/rabbit|duck|owl|squirrel|frog|pet|companion/i},
  {id:"bed", name:"Bed / Loft", icon:"🛏️", keywords:/blanket|pillow|quilt|bed/i},
  {id:"hearth", name:"Hearth", icon:"🔥", keywords:/lantern|kettle|candle|fire|hearth/i}
];

function lrEnsureDecor(){
  const h = ensureHome();
  if(!h.decor) h.decor = {};
  LR_DECOR_SLOTS.forEach(s=>{ if(h.decor[s.id] === undefined) h.decor[s.id] = null; });
  return h.decor;
}

function lrItemName(item){
  if(!item) return "";
  return typeof item === "string" ? item : (item.name || "");
}

function lrDecorInventory(){
  const h = ensureHome();
  const seen = {};
  return (h.storage || []).filter(item=>{
    const name = lrItemName(item);
    if(!name || seen[name]) return false;
    seen[name] = true;
    return true;
  });
}

function lrSuggestedSlotForItem(name){
  const slot = LR_DECOR_SLOTS.find(s=>s.keywords.test(name || ""));
  return slot ? slot.id : "shelf";
}

function lrPlaceDecor(slotId, itemName){
  const h = ensureHome();
  const decor = lrEnsureDecor();
  const item = (h.storage || []).find(x=>lrItemName(x) === itemName);
  if(!item){
    $("feedback").textContent = "That item is not in storage.";
    return;
  }
  decor[slotId] = {name:itemName};
  addMemory("Home Decor", activeChild + " displayed " + itemName + " in " + (LR_DECOR_SLOTS.find(s=>s.id===slotId)?.name || slotId) + ".");
  save();
  openDecorPlacementPopup();
  renderStats();
}

function lrClearDecor(slotId){
  const decor = lrEnsureDecor();
  decor[slotId] = null;
  save();
  openDecorPlacementPopup();
  renderStats();
}

function lrDecorSlotHtml(slot){
  const decor = lrEnsureDecor();
  const current = decor[slot.id];
  const inventory = lrDecorInventory();
  const options = inventory.map(item=>{
    const name = lrItemName(item);
    const selected = current && current.name === name ? "selected" : "";
    return `<option value="${lrEscape(name)}" ${selected}>${lrEscape(name)}</option>`;
  }).join("");

  return `<div class="decorSlotCard">
    <div class="decorSlotIcon">${slot.icon}</div>
    <div class="decorSlotBody">
      <b>${lrEscape(slot.name)}</b>
      <p>${current ? "Displaying: " + lrEscape(current.name) : "Empty slot"}</p>
      <div class="decorControls">
        <select id="decorSelect_${slot.id}">
          <option value="">Choose item...</option>
          ${options}
        </select>
        <button type="button" onclick="lrPlaceDecor('${slot.id}', $('decorSelect_${slot.id}').value)">Place</button>
        <button type="button" onclick="lrClearDecor('${slot.id}')">Clear</button>
      </div>
    </div>
  </div>`;
}

function lrDecorScore(){
  const decor = lrEnsureDecor();
  return Object.values(decor).filter(Boolean).length * 5;
}

function openDecorPlacementPopup(){
  const h = ensureHome();
  const decor = lrEnsureDecor();
  const inventory = lrDecorInventory();
  let html = `<div class="decorIntro">
    <p>Place treasures, pets, wall items, rugs, and keepsakes into visible Home slots. This is the first simple Animal Crossing-style display layer.</p>
    <p><b>Items in storage:</b> ${inventory.length}</p>
    <p><b>Filled slots:</b> ${Object.values(decor).filter(Boolean).length} / ${LR_DECOR_SLOTS.length}</p>
  </div>`;
  html += `<div class="decorSlotGrid">${LR_DECOR_SLOTS.map(lrDecorSlotHtml).join("")}</div>`;
  html += `<div class="decorPreview"><h3>Home Preview</h3>${lrHomeDecorPreviewHtml()}</div>`;
  lrOpenPopup("Decorate Home", html);
}

function lrHomeDecorPreviewHtml(){
  const decor = lrEnsureDecor();
  return `<div class="homePreviewRoom">
    <div class="previewWall">
      <div class="previewItem wall">${decor.wallLeft ? lrEscape(decor.wallLeft.name) : "Left Wall Empty"}</div>
      <div class="previewItem wall">${decor.wallRight ? lrEscape(decor.wallRight.name) : "Right Wall Empty"}</div>
    </div>
    <div class="previewShelf">${decor.shelf ? lrEscape(decor.shelf.name) : "Shelf Empty"}</div>
    <div class="previewTable">${decor.table ? lrEscape(decor.table.name) : "Table Empty"}</div>
    <div class="previewHearth">${decor.hearth ? lrEscape(decor.hearth.name) : "Hearth Empty"}</div>
    <div class="previewPet">${decor.petSpot ? lrEscape(decor.petSpot.name) : "Pet Spot Empty"}</div>
    <div class="previewBed">${decor.bed ? lrEscape(decor.bed.name) : "Loft Empty"}</div>
    <div class="previewRug">${decor.rug ? lrEscape(decor.rug.name) : "Rug Empty"}</div>
  </div>`;
}

/* Add decoration score into prestige if prestige exists. */
if(typeof lrRecalcPrestige === "function" && !window.__lrDecorPrestigePatched){
  window.__lrDecorPrestigePatched = true;
  const _oldDecorPrestige = lrRecalcPrestige;
  lrRecalcPrestige = function(){
    const p = _oldDecorPrestige();
    p.decor = (p.decor || 0) + lrDecorScore();
    return p;
  };
}

/* Add Decorate button in Home gameplay area. */
if(typeof lrRenderMainGameplayActions === "function" && !window.__lrDecorButtonPatched){
  window.__lrDecorButtonPatched = true;
  const _oldDecorMain = lrRenderMainGameplayActions;
  lrRenderMainGameplayActions = function(){
    _oldDecorMain();
    const mount = $("mainGameplayActions");
    if(!mount || !lrIsHomeRoom()) return;
    if(mount.innerHTML.indexOf("openDecorPlacementPopup") === -1){
      mount.innerHTML += `<div class="homeExpansionQuickBox"><div class="mainGameplayTitle">Decor</div><div class="mainGameplayGrid"><button type="button" onclick="openDecorPlacementPopup()">🖼️ Decorate Home</button></div></div>`;
    }
  };
}
/* End Decoration Placement Pack 1 */




/* 6.2E SANITIZED OVERRIDES: keep the real game shell visible */
try{
  window.lrHardHideButtonExplosion = function(){};
  lrHardHideButtonExplosion = window.lrHardHideButtonExplosion;
}catch(e){}
try{
  window.lrHideLooseUtilityButtons = function(){};
  lrHideLooseUtilityButtons = window.lrHideLooseUtilityButtons;
}catch(e){}
try{
  window.lrCleanDuplicateUtilityButtons = function(){};
  lrCleanDuplicateUtilityButtons = window.lrCleanDuplicateUtilityButtons;
}catch(e){}
try{
  window.lrRunPostRenderAudit = function(){};
  lrRunPostRenderAudit = window.lrRunPostRenderAudit;
}catch(e){}
/* End 6.2E SANITIZED OVERRIDES */
