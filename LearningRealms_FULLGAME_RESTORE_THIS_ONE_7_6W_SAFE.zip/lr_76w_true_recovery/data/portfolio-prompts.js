// Portfolio Prompts v1
// Written/project-style prompts for longer classroom blocks.
// These are not normal quiz questions. They are meant for saved written responses and parent review.

window.LR_PORTFOLIO_PROMPTS = {
  Luna:[
    {
      id:"LUNA-READ-RETELL-1",
      subject:"Reading",
      unit:"G1-READ-COMP",
      title:"Retell a Story",
      prompt:"Tell what happened in the story using beginning, middle, and end.",
      helper:"Use: First..., Next..., Last...",
      estimatedMinutes:15
    },
    {
      id:"LUNA-WRITE-SENTENCE-1",
      subject:"English",
      unit:"G1-ELA-WRITING",
      title:"Write a Detailed Sentence",
      prompt:"Write one sentence about an animal. Add where it is or what it is doing.",
      helper:"Example pattern: The ___ is ___ in the ___.",
      estimatedMinutes:10
    },
    {
      id:"LUNA-MATH-STORY-1",
      subject:"Math",
      unit:"G1-MATH-FACTS",
      title:"Make an Addition Story",
      prompt:"Make your own addition story problem using two numbers under 10.",
      helper:"Example: I found 4 shells and then 3 more. How many?",
      estimatedMinutes:10
    },
    {
      id:"LUNA-SCI-OBSERVE-1",
      subject:"Science",
      unit:"G1-SCI-EARTH",
      title:"Weather Observation",
      prompt:"Look outside or imagine today's weather. Write or tell three things you notice.",
      helper:"Think about sky, wind, temperature, rain, sun, or clouds.",
      estimatedMinutes:10
    }
  ],

  Ava:[
    {
      id:"AVA-ELA-CER-1",
      subject:"English",
      unit:"G7-ELA-WRITING",
      title:"CER Reading Response",
      prompt:"Write a short CER response about a character's choice. Make a claim, give evidence, and explain your reasoning.",
      helper:"Claim: ___ Evidence: ___ Reasoning: ___",
      estimatedMinutes:25
    },
    {
      id:"AVA-MATH-RATIO-1",
      subject:"Math",
      unit:"G7-MATH-RATIO",
      title:"Real-Life Ratio Problem",
      prompt:"Create and solve a real-life ratio or unit-rate problem.",
      helper:"Example topics: miles per hour, recipes, prices, or scale drawings.",
      estimatedMinutes:20
    },
    {
      id:"AVA-SCI-EXPERIMENT-1",
      subject:"Science",
      unit:"G7-SCI-PHYSICAL",
      title:"Design a Fair Test",
      prompt:"Design a controlled experiment. State the question, independent variable, dependent variable, and constants.",
      helper:"Only one main variable should change.",
      estimatedMinutes:25
    },
    {
      id:"AVA-HIST-SOURCE-1",
      subject:"History",
      unit:"G7-SS-SOURCES",
      title:"Primary Source Check",
      prompt:"Explain whether a diary, photo, map, or letter would be useful as a primary source. Tell why.",
      helper:"Think: Who made it? When? What can it prove?",
      estimatedMinutes:20
    }
  ],

  Michael:[
    {
      id:"MICHAEL-ARG-1",
      subject:"English",
      unit:"G8-ELA-ARG",
      title:"Argument Paragraph",
      prompt:"Write one argument paragraph with a claim, evidence, reasoning, and a counterclaim or rebuttal.",
      helper:"Keep it clear and direct. Avoid weak evidence.",
      estimatedMinutes:30
    },
    {
      id:"MICHAEL-MATH-FUNC-1",
      subject:"Math",
      unit:"G8-MATH-FUNC",
      title:"Function Explanation",
      prompt:"Explain slope and y-intercept in your own words, then create a simple linear equation and describe what it means.",
      helper:"Use y = mx + b.",
      estimatedMinutes:25
    },
    {
      id:"MICHAEL-SCI-FORCE-1",
      subject:"Science",
      unit:"G8-SCI-FORCE",
      title:"Force and Motion Explanation",
      prompt:"Explain how force, mass, and acceleration are connected. Give a real-life example.",
      helper:"Use F = ma in your explanation.",
      estimatedMinutes:25
    },
    {
      id:"MICHAEL-CIVICS-1",
      subject:"History",
      unit:"G8-SS-CIVICS",
      title:"Checks and Balances Response",
      prompt:"Explain why checks and balances matter. Give one example of one branch limiting another.",
      helper:"Use the words power, branch, and limit.",
      estimatedMinutes:25
    }
  ]
};
