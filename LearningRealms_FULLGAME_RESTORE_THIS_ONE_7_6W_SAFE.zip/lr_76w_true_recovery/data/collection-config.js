// Game Fun Pack 2: Collection Log & Title Book
// Pure config for collection categories and title rewards.
// Engine patch lives in app.js.

window.LR_COLLECTION_CONFIG = {
  categories:[
    {id:"realms",title:"Realm Discovery",icon:"🗺️",desc:"Zones and realms visited while adventuring."},
    {id:"subjects",title:"Subject Mastery Seeds",icon:"📚",desc:"Subjects where the student has earned at least one correct answer."},
    {id:"bosses",title:"Boss Clears",icon:"⚔️",desc:"Subject bosses cleared."},
    {id:"items",title:"Home Treasures",icon:"🏠",desc:"Unique home rewards found or equipped."},
    {id:"achievements",title:"Achievements",icon:"🏅",desc:"Claimed achievements from the Quest Board."},
    {id:"titles",title:"Titles",icon:"👑",desc:"Earned titles that can be equipped."},
    {id:"badges",title:"Badges",icon:"🎖️",desc:"Academic ladder badges and special badges earned."}
  ],

  starterTitles:[
    {id:"new_adventurer",title:"New Adventurer",unlock:"Always available."},
    {id:"realm_learner",title:"Realm Learner",unlock:"Answer 10 questions."},
    {id:"steady_student",title:"Steady Student",unlock:"Get 25 correct lesson answers."},
    {id:"room_roamer",title:"Room Roamer",unlock:"Visit 50 rooms."},
    {id:"subject_scout",title:"Subject Scout",unlock:"Get correct answers in 5 subjects."},
    {id:"boss_challenger",title:"Boss Challenger",unlock:"Attempt a boss."}
  ],

  completionRewards:[
    {id:"items_10",category:"items",target:10,title:"Treasure Keeper",reward:{sparks:50,xp:60,item:{name:"Treasure Keeper Shelf Plaque",slot:"wall"}}},
    {id:"realms_10",category:"realms",target:10,title:"Realm Cartographer",reward:{sparks:75,xp:80,item:{name:"Realm Cartographer Map",slot:"wall"}}},
    {id:"subjects_8",category:"subjects",target:8,title:"Subject Explorer",reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Subject Explorer Crest",slot:"wall"}}},
    {id:"bosses_5",category:"bosses",target:5,title:"Boss Trophy Hunter",reward:{sparks:150,xp:175,ancientCoins:2,item:{name:"Boss Trophy Hunter Statue",slot:"shelf"}}}
  ]
};
