// Curriculum Architecture v1
// Batch 1: structure only.
// No engine changes required.
// This file gives the game a school-year curriculum map that future packs can plug into.
//
// Long-term structure:
// Child -> Subject -> Unit -> Skills -> Future Lessons / Reviews / Bosses / Projects
//
// Future lesson packs can later tag lessons like:
// unit:"G1-READ-PHONICS"
// skill:"short-vowels"
// difficulty:"core"
// mode:"lesson" / "review" / "checkpoint" / "boss"

window.LR_CURRICULUM_MAP = {
  version:"1.0",
  designNote:"This map is designed to scale to thousands of lessons and many future subjects without rewriting the engine.",

  Luna:{
    gradeLabel:"Grade 1",
    yearGoal:"Finish a full first-grade core with strong phonics, reading fluency, early writing, math facts, place value, science observation, and social studies basics.",
    subjects:{
      Reading:{
        zone:"Whisperwood",
        units:[
          {
            id:"G1-READ-PHONICS",
            title:"Phonics and Word Reading",
            goal:"Build strong decoding using short vowels, long vowels, blends, digraphs, and common spelling patterns.",
            targetLessons:400,
            skills:["short vowels","long vowels","final e","consonant blends","digraphs","sight words","word families","fluency"]
          },
          {
            id:"G1-READ-COMP",
            title:"Reading Comprehension",
            goal:"Understand characters, setting, problem, solution, main idea, details, and sequence.",
            targetLessons:250,
            skills:["character","setting","problem","solution","main idea","details","sequence","retell"]
          },
          {
            id:"G1-READ-FLUENCY",
            title:"Reading Fluency",
            goal:"Read grade-level sentences and short passages smoothly with understanding.",
            targetLessons:200,
            skills:["sentence reading","phrase reading","expression","accuracy","rereading"]
          }
        ]
      },
      English:{
        zone:"Grammar Grove",
        units:[
          {
            id:"G1-ELA-SENTENCES",
            title:"Sentences and Grammar",
            goal:"Write complete sentences with capitals, punctuation, nouns, verbs, adjectives, and pronouns.",
            targetLessons:250,
            skills:["complete sentences","capital letters","punctuation","nouns","verbs","adjectives","pronouns"]
          },
          {
            id:"G1-ELA-WRITING",
            title:"Early Writing",
            goal:"Answer questions in complete sentences, retell stories, and add details.",
            targetLessons:200,
            skills:["restating questions","adding details","retelling","because answers","beginning-middle-end"]
          }
        ]
      },
      Math:{
        zone:"Iron Hills",
        units:[
          {
            id:"G1-MATH-FACTS",
            title:"Addition and Subtraction",
            goal:"Master addition and subtraction within 20 with strategies and fact fluency.",
            targetLessons:350,
            skills:["addition within 20","subtraction within 20","make ten","doubles","near doubles","fact families"]
          },
          {
            id:"G1-MATH-PLACE",
            title:"Place Value",
            goal:"Understand tens and ones, compare numbers, and count by 1s, 5s, and 10s.",
            targetLessons:250,
            skills:["tens and ones","compare numbers","count by 5","count by 10","number lines"]
          },
          {
            id:"G1-MATH-MEASURE",
            title:"Measurement, Time, Money, and Shapes",
            goal:"Read time, count coins, compare lengths, and identify 2D/3D shapes.",
            targetLessons:250,
            skills:["time","coins","length","picture graphs","2D shapes","3D shapes","symmetry"]
          }
        ]
      },
      Science:{
        zone:"Crystal Marsh",
        units:[
          {
            id:"G1-SCI-LIFE",
            title:"Plants and Animals",
            goal:"Observe living things, plant parts, animal groups, needs, and habitats.",
            targetLessons:200,
            skills:["living things","plant parts","animal parts","habitats","animal groups","basic needs"]
          },
          {
            id:"G1-SCI-PHYSICAL",
            title:"Light, Sound, Magnets, and Motion",
            goal:"Explore shadows, vibrations, magnets, floating/sinking, and pushes/pulls.",
            targetLessons:150,
            skills:["light","shadows","sound","vibrations","magnets","pushes and pulls","float and sink"]
          },
          {
            id:"G1-SCI-EARTH",
            title:"Weather and Seasons",
            goal:"Observe weather, seasons, temperature, and sky patterns.",
            targetLessons:150,
            skills:["weather","seasons","sunny","rainy","windy","snowy","daily observation"]
          }
        ]
      },
      History:{
        zone:"Kingdom Archives",
        units:[
          {
            id:"G1-SS-COMMUNITY",
            title:"Community and Citizenship",
            goal:"Learn rules, helpers, leaders, citizens, needs, wants, goods, and services.",
            targetLessons:200,
            skills:["rules","community helpers","leaders","citizens","needs","wants","goods","services"]
          },
          {
            id:"G1-SS-MAPS",
            title:"Maps, Timelines, and Past/Present",
            goal:"Use maps, globes, symbols, timelines, and time words.",
            targetLessons:150,
            skills:["maps","globes","symbols","timelines","past","present","future"]
          }
        ]
      }
    }
  },

  Ava:{
    gradeLabel:"Grade 7",
    yearGoal:"Finish a strong seventh-grade core across ratios, proportional reasoning, integers, equations, geometry, statistics, evidence-based reading, writing, science, history, civics, and economics.",
    subjects:{
      Math:{
        zone:"Iron Hills",
        units:[
          {
            id:"G7-MATH-RATIO",
            title:"Ratios, Proportions, and Percent",
            goal:"Master ratios, unit rates, proportional relationships, percent increase/decrease, and scale.",
            targetLessons:500,
            skills:["ratios","unit rates","proportions","constant of proportionality","percent","markup","discount","scale factor"]
          },
          {
            id:"G7-MATH-INT",
            title:"Integers, Rational Numbers, and Expressions",
            goal:"Fluently operate with positive and negative numbers, fractions, decimals, and expressions.",
            targetLessons:450,
            skills:["integer addition","integer subtraction","integer multiplication","integer division","rational numbers","equivalent expressions","like terms"]
          },
          {
            id:"G7-MATH-EQ",
            title:"Equations and Inequalities",
            goal:"Solve multi-step equations and inequalities using inverse operations.",
            targetLessons:350,
            skills:["one-step equations","two-step equations","multi-step equations","inequalities","variables"]
          },
          {
            id:"G7-MATH-GEO-DATA",
            title:"Geometry, Probability, and Statistics",
            goal:"Work with circles, area, volume, angle relationships, probability, and data spread.",
            targetLessons:400,
            skills:["circle area","circumference","area","volume","angles","probability","mean","median","mode","MAD"]
          }
        ]
      },
      English:{
        zone:"Grammar Grove",
        units:[
          {
            id:"G7-ELA-EVIDENCE",
            title:"Reading Evidence and Inference",
            goal:"Answer reading questions using evidence, inference, theme, central idea, and context clues.",
            targetLessons:450,
            skills:["text evidence","inference","theme","central idea","context clues","point of view","tone"]
          },
          {
            id:"G7-ELA-WRITING",
            title:"Paragraphs, CER, and Written Response",
            goal:"Write clear responses with claims, evidence, reasoning, transitions, and conclusions.",
            targetLessons:400,
            skills:["claim","evidence","reasoning","CER","topic sentence","paragraph","summary","conclusion"]
          },
          {
            id:"G7-ELA-LANGUAGE",
            title:"Vocabulary and Language",
            goal:"Use roots, prefixes, suffixes, domain words, precise verbs, and grammar conventions.",
            targetLessons:250,
            skills:["roots","prefixes","suffixes","domain vocabulary","precise language","grammar"]
          }
        ]
      },
      Science:{
        zone:"Crystal Marsh",
        units:[
          {
            id:"G7-SCI-LIFE",
            title:"Life Science and Ecosystems",
            goal:"Understand cells, adaptations, food webs, energy flow, biodiversity, and interactions.",
            targetLessons:450,
            skills:["cells","cell parts","adaptations","producers","consumers","decomposers","food webs","biodiversity"]
          },
          {
            id:"G7-SCI-EARTH",
            title:"Earth Science",
            goal:"Study water cycle, weathering, erosion, deposition, rocks, fossils, watersheds, and weather/climate.",
            targetLessons:350,
            skills:["water cycle","weathering","erosion","deposition","rock types","fossils","watersheds","weather","climate"]
          },
          {
            id:"G7-SCI-PHYSICAL",
            title:"Forces, Motion, and Scientific Practice",
            goal:"Use models, experiments, variables, data, forces, speed, and graph interpretation.",
            targetLessons:300,
            skills:["forces","speed","variables","controlled experiment","models","data tables","graphs","conclusions"]
          }
        ]
      },
      History:{
        zone:"Kingdom Archives",
        units:[
          {
            id:"G7-SS-SOURCES",
            title:"Historical Thinking and Sources",
            goal:"Analyze primary/secondary sources, context, chronology, cause/effect, fact/opinion, and bias.",
            targetLessons:350,
            skills:["primary sources","secondary sources","context","chronology","cause and effect","fact vs opinion","bias"]
          },
          {
            id:"G7-SS-CIVICS",
            title:"Civics and Government",
            goal:"Understand citizenship, limited government, democracy, rights, responsibilities, and public services.",
            targetLessons:300,
            skills:["citizenship","rights","responsibilities","limited government","democracy","taxes","public services"]
          },
          {
            id:"G7-SS-ECON",
            title:"Economics",
            goal:"Understand supply, demand, trade, budgets, scarcity, goods, services, and choices.",
            targetLessons:250,
            skills:["supply","demand","trade","budget","scarcity","goods","services","resources"]
          }
        ]
      }
    }
  },

  Michael:{
    gradeLabel:"Grade 8",
    yearGoal:"Finish a strong eighth-grade core across algebra, functions, systems, geometry, data, argument writing, research, physical science, civics, history, and economics.",
    subjects:{
      Math:{
        zone:"Iron Hills",
        units:[
          {
            id:"G8-MATH-EQ",
            title:"Equations and Algebraic Reasoning",
            goal:"Solve linear equations, equations with variables on both sides, and multi-step algebra problems.",
            targetLessons:550,
            skills:["linear equations","multi-step equations","variables both sides","distributive property","like terms"]
          },
          {
            id:"G8-MATH-FUNC",
            title:"Functions, Slope, and Systems",
            goal:"Understand functions, slope, intercepts, proportional/nonproportional relationships, and systems.",
            targetLessons:550,
            skills:["functions","slope","y-intercept","x-intercept","slope-intercept form","systems","substitution","elimination"]
          },
          {
            id:"G8-MATH-GEO-DATA",
            title:"Geometry, Transformations, and Data",
            goal:"Use Pythagorean theorem, transformations, volume, scatter plots, trend lines, and two-way tables.",
            targetLessons:450,
            skills:["Pythagorean theorem","transformations","dilations","volume","scatter plots","trend lines","two-way tables"]
          },
          {
            id:"G8-MATH-NUMBERS",
            title:"Scientific Notation and Number Systems",
            goal:"Work with scientific notation, powers of ten, rational/irrational numbers, and estimates.",
            targetLessons:300,
            skills:["scientific notation","powers of ten","rational numbers","irrational numbers","estimation"]
          }
        ]
      },
      English:{
        zone:"Grammar Grove",
        units:[
          {
            id:"G8-ELA-ARG",
            title:"Argument Writing",
            goal:"Write arguments with precise claims, evidence, reasoning, counterclaims, rebuttals, and transitions.",
            targetLessons:500,
            skills:["claim","thesis","evidence","reasoning","counterclaim","rebuttal","transitions","academic tone"]
          },
          {
            id:"G8-ELA-RESEARCH",
            title:"Research and Source Reliability",
            goal:"Evaluate sources, cite information, paraphrase, corroborate, and organize research.",
            targetLessons:400,
            skills:["source reliability","author","date","purpose","bias","citation","paraphrase","corroboration","sourcing"]
          },
          {
            id:"G8-ELA-READING",
            title:"Reading, Inference, and Analysis",
            goal:"Analyze theme, central idea, inference, tone, perspective, source meaning, and evidence.",
            targetLessons:350,
            skills:["inference","theme","central idea","tone","perspective","evidence","analysis"]
          }
        ]
      },
      Science:{
        zone:"Crystal Marsh",
        units:[
          {
            id:"G8-SCI-MATTER",
            title:"Matter, Atoms, and Chemistry",
            goal:"Understand atoms, elements, compounds, mixtures, physical/chemical changes, and conservation of mass.",
            targetLessons:500,
            skills:["atoms","protons","neutrons","electrons","elements","compounds","mixtures","physical change","chemical change","conservation of mass"]
          },
          {
            id:"G8-SCI-FORCE",
            title:"Forces, Motion, Work, and Energy",
            goal:"Use force, mass, acceleration, speed, velocity, work, power, kinetic energy, and potential energy.",
            targetLessons:450,
            skills:["force","mass","acceleration","Newton's laws","speed","velocity","work","power","kinetic energy","potential energy"]
          },
          {
            id:"G8-SCI-WAVES-EARTH",
            title:"Waves and Earth Systems",
            goal:"Study waves, sound, light, thermal energy, rock cycle, weathering, erosion, and earth systems.",
            targetLessons:400,
            skills:["waves","amplitude","frequency","sound","light","thermal energy","rock cycle","weathering","erosion"]
          }
        ]
      },
      History:{
        zone:"Kingdom Archives",
        units:[
          {
            id:"G8-SS-CIVICS",
            title:"Constitution, Government, and Civics",
            goal:"Understand federalism, separation of powers, checks and balances, rule of law, rights, and civic virtue.",
            targetLessons:500,
            skills:["Constitution","federalism","separation of powers","checks and balances","rule of law","Bill of Rights","civil liberties","civic virtue"]
          },
          {
            id:"G8-SS-ECON",
            title:"Economics and Decision Making",
            goal:"Understand scarcity, opportunity cost, supply/demand, specialization, markets, and inflation.",
            targetLessons:350,
            skills:["scarcity","opportunity cost","supply and demand","specialization","markets","inflation","choices"]
          },
          {
            id:"G8-SS-HISTORICAL",
            title:"Historical Analysis",
            goal:"Analyze context, cause/effect, bias, interpretation, evidence, and source perspective.",
            targetLessons:400,
            skills:["historical context","cause and effect","bias","interpretation","evidence","source perspective","chronology"]
          }
        ]
      }
    }
  }
};
