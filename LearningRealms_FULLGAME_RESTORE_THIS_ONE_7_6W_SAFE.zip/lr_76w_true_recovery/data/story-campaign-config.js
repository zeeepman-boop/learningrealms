// Game Fun Pack 9: Story Campaign Quest Chains
// Adds longer guided RPG-style quest chains with stage objectives, rewards, active campaign tracking, and completion rewards.
// Engine patch lives in app.js.

window.LR_STORY_CAMPAIGN_CONFIG = {
  title:"Story Campaign Quest Chains",

  chains:[
    {
      id:"first_realm_expedition",
      title:"First Realm Expedition",
      icon:"🧭",
      intro:"A beginner-friendly campaign that teaches the rhythm of adventuring, solving, exploring, and facing a boss.",
      finalTitle:"Realm Expeditioner",
      stages:[
        {
          id:"solve_any_10",
          title:"Pack Your Learning Bag",
          text:"Answer 10 questions in any subject.",
          metric:"totalAnswers",
          target:10,
          reward:{sparks:20,xp:20,item:{name:"Packed Learning Bag",slot:"shelf"}}
        },
        {
          id:"visit_15_rooms",
          title:"Walk the Realm Roads",
          text:"Visit 15 rooms while exploring.",
          metric:"roomsVisitedTotal",
          target:15,
          reward:{sparks:25,xp:25,item:{name:"Realm Road Boots",slot:"shelf"}}
        },
        {
          id:"subjects_3",
          title:"Try Three Paths",
          text:"Get correct answers in 3 different subjects.",
          metric:"subjectsStarted",
          target:3,
          reward:{sparks:30,xp:30,item:{name:"Three Path Compass",slot:"shelf"}}
        },
        {
          id:"boss_attempt_1",
          title:"Face a Realm Challenge",
          text:"Attempt at least 1 boss challenge.",
          metric:"bossAttemptsTotal",
          target:1,
          reward:{sparks:35,xp:35,item:{name:"Boss Gate Token",slot:"wall"}}
        }
      ],
      completionReward:{sparks:90,xp:100,ancientCoins:1,item:{name:"First Realm Expedition Trophy",slot:"shelf"}}
    },

    {
      id:"citizen_scholar_trial",
      title:"Citizen Scholar Trial",
      icon:"⚖️",
      intro:"A civics campaign through rules, responsibility, services, sources, and fair government.",
      finalTitle:"Citizen Scholar",
      stages:[
        {
          id:"civics_10",
          title:"Learn the Gate Rule",
          text:"Get 10 correct Civics answers.",
          metric:"totalCorrectInSubjects",
          subjects:["Civics"],
          target:10,
          reward:{sparks:25,xp:25,item:{name:"Council Gate Rule Card",slot:"wall"}}
        },
        {
          id:"civics_25",
          title:"Serve the Square",
          text:"Get 25 correct Civics answers.",
          metric:"totalCorrectInSubjects",
          subjects:["Civics"],
          target:25,
          reward:{sparks:45,xp:45,item:{name:"Citizen Square Service Seal",slot:"wall"}}
        },
        {
          id:"civics_boss",
          title:"Stand Before the Court",
          text:"Clear the Civics boss.",
          metric:"bossCleared",
          subject:"Civics",
          target:1,
          reward:{sparks:60,xp:60,ancientCoins:1,item:{name:"Court of Fairness Medal",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:125,xp:125,ancientCoins:2,item:{name:"Citizen Scholar Statue",slot:"shelf"}}
    },

    {
      id:"mapmaker_treasure_route",
      title:"Mapmaker Treasure Route",
      icon:"🗺️",
      intro:"A geography and exploration campaign for finding routes, reading maps, and gathering treasure scraps.",
      finalTitle:"Hidden Route Hunter",
      stages:[
        {
          id:"geo_10",
          title:"Read the First Map",
          text:"Get 10 correct Geography answers.",
          metric:"totalCorrectInSubjects",
          subjects:["Geography"],
          target:10,
          reward:{sparks:25,xp:25,item:{name:"First Route Map",slot:"wall"}}
        },
        {
          id:"map_scraps_3",
          title:"Gather Three Map Scraps",
          text:"Find 3 treasure map scraps from random events.",
          metric:"mapScraps",
          target:3,
          reward:{sparks:50,xp:50,item:{name:"Three Scrap Map",slot:"wall"}}
        },
        {
          id:"events_10",
          title:"Notice the Hidden World",
          text:"Discover 10 random exploration events.",
          metric:"eventTotal",
          target:10,
          reward:{sparks:55,xp:55,item:{name:"Hidden World Journal",slot:"desk"}}
        },
        {
          id:"geo_30",
          title:"Chart the Expanse",
          text:"Get 30 correct Geography answers.",
          metric:"totalCorrectInSubjects",
          subjects:["Geography"],
          target:30,
          reward:{sparks:65,xp:65,ancientCoins:1,item:{name:"Mapmaker Route Crest",slot:"wall"}}
        }
      ],
      completionReward:{sparks:150,xp:160,ancientCoins:2,item:{name:"Mapmaker Treasure Route Trophy",slot:"shelf"}}
    },

    {
      id:"six_hour_school_day",
      title:"Full Classroom Day Campaign",
      icon:"🏫",
      intro:"A serious homeschool campaign for completing the classroom day structure and building a real record.",
      finalTitle:"Full Day Scholar",
      stages:[
        {
          id:"active_60",
          title:"One-Hour Mark",
          text:"Log 60 active learning minutes today.",
          metric:"activeMinutesToday",
          target:60,
          reward:{sparks:25,xp:25,item:{name:"One Hour Class Stamp",slot:"wall"}}
        },
        {
          id:"blocks_3",
          title:"Halfway Through the Schedule",
          text:"Claim 3 classroom block rewards today.",
          metric:"classBlocksClaimedToday",
          target:3,
          reward:{sparks:60,xp:60,item:{name:"Half Schedule Ribbon",slot:"wall"}}
        },
        {
          id:"active_360",
          title:"Complete the Six-Hour Day",
          text:"Log 360 active learning minutes today.",
          metric:"activeMinutesToday",
          target:360,
          reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Six Hour Day Plaque",slot:"wall"}}
        },
        {
          id:"blocks_all",
          title:"Claim the Full Schedule",
          text:"Claim all classroom block rewards today.",
          metric:"classBlocksClaimedToday",
          target:6,
          reward:{sparks:125,xp:125,ancientCoins:1,item:{name:"Full Schedule Seal",slot:"wall"}}
        }
      ],
      completionReward:{sparks:200,xp:225,ancientCoins:3,item:{name:"Full Classroom Day Monument",slot:"shelf"}}
    },

    {
      id:"companion_bond_path",
      title:"Companion Bond Path",
      icon:"🐾",
      intro:"A campaign for training, bonding, and learning beside the student's companion.",
      finalTitle:"Companion Keeper",
      stages:[
        {
          id:"comp_level_2",
          title:"Become Trusted Friends",
          text:"Raise your companion to Level 2.",
          metric:"companionLevel",
          target:2,
          reward:{sparks:30,xp:30,item:{name:"Trusted Friend Collar Tag",slot:"shelf"}}
        },
        {
          id:"comp_bond_10",
          title:"Build a Gentle Bond",
          text:"Reach Companion Bond 10.",
          metric:"companionBond",
          target:10,
          reward:{sparks:45,xp:45,item:{name:"Companion Bond Ribbon",slot:"wall"}}
        },
        {
          id:"comp_subjects_5",
          title:"Learn Across Five Subjects",
          text:"Have companion discoveries in 5 subjects.",
          metric:"companionSubjectDiscoveries",
          target:5,
          reward:{sparks:60,xp:60,ancientCoins:1,item:{name:"Five Subject Pawprint Crest",slot:"wall"}}
        },
        {
          id:"comp_level_5",
          title:"Study Sidekick",
          text:"Raise your companion to Level 5.",
          metric:"companionLevel",
          target:5,
          reward:{sparks:85,xp:85,ancientCoins:1,item:{name:"Study Sidekick Trophy",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:160,xp:175,ancientCoins:2,item:{name:"Companion Keeper Statue",slot:"shelf"}}
    },

    {
      id:"mastery_first_path",
      title:"First Mastery Path",
      icon:"🌟",
      intro:"A long-term subject mastery campaign for pushing any subject beyond basic practice.",
      finalTitle:"First Path Adept",
      stages:[
        {
          id:"one_rank_2",
          title:"Reach Apprentice",
          text:"Reach Rank 2 in at least 1 subject mastery path.",
          metric:"masteryRankSubjectsAt",
          rank:2,
          target:1,
          reward:{sparks:40,xp:40,item:{name:"First Apprentice Star",slot:"wall"}}
        },
        {
          id:"three_rank_2",
          title:"Three Apprentice Paths",
          text:"Reach Rank 2 in at least 3 subject mastery paths.",
          metric:"masteryRankSubjectsAt",
          rank:2,
          target:3,
          reward:{sparks:70,xp:70,ancientCoins:1,item:{name:"Three Apprentice Paths Crest",slot:"wall"}}
        },
        {
          id:"one_rank_3",
          title:"Reach Adept",
          text:"Reach Rank 3 in at least 1 subject mastery path.",
          metric:"masteryRankSubjectsAt",
          rank:3,
          target:1,
          reward:{sparks:90,xp:90,ancientCoins:1,item:{name:"First Adept Path Trophy",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:160,xp:180,ancientCoins:2,item:{name:"First Mastery Path Monument",slot:"shelf"}}
    }
  ]
};
