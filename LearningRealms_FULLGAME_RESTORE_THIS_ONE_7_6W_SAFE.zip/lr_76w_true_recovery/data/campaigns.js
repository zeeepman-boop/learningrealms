window.LR_CAMPAIGNS = {
  Luna:{title:"The Lost Sounds of Whisperwood",chapters:["Find SH sound","Find CH sound","Find TH sound","Restore Story Stone","Wake Silver Owl"],world:["Story Stone is cracked.","The Story Stone glows faintly.","The Silver Owl opens one eye.","Story Stone restored. Reader Rabbit appears."]},
  Ava:{title:"The Broken Lift of Iron Hills",chapters:["Repair survey camp","Fix gear ratios","Restore mine lift","Map tunnel network"],world:["Broken Lift hangs silent.","A repaired gear turns slowly.","Survey maps appear.","Lift restored. Gear Fox arrives."]},
  Michael:{title:"The Shattered Timeline",chapters:["Restore archives","Recover records","Debate in council","Repair timeline"],world:["Timeline shards lie scattered.","Recovered archive pages return.","The council gathers once more.","Timeline restored. Archivist Owl joins."]}
};

window.LR_COMPANIONS = {
  Luna:{name:"Reader Rabbit",stages:["A shy rabbit watches from the grass.","Reader Rabbit follows quietly.","Reader Rabbit finds hidden reading places."],abilities:["Vocabulary hints","Hidden reading rooms"],home:"Reader Rabbit Nook"},
  Ava:{name:"Gear Fox",stages:["A fox studies broken gears.","Gear Fox follows through Iron Hills.","Gear Fox reveals engineering secrets."],abilities:["Math hints","Engineering rewards"],home:"Gear Fox Resting Area"},
  Michael:{name:"Archivist Owl",stages:["An owl circles overhead.","Archivist Owl remembers old lessons.","Archivist Owl reveals archive secrets."],abilities:["Lesson recall","Archive secrets"],home:"Archivist Owl Perch"}
};
