// Game Fun Pack 11: Boss Gauntlets & Capstone Trials
// Adds larger challenge tracks that combine subjects, boss clears, mastery ranks, class blocks,
// adaptive review, companions, treasure maps, and long-term capstone rewards.
// Engine patch lives in app.js.

window.LR_BOSS_GAUNTLET_CONFIG = {
  title:"Boss Gauntlets & Capstone Trials",

  gauntlets:[
    {
      id:"foundation_gauntlet",
      title:"Foundation Gauntlet",
      icon:"🛡️",
      intro:"A beginner gauntlet that proves the student can explore, answer, practice several subjects, and clear a first boss.",
      finalTitle:"Foundation Challenger",
      stages:[
        {
          id:"answer_25",
          title:"Answer 25 Questions",
          text:"Answer 25 total questions across the game.",
          metric:"totalAnswers",
          target:25,
          reward:{sparks:35,xp:35,item:{name:"Foundation Answer Shield",slot:"wall"}}
        },
        {
          id:"subjects_4",
          title:"Practice Four Subjects",
          text:"Get correct answers in 4 different subjects.",
          metric:"subjectsStarted",
          target:4,
          reward:{sparks:45,xp:45,item:{name:"Four Subject Gauntlet Crest",slot:"wall"}}
        },
        {
          id:"rooms_30",
          title:"Explore 30 Rooms",
          text:"Travel through 30 rooms.",
          metric:"roomsVisitedTotal",
          target:30,
          reward:{sparks:50,xp:50,item:{name:"Thirty Room Explorer Token",slot:"shelf"}}
        },
        {
          id:"boss_1",
          title:"Clear One Boss",
          text:"Clear any 1 subject boss.",
          metric:"bossClearsTotal",
          target:1,
          reward:{sparks:75,xp:80,ancientCoins:1,item:{name:"First Gauntlet Boss Trophy",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:125,xp:150,ancientCoins:2,item:{name:"Foundation Gauntlet Monument",slot:"shelf"}}
    },

    {
      id:"core_scholar_gauntlet",
      title:"Core Scholar Gauntlet",
      icon:"📚",
      intro:"A core academic challenge across Reading, English, Math, Science, and History.",
      finalTitle:"Core Scholar",
      stages:[
        {
          id:"reading_25",
          title:"Reading Path",
          text:"Get 25 correct Reading answers.",
          metric:"subjectCorrect",
          subject:"Reading",
          target:25,
          reward:{sparks:45,xp:45,item:{name:"Core Reading Laurel",slot:"wall"}}
        },
        {
          id:"math_25",
          title:"Math Path",
          text:"Get 25 correct Math answers.",
          metric:"subjectCorrect",
          subject:"Math",
          target:25,
          reward:{sparks:45,xp:45,item:{name:"Core Math Laurel",slot:"wall"}}
        },
        {
          id:"science_20",
          title:"Science Path",
          text:"Get 20 correct Science answers.",
          metric:"subjectCorrect",
          subject:"Science",
          target:20,
          reward:{sparks:45,xp:45,item:{name:"Core Science Laurel",slot:"wall"}}
        },
        {
          id:"history_20",
          title:"History Path",
          text:"Get 20 correct History answers.",
          metric:"subjectCorrect",
          subject:"History",
          target:20,
          reward:{sparks:45,xp:45,item:{name:"Core History Laurel",slot:"wall"}}
        },
        {
          id:"core_boss_2",
          title:"Two Core Bosses",
          text:"Clear 2 bosses from Reading, English, Math, Science, or History.",
          metric:"bossClearsInSubjects",
          subjects:["Reading","English","Math","Science","History"],
          target:2,
          reward:{sparks:90,xp:100,ancientCoins:1,item:{name:"Two Core Bosses Banner",slot:"wall"}}
        }
      ],
      completionReward:{sparks:175,xp:200,ancientCoins:3,item:{name:"Core Scholar Gauntlet Trophy",slot:"shelf"}}
    },

    {
      id:"new_realms_gauntlet",
      title:"New Realms Gauntlet",
      icon:"🌍",
      intro:"A challenge built around the newer realms: Civics, Geography, Economics, Logic, Nature, Health, Music, Copywork, and Life Skills.",
      finalTitle:"Realm Sampler",
      stages:[
        {
          id:"new_subjects_6",
          title:"Try Six New Realms",
          text:"Get correct answers in 6 of the newer realm subjects.",
          metric:"subjectsStartedInSet",
          subjects:["Civics","Geography","Economics","Logic","Nature","Health","Music","Copywork","LifeSkills"],
          target:6,
          reward:{sparks:70,xp:70,item:{name:"Six New Realms Compass",slot:"shelf"}}
        },
        {
          id:"civ_geo_econ",
          title:"Civic Map Market",
          text:"Get 10 correct answers each in Civics, Geography, and Economics.",
          metric:"allSubjectsAtCorrect",
          subjects:["Civics","Geography","Economics"],
          target:10,
          reward:{sparks:85,xp:85,ancientCoins:1,item:{name:"Civic Map Market Crest",slot:"wall"}}
        },
        {
          id:"logic_nature_health",
          title:"Mind, Wildroot, Hearthwell",
          text:"Get 10 correct answers each in Logic, Nature, and Health.",
          metric:"allSubjectsAtCorrect",
          subjects:["Logic","Nature","Health"],
          target:10,
          reward:{sparks:85,xp:85,ancientCoins:1,item:{name:"Mind Wildroot Hearthwell Crest",slot:"wall"}}
        },
        {
          id:"creative_practical_set",
          title:"Creative Practical Trio",
          text:"Get 8 correct answers each in Music, Copywork, and Life Skills.",
          metric:"allSubjectsAtCorrect",
          subjects:["Music","Copywork","LifeSkills"],
          target:8,
          reward:{sparks:85,xp:85,ancientCoins:1,item:{name:"Creative Practical Trio Banner",slot:"wall"}}
        }
      ],
      completionReward:{sparks:200,xp:225,ancientCoins:3,item:{name:"New Realms Gauntlet Trophy",slot:"shelf"}}
    },

    {
      id:"mastery_gauntlet",
      title:"Mastery Rank Gauntlet",
      icon:"🌟",
      intro:"A long-term challenge for building subject mastery ranks instead of only answering questions.",
      finalTitle:"Mastery Challenger",
      stages:[
        {
          id:"rank2_3",
          title:"Three Apprentices",
          text:"Reach mastery Rank 2 in 3 subjects.",
          metric:"masteryRankSubjectsAt",
          rank:2,
          target:3,
          reward:{sparks:75,xp:80,item:{name:"Three Apprentice Gauntlet Mark",slot:"wall"}}
        },
        {
          id:"rank3_2",
          title:"Two Adepts",
          text:"Reach mastery Rank 3 in 2 subjects.",
          metric:"masteryRankSubjectsAt",
          rank:3,
          target:2,
          reward:{sparks:100,xp:110,ancientCoins:1,item:{name:"Two Adept Gauntlet Mark",slot:"wall"}}
        },
        {
          id:"rank4_1",
          title:"One Skilled Path",
          text:"Reach mastery Rank 4 in 1 subject.",
          metric:"masteryRankSubjectsAt",
          rank:4,
          target:1,
          reward:{sparks:125,xp:140,ancientCoins:2,item:{name:"Skilled Path Gauntlet Trophy",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:225,xp:250,ancientCoins:4,item:{name:"Mastery Rank Gauntlet Statue",slot:"shelf"}}
    },

    {
      id:"classroom_capstone",
      title:"Classroom Capstone Trial",
      icon:"🏫",
      intro:"A serious homeschool-day capstone that rewards completing the classroom structure and building a real record.",
      finalTitle:"Classroom Capstone Scholar",
      stages:[
        {
          id:"active_180",
          title:"Half-Day Time Gate",
          text:"Log 180 active learning minutes today.",
          metric:"activeMinutesToday",
          target:180,
          reward:{sparks:70,xp:75,item:{name:"Half-Day Capstone Mark",slot:"wall"}}
        },
        {
          id:"blocks_4",
          title:"Four Class Blocks",
          text:"Claim 4 classroom block rewards today.",
          metric:"classBlocksClaimedToday",
          target:4,
          reward:{sparks:90,xp:100,ancientCoins:1,item:{name:"Four Block Capstone Crest",slot:"wall"}}
        },
        {
          id:"subjects_today_5",
          title:"Five Subjects Today",
          text:"Practice 5 different subjects correctly today.",
          metric:"subjectsCorrectToday",
          target:5,
          reward:{sparks:100,xp:110,ancientCoins:1,item:{name:"Five Subject Day Seal",slot:"wall"}}
        },
        {
          id:"active_360",
          title:"Full-Day Time Gate",
          text:"Log 360 active learning minutes today.",
          metric:"activeMinutesToday",
          target:360,
          reward:{sparks:150,xp:175,ancientCoins:2,item:{name:"Full-Day Time Gate Trophy",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:250,xp:300,ancientCoins:4,item:{name:"Classroom Capstone Monument",slot:"shelf"}}
    },

    {
      id:"rescue_capstone",
      title:"Weak Skill Rescue Trial",
      icon:"🛟",
      intro:"A challenge for turning mistakes and weak subjects into wins.",
      finalTitle:"Rescue Trial Champion",
      stages:[
        {
          id:"rescue_correct_10",
          title:"Ten Rescue Wins",
          text:"Get 10 correct answers through adaptive rescue progress.",
          metric:"adaptiveRescueCorrect",
          target:10,
          reward:{sparks:80,xp:90,item:{name:"Ten Rescue Wins Badge",slot:"wall"}}
        },
        {
          id:"missed_queue_3",
          title:"Repair Three Misses",
          text:"Repair 3 missed questions through adaptive review mode.",
          metric:"adaptiveQueueCorrect",
          target:3,
          reward:{sparks:90,xp:100,ancientCoins:1,item:{name:"Three Repaired Mistakes Ribbon",slot:"wall"}}
        },
        {
          id:"rescue_streak_5",
          title:"Five-Win Rescue Streak",
          text:"Build a best adaptive rescue streak of 5.",
          metric:"adaptiveBestStreak",
          target:5,
          reward:{sparks:125,xp:140,ancientCoins:2,item:{name:"Five-Win Rescue Flame",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:225,xp:250,ancientCoins:3,item:{name:"Weak Skill Rescue Trial Trophy",slot:"shelf"}}
    },

    {
      id:"grand_capstone",
      title:"Grand Learning Capstone",
      icon:"👑",
      intro:"A huge long-term challenge that ties together bosses, subjects, mastery, companions, maps, campaigns, and class records.",
      finalTitle:"Grand Learning Champion",
      stages:[
        {
          id:"boss_5",
          title:"Five Boss Clears",
          text:"Clear 5 subject bosses.",
          metric:"bossClearsTotal",
          target:5,
          reward:{sparks:150,xp:160,ancientCoins:2,item:{name:"Five Boss Crown Piece",slot:"shelf"}}
        },
        {
          id:"subjects_10",
          title:"Ten Subjects Started",
          text:"Get correct answers in 10 different subjects.",
          metric:"subjectsStarted",
          target:10,
          reward:{sparks:150,xp:160,ancientCoins:2,item:{name:"Ten Subject Crown Piece",slot:"shelf"}}
        },
        {
          id:"companion_5",
          title:"Companion Level 5",
          text:"Raise the companion to Level 5.",
          metric:"companionLevel",
          target:5,
          reward:{sparks:150,xp:160,ancientCoins:2,item:{name:"Companion Crown Piece",slot:"shelf"}}
        },
        {
          id:"map_scraps_6",
          title:"Six Map Scraps",
          text:"Find 6 treasure map scraps.",
          metric:"mapScraps",
          target:6,
          reward:{sparks:150,xp:160,ancientCoins:2,item:{name:"Map Crown Piece",slot:"shelf"}}
        },
        {
          id:"campaign_2",
          title:"Two Story Campaigns",
          text:"Complete 2 story campaigns.",
          metric:"storyCampaignsCompleted",
          target:2,
          reward:{sparks:175,xp:200,ancientCoins:3,item:{name:"Campaign Crown Piece",slot:"shelf"}}
        }
      ],
      completionReward:{sparks:500,xp:600,ancientCoins:8,item:{name:"Grand Learning Champion Crown",slot:"shelf"}}
    }
  ]
};
