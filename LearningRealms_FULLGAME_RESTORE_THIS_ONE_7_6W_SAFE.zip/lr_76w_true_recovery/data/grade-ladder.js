// Grade Ladder Config v1
// All students begin at Kindergarten difficulty and climb grade bands through mastery.
// Caps are intentionally configurable so the ladder can expand as the kids age.

window.LR_GRADE_LADDER = {
  order:["K","G1","G2","G3","G4","G5","G6","G7","G8","ALG1","GEO","ALG2"],

  display:{
    K:"Kindergarten",
    G1:"Grade 1",
    G2:"Grade 2",
    G3:"Grade 3",
    G4:"Grade 4",
    G5:"Grade 5",
    G6:"Grade 6",
    G7:"Grade 7",
    G8:"Grade 8",
    ALG1:"Algebra 1",
    GEO:"Geometry",
    ALG2:"Algebra 2"
  },

  startBand:{
    Luna:"K",
    Ava:"K",
    Michael:"K"
  },

  currentCaps:{
    Luna:"G1",
    Ava:"G6",
    Michael:"G7"
  },

  // Small numbers for now so the system can be tested.
  // Later these can be raised to 50, 100, 250, etc. per band.
  promotionRules:{
    correctAtBand:20,
    bossClearsAtBand:0,
    portfolioAtBand:0
  },

  fallback:{
    // If a grade band has no exact lessons yet, allow review of lower-band lessons
    // so the game never gets stuck while we build the huge curriculum.
    allowLowerBandReview:true,
    allowUntaggedWhenNoBandLessons:true
  },

  notes:[
    "All children start at Kindergarten difficulty.",
    "Luna currently caps at Grade 1.",
    "Ava currently caps at Grade 6.",
    "Michael currently caps at Grade 7.",
    "Future caps can be raised in this file as they age.",
    "Future curriculum packs should tag lessons with gradeBand:'K', 'G1', 'G2', etc."
  ]
};
