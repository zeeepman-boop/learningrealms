// Game Fun Pack 5: Random Events & Treasure Maps
// Adds exploration events, hidden caches, clue scraps, companion finds, and an Event Log.
// Engine patch lives in app.js.

window.LR_RANDOM_EVENT_CONFIG = {
  chancePerRoom:0.22,
  dailyEventCap:12,
  cooldownRooms:2,

  events:[
    {
      id:"hidden_cache",
      title:"Hidden Cache",
      type:"reward",
      weight:6,
      text:"A loose stone shifts near the path. Behind it is a tiny hidden cache left by old realm travelers.",
      reward:{sparks:12,xp:10,item:{name:"Hidden Cache Pebble",slot:"shelf"}}
    },
    {
      id:"ancient_coin_glimmer",
      title:"Ancient Coin Glimmer",
      type:"reward",
      weight:2,
      text:"Something flashes under a patch of dust. It is an Ancient Coin, warm with old magic.",
      reward:{ancientCoins:1,xp:15,item:{name:"Ancient Coin Dust Jar",slot:"shelf"}}
    },
    {
      id:"companion_find",
      title:"Companion Find",
      type:"companion",
      weight:5,
      text:"Your companion scratches at the ground and uncovers a small study charm.",
      reward:{sparks:8,xp:8,item:{name:"Companion Found Charm",slot:"shelf"}},
      companionXp:8
    },
    {
      id:"map_scrap",
      title:"Treasure Map Scrap",
      type:"map",
      weight:5,
      text:"A torn piece of old map flutters against your boot. It shows part of a trail, a strange mark, and the words: keep looking.",
      reward:{sparks:5,xp:5,item:{name:"Treasure Map Scrap",slot:"wall"}}
    },
    {
      id:"lore_tablet",
      title:"Realm Lore Tablet",
      type:"lore",
      weight:4,
      text:"A small tablet tells a bit of realm history. It says learners who master many paths will unlock deeper gates.",
      reward:{xp:12,item:{name:"Realm Lore Tablet",slot:"shelf"}}
    },
    {
      id:"subject_clue",
      title:"Subject Clue",
      type:"subject",
      weight:7,
      text:"A glowing clue appears beside the path. It seems connected to the subject studied in this room.",
      reward:{sparks:6,xp:8}
    },
    {
      id:"streak_wind",
      title:"Streak Wind",
      type:"boost",
      weight:4,
      text:"A warm wind circles around you. It feels like the realm is cheering your steady work.",
      reward:{sparks:10,xp:10}
    },
    {
      id:"quiet_observation",
      title:"Quiet Observation",
      type:"lore",
      weight:5,
      text:"You pause and notice details you almost missed: marks on stone, faint tracks, old writing, and a path branching ahead.",
      reward:{xp:10,item:{name:"Observation Note",slot:"desk"}}
    },
    {
      id:"mini_supply_crate",
      title:"Mini Supply Crate",
      type:"reward",
      weight:4,
      text:"A little supply crate is tucked beside the trail. Someone packed it for careful travelers.",
      reward:{sparks:15,xp:8,item:{name:"Mini Supply Crate",slot:"shelf"}}
    },
    {
      id:"riddle_mark",
      title:"Riddle Mark",
      type:"logic",
      weight:3,
      text:"A riddle mark glows on the wall, then fades. It leaves behind a tiny gear-shaped clue.",
      reward:{sparks:8,xp:12,item:{name:"Riddle Mark Gear",slot:"shelf"}}
    }
  ],

  subjectEventText:{
    Reading:"The clue whispers: Look for meaning, not just words.",
    Math:"The clue clicks into place like a number pattern.",
    Science:"The clue glows like a specimen under careful observation.",
    History:"The clue feels old, like a piece of a timeline.",
    English:"The clue rearranges into a cleaner sentence.",
    Art:"The clue shimmers with color, line, and shape.",
    Civics:"The clue bears a tiny seal of fairness and responsibility.",
    Geography:"The clue points north, then marks a hidden route.",
    Economics:"The clue looks like a tiny trade token.",
    Logic:"The clue will not open until the pattern is understood.",
    Nature:"The clue looks like a leaf, a track, and a cloud all at once.",
    Health:"The clue pulses like a tiny heart lantern.",
    Music:"The clue hums a quiet rhythm.",
    Copywork:"The clue forms itself into neat, careful letters.",
    LifeSkills:"The clue becomes a checklist with one box already marked."
  },

  mapMilestones:[
    {scraps:3,title:"First Treasure Map",reward:{sparks:50,xp:50,item:{name:"First Treasure Map",slot:"wall"}}},
    {scraps:6,title:"Mapmaker's Secret",reward:{sparks:75,xp:75,ancientCoins:1,item:{name:"Mapmaker Secret Compass",slot:"shelf"}}},
    {scraps:10,title:"Hidden Route Hunter",reward:{sparks:120,xp:125,ancientCoins:2,item:{name:"Hidden Route Hunter Banner",slot:"wall"}}}
  ]
};
