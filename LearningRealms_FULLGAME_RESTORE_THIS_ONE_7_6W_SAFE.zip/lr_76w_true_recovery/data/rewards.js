window.LR_REWARDS = {
  Reading:[{name:"Story Lantern",slot:"shelf"},{name:"Reader Rabbit Ribbon",slot:"pet"}],
  English:[{name:"Grammar Scroll",slot:"wall"}],
  Math:[{name:"Gear Sketch",slot:"desk"},{name:"Engineer Banner",slot:"wall"}],
  Science:[{name:"Observation Journal",slot:"desk"},{name:"Crystal Frog",slot:"pet"}],
  History:[{name:"Timeline Banner",slot:"wall"}],
  Civics:[{name:"Council Seal",slot:"shelf"}]
};
