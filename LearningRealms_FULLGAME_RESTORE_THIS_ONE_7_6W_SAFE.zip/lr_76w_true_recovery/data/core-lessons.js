window.LR_LESSONS = {
  Luna:{Reading:[],English:[],Math:[],Science:[],History:[],Civics:[]},
  Ava:{Reading:[],English:[],Math:[],Science:[],History:[],Civics:[]},
  Michael:{Reading:[],English:[],Math:[],Science:[],History:[],Civics:[]}
};

window.LR_addLessons = function(child, subject, items){
  if(!window.LR_LESSONS[child]) window.LR_LESSONS[child] = {};
  if(!window.LR_LESSONS[child][subject]) window.LR_LESSONS[child][subject] = [];
  window.LR_LESSONS[child][subject].push(...items);
};
