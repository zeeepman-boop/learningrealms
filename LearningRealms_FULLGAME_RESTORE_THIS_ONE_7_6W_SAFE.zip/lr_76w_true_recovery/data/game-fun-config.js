// Game Fun Pack 1: Quest Board Upgrade
// Claimable daily quests, weekly quests, achievements, and reward hooks.
// Engine patch lives in app.js. This file keeps reward values easy to change later.

window.LR_GAME_FUN_CONFIG = {
  dailyQuests:[
    {
      id:"daily_answer_10",
      title:"Solve 10 Problems",
      goal:"Answer 10 lesson or boss questions today.",
      metric:"answers",
      target:10,
      reward:{sparks:25,xp:30,item:{name:"Daily Problem Solver Pennant",slot:"wall"}}
    },
    {
      id:"daily_correct_5",
      title:"Win 5 Lessons",
      goal:"Get 5 lesson questions correct today.",
      metric:"correctLessons",
      target:5,
      reward:{sparks:30,xp:35,item:{name:"Five-Win Study Candle",slot:"shelf"}}
    },
    {
      id:"daily_visit_8",
      title:"Explore 8 Rooms",
      goal:"Travel through 8 rooms today.",
      metric:"roomVisits",
      target:8,
      reward:{sparks:20,xp:25,item:{name:"Explorer Boot Charm",slot:"shelf"}}
    },
    {
      id:"daily_subject_3",
      title:"Practice 3 Subjects",
      goal:"Get correct answers in 3 different subjects today.",
      metric:"subjectsCorrect",
      target:3,
      reward:{sparks:35,xp:40,item:{name:"Three-Subject Ribbon",slot:"wall"}}
    },
    {
      id:"daily_streak_3",
      title:"Build a 3-Win Streak",
      goal:"Reach a streak of 3 correct answers.",
      metric:"bestStreak",
      target:3,
      reward:{sparks:20,xp:25,item:{name:"Tiny Streak Flame",slot:"shelf"}}
    }
  ],

  weeklyQuests:[
    {
      id:"weekly_answer_50",
      title:"Weekly Scholar",
      goal:"Answer 50 questions this week.",
      metric:"answers",
      target:50,
      reward:{sparks:100,xp:125,ancientCoins:1,item:{name:"Weekly Scholar Banner",slot:"wall"}}
    },
    {
      id:"weekly_correct_30",
      title:"Thirty Correct Wins",
      goal:"Get 30 correct lesson answers this week.",
      metric:"correctLessons",
      target:30,
      reward:{sparks:120,xp:150,ancientCoins:1,item:{name:"Thirty-Win Trophy",slot:"shelf"}}
    },
    {
      id:"weekly_rooms_35",
      title:"Realm Wanderer",
      goal:"Travel through 35 rooms this week.",
      metric:"roomVisits",
      target:35,
      reward:{sparks:90,xp:100,item:{name:"Realm Wanderer Map",slot:"wall"}}
    },
    {
      id:"weekly_subject_6",
      title:"Six-Subject Sampler",
      goal:"Get correct answers in 6 different subjects this week.",
      metric:"subjectsCorrect",
      target:6,
      reward:{sparks:130,xp:150,ancientCoins:1,item:{name:"Six-Subject Crest",slot:"wall"}}
    },
    {
      id:"weekly_boss_try",
      title:"Face a Realm Boss",
      goal:"Attempt at least 1 boss challenge this week.",
      metric:"bossAttempts",
      target:1,
      reward:{sparks:75,xp:100,item:{name:"Boss Challenger Token",slot:"shelf"}}
    }
  ],

  achievements:[
    {
      id:"ach_first_steps",
      title:"First Steps",
      goal:"Answer 10 total questions.",
      metric:"totalAnswers",
      target:10,
      reward:{sparks:50,xp:50,item:{name:"First Steps Plaque",slot:"wall"}}
    },
    {
      id:"ach_room_roamer",
      title:"Room Roamer",
      goal:"Travel through 50 rooms total.",
      metric:"totalRooms",
      target:50,
      reward:{sparks:75,xp:75,item:{name:"Room Roamer Boots",slot:"shelf"}}
    },
    {
      id:"ach_subject_collector",
      title:"Subject Collector",
      goal:"Get at least one correct answer in 8 different subjects.",
      metric:"subjectsEverCorrect",
      target:8,
      reward:{sparks:125,xp:125,ancientCoins:1,item:{name:"Subject Collector Shield",slot:"wall"}}
    },
    {
      id:"ach_boss_clear_3",
      title:"Boss Breaker",
      goal:"Clear 3 subject bosses.",
      metric:"bossesCleared",
      target:3,
      reward:{sparks:150,xp:175,ancientCoins:2,item:{name:"Boss Breaker Trophy",slot:"shelf"}}
    },
    {
      id:"ach_level_5",
      title:"Level 5 Adventurer",
      goal:"Reach Level 5.",
      metric:"level",
      target:5,
      reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Level 5 Adventurer Banner",slot:"wall"}}
    },
    {
      id:"ach_level_10",
      title:"Level 10 Hero",
      goal:"Reach Level 10.",
      metric:"level",
      target:10,
      reward:{sparks:200,xp:200,ancientCoins:3,item:{name:"Level 10 Hero Statue",slot:"shelf"}}
    }
  ]
};
