// Game Fun Pack 10: Adaptive Review & Weak Skill Rescue
// Adds smart review missions, weak-subject detection, stale-subject detection, missed-question practice,
// targeted rescue rewards, and an Adaptive Review Center screen.
// Engine patch lives in app.js.

window.LR_ADAPTIVE_REVIEW_CONFIG = {
  title:"Adaptive Review & Weak Skill Rescue",

  weakAccuracyThreshold:70,
  weakMinimumAttempts:5,
  staleDays:3,

  missions:[
    {
      id:"rescue_3",
      title:"Quick Rescue",
      targetCorrect:3,
      reward:{sparks:30,xp:30,item:{name:"Quick Rescue Badge",slot:"wall"}}
    },
    {
      id:"rescue_5",
      title:"Steady Rescue",
      targetCorrect:5,
      reward:{sparks:55,xp:60,item:{name:"Steady Rescue Lantern",slot:"shelf"}}
    },
    {
      id:"rescue_10",
      title:"Full Rescue",
      targetCorrect:10,
      reward:{sparks:100,xp:120,ancientCoins:1,item:{name:"Full Rescue Trophy",slot:"shelf"}}
    }
  ],

  reviewQueueMissions:[
    {
      id:"missed_3",
      title:"Fix 3 Missed Questions",
      targetCorrect:3,
      reward:{sparks:35,xp:35,item:{name:"Mistake Fixer Ribbon",slot:"wall"}}
    },
    {
      id:"missed_7",
      title:"Mistake Breaker",
      targetCorrect:7,
      reward:{sparks:80,xp:90,ancientCoins:1,item:{name:"Mistake Breaker Shield",slot:"wall"}}
    }
  ],

  streakRewards:[
    {
      id:"rescue_streak_3",
      title:"Three Rescue Wins",
      target:3,
      reward:{sparks:35,xp:35,item:{name:"Three Rescue Wins Spark",slot:"shelf"}}
    },
    {
      id:"rescue_streak_5",
      title:"Five Rescue Wins",
      target:5,
      reward:{sparks:75,xp:85,ancientCoins:1,item:{name:"Five Rescue Wins Flame",slot:"shelf"}}
    }
  ],

  completionTitles:[
    {correct:10,title:"Weak Skill Rescuer"},
    {correct:25,title:"Review Champion"},
    {correct:50,title:"Mastery Repairer"}
  ],

  messages:{
    weak:"This subject may need attention because accuracy is low.",
    stale:"This subject has not been practiced recently.",
    strong:"This subject looks stable right now.",
    noData:"Not enough records yet."
  }
};
