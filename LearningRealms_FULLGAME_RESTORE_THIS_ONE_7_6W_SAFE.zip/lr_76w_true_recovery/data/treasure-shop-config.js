// Game Fun Pack 3: Treasure Drops & Level-Gated Shops
// Adds rare bonus drops and level-gated shop stock.
// Engine patch lives in app.js.

window.LR_TREASURE_SHOP_CONFIG = {
  lessonDrops:[
    {id:"spark_satchel",chance:0.07,type:"sparks",amount:5,text:"Spark Satchel"},
    {id:"ancient_coin_glint",chance:0.015,type:"ancientCoins",amount:1,text:"Ancient Coin Glint"},
    {id:"general_trinket",chance:0.035,type:"item",pool:"general",text:"Study Trinket"},
    {id:"subject_trinket",chance:0.025,type:"subjectItem",text:"Subject Trinket"}
  ],

  bossDrops:[
    {id:"boss_coin_cache",chance:0.20,type:"ancientCoins",amount:1,text:"Boss Coin Cache"},
    {id:"boss_relic",chance:0.35,type:"item",pool:"boss",text:"Boss Relic"}
  ],

  pools:{
    general:[
      {name:"Tiny Quest Bead",slot:"shelf"},
      {name:"Lucky Study Pebble",slot:"shelf"},
      {name:"Pocket Star Token",slot:"shelf"},
      {name:"Small Scholar Candle",slot:"shelf"},
      {name:"Copper Bookmark",slot:"desk"},
      {name:"Practice Bell",slot:"shelf"},
      {name:"Mini Lantern Charm",slot:"shelf"},
      {name:"Traveler's Button",slot:"shelf"}
    ],
    boss:[
      {name:"Boss Room Banner",slot:"wall"},
      {name:"Victory Torch",slot:"shelf"},
      {name:"Champion's Small Shield",slot:"wall"},
      {name:"Bravery Medal Stand",slot:"shelf"},
      {name:"Trial Clear Tablet",slot:"wall"},
      {name:"Realm Boss Keystone",slot:"shelf"}
    ],
    subjects:{
      Reading:[
        {name:"Silver Story Leaf",slot:"shelf"},
        {name:"Whisperwood Reading Ribbon",slot:"wall"},
        {name:"Tiny Book Nook Lamp",slot:"shelf"}
      ],
      Math:[
        {name:"Number Crystal",slot:"shelf"},
        {name:"Iron Hills Gear Token",slot:"shelf"},
        {name:"Golden Counting Rod",slot:"desk"}
      ],
      Science:[
        {name:"Crystal Marsh Specimen Jar",slot:"shelf"},
        {name:"Weather Watcher Pin",slot:"wall"},
        {name:"Tiny Science Lens",slot:"desk"}
      ],
      History:[
        {name:"Archive Dust Seal",slot:"wall"},
        {name:"Old Timeline Chip",slot:"shelf"},
        {name:"Historian's Ribbon",slot:"wall"}
      ],
      English:[
        {name:"Grammar Grove Acorn",slot:"shelf"},
        {name:"Sentence Builder Tile",slot:"desk"},
        {name:"Punctuation Spark",slot:"shelf"}
      ],
      Art:[
        {name:"Dragonbrush Scale",slot:"shelf"},
        {name:"Painter's Tiny Palette",slot:"desk"},
        {name:"Gallery Frame Token",slot:"wall"}
      ],
      Civics:[
        {name:"Council Seal Button",slot:"shelf"},
        {name:"Fair Rule Scroll",slot:"wall"},
        {name:"Citizen Star Badge",slot:"wall"}
      ],
      Geography:[
        {name:"Compass Rose Chip",slot:"shelf"},
        {name:"Mapmaker Pin",slot:"wall"},
        {name:"Tiny Landform Model",slot:"shelf"}
      ],
      Economics:[
        {name:"Merchant Coin Tile",slot:"shelf"},
        {name:"Budget Jar Charm",slot:"shelf"},
        {name:"Trade Bridge Stamp",slot:"wall"}
      ],
      Logic:[
        {name:"Puzzle Spire Gear",slot:"shelf"},
        {name:"Because Token",slot:"shelf"},
        {name:"Riddle Key",slot:"shelf"}
      ],
      Nature:[
        {name:"Wildroot Seed Pod",slot:"shelf"},
        {name:"Tracker Pawprint Cast",slot:"wall"},
        {name:"Pond Lily Pin",slot:"wall"}
      ],
      Health:[
        {name:"Hearthwell Water Drop",slot:"shelf"},
        {name:"Movement Ribbon",slot:"wall"},
        {name:"Safety Spark Badge",slot:"wall"}
      ],
      Music:[
        {name:"Bardwood Note Charm",slot:"shelf"},
        {name:"Rhythm Stone",slot:"shelf"},
        {name:"Tiny Tempo Bell",slot:"shelf"}
      ],
      Copywork:[
        {name:"Scribe Ink Drop",slot:"shelf"},
        {name:"Golden Spacing Dot",slot:"desk"},
        {name:"Clean Copy Seal",slot:"wall"}
      ],
      LifeSkills:[
        {name:"Homestead Checkmark",slot:"wall"},
        {name:"Tiny Toolbox Badge",slot:"shelf"},
        {name:"Measuring Spoon Charm",slot:"shelf"}
      ]
    }
  },

  shopStock:{
    seasonalShop:[
      {name:"Level 2 Festival Lantern",cost:35,currency:"sparks",slot:"shelf",minLevel:2},
      {name:"Level 5 Festival Banner",cost:65,currency:"sparks",slot:"wall",minLevel:5},
      {name:"Level 10 Grand Festival Arch",cost:140,currency:"sparks",slot:"wall",minLevel:10}
    ],
    pictureShop:[
      {name:"Level 3 Realm Map Frame",cost:45,currency:"sparks",slot:"wall",minLevel:3},
      {name:"Level 6 Champion Portrait Frame",cost:80,currency:"sparks",slot:"wall",minLevel:6},
      {name:"Level 12 Legendary Gallery Frame",cost:160,currency:"sparks",slot:"wall",minLevel:12}
    ],
    luckyKettle:[
      {name:"Level 2 Warm Study Cocoa",cost:25,currency:"sparks",slot:"food",minLevel:2,unique:false},
      {name:"Level 5 Hero Breakfast Plate",cost:55,currency:"sparks",slot:"food",minLevel:5,unique:false},
      {name:"Level 10 Victory Feast Ticket",cost:110,currency:"sparks",slot:"food",minLevel:10,unique:false}
    ],
    shiftyTent:[
      {name:"Level 4 Moonlit Relic Shard",cost:4,currency:"ancientCoins",slot:"shelf",minLevel:4},
      {name:"Level 8 Secret Gate Gear",cost:7,currency:"ancientCoins",slot:"shelf",minLevel:8},
      {name:"Level 12 Ancient Collector Idol",cost:12,currency:"ancientCoins",slot:"shelf",minLevel:12}
    ]
  }
};
