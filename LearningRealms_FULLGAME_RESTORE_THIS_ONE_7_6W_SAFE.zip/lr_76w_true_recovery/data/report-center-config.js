// Game Fun Pack 7: Homeschool Report Center
// Adds parent-facing attendance records, daily summaries, problem logs, notes, print view, and CSV exports.
// Engine patch lives in app.js.

window.LR_REPORT_CENTER_CONFIG = {
  title:"Homeschool Report Center",
  dailyInstructionMinutes:360,
  partialDayMinutes:180,
  minimumLoggedMinutes:1,

  attendanceRewards:[
    {
      id:"daily_60",
      title:"One-Hour Learning Mark",
      minutes:60,
      scope:"daily",
      reward:{sparks:25,xp:25,item:{name:"One-Hour Learning Ribbon",slot:"wall"}}
    },
    {
      id:"daily_180",
      title:"Half-Day Learning Mark",
      minutes:180,
      scope:"daily",
      reward:{sparks:60,xp:60,item:{name:"Half-Day Study Plaque",slot:"wall"}}
    },
    {
      id:"daily_360",
      title:"Full Classroom Day",
      minutes:360,
      scope:"daily",
      reward:{sparks:125,xp:125,ancientCoins:1,item:{name:"Full Classroom Day Banner",slot:"wall"}}
    }
  ],

  exportColumns:[
    "Student",
    "Date",
    "Status",
    "Active Minutes",
    "Target Minutes",
    "Login Count",
    "First Login",
    "Last Seen",
    "Problems Attempted",
    "Correct",
    "Wrong",
    "Subjects Practiced",
    "Daily Note"
  ]
};
