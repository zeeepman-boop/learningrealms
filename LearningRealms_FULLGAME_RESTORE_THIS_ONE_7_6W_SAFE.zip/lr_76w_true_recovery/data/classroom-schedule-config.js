// Game Fun Pack 8: Classroom Schedule & Focus Blocks
// Adds a structured 6-hour homeschool schedule, focus blocks, block rewards, and daily completion rewards.
// Engine patch lives in app.js.

window.LR_CLASSROOM_SCHEDULE_CONFIG = {
  title:"Classroom Schedule & Focus Blocks",
  dailyMinutes:360,

  blocks:[
    {
      id:"warmup",
      title:"Morning Warm-Up",
      theme:"wake up the brain",
      minutes:30,
      subjects:"any",
      targetCorrect:{Luna:3,Ava:5,Michael:5},
      reward:{sparks:20,xp:20,item:{name:"Morning Warm-Up Stamp",slot:"wall"}}
    },
    {
      id:"core_math",
      title:"Core Math Block",
      theme:"numbers, patterns, and problem solving",
      minutes:60,
      subjects:["Math"],
      targetCorrect:{Luna:4,Ava:8,Michael:8},
      reward:{sparks:35,xp:35,item:{name:"Core Math Stamp",slot:"wall"}}
    },
    {
      id:"reading_language",
      title:"Reading & Language Block",
      theme:"reading, English, writing, and copywork",
      minutes:75,
      subjects:["Reading","English","Writing","Copywork"],
      targetCorrect:{Luna:5,Ava:9,Michael:9},
      reward:{sparks:40,xp:40,item:{name:"Reading Language Stamp",slot:"wall"}}
    },
    {
      id:"science_social",
      title:"Science & Social Studies Block",
      theme:"science, history, civics, geography, economics, and nature",
      minutes:90,
      subjects:["Science","History","Civics","Geography","Economics","Nature"],
      targetCorrect:{Luna:4,Ava:9,Michael:9},
      reward:{sparks:45,xp:45,item:{name:"Science Social Stamp",slot:"wall"}}
    },
    {
      id:"creative_practical",
      title:"Creative & Practical Block",
      theme:"art, music, health, logic, and life skills",
      minutes:75,
      subjects:["Art","Music","Health","Logic","LifeSkills"],
      targetCorrect:{Luna:4,Ava:8,Michael:8},
      reward:{sparks:40,xp:40,item:{name:"Creative Practical Stamp",slot:"wall"}}
    },
    {
      id:"review_boss",
      title:"Review, Boss, or Quest Block",
      theme:"review weak subjects, clear quests, or attempt a boss",
      minutes:30,
      subjects:"any",
      targetCorrect:{Luna:3,Ava:5,Michael:5},
      targetBossAttempts:1,
      reward:{sparks:35,xp:35,ancientCoins:1,item:{name:"Review Boss Stamp",slot:"wall"}}
    }
  ],

  dailyCompletionReward:{
    title:"Full Schedule Clear",
    reward:{sparks:150,xp:175,ancientCoins:2,item:{name:"Full Schedule Clear Trophy",slot:"shelf"}}
  },

  focusBonus:{
    sparks:1,
    companionXp:1,
    masteryXp:1,
    cooldownCorrect:1
  },

  subjectTravelHints:{
    Math:"Try Iron Hills or any Math room.",
    Reading:"Try Whisperwood or any Reading room.",
    English:"Try Grammar Grove or any English room.",
    Writing:"Try a Writing room or portfolio prompt.",
    Copywork:"Try Scribe's Abbey.",
    Science:"Try Crystal Marsh or any Science room.",
    History:"Try the Historical Society or any History room.",
    Civics:"Try Councilhall Citadel.",
    Geography:"Try Mapmaker's Expanse.",
    Economics:"Try Merchant Row.",
    Nature:"Try Wildroot Preserve.",
    Art:"Try Dragonbrush Vale.",
    Music:"Try Bardwood Hall.",
    Health:"Try Hearthwell Clinic.",
    Logic:"Try Puzzle Spire.",
    LifeSkills:"Try Homestead Workshop."
  }
};
