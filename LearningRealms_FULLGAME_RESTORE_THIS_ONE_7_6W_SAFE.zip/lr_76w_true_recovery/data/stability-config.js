// Stability Pack 1: System Health & Save Repair
// Adds diagnostics, save repair, startup migration, backup/export/import, and emergency reset helpers.
// Engine patch lives in app.js.

window.LR_STABILITY_CONFIG = {
  title:"System Health & Save Repair",

  requiredRooms:[
    "crossroads",
    "townSquare",
    "home",
    "questBoardPlaza"
  ],

  importantRooms:[
    "whisperGate",
    "ironGate",
    "crystalMarsh",
    "recordVault",
    "grammarRoad",
    "dragonbrushGate",
    "councilGate",
    "mapmakerGate",
    "merchantGate",
    "puzzleGate",
    "wildrootGate",
    "hearthwellGate",
    "bardwoodGate",
    "scribeGate",
    "homesteadGate"
  ],

  requiredDomIds:[
    "roomTitle",
    "roomText",
    "zoneName",
    "leftActionButtons",
    "lessonBox",
    "storageBox",
    "actionTitle",
    "actionText",
    "feedback",
    "progress",
    "inventory",
    "memoryBook",
    "studentSelect",
    "gameMenuSelect"
  ],

  storageKeys:{
    profiles:"LR_profiles_recovery_2a",
    activeChild:"LR_active_child_recovery_2a",
    corruptBackupPrefix:"LR_corrupt_profiles_backup_",
    manualBackupPrefix:"LR_manual_profiles_backup_"
  },

  repairDefaults:{
    safeRoom:"crossroads",
    students:["Luna","Ava","Michael"]
  }
};
