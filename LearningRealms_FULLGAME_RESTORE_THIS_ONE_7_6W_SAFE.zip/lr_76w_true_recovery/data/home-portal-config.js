// Stability Pack 2.0: Home Portal Mode
// Makes Home feel like a separate special place.

window.LR_HOME_PORTAL_CONFIG = {
  title:"Home Portal Mode",
  arrivalLines:{
    Luna:[
      "The little door opens into Luna's Storybook Cottage. The outside world gets quiet, and the room feels soft, safe, and full of treasures.",
      "A warm story-light flickers inside. Luna has entered her own cozy home room."
    ],
    Ava:[
      "A clever fox-shaped lantern clicks on. Ava steps into her Foxwork Workshop, where rewards and treasures have their own places.",
      "The door swings open to a tidy workshop home with a bright little spark of adventure tucked inside."
    ],
    Michael:[
      "The archive lamp glows. Michael enters his Owl Archive Room, quiet and steady, with trophies and study treasures waiting.",
      "A calm owl light wakes in the corner. This is Michael's home base."
    ]
  },
  defaultArrival:"The door opens into a cozy home room. The adventure quiets down, and this place feels like a special base of your own."
};
