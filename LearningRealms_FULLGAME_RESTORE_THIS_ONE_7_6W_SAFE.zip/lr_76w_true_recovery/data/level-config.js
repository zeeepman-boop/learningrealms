// Leveling Config v1
// Designed to make the homeschool game feel like an RPG.
// XP, rewards, and unlocks can be expanded forever without rewriting the engine.

window.LR_LEVEL_CONFIG = {
  maxSoftLevel:100,

  xpCurve:{
    base:100,
    growth:35,
    everyFiveBonus:75
  },

  xpAwards:{
    correctLesson:10,
    portfolioComplete:25,
    bossAttempt:15,
    bossWin:100,
    firstBossClearBonus:75
  },

  milestones:{
    2:{title:"New Explorer",reward:{name:"Beginner Explorer Banner",slot:"wall"},message:"A beginner banner is unlocked for home."},
    3:{title:"Pathfinder",reward:{name:"Pathfinder Lantern",slot:"shelf"},message:"A lantern is unlocked for home."},
    4:{title:"Apprentice Learner",reward:{name:"Apprentice Study Rug",slot:"rug"},message:"A study rug is unlocked for home."},
    5:{title:"Ancient Coin Finder",ancientCoins:1,reward:{name:"Level 5 Coin Display",slot:"shelf"},message:"First major level milestone. +1 Ancient Coin."},
    6:{title:"Realm Helper",reward:{name:"Realm Helper Wall Badge",slot:"wall"},message:"A helper badge is unlocked."},
    7:{title:"Steady Scholar",reward:{name:"Steady Scholar Desk Book",slot:"desk"},message:"A scholar book is unlocked."},
    8:{title:"Quest Walker",reward:{name:"Quest Walker Cloak",slot:"cloak"},message:"A cloak slot item is unlocked."},
    9:{title:"Skill Seeker",reward:{name:"Skill Seeker Trophy",slot:"shelf"},message:"A trophy is unlocked."},
    10:{title:"Realm Adventurer",ancientCoins:2,reward:{name:"Level 10 Adventurer Banner",slot:"wall"},message:"Big milestone. +2 Ancient Coins and a banner."},
    15:{title:"Veteran Student",ancientCoins:2,reward:{name:"Veteran Student Crest",slot:"wall"},message:"A veteran crest is unlocked."},
    20:{title:"Mastery Hunter",ancientCoins:3,reward:{name:"Level 20 Mastery Statue",slot:"shelf"},message:"Major milestone. +3 Ancient Coins and a statue."},
    25:{title:"Boss Breaker",ancientCoins:3,reward:{name:"Boss Breaker Trophy",slot:"shelf"},message:"A boss trophy is unlocked."},
    30:{title:"Deep Realm Explorer",ancientCoins:4,reward:{name:"Deep Realm Map Table",slot:"desk"},message:"A map table is unlocked."},
    40:{title:"Ancient Road Scholar",ancientCoins:5,reward:{name:"Ancient Road Relic",slot:"shelf"},message:"A rare relic is unlocked."},
    50:{title:"Half-Century Hero",ancientCoins:10,reward:{name:"Level 50 Hero Banner",slot:"wall"},message:"Huge milestone. +10 Ancient Coins and a hero banner."}
  },

  repeatingRewards:{
    everyLevel:{sparks:5},
    every5:{ancientCoins:1},
    every10:{rewardPrefix:"Milestone Trophy Level "}
  },

  unlockNotes:[
    "Levels give home rewards, Sparks, Ancient Coins, titles, and future access gates.",
    "Future shops, zones, clothes, pets, mounts, house rooms, boss chains, and mystery areas can require level gates.",
    "This file is separate so the reward table can grow forever."
  ]
};
