// Game Fun Pack 4: Companion Training & Bonding
// Adds companion levels, bonding, daily care actions, tricks, subject discoveries, and companion rewards.
// Engine patch lives in app.js.

window.LR_COMPANION_TRAINING_CONFIG = {
  xp:{
    correctLesson:3,
    bossWin:15,
    train:8,
    play:4,
    feed:3,
    askAdvice:1
  },

  levelRewards:[
    {level:2,title:"Trusted Friend",reward:{sparks:25,xp:20,item:{name:"Companion Welcome Mat",slot:"rug"}}},
    {level:3,title:"Helpful Partner",reward:{sparks:35,xp:25,item:{name:"Companion Snack Bowl",slot:"shelf"}}},
    {level:5,title:"Study Sidekick",reward:{sparks:60,xp:60,ancientCoins:1,item:{name:"Study Sidekick Banner",slot:"wall"}}},
    {level:8,title:"Realm Partner",reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Realm Partner Perch",slot:"shelf"}}},
    {level:10,title:"Loyal Companion",reward:{sparks:150,xp:150,ancientCoins:2,item:{name:"Loyal Companion Statue",slot:"shelf"}}}
  ],

  tricks:[
    {level:1,name:"Encourage",desc:"Gives a simple confidence boost."},
    {level:2,name:"Find Clue",desc:"Helps notice room and subject details."},
    {level:3,name:"Study Nudge",desc:"Suggests how to approach a lesson."},
    {level:5,name:"Treasure Sniff",desc:"Feels close to treasure drops and rare trinkets."},
    {level:8,name:"Boss Brave",desc:"Gives courage before boss challenges."},
    {level:10,name:"Realm Memory",desc:"Remembers what the learner has already mastered."}
  ],

  moods:["Curious","Happy","Focused","Playful","Sleepy","Excited","Proud","Thoughtful"],

  childFlavor:{
    Luna:{
      den:"Reader Rabbit Nook",
      favorite:"story carrots",
      advice:[
        "Look at the first sound, then say the word slowly.",
        "Point to each word as you read.",
        "A story has people or animals, a place, and something that happens."
      ]
    },
    Ava:{
      den:"Gear Fox Resting Area",
      favorite:"gear biscuits",
      advice:[
        "Break the problem into small steps.",
        "Write down what you know first.",
        "Check your answer by doing the opposite operation."
      ]
    },
    Michael:{
      den:"Archivist Owl Perch",
      favorite:"archive berries",
      advice:[
        "Look for evidence before deciding.",
        "Compare this to something you already mastered.",
        "Slow down and explain the reasoning, not just the answer."
      ]
    }
  },

  subjectDiscoveryRewards:[
    {count:3,reward:{sparks:25,item:{name:"Companion Subject Scout Pin",slot:"wall"}}},
    {count:6,reward:{sparks:50,xp:50,item:{name:"Companion Multi-Subject Ribbon",slot:"wall"}}},
    {count:10,reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Companion Scholar Crest",slot:"wall"}}}
  ]
};
