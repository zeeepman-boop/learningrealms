// Game Fun Pack 6: Subject Mastery Paths
// Adds per-subject mastery XP, ranks, rank rewards, subject titles, and a Mastery Paths screen.
// Engine patch lives in app.js.

window.LR_MASTERY_PATH_CONFIG = {
  xp:{
    correctLesson:5,
    bossWin:40,
    portfolioPrompt:20
  },

  ranks:[
    {rank:1,name:"Novice",xp:0,reward:{sparks:10,xp:10}},
    {rank:2,name:"Apprentice",xp:50,reward:{sparks:25,xp:25,item:{name:"Apprentice Subject Token",slot:"shelf"}}},
    {rank:3,name:"Adept",xp:125,reward:{sparks:40,xp:40,item:{name:"Adept Study Banner",slot:"wall"}}},
    {rank:4,name:"Skilled",xp:250,reward:{sparks:60,xp:60,ancientCoins:1,item:{name:"Skilled Scholar Crest",slot:"wall"}}},
    {rank:5,name:"Expert",xp:425,reward:{sparks:85,xp:85,ancientCoins:1,item:{name:"Expert Subject Trophy",slot:"shelf"}}},
    {rank:6,name:"Master",xp:650,reward:{sparks:125,xp:125,ancientCoins:2,item:{name:"Mastery Path Statue",slot:"shelf"}}},
    {rank:7,name:"Grandmaster",xp:950,reward:{sparks:175,xp:175,ancientCoins:3,item:{name:"Grandmaster Realm Banner",slot:"wall"}}}
  ],

  subjectFlavor:{
    Reading:{title:"Wordwarden",icon:"📖",item:"Wordwarden Candle"},
    Math:{title:"Number Knight",icon:"🔢",item:"Number Knight Gear"},
    Science:{title:"Marsh Scholar",icon:"🔬",item:"Marsh Scholar Lens"},
    History:{title:"Timeline Keeper",icon:"🏛️",item:"Timeline Keeper Tablet"},
    English:{title:"Sentence Smith",icon:"✍️",item:"Sentence Smith Quill"},
    Writing:{title:"Story Scribe",icon:"🪶",item:"Story Scribe Ink"},
    Art:{title:"Dragonbrush Artist",icon:"🎨",item:"Dragonbrush Artist Scale"},
    Civics:{title:"Council Scholar",icon:"⚖️",item:"Council Scholar Seal"},
    Geography:{title:"Mapmaker",icon:"🧭",item:"Mapmaker Compass"},
    Economics:{title:"Market Mind",icon:"🪙",item:"Market Mind Coin"},
    Logic:{title:"Puzzle Sage",icon:"🧩",item:"Puzzle Sage Gear"},
    Nature:{title:"Wildroot Naturalist",icon:"🌿",item:"Wildroot Naturalist Leaf"},
    Health:{title:"Hearthwell Helper",icon:"🫀",item:"Hearthwell Helper Lantern"},
    Music:{title:"Bardwood Listener",icon:"🎵",item:"Bardwood Listener Note"},
    Copywork:{title:"Abbey Scribe",icon:"✒️",item:"Abbey Scribe Seal"},
    LifeSkills:{title:"Homestead Hand",icon:"🧰",item:"Homestead Hand Checkmark"}
  },

  multiSubjectMilestones:[
    {id:"three_rank2",rank:2,count:3,title:"Triple Apprentice",reward:{sparks:60,xp:60,item:{name:"Triple Apprentice Crest",slot:"wall"}}},
    {id:"five_rank3",rank:3,count:5,title:"Fivefold Adept",reward:{sparks:100,xp:100,ancientCoins:1,item:{name:"Fivefold Adept Banner",slot:"wall"}}},
    {id:"three_rank5",rank:5,count:3,title:"Three-Path Expert",reward:{sparks:150,xp:150,ancientCoins:2,item:{name:"Three-Path Expert Trophy",slot:"shelf"}}},
    {id:"one_rank6",rank:6,count:1,title:"First Subject Master",reward:{sparks:200,xp:200,ancientCoins:2,item:{name:"First Subject Master Statue",slot:"shelf"}}}
  ]
};
