// Game Fun Pack 12: World Atlas & Fast Travel
// Adds a realm atlas, fast travel, zone discovery, route hints, and hub cards.
// Engine patch lives in app.js.

window.LR_WORLD_ATLAS_CONFIG = {
  title:"World Atlas & Fast Travel",

  categories:[
    {id:"core",title:"Core Adventure Realms",icon:"🏰"},
    {id:"subject",title:"Subject Realms",icon:"📚"},
    {id:"town",title:"Town, Shops, and Home",icon:"🏡"},
    {id:"systems",title:"Game Systems",icon:"⚙️"}
  ],

  hubs:[
    // Town / core
    {id:"crossroads",title:"Crossroads",zone:"Crossroads",category:"town",icon:"🧭",desc:"Main travel crossroads."},
    {id:"questBoardPlaza",title:"Quest Board Plaza",zone:"Quest Board Plaza",category:"systems",icon:"📜",desc:"Daily quests, weekly quests, classroom plan, campaigns, gauntlets, and reports."},
    {id:"home",title:"Home",zone:"Home",category:"town",icon:"🏠",desc:"Storage, rooms, companion areas, collection access, and family halls."},
    {id:"seasonalShop",title:"Seasonal Shop",zone:"Market Row",category:"town",icon:"🎁",desc:"Festival and seasonal shop items."},
    {id:"pictureShop",title:"Picture Shop",zone:"Picture Row",category:"town",icon:"🖼️",desc:"Frames, pictures, and home wall rewards."},
    {id:"luckyKettle",title:"Lucky Kettle",zone:"Clover Lane",category:"town",icon:"🍲",desc:"Diner and treat shop."},
    {id:"shiftyTent",title:"Shifty Tent",zone:"Crooked Alley",category:"town",icon:"🎪",desc:"Ancient Coin relic shop."},

    // Original subject realms
    {id:"whisperGate",title:"Whisperwood Gate",zone:"Whisperwood",category:"subject",subject:"Reading",icon:"📖",desc:"Reading, stories, comprehension, and word work."},
    {id:"ironGate",title:"Iron Hills Gate",zone:"Iron Hills",category:"subject",subject:"Math",icon:"🔢",desc:"Math, numbers, operations, algebra paths, and geometry."},
    {id:"crystalMarsh",title:"Crystal Marsh",zone:"Crystal Marsh",category:"subject",subject:"Science",icon:"🔬",desc:"Science, observation, weather, nature patterns, and experiments."},
    {id:"recordVault",title:"Kingdom Archives",zone:"Kingdom Archives",category:"subject",subject:"History",icon:"🏛️",desc:"History, timelines, evidence, maps, and old records."},
    {id:"grammarRoad",title:"Grammar Grove",zone:"Grammar Grove",category:"subject",subject:"English",icon:"✍️",desc:"English, grammar, spelling, punctuation, and sentences."},
    {id:"dragonbrushGate",title:"Dragonbrush Vale",zone:"Dragonbrush Vale",category:"subject",subject:"Art",icon:"🎨",desc:"Art, dragons, color, line, shape, galleries, and creative quests."},

    // New realm pack hubs
    {id:"councilGate",title:"Councilhall Citadel",zone:"Councilhall Citadel",category:"subject",subject:"Civics",icon:"⚖️",desc:"Civics, laws, rights, responsibilities, courts, and government."},
    {id:"mapmakerGate",title:"Mapmaker's Expanse",zone:"Mapmaker's Expanse",category:"subject",subject:"Geography",icon:"🧭",desc:"Maps, directions, landforms, regions, and human geography."},
    {id:"merchantGate",title:"Merchant Row",zone:"Merchant Row",category:"subject",subject:"Economics",icon:"🪙",desc:"Needs, wants, money, trade, markets, scarcity, and budgets."},
    {id:"puzzleGate",title:"Puzzle Spire",zone:"Puzzle Spire",category:"subject",subject:"Logic",icon:"🧩",desc:"Logic, patterns, evidence, analogies, and critical thinking."},
    {id:"wildrootGate",title:"Wildroot Preserve",zone:"Wildroot Preserve",category:"subject",subject:"Nature",icon:"🌿",desc:"Nature study, habitats, field notes, weather, plants, and animal signs."},
    {id:"hearthwellGate",title:"Hearthwell Clinic",zone:"Hearthwell Clinic",category:"subject",subject:"Health",icon:"🫀",desc:"Body science, healthy habits, hygiene, nutrition, sleep, and safety."},
    {id:"bardwoodGate",title:"Bardwood Hall",zone:"Bardwood Hall",category:"subject",subject:"Music",icon:"🎵",desc:"Music, rhythm, tempo, melody, instruments, and listening."},
    {id:"scribeGate",title:"Scribe's Abbey",zone:"Scribe's Abbey",category:"subject",subject:"Copywork",icon:"✒️",desc:"Handwriting, copywork, spacing, punctuation, proofreading, and accuracy."},
    {id:"homesteadGate",title:"Homestead Workshop",zone:"Homestead Workshop",category:"subject",subject:"LifeSkills",icon:"🧰",desc:"Life skills, time, chores, measuring, tools, safety, and practical problem solving."},

    // System shortcuts
    {id:"atlas_system_report",title:"Report Center Shortcut",zone:"System",category:"systems",systemAction:"report",icon:"📘",desc:"Open the Homeschool Report Center."},
    {id:"atlas_system_schedule",title:"Classroom Schedule Shortcut",zone:"System",category:"systems",systemAction:"schedule",icon:"🏫",desc:"Open classroom schedule and focus blocks."},
    {id:"atlas_system_campaigns",title:"Story Campaign Shortcut",zone:"System",category:"systems",systemAction:"campaigns",icon:"📜",desc:"Open Story Campaign quest chains."},
    {id:"atlas_system_gauntlets",title:"Boss Gauntlet Shortcut",zone:"System",category:"systems",systemAction:"gauntlets",icon:"⚔️",desc:"Open Boss Gauntlets and capstone trials."},
    {id:"atlas_system_adaptive",title:"Adaptive Review Shortcut",zone:"System",category:"systems",systemAction:"adaptive",icon:"🛟",desc:"Open weak-skill rescue and adaptive review."},
    {id:"atlas_system_collection",title:"Collection Log Shortcut",zone:"System",category:"systems",systemAction:"collection",icon:"📖",desc:"Open collection log and titles."}
  ],

  travelRewards:[
    {count:5,title:"Atlas Walker",reward:{sparks:30,xp:30,item:{name:"Atlas Walker Badge",slot:"wall"}}},
    {count:10,title:"Realm Hopper",reward:{sparks:60,xp:65,ancientCoins:1,item:{name:"Realm Hopper Boots",slot:"shelf"}}},
    {count:16,title:"World Atlas Keeper",reward:{sparks:120,xp:130,ancientCoins:2,item:{name:"World Atlas Keeper Globe",slot:"shelf"}}}
  ],

  discoveryRewards:[
    {count:5,title:"Five Hub Discovery",reward:{sparks:35,xp:35,item:{name:"Five Hub Discovery Pin",slot:"wall"}}},
    {count:10,title:"Ten Hub Discovery",reward:{sparks:75,xp:80,ancientCoins:1,item:{name:"Ten Hub Discovery Map",slot:"wall"}}},
    {count:16,title:"Great Realm Survey",reward:{sparks:150,xp:175,ancientCoins:2,item:{name:"Great Realm Survey Banner",slot:"wall"}}}
  ]
};
