// Grade Ladder Rewards v1
// Academic band rewards separate from RPG level rewards.
// This makes starting at Kindergarten feel like clearing starter zones, not remedial work.

window.LR_GRADE_LADDER_REWARDS = {
  bandRewards:{
    K:{
      title:"Kindergarten Trail Cleared",
      badge:"Kindergarten Trail Badge",
      sparks:50,
      xp:75,
      ancientCoins:1,
      homeReward:{name:"Kindergarten Trail Banner",slot:"wall"},
      unlock:"Starter Zone Clear",
      message:"Kindergarten foundations cleared. Starter trail rewards unlocked."
    },
    G1:{
      title:"Grade 1 Gatekeeper",
      badge:"Grade 1 Gate Badge",
      sparks:75,
      xp:100,
      ancientCoins:1,
      homeReward:{name:"Grade 1 Gate Trophy",slot:"shelf"},
      unlock:"First Grade Gate Clear",
      message:"Grade 1 foundations cleared. Early learning gate rewards unlocked."
    },
    G2:{
      title:"Grade 2 Pathwalker",
      badge:"Grade 2 Path Badge",
      sparks:100,
      xp:125,
      ancientCoins:2,
      homeReward:{name:"Grade 2 Path Map",slot:"wall"},
      unlock:"Old Road Clear",
      message:"Grade 2 path cleared. More advanced review rewards unlocked."
    },
    G3:{
      title:"Grade 3 Skill Seeker",
      badge:"Grade 3 Skill Badge",
      sparks:125,
      xp:150,
      ancientCoins:2,
      homeReward:{name:"Grade 3 Skill Lantern",slot:"shelf"},
      unlock:"Skill Pass Clear",
      message:"Grade 3 skill pass cleared. Rare shop gate seed unlocked for future use."
    },
    G4:{
      title:"Grade 4 Trial Runner",
      badge:"Grade 4 Trial Badge",
      sparks:150,
      xp:175,
      ancientCoins:3,
      homeReward:{name:"Grade 4 Trial Shield",slot:"wall"},
      unlock:"Trial Fields Clear",
      message:"Grade 4 trial fields cleared. Stronger mastery reward unlocked."
    },
    G5:{
      title:"Grade 5 Scholar",
      badge:"Grade 5 Scholar Badge",
      sparks:175,
      xp:200,
      ancientCoins:3,
      homeReward:{name:"Grade 5 Scholar Crest",slot:"wall"},
      unlock:"Scholar Gate Clear",
      message:"Grade 5 scholar gate cleared. Ancient Coin chances can expand from here."
    },
    G6:{
      title:"Grade 6 Bridgewalker",
      badge:"Grade 6 Bridge Badge",
      sparks:225,
      xp:250,
      ancientCoins:4,
      homeReward:{name:"Grade 6 Mastery Bridge Model",slot:"shelf"},
      unlock:"Mastery Bridge Clear",
      message:"Grade 6 mastery bridge cleared. Upper academy path unlocked."
    },
    G7:{
      title:"Grade 7 Realm Scholar",
      badge:"Grade 7 Realm Badge",
      sparks:300,
      xp:325,
      ancientCoins:5,
      homeReward:{name:"Grade 7 Realm Scholar Statue",slot:"shelf"},
      unlock:"Current Realm Clear",
      message:"Grade 7 current realm cleared. Advanced capstone rewards unlocked."
    },
    G8:{
      title:"Grade 8 High Scholar",
      badge:"Grade 8 High Scholar Badge",
      sparks:350,
      xp:400,
      ancientCoins:6,
      homeReward:{name:"Grade 8 High Scholar Banner",slot:"wall"},
      unlock:"High Scholar Clear",
      message:"Grade 8 high scholar path cleared."
    },
    GEO:{
      title:"Geometry Gate Scholar",
      badge:"Geometry Gate Badge",
      sparks:375,
      xp:450,
      ancientCoins:6,
      homeReward:{name:"Geometry Gate Compass",slot:"shelf"},
      unlock:"Geometry Gate Clear",
      message:"Geometry gate cleared. Shape, proof, and measurement rewards unlocked."
    }
  },

  capstoneRewards:{
    Luna:{
      title:"Luna First Grade Capstone",
      badge:"Luna Grade 1 Capstone Badge",
      sparks:250,
      xp:300,
      ancientCoins:3,
      homeReward:{name:"Luna First Grade Crowned Star",slot:"shelf"},
      message:"Luna mastered her current Grade 1 cap. Her cap can be raised later when ready."
    },
    Ava:{
      title:"Ava Grade 6 Capstone",
      badge:"Ava Grade 6 Capstone Badge",
      sparks:400,
      xp:500,
      ancientCoins:5,
      homeReward:{name:"Ava Grade 6 Scholar Banner",slot:"wall"},
      message:"Ava mastered her current Grade 6 cap. Her cap can be raised later when ready."
    },
    Michael:{
      title:"Michael Grade 7 Capstone",
      badge:"Michael Grade 7 Capstone Badge",
      sparks:500,
      xp:650,
      ancientCoins:7,
      homeReward:{name:"Michael Grade 7 Mastery Relic",slot:"shelf"},
      message:"Michael mastered his current Grade 7 cap. His cap can be raised later when ready."
    }
  },

  futureGateIdeas:{
    K:["starter cosmetic shelf items","basic banners","first room decorations"],
    G1:["extra color choices","beginner shop stock","first capstone boss"],
    G2:["new road cosmetics","extra pet trinkets","early mystery clues"],
    G3:["Shifty Salesman rare shelf 1","special study tools","minor clothing unlock"],
    G4:["trial field boss chain","better wall trophies","festival item tier"],
    G5:["Ancient Coin bonus chances","rare gallery frame","advanced portfolio projects"],
    G6:["upper academy gate","harder boss chains","rare outfit slot items"],
    G7:["current realm mastery bosses","rare Art dragon rewards","advanced shop stock"],
    G8:["high scholar district","research boss chains","legendary capstone trophies"],
    GEO:["geometry gate","proof challenge chain","compass and straightedge relics"]
  }
};
