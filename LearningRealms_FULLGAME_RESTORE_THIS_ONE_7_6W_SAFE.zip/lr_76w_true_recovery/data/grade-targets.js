// Grade Completion Targets v1
// This file is intentionally separate so the game can grow to thousands of questions,
// more subjects, and larger yearly targets without rewriting the engine.

window.LR_GRADE_CONFIG = {
  defaults:{
    targetCorrect:250,
    bossTarget:1,
    note:"Unknown/new subjects automatically use this default target unless listed below."
  },

  Luna:{
    gradeLabel:"Grade 1 Core",
    longGoal:"Build first-grade readiness across phonics, reading, writing, math, science, and social studies.",
    subjects:{
      Reading:{display:"Reading / Phonics",targetCorrect:550,bossTarget:3},
      English:{display:"Writing / Grammar",targetCorrect:350,bossTarget:2},
      Math:{display:"Math",targetCorrect:500,bossTarget:3},
      Science:{display:"Science",targetCorrect:250,bossTarget:1},
      History:{display:"Social Studies",targetCorrect:200,bossTarget:1},
      Civics:{display:"Civics / Rules / Community",targetCorrect:150,bossTarget:1}
    }
  },

  Ava:{
    gradeLabel:"Grade 7 Core",
    longGoal:"Build seventh-grade strength in math, evidence-based reading, writing, science, history, and civics.",
    subjects:{
      Math:{display:"Grade 7 Math",targetCorrect:700,bossTarget:4},
      English:{display:"ELA / Writing",targetCorrect:550,bossTarget:3},
      Reading:{display:"Literature / Reading Response",targetCorrect:350,bossTarget:2},
      Science:{display:"Life / Earth / Physical Science",targetCorrect:500,bossTarget:3},
      History:{display:"History / Social Studies",targetCorrect:400,bossTarget:2},
      Civics:{display:"Civics / Economics",targetCorrect:250,bossTarget:1},
      Writing:{display:"Writing",targetCorrect:300,bossTarget:1}
    }
  },

  Michael:{
    gradeLabel:"Grade 8 Core",
    longGoal:"Build eighth-grade readiness across algebra, functions, argument writing, science, civics, and history.",
    subjects:{
      Math:{display:"Grade 8 Math / Algebra",targetCorrect:800,bossTarget:4},
      English:{display:"ELA / Argument Writing",targetCorrect:600,bossTarget:3},
      Reading:{display:"Literature / Source Reading",targetCorrect:350,bossTarget:2},
      Science:{display:"Physical / Earth Science",targetCorrect:600,bossTarget:3},
      History:{display:"History / Civics",targetCorrect:500,bossTarget:3},
      Civics:{display:"Civics / Government",targetCorrect:300,bossTarget:2},
      Writing:{display:"Research / Writing",targetCorrect:350,bossTarget:2}
    }
  }
};
