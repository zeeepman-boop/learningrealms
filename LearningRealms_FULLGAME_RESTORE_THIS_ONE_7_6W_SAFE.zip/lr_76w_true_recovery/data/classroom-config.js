// Classroom / Attendance Config v1
// Separate config file so daily minute goals, subjects, and assignment sizes can grow later.

window.LR_CLASSROOM_CONFIG = {
  dailyInstructionMinutes: 360,
  exactKYAnnualNote:"Kentucky's published homeschool packet references 1,062 instructional hours in no less than 170 attendance days. This game defaults to a 6-hour simulated classroom day, but the target can be raised if you want a stricter daily average.",
  assignmentSubjects:{
    Luna:["Reading","Math","English","Science","History"],
    Ava:["Math","English","Science","History","Reading"],
    Michael:["Math","Science","English","History","Civics"]
  },
  dailyQuestionTargets:{
    Luna:{Reading:12,Math:10,English:6,Science:4,History:3},
    Ava:{Math:14,English:8,Science:6,History:5,Reading:5},
    Michael:{Math:14,Science:8,English:8,History:6,Civics:4}
  },
  timeBlocks:{
    Luna:[
      ["Reading / Phonics",70],
      ["Math",65],
      ["Writing / Grammar",45],
      ["Science / Nature",35],
      ["Social Studies",30],
      ["Review / Boss Prep",35],
      ["Exploration / Projects / Read Aloud",80]
    ],
    Ava:[
      ["Math",80],
      ["ELA / Writing",70],
      ["Science",55],
      ["History / Civics",50],
      ["Review / Boss Prep",45],
      ["Exploration / Projects / Reading",60]
    ],
    Michael:[
      ["Math / Algebra",85],
      ["Science",70],
      ["ELA / Argument Writing",65],
      ["History / Civics",55],
      ["Review / Boss Prep",45],
      ["Exploration / Projects / Reading",40]
    ]
  }
};
