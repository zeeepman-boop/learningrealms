Learning Realms Stable Skeleton v1

This is the new base-game structure.

Core files:
- index.html
- style.css
- app.js

Data files:
- data/rooms.js
- data/campaigns.js
- data/rewards.js
- data/core-lessons.js

Expansion packs:
- expansions/luna-reading-01.js
- expansions/ava-math-01.js
- expansions/michael-math-01.js

How to add curriculum:
1. Create a new JS file in /expansions/
2. Add lessons using:
   LR_addLessons("Luna", "Reading", [
     {teach:"...", practice:"...", q:"...", c:["A","B","C"], a:"A"}
   ]);
3. Add a script tag for the file in index.html before app.js.

This lets curriculum grow forever without changing the engine.


Documentation added:
- FEATURE_LEDGER.txt
- STABILITY_CHECKLIST.txt
- SAFE_EXPANSION_RULES.txt
- VERSION_LOG.txt
